# FINAL — Implementation Plan

> **Purpose:** canonical delivery roadmap, stable package catalog/DAG, owner decisions, mutable-value register, uncertainties, acceptance strategy, and supersession/move history.
> **Owns:** numeric §§6–11, package IDs, decisions #1–#20, `TH-*`, `AR-*`, `AT-*`, and Appendix A.
> **Siblings:** [index](FINAL-INDEX.md) owns set membership and namespaces; [architecture](FINAL-architecture-2026-08-26.md) owns principles, as-built evidence, topology, boundaries, capabilities, adjudications, and sources; [todo](FINAL-todo-2026-08-27.md) owns mutable `T-*` state; [pipeline](FINAL-pipeline-2026-08-27.md) owns `PIPE-*`; [contracts](FINAL-contracts-2026-08-27.md) owns `SCHEMA-*`; [runbooks](FINAL-runbooks-2026-08-27.md) owns `RB-*`.
> **Last updated:** 2026-08-27.
> **One fact, one home:** §6 names stage outcomes, planning ranges, and package IDs; §7 owns package scope/dependencies; TODO owns execution state/evidence; §9 owns runtime, policy, and evaluation mutable values; §11 owns acceptance intent, while exact mechanics/shapes/procedures remain in their companions.

Dev-day ranges assume approximately four implementation days per calendar week. Waits for access, shadow evidence, approvals, or owner decisions are stated separately and are never converted into probability claims. The authoritative deployment is decision #1; this analysis copy is not mutated as if it were that deployment.

## Contents

6. [Delivery roadmap](#6-delivery-roadmap)
7. [Work packages](#7-work-packages)
8. [Owner decisions](#8-owner-decisions)
9. [Thresholds and mutable values](#9-thresholds-and-mutable-values)
   - [9.2 As-built values](#92-as-built-values)
10. [Open uncertainties](#10-open-uncertainties)
11. [Acceptance test strategy](#11-acceptance-test-strategy)
- [Appendix A — Supersession and move map](#appendix-a--supersession-and-move-map)
- [Whole-set membership and ownership](FINAL-INDEX.md)

---

## 6. Delivery roadmap

Stage tables own outcomes and package allocation, not package scope.

| Stage | Package IDs | Dev-days | Exit gate | First user value |
|---|---|---:|---|---|
| **−1 Preserve and decide** | `PRESERVE-00`, `RETENTION-01`; probes `T-AR-19` and `T-AR-21` | 1–2 | `AT-PRESERVE-00` accepts a verified `SCHEMA-CFG-10` pre-evidence receipt with `deployment_seed_receipt.seed_sha256` plus an `RB-RESTORE-00` empty-directory restore; automerge disabled; decision #20 closed with schema/test branch | preservation and an implementable evidence policy |
| **0 Runtime, auth, doctor** | `RUNTIME-01`, `DOCTOR-01` plus `RB-AUTH-01` and `RB-AUTH-02`; probes `T-AR-10`, `T-AR-11`, `T-AR-12`, and `T-AR-17` | 3–5 | locked runtime and doctor pass clean/negative fixtures; zero-secret auth procedure exists before connector work | `wiki doctor` and an operable auth path |
| **1 Truthful local navigation** | `IDX-01`, `SRC-00`, `QUERY-01` | 5–8 | missing evidence cannot display green; indexed pages are findable; answer cards meet `TH-TGT-015` and `TH-TGT-016` in an accepted run-local `SCHEMA-REL-04` result produced from `tests/query/golden.json` and compared with its digest-bound baseline manifest/result | local search, ownership, questions, backlinks, truthful legacy UNVERIFIED state |
| **2 Contracts and safe publication** | `CONTRACT-01`, `KIRO-SEC-01R`, `VER-01`, `TXN-01R`, early milestone of `AUTH-02` | 6–10 | generated-schema drift gate passes; production trust flag absent; `AT-SEC-GUARD-01` passes before real acquisition; every mutation-boundary fault preserves integrity; minimal authority/protected behavior is available before source conflict handling | failed runs cannot corrupt the published set |
| **3 Confluence evidence and operations** | `CONFLUENCE-01`, `FRESH-01R`, `KEYFACTS-01`, `SUMMARY-01`, `MONITOR-01`, `BACKUP-01`, `DISCOVERY-01`; probes `T-AR-16` and `T-AR-20` | 8–14 plus auth/shadow waits | decision #20 branch enforced; completed events/raw/index recover; Confluence discovery/backfill/trace CLI work; shadow batches explain every discrepancy; unhealthy never wakes writer; independent `SCHEMA-CFG-13` backup and dead-man receipts validate | `wiki trace-source`, morning health, verified evidence backup |
| **4 Assistants, capture, portability** | `MCP-QUERY-01`, `CAPTURE-01`, `FRAMEWORK-01`; probes `T-AR-13` and `T-AR-23` | 6–10 | query cannot write, capture cannot publish, capture ID follows durable submission, abstention/conflict fixtures pass, client parity and symlinkless restore pass | query/capture from Claude Code, local Copilot, and Kiro |
| **5 Multi-source governance** | `PORTAL-01`, `PORTAL-02`, `PORTAL-03`, `REPO-01`, `WEB-01`, `META-02`, full milestone of `AUTH-02`, `CODE-01`, `RENUMBER-01`, `RETIRE-01`, `READY-01`, `DRILL-01`; probes `T-AR-14`, `T-AR-15`, and `T-AR-22` | 10–20 plus source waits | each connector shadows before publication; owner and discovery gates meet `TH-TGT-017`, `TH-TGT-018`, and `TH-TGT-038`; retirement/renumber are bounded by `TH-TGT-034`, `TH-TGT-035`, `TH-TGT-036`, `TH-TGT-037`, `TH-TGT-050`, `TH-TGT-054`, and `TH-TGT-061`; placement/provenance/canonical/code invariants pass; restore, rollback, torn-acquisition, injection, and provider drills pass | consistent freshness/authority across governed sources |
| **6 Reproducible evaluation** | `EVAL-01` | ongoing | reviewed `SCHEMA-REL-05` result over the versioned `TH-TGT-064` suite, complete lineage, `TH-TGT-002` and `TH-TGT-003` floors, and an explicit adopt/reject record against each applicable `TH-TGT-023`, `TH-TGT-024`, `TH-TGT-025`, `TH-TGT-026`, `TH-TGT-027`, `TH-TGT-028`, `TH-TGT-065`, `TH-TGT-066`, `TH-TGT-067`, `TH-TGT-068`, `TH-TGT-069`, `TH-TGT-070`, and `TH-TGT-071` gate | evidence-gated search/extraction/orchestration upgrades |

Arithmetic from the stage rows: foundation through Stage 2 is **15–25 dev-days**; through Stage 4 is **29–49 dev-days**; through Stage 5 is **39–69 dev-days**. These totals exclude access waits, shadow cadence, and source-specific remediation. Stage 1 is the first no-credential value point; AR-16 and decision #20 gate Stage 3 persistence.

Surface contract by stage: Stage 1 maps legacy/missing evidence to UNVERIFIED and offers a manual handoff, not a capture ID; Stage 3 adds CLI trace after real evidence exists; Stage 4 adds consent → durable capture → ID and read-only MCP. Prose is the default human output and `--json` is the machine form for doctor, health, query, and lifecycle administration.

## 7. Work packages

### 7.1 Package catalog

Each row is one stable scope. Mutable state, commands, receipts, and blockers live only in the matching `T-*` card.

| ID | Stage | Scope | Exit owner |
|---|---:|---|---|
| `PRESERVE-00` | −1 | pre-mutation repository bundles, accepted Stage −1 `deployment_seed_receipt` and `seed_sha256`, `SCHEMA-CFG-10` receipt, `RB-RESTORE-00` empty-dir restore, automerge-off and redaction baseline; it does not own `orchestrator/deploy.yaml` | `AT-PRESERVE-00` |
| `RETENTION-01` | −1 | decision #20 record, versioned retention/hold policy branch, migration and non-resurrection/negative fixtures | `AT-RETENTION-01` |
| `RUNTIME-01` | 0 | locked Python/runtime, qualified Bash/tool paths, sole canonical `orchestrator/deploy.yaml` using the accepted `deployment_seed_receipt.seed` as a required invariant input, desired deployment/scheduler derivatives | `AT-STAGE-0` |
| `DOCTOR-01` | 0 | `SCHEMA-CFG-03` implementation, deployment/auth/job/lock/dead-man probes | `AT-STAGE-0` |
| `IDX-01` | 1 | Jenkins index repair and blocking index-coverage gate | `AT-MECH-16` |
| `SRC-00` | 1 | legacy no-coverage/skip false-green hotfix | `AT-FRESH-TOTAL` |
| `QUERY-01` | 1 | deterministic catalog/CLI/private guard, dedicated `SCHEMA-CFG-19` ownership result, page template, pinned `tests/query/golden.json`, digest-bound `tests/query/baselines/stage1-manifest.json` and `tests/query/baselines/stage1-metrics.jsonl`, plus an accepted run-local `SCHEMA-REL-04` result for `TH-TGT-015` and `TH-TGT-016` | `AT-B-QUERY` |
| `CONTRACT-01` | 2 | generate/validate every `SCHEMA-*` artifact and fixture from canonical contract IR | `AT-A-CONTRACT` |
| `KIRO-SEC-01R` | 2 | least-capability profiles, production trust-flag removal, handoff renderer/lint, shared pre-persistence classification and egress guard, and hostile-input fixtures | `AT-A-HANDOFF`, `AT-SEC-GUARD-01` |
| `VER-01` | 2 | no-write verifier and exact current-input/diff/tree binding | `AT-C-TRANSACTION` |
| `TXN-01R` | 2 | `PIPE-*` workspaces, gates, results, journal/CAS release, finalizer and recovery | `AT-C-TRANSACTION` |
| `AUTH-02` | 2/5 | early read-only authority/protected resolver before Stage 3; full authority/owner projection rollout in Stage 5 | `AT-AUTH-02-EARLY`, `AT-AUTH-02-RESOLUTION` |
| `CONFLUENCE-01` | 3 | REST provider and adapter over the shared classification/egress guard, raw/object/index/event/marker writers, registry/backfill and shadow fixtures | `AT-B-CONNECTORS` |
| `FRESH-01R` | 3 | acquisition/semantic split, total health projection, proceed adapter, alerts/coverage evidence | `AT-FRESH-TOTAL` |
| `KEYFACTS-01` | 3 | versioned Key-Facts audit and assessment comparison evidence | `AT-KEYFACTS-01` |
| `SUMMARY-01` | 3 | deterministic every-branch morning summary and prose/JSON health projection | `AT-PIPE-FINALIZE` |
| `MONITOR-01` | 3 | generated source monitor/discovery-manifest views and legacy archive | `AT-PIPE-FINALIZE` |
| `BACKUP-01` | 3 | independent evidence/run/journal backup, relative inventory and recovery integration | `AT-E-BACKUP` |
| `DISCOVERY-01` | 3 | scoped Confluence discovery first, then provider adapters/candidate projection and recall evidence without registry mutation | `AT-DISCOVERY-01` |
| `MCP-QUERY-01` | 4 | read-only MCP, synthesis/support/conflict/abstention and three-client response normalization | `AT-D-CLIENTS` |
| `CAPTURE-01` | 4 | CLI/MCP question/note/url/file capture, enforcement adapters over the shared PII/egress guard, lifecycle admin/staging/projection | `AT-B-PII-EGRESS` |
| `FRAMEWORK-01` | 4 | generated client/workspace framework, drift/conformance and symlinkless materialization | `AT-D-CLIENTS` |
| `PORTAL-01` | 5 | first parameterized portal profile/provider and connector-gate receipt | `AT-B-CONNECTORS` |
| `PORTAL-02` | 5 | second portal profile/provider and connector-gate receipt | `AT-B-CONNECTORS` |
| `PORTAL-03` | 5 | third portal profile/provider and connector-gate receipt | `AT-B-CONNECTORS` |
| `REPO-01` | 5 | repository provider with commit ancestry/diff evidence and bounded auth | `AT-B-CONNECTORS` |
| `WEB-01` | 5 | hardened web/browser provider and source-specific enforcement adapter over the centralized SSRF/redirect/DNS-rebinding guard | `AT-B-PII-EGRESS` |
| `META-02` | 5 | registry/frontmatter owner/topic/canonical/provenance migration and placement pilot | `AT-STAGE-5` |
| `CODE-01` | 5 | code-sample dependency validation and gate rollout | `AT-STAGE-5` |
| `RENUMBER-01` | 5 | bounded proposal-only renumber/link planner with veto/rollback evidence | `AT-RENUMBER-01` |
| `RETIRE-01` | 5 | mark/grace/tombstone/disclaimer lifecycle under decision #20 | `AT-F-RETIRE` |
| `READY-01` | 5 | readiness meta-gate, negative-fixture proof and governed warn→enforce rollout | `AT-STAGE-5` |
| `DRILL-01` | 5 | restore, rollback, torn acquisition, injection, provider and source-failure drills | `AT-E-DRILLS` |
| `EVAL-01` | 6 | versioned `TH-TGT-064` evaluation corpus, runner/lineage, baseline/candidate results and review | `AT-EVAL-01-LINEAGE` |

### 7.2 Dependency graph

The package-ID labels below are exactly the §7.1 package set. `AUTH-02` is one package subgraph with two ordered internal milestones: the early output gates Confluence, while the full milestone depends on metadata rollout. The milestone graph is acyclic and neither internal milestone creates a second package.

```mermaid
flowchart TD
  subgraph A[AUTH-02]
    A0[early milestone]
    A1[full milestone]
  end
  P[PRESERVE-00] --> R[RETENTION-01]
  P --> RT[RUNTIME-01] --> D[DOCTOR-01]
  D --> I[IDX-01]
  D --> S[SRC-00]
  I --> Q[QUERY-01]
  S --> Q
  Q --> C[CONTRACT-01] --> K[KIRO-SEC-01R] --> V[VER-01] --> X[TXN-01R]
  C --> A0
  R --> CF[CONFLUENCE-01]
  X --> CF
  A0 --> CF
  CF --> F[FRESH-01R]
  F --> KF[KEYFACTS-01]
  F --> SU[SUMMARY-01]
  F --> M[MONITOR-01]
  CF --> B[BACKUP-01]
  M --> DI[DISCOVERY-01]
  SU --> MQ[MCP-QUERY-01]
  X --> CP[CAPTURE-01]
  MQ --> FW[FRAMEWORK-01]
  CP --> FW
  FW --> P1[PORTAL-01] --> P2[PORTAL-02] --> P3[PORTAL-03]
  P1 --> RP[REPO-01]
  P1 --> WB[WEB-01]
  DI --> MT[META-02]
  KF --> MT
  P3 --> MT
  RP --> MT
  WB --> MT
  A0 --> A1
  MT --> A1
  MT --> CD[CODE-01]
  MT --> RN[RENUMBER-01]
  R --> RE[RETIRE-01]
  DI --> RE
  P3 --> RE
  RP --> RE
  WB --> RE
  MT --> RE
  A1 --> RD[READY-01]
  CD --> RD
  RN --> RD
  RE --> RD
  B --> DR[DRILL-01]
  X --> DR
  RD --> DR --> EV[EVAL-01]
```

## 8. Owner decisions

Decisions #1–#19 use the recorded defaults. Decision #20 is the only unresolved owner choice and is a blocking predecessor of Stage 3 persistence, backup rotation, retirement, and purge behavior.

| # | Decision | Recorded outcome / required choice |
|---:|---|---|
| 1 | authoritative deployment | single host/tree resolved from `SCHEMA-CFG-04`; launchd jobs are desired config, not path discovery |
| 2 | raw retention medium | content-addressed git evidence with `retention_class`; repository split uses `TH-TGT-013`; subject to #20 |
| 3 | content visibility | internal; proposal classification further distinguishes standard/sensitive/personal |
| 4 | unattended publication | off through Stage 2; only fixture-proven formatting/link policy may widen; semantic edits require human approval |
| 5 | execution host | one host; no multi-host lock claim |
| 6 | assistant scheduling | tools only; deployment scheduler owns jobs |
| 7 | GitHub/Copilot cloud | no; local VS Code only; AR-18 remains out of scope |
| 8 | durable ledger | dated write-once JSONL plus rebuildable JSON views |
| 9 | valid owner values | teams already named in the corpus/policy |
| 10 | model/cost | enterprise-approved profiles; per-run and rolling controls are distinct `TH-TGT-031`, `TH-TGT-032`, and `TH-TGT-033` |
| 11 | recovery | off-host target; RPO/RTO objectives are `TH-TGT-074` and `TH-TGT-075` |
| 12 | release/approval | root plus affected wikis in one manifest; sequential evidence-first publication; rollback by audited revert release |
| 13 | worktree | validated hidden same-depth sibling; never a generic temporary directory |
| 14 | status vocabulary | core: FRESH/STALE/UNVERIFIED/CRITICAL; diagnostics: CHECK, CHECK_FAILED, NOT_STARTED, IN_PROGRESS, coverage/retry/retired; `SCHEMA-SO-04` owns precedence |
| 15 | `local_laptop` | unmanaged/private, excluded from shared catalog/MCP/generated content bundles; CLI opt-in and default note target; its private repository remains versioned and eligible for private off-OneDrive repository-bundle preservation |
| 16 | evidence encryption | FileVault only unless this decision changes; backup target applies approved at-rest controls |
| 17 | Kiro permissions/trust | probe version/behavior, migrate to proven permissions; production `--trust-all-tools` is unconditionally absent |
| 18 | Confluence deployment/auth | close AR-16 and record `deployment_profile`; do not infer from MCP success |
| 19 | runtime contracts | three wire families; subtypes/config/release/eval shapes remain `SCHEMA-*`, not extra role contracts |
| **20** | **retention, `legal_hold`, hard purge** | **choose before Stage 3:** (a) retain/quarantine-only, no hard purge; or (b) schema-versioned governed purge defining hold authority/scope/precedence, purge actor/reason/approval, tombstone/index rewrite, backup treatment and non-resurrection. Pending behavior is preserve/isolate/stop/escalate; `retention_class` is canonical and page `legal_hold=true` only freezes autonomous edit/retire. |

## 9. Thresholds and mutable values

Every row is owned by the maintainer unless a package is named. `type` controls calibration: **invariant** changes only by owner decision and full regression; **SLO/target** changes from measured evidence with a `DECISIONS.md` entry; **cap/deadline** changes after safety and false-positive review; **adoption gate** changes only with a new reviewed evaluation; **planning estimate** does not control runtime. A threshold event uses exact `TH-*` as `SCHEMA-REL-04.metric_id`; zero denominators yield null plus a reason.

| ID | Type | Value / comparator | Measurement source | Review trigger | Calibration/change rule |
|---|---|---|---|---|---|
| `TH-TGT-001` | SLO | claim-verified / reachable `>= 0.95`; reachable `=0` → undefined | `SCHEMA-REL-04` metric derived from completed eligible `SCHEMA-SO-04` observed variants: `sum(claim_verified) / sum(reachable)` | after three Stage-3 shadow batches, then quarterly | inspect FN/FP and undefined cases; documented SLO change only |
| `TH-TGT-002` | quality floor | answer accuracy `>= 0.90` | reviewed `SCHEMA-REL-05` cases | Stage 6 baseline and every provider/model/prompt/corpus-lineage change | regression blocks release; lower only by owner decision |
| `TH-TGT-003` | quality floor | citation recall `>= 0.95` | reviewed eval citations vs gold evidence | same as `TH-TGT-002` | regression blocks release |
| `TH-TGT-004` | deadline | acquisition batch `<= 15 min` | batch start/end events | Stage 3 shadow, quarterly | measured P95 plus safety margin within nightly window |
| `TH-TGT-005` | deadline | source attempt `<= 90 s` | `SCHEMA-SO-02.duration_ms` | Stage 3 shadow | measured P95 plus bounded margin |
| `TH-TGT-006` | classifier | login detection `>= 2 of 5` independent signals | authorized/login fixture confusion matrix | connector/profile change | zero harmful false negatives; review false positives |
| `TH-TGT-007` | cap | one source span `<= 64 KiB` | handoff-lint receipt | prompt/provider change | increase only after hostile/cost fixtures |
| `TH-TGT-008` | cap | total handoff `<= 512 KiB` | handoff-lint receipt | prompt/provider change | same as `TH-TGT-007` |
| `TH-TGT-009` | alert target | Confluence unhealthy recurrence `>= 3 consecutive completed batches` | source observations | Stage 3 shadow | tune from false alerts; distinct from live cumulative noise counter |
| `TH-TGT-010` | alert target | portal unhealthy recurrence `>= 1 completed batch` | source observations | each connector shadow | tune per connector evidence |
| `TH-TGT-011` | retention deadline | run evidence eligible after `30 days` | doctor/cleanup inventory | quarterly | cleanup still requires backup/no-journal/no-hold guards |
| `TH-TGT-012` | planning estimate | raw growth `100–150 MB/year` | doctor storage metric | quarterly | replace range with observed slope |
| `TH-TGT-013` | capacity cap | split raw repo at `>= 250 MB` | repository size receipt | quarterly | change only with restore/backup benchmark |
| `TH-TGT-014` | recovery target | restore-test `<= 15 min` | `RB-RESTORE-02` receipt | every drill/release | target change requires decision #11 review |
| `TH-TGT-015` | latency SLO | query P95 `< 250 ms` | accepted `state/runs/<run_id>/delivery/T-QUERY-01-01/stage1-metrics.jsonl` `SCHEMA-REL-04` result from the pinned corpus/manifest/baseline | Stage 1 and corpus growth | measured P95; errors stay in the denominator and cannot be hidden |
| `TH-TGT-016` | quality floor | navigation Recall@5 `>= 0.90` | the same accepted Stage-1 run result; Stage 6 additionally evaluates the reviewed lineage suite | Stage 1, Stage 6, corpus-lineage change | regression blocks release |
| `TH-TGT-017` | rollout gate | owner coverage `>= 0.50` for Stage-5 pilot | readiness metric | pilot exit | no autonomy widening |
| `TH-TGT-018` | governance invariant | active-page owner coverage `= 1.00` before decision #4 widens | readiness metric | autonomy decision | invariant unless decision #4 changes |
| `TH-TGT-019` | cap | raw object uncompressed body `<= 5 MB` | connector fixture/storage receipt | Stage 3 | oversize is partial; raise only with restore/security evidence |
| `TH-TGT-020` | representation cap | payloads `> 1 MiB` use deterministic gzip | object validator | Stage 3 | representation-only; identity stays uncompressed |
| `TH-TGT-021` | deadline | LIGHT invocation `<= 180 min` | global `run-result/1` | Stage 3, scheduler change | measured P95 within work-day boundary |
| `TH-TGT-022` | schedule cap | target stagger `= 300 s` between wiki starts | scheduler/run events | Stage 3 | change from contention evidence |
| `TH-TGT-023` | adoption gate | lexical miss rate `> 0.20` triggers FTS evaluation, not adoption | reviewed eval | Stage 6 | adoption requires benchmark record |
| `TH-TGT-024` | canary | corpus pages `> 500` triggers search eval | catalog metric | Stage 6 | canary only |
| `TH-TGT-025` | canary | deterministic search scan `> 3 s` triggers eval | query benchmark | Stage 6 | canary only |
| `TH-TGT-026` | canary | search users `>= 3/week` triggers eval | redacted usage count | Stage 6 | observational, never authority |
| `TH-TGT-027` | warning deadline | page review age `> 90 days` warns before answer | page/view metric | Stage 6 | calibrate stale FP/FN |
| `TH-TGT-028` | adoption gate | semantic Recall@5 gain `>= 0.15` over lexical | same eval corpus | Stage 6 | include latency/citation/security cost |
| `TH-TGT-029` | invariant | every completed failure/recovery leaves published pointer on a fully verified release (`=1.00`) | release journal/pointer/heads | every transaction test and run | never error-budgeted; mixed is failed recovery state |
| `TH-TGT-030` | reliability SLO | scheduled terminal succeeded/degraded `>= 0.98` over 28 days | scheduler-to-terminal join | monthly | excludes integrity; tune only with error-budget record |
| `TH-TGT-031` | cap | per-run token use `<= 200000`; breach aborts phase | `SCHEMA-RR-01.usage` | after AR-10 and monthly | measured safe cap |
| `TH-TGT-032` | cap | per-run USD brake initially null; breach aborts phase | usage/metrics | after AR-10 and observation | set from approved per-run distribution |
| `TH-TGT-033` | budget | rolling 28-day USD budget initially null; breach alerts/blocks widening, does not abort an active phase | metrics | after four weeks | set separately from per-run brake |
| `TH-TGT-034` | deadline | retirement grace `>= 14 calendar days` | proposal/disposition events | Stage 5 | legal/governance review |
| `TH-TGT-035` | action cap | retire actions `<= 3/run` | gate evidence | Stage 5 pilot | lower on adverse effect; raise only after rollback evidence |
| `TH-TGT-036` | action cap | reroute actions `<= 1/run` | gate evidence | Stage 5 pilot | same |
| `TH-TGT-037` | action cap | renumber actions `<= 1/run` | gate evidence | Stage 5 pilot | same |
| `TH-TGT-038` | discovery SLO | tracked / discoverable source pages `>= 0.90` | discovery vs registry | Stage 5 | defined scope/zero case required |
| `TH-TGT-039` | advisory target | median concept links/page `>= 3` | backlinks view | Stage 6 | no blocking use before eval |
| `TH-TGT-040` | advisory target | backlink coverage `>= 0.80` | backlinks view | Stage 6 | same |
| `TH-TGT-041` | advisory cap | orphan-by-link `<= 0.05` | backlinks view | Stage 6 | same |
| `TH-TGT-042` | adoption gate | resumability engine considered after `>= 3` restart-insufficient failures/month | failure classes | Stage 6 | prove simpler restart cannot solve |
| `TH-TGT-043` | routing trigger | recurring out-of-bound topic `>= 3` occurrences | routing proposals | governance review | human bootstrap still required |
| `TH-TGT-044` | routing trigger | projected new wiki `>= 5` pages | routing proposals | governance review | human bootstrap still required |
| `TH-TGT-045` | policy cap | Key Facts/source `<= 3` | registry validator | Stage 3 audit | expand only with assessor-cost evidence |
| `TH-TGT-046` | timeout | HTTP connect `<= 10 s` | connector timings | connector shadow | P95 plus margin |
| `TH-TGT-047` | timeout | HTTP read `<= 30 s` | connector timings | connector shadow | P95 plus margin |
| `TH-TGT-048` | timeout | HTTP write `<= 10 s` | connector timings | connector shadow | P95 plus margin |
| `TH-TGT-049` | timeout | HTTP pool acquire `<= 5 s` | connector timings | connector shadow | P95 plus margin |
| `TH-TGT-050` | evidence rule | confirmed removal/retirement evidence persists for `>= 3` eligible batches | observations | Stage 3/5 | never conflate 404 without prior success |
| `TH-TGT-051` | content trigger | split candidate at `>= 50 KiB` | page metrics | Stage 5 | advisory candidate |
| `TH-TGT-052` | content trigger | split candidate at `>= 8000 words` | page metrics | Stage 5 | advisory candidate |
| `TH-TGT-053` | content cap | split mandatory at `>= 100 KiB` unless approved exception | page metrics | Stage 5 | exception requires review receipt |
| `TH-TGT-054` | blast-radius gate | `> 10` dependent pages requires human review | backlinks | Stage 5 | tune only with rollback data |
| `TH-TGT-055` | doctor deadline | stranded pipeline branch age `> 7 days` warns | branch commit time | Stage 0 | no automatic deletion |
| `TH-TGT-056` | dead-man deadline | latest terminal event age `> 48 h` fails deployment health | scheduler/result join | Stage 0 | aligned to schedules/outages |
| `TH-TGT-057` | alert SLA | review acknowledgement `<= 5 days` | alert events | Stage 5 | severity-specific policy may be stricter |
| `TH-TGT-058` | behavioral target | navigation success `>= 8/10` sampled tasks within `30 s` | observational study | after Stage 4 | observational only; Stage-1 functional gates remain `TH-TGT-015` and `TH-TGT-016`, while Stage-6 evaluation owns `TH-TGT-002` and `TH-TGT-003` |
| `TH-TGT-059` | observational target | capture use `>= 1/week` | redacted proposal events | after Stage 4 | absence in a quiet week is not release failure |
| `TH-TGT-060` | lifecycle SLO | proposal-to-disposition `< 7 days` | disposition events | after Stage 4 | exclude quarantined/legal hold with reason |
| `TH-TGT-061` | invariant | answers from superseded pages without disclaimer `= 0` | evaluated answers | after Stage 5 | release blocker |
| `TH-TGT-062` | behavioral target | maintainer hygiene `< 30 min/week` | observational log | after Stage 4 | diagnose non-substantive friction |
| `TH-TGT-063` | behavioral target | manual intervention for non-substantive gate failure `= 0` | incident classes | after Stage 4 | does not suppress substantive review |
| `TH-TGT-064` | evaluation invariant | Stage-6 suite sample count `= 100` | `SCHEMA-REL-05` | each baseline | changing corpus requires new version/review |
| `TH-TGT-065` | extraction adoption gate | born-digital normalized character recall `>= 0.99` | first binary-doc eval | when binary source exists | no adoption before real document |
| `TH-TGT-066` | extraction adoption gate | simple-table cell F1 `>= 0.98` | binary-doc eval | same | same |
| `TH-TGT-067` | extraction adoption gate | clean-scan CER `<= 0.02` | OCR eval | same | same |
| `TH-TGT-068` | extraction review cap | degraded-scan CER `<= 0.08`, otherwise review | OCR eval | same | same |
| `TH-TGT-069` | GROBID adoption gate | bibliography-entry recall `>= 0.95` | scholarly-PDF eval | first scholarly source | source-specific adoption |
| `TH-TGT-070` | GROBID adoption gate | in-text citation-target recall `>= 0.90` | scholarly-PDF eval | same | same |
| `TH-TGT-071` | graph adoption gate | `>= 3` recurring multi-hop questions deterministic edges cannot answer | reviewed query-gap themes | Stage 6 | never use raw misses as authority |
| `TH-TGT-072` | eval corpus planning bound | exploratory gold set `50–100` cases before fixed `TH-TGT-064` baseline | eval design receipt | Stage 6 setup | final baseline is exactly `TH-TGT-064` |
| `TH-TGT-073` | calibration window | cost observation `= 28 days` before setting `TH-TGT-032` and `TH-TGT-033` | metrics | after AR-10 | missing usage does not become zero |
| `TH-TGT-074` | recovery objective | RPO `<= 1 completed nightly cycle` | verified backup receipts | every drill | decision #11 review |
| `TH-TGT-075` | recovery objective | RTO `< 1 h` | incident/restore drill | every drill | decision #11 review |
| `TH-TGT-076` | query-gap proposal gate | repeated redacted misses / eligible redacted misses `> 0.20` | `SCHEMA-REL-04` query-gap metric over the reviewed Stage-4 evaluation window | each Stage-4 review | opens a derived-view proposal only; never creates authority or bypasses review |
| `TH-TGT-077` | rollout gate | clear a non-incident target fix gate only after `>= 2` consecutive completed eligible runs with non-negative issue delta and no failed required gate | `TXN-01R` governed `SCHEMA-REL-04` issue-delta and required-gate events | every target recovery attempt | `TXN-01R` persists the evidence and `AT-MECH-09` verifies it; any associated incident requires `RB-INCIDENT-02` approval and cannot auto-resume |

### 9.2 As-built values

These rows inventory the live scripts copied on 2026-08-26. They are constants, not target hypotheses. Target code may replace them only through the owning package and acceptance test.

| ID | Type | Live value | Evidence | Interpretation |
|---|---|---|---|---|
| `TH-LIVE-001` | live constant | `STUB_THRESHOLD=0.30` | `wiki-nightly.sh:78`, setup validator | maximum stub ratio in current checks |
| `TH-LIVE-002` | live switch | `ENFORCE_FRONTMATTER=true` | `orchestrator/enforcement.env` | blocking |
| `TH-LIVE-003` | live switch | `ENFORCE_LINKS=true` | same | blocking |
| `TH-LIVE-004` | live switch | `ENFORCE_PROVENANCE=true` | `orchestrator/enforcement.env:25` | blocking; corrects stale false inventory |
| `TH-LIVE-005` | live switch | `ENFORCE_PLACEMENT=false` | enforcement file | advisory |
| `TH-LIVE-006` | live switch | `ENFORCE_STALE=false` | enforcement file | advisory |
| `TH-LIVE-007` | live switch | `AUTOMERGE_ENABLED=true` for aidlc only | `wiki-config/aidlc.env` | `PRESERVE-00` turns it off first |
| `TH-LIVE-008` | live switch | `ALLOW_AUTONOMOUS_RETIRE` unset | `hp5-drift-check.py` | retirement not autonomous |
| `TH-LIVE-009` | live cutoff | duplicate overlap `0.65` | `minhash-overlap.py:97–100,214–216` | literal is active although env name is not implemented |
| `TH-LIVE-010` | live cutoff | related overlap minimum `0.25` | same | literal is active |
| `TH-LIVE-011` | live timeout | LIGHT role `600 s` | `wiki-nightly.sh:75` | role timeout, not global window |
| `TH-LIVE-012` | live timeout | HEAVY role `1800 s` | `wiki-nightly.sh:76` | role timeout |
| `TH-LIVE-013` | live retention | report/log deletion age `30 days` | `wiki-nightly.sh:77,149–150` | legacy destructive cleanup; target `PIPE-REC-07` is recoverable |
| `TH-LIVE-014` | live stagger | `300 s` between wiki starts | `run-pipeline.sh:14,115–117` | five wikis incur four intervals |
| `TH-LIVE-015` | live circuit | clear the suppression list when suppressed ratio `> 0.50`; the cumulative noise tracker is not reset | `wiki-nightly.sh:334–338` | finding-suppression circuit; the log message is imprecise |
| `TH-LIVE-016` | live rotation | rotate outcomes when `>10000` rows, retain `5000` | `wiki-nightly.sh:616–618` | legacy bounded log |
| `TH-LIVE-017` | live suppression | suppress a noncritical audit ID when cumulative prior count `>=2` | `wiki-nightly.sh:319–325` | counter has no reset-on-absence; not consecutive source failures |
| `TH-LIVE-018` | live alert behavior | critical/high issue IDs alert immediately and once | `wiki-nightly.sh:310–317` | separate from `TH-LIVE-017` |
| `TH-LIVE-019` | live escalation | stuck fix gate alerts after `>5 days` | `wiki-nightly.sh:643` | legacy circuit behavior |
| `TH-LIVE-020` | live recovery | remove `fix-gate` after the stored prior delta and current delta are both non-negative | `wiki-nightly.sh:632–637` | legacy two-run recovery; it does not distinguish incident recovery |

## 10. Open uncertainties

Every uncertainty has one owner package, exact `T-AR-*` work record, probe/evidence, and closure rule. REST cannot close an MCP-specific question. Probe evidence is redacted.

| ID | Question | Owner package / work record | Probe and evidence | Closure |
|---|---|---|---|---|
| `AR-09` | does the legacy trust flag bypass installed-version permissions? | `KIRO-SEC-01R` / `T-AR-09` | headless denied-write fixture receipt | behavior recorded; production flag still absent |
| `AR-10` | what token/model/cost fields does installed Kiro expose? | `RUNTIME-01` / `T-AR-10` | one redacted captured result | parser fixture accepted or fields remain explicit null |
| `AR-11` | is a working-directory option supported? | `RUNTIME-01` / `T-AR-11` | installed help/probe receipt | invocation adapter selected and tested |
| `AR-12` | what PATH/environment reaches launchd? | `RUNTIME-01` / `T-AR-12` | scheduler environment receipt | desired explicit executable/environment verified |
| `AR-13` | does interactive `adp-confluence` MCP expose `version.number`? | `MCP-QUERY-01` / `T-AR-13` | MCP-specific result fixture | version field observed/typed or capability remains unavailable |
| `AR-14` | is each portal search index present and complete? | `PORTAL-01` / `T-AR-14` | authorized index/sample comparison | per-profile hint policy recorded |
| `AR-15` | do InnerSpace/OneCICD require login via plain proxy? | `PORTAL-02` / `T-AR-15` | hardened doctor probes | auth profile recorded; no inference from unrelated site |
| `AR-16` | can approved OAP auth call direct REST, and DC or Cloud? | `CONFLUENCE-01` / `T-AR-16` | plugin inspection plus approved REST probe | `deployment_profile` and auth capability recorded |
| `AR-17` | installed Kiro version/config compatibility | `RUNTIME-01` / `T-AR-17` | version and profile-load receipt | exact supported profile syntax selected |
| `AR-18` | Copilot cloud/CLI MCP location | none / `T-AR-18` | no probe under decision #7 | remains `out_of_scope` until decision changes |
| `AR-19` | is the authoritative tree clean? | `PRESERVE-00` / `T-AR-19` | read-only live-tree doctor/status receipt | state classified before any mutation |
| `AR-20` | does interactive MCP failure raise or return empty success? | `CONFLUENCE-01` / `T-AR-20` | forced-failure Kiro fixture | error class is explicit; empty cannot mean success |
| `AR-21` | are bundles sufficient before evidence paths exist? | `PRESERVE-00` / `T-AR-21` | Stage −1 empty-dir restore | preservation scope explicitly accepted or blocked; Stage 3 still adds evidence backup |
| `AR-22` | do live timeless findings block retirement rollout? | `RETIRE-01` / `T-AR-22` | live read-only strict lint receipt | failure scope is corrected or explicitly dispositioned |
| `AR-23` | when do repeated redacted misses add value? | `CAPTURE-01` / `T-AR-23` | Stage-4 miss/repeat metric | apply `TH-TGT-076`; a passing result opens a proposal for a derived query-gap view, never authority |

## 11. Acceptance test strategy

Levels are fixed: **Level 1** unit/contract, **Level 2** component/provider, **Level 3** end-to-end scenario/fault injection. A smoke (“file exists”, parses, grep matches) is not acceptance. Every receipt binds code/config/contract versions, inputs, outputs, hashes, environment, and terminal disposition.

### Acceptance families

| ID | Level | Assertion / required evidence |
|---|---:|---|
| `AT-A-CONTRACT` | 1 | all `SCHEMA-*` valid/invalid fixtures, JSON-Schema/Pydantic/transition parity, deterministic views, ID/hash/path/zero-case rules, generated-source drift |
| `AT-A-HANDOFF` | 1/2 | byte renderer/linter oracle, span inversion, caps `TH-TGT-007` and `TH-TGT-008`, hostile breakout, wrong fence/map/source bytes |
| `AT-SEC-GUARD-01` | 1/2 | shared classification and egress library enforces allow/redact/quarantine/reject, the private-personal/shared-rejection matrix, scheme/domain/IP/DNS/redirect/metadata/link-local/body bounds, and adapter non-weakening before real acquisition |
| `AT-RETENTION-01` | 1/3 | selected decision #20 profile, migration, hold/purge negative cases, backup treatment and non-resurrection when applicable |
| `AT-QUERY-01-PAGE-TEMPLATE` | 1 | generated template source/drift and answer-first/freshness orientation without forked policy |
| `AT-AUTH-02-EARLY` | 1/2 | read-only authority resolution and protected default available before Confluence conflict handling |
| `AT-KEYFACTS-01` | 1/2 | complete registered-fact audit, assessment/acquisition separation, evidence spans, mismatch proposal, no automatic semantic publication |
| `AT-AUTH-02-RESOLUTION` | 1/2 | full domain/global/newer/unresolved policy, projection drift, conflict fixtures |
| `AT-RENUMBER-01` | 2/3 | proposal-only scope, `TH-TGT-037` and `TH-TGT-054`, link preview, veto, idempotence and rollback |
| `AT-FRESH-TOTAL` | 1/2/3 | all acquisition/source/semantic combinations map under `SCHEMA-SO-04`; zero reachable undefined; first healthy observation actionable; first unhealthy does not proceed |
| `AT-B-CONNECTORS` | 2 | page/pagination/change/unchanged/unauthorized/login/404/timeout/rate-limit/malformed/oversize; repo ancestry; deterministic outputs; per-connector shadow |
| `AT-B-PII-EGRESS` | 2/3 | secret/PII classification/redaction/quarantine and URL/file SSRF, redirect, DNS-rebinding, metadata/private/link-local, oversize, caller-path/browser-arg rejection |
| `AT-B-QUERY` | 2 | exact/split identifiers, deterministic ranking, citations, warning-first freshness, `SCHEMA-CFG-19` ownership, private exclusion, digest-bound pinned corpus/manifest/baseline, and an accepted run-local `SCHEMA-REL-04` result for `TH-TGT-015` and `TH-TGT-016` |
| `AT-DISCOVERY-01` | 2/3 | scope guard, proposal-only candidates, no registry mutation, defined denominator and `TH-TGT-038` receipt |
| `AT-C-ACQUISITION` | 3 | fault at every object/index/event/marker promotion; incomplete batch invisible; resume idempotent; completed events rebuild identical views |
| `AT-C-TRANSACTION` | 3 | dirty user state, allowed new files, writer/auditor/triage/librarian failures, semantic `fail` veto, timeout descendant, malformed/stale result, wrong base/input/diff/tree, safe WIP and `TH-TGT-029` |
| `AT-C-RELEASE` | 3 | approval wait, stale approval, each evidence/wiki/manifest/pointer checkpoint, CAS conflict, mixed detection, idempotent resume, audited revert rollback |
| `AT-PIPE-FINALIZE` | 3 | actionable/quiet/unhealthy/blocked/cancel/failure each yields summary, monitor, alert evaluation, wiki/global result and backup request; launcher death is detected independently |
| `AT-D-CLIENTS` | 2/3 | Claude Code, local Copilot and Kiro share normalized schemas/semantic assertions; query is read-only; capture separate; support/conflict/abstention; CLI/files outage path |
| `AT-E-BACKUP` | 3 | independently scheduled receipt, relative manifest, all bundle heads/evidence/event high-water, interruption/corruption, empty-dir and symlinkless restore, `TH-TGT-014`, `TH-TGT-074`, and `TH-TGT-075` |
| `AT-E-DRILLS` | 3 | restore, rollback, torn acquisition, hostile source, PII/SSRF, provider failure, source failure, dead-man and postmortem/autonomy-resume receipts |
| `AT-F-NAV` | observational | after Stage 4 only: observe `TH-TGT-058`; this acceptance is not a Stage-1 exit and does not replace the Stage-1 `TH-TGT-015` and `TH-TGT-016` functional gates or Stage-6 evaluation |
| `AT-F-CAPTURE` | observational + lifecycle | after Stage 4: scripted durable capture/lifecycle must pass; observe `TH-TGT-059` and `TH-TGT-060` without failing quiet weeks |
| `AT-F-RETIRE` | eval/audit | after Stage 5: `TH-TGT-061`, grace/hold/disclaimer/authority and individual page evidence |
| `AT-F-HYGIENE` | observational | after Stage 4: `TH-TGT-062` and `TH-TGT-063`; substantive reviews are excluded, not suppressed |
| `AT-EVAL-01-LINEAGE` | 2/3 | exactly `TH-TGT-064` cases; corpus/source commit/fixture/runner/environment/client/provider/model/prompt/capability lineage; reviewed `SCHEMA-REL-05`; rebaseline on any lineage change |

Named Level-3 scenarios extend, never rename, the existing harness: `pass`, `fail`, `crash_after_ingestor`, `wrong-run-id`, `all_skips`, `html_login_error`, `source_removed`, `timeout_error`, `hostile_source`, `healthy_wiki_idempotent`, `reconcile_cap_enforcement`, `crit_contradiction_escalates`, `monotonic_convergence`, `discovery_scope_guard`, and `placement_violation`. Cap assertions reference `TH-TGT-035`, `TH-TGT-036`, and `TH-TGT-037`, never free literals.

### Seventeen mechanism trace

| Acceptance ID | Architecture mechanism | Test intent |
|---|---:|---|
| `AT-MECH-01` | 1 | dirty tracked/untracked user work blocks with zero mutation |
| `AT-MECH-02` | 2 | lock token/PID/start identity, stale quarantine and ownership-safe release |
| `AT-MECH-03` | 3 | quiet path spends zero model tokens but still finalizes |
| `AT-MECH-04` | 4 | stable content-hash issue IDs across equivalent runs |
| `AT-MECH-05` | 5 | live cumulative suppression behaves exactly as `TH-LIVE-017`; target source alerts remain separate |
| `AT-MECH-06` | 6 | critical/high live alert is immediate/once (`TH-LIVE-018`) |
| `AT-MECH-07` | 7 | suppression circuit clears only the suppression list under `TH-LIVE-015`, leaves the cumulative noise tracker intact, and cannot hide critical findings |
| `AT-MECH-08` | 8 | score regression halts fix path and preserves evidence |
| `AT-MECH-09` | 9 | fixtures distinguish live `TH-LIVE-020` behavior from target `TH-TGT-077`; target non-incident recovery requires its governed two-run evidence, while incident recovery never auto-resumes and follows `RB-INCIDENT-02` |
| `AT-MECH-10` | 10 | branch/candidate is gated, verified and approval-bound before publication |
| `AT-MECH-11` | 11 | each enforce switch has a negative fixture that genuinely fails |
| `AT-MECH-12` | 12 | auditor input inventory is recomputed after writer output |
| `AT-MECH-13` | 13 | empty candidate produces no empty commit/release member |
| `AT-MECH-14` | 14 | stagger count is `(managed_wikis−1)` and target/live values are `TH-TGT-022` and `TH-LIVE-014` |
| `AT-MECH-15` | 15 | live outcome rotation matches `TH-LIVE-016`; target run cleanup remains recoverable |
| `AT-MECH-16` | 16 | binary/Unicode stub markers are detected under C locale and index coverage blocks misses |
| `AT-MECH-17` | 17 | headless PTY/runtime path works through desired configuration and failure is explicit |

### Interaction and stage-exit trace

| ID | Requirement | Acceptance |
|---|---|---|
| `AT-R-01` | freshness before content | `AT-FRESH-TOTAL`, `AT-B-QUERY` |
| `AT-R-02` | not-found offers capture only when Stage-4 capture is available | Stage 1 manual handoff fixture; Stage 4 durable capture fixture |
| `AT-R-03` | three-line answer, warning first | `AT-B-QUERY` formatting, freshness, citation, and abstention fixtures |
| `AT-R-04` | question and note remain distinct | `SCHEMA-CP-01` fixtures |
| `AT-R-05` | query/capture are separate processes | `AT-D-CLIENTS`, denied-write fixtures |
| `AT-R-06` | no superseded answer without disclaimer | `AT-F-RETIRE`, `TH-TGT-061` |
| `AT-R-07` | wiki does not notify source owners | alert/RACI fixture routes maintainer review only |
| `AT-R-08` | doctor/health prose plus identical `--json` semantics | `SCHEMA-CFG-02` and `SCHEMA-CFG-03` conformance |
| `AT-R-09` | ownership → routing → reviewer | `AT-AUTH-02-RESOLUTION`, `SCHEMA-CFG-19`, `TH-TGT-017`, and `TH-TGT-018` |
| `AT-R-10` | failure leaves published state clean and scoped evidence | `AT-C-TRANSACTION`, `AT-C-RELEASE`, `TH-TGT-029` |
| `AT-PRESERVE-00` | Stage −1 pre-mutation preservation | pre-evidence bundles, relative inventory, clean/dirty state classification, automerge-off proof, a `SCHEMA-CFG-10` receipt containing an accepted `deployment_seed_receipt` with valid `seed_sha256` and `receipt_sha256`, interruption/corruption negatives, and `RB-RESTORE-00` empty-directory restore; it neither creates nor owns `orchestrator/deploy.yaml` |
| `AT-STAGE-M1` | preservation/policy | `AT-PRESERVE-00`, `AT-RETENTION-01` |
| `AT-STAGE-0` | runtime/doctor/auth | runtime/doctor negatives plus `RB-AUTH-01` and `RB-AUTH-02` drills |
| `AT-STAGE-1` | truthful navigation | `AT-MECH-16`, `AT-FRESH-TOTAL`, `AT-B-QUERY` |
| `AT-STAGE-2` | safe publication | `AT-A-CONTRACT`, `AT-A-HANDOFF`, `AT-C-TRANSACTION`, `AT-C-RELEASE` |
| `AT-STAGE-3` | Confluence evidence | `AT-B-CONNECTORS`, `AT-FRESH-TOTAL`, `AT-KEYFACTS-01`, `AT-E-BACKUP` |
| `AT-STAGE-4` | assistants/capture/framework | `AT-D-CLIENTS`, `AT-B-PII-EGRESS`, `AT-F-CAPTURE` |
| `AT-STAGE-5` | governance/drills | owner/provenance/canonical/placement/code gates plus `AT-F-RETIRE`, `AT-E-DRILLS` |
| `AT-STAGE-6` | reproducible eval | `AT-EVAL-01-LINEAGE` and reviewed threshold verdicts |

## Appendix A — Supersession and move map

Anything not in [FINAL-INDEX.md](FINAL-INDEX.md) is history. This table imports only facts still needed for implementation and records every approved content move.

| Earlier fact/home | Canonical home |
|---|---|
| retired end-to-end plan/design/review and unnamed build-sheet dependencies | this FINAL set only; no blanket validity sentence survives |
| architecture §§3.8/4 exact phase, environment, exit, lock, publication and recovery detail | `FINAL-pipeline-2026-08-27.md`, `PIPE-*`; architecture retains transaction invariants/topology |
| architecture §§3.10/3.12/3.14 fields, enums, transitions, tool/config/release shapes | `FINAL-contracts-2026-08-27.md`, `SCHEMA-*`; generated schemas derive from its IR |
| architecture §3.14 auth/restore/rollback/incident/alert procedures and promised `RUNBOOK-auth.md` | `FINAL-runbooks-2026-08-27.md`, `RB-*`; no second auth file |
| plan §7 inline file/command/test/status detail and surviving executable build-sheet facts | `FINAL-todo-2026-08-27.md`, `T-*`; plan §7 retains stable package scope/DAG |
| raw locator-path layout, mutable object metadata, sha-prefix identity, conflicting gzip rule | `SCHEMA-SO-01` content-bundle identity and `SCHEMA-SO-02` observation separation |
| mutable registry/runtime fields and rewritten “append-only” health ledger | `SCHEMA-CFG-01` policy + `SCHEMA-SO-*` events + rebuildable views |
| six/long status ladders and false-green SKIP | `SCHEMA-SO-04` four core states plus diagnostics/total precedence |
| verifier-written partial block and verdict-string authorization | `SCHEMA-RR-01`, `SCHEMA-RR-02`, architecture §3.9, `PIPE-W-07` |
| five runtime-role contracts | decision #19 three families with registered `SCHEMA-*` subtypes/state schemas |
| inbox handed to ingestor/writer or questions promoted directly | `SCHEMA-CP-*`, `PIPE-W-04`, architecture §3.11 |
| `/tmp` worktrees, unsafe allowlist expansion, repository-wide staging, reset/delete recovery | `PIPE-W-01`, `PIPE-REC-02`, and `PIPE-REC-07`; rejected |
| control-plane-last/view-committed release variants and post-merge blocking index gate | `PIPE-G-06`: completed evidence first, wiki candidates, final manifest/pointer; views excluded; index gate pre-verifier |
| old release state diagrams | `SCHEMA-REL-02` only; pipeline sequence references it |
| doctor exit inversion | `SCHEMA-CFG-03`; global pipeline exit is `PIPE-EXIT-06` |
| one cost variable used as both phase brake and rolling budget | `TH-TGT-032` and `TH-TGT-033` separately |
| un-ID'd or duplicated threshold literals | §9/§9.2 `TH-*`; siblings reference IDs only |
| `retain_class`, unconditional never-prune language, undefined purge/hold behavior | `retention_class`, decision #20, `RETENTION-01`, `SCHEMA-CFG-01` profiles |
| authority file under orchestrator or unqualified | `.kiro/steering/authority.yaml` only |
| portal implementation under both package and orchestrator paths | `src/wiki_core/providers/portal.py`; orchestrator adapter only |
| `SCHEMA-CFG-01` or stage-late adapters treated as the shared egress/classification owner | `KIRO-SEC-01R` shared implementation accepted by `AT-SEC-GUARD-01`; connector and `CAPTURE-01` adapters accepted by `AT-B-PII-EGRESS` |
| file capture advertised only by CLI | `SCHEMA-CP-01` and `SCHEMA-CFG-02` represent CLI/MCP file capture end to end |
| Stage-4 auth delivery after Stage-3 connector need | `RB-AUTH-01` and `RB-AUTH-02` delivered by Stage 0; AR-16 closes before Stage 3 |
| conflated pre-evidence preservation and evidence-era backup | Stage −1 `PRESERVE-00`, `SCHEMA-CFG-10`, `RB-RESTORE-00`, and `AT-PRESERVE-00`; Stage 3 `BACKUP-01`, `SCHEMA-CFG-13`, `RB-RESTORE-01`, and `AT-E-BACKUP` |
| generic relation reused for ownership query results | dedicated `SCHEMA-CFG-19` `owner-result/1`, owned by `QUERY-01` and exercised by `AT-B-QUERY` |
| private personal capture either rejected globally or included in shared artifacts | private `local_laptop` catalog/inbox and private repository-bundle preservation are allowed; shared personal capture is rejected before ID allocation, and generated/shared evidence bundles exclude private content |
| release journal treated as a run-local transient | committed `state/releases/journals/<release_id>.jsonl` release journal; run-local copies are projections only |
| deployment manifest written by preservation and runtime | `RUNTIME-01` solely owns `orchestrator/deploy.yaml`; Stage −1 records only the accepted `deployment_seed_receipt`, `seed_sha256`, and `receipt_sha256` in `SCHEMA-CFG-10` |
| Stage-3 command named as MCP-only trace surface | Stage 3 CLI trace; Stage 4 MCP/capture |
| mandatory trigram or one-window/vector conclusion from incomplete measurements | optional benchmark under `EVAL-01`; App. C qualifications and `TH-TGT-023`, `TH-TGT-024`, `TH-TGT-025`, `TH-TGT-026`, `TH-TGT-027`, and `TH-TGT-028` |
| separate FINAL diagrams companion | rejected by `AB-STR-06`; diagrams stay beside owning architecture/`PIPE-*`/`SCHEMA-*` facts |
