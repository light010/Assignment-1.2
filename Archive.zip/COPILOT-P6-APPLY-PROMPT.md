# P6 — Apply the approved review findings to the FINAL documentation set

You are the SUPERVISOR of a multi-agent edit run on the seven-file FINAL set in `reports/`:
`FINAL-INDEX.md`, `FINAL-architecture-2026-08-26.md` (arch), `FINAL-implementation-plan-2026-08-26.md` (plan), `FINAL-todo-2026-08-27.md` (todo), `FINAL-pipeline-2026-08-27.md` (pipeline), `FINAL-contracts-2026-08-27.md` (contracts), `FINAL-runbooks-2026-08-27.md` (runbooks).

The review is finished and approved. Your job is to apply exactly the work items below — nothing more, nothing less — and prove each one with the stated post-check. Do not re-review, do not "improve" untouched text, do not reflow tables, do not change ids you were not told to change.

## Non-negotiable rules

1. **Anchored edits only.** Every edit names a verbatim anchor string. Before editing, run `grep -c -F -- '<anchor>' <file>` and require exactly `1`. If it is `0` or `>1`, STOP that item, record `ANCHOR-MISS` in the report, and continue with the next item. Never guess a nearby location.
2. **One fact, one home.** New text goes into the file the item names. If the same fact already exists elsewhere in the set (grep the whole set for its key token first), write a pointer, not a copy.
3. **Never invent ids, values, env-var names, or URLs.** If an item needs a value you cannot derive from the set or the repository scripts, write `[OWNER DECISION]` in the text and list it in the report.
4. **No secrets, no e-mail addresses, no cookie/token values** anywhere in the files or in your output.
5. **Ids are stable.** Never renumber existing `TH-*`, `AT-*`, `AR-*`, `T-*`, `PIPE-*`, `SCHEMA-*`, `RB-*`, `AB-*`, `AC-EV-*`, `FI-*`. New ids take the next free number.
6. **Post-check every item** with the stated command and paste the exact output into the report. An item without a passing post-check is not done.
7. **Context hygiene.** One worker edits one file at a time. Workers receive only their items and the anchors; they never read a whole file unless the item says so. Workers write a ≤20-line report; the supervisor merges. If your Copilot build supports custom agents / subagents (`.github/agents/*.agent.md`) create: `writer-arch`, `writer-plan`, `writer-todo`, `writer-pipeline`, `writer-contracts`, `writer-runbooks`, `writer-index`, `verifier` (read-only). If it does not, run each phase as a fresh chat with this document attached as context and the same rules. (The subagent feature availability is not assumed — fall back without complaint.)
8. **Verifier is independent.** The final verification phase is run by a worker that made no edits.
9. **Git safety.** Phase 0 commits the untouched set first (see below). Every phase ends with `git add reports/ && git commit -m "P6 <phase>: <items>"`. Never `git add -A`. Never force-push. Never rewrite history.
10. **Report faithfully.** ANCHOR-MISS, OWNER DECISION, and any post-check failure are listed verbatim in the final report; nothing is described as done that is not proven.

---

## Phase 0 — Baseline (supervisor)

```bash
cd <repo-root>
git status --short reports/FINAL-*.md            # expected: all seven untracked (??)
git add reports/FINAL-*.md && git commit -m "P6 baseline: FINAL set before review edits"
wc -l reports/FINAL-*.md                         # expected total 5528
# baseline counters (save these numbers; the verifier compares against them)
grep -c '^| `TH-TGT-' reports/FINAL-implementation-plan-2026-08-26.md   # 77
grep -c '^| `TH-LIVE-' reports/FINAL-implementation-plan-2026-08-26.md  # 20
grep -c '^| `AR-'     reports/FINAL-implementation-plan-2026-08-26.md   # 15
grep -c '^### `T-'    reports/FINAL-todo-2026-08-27.md                  # 51
grep -c '^## RB-'     reports/FINAL-runbooks-2026-08-27.md              # 14
grep -c '```mermaid'  reports/FINAL-architecture-2026-08-26.md          # 3
grep -c '```mermaid'  reports/FINAL-pipeline-2026-08-27.md              # 4
grep -c '```mermaid'  reports/FINAL-implementation-plan-2026-08-26.md   # 1
grep -rEc '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[a-z]{2,}' reports/FINAL-*.md   # every file 0
```
If any expected number differs, stop and report before editing — the set is not the reviewed revision.

---

## Phase 1 — Architecture (`writer-arch`, file: arch)

### W-01 (K-01 + K-02) — align §3.5 freshness enums with `SCHEMA-SO-04`, make the table non-normative
Anchor A (exact row):
```
| `source_condition` | `unchanged` · `drifted` · `suspected_removed` · `confirmed_removed` · `conflict` · `unknown` |
```
Replace with:
```
| `source_condition` | `new` · `unchanged` · `changed` · `suspected_removed` · `confirmed_removed` · `conflict` · `unknown` |
```
Then compare the other two rows (`acquisition`, `semantic`) of that table against the normative value sets in contracts `### `SCHEMA-SO-04`` prose (contracts line ≈252 and ≈287–306). If any value differs, align the arch row to contracts and list the change in the report.
Anchor B (exact paragraph start):
```
Execution status lives in `run-result/1` (`status {succeeded, degraded, failed, cancelled}`); publication status lives in the proposal lifecycle `state` (§3.11, §3.12) — neither is a freshness dimension.
```
Replace with:
```
Execution status lives in `run-result/1` (`SCHEMA-RR-01.status`); publication status lives in the proposal lifecycle `state` (§3.11, §3.12) — neither is a freshness dimension. The value lists in the table above are illustrative; `SCHEMA-SO-04` owns the normative freshness enumerations and `SCHEMA-RR-01` owns `status`.
```
Post-check: `grep -c 'drifted' arch` → `0`; `grep -c 'SCHEMA-SO-04 owns the normative' arch` → `1`; `grep -c 'succeeded, degraded, failed, cancelled' arch` → `0`.

### W-02 (K-05 + frontmatter contract) — restore the as-built page-frontmatter facts
First grep the whole set: `grep -rn 'schema_version\|doc_type\|migrate-frontmatter\|generate-llms' reports/FINAL-*.md`. Add ONLY the tokens that are absent.
Anchor (paragraph start, arch §3.3):
```
Registry/frontmatter reconciliation is additive and approval-gated.
```
Insert immediately BEFORE that paragraph, as its own paragraph:
```
As built, every managed page (127/127) already carries `schema_version: 1` and `doc_type` (written by `migrate-frontmatter.sh`; `generate-llms.sh` groups the LLM export by `doc_type`). Two markers are transitional: `protected: true` is written with a `# PLANNED` comment until the early `AUTH-02` milestone enforces it, and `source_hash: pending` is the pre-migration sentinel (`orchestrator/enforcement.env:20-24`) that the Stage-3 cutover replaces with full object hashes. The normative field list lives in the contract that owns page frontmatter (see W-12 in contracts).
```
Post-check: `grep -c 'schema_version: 1' arch` → `1`; `grep -c '# PLANNED' arch` → `1`; `grep -c 'source_hash: pending' arch` → `1`.

### W-03 (K-07) — denominator note in App. C
Anchor (exact row start): `| `AC-EV-05` | Confluence grounding is uneven by wiki |`
Append to the END of that row's last cell (before the final `|`): ` The retired second-brain gap analysis' "31 Confluence-sourced of 111 active/draft" and this register's "35 of 127" use different denominators; both are correct.`
Post-check: `grep -c '31 Confluence-sourced of 111' arch` → `1`.

### W-04 (K-25) — record the merge-closure SLI as an open uncertainty, not a silent drop
Add a new App. B row directly after the row that starts with `| `AB-18` |`:
```
| `AB-19` | merge-closure SLI `>= 99 %` of proposals reaching a terminal state within a bounded number of runs | deferred to owner | distinct from the `AB-16` pointer-integrity SLI; becomes a `TH-TGT-*` row or an explicit rejection | plan §10 `AR-24` |
```
(If `AB-18` is not the last row, insert after the last `AB-` row instead and say so.) Post-check: `grep -c '^| `AB-19`' arch` → `1`.

### W-05 (K-22) — Kiro issue #7527 evidence
Anchor: the App. C line containing `github.com/kirodotdev/Kiro/issues/7527`. Use the fetch tool to open that URL. If the page title mentions `knowledgeBase` / `autoUpdate` (or a knowledge-base auto-update defect), leave the line unchanged and record "verified" in the report. If it does not resolve or is a different issue, append ` [UNCERTAIN: issue URL unverified — cite by number]` to that line. Post-check: report the fetched title or the qualifier.

### W-06 — header date
Anchor: `> **Last updated:** 2026-08-27.` → `> **Last updated:** 2026-08-28.` (arch only in this phase; each later phase does the same for its own file).

Commit: `git add reports/FINAL-architecture-2026-08-26.md && git commit -m "P6 arch: W-01..W-06"`.

---

## Phase 2 — Plan (`writer-plan`, file: plan)

### W-07 (K-08) — through-Stage-5 sign-off table
Anchor (exact heading): `### Acceptance families`
Insert immediately BEFORE it:
```
### Through-Stage-5 sign-off

One table; each gate is owned by the section or id named. Every id below must resolve in this set.

| dimension | gate | owned by |
|---|---|---|
| reproducibility | clean bootstrap and `wiki doctor` PASS on the authoritative host and in an empty-directory restore | `AT-PRESERVE-00`, `AT-STAGE-0`, `RB-RESTORE-02` |
| deployment integrity | 100 % of required shared assets present with hash/mode validated by `framework-check` | `AT-D-CLIENTS`, `FRAMEWORK-01` |
| transaction safety | 100 % of injected failures leave `main` clean with evidence preserved | `AT-C-TRANSACTION`, `AT-C-RELEASE`, pipeline mutation-boundary matrix |
| role-output integrity | 100 % of role outputs schema-valid and bound to the current run and input revision | `AT-A-CONTRACT`, `AT-A-HANDOFF`, `SCHEMA-RR-02` |
| source verification | claim-verified / reachable `>= 0.95` (`TH-TGT-001`); zero skips shown as unchanged | `AT-B-CONNECTORS`, `AT-FRESH-TOTAL`, `TH-TGT-001` |
| provenance | 100 % of changed factual claims cite a `source_ref`; high-risk claims carry a span | `AT-KEYFACTS-01`, §3.3 |
| governance | 100 % of active pages have an owner and classification; one canonical location per topic | `AT-STAGE-5` |
| backlog hygiene | 100 % of items typed, attributable, dispositioned; no stale item re-triggers a run | `AT-MECH-05`, `AT-MECH-06`, `AT-MECH-07`, `AT-MECH-08` |
| security | injection, secret and PII fixtures blocked; no `--trust-all-tools` in the production path | `AT-SEC-GUARD-01`, `AT-B-PII-EGRESS`, decision #17 |
| provider conformance | Claude Code, Copilot and Kiro pass the same fixtures and schemas | `AT-D-CLIENTS` |
| answer quality | golden-set accuracy and citation recall meet `TH-TGT-015` / `TH-TGT-016`; regressions block release | `AT-B-QUERY`, `AT-EVAL-01-LINEAGE` |
| recovery | restore from bundles plus `raw/_index` replay in a clean environment | `AT-E-BACKUP`, `AT-E-DRILLS` |
| auditability | every scheduled phase has a durable `run-result/1` with hashes, capability status and disposition | `AT-PIPE-FINALIZE`, `SCHEMA-RR-01` |
```
Before inserting: confirm `grep -n '^| `TH-TGT-001`' plan` is the `claim-verified / reachable >= 0.95` row (it is at plan:178 in the reviewed revision). Then verify every id in the table exists: for each `AT-`/`TH-`/`SCHEMA-`/`RB-`/package id in the block run `grep -c '<id>' reports/FINAL-*.md` and require ≥1 outside this table. Replace any non-existent id with `—` and list it.
Post-check: `grep -c '^### Through-Stage-5 sign-off' plan` → `1`; table has 13 data rows (`awk` count between the header and the next blank line).

### W-08 (K-24) — restore three lost App. A rows
Anchor (exact row start): `| separate FINAL diagrams companion |`
Insert immediately BEFORE that row:
```
| per-role result files / `role-result/1` wire contract | single `run-result/1` (`SCHEMA-RR-01`); one result per run, roles bound by `SCHEMA-RR-02` |
| fields dropped at the `run-result/1` consolidation | [OWNER DECISION: the dropped-field list existed in the pre-2026-08-27 plan revision, which is not in git history; recover from the owner's copy or from `SCHEMA-RR-01` change notes before Stage 2] |
| technology plan "encrypted content-addressed store outside the wiki Git repositories; git keeps pointers" | §8 #2 (raw in git, `retention_class`, seventh repo cap) and §8 #16 (no encryption beyond FileVault) — owner decisions; not adopted |
```
Post-check: `grep -c 'encrypted content-addressed store' plan` → `1`; `grep -c 'role-result/1' plan` → `1`.

### W-09 (K-26) — golden-set size threshold
Anchor (exact row start): `| `TH-TGT-077` |` — insert AFTER that full row (it is one line):
```
| `TH-TGT-078` | evaluation set | golden query set `>= 30` pinned queries in `tests/query/golden.json` | `QUERY-01` fixtures | Stage 1, Stage 6 | count is a floor; the set changes only through a reviewed `EVAL-01` lineage change |
```
Post-check: `grep -c '^| `TH-TGT-' plan` → `78`.

### W-10 (K-27) — AR-23 closure artifact
Anchor (exact row start): `| `AR-23` |`. In that row, replace the last cell text
`apply `TH-TGT-076`; a passing result opens a proposal for a derived query-gap view, never authority` with
`apply `TH-TGT-076`; a passing result opens a proposal for the derived view `state/views/query-gaps-current.json` (rebuilt, never committed), never authority`.
Post-check: `grep -c 'query-gaps-current.json' plan` → `1`.

### W-11 (K-25) — AR-24 uncertainty for the merge-closure SLI
Insert AFTER the `| `AR-23` |` row:
```
| `AR-24` | is a merge-closure SLI (`>= 99 %` of proposals reaching a terminal state within a bounded run count) required in addition to `TH-TGT-029` pointer integrity? | owner / `T-AR-24` | Stage-2 proposal lifecycle metrics | decide before Stage 3: add a `TH-TGT-*` row or record the rejection in arch `AB-19` |
```
Post-check: `grep -c '^| `AR-' plan` → `16`.

### W-12 (K-28) — TH-LIVE-001 label
Anchor: `| `TH-LIVE-001` | live constant |` → `| `TH-LIVE-001` | live default (env-overridable) |`. Post-check: `grep -c 'live default (env-overridable)' plan` → `1`.

### W-13 — header date (plan). Commit: `git add reports/FINAL-implementation-plan-2026-08-26.md && git commit -m "P6 plan: W-07..W-13"`.

---

## Phase 3 — Todo (`writer-todo`, file: todo)

### W-14 (K-04) — daily make targets
Anchor (inside `T-RUNTIME-01-01` Outputs): `launchd derivatives, and runtime guard fixtures.`
Replace with: `launchd derivatives, runtime guard fixtures, and the daily \`Makefile\` entry points \`doctor\`, \`test-smoke\` and \`test-flow\` (\`run-pipeline\` depends on \`doctor\`; they sit beside the existing \`ct-gate\`, \`validate\`, \`readiness\`, \`backup\`, \`restore-test\` targets).`
Post-check: `grep -c 'test-smoke' todo` → `1`.

### W-15 (K-06) — four build notes
Each is a new line inserted directly AFTER the `Outputs:` line of the named card (the line that starts with `Outputs:` under that card's `###` heading). Use the card heading as the locator, then the first `Outputs:` line after it.
- `### `T-RUNTIME-01-01``: `Build note: Bash guard is \`if (( BASH_VERSINFO[0] < 4 || ( BASH_VERSINFO[0] == 4 && BASH_VERSINFO[1] < 3 ) )); then echo "ERROR: bash >= 4.3 required" >&2; exit 2; fi\` — never parse \`bash --version\`; also fix \`aidlc/.kiro/pipeline/tests/level2-flow.sh:9\` (\`[[ "${BASH_VERSINFO[0]}" -lt 4 ]]\`) to the same 4.3 guard.`
- `### `T-DOCTOR-01-01``: `Build note: stranded \`pipeline/*\` branch age comes from \`git branch --format='%(refname:short) %(committerdate:unix)'\` (stable field name across Git versions); the age limit is \`TH-TGT-055\`.`  — first confirm `grep -n 'TH-TGT-055' plan` is the stranded-branch row; if not, use the correct id.
- `### `T-IDX-01-01``: `Build note: for every \`wiki/*.md\` except \`00-index.md\`, \`98-*\`, \`99-*\`: if frontmatter \`status: active\` and not \`nav: hidden\`, require a link from \`00-index.md\`; print \`missing=<n>\` and exit non-zero on any miss (BLOCKING in the CT gate). \`nav: hidden\` is the only opt-out and must be set explicitly.`
- `### `T-TXN-01R-01``: `Build note: \`state/runs\` retention runs at nightly start — \`find "$STATE_DIR/runs" -maxdepth 1 -type d -mtime +"${STATE_RETENTION_DAYS:-30}" -exec rm -rf {} +\`; the value is \`TH-LIVE-013\`.` — first confirm `TH-LIVE-013` is the 30-day retention row.
Post-check: `grep -c 'BASH_VERSINFO\|committerdate:unix\|nav: hidden\|STATE_RETENTION_DAYS' todo` → `4`.

### W-16 (layout P4) — `stage:` field on every card
For each of the 51 `### `T-…`` cards, in the metadata line that begins with `` `package_id`: `` (or `` `owner_package`: `` for `T-AR-*` cards), insert `` · `stage`: <N> `` immediately after the `` `state`: `<value>` `` field, where `<N>` is taken from the enclosing `### Stage <N> —` heading (`−1`, `0`, `1`, …, `6`). For cards under `## Uncertainty work records` use the stage named in the card's own text; if none, `—`. Then add to `## Ledger rules` a bullet: `- \`stage\` mirrors the enclosing stage heading and is delivery state; stage *definitions* stay in plan §6.`
Post-check: `grep -c '`stage`:' todo` → `51`; `grep -c '^### `T-' todo` → `51` (unchanged).

### W-17 (K-25) — `T-AR-24` card
Insert after the `T-AR-23` card, copying its exact three-line layout (`### `T-AR-23`` / metadata line / `Command:` line):
```
### `T-AR-24`
`owner_package`: `TXN-01R` · `state`: `planned` · `stage`: 2 · `owner_role`: release maintainer · `blocked_by`: `T-TXN-01R-01` · probe: measure the share of proposals reaching a terminal `state` within the Stage-2 fixture runs and compare with `TH-TGT-029` pointer integrity, so the owner can decide plan §10 `AR-24` (arch `AB-19`).
Command: `uv run wiki metrics proposal-closure --json` · acceptance: `AT-C-RELEASE`, `TH-TGT-029` · evidence: `state/runs/<run_id>/delivery/T-AR-24/receipt.json` · closure: `C-PROBE`.
```
Post-check: `grep -c '^### `T-AR-24`' todo` → `1`; `grep -c '^### `T-' todo` → `52`.

### W-18 — header date (todo). Commit.

---

## Phase 4 — Pipeline (`writer-pipeline`, file: pipeline)

### W-19 (K-11) — acquisition inputs and lock CLI
Read only `## `PIPE-G-03`` (pipeline lines ≈64–103). Then derive — do not invent — the inputs from the as-built scripts and the contracts:
```bash
grep -oh '\$\{\?[A-Z][A-Z0-9_]*' .kiro/pipeline/run-pipeline.sh .kiro/pipeline/wiki-nightly.sh orchestrator/*.sh 2>/dev/null | tr -d '${' | sort -u
grep -n 'SCHEMA-CFG-04\|SCHEMA-CFG-05\|SCHEMA-CFG-06' reports/FINAL-contracts-2026-08-27.md | head
```
Append at the end of the `PIPE-G-03` section (before the next `## ` heading) a subsection:
```
### `PIPE-G-03` inputs — names only, values never

| input | kind | owner | consumer |
|---|---|---|---|
| `CONFLUENCE_SPACES` | env (space keys) | `SCHEMA-CFG-04` | space discovery |
| `~/.oap.json` | opaque credential file, mode 600, never read by the pipeline except through the connector | `RB-AUTH-01` | Confluence connector |
| … one row per env var / file the scripts actually read (from the grep above), each mapped to the `SCHEMA-CFG-*` field that owns it or `[OWNER DECISION]` if none does … |

Lock manager (single host, decision #5): `uv run wiki lock acquire|inspect|release --scope acquisition --owner-token <token-id>`; the lock record shape is the `PIPE-G-03` lock record above; `inspect` is the only sub-command a runbook may call.
```
Keep only inputs that PIPE-G-03 acquisition actually consumes. Do not list values. If the CLI naming `uv run wiki …` is not what the todo cards use, match the todo convention.
Post-check: `grep -c 'PIPE-G-03. inputs' pipeline` → `1`; `grep -c 'CONFLUENCE_SPACES' pipeline` → `1`; no line in the new table contains `=` followed by a value.

### W-20 — header date (pipeline). Commit.

---

## Phase 5 — Contracts (`writer-contracts`, file: contracts)

### W-21 (K-12) — home the alert fallback path
Anchor (exact heading): `### `SCHEMA-CFG-04`, `SCHEMA-CFG-05`, and `SCHEMA-CFG-06` — deployment/framework/auth state (IR summary)`
Append at the end of that section (before the next `### ` or `## ` heading) the paragraph:
`\`alert_route\` accepts a sink identifier or the literal \`fallback\`; \`fallback\` resolves to \`<wiki_root>/.kiro/pipeline/alerts.log\` (append-only, redacted, local). \`RB-ALERT-01\` cites this field; no runbook or script may hardcode a different path.`
Do NOT edit the YAML IR unless every other `properties:` entry in the same object carries a `description:` key (check `sed -n '1190,1200p'`); if they do, add `description: 'fallback = <wiki_root>/.kiro/pipeline/alerts.log'` to the `alert_route` property at BOTH occurrences (≈1195 and ≈2413); if they do not, leave the IR untouched.
Post-check: `grep -c 'fallback. resolves to' contracts` → `1`.

### W-22 (K-14) — drift-gate precondition
Anchor (paragraph start): `Generated files begin with `GENERATED FROM reports/FINAL-contracts-2026-08-27.md``
Append at the END of that paragraph: ` This gate is effective only after \`T-CONTRACT-01-01\` is \`done\`; until then publication is gated by the as-built \`validate.sh\` / \`ct-gate.sh\` set recorded in arch §1.`
Post-check: `grep -c 'effective only after' contracts` → `1`.

### W-23 (K-15) — decision-#20 tail becomes a pointer
Anchor (paragraph start): `Plan §8 decision #20 remains unresolved. This contract fixes the canonical name `retention_class``
First confirm `grep -n 'retention_class\|legal_hold' contracts | head` shows both defined under `SCHEMA-CFG-01` prose (≈380–388). If yes, replace the whole paragraph with:
`Plan §8 decision #20 remains unresolved. \`SCHEMA-CFG-01\` states the accepted partial profile (\`retention_class\`, \`legal_hold\` autonomous freeze). Nothing in this contract decides hard purge, hold authority, retention duration, archive policy, or purge approval — see plan §8 #20 and \`RB-RESTORE-04\`.`
If not both defined there, leave unchanged and report.
Post-check: `grep -c 'accepted partial profile' contracts` → `1`.

### W-24 (K-05 continued) — page-frontmatter owner
`grep -n -i 'frontmatter' contracts | head -20`. If a `SCHEMA-*` prose section owns page frontmatter, append one sentence there listing the as-built fields `schema_version` (integer, currently `1`), `doc_type`, `protected` (with the transitional `# PLANNED` comment), `source_hash` (with the `pending` sentinel) and pointing to arch §3.3 for behaviour. If NO schema owns page frontmatter, do not create one; write `[OWNER DECISION: page-frontmatter field contract has no SCHEMA-* owner; candidate SCHEMA-CFG-20 page-frontmatter/1]` in the report.
Post-check: either `grep -c 'schema_version' contracts` → `≥1`, or the OWNER DECISION line in the report.

### W-25 (P1) — move the retired v1 IR block to history
Precondition: Phase 0 commit exists (`git log --oneline -1` shows "P6 baseline").
1. Locate start: line of `## Retired v1 IR — migration evidence only`. Locate end: the line BEFORE `## Canonical machine-readable contract IR v2`.
2. `mkdir -p reports/history` and write those lines to `reports/history/FINAL-contracts-ir-v1-retired.md`, prefixed with:
```
# History — retired contract IR v1 (not a FINAL set member)

> Moved out of `reports/FINAL-contracts-2026-08-27.md` on 2026-08-28 (plan Appendix A row "retired v1 IR block"). Non-normative. No executable may parse this as contract IR. The baseline commit "P6 baseline" holds the pre-move file.
```
3. Replace the removed block in contracts with exactly:
```
## Retired v1 IR — moved to history

The non-normative v1 IR (migration evidence only) lives in `reports/history/FINAL-contracts-ir-v1-retired.md`; it is not a set member, and `CONTRACT-01` continues to reject any `legacy_contract_ir` block wherever it appears.
```
4. In the contracts preamble, anchor: `The retained `legacy_contract_ir: 1` block is non-normative migration evidence and MUST NOT be parsed by generators or validators.` → replace with `The retired `legacy_contract_ir: 1` block was moved to `reports/history/FINAL-contracts-ir-v1-retired.md`; it is non-normative and MUST NOT be parsed by generators or validators.`
5. Ask `writer-plan` to add to App. A before the diagrams row: `| retired v1 contract IR block inline in the contracts member | \`reports/history/FINAL-contracts-ir-v1-retired.md\` (history, not a member); baseline commit "P6 baseline" |`
Post-check: `wc -l contracts` → between 1890 and 1920; `grep -c '^legacy_contract_ir: 1' contracts` → `0`; `grep -c 'contract_ir: 2' contracts` → unchanged from baseline (`grep -c 'contract_ir: 2'` before the move); `wc -l reports/history/FINAL-contracts-ir-v1-retired.md` → ≈877.

### W-26 — header date (contracts). Commit.

---

## Phase 6 — Runbooks (`writer-runbooks`, file: runbooks)

### W-27 (K-13) — cite the rollback mechanic owner
Anchor (paragraph start): `Choose exactly one `RECOVERY_ACTION` after `RB-ROLLBACK-01`.`
Insert immediately BEFORE that paragraph: `Mechanics are owned by \`PIPE-REC-06\` (rollback) and \`PIPE-REC-03\` / \`PIPE-REC-04\` (release journal, CAS); this runbook owns only the human steps and stop conditions.`
Post-check: `grep -c 'PIPE-REC-06' runbooks` → `1`.

### W-28 (K-12) — alert path comment
Anchor: the line `   if test -e "$wiki_root_abs/.kiro/pipeline/alerts.log"; then`. Insert the line above it (same indentation): `   # path is SCHEMA-CFG-04 alert_route=fallback; never change it here`.
Post-check: `grep -c 'alert_route=fallback' runbooks` → `1`.

### W-29 (K-11 pointer) — RB-AUTH-01 pointer to inputs
In `## RB-AUTH-01 — Zero-secret bootstrap`, after its `**Preconditions**` block, add one line: `Input names (never values) are the \`PIPE-G-03\` inputs table; this runbook adds no new names.`
Post-check: `grep -c 'PIPE-G-03. inputs table' runbooks` → `1`.

### W-30 — header date (runbooks). Commit.

---

## Phase 7 — Index (`writer-index`, file: FINAL-INDEX.md)

### W-31 (P6 layout) — replace enumerations with pattern + count + owner pointer
Replace the bodies (not the headings) of `## `FI-PIPELINE-01``, `## `FI-CONTRACTS-01``, `## `FI-RUNBOOKS-01`` with one sentence each of the form:
`The <member> owns exactly <N> <things> matching \`<pattern>\`; the authoritative list is that file's \`##\`/\`###\` headings (\`grep -c '^## \`PIPE-' …\`).` with N = 29 / 47 / 14.
In `## `FI-PLAN-01``, KEEP the `packages` row (34 ids — they are parity keys), and replace the `target thresholds`, `live thresholds`, `uncertainties`, and the three acceptance rows with count + pattern rows: `TH-TGT-001`…`TH-TGT-078` (78), `TH-LIVE-001`…`TH-LIVE-020` (20), `AR-09`…`AR-24` mapped to `T-AR-09`…`T-AR-24` (`AR-18`/`T-AR-18` out of scope), `AT-*` (62; authoritative: plan §11 tables).
Update `FI-NAMESPACE-01`: `T-AR-09` through `T-AR-24`.
Update `**Last updated:**` to 2026-08-28. Add under `FI-HISTORY-01`: `\`reports/history/\` holds moved, non-member history files; they are never authority.`
Post-check: `grep -c 'TH-TGT-0[0-9][0-9]`, `' FINAL-INDEX.md` → `0` (no enumeration left); `grep -c 'T-AR-24' FINAL-INDEX.md` → `≥1`; `grep -c 'reports/history/' FINAL-INDEX.md` → `1`.

Commit.

---

## Phase 8 — Verification (`verifier`, read-only, fresh context)

Run every post-check above again from scratch and paste outputs. Then the set-wide checks:
```bash
cd <repo-root>/reports
# counters vs baseline
grep -c '^| `TH-TGT-' FINAL-implementation-plan-2026-08-26.md     # 78
grep -c '^| `AR-'     FINAL-implementation-plan-2026-08-26.md     # 16
grep -c '^### `T-'    FINAL-todo-2026-08-27.md                    # 52
grep -c '^## RB-'     FINAL-runbooks-2026-08-27.md                # 14
grep -c '```mermaid'  FINAL-architecture-2026-08-26.md            # 3 (unchanged)
grep -c '```mermaid'  FINAL-pipeline-2026-08-27.md                # 4
grep -c '```mermaid'  FINAL-implementation-plan-2026-08-26.md     # 1
grep -rEc '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[a-z]{2,}' FINAL-*.md # all 0
grep -rn 'drifted\|role-result/1 wire\|five contracts\|/tmp/worktree\|toolsSettings\|git add -A\|http_proxy=' FINAL-*.md | grep -v 'App\|AB-\|rejected\|D-j'   # expect only recorded rejections
# every id referenced resolves (definitions = heading or backticked first table cell)
python3 - <<'EOF'
import re,glob
files=glob.glob('FINAL-*.md'); txt={f:open(f,encoding='utf-8').read() for f in files}
pat=r'\b(?:PIPE-(?:G|W|EXIT|REC)-\d+|SCHEMA-(?:RR|SO|CP|CFG|REL)-\d+|RB-(?:AUTH|RESTORE|ROLLBACK|INCIDENT|ALERT)-\d+|TH-(?:TGT|LIVE)-\d+|AR-\d+|AT-[A-Z0-9-]+|T-AR-\d+|T-[A-Z0-9]+-[0-9A-Z]+-\d+|AB-STR-\d+|AB-\d+|AC-EV-\d+|FI-[A-Z]+-\d+)\b'
defs=set()
for f,t in txt.items():
    for line in t.splitlines():
        m=re.match(r'^(?:#{2,4}\s+`?|\|\s*`)('+pat[2:-2]+r')`?',line)
        if m: defs.add(m.group(1))
refs={m for t in txt.values() for m in re.findall(pat,t)}
missing=sorted(r for r in refs if r not in defs and not r.endswith('-'))
print('defined',len(defs),'referenced',len(refs),'unresolved',missing)
EOF
# markdown table integrity: every row of a table has the header's column count
python3 - <<'EOF'
import glob
for f in glob.glob('FINAL-*.md'):
    hdr=None
    for i,l in enumerate(open(f,encoding='utf-8'),1):
        if l.startswith('|'):
            n=l.count('|')
            if hdr is None: hdr=n
            elif n!=hdr: print(f,i,'columns',n,'vs',hdr)
        else: hdr=None
EOF
git status --short; git log --oneline | head -12
```
Expected: `unresolved []`; no table-integrity lines; only committed changes; eight commits (baseline + seven phases).

## Final report (supervisor, ≤80 lines)
1. Table: W-id | file | status (DONE / ANCHOR-MISS / OWNER DECISION / FAILED) | post-check output (exact).
2. List of every `[OWNER DECISION]` written into the files, with file:line.
3. Baseline vs final counters table.
4. Verifier's unresolved-id and table-integrity output verbatim.
5. `git log --oneline` of the eight commits.
Do not summarise anything as done that lacks a pasted passing post-check.
