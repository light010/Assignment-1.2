# FINAL — Set Index

> **Purpose:** membership, ownership, namespace, and history boundary for the implementation-authoritative FINAL documentation set.
> **Owns:** `FI-*` membership and ownership mappings only; it does not restate architecture, plan, task, pipeline, schema, or runbook facts.
> **Siblings:** [architecture](FINAL-architecture-2026-08-26.md), [implementation plan](FINAL-implementation-plan-2026-08-26.md), [todo](FINAL-todo-2026-08-27.md), [pipeline](FINAL-pipeline-2026-08-27.md), [contracts](FINAL-contracts-2026-08-27.md), and [runbooks](FINAL-runbooks-2026-08-27.md).
> **Last updated:** 2026-08-27.
> **One fact, one home:** only the seven members listed by `FI-SET-01` are implementation authority. Anything else, including retired design/review/build documents, is history unless a current member imports the fact and assigns it a current ID.

## `FI-SET-01` — Authoritative members

| Member | Purpose | Owned sections / namespaces |
|---|---|---|
| [Target Architecture](FINAL-architecture-2026-08-26.md) | principles, verified as-built evidence, target invariants/topology, capability and user contract, adjudications, whole-set sources | numeric §§0–5; Appendix B; Appendix C; `AB-*`, `AB-STR-*`, `AC-EV-*` |
| [Implementation Plan](FINAL-implementation-plan-2026-08-26.md) | roadmap, packages/DAG, decisions, mutable values, uncertainties, acceptance, history | numeric §§6–11; Appendix A; package IDs; decisions #1–#20; `TH-TGT-*`, `TH-LIVE-*`, `AR-*`, `AT-*` |
| [Delivery Ledger](FINAL-todo-2026-08-27.md) | mutable package/probe delivery cards and receipts | `T-*`; nested `T-AR-*` |
| [Pipeline Contract](FINAL-pipeline-2026-08-27.md) | exact global/wiki execution, exits, locking, publication and recovery | `PIPE-G-*`, `PIPE-W-*`, `PIPE-EXIT-*`, `PIPE-REC-*` |
| [Runtime and State Contracts](FINAL-contracts-2026-08-27.md) | canonical machine IR, shapes, byte grammar, lifecycles, compatibility and generated-schema rule | `SCHEMA-RR-*`, `SCHEMA-SO-*`, `SCHEMA-CP-*`, `SCHEMA-CFG-*`, `SCHEMA-REL-*` |
| [Operator Runbooks](FINAL-runbooks-2026-08-27.md) | human auth, restore, rollback, incident and alert procedures | `RB-AUTH-*`, `RB-RESTORE-*`, `RB-ROLLBACK-*`, `RB-INCIDENT-*`, `RB-ALERT-*` |
| [Set Index](FINAL-INDEX.md) | this membership/ownership/history map | `FI-*` |

## `FI-SECTIONS-01` — Numeric and appendix ownership

Numeric root sections are unique across the set: architecture owns §0 Principles, §1 Keep-list/as-built, §2 verified defects/gaps, §3 target architecture, §4 topology/roles, and §5 user contract; plan owns §6 roadmap, §7 packages/DAG, §8 decisions, §9 thresholds, §9.2 live values, §10 uncertainties, and §11 acceptance. Appendix A is the plan's supersession/move ledger; Appendix B is architecture adjudication; Appendix C is architecture's whole-set source/evidence register. No companion may allocate a numeric root section or another Appendix A/B/C.

## `FI-NAMESPACE-01` — Stable namespaces

- Membership: `FI-*`.
- Delivery: `T-<PACKAGE-ID>-NN`; uncertainty work: `T-AR-09` through `T-AR-23` (the sole intentional subnamespace of `T-*`).
- Pipeline: `PIPE-G-*`, `PIPE-W-*`, `PIPE-EXIT-*`, `PIPE-REC-*`.
- Contracts: `SCHEMA-RR-*`, `SCHEMA-SO-*`, `SCHEMA-CP-*`, `SCHEMA-CFG-*`, `SCHEMA-REL-*`.
- Runbooks: `RB-AUTH-*`, `RB-RESTORE-*`, `RB-ROLLBACK-*`, `RB-INCIDENT-*`, `RB-ALERT-*`.
- Plan values/evidence: `TH-TGT-*`, `TH-LIVE-*`, `AR-*`, `AT-*`; package IDs are the exact §7.1 catalog keys.
- Architecture decisions/evidence: `AB-*`, `AB-STR-*`, `AC-EV-*`; user rules are R-1 through R-10.

Full IDs are globally unique. A reference to a package, threshold, acceptance, AR, pipeline step, schema, runbook, or card must use the exact ID; prose row names and historical section labels are not references.

## `FI-PIPELINE-01` — Pipeline catalog

The Pipeline Contract owns exactly 29 stable steps: `PIPE-G-01`, `PIPE-G-02`, `PIPE-G-03`, `PIPE-G-04`, `PIPE-G-05`, `PIPE-G-06`, `PIPE-G-07`, `PIPE-W-01`, `PIPE-W-02`, `PIPE-W-03`, `PIPE-W-04`, `PIPE-W-05`, `PIPE-W-06`, `PIPE-W-07`, `PIPE-W-08`, `PIPE-EXIT-01`, `PIPE-EXIT-02`, `PIPE-EXIT-03`, `PIPE-EXIT-04`, `PIPE-EXIT-05`, `PIPE-EXIT-06`, `PIPE-REC-01`, `PIPE-REC-02`, `PIPE-REC-03`, `PIPE-REC-04`, `PIPE-REC-05`, `PIPE-REC-06`, `PIPE-REC-07`, and `PIPE-REC-08`.

## `FI-CONTRACTS-01` — Contract catalog

The Runtime and State Contracts companion owns exactly 47 schemas: `SCHEMA-RR-01`, `SCHEMA-RR-02`, `SCHEMA-RR-03`, `SCHEMA-RR-04`, `SCHEMA-SO-01`, `SCHEMA-SO-02`, `SCHEMA-SO-03`, `SCHEMA-SO-04`, `SCHEMA-SO-05`, `SCHEMA-SO-06`, `SCHEMA-SO-07`, `SCHEMA-SO-08`, `SCHEMA-SO-09`, `SCHEMA-CP-01`, `SCHEMA-CP-02`, `SCHEMA-CP-03`, `SCHEMA-CP-04`, `SCHEMA-CFG-00`, `SCHEMA-CFG-01`, `SCHEMA-CFG-02`, `SCHEMA-CFG-03`, `SCHEMA-CFG-04`, `SCHEMA-CFG-05`, `SCHEMA-CFG-06`, `SCHEMA-CFG-07`, `SCHEMA-CFG-08`, `SCHEMA-CFG-09`, `SCHEMA-CFG-10`, `SCHEMA-CFG-11`, `SCHEMA-CFG-12`, `SCHEMA-CFG-13`, `SCHEMA-CFG-14`, `SCHEMA-CFG-15`, `SCHEMA-CFG-16`, `SCHEMA-CFG-17`, `SCHEMA-CFG-18`, `SCHEMA-CFG-19`, `SCHEMA-REL-00`, `SCHEMA-REL-01`, `SCHEMA-REL-02`, `SCHEMA-REL-03`, `SCHEMA-REL-04`, `SCHEMA-REL-05`, `SCHEMA-REL-06`, `SCHEMA-REL-07`, `SCHEMA-REL-08`, and `SCHEMA-REL-09`.

## `FI-RUNBOOKS-01` — Runbook catalog

The Operator Runbooks companion owns exactly 14 procedures: `RB-AUTH-01`, `RB-AUTH-02`, `RB-RESTORE-00`, `RB-RESTORE-01`, `RB-RESTORE-02`, `RB-RESTORE-03`, `RB-RESTORE-04`, `RB-ROLLBACK-01`, `RB-ROLLBACK-02`, `RB-ROLLBACK-03`, `RB-INCIDENT-01`, `RB-INCIDENT-02`, `RB-ALERT-01`, and `RB-ALERT-02`.

## `FI-PLAN-01` — Plan-owned stable catalogs

This is a membership map, not a second definition of scope, values, or tests. The 34 package IDs below are exactly the plan §7.1 catalog, plan §7.2 DAG label set, and Delivery Ledger `package_id` set.

| Catalog | Indexed stable IDs |
|---|---|
| packages | `PRESERVE-00`, `RETENTION-01`, `RUNTIME-01`, `DOCTOR-01`, `IDX-01`, `SRC-00`, `QUERY-01`, `CONTRACT-01`, `KIRO-SEC-01R`, `VER-01`, `TXN-01R`, `AUTH-02`, `CONFLUENCE-01`, `FRESH-01R`, `KEYFACTS-01`, `SUMMARY-01`, `MONITOR-01`, `BACKUP-01`, `DISCOVERY-01`, `MCP-QUERY-01`, `CAPTURE-01`, `FRAMEWORK-01`, `PORTAL-01`, `PORTAL-02`, `PORTAL-03`, `REPO-01`, `WEB-01`, `META-02`, `CODE-01`, `RENUMBER-01`, `RETIRE-01`, `READY-01`, `DRILL-01`, `EVAL-01` |
| target thresholds | `TH-TGT-001`, `TH-TGT-002`, `TH-TGT-003`, `TH-TGT-004`, `TH-TGT-005`, `TH-TGT-006`, `TH-TGT-007`, `TH-TGT-008`, `TH-TGT-009`, `TH-TGT-010`, `TH-TGT-011`, `TH-TGT-012`, `TH-TGT-013`, `TH-TGT-014`, `TH-TGT-015`, `TH-TGT-016`, `TH-TGT-017`, `TH-TGT-018`, `TH-TGT-019`, `TH-TGT-020`, `TH-TGT-021`, `TH-TGT-022`, `TH-TGT-023`, `TH-TGT-024`, `TH-TGT-025`, `TH-TGT-026`, `TH-TGT-027`, `TH-TGT-028`, `TH-TGT-029`, `TH-TGT-030`, `TH-TGT-031`, `TH-TGT-032`, `TH-TGT-033`, `TH-TGT-034`, `TH-TGT-035`, `TH-TGT-036`, `TH-TGT-037`, `TH-TGT-038`, `TH-TGT-039`, `TH-TGT-040`, `TH-TGT-041`, `TH-TGT-042`, `TH-TGT-043`, `TH-TGT-044`, `TH-TGT-045`, `TH-TGT-046`, `TH-TGT-047`, `TH-TGT-048`, `TH-TGT-049`, `TH-TGT-050`, `TH-TGT-051`, `TH-TGT-052`, `TH-TGT-053`, `TH-TGT-054`, `TH-TGT-055`, `TH-TGT-056`, `TH-TGT-057`, `TH-TGT-058`, `TH-TGT-059`, `TH-TGT-060`, `TH-TGT-061`, `TH-TGT-062`, `TH-TGT-063`, `TH-TGT-064`, `TH-TGT-065`, `TH-TGT-066`, `TH-TGT-067`, `TH-TGT-068`, `TH-TGT-069`, `TH-TGT-070`, `TH-TGT-071`, `TH-TGT-072`, `TH-TGT-073`, `TH-TGT-074`, `TH-TGT-075`, `TH-TGT-076`, `TH-TGT-077` |
| live thresholds | `TH-LIVE-001`, `TH-LIVE-002`, `TH-LIVE-003`, `TH-LIVE-004`, `TH-LIVE-005`, `TH-LIVE-006`, `TH-LIVE-007`, `TH-LIVE-008`, `TH-LIVE-009`, `TH-LIVE-010`, `TH-LIVE-011`, `TH-LIVE-012`, `TH-LIVE-013`, `TH-LIVE-014`, `TH-LIVE-015`, `TH-LIVE-016`, `TH-LIVE-017`, `TH-LIVE-018`, `TH-LIVE-019`, `TH-LIVE-020` |
| uncertainties | `AR-09`, `AR-10`, `AR-11`, `AR-12`, `AR-13`, `AR-14`, `AR-15`, `AR-16`, `AR-17`, `AR-18`, `AR-19`, `AR-20`, `AR-21`, `AR-22`, `AR-23`; mapped one-to-one to `T-AR-09`, `T-AR-10`, `T-AR-11`, `T-AR-12`, `T-AR-13`, `T-AR-14`, `T-AR-15`, `T-AR-16`, `T-AR-17`, `T-AR-18`, `T-AR-19`, `T-AR-20`, `T-AR-21`, `T-AR-22`, `T-AR-23`; `AR-18` and `T-AR-18` are out of scope |
| contract and capability acceptance | `AT-A-CONTRACT`, `AT-A-HANDOFF`, `AT-SEC-GUARD-01`, `AT-PRESERVE-00`, `AT-RETENTION-01`, `AT-QUERY-01-PAGE-TEMPLATE`, `AT-AUTH-02-EARLY`, `AT-KEYFACTS-01`, `AT-AUTH-02-RESOLUTION`, `AT-RENUMBER-01`, `AT-FRESH-TOTAL`, `AT-B-CONNECTORS`, `AT-B-PII-EGRESS`, `AT-B-QUERY`, `AT-DISCOVERY-01`, `AT-C-ACQUISITION`, `AT-C-TRANSACTION`, `AT-C-RELEASE`, `AT-PIPE-FINALIZE`, `AT-D-CLIENTS`, `AT-E-BACKUP`, `AT-E-DRILLS`, `AT-F-NAV`, `AT-F-CAPTURE`, `AT-F-RETIRE`, `AT-F-HYGIENE`, `AT-EVAL-01-LINEAGE` |
| mechanism acceptance | `AT-MECH-01`, `AT-MECH-02`, `AT-MECH-03`, `AT-MECH-04`, `AT-MECH-05`, `AT-MECH-06`, `AT-MECH-07`, `AT-MECH-08`, `AT-MECH-09`, `AT-MECH-10`, `AT-MECH-11`, `AT-MECH-12`, `AT-MECH-13`, `AT-MECH-14`, `AT-MECH-15`, `AT-MECH-16`, `AT-MECH-17` |
| user/stage acceptance | `AT-R-01`, `AT-R-02`, `AT-R-03`, `AT-R-04`, `AT-R-05`, `AT-R-06`, `AT-R-07`, `AT-R-08`, `AT-R-09`, `AT-R-10`, `AT-STAGE-M1`, `AT-STAGE-0`, `AT-STAGE-1`, `AT-STAGE-2`, `AT-STAGE-3`, `AT-STAGE-4`, `AT-STAGE-5`, `AT-STAGE-6` |

## `FI-HISTORY-01` — History boundary

Plan Appendix A is the sole supersession/move ledger. Architecture Appendix B is the sole adjudication ledger, and Appendix C is the sole external/repository evidence register. Retired files may explain provenance but cannot supply missing package scope, field definitions, commands, tests, thresholds, or decisions. A missing fact must be added to its current owner with a stable ID, not recovered through a blanket “still valid” reference.
