# FINAL — Delivery Ledger

> **Purpose:** ordered, mutable delivery cards for implementing and verifying the FINAL architecture and plan.
> **Owns:** `T-*` delivery state and `T-AR-*` uncertainty work records.
> **Siblings:** [architecture](FINAL-architecture-2026-08-26.md) owns principles, topology, and security invariants; [implementation plan](FINAL-implementation-plan-2026-08-26.md) owns stages, package scope/DAG, decisions, thresholds, uncertainties, and acceptance intent; [index](FINAL-INDEX.md) owns set membership; [pipeline](FINAL-pipeline-2026-08-27.md) owns execution, locking, exits, and recovery; [contracts](FINAL-contracts-2026-08-27.md) owns machine shapes and transitions; [runbooks](FINAL-runbooks-2026-08-27.md) owns human procedures.
> **Last updated:** 2026-08-27.
> **One fact, one home:** cards record delivery state, concrete outputs, commands, evidence, and completion only. Package scope stays in plan §7; acceptance intent stays in §11; schema, pipeline, and operator behavior stay in `SCHEMA-*`, `PIPE-*`, and `RB-*`.

## Ledger rules

- Valid states are `planned`, `blocked`, `in_progress`, `done`, `cancelled`, and `out_of_scope`. No card is `done` without its named receipt and completion condition.
- Every `package_id` resolves to plan §7.1 and appears in §7.2. Plan integration is complete: `AUTH-02` has an early Stage-2 resolver/protected milestone and a full Stage-5 rollout. A package card may remain blocked only by an owner decision, probe, or another exact `T-*` card.
- `blocked_by: none` means no known ledger dependency; it does not waive preflight, plan decisions, or package acceptance. `<run_id>` is a valid `PIPE-G-01` ID. Evidence receipts live at the exact card path shown and conform to `SCHEMA-RR-01` or `SCHEMA-REL-04` as applicable.
- Completion code `C-PACKAGE` means: named outputs exist; implementation and verification commands pass on the package fixtures and a clean fixture; cited acceptance passes; the receipt binds inputs, outputs, versions, and hashes; no listed blocker remains. `C-PROBE` means: the probe is run in its stated environment, redacted evidence is retained, plan §10 records the result or explicit residual uncertainty, and dependent cards are updated.
- Commands are the required invocation surfaces after the card's implementation exists. A missing command is work to implement, not permission to substitute a grep-only smoke test.

## Ordered package delivery

### Stage −1 — preservation and policy gate

### `T-PRESERVE-00-01` — deliver `PRESERVE-00`
`package_id`: `PRESERVE-00` · `state`: `planned` · `owner_role`: maintainer · `blocked_by`: none · refs: `SCHEMA-CFG-10`, `PIPE-G-02`, `PIPE-REC-08`, `RB-RESTORE-00`.
Outputs: `DECISIONS.md`, verified pre-evidence bundle inventory, accepted Stage −1 `deployment_seed_receipt` with valid `seed_sha256` and `receipt_sha256` in the `SCHEMA-CFG-10` preservation receipt, restored empty-directory fixture, automerge-off evidence, and the approved redaction patch; this card neither creates nor owns `orchestrator/deploy.yaml`. · Commands: implement with `uv run wiki preservation create --run-id <run_id> --json`; verify the receipt with `uv run wiki contract validate --schema preservation-receipt/1 --input <receipt> --json` and execute `RB-RESTORE-00` against an empty directory.
Acceptance: `AT-PRESERVE-00`, `AT-STAGE-M1`, `RB-RESTORE-00` · evidence: `state/runs/<run_id>/delivery/T-PRESERVE-00-01/receipt.json` · completion: `C-PACKAGE` plus automerge disabled in desired and live configuration.

### `T-RETENTION-01-01` — close decision #20 before persistence
`package_id`: `RETENTION-01` · `state`: `blocked` · `owner_role`: maintainer · `blocked_by`: `T-PRESERVE-00-01` and owner decision #20 · refs: `SCHEMA-SO-01`, `SCHEMA-SO-02`, `PIPE-REC-06`, `PIPE-REC-07`, `RB-RESTORE-04`.
Outputs: decision #20 record, aligned retention/hold schema policy, migration note, and negative restore/rotation fixtures. · Commands: implement with `uv run wiki retention validate --all`; verify with `uv run pytest tests/retention -q`.
Acceptance: `AT-RETENTION-01` · evidence: `state/runs/<run_id>/delivery/T-RETENTION-01-01/receipt.json` · completion: `C-PACKAGE` and no Stage-3 persistence card still names decision #20 as unresolved.

### Stage 0 — runtime, doctor, and deployment probes

### `T-RUNTIME-01-01` — deliver `RUNTIME-01`
`package_id`: `RUNTIME-01` · `state`: `planned` · `owner_role`: runtime maintainer · `blocked_by`: `T-PRESERVE-00-01` · refs: `PIPE-G-01`, `PIPE-G-02`, `SCHEMA-CFG-04`.
Outputs: `pyproject.toml`, `uv.lock`, `orchestrator/runtime.env`, the sole canonical `orchestrator/deploy.yaml` using the accepted Stage −1 `deployment_seed_receipt.seed` as a required invariant input, launchd derivatives, and runtime guard fixtures. · Commands: implement with `uv lock` and `uv sync --locked`; verify with `uv run pytest tests/runtime -q`.
Acceptance: `AT-MECH-17`, `AT-STAGE-0` · evidence: `state/runs/<run_id>/delivery/T-RUNTIME-01-01/receipt.json` · completion: `C-PACKAGE`.

### `T-DOCTOR-01-01` — deliver `DOCTOR-01`
`package_id`: `DOCTOR-01` · `state`: `planned` · `owner_role`: operations maintainer · `blocked_by`: `T-RUNTIME-01-01` · refs: `SCHEMA-CFG-03`, `SCHEMA-CFG-06`, `RB-AUTH-01`, `RB-AUTH-02`, `PIPE-G-02`.
Outputs: `src/wiki_cli/doctor.py`, doctor fixtures, redacted auth-state adapter, dead-man check, and Stage-0 evidence. · Commands: implement with `uv run wiki doctor --json`; verify with `uv run pytest tests/doctor -q` and `uv run wiki doctor --json` on the clean fixture.
Acceptance: `AT-R-08`, `AT-STAGE-0` · evidence: `state/runs/<run_id>/delivery/T-DOCTOR-01-01/receipt.json` · completion: `C-PACKAGE`.

### Stage 1 — truthful navigation

### `T-IDX-01-01` — deliver `IDX-01`
`package_id`: `IDX-01` · `state`: `planned` · `owner_role`: wiki maintainer · `blocked_by`: `T-DOCTOR-01-01` · refs: `PIPE-W-06`.
Outputs: Jenkins index edits, `orchestrator/index-coverage-lint.sh`, CT-gate integration, and positive/negative fixtures. · Commands: implement with `bash orchestrator/index-coverage-lint.sh jenkins`; verify with `make ct-gate WIKI=jenkins` and `uv run pytest tests/index_coverage -q`.
Acceptance: `AT-MECH-16`, `AT-STAGE-1` · evidence: `state/runs/<run_id>/delivery/T-IDX-01-01/receipt.json` · completion: `C-PACKAGE`.

### `T-SRC-00-01` — deliver `SRC-00`
`package_id`: `SRC-00` · `state`: `planned` · `owner_role`: source-integrity maintainer · `blocked_by`: `T-DOCTOR-01-01` · refs: `SCHEMA-SO-04`, `PIPE-W-02`, `PIPE-W-08`.
Outputs: corrected `orchestrator/hp5-drift-check.py` and regression fixtures for missing or unusable coverage. · Commands: implement with `uv run python orchestrator/hp5-drift-check.py --help`; verify with `uv run pytest tests/test_hp5_drift_check.py -q`.
Acceptance: `AT-FRESH-TOTAL`, `AT-STAGE-1` (`all_skips`) · evidence: `state/runs/<run_id>/delivery/T-SRC-00-01/receipt.json` · completion: `C-PACKAGE`.

### `T-QUERY-01-01` — deliver `QUERY-01`
`package_id`: `QUERY-01` · `state`: `planned` · `owner_role`: query maintainer · `blocked_by`: `T-IDX-01-01`, `T-SRC-00-01` · refs: `SCHEMA-CFG-02`, `SCHEMA-CFG-19`, `SCHEMA-SO-04`, `SCHEMA-REL-04`, `TH-TGT-015`, `TH-TGT-016`.
Outputs: `src/wiki_core/`, `src/wiki_cli/`, dedicated `owner-result/1` resolver/formatter, private-catalog guard, pinned `tests/query/golden.json`, `tests/query/baselines/stage1-manifest.json` binding corpus/runner/baseline digests, validated `tests/query/baselines/stage1-metrics.jsonl` baseline, accepted `state/runs/<run_id>/delivery/T-QUERY-01-01/stage1-metrics.jsonl` `SCHEMA-REL-04` latency/Recall@5 result, and legacy-to-UNVERIFIED compatibility fixtures. · Commands: implement with `uv run wiki find --json --query <fixture-query>`; verify with `uv run pytest tests/query -q` and `uv run wiki query benchmark --corpus tests/query/golden.json --manifest tests/query/baselines/stage1-manifest.json --baseline tests/query/baselines/stage1-metrics.jsonl --result state/runs/<run_id>/delivery/T-QUERY-01-01/stage1-metrics.jsonl`.
Acceptance: `AT-B-QUERY`, `AT-STAGE-1` · evidence: `state/runs/<run_id>/delivery/T-QUERY-01-01/receipt.json` · completion: `C-PACKAGE` after exact/split lookup, warning-first freshness, citations, ownership, private exclusion, `TH-TGT-015`, and `TH-TGT-016` pass.

### `T-QUERY-01-02` — install the page-authoring projection
`package_id`: `QUERY-01` · `state`: `planned` · `owner_role`: documentation maintainer · `blocked_by`: `T-QUERY-01-01` · refs: `SCHEMA-CFG-01`.
Outputs: `.kiro/steering/page-template.md`, generated per-wiki copies, and drift fixture; no package or schema prose is duplicated in the template. · Commands: implement with `uv run wiki framework sync --component page-template`; verify with `uv run wiki framework check --component page-template`.
Acceptance: `AT-QUERY-01-PAGE-TEMPLATE` · evidence: `state/runs/<run_id>/delivery/T-QUERY-01-02/receipt.json` · completion: `C-PACKAGE`.

### Stage 2 — contracts, capabilities, verification, and transactions

### `T-CONTRACT-01-01` — deliver `CONTRACT-01`
`package_id`: `CONTRACT-01` · `state`: `planned` · `owner_role`: contract maintainer · `blocked_by`: `T-QUERY-01-01` · refs: `SCHEMA-RR-01`, `SCHEMA-RR-02`, `SCHEMA-RR-03`, `SCHEMA-RR-04`, `SCHEMA-SO-01`, `SCHEMA-SO-02`, `SCHEMA-SO-03`, `SCHEMA-SO-04`, `SCHEMA-SO-05`, `SCHEMA-SO-06`, `SCHEMA-SO-07`, `SCHEMA-SO-08`, `SCHEMA-SO-09`, `SCHEMA-CP-01`, `SCHEMA-CP-02`, `SCHEMA-CP-03`, `SCHEMA-CP-04`, `SCHEMA-CFG-00`, `SCHEMA-CFG-01`, `SCHEMA-CFG-02`, `SCHEMA-CFG-03`, `SCHEMA-CFG-04`, `SCHEMA-CFG-05`, `SCHEMA-CFG-06`, `SCHEMA-CFG-07`, `SCHEMA-CFG-08`, `SCHEMA-CFG-09`, `SCHEMA-CFG-10`, `SCHEMA-CFG-11`, `SCHEMA-CFG-12`, `SCHEMA-CFG-13`, `SCHEMA-CFG-14`, `SCHEMA-CFG-15`, `SCHEMA-CFG-16`, `SCHEMA-CFG-17`, `SCHEMA-CFG-18`, `SCHEMA-CFG-19`, `SCHEMA-REL-00`, `SCHEMA-REL-01`, `SCHEMA-REL-02`, `SCHEMA-REL-03`, `SCHEMA-REL-04`, `SCHEMA-REL-05`, `SCHEMA-REL-06`, `SCHEMA-REL-07`, `SCHEMA-REL-08`, `SCHEMA-REL-09`.
Outputs: generated `orchestrator/schemas/*.json`, validators, valid/invalid fixtures, and canonical-source drift check. · Commands: implement with `uv run wiki schemas generate`; verify with `uv run wiki schemas check` and `uv run pytest tests/contracts -q`.
Acceptance: `AT-A-CONTRACT` · evidence: `state/runs/<run_id>/delivery/T-CONTRACT-01-01/receipt.json` · completion: `C-PACKAGE`.

### `T-KIRO-SEC-01R-01` — deliver `KIRO-SEC-01R`
`package_id`: `KIRO-SEC-01R` · `state`: `planned` · `owner_role`: security maintainer · `blocked_by`: `T-CONTRACT-01-01`, `T-AR-09`, `T-AR-17` · refs: `SCHEMA-RR-04`, `PIPE-W-04`, `PIPE-W-05`.
Outputs: least-capability agent profiles, `permissions` migration, handoff renderer/linter, the shared pre-persistence classification and egress-guard library, and deny/PII/SSRF/redirect/DNS-rebinding/hostile-input fixtures. · Commands: implement with `uv run wiki security render-profiles`; verify with `uv run pytest tests/security -q` and `uv run wiki handoff-lint <fixture>`.
Acceptance: `AT-A-HANDOFF`, `AT-SEC-GUARD-01`, `AT-E-DRILLS` (`hostile_source`), and `T-AR-09` · evidence: `state/runs/<run_id>/delivery/T-KIRO-SEC-01R-01/receipt.json` · completion: `C-PACKAGE`.

### `T-VER-01-01` — deliver `VER-01`
`package_id`: `VER-01` · `state`: `planned` · `owner_role`: verification maintainer · `blocked_by`: `T-KIRO-SEC-01R-01` · refs: `SCHEMA-RR-01`, `SCHEMA-RR-02`, `PIPE-W-07`, `PIPE-EXIT-01`.
Outputs: verifier profile, orchestrator-side attestation transport/validator, and binding/no-write fixtures. · Commands: implement with `uv run wiki verify --candidate <fixture>`; verify with `uv run pytest tests/verifier -q`.
Acceptance: `AT-A-CONTRACT`, `AT-C-TRANSACTION` (`wrong-run-id`) · evidence: `state/runs/<run_id>/delivery/T-VER-01-01/receipt.json` · completion: `C-PACKAGE`.

### `T-TXN-01R-01` — deliver `TXN-01R`
`package_id`: `TXN-01R` · `state`: `planned` · `owner_role`: release maintainer · `blocked_by`: `T-VER-01-01` · refs: `PIPE-G-04`, `PIPE-G-05`, `PIPE-G-06`, `PIPE-W-01`, `PIPE-W-06`, `PIPE-W-07`, `PIPE-EXIT-01`, `PIPE-EXIT-02`, `PIPE-EXIT-03`, `PIPE-EXIT-04`, `PIPE-EXIT-05`, `PIPE-EXIT-06`, `PIPE-REC-02`, `PIPE-REC-03`, `PIPE-REC-04`, `PIPE-REC-05`, `PIPE-REC-06`, `PIPE-REC-07`, `SCHEMA-REL-00`, `SCHEMA-REL-01`, `SCHEMA-REL-02`, `SCHEMA-REL-03`, `SCHEMA-REL-04`, `SCHEMA-REL-06`, `SCHEMA-REL-07`, `SCHEMA-REL-08`, `SCHEMA-REL-09`, `TH-TGT-077`, `TH-LIVE-020`.
Outputs: transactional orchestrator, scoped workspace/index utilities, release CLI, committed `state/releases/journals/<release_id>.jsonl` journal with run-local projections only, finalizer, and mutation-boundary fixture matrix. · Commands: implement with `uv run wiki pipeline run --mode fixture`; verify with `uv run pytest tests/transaction -q`.
Acceptance: `AT-C-TRANSACTION`, `AT-C-RELEASE`, `AT-PIPE-FINALIZE`, `AT-MECH-09`, and the pipeline mutation-boundary matrix · evidence: `state/runs/<run_id>/delivery/T-TXN-01R-01/receipt.json` · completion: `C-PACKAGE`.

### `T-AUTH-02-00` — establish minimum authority before source conflict handling
`package_id`: `AUTH-02` · `state`: `planned` · `owner_role`: governance maintainer · `blocked_by`: `T-CONTRACT-01-01` · refs: `SCHEMA-CFG-01`, `SCHEMA-SO-03`, `PIPE-W-04`, `PIPE-W-06`.
Outputs: minimal read-only authority resolver, protected-field migration, and conflict fixtures. · Commands: implement with `uv run wiki authority bootstrap --minimal`; verify with `uv run pytest tests/authority -q -k minimal`.
Acceptance: `AT-AUTH-02-EARLY` · evidence: `state/runs/<run_id>/delivery/T-AUTH-02-00/receipt.json` · completion: `C-PACKAGE`; Stage-3 roles consume the resolver without Stage-5 autonomous authority.

### Stage 3 — Confluence evidence, freshness, and operations

### `T-CONFLUENCE-01-01` — deliver `CONFLUENCE-01`
`package_id`: `CONFLUENCE-01` · `state`: `planned` · `owner_role`: connector maintainer · `blocked_by`: `T-TXN-01R-01`, `T-AUTH-02-00`, `T-RETENTION-01-01`, `T-AR-16` · refs: `SCHEMA-SO-01`, `SCHEMA-SO-02`, `SCHEMA-SO-05`, `SCHEMA-SO-06`, `SCHEMA-SO-07`, `SCHEMA-SO-08`, `SCHEMA-SO-09`, `SCHEMA-CFG-01`, `SCHEMA-CFG-06`, `SCHEMA-CFG-17`, `PIPE-G-03`, `PIPE-REC-01`, `RB-AUTH-01`, `RB-AUTH-02`.
Outputs: Confluence provider and enforcement adapter over the shared classification/egress guard, immutable evidence writers, event/index/view builders, registry backfill, and recorded connector fixtures. · Commands: implement with `uv run wiki acquire --connector confluence --fixture <fixture>`; verify with `uv run pytest tests/connectors/test_confluence.py -q`.
Acceptance: `AT-B-CONNECTORS`, `AT-B-PII-EGRESS`, `AT-C-ACQUISITION`, `AT-STAGE-3` · evidence: `state/runs/<run_id>/delivery/T-CONFLUENCE-01-01/receipt.json` · completion: `C-PACKAGE`.

### `T-FRESH-01R-01` — deliver `FRESH-01R`
`package_id`: `FRESH-01R` · `state`: `planned` · `owner_role`: source-integrity maintainer · `blocked_by`: `T-CONFLUENCE-01-01` · refs: `SCHEMA-SO-03`, `SCHEMA-SO-04`, `PIPE-W-02`, `PIPE-W-08`, `PIPE-EXIT-05`.
Outputs: assessment/freshness engine, presentation projector, proceed adapter, and total-state fixtures. · Commands: implement with `uv run wiki freshness rebuild --fixture <fixture>`; verify with `uv run pytest tests/freshness -q`.
Acceptance: `AT-FRESH-TOTAL`, `AT-STAGE-3` (`all_skips`, `html_login_error`, `source_removed`, `timeout_error`) · evidence: `state/runs/<run_id>/delivery/T-FRESH-01R-01/receipt.json` · completion: `C-PACKAGE`.

### `T-SUMMARY-01-01` — deliver `SUMMARY-01`
`package_id`: `SUMMARY-01` · `state`: `planned` · `owner_role`: operations maintainer · `blocked_by`: `T-FRESH-01R-01` · refs: `SCHEMA-RR-01`, `SCHEMA-SO-04`, `PIPE-W-08`, `PIPE-EXIT-05`.
Outputs: deterministic summary projector, optional navigator renderer, CLI prose/JSON views, and quiet/unhealthy fixtures. · Commands: implement with `uv run wiki health --json`; verify with `uv run pytest tests/summary -q`.
Acceptance: `AT-PIPE-FINALIZE` · evidence: `state/runs/<run_id>/delivery/T-SUMMARY-01-01/receipt.json` · completion: `C-PACKAGE`.

### `T-MONITOR-01-01` — deliver `MONITOR-01`
`package_id`: `MONITOR-01` · `state`: `planned` · `owner_role`: operations maintainer · `blocked_by`: `T-FRESH-01R-01` · refs: `SCHEMA-SO-04`, `SCHEMA-REL-04`, `PIPE-W-08`.
Outputs: source-monitor and discovery-manifest generators, archived hand-edited monitor, and deterministic projection fixtures. · Commands: implement with `uv run wiki monitor generate --all`; verify with `uv run pytest tests/monitor -q`.
Acceptance: `AT-PIPE-FINALIZE` · evidence: `state/runs/<run_id>/delivery/T-MONITOR-01-01/receipt.json` · completion: `C-PACKAGE`.

### `T-BACKUP-01-01` — include raw evidence and events in verified recovery
`package_id`: `BACKUP-01` · `state`: `planned` · `owner_role`: recovery maintainer · `blocked_by`: `T-CONFLUENCE-01-01` · refs: `SCHEMA-CFG-13`, `SCHEMA-CFG-18`, `PIPE-G-07`, `PIPE-REC-08`, `RB-RESTORE-01`, `RB-RESTORE-02`, `RB-RESTORE-03`.
Outputs: registered evidence-store backup inventory, off-host adapter, backup receipt, empty-tree restore path, and interruption/corruption fixtures. · Commands: implement with `make backup`; verify with `make restore-test` and `uv run pytest tests/backup -q`.
Acceptance: `AT-E-BACKUP`, `AT-STAGE-3` · evidence: `state/runs/<run_id>/delivery/T-BACKUP-01-01/receipt.json` · completion: `C-PACKAGE`.

### `T-KEYFACTS-01-01` — deliver the governed Key-Facts audit
`package_id`: `KEYFACTS-01` · `state`: `planned` · `owner_role`: evidence auditor · `blocked_by`: `T-FRESH-01R-01` · refs: `SCHEMA-SO-03`, `SCHEMA-RR-01`, `PIPE-W-04`, `PIPE-W-06`.
Outputs: versioned Key-Facts registry, comparison projector, full-corpus audit receipt, and discrepancy fixtures. · Commands: implement with `uv run wiki key-facts audit --all`; verify with `uv run pytest tests/key_facts -q`.
Acceptance: `AT-KEYFACTS-01` · evidence: `state/runs/<run_id>/delivery/T-KEYFACTS-01-01/receipt.json` · completion: `C-PACKAGE`.

### `T-DISCOVERY-01-01` — roll out discovery without widening authority
`package_id`: `DISCOVERY-01` · `state`: `planned` · `owner_role`: discovery maintainer · `blocked_by`: `T-MONITOR-01-01`, `T-CONFLUENCE-01-01` · refs: `SCHEMA-CP-01`, `SCHEMA-CP-02`, `PIPE-W-03`, `PIPE-W-08`.
Outputs: scoped Confluence discovery first, provider adapters, candidate projection, scope guards, recall metric receipt, and per-source rollout receipts. · Commands: implement with `uv run wiki discover --mode fixture`; verify with `uv run pytest tests/discovery -q`.
Acceptance: `AT-DISCOVERY-01` · evidence: `state/runs/<run_id>/delivery/T-DISCOVERY-01-01/receipt.json` · completion: `C-PACKAGE`.

### Stage 4 — assistants, capture, and portable framework

### `T-MCP-QUERY-01-01` — deliver `MCP-QUERY-01`
`package_id`: `MCP-QUERY-01` · `state`: `planned` · `owner_role`: assistant maintainer · `blocked_by`: `T-SUMMARY-01-01`, `T-AR-13` · refs: `SCHEMA-CFG-02`, `SCHEMA-CFG-19`, `SCHEMA-SO-04`.
Outputs: `src/wiki_mcp_query/`, read-only tool schemas, abstention fixtures, and normalized client responses.
Commands: implement with `uv run wiki-mcp-query --fixture <fixture>`; verify with `uv run pytest tests/mcp_query -q`.
Acceptance: `AT-B-QUERY`, `AT-D-CLIENTS`, `AT-F-NAV` · evidence: `state/runs/<run_id>/delivery/T-MCP-QUERY-01-01/receipt.json` · completion: `C-PACKAGE`.

### `T-CAPTURE-01-01` — deliver `CAPTURE-01`
`package_id`: `CAPTURE-01` · `state`: `planned` · `owner_role`: contribution maintainer · `blocked_by`: `T-TXN-01R-01` · refs: `SCHEMA-CP-01`, `SCHEMA-CP-02`, `SCHEMA-CP-03`, `SCHEMA-RR-03`, `SCHEMA-RR-04`, `PIPE-W-04`, `PIPE-W-05`.
Outputs: `src/wiki_mcp_capture/`, CLI capture/lifecycle administration, atomic `SCHEMA-CP-04` submission marker, staging/projector, privacy/egress enforcement, private `local_laptop` note routing, shared personal-data rejection before proposal ID allocation, and lifecycle fixtures.
Commands: implement with `uv run wiki capture --fixture <fixture>`; verify with `uv run pytest tests/capture -q`.
Acceptance: `AT-A-CONTRACT`, `AT-B-PII-EGRESS`, `AT-F-CAPTURE` · evidence: `state/runs/<run_id>/delivery/T-CAPTURE-01-01/receipt.json` · completion: `C-PACKAGE`.

### `T-FRAMEWORK-01-01` — deliver `FRAMEWORK-01`
`package_id`: `FRAMEWORK-01` · `state`: `planned` · `owner_role`: platform maintainer · `blocked_by`: `T-MCP-QUERY-01-01`, `T-CAPTURE-01-01` · refs: `SCHEMA-CFG-04`, `SCHEMA-CFG-05`, `RB-RESTORE-02`.
Outputs: framework source, generated client/workspace files, manifest/version records, conformance fixtures, and symlinkless restore integration.
Commands: implement with `uv run wiki framework sync`; verify with `uv run wiki framework check` and `uv run pytest tests/client_conformance -q`.
Acceptance: `AT-D-CLIENTS`, `AT-E-BACKUP`, `AT-STAGE-4` · evidence: `state/runs/<run_id>/delivery/T-FRAMEWORK-01-01/receipt.json` · completion: `C-PACKAGE`.

### Stage 5 — connector rollout and governance

### `T-PORTAL-01-01` — deliver `PORTAL-01`
`package_id`: `PORTAL-01` · `state`: `planned` · `owner_role`: connector maintainer · `blocked_by`: `T-FRAMEWORK-01-01`, `T-AR-14` · refs: `SCHEMA-SO-01`, `SCHEMA-SO-02`, `SCHEMA-CFG-01`, `PIPE-G-03`.
Outputs: first portal provider, policy profile, recorded fixtures, shadow receipt, and connector-gate receipt.
Commands: implement with `uv run wiki acquire --connector portal-01 --fixture <fixture>`; verify with `uv run pytest tests/connectors/test_portal_01.py -q`.
Acceptance: `AT-B-CONNECTORS`, `AT-B-PII-EGRESS`, `AT-STAGE-5` · evidence: `state/runs/<run_id>/delivery/T-PORTAL-01-01/receipt.json` · completion: `C-PACKAGE`.

### `T-PORTAL-02-01` — deliver `PORTAL-02`
`package_id`: `PORTAL-02` · `state`: `planned` · `owner_role`: connector maintainer · `blocked_by`: `T-PORTAL-01-01`, `T-AR-15` · refs: `SCHEMA-SO-01`, `SCHEMA-SO-02`, `SCHEMA-CFG-01`, `SCHEMA-CFG-06`, `PIPE-G-03`, `RB-AUTH-01`, `RB-AUTH-02`.
Outputs: second portal provider, policy profile, recorded fixtures, shadow receipt, and connector-gate receipt.
Commands: implement with `uv run wiki acquire --connector portal-02 --fixture <fixture>`; verify with `uv run pytest tests/connectors/test_portal_02.py -q`.
Acceptance: `AT-B-CONNECTORS`, `AT-B-PII-EGRESS`, `AT-STAGE-5` · evidence: `state/runs/<run_id>/delivery/T-PORTAL-02-01/receipt.json` · completion: `C-PACKAGE`.

### `T-PORTAL-03-01` — deliver `PORTAL-03`
`package_id`: `PORTAL-03` · `state`: `planned` · `owner_role`: connector maintainer · `blocked_by`: `T-PORTAL-02-01` · refs: `SCHEMA-SO-01`, `SCHEMA-SO-02`, `SCHEMA-CFG-01`, `SCHEMA-CFG-06`, `PIPE-G-03`, `RB-AUTH-01`, `RB-AUTH-02`.
Outputs: third portal provider, policy profile, recorded fixtures, shadow receipt, and connector-gate receipt.
Commands: implement with `uv run wiki acquire --connector portal-03 --fixture <fixture>`; verify with `uv run pytest tests/connectors/test_portal_03.py -q`.
Acceptance: `AT-B-CONNECTORS`, `AT-B-PII-EGRESS`, `AT-STAGE-5` · evidence: `state/runs/<run_id>/delivery/T-PORTAL-03-01/receipt.json` · completion: `C-PACKAGE`.

### `T-REPO-01-01` — deliver the repository connector
`package_id`: `REPO-01` · `state`: `planned` · `owner_role`: connector maintainer · `blocked_by`: `T-PORTAL-01-01` · refs: `SCHEMA-SO-01`, `SCHEMA-SO-02`, `SCHEMA-CFG-01`, `PIPE-G-03`.
Outputs: repository provider, bounded policy profile, recorded ancestor/non-ancestor fixtures, shadow receipt, and connector-gate receipt.
Commands: implement with `uv run wiki acquire --connector repo --fixture <fixture>`; verify with `uv run pytest tests/connectors/test_repo.py -q`.
Acceptance: `AT-B-CONNECTORS`, `AT-STAGE-5` (repository ancestry fixture) · evidence: `state/runs/<run_id>/delivery/T-REPO-01-01/receipt.json` · completion: `C-PACKAGE`.

### `T-WEB-01-01` — deliver the hardened web connector
`package_id`: `WEB-01` · `state`: `planned` · `owner_role`: connector/security maintainer · `blocked_by`: `T-PORTAL-01-01` · refs: `SCHEMA-SO-01`, `SCHEMA-SO-02`, `SCHEMA-CFG-01`, `PIPE-G-03`.
Outputs: hardened web provider/worker enforcement adapter over the shared egress guard, recorded SSRF/redirect/DNS fixtures, shadow receipt, and connector-gate receipt.
Commands: implement with `uv run wiki acquire --connector web --fixture <fixture>`; verify with `uv run pytest tests/connectors/test_web.py tests/security/test_egress.py -q`.
Acceptance: `AT-B-CONNECTORS`, `AT-B-PII-EGRESS`, `AT-STAGE-5` · evidence: `state/runs/<run_id>/delivery/T-WEB-01-01/receipt.json` · completion: `C-PACKAGE`.

### `T-META-02-01` — deliver `META-02`
`package_id`: `META-02` · `state`: `planned` · `owner_role`: metadata maintainer · `blocked_by`: `T-KEYFACTS-01-01`, `T-DISCOVERY-01-01`, `T-PORTAL-03-01`, `T-REPO-01-01`, `T-WEB-01-01` · refs: `SCHEMA-CFG-01`, `PIPE-W-06`.
Outputs: metadata migration, registry/frontmatter reconciliation, placement/dedup projections, and pilot/rollout receipts.
Commands: implement with `uv run wiki metadata migrate --fixture <fixture>`; verify with `make readiness` and `uv run pytest tests/metadata -q`.
Acceptance: `AT-A-CONTRACT`, `AT-STAGE-5` (`placement_violation`) · evidence: `state/runs/<run_id>/delivery/T-META-02-01/receipt.json` · completion: `C-PACKAGE`.

### `T-AUTH-02-01` — deliver `AUTH-02`
`package_id`: `AUTH-02` · `state`: `planned` · `owner_role`: governance maintainer · `blocked_by`: `T-AUTH-02-00`, `T-META-02-01` · refs: `SCHEMA-CFG-01`, `PIPE-W-04`, `PIPE-W-06`.
Outputs: `.kiro/steering/authority.yaml`, resolver, generated project-context projection, protected-field migration, and conflict fixtures.
Commands: implement with `uv run wiki authority sync`; verify with `uv run wiki authority check` and `uv run pytest tests/authority -q`.
Acceptance: `AT-AUTH-02-RESOLUTION` · evidence: `state/runs/<run_id>/delivery/T-AUTH-02-01/receipt.json` · completion: `C-PACKAGE`.

### `T-CODE-01-01` — deliver `CODE-01`
`package_id`: `CODE-01` · `state`: `planned` · `owner_role`: quality maintainer · `blocked_by`: `T-META-02-01` · refs: `PIPE-W-06`.
Outputs: code-sample lint, language fixtures, CT-gate integration, and gate receipt.
Commands: implement with `uv run wiki code-lint --all`; verify with `uv run pytest tests/code_lint -q` and `make validate`.
Acceptance: `AT-STAGE-5` · evidence: `state/runs/<run_id>/delivery/T-CODE-01-01/receipt.json` · completion: `C-PACKAGE`.

### `T-RENUMBER-01-01` — deliver bounded renumber repair
`package_id`: `RENUMBER-01` · `state`: `planned` · `owner_role`: librarian maintainer · `blocked_by`: `T-META-02-01` · refs: `SCHEMA-CP-01`, `SCHEMA-CP-02`, `SCHEMA-CP-03`, `PIPE-W-04`, `PIPE-W-06`.
Outputs: proposal-only renumber planner, allocator integration, link-update preview, veto/cap evidence, and rollback fixtures.
Commands: implement with `uv run wiki renumber plan --fixture <fixture>`; verify with `uv run pytest tests/renumber -q` and `bash orchestrator/allocate-filename.sh --check aidlc`.
Acceptance: `AT-RENUMBER-01` · evidence: `state/runs/<run_id>/delivery/T-RENUMBER-01-01/receipt.json` · completion: `C-PACKAGE`.

### `T-RETIRE-01-01` — deliver governed retirement
`package_id`: `RETIRE-01` · `state`: `planned` · `owner_role`: governance maintainer · `blocked_by`: `T-RETENTION-01-01`, `T-DISCOVERY-01-01`, `T-PORTAL-03-01`, `T-REPO-01-01`, `T-WEB-01-01`, `T-META-02-01`, `T-AR-22` · refs: `SCHEMA-CP-01`, `SCHEMA-CP-02`, `PIPE-W-04`, `PIPE-W-06`, `RB-RESTORE-04`.
Outputs: mark/grace/tombstone workflow, legal-hold guard, per-page disposition evidence, generated disclaimers, and recovery fixtures.
Commands: implement with `uv run wiki retire plan --fixture <fixture>`; verify with `uv run pytest tests/retirement -q`.
Acceptance: `AT-F-RETIRE`, `AT-STAGE-5` (`source_removed`) · evidence: `state/runs/<run_id>/delivery/T-RETIRE-01-01/receipt.json` · completion: `C-PACKAGE`.

### `T-READY-01-01` — deliver `READY-01`
`package_id`: `READY-01` · `state`: `planned` · `owner_role`: release maintainer · `blocked_by`: `T-AUTH-02-01`, `T-CODE-01-01`, `T-RENUMBER-01-01`, `T-RETIRE-01-01` · refs: `PIPE-W-06`, `SCHEMA-REL-04`.
Outputs: readiness meta-gate, governed owner/placement checks, metric receipts, and warn-to-enforce fixtures.
Commands: implement with `make readiness`; verify with `uv run pytest tests/readiness -q` and `make validate`.
Acceptance: `AT-STAGE-5` · evidence: `state/runs/<run_id>/delivery/T-READY-01-01/receipt.json` · completion: `C-PACKAGE`.

### `T-DRILL-01-01` — execute recovery and security drills
`package_id`: `DRILL-01` · `state`: `planned` · `owner_role`: incident commander · `blocked_by`: `T-BACKUP-01-01`, `T-TXN-01R-01`, `T-READY-01-01` · refs: `PIPE-REC-01`, `PIPE-REC-05`, `PIPE-REC-06`, `PIPE-REC-08`, `RB-RESTORE-02`, `RB-ROLLBACK-01`, `RB-ROLLBACK-02`, `RB-ROLLBACK-03`, `RB-INCIDENT-01`, `RB-INCIDENT-02`.
Outputs: restore, rollback, torn-acquisition, injection, provider-failure, and source-failure drill receipts with postmortem actions.
Commands: implement with `uv run wiki drill run --suite stage5`; verify with `uv run wiki drill verify --suite stage5`.
Acceptance: `AT-E-DRILLS`, `AT-STAGE-5` · evidence: `state/runs/<run_id>/delivery/T-DRILL-01-01/receipt.json` · completion: `C-PACKAGE`.

### Stage 6 — reproducible evaluation

### `T-EVAL-01-01` — deliver the baseline evaluation
`package_id`: `EVAL-01` · `state`: `planned` · `owner_role`: evaluation maintainer · `blocked_by`: `T-READY-01-01`, `T-DRILL-01-01` · refs: `SCHEMA-REL-04`, `SCHEMA-REL-05`, `SCHEMA-CFG-02`.
Outputs: versioned question corpus, runner/config digest, baseline and candidate result artifacts, review record, and regression fixtures.
Commands: implement with `uv run wiki eval run --corpus tests/eval/corpus.json`; verify with `uv run wiki eval check --result <eval-result>` and `uv run pytest tests/eval -q`.
Acceptance: `AT-EVAL-01-LINEAGE` · evidence: `state/runs/<run_id>/delivery/T-EVAL-01-01/receipt.json` · completion: `C-PACKAGE` and plan §6 Stage-6 exit cites the accepted `SCHEMA-REL-05` result.

## Uncertainty work records

These records execute plan §10 only; they do not redefine the question or closure criterion. Probe output must be redacted before it enters the evidence path.

### `T-AR-09`
`owner_package`: `KIRO-SEC-01R` · `state`: `planned` · `owner_role`: security maintainer · `blocked_by`: `T-RUNTIME-01-01` · probe: run the plan §10 AR-09 headless deny case through the Stage-2 fixture host.
Command: `uv run pytest tests/security/test_kiro_permissions.py -q -k headless_deny` · acceptance: `AT-A-HANDOFF`, `AT-E-DRILLS` · evidence: `state/runs/<run_id>/delivery/T-AR-09/receipt.json` · closure: `C-PROBE`.

### `T-AR-10`
`owner_package`: `RUNTIME-01` · `state`: `planned` · `owner_role`: runtime maintainer · `blocked_by`: `T-RUNTIME-01-01` · probe: capture one redacted CLI result using the plan §10 AR-10 fixture.
Command: `uv run wiki probe kiro-output --json` · acceptance: `AT-STAGE-0` · evidence: `state/runs/<run_id>/delivery/T-AR-10/receipt.json` · closure: `C-PROBE`.

### `T-AR-11`
`owner_package`: `RUNTIME-01` · `state`: `planned` · `owner_role`: runtime maintainer · `blocked_by`: `T-RUNTIME-01-01` · probe: execute the plan §10 AR-11 help/working-directory check.
Command: `uv run wiki probe kiro-cwd --json` · acceptance: `AT-STAGE-0` · evidence: `state/runs/<run_id>/delivery/T-AR-11/receipt.json` · closure: `C-PROBE`.

### `T-AR-12`
`owner_package`: `RUNTIME-01` · `state`: `planned` · `owner_role`: operations maintainer · `blocked_by`: `T-RUNTIME-01-01` · probe: inspect the scheduled environment through the plan §10 AR-12 launchd fixture.
Command: `uv run wiki probe launchd-path --json` · acceptance: `AT-STAGE-0` · evidence: `state/runs/<run_id>/delivery/T-AR-12/receipt.json` · closure: `C-PROBE`.

### `T-AR-13`
`owner_package`: `MCP-QUERY-01` · `state`: `planned` · `owner_role`: assistant maintainer · `blocked_by`: `T-DOCTOR-01-01` · probe: execute the MCP-specific revision-field check named by plan §10 AR-13.
Command: `uv run wiki probe confluence-mcp-version --json` · acceptance: `AT-D-CLIENTS` · evidence: `state/runs/<run_id>/delivery/T-AR-13/receipt.json` · closure: `C-PROBE`; REST evidence cannot close it.

### `T-AR-14`
`owner_package`: `PORTAL-01` · `state`: `planned` · `owner_role`: connector maintainer · `blocked_by`: `T-DOCTOR-01-01` · probe: run the plan §10 AR-14 index-presence/completeness request against the authorized fixture target.
Command: `uv run wiki probe portal-index --connector portal-01 --json` · acceptance: `AT-B-CONNECTORS` · evidence: `state/runs/<run_id>/delivery/T-AR-14/receipt.json` · closure: `C-PROBE`.

### `T-AR-15`
`owner_package`: `PORTAL-02` · `state`: `planned` · `owner_role`: connector maintainer · `blocked_by`: `T-DOCTOR-01-01` · probe: run the plan §10 AR-15 login-page classification check against both named portal profiles.
Command: `uv run wiki doctor --probe portals --json` · acceptance: `AT-B-CONNECTORS`, `AT-B-PII-EGRESS` · evidence: `state/runs/<run_id>/delivery/T-AR-15/receipt.json` · closure: `C-PROBE`.

### `T-AR-16`
`owner_package`: `CONFLUENCE-01` · `state`: `planned` · `owner_role`: auth maintainer · `blocked_by`: `T-DOCTOR-01-01` · probe: use `RB-AUTH-01` to perform the redacted deployment-profile and direct-REST capability check named by plan §10 AR-16.
Command: `uv run wiki doctor --probe confluence-auth --json` · acceptance: `AT-B-CONNECTORS`, `RB-AUTH-01` · evidence: `state/runs/<run_id>/delivery/T-AR-16/receipt.json` · closure: `C-PROBE`.

### `T-AR-17`
`owner_package`: `RUNTIME-01` · `state`: `planned` · `owner_role`: runtime maintainer · `blocked_by`: `T-PRESERVE-00-01` · probe: capture the installed CLI/version/config-compatibility facts named by plan §10 AR-17.
Command: `uv run wiki probe kiro-version --json` · acceptance: `AT-STAGE-0` · evidence: `state/runs/<run_id>/delivery/T-AR-17/receipt.json` · closure: `C-PROBE`.

### `T-AR-18` — out-of-scope record, not an executable task
`owner_package`: none · `state`: `out_of_scope` · `owner_role`: maintainer · `blocked_by`: plan §8 decision #7 · probe: none; no Copilot cloud/CLI capability may be exercised while decision #7 stands.
Command: none · acceptance: decision #7 · evidence: plan §8 decision #7 and plan §10 AR-18 · closure: remains `out_of_scope`; create executable work only after an explicit decision change.

### `T-AR-19`
`owner_package`: `PRESERVE-00` · `state`: `planned` · `owner_role`: maintainer · `blocked_by`: none · probe: record the read-only live-tree status named by plan §10 AR-19 before mutation; runtime preflight resolves decision #1 authority and fails safely when unavailable.
Command: `uv run wiki doctor --probe live-tree --json` · acceptance: `AT-PRESERVE-00` · evidence: `state/runs/<run_id>/delivery/T-AR-19/receipt.json` · closure: `C-PROBE`.

### `T-AR-20`
`owner_package`: `CONFLUENCE-01` · `state`: `planned` · `owner_role`: source-integrity maintainer · `blocked_by`: `T-KIRO-SEC-01R-01` · probe: force the plan §10 AR-20 MCP failure and distinguish exception from empty success without publication.
Command: `uv run pytest tests/connectors/test_confluence_mcp_failure.py -q` · acceptance: `AT-B-CONNECTORS`, `AT-C-ACQUISITION` · evidence: `state/runs/<run_id>/delivery/T-AR-20/receipt.json` · closure: `C-PROBE`.

### `T-AR-21`
`owner_package`: `PRESERVE-00` · `state`: `planned` · `owner_role`: recovery maintainer · `blocked_by`: `T-PRESERVE-00-01` · probe: adjudicate plan §10 AR-21 from the Stage −1 empty-directory restore evidence.
Command: `uv run wiki preservation create --run-id <run_id> --json` in the `RB-RESTORE-00` empty-directory fixture · acceptance: `AT-PRESERVE-00`, `RB-RESTORE-00` · evidence: `state/runs/<run_id>/delivery/T-AR-21/receipt.json` · closure: `C-PROBE`.

### `T-AR-22`
`owner_package`: `RETIRE-01` · `state`: `planned` · `owner_role`: quality maintainer · `blocked_by`: `T-PRESERVE-00-01` · probe: run the plan §10 AR-22 live-tree timeless validation without modifying pages after the accepted authority/preservation preflight.
Command: `bash orchestrator/timeless-lint.sh` · acceptance: `AT-F-RETIRE`, `AT-STAGE-5` · evidence: `state/runs/<run_id>/delivery/T-AR-22/receipt.json` · closure: `C-PROBE`.

### `T-AR-23`
`owner_package`: `CAPTURE-01` · `state`: `planned` · `owner_role`: product/evaluation maintainer · `blocked_by`: `T-CAPTURE-01-01` · probe: measure the redacted miss/repeat evidence named by plan §10 AR-23 at the Stage-4 exit.
Command: `uv run wiki metrics query-gaps --json` · acceptance: `AT-F-CAPTURE`, `TH-TGT-076`, `SCHEMA-REL-04` · evidence: `state/runs/<run_id>/delivery/T-AR-23/receipt.json` · closure: `C-PROBE`.

## Release-order blockers

The current critical chain begins at `T-PRESERVE-00-01`. `T-RETENTION-01-01` requires both that preservation card and owner decision #20. Stage 2 cannot start mutating work until `T-AR-09` and `T-AR-17` close. Stage 3 persistence cannot start until `T-RETENTION-01-01` and `T-AR-16` close. `T-META-02-01` and `T-RETIRE-01-01` enumerate every connector predecessor as exact `T-*` cards. Package catalog/DAG integration is complete; no unnamed dependency is a blocker. No other state transition is asserted by this ledger.
