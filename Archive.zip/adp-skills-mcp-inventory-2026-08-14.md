# ADP AI Skills, MCP Servers & Agents — Inventory

**Date:** 2026-08-14

**Purpose.** This inventory consolidates the ADP AI **skills**, **MCP servers**, and **agents** that are installed on this workstation, installable from ADP catalogs, or documented across ADP Confluence spaces. It is compiled strictly from two research source files — a Confluence research pass (skills catalogs, the GSO-approved MCP list, agents, platforms) and a local-sources pass (this workspace's wikis, this machine's configured MCP servers, install directories, and the prompt-fetcher catalog). Every named item traces back to one of those two sources; where a fact was not observed, it is omitted rather than guessed.

**How to read this (availability tiers).** Each section is tagged with an availability tier:

- **[Installed]** — present on this machine now (verified filesystem/config state).
- **[Installable]** — published in an ADP catalog/registry you can install from.
- **[Org-documented]** — described in Confluence; availability varies by team, space, and entitlement.

---

## Summary counts

| Category | Count | Tier |
|---|---|---|
| Copilot skills installed locally (`~/.copilot/skills/`) | 45 | Installed |
| — of which non-user-invocable shared library (`adp-developer-shared`) | 1 | Installed |
| OpenADP Agentic Platform plugins (+ `hx-skills`) | 5 (+1) | Installable |
| OpenADP `plugin:skill` entries documented | ~22 | Installable |
| GSO-approved MCP servers (authoritative list) | ~35 | Org-documented |
| MCP servers configured on this machine (Kiro CLI) | 3 | Installed |
| CP-project MCP suite (wiki 16) | 9 | Installable |
| PI-project MCP suite (wiki 28) | 5 | Installable |
| Other individually-documented MCP servers | 12 | Org-documented |
| AI-DLC ops/infra skills (wiki 26) | 8 | Org-documented |
| Confluence — Lyric "GEN AI Agents & Skills" | 7 | Org-documented |
| Confluence — Sora Claude Skill Catalog | ~60 | Org-documented |
| Confluence — pm-po-ops plugin skills | 81 | Org-documented |
| PS GenAI persona agents | 4 | Org-documented |
| Sora (Claude Code) agents | 8 | Org-documented |
| Wiki-pipeline agents (this repo) | 7 | Installed |
| Prompt-fetcher categories / technologies / tasks | 10 / 7 / 7 | Installable |

---

## 1. Copilot skills installed locally [Installed]

45 skill directories at `~/.copilot/skills/` on this machine (`local-sources.md` §I). `adp-developer-shared` is a shared library (Bitbucket client, config, YAML parsing), **not user-invocable**. Grouped per the categories in the source files.

**Atlassian / ALM (10)**

| Skill | One-line |
|---|---|
| `jira-tools` | Jira/Zephyr/Tempo issue management + time tracking |
| `jira-export` | Export on-prem Jira backlog for cloud migration |
| `jira-recurrence-analysis` | Detect recurring Jira issues against closed tickets |
| `confluence-tools` | Confluence page CRUD, search, inventory, attachments |
| `bitbucket-tools` | Bitbucket PR lifecycle + file/repo operations |
| `create-test-cycle` | Create Zephyr Scale test cycles |
| `create-test-workflow` | Test cases from Jira ACs with interactive edit loop |
| `create-zephyr-tests` | Publish test cases to Zephyr with Jira story linking |
| `zephyr-retrieve-testcase-info` | Retrieve/search Zephyr test cases (`MYADP-T`) |
| `zephyr-test-generator` | Analyze Jira stories → Zephyr test cases |

**Code quality / security / test (10)**

| Skill | One-line |
|---|---|
| `code-review` | Fallback PR review guidelines (security/quality/perf) |
| `code-reviewer` | Code review via company-standard prompts |
| `code-documenter` | Documentation generation (JavaDoc/docstrings/README) |
| `code-upgrader` | Upgrade/migration feasibility and guides |
| `security-reviewer` | Security review (OWASP Top 10 / CWE) |
| `snyk-security-scan` | Snyk CVE scan, safe upgrades, exception PRs |
| `tech-debt-analyzer` | Code-smell / technical-debt refactor analysis |
| `test-writer` | Test generation (JUnit5 / Jest / pytest / Jasmine) |
| `generate-java-tests` | Production-grade JUnit 5 tests for Java |
| `api-designer` | REST/GraphQL/OpenAPI design via company prompts |

**Accessibility (2)**

| Skill | One-line |
|---|---|
| `a11y-fundamentals` | Framework-agnostic WCAG 2.1 AA/AAA fundamentals |
| `angular-a11y` | Angular ARIA / keyboard / focus / screen-reader patterns |

**Content / docs (6)**

| Skill | One-line |
|---|---|
| `adp-content-guidelines` | ADP content formatting, structure, tone standards |
| `document-writer` | Create/update technical documentation |
| `document-reviewer` | Review technical docs for accuracy/style |
| `document-converter` | Convert documents (CSV/JSON/XLSX) |
| `document-extractor` | Extract text/pages/metadata from PDF/DOCX/PPTX |
| `prompt-fetcher` | Fetch ADP standardized prompts from Bitbucket |

**Design / UI / Figma / Waypoint / MFE (7)**

| Skill | One-line |
|---|---|
| `use-waypoint-components` | Implement Waypoint design-system components |
| `convert-figma-mockup-to-code` | Figma URL → Waypoint HTML via internal API |
| `convert-waypoint-builder-to-code` | Waypoint Builder prototype → framework code |
| `fetch-waypoint-reference-image` | Fetch Waypoint component/pattern reference images |
| `screenshot-to-code` | Identify codebase/team/repo from UI screenshots |
| `mfe-translations` | i18n translations scaffolding for Stencil MFEs |
| `lifion-mfe-tools` | Lifion/ADP MFE deployment status & version checks |

**Lyric / payroll platform (4)**

| Skill | One-line |
|---|---|
| `lyric-mdo-design` | Design docs / functional requirements from a Lyric MDO |
| `lyric-tile-to-mcp` | Generate MCP tools from a Lyric tile MDO |
| `lyric-tile-to-mfe-requirements` | Stencil MFE requirements from a Lyric tile |
| `logiflow-execution-analysis` | Lyric logiflow execution debug reports |

**Agent-creation / NAS (2)**

| Skill | One-line |
|---|---|
| `create-nas-agent` | Create NAS LangChain agents with MCP tools |
| `nas-create-strands-agent` | Create NAS Strands agents with MCP tools |

**Deploy / infra / onboarding (3)**

| Skill | One-line |
|---|---|
| `helm-chart-generator` | Helm charts for MFE / backend microservices |
| `release-services-onboarding` | Onboard MFE/microservices to Lifion release pipeline |
| `ui-web-api-gateway-routing` | Routing config for `ui-web-api-gateway` |

**Shared library (1, not user-invocable)**

| Skill | One-line |
|---|---|
| `adp-developer-shared` | Shared utilities (Bitbucket client, config, YAML) for other skills |

---

## 2. OpenADP Agentic Platform plugin skills [Installable]

From `aidlc/wiki/06-install-adp-skills.md` (the "Complete Skills Reference"). Install via the OpenADP npm registry:

```bash
npx @openadp/openadp-agentic-platform \
  --install-plugins=adp-developer,documentation,a11y-toolkit,lifion,atlassian
```

**Plugins (5) + `hx-skills`:** `adp-developer`, `documentation`, `a11y-toolkit`, `lifion`, `atlassian`; `hx-skills` is added separately via `@adphx/hx-skills`.

**~22 `plugin:skill` entries documented:**

| Plugin | Skills |
|---|---|
| `atlassian` | `jira-tools`, `bitbucket-tools`, `confluence-tools`, `code-review`, `zephyr-test-generator`, `create-test-workflow`, `create-zephyr-tests`, `create-test-cycle` |
| `adp-developer` | `test-writer`, `code-documenter`, `code-reviewer`, `api-designer`, `security-reviewer`, `code-upgrader`, `tech-debt-analyzer` |
| `documentation` | `document-writer` |
| `a11y-toolkit` | `a11y-fundamentals`, `angular-a11y`, `react-a11y` ⚑, `stencil-a11y` ⚑ |
| `hx-skills` | `use-waypoint-components`, `convert-figma-mockup-to-code` |

⚑ `react-a11y` and `stencil-a11y` are **catalog-only** — they are documented in the plugin catalog but are **not** part of the local `~/.copilot/skills/` install on this machine.

**Additional installable tooling (same wiki):**

- `graphify` (pip `graphifyy`) — codebase knowledge-graph for AI navigation (`graphify {kiro|copilot|claude} install`).
- `@nas/aidlc-workflows` — AI-DLC rule/workflow pack (`@nas/aidlc-workflows add --agent {kiro|claude}`, lifion-npm).

---

## 3. Confluence skill catalogs & marketplaces [Org-documented]

### Lyric "GEN AI: Agents and Skills" catalog — 7 skills (LYBR/4173077895)

Marketplace: `skills.lifion.oneadp.com/skills/marketplace/<x>`.

| Skill | One-line | Status |
|---|---|---|
| `dts-check-diff` | Compare live entitycache PROD vs APPBUILD (tables/schema/fields) | Available |
| `tables-for-views` | Inventory v1/v2 view→table dependencies to Excel | Coming Soon |
| `lyric-reporting-documentation` | Documentation aggregator / onboarding | Coming Soon |
| `ldm-to-rcm-converter` | Convert LDM views to RCM copiedObjects via API | Available |
| `reporting-query` | Generate Oracle SQL to explore GHCM V1/V2 catalog | Available |
| `lra-ad-hoc-jira-ticket` | Create ad-hoc Jira tickets for LRA teams | Available |
| `capability-demo-checklist` | Build feature-completion demo checklists from Jira | Available |

### Sora Claude Skill Catalog — ~60 skills by plugin (SORAADP/4152264694)

Claude Code plugins expose slash-command skills. Notable plugin groupings:

- `investigation`: `/investigate`, `/scope-check`, `/trace-flow`, `/deep-dive`, `/diagnose-sora-permissions`
- `jira-sora`: `/jira` (+ query/list/create/comment/assign/transition), `/bitbucket-*` (PR/diff/builds/files/read/create), `/jenkins-*`, `/genai-start-work|finish-work|review-pr`
- `rfc`: `/write-rfc`, `/architecture-proposal`, `/rfc-to-tickets`, `/review-rfc`, `/finalize-rfc`, `/post-rfc`
- `review-pr`: `/review-pr`, `/address-pr-feedback`, `/create-frontend-pr`
- `test-automation` / `testing`: `/write-automation-test`, `/audit-test-coverage`, `/capture-test-screenshots`, `/test-plan`
- `ticket-lane` / `triage`: `/ai-readiness-check`, `/remote-implement`, `/screenshot-verify`, `/triage-tickets`
- `ai-first-guardrails`: `/validate-change`, `/audit-change-scope` *(deprecated)*
- others: `code-quality`, `estimation`, `i18n`, `metrics`, `post-doc`, `project-management`, `project-retro`, `setup-project`, `sprint-planner`, `marketplace-admin`

### pm-po-ops plugin — 81 skills (RDBX/3907623183)

Groupings (representative skills, not exhaustive):

- **Discovery:** `guided-discovery`, `discovery-lite`, `define-outcome`, `experience-mapping`, `opportunity-prioritization`, `discover-solutions`, `solution-prototype`, `solution-validation`, `mural-tools`
- **Spec authoring:** `capability-spec`, `feature-spec`, `maintenance-spec`, `pod-spec`, `spec-quality-gate`, `spec-agent`, `decision-log`
- **Market / CI / VoC:** `voc-pipeline`, `adp-market-context`, `ci-management`, `dovetail-research`, `pendo-client-profile`, `myadp-engagement-trends`
- **GTM / portfolio:** `gtm-evaluation`, `feature-readiness`, `ai-po`, `roadmap-builder`, `pod-charter`, `quarterly-assessment`
- **~40 team `*-tpo` skills:** `tpo`, `avengers-tpo`, `glue-tpo`, `pegasus-tpo`, `phoenix-tpo`, `vanguard-tpo`, etc., plus `webex-tools`, `strategy-red-team`, `pre-mortem`, `deck-review`, `stakeholder-management`

### Marketplaces & notable individually-documented skills

| Item | Space / pageId | One-line |
|---|---|---|
| Lyric Skills Marketplace | OTD/3928591239, M2/3938326382 | Next.js app to publish/discover/install AI skills; `/skills/plugin` for Claude Code |
| Adding Lyric Skills Marketplace to Claude Code & Copilot | OTD/3875485452 | Install steps + marketplace git URL |
| PM Skills Marketplace (Overview & Install) | CSPRODOP/4104728636 | PM skills marketplace install guide |
| Recipe Builder — Copilot Skill | (patelm8)/4053338435 | Individually-documented Copilot skill |
| Prompt Engineering Helper — Copilot Skill | (patelm8)/4049805599 | Individually-documented Copilot skill |
| MFE Feature Tests Skill for Claude Code | TMS/4152430921 | MFE feature-test generation |
| IaC Generation Skill | ND/4091643088 | Infrastructure-as-code generation |
| Key Facts Implementer - AI Skill | SBS/4172910648 | Key-facts implementation skill |
| ADA (ADP Discovery Agent) - Implementation Skill | (gangireu)/4152436274 | ADA implementation companion skill |
| Ops AIDLC - Skills - Phase 1 | ND/4069140406 | Ops AI-DLC phase-1 skills |
| WFS Agent Skills | WFS/4173076425 | Workforce Software agent skills |

*…and others documented individually:* `LRE Test Results / Test Execution` (ralencar/3907631689, 3907631690) · `QA FAQ Claude Skill` (SP/4035838573, RDBX/3947365834) · `DTB Inbound Generator Skill` (EDB/4172909602) · openadp-observability skills `pendo-tools` / `analytics-service-analysis` / `analytics-spec-story` / `powerpoint-tools` (RDBX/3976565189, 3982098989, 3979514042, 3976565193).

### AI-DLC Ops / Infra skills [Org-documented]

From `aidlc/wiki/26-ops-infra-skills.md`; invoked via AI-DLC ops tooling (`security-tools`, `helm-tools`, `infra-tools`). The paired capacity **agents** are in §5.

| Skill | One-line |
|---|---|
| `Trivy Image Scan` | CVE/misconfig image scan (`security-tools trivy-scan`) — deprecating → Security Workbench |
| `Secrets Detection` | Hardcoded-secret scan (`security-tools secrets-scan`) |
| `Dockerfile Generation` | Generate Dockerfile at Construction · Infra Design |
| `IaC / Terraform` | Propose + generate Terraform modules after approval |
| `Slow Query Detection & Remediation` | Query-plan / index / partition tuning |
| `Observability Triage` | Lock/deadlock/replication-lag/connection-saturation triage |
| `Data Quality Checks` | Null/anomaly detection, schema validation |
| `Routing (farm / farmless)` | Capacity-aware routing recommendation |

*(Helm Chart Generator is the `lifion:helm-chart-generator` skill, listed in §1.)*

---

## 4. MCP servers

### 4a. GSO Approved MCP Servers [Org-documented]

Authoritative list "11.1 GSO Approved MCP Servers" (GPS/3604888497), in its three sections. Approval status noted where the source states it; ticket refs are `GENAI-*`.

**§ Developer coding-assistant (local, external / third-party)**

| Server | Owner / origin | Status |
|---|---|---|
| AWS MCP Servers | AWS/Amazon | Listed |
| Deque Axe MCP | Accessibility testing | POC (GENAI-4694) |
| Copilot Enterprise Memory MCP | Memory / knowledge-graph | Listed (GENAI-3763) |
| Atlassian Confluence Cloud Remote Rovo MCP | Atlassian | Listed (GENAI-4697) |
| Databricks MCP | Vector Search / Unity Catalog / Genie | Listed (GENAI-4229) |
| Dynatrace MCP | Observability | **Approved** remote (GENAI-4268) |
| Figma MCP | Code-from-design (min v0.6.3) | **Approved** (GENAI-3177) |
| GitHub MCP Server | `github/github-mcp-server` | Listed (GENAI-3331) |
| Grafana MCP Server | `grafana/mcp-grafana` | **Approved** remote (GENAI-4264) |
| Atlassian Jira Cloud Remote Rovo MCP | Atlassian | Listed (GENAI-4697) |
| Snyk MCP Server | Invoke Snyk scans | **Approved** (GENAI-3996) |
| Playwright MCP Server | `microsoft/playwright-mcp` | **Approved** (GENAI-3214/3749) |
| Waypoint MCP | ADP in-house, `SYNERG/waypoint-mcp-server` | ADP in-house (GENAI-3596) |
| MABL MCP | MABL testing | Listed (GENAI-4253) |
| basic memory MCP | Open source | Listed (GENAI-4103) |
| obsidian-mcp | Open source | Listed |
| Custom ADP MCP Servers | ADP (FastMCP SDK): Jira/Bitbucket/Confluence/Tempo/Postgres/Waypoint | ADP (GENAI-4512) |
| SAP ABAP MCP Server | SAP & AWS | POC |
| Splunk MCP Server | Splunk | Cancelled (GENAI-5303) |
| DBT MCP Server | dbt Labs | Listed (GENAI-5086) |
| Microsoft MCP for Enterprise | Microsoft | Listed (GENAI-5875) |
| SonarQube MCP Server | SonarSource | Listed (GENAI-6013) |

**§ Third-party used by products:** `Snyk SAW-MCP (DAST)` (GENAI-6136) · `Pendo MCP Server` · `mcp.gong.io`.

**§ ADP-developed:** `(ADP Assist) MCP Server` (exposes Time-Off etc.) · `NL2SQL` (Workforce Now) · `Custom AWS MCP Server` (Platform AIOps) · `PlatformAI MCP Server` · `PlatformAI Splunk MCP Local` · `Platform AI Dynatrace MCP Local` · `Databrick Custom MCP` (OneData) · `Marketplace MCP` · `AI Studio / ADP Spark MCP Servers` · `DevSecOps Workbench MCP Server` · `Custom Microsoft SharePoint MCP-FT`.

### 4b. Configured on this machine [Installed]

Only **one** client has MCP servers configured — **Kiro CLI (3 servers)** at `~/.kiro/settings/mcp.json` (`local-sources.md` §H). Each runs via `uv --directory /Users/mishrapr/GIT/pi_mcps/<dir> run src/server.py` (env key: `TOKEN`).

| Server | Directory |
|---|---|
| `adp-jira` | `pi_mcps/mcp-adp-jira` |
| `adp-confluence` | `pi_mcps/mcp-adp-confluence` |
| `adp-bitbucket` | `pi_mcps/mcp-adp-bitbucket` |

**No MCP servers are configured** for VS Code, Copilot CLI, Claude Code, or Amazon Q on this machine (Amazon Q's agent has an empty `mcpServers: {}`).

### 4c. Project MCP server suites [Installable / Org-documented]

**CP project — 9 servers** (`aidlc/wiki/16-mcp-integrations.md`; repo `cp/mcp-servers.git`, path `~/mcp-servers`, pipenv):

`Jira`, `Bitbucket`, `Confluence`, `Jenkins`, `Databricks`, `Tempo`, `AWS`, `PostgreSQL`, `Webex`. *(Wiki also lists Splunk/Vault/Zephyr Scale servers in the repo.)* The same wiki documents Amazon Q **saved prompts** `@reverse-engineer-ms-app` and `@dc-aidlc` (stored in `~/.aws/amazonq/prompts/`).

**PI project — 5 servers** (`aidlc/wiki/28-kiro-mcp-atlassian-setup.md`; repo `pi/pi_mcps.git`, path `~/GIT/pi_mcps`, uv):

`adp-jira`, `adp-confluence`, `adp-bitbucket`, `mcp-adp-tempo`, `mcp-adp-zephyr`.

**Registry & how-to:**

- **MCP Registry** service (ADPI/3963562627) — CRUD API for MCP servers+tools; deploys AWS Bedrock **AgentCore Gateways** + DynamoDB; DIT/FIT/IAT/PROD `adp-ai-hub` endpoints.
- **ADP AI - MCP Servers & Tools** how-to (ADPI/3963562623) — build MCP tools from OpenAPI specs (`tool-` header prefix) on the Bedrock AgentCore runtime.

### 4d. Other individually-documented MCP servers [Org-documented]

Additional MCP servers documented on their own Confluence pages (`confluence.md` §C):

| Server | Space/pageId | One-line |
|---|---|---|
| Analytics MCP Server | ADPI/3784770723 | Analytics MCP tech spec |
| Data Intelligence MCP Server | ADPI/3907523448 | Data Intelligence MCP API spec |
| axe MCP Server | Accessibility/3947376489 | Accessibility (axe) MCP server |
| Jira Cloud MCP Server Setup | ADPDPE/4152437048 | Jira Cloud MCP setup guide |
| MCP Core Payroll | MCPPM/2340333365 | Core payroll MCP |
| MCP Payroll Insights API | ADPI/4056584453 | Payroll insights MCP API |
| wfn-mcp-server | WFNOTG/3874732086 | Workforce Now MCP server |
| User Guardian MCP Server | iHCMHome/4142240345 | User Guardian MCP |
| Agentforce MCP Registry | ALD/4115738093 | Salesforce Agentforce MCP registry |
| Atlassian Local MCP Server (OSS) | RDBX/3457820519 | Open-source Atlassian local MCP |
| mcp-services-payroll-dashboard | M2/3955074530 | Payroll dashboard MCP services |
| aws-mcp-payroll-insights-web | M2/3954786164 | AWS MCP payroll-insights web |

*(The WFN Recruitment MCP tools catalog — TALACQ/4009692619, 27 tools — is documented but stored in a Confluence macro not machine-extracted this pass; see §9.)*

---

## 5. AI agents [Org-documented]

**PS GenAI Agents — 4 persona agents** (AWP/WP `WP/ps-genai-agents`, 3999563808): `PS Code Review Agent`, `PS Developer Agent`, `PS QA Agent`, `PS SRE Agent`.

**Sora (Claude Code) agents — 8** (SORAADP/4152264694): `commit-reviewer`, `migration-checker`, `pr-reviewer`, `pr-build-status-checker`, `sre-engineer`, `message-poster`, `historian`, `database-manager`.

**Discovery / Plan agents** (`aidlc/wiki/15-discovery-agent.md`): `Discovery Agent` (`/discovery`, NAS HX only; 29-dimension requirements → Jira doc), `Plan Agent` (codebase → Jira features/stories, stops for approval), plus deprecation agents (pod learning).

**Ops / Infra agents** (`aidlc/wiki/26-ops-infra-skills.md`): `Workload Profiling Agent`, `Kubernetes Capacity Planning Agent`, `Database Sizing Agent`, `Infrastructure Cost Estimation Agent`.

**Databricks agents** (root workspace files): cost-conscious platform-ops agent (`databricks.md`); workspace-ops agent for clusters/jobs/warehouses/pipelines/Unity Catalog via REST (`databricks-agent.md`).

**pm-po-ops agent** (RDBX/3907623183): `product-owner` (command `jira-groom-issue`).

**GitHub Copilot built-in agents** (M2/4015363147): `explore`, `task`, `general-purpose`, `code-review`, `research`, `rubber-duck`.

**Wiki-pipeline agents (this repo, `.kiro/agents/*.json`):** `navigator`, `ingestor`, `writer`, `auditor`, `librarian`, `researcher`, `advisor` (7 role-scoped nightly-pipeline agents).

**Notable individually-documented ADP agents:** `ADA — ADP Discovery Agent` (gangireu/4152436274) · `Lyra — Lyric Implementation & Resolution Assistant` (OTD/3947370206) · `Knowledge Agent (KEA)` (ADPI/4172809880) · `Data Analyst Agent — AI Observability` (ADPI/3963557195) · `Copilot Chat FAQ Agent` (TTA/4172812830) · `Helpdesk Knowledge Agent` (TTA/3875283330) · `Forge BMA Configurator Agent` (LDW/4173081197) · `Forge QA Validator Agent` (LDW/4172816698) · `User Guardian Agent` (iHCMHome/4142240067) · `Benefits Reconciliation Agent (AI-DLC)` (LIFBEN/4115439988) · `Benefits Advisor Agent` (WFNB/3885900476) · `Pay Profile Agent — SBE` (WFNOBT/4062021890) · `aca_assist_agent` (AHCS/4173367858) · `ADP Assist Genie Agent` (SBS/4173371660) · `Atlassian Robo` (SP/4049090544) · `Serverless Autodev` (GAISVC/4115444755) · `Temporal-based Agent on AI Platform` (DCL/4079330960) · `UDM Agent (Client 360)` (AVSSmart/4172912727) · `Vista AI-DLC — Agent & Skill Authoring` (PDD/4172910073).

**Agent registries / platforms:** `Agent Registry` (GPS/3805750306) · `AI Agent Ecosystem Architecture Overview` (ADPEA/3678050488) · `OpenADP Agentic Platform` (OPENADP/3745757086) · `NAS AI Agents — Architecture` (1NASEng/4172814887; manifest `LIFCICD/nas-agents-release-manifest`).

---

## 6. Underpinning platforms

| Platform | Source | One-line |
|---|---|---|
| Kiro CLI | MCPE/3745616529 | ADP coding-assistant CLI (formerly Amazon Q Developer) |
| AI Gateway | GAISVC / GIDM | Governed LLM access layer for ADP apps/agents |
| AWS Bedrock AgentCore | GSOCSA/3550719567 | Runtime + gateways hosting ADP MCP tools/agents |
| ADP Spark / AI Studio | ADPI/3724067133 | ADP GenAI platform (Spark) / agent & prompt studio |
| OpenADP Agentic Platform | OPENADP/3745757086 | Plugin/skill distribution + agentic platform |
| Strands + MCP agent framework | `project-context.md` (AWS wiki `05-agent-framework-strands-mcp.md`) | Strands agentic loop + MCP Apps + OPA hooks |

---

## 7. ADP standardized prompts (prompt-fetcher) [Installable]

Repo coordinates (`local-sources.md` §J): Bitbucket project **AGR**, repo **`genai-adp-prompts`**, branch `main` (overridable via `OAP_PROMPTS_*` / `~/.oap.json`). Auth: `OAP_BITBUCKET_TOKEN`.

- **Categories (10)** — language-agnostic: `accessibility`, `database-optimization`, `ui-automation-testing`, `container-security`, `quality-assurance`, `code-review`, `project-management`, `business-analysis`, `general-best-practices`, `openadp`.
- **Technologies (7):** `java-springboot`, `python`, `typescript`, `angular`, `javascript`, `dotnet`, `graphql`.
- **Tasks (7):** `testing`, `documentation`, `code-review`, `api-design`, `security`, `upgrading`, `technical-debt`.

---

## 8. Sources & references

**Key Confluence catalog / registry pages** (`confluence.md` §E):

| pageId | Space | Title |
|---|---|---|
| 3604888497 | GPS | 11.1 GSO Approved MCP Servers (authoritative) |
| 3963562627 | ADPI | MCP Registry (service + DIT/FIT/IAT/PROD endpoints) |
| 3963562623 | ADPI | ADP AI - MCP Servers & Tools (build tools from OpenAPI) |
| 4173077895 | LYBR | GEN AI: Agents and Skills catalog (7 Lyric skills) |
| 4152264694 | SORAADP | Sora Claude Skill Catalog (~60 skills + 8 agents) |
| 3907623183 | RDBX | pm-po-ops Plugin — Skills Guide (81 skills + `product-owner`) |
| 3999563808 | AWP/WP | PS GenAI Agents — Catalog & Quick Start (4 agents) |
| 3928591239 / 3938326382 | OTD / M2 | Lyric Skills Marketplace |
| 3875485452 | OTD | Adding Lyric Skills Marketplace to Claude Code & Copilot |
| 4104728636 | CSPRODOP | PM Skills Marketplace — Overview & Install |
| 4142241523 | DDS | Approved AI Tools — Kiro, MCP, Connectors |
| 4009692619 | TALACQ | WFN Recruitment MCP — Tools Catalog (27 tools) |
| 3805750306 | GPS | 10.11 — Agent Registry |
| 3678050488 | ADPEA | AI Agent Ecosystem Architecture Overview |
| 3745757086 | OPENADP | OpenADP Agentic Platform |
| 4172814887 | 1NASEng | NAS AI Agents — Architecture |
| 3947369968 | RDBX | pm-po-ops Taxonomy and Roadmap |
| 4115738093 | ALD | Agentforce MCP Registry |
| 4025124261 | MCPE | MCP Service Integrations (index) |

**Workspace wiki / file paths used** (`local-sources.md` §G–K):

- [aidlc/wiki/06-install-adp-skills.md](../aidlc/wiki/06-install-adp-skills.md) — OpenADP plugin skills catalog
- [aidlc/wiki/16-mcp-integrations.md](../aidlc/wiki/16-mcp-integrations.md) — CP-project MCP servers
- [aidlc/wiki/28-kiro-mcp-atlassian-setup.md](../aidlc/wiki/28-kiro-mcp-atlassian-setup.md) — PI-project MCP servers
- [aidlc/wiki/15-discovery-agent.md](../aidlc/wiki/15-discovery-agent.md) — Discovery / Plan agents
- [aidlc/wiki/26-ops-infra-skills.md](../aidlc/wiki/26-ops-infra-skills.md) — Ops/Infra skills & agents
- [databricks.md](../databricks.md), [databricks-agent.md](../databricks-agent.md) — Databricks agents
- [project-context.md](../project-context.md), [spark_AIDLC_template.md](../spark_AIDLC_template.md) — Strands+MCP framework
- Local install dirs: `~/.copilot/skills/` (45), `~/.kiro/settings/mcp.json` (3 servers)

---

## 9. Caveats / gaps

- **Space scope:** `list_spaces` was token-scoped to **50** spaces (`isLastPage=true`); search surfaced many additional AI/dev spaces, so the broader org catalog is larger than any single enumeration here (`confluence.md` §A).
- **prompt-fetcher listing:** `--list-all` fails locally because `js-yaml` is not installed under `~/.copilot/skills/adp-developer-shared` — category/tech/task lists come from the shipped script constants, not a live Bitbucket enumeration (`local-sources.md` §J–K).
- **WFN Recruitment MCP catalog:** its 27 tools live inside a Confluence markdown macro and were **not** machine-extracted this pass (TALACQ/4009692619; `confluence.md` §C/§F).
- **Catalog drift:** ADP skill/MCP/agent catalogs evolve; page IDs and counts reflect the two dated research passes and should be re-fetched before relying on exact totals.

*Compiled 2026-08-14 from Confluence + local sources.*
