# ADP Spark (ADPI) Documentation Ecosystem — Comprehensive Analysis Report

**Date:** 2026-07-27 | **Author:** Synthesizer Agent  
**Scope:** ADPI, Data, cdomlops, DMTeam, ADPDPE + Local Wikis  
**Audience:** Sr. Software Engineers building LLM applications on Databricks at ADP

---

## 1. EXECUTIVE SUMMARY

### Overall State

The ADP documentation ecosystem for LLM engineers is **functionally adequate but dangerously stale in critical areas**. The local wiki system (`databricks-guidelines/` and `databricks/wiki/`) provides a well-structured onboarding path covering 80% of what a new engineer needs. However, three critical failures — retired models listed as available, two undifferentiated AI Gateway systems, and missing production model lists — actively block engineers and cause wasted engineering time.

The governance process (GAIN) is well-documented procedurally but suffers from a form/catalog mismatch that adds weeks to approval cycles. The Confluence source pages span 8 spaces with no single owner, creating consistency drift that compounds monthly.

### Key Findings

1. **🚨 ACTIVE PRODUCTION RISK:** 4 retired LLM models (Claude 3 Haiku, Llama 3.2, Claude Haiku 4.5, o3-mini) are still listed as available in both local wiki and Confluence. Engineers following docs get cryptic 404 errors.

2. **🚨 ARCHITECTURAL CONFUSION:** Two completely separate AI Gateway systems exist (Databricks AIGW for notebooks/pipelines vs AWS Agent AIGW for MCP/Strands agents) with zero documentation explaining which to use when.

3. **🚨 NO PRODUCTION MODEL LIST:** The entire AIGW catalog (65+ routes) is labeled "US Non-Prod" only. No Production or EU region model list exists anywhere.

4. **🔴 GOVERNANCE FORM MISMATCH:** The GAIN form dropdown lists Claude 2/3 and GPT-3.5/4.x while the actual AIGW offers Claude 4.x-4.7 and GPT-5.x. Engineers cannot select their actual model.

5. **🟡 73% OF AWS WIKI IS EMPTY:** 11 of 15 AWS wiki pages are stubs marked "Awaiting Ingestion," leaving engineers without local reference for AWS-based LLM patterns.

### Recommended Immediate Actions (This Week)

| # | Action | Effort | Impact |
|---|--------|--------|--------|
| 1 | Remove retired models from `databricks-guidelines/06-model-serving-and-aigw.md` | 30 min | Stops failed API calls |
| 2 | Add "⚠️ o3-mini retiring 2026-08-02" banner | 5 min | Prevents imminent breakage |
| 3 | Create decision guide: "Which AI Gateway?" | 2 hours | Prevents wrong architecture |
| 4 | Request Production model list from DMTeam (Li, Zhilin) | 1 hour | Unblocks prod deployments |
| 5 | Add known-gap note to `guidelines/09` about governance form dropdown | 15 min | Sets expectations |

---

## 2. INVENTORY OF KEY RESOURCES

### 2.1 Critical Confluence Pages

| Page ID | Title | Space | Topic | Freshness |
|---------|-------|-------|-------|-----------|
| 3955721922 | GenAI Use Case Governance for AI Studio | ADPI | GAIN process, compliance gates | Active but form outdated |
| 4024471302 | Available AIGW Models (cdo-oneai-qum) | DMTeam | Model catalog (Non-Prod only) | ⚠️ Contains retired models |
| 3260589876 | OneData Onboarding | Data | Platform onboarding | Current |
| 2332667275 | Group Configuration | cdomlops | Databricks group setup | 11 months old |
| 3580930544 | Unity Catalog Model Registration | cdomlops | UC model registration flow | 11 months old |
| 3341781734 | UC Model Promotion/Demotion Self Service | cdomlops | Model lifecycle | Current |
| 3197965047 | Permissions needed & Tags | cdomlops | Mandatory model tags | Current |
| 3261277147 | Databricks model serving | cdomlops | Serving endpoints | ⚠️ 16 months old, nearly empty |
| 2626851511 | Embedding Model API (OneAI Internal) | cdomlops | Legacy embedding service | ⚠️ Registration struck through |
| 3604718156 | Databricks Secrets | DMTeam | Secret scope management | Current |
| 4060157018 | Databricks SP Token Creation | ADPDPE | Service principal tokens | Current |
| 3591050035 | Project Template V2 | cdomlops | DABs project structure | Current |
| 3848802744 | DABs PROS & CONS for EC360 | OCV | DABs evaluation | Current |
| 3755720594 | Comprehensive Arize Onboarding | cdomlops | ML/LLM observability | Current |
| 3963557191 | Data Analyst Agent - Evaluation Metrics | ADPI | LLM eval metrics | Current |
| 4059704161 | Genie AI Interaction Details | Data | Genie MCP | Fresh (Jun 2026) |
| 4091811288 | Databricks Genie MCP Testing Guide | Data | Genie testing | Fresh (Jun 2026) |
| 4079853962 | AIDLC and Kiro CLI | ADPDPE | Development lifecycle | Fresh (Jun 2026) |
| 3171550398 | Workspace & Environment | Data | Workspace topology | Current |
| 2332667363 | Create Cluster | cdomlops | Cluster creation steps | Current |
| 3481737621 | Databricks Workspaces | OCV | Workspace reference | Current |
| 4077322587 | Pause/Unpause Scheduled Databricks Jobs | OCV | Job management | Current |
| 3269202313 | Cloud Security Credential setup | cdomlops | CSC for AWS services | Current |

### 2.2 Local Wiki Files — Coverage Matrix

#### `databricks-guidelines/` (Playbook — "How do I do X?")

| File | Topic | Coverage | Issues |
|------|-------|----------|--------|
| 00-index.md | Master navigation | ✅ Complete | None |
| 01-onboarding-and-access.md | Team provisioning, entitlements | ✅ Complete | None |
| 02-workspaces-and-clusters.md | URLs, compute options, runtimes | ✅ Complete | URL inconsistency with project-context |
| 03-project-setup-and-dabs.md | Repo structure, databricks.yml | ✅ Complete | None |
| 04-secrets-and-security.md | Scopes, CSC, SP tokens, OAuth | ✅ Complete | None |
| 05-unity-catalog-and-models.md | Registration, tags, promotion | ✅ Complete | None |
| 06-model-serving-and-aigw.md | AIGW, serving, embeddings | ⚠️ CRITICAL | Retired models, no decision guide |
| 07-cicd-pipeline.md | Jenkins, DABs deploy | ✅ Complete | None |
| 08-monitoring-and-arize.md | Arize, LLM tracing | ✅ Complete | Missing eval framework detail |
| 09-genai-governance-gain.md | GAIN process, compliance | ✅ Complete | Missing Genie governance, form gap note |
| 10-reference-and-troubleshooting.md | FAQ, InnerSpace tools | ✅ Complete | None |

#### `databricks/wiki/` (Reference — "What is X?")

| File | Topic | Coverage | Issues |
|------|-------|----------|--------|
| 00-index.md | Master index | ✅ Complete | Missing page 23 |
| 01-what-is-databricks.md | Platform overview | ✅ Complete | None |
| 02-workspace-architecture.md | Workspace layout, catalogs | ✅ Complete | None |
| 03-access-and-setup.md | Access, CLI, auth | ✅ Complete | None |
| 04-cli-and-tokens.md | CLI commands, SP auth | ✅ Complete | None |
| 05-unity-catalog.md | UC governance deep-dive | ✅ Complete | None |
| 06-delta-lake.md | Delta format, operations | ✅ Complete | None |
| 07-compute-and-clusters.md | Sizing, policies, Photon | ✅ Complete | None |
| 08-databricks-asset-bundles.md | DABs mechanics | ✅ Complete | None |
| 09-dlt-pipelines.md | DLT/Lakeflow patterns | ✅ Complete | None |
| 10-jobs-and-workflows.md | Job orchestration | ✅ Complete | None |
| 11-dlt-operations-validation.md | Quality gates for DLT | ✅ Complete | None |
| 13-cost-management.md | DBU tracking, optimization | ✅ Complete | None |
| 20-troubleshooting.md | Error reference | ✅ Complete | None |
| 22-vscode-databricks-setup.md | Local dev with VSCode | ✅ Complete | ⚠️ Broken link to page 23 |

#### `aws/wiki/` (AWS LLM Patterns)

| File | Topic | Coverage | Issues |
|------|-------|----------|--------|
| 00-index.md | Navigation | ✅ Complete | None |
| 01-getting-aws-access.md | SSO, switch roles | ✅ Complete | None |
| 02-ai-gateway-bedrock.md | AWS AIGW + Bedrock | ❌ STUB | "Awaiting Ingestion" |
| 03-deployment-environments.md | DIT→FIT→IAT→Prod | ❌ STUB | "Awaiting Ingestion" |
| 04-agent-development-lifecycle.md | AIDLC, Kiro, Strands | ✅ Complete | None |
| 05-adp-ai-studio.md | Agent hosting | ❌ STUB | "Awaiting Ingestion" |
| 06-cicd-flexible-ci.md | Jenkins CI | ❌ STUB | "Awaiting Ingestion" |
| 07-eks-container-patterns.md | EKS, Helm | ❌ STUB | "Awaiting Ingestion" |
| 08-model-registration-serving.md | UC + SageMaker | ❌ STUB | "Awaiting Ingestion" |
| 09-observability-arize.md | Arize + OTel | ❌ STUB | "Awaiting Ingestion" |
| 10-data-patterns-s3-sqs.md | S3, SQS, DynamoDB | ❌ STUB | "Awaiting Ingestion" |
| 11-gso-approvals-compliance.md | GSO/CDO approval | ❌ STUB | "Awaiting Ingestion" |
| 12-architecture-decisions.md | ADRs | ❌ STUB | "Awaiting Ingestion" |
| 13-cost-tagging.md | Mandatory tags | ❌ STUB | "Awaiting Ingestion" |
| 14-troubleshooting.md | Error reference | ❌ STUB | "Awaiting Ingestion" |
| 15-reference-links.md | All URLs, page IDs | ✅ Complete | None |


### 2.3 Cross-Reference Matrix

| Topic | Confluence Source | Local Wiki (guidelines) | Local Wiki (databricks) | Local Wiki (aws) | Status |
|-------|------------------|------------------------|------------------------|-----------------|--------|
| Onboarding | Data/3260589876, cdomlops/2332667275 | 01 ✅ | 03 ✅ | 01 ✅ | ✅ Consistent |
| Workspaces | Data/3171550398, OCV/3481737621 | 02 ✅ | 02 ✅ | — | ⚠️ URL mismatch |
| Clusters | cdomlops/2332667363 | 02 ✅ | 07 ✅ | — | ✅ Consistent |
| Secrets | DMTeam/3604718156, Data/2841290029 | 04 ✅ | 04 ✅ | — | ✅ Consistent |
| Unity Catalog | cdomlops/3580930544, 3341781734, 3197965047 | 05 ✅ | 05 ✅ | 08 (stub) | ✅ Consistent |
| AIGW (Databricks) | DMTeam/4024471302 | 06 ⚠️ | — | — | 🚨 Retired models |
| AIGW (AWS/Bedrock) | LDW/4086465110 | — | — | 02 (stub) | 🚨 Not documented |
| Model Serving | cdomlops/3261277147 | 06 ✅ | — | 08 (stub) | ⚠️ Source page empty |
| CI/CD | cdomlops/3305548823, LDW/4069589173 | 07 ✅ | 08 ✅ | 06 (stub) | ✅ Consistent |
| Arize/Monitoring | cdomlops/3755720594 | 08 ✅ | — | 09 (stub) | ✅ Consistent |
| Governance (GAIN) | ADPI/3955721922 | 09 ✅ | — | 11 (stub) | ⚠️ Form outdated |
| Genie MCP | Data/4059704161, Data/4091811288 | — | — | — | ❌ Not in local wiki |
| RAG Patterns | — | — | — | — | ❌ Does not exist |
| Cost/Budgeting | OCV/3560462267 | — | 13 ✅ | 13 (stub) | ⚠️ No LLM cost info |
| DABs | OCV/3848802744, cdomlops/3591050035 | 03 ✅ | 08 ✅ | — | ✅ Consistent |
| Embeddings | cdomlops/2626851511 | 06 (partial) | — | — | ⚠️ 3 paths, no guide |
| AIGUARD | ADPI (referenced in GAIN) | 09 (process only) | — | — | ⚠️ No implementation guide |
| Job Scheduling | OCV/4077322587 | — | 10 ✅ | — | ⚠️ Pause/unpause not in guidelines |

---

## 3. GAP ANALYSIS

### 3.1 What's Well Documented ✅

| Area | Quality | Notes |
|------|---------|-------|
| **Onboarding flow** | Excellent | Step-by-step with URLs, timelines, contacts |
| **Unity Catalog model lifecycle** | Excellent | Registration, tags, promotion, batch inference all covered |
| **Secrets management** | Excellent | Scopes, CSC, OAuth, SP tokens with code examples |
| **DABs project setup** | Excellent | Template repo, YAML examples, branching strategy |
| **GAIN governance process** | Good | Full lifecycle, portals, timelines, tips |
| **Arize observability** | Good | ML + LLM tracing, code examples, monitors |
| **CI/CD pipeline** | Good | Jenkins automation, merge-to-master trigger |
| **Workspace topology** | Good | URLs by region/env, compute options, runtime selection |
| **DLT/Lakeflow pipelines** | Excellent | CDC, expectations, medallion architecture |
| **AIDLC methodology** | Good | Phases, quality gates, Kiro CLI setup |

### 3.2 What's Missing ❌

| Gap | Impact | Who Needs It | Suggested Location |
|-----|--------|-------------|-------------------|
| **"Which AI Gateway?" decision guide** | CRITICAL — wrong architecture choice | Every new LLM engineer | New page or section in guidelines/06 |
| **Production AIGW model list** | CRITICAL — can't confirm prod works | Anyone deploying to GA | guidelines/06 + Confluence DMTeam |
| **RAG implementation patterns** | HIGH — approved use case, no guide | RAG-approved teams | New guidelines page or section in 06 |
| **Genie MCP in local wiki** | MEDIUM — powerful tool undiscoverable | Data teams | New guidelines page |
| **LLM cost estimation** | MEDIUM — can't budget | Project leads, architects | guidelines/06 or new cost page |
| **AIGUARD implementation guide** | MEDIUM — process known, code unknown | Internal Build teams | Section in guidelines/09 |
| **LLM evaluation framework** | MEDIUM — only passing reference | ML engineers | Section in guidelines/08 |
| **Embedding path decision guide** | HIGH — 3 options, no guidance | Anyone needing embeddings | Decision box in guidelines/06 |
| **Genie governance path** | HIGH — security risk | Genie adopters | Section in guidelines/09 |
| **EU region model availability** | MEDIUM — EU teams blocked | EU-based teams | Table in guidelines/06 |

### 3.3 What's Outdated 🕐

| Content | Location | Age | Issue |
|---------|----------|-----|-------|
| Claude 3 Haiku listed as available | guidelines/06, DMTeam/4024471302 | Retired 2026-06-10 | 47 days stale |
| Llama 3.2 (1B/3B/11B) listed | guidelines/06 | Retired 2026-04-07 | 111 days stale |
| Claude Haiku 4.5 listed | guidelines/06 | Retired 2026-07-14 | 13 days stale |
| o3-mini listed without retirement warning | guidelines/06 | Retiring 2026-08-02 | 6 days until breakage |
| GAIN form Q13 LLM dropdown | ADPI/3955721922 | Lists Claude 2/3, GPT-3.5/4.x | Months behind catalog |
| Databricks model serving page | cdomlops/3261277147 | 16 months old | Nearly empty redirect |
| Embedding Model API registration | cdomlops/2626851511 | 6 months, struck through | Possibly deprecated |
| `model_type: "embedding_model"` workaround | guidelines/06, cdomlops/3261277147 | 16 months as "temporary" | No tracking/resolution info |

### 3.4 What's Inconsistent ⚡

| Inconsistency | Source A | Source B | Impact |
|---------------|----------|----------|--------|
| Workspace URLs | guidelines/02 lists DIT/FIT/IAT/UAT/PROD/Sidecar/CA/EU | project-context.md lists only DEV/FIT/PROD (US+EU) | Engineers unsure which is canonical |
| PROD URL | `adpdc-onedata-share1-prod-us-east` (guidelines/02) | `adpdc-share1-prod` (project-context) | May be different workspaces or alias |
| AIGW = "only sanctioned path" | aws/wiki/02 says AIGW is THE ONLY path | guidelines/06 describes Databricks AIGW (different system) | Two "only" paths exist |
| Onboarding SSO | aws/wiki/01 says "SSO via Okta" | databricks/wiki/03 says "SSO via Okta" | guidelines/01 says "Azure AD (NOT email)" — unclear if same |
| File numbering | guidelines/ has 01-10 onboarding series | guidelines/ ALSO has 01-05 AIDLC series | Duplicate numbers cause confusion |


---

## 4. PRIORITIZED UPDATE RECOMMENDATIONS

### 4.1 🚨 CRITICAL (Blocks engineers — fix this week)

| # | Issue | Location | Action | Owner | Effort |
|---|-------|----------|--------|-------|--------|
| C1 | Retired models listed as available | `databricks-guidelines/06-model-serving-and-aigw.md` | Remove Claude 3 Haiku, Llama 3.2 (1B/3B/11B), Claude Haiku 4.5. Add deprecation banner for o3-mini (retiring 2026-08-02). Add `last-verified` date to model list. | Wiki maintainer | 30 min |
| C2 | Two AIGW systems, zero explanation | No page exists | Create "Which AI Gateway?" decision page comparing Databricks AIGW (REST/OAuth, 50+ models, notebooks/pipelines) vs AWS Agent AIGW (@adp/agent-sdk, Bedrock Claude, MCP/Strands agents) | Wiki maintainer | 2 hours |
| C3 | No Production model list | DMTeam/4024471302 + guidelines/06 | Escalate to Li, Zhilin (DMTeam) to provide Prod + EU model lists. Add env comparison table to guidelines/06. | Escalate to DMTeam | 1 hour (request) |

### 4.2 🔴 HIGH (Causes confusion or security issues — fix within 2 weeks)

| # | Issue | Location | Action | Owner | Effort |
|---|-------|----------|--------|-------|--------|
| H1 | Governance form LLM dropdown outdated | ADPI/3955721922 (Form 1, Q13) + guidelines/09 | Add note to guidelines/09: "Known issue: GAIN form dropdown does not list latest models. Select closest match or contact CDO team." Request form update from GAIN admin. | Wiki maintainer + GAIN admin | 30 min |
| H2 | Genie MCP governance gap | guidelines/09 | Add section: "Genie & MCP Governance" explaining that Genie bypasses AIGW, GENAI-4229 is POC-only, and MCP "on behalf of" creates PII risk. No approved prod path exists yet. | Wiki maintainer | 1 hour |
| H3 | Embedding fragmentation — 3 paths | guidelines/06 | Add decision box: "Legacy OneAI API (deprecated?) → AIGW embeddings (recommended for new projects) → Databricks-hosted bge-large-en (UC serving)." Mark legacy API status clearly. | Wiki maintainer | 30 min |
| H4 | Broken navigation link (page 22→23) | `databricks/wiki/22-vscode-databricks-setup.md` | Either create `23-ai-gateway-integration.md` with content from guidelines/06, OR change link to point to `../databricks-guidelines/06-model-serving-and-aigw.md` | Wiki maintainer | 15 min |
| H5 | `model_type: "embedding_model"` workaround undocumented risk | guidelines/06 | Add context box: "This is a platform validation workaround (tracked since Mar 2025). Required for all model types as of Jul 2026. If platform fixes this, deployments using the workaround may need updates. Check with cdomlops team for status." | Wiki maintainer | 15 min |

### 4.3 🟡 MEDIUM (Missing helpful info — fix within 1 month)

| # | Issue | Location | Action | Owner | Effort |
|---|-------|----------|--------|-------|--------|
| M1 | AWS wiki 73% empty | `aws/wiki/` pages 02-13 | Prioritize ingesting: 02 (AIGW), 06 (CI), 08 (Model Serving), 09 (Arize), 11 (GSO). These are highest-value for LLM engineers. | Ingestion pipeline | 1 day per page |
| M2 | Duplicate page numbering | `databricks-guidelines/` | Rename AIDLC series with prefix: `aidlc-01-prerequisites.md`, `aidlc-02-project-init.md`, etc. Or move to subdirectory `databricks-guidelines/aidlc/` | Wiki maintainer | 1 hour |
| M3 | No RAG implementation guide | None exists | Create guide covering: Vector store selection (Databricks Vector Search vs external), chunking strategies, embedding→store→retrieval pipeline, AIGW integration for generation. | Sr. Engineer | 4 hours |
| M4 | Genie MCP not in local wiki | Data/4059704161, Data/4091811288 not ingested | Ingest both Confluence pages into `databricks-guidelines/` as new page (e.g., `11-genie-mcp.md`) | Ingestion pipeline | 2 hours |
| M5 | cdomlops space deprecation risk | 14+ source pages in cdomlops | Establish monthly freshness check. Snapshot critical pages. Consider migrating content to non-deprecated space or local wiki. | Wiki maintainer | Ongoing |
| M6 | Workspace URL inconsistency | guidelines/02 vs project-context.md | Verify with platform team: is `adpdc-share1-prod` an alias for `adpdc-onedata-share1-prod-us-east`? Standardize across all docs. | Platform team | 1 hour |
| M7 | No LLM cost estimation guidance | No page | Add section to guidelines/06 or create cost guide: per-model TPM limits, cost per 1K tokens (if available), guidance on requesting higher limits. | Sr. Engineer + DMTeam | 2 hours |

### 4.4 🟢 Nice-to-Have (Improve when time permits)

| # | Issue | Action | Effort |
|---|-------|--------|--------|
| L1 | Databricks model serving Confluence page nearly empty | Update cdomlops/3261277147 or add "this page is superseded by local wiki guidelines/06" banner | 15 min |
| L2 | LLM evaluation metrics not detailed in local wiki | Expand guidelines/08 with content from ADPI/3963557191 (golden-set scoring, hallucination checks) | 2 hours |
| L3 | Pause/Unpause jobs not in guidelines | Ingest OCV/4077322587 content into guidelines/10 or create operations section | 1 hour |
| L4 | No AIGUARD code implementation guide | Add section to guidelines/09 showing how to integrate guardrails in application code (RaaS config, prompt list format) | 3 hours |


---

## 5. SPECIFIC ACTION ITEMS

### Action Item 1: Remove Retired Models (30 min)
**File:** `databricks-guidelines/06-model-serving-and-aigw.md`  
**What to do:**
- DELETE from Anthropic table: `Claude 3 Haiku | anthropic-claude-3-haiku`
- DELETE from Meta Llama table: `Llama 3.2 | 1B, 3B, 11B`
- ADD to Anthropic table note: "Claude Haiku 4.5 — RETIRED 2026-07-14"
- ADD banner at top of AIGW section:
  ```
  > ⚠️ **Model Retirement Alert:** o3-mini is retiring 2026-08-02. 
  > Migrate to o3 or o4-mini before that date.
  > Last verified: 2026-07-27
  ```
- ADD `<!-- last-verified: 2026-07-27 -->` comment to model list section

---

### Action Item 2: Create "Which AI Gateway?" Decision Guide (2 hours)
**File:** Create `databricks-guidelines/12-which-ai-gateway.md` (or add as section to 06)  
**Suggested content:**

```markdown
## Which AI Gateway Should I Use?

| Question | Databricks AIGW | AWS Agent AIGW |
|----------|----------------|----------------|
| **What am I building?** | Notebooks, pipelines, batch jobs, model serving | MCP/Strands agentic applications |
| **SDK** | Raw REST + OAuth (`requests` library) | `@adp/agent-sdk` (handles auth automatically) |
| **Available models** | 50+ (Claude, GPT, Llama, Mistral, Qwen, Cohere, etc.) | Bedrock Claude only (Sonnet 4.6 confirmed) |
| **Authentication** | Azure AD client_credentials (manual token refresh every 30 min) | Azure AD (handled by SDK) |
| **Rate limit** | 50,000 TPM per route | Unknown (contact platform team) |
| **When to use** | You're in a Databricks notebook/job and need LLM access | You're building a Strands agent deployed to EKS |
| **Governance** | GAIN → AIGW onboarding | GAIN → AIGW onboarding (same process) |

### Decision Tree
- Building on **Databricks** (notebooks, jobs, DLT)? → **Databricks AIGW**
- Building a **Strands agent** (MCP tools, EKS deployment)? → **AWS Agent AIGW**
- Need **multi-model comparison** in one project? → **Databricks AIGW** (50+ models)
- Want **SDK-managed auth** (no token refresh)? → **AWS Agent AIGW**
```

---

### Action Item 3: Request Production Model List (1 hour)
**Who:** Escalate to Li, Zhilin (DMTeam)  
**Template message:**
> Subject: Production AIGW Model List Needed for Documentation
>
> The current AIGW model documentation (DMTeam/4024471302) only shows US Non-Prod routes. 
> Engineers cannot confirm production deployments will work.
>
> Request:
> 1. Full list of Production AIGW model routes (US)
> 2. EU region model availability (if different)
> 3. Confirmation: do Non-Prod routes map 1:1 to Prod?
> 4. Model retirement schedule (upcoming 90 days)

---

### Action Item 4: Add Governance Form Gap Note (15 min)
**File:** `databricks-guidelines/09-genai-governance-gain.md`  
**Where:** After "LLM selection (from approved list)" in Required Fields  
**Add:**
```markdown
> ⚠️ **Known Issue (as of Jul 2026):** The GAIN form dropdown (Q13) has not been 
> updated to reflect the current AIGW catalog. It still lists Claude 2/3 and GPT-3.5/4.x. 
> If your model (e.g., Claude Sonnet 4.6, GPT-5) is not in the dropdown, select the 
> closest available option and add a note in the description field specifying your actual 
> model. This is a known gap being tracked with the CDO team.
```

---

### Action Item 5: Fix Broken Link (15 min)
**File:** `databricks/wiki/22-vscode-databricks-setup.md`  
**Current:** `Next: [AI Gateway Integration →](23-ai-gateway-integration.md)`  
**Replace with:** `Next: [AI Gateway Integration →](../databricks-guidelines/06-model-serving-and-aigw.md)`  
**Also:** Update `00-index.md` to remove reference to non-existent page 23.

---

### Action Item 6: Add Embedding Decision Guide (30 min)
**File:** `databricks-guidelines/06-model-serving-and-aigw.md`  
**Where:** Before or replacing the "Embedding Model API (OneAI Internal)" section  
**Add:**
```markdown
## Choosing an Embedding Path

| Path | Models | Status | Use When |
|------|--------|--------|----------|
| **AIGW embedding routes** (recommended) | titan-embed-v1/v2, cohere-embed-v3, nova-2-multimodal, bge-large-en | ✅ Active | New projects. Full OAuth auth, same as LLM access. |
| **Databricks-hosted bge-large-en** | bge-large-en | ✅ Active | Need embeddings within Databricks serving endpoint. |
| **OneAI Embedding API (Legacy)** | 2 models only | ⚠️ Possibly deprecated (registration struck through) | Existing integrations only. Do NOT use for new projects. |

**For new projects:** Use AIGW embedding routes. Same auth pattern as LLM calls.
```

---

### Action Item 7: Add Genie MCP Governance Section (1 hour)
**File:** `databricks-guidelines/09-genai-governance-gain.md`  
**Where:** New section before "Source Pages"  
**Add:**
```markdown
## Genie & MCP Governance (Special Case)

### Key Differences from Standard GAIN Path
- Genie uses Databricks SaaS LLMs **directly** — it does NOT go through AI Gateway
- The standard GAIN flow (AIGW → AIGUARD) does not apply to Genie
- Genie MCP use case GENAI-4229 is **POC only** — NOT approved for Production

### Security Risks to Document
- MCP interactions execute **on behalf of the configuring account**
- This creates PII/PCI leakage risk if the account has broad data access
- No documented mitigation for this risk exists yet

### What to Do
1. If your use case involves Genie: flag it explicitly in GAIN submission
2. Do NOT assume standard governance path applies
3. Contact CDO team for Genie-specific governance guidance
4. Do NOT deploy Genie-based features to production without explicit written approval

**Source:** [Genie AI Interaction Details](https://confluence.es.ad.adp.com/spaces/Data/pages/4059704161) (Data space)
```

---

### Action Item 8: Rename AIDLC Duplicate Pages (1 hour)
**Current files in `databricks-guidelines/`:**
- `01-prerequisites-and-install.md` (AIDLC)
- `02-project-initialization.md` (AIDLC)
- `03-inception-phase.md` (AIDLC)
- `04-construction-phase.md` (AIDLC)
- `05-operations-and-quality-gates.md` (AIDLC)

**Rename to:**
- `aidlc-01-prerequisites-and-install.md`
- `aidlc-02-project-initialization.md`
- `aidlc-03-inception-phase.md`
- `aidlc-04-construction-phase.md`
- `aidlc-05-operations-and-quality-gates.md`

**Also:** Update any internal cross-references and add AIDLC section to `00-index.md`.


---

## 6. ONEDATA-SPECIFIC FINDINGS

### 6.1 OneData/Data Space Coverage Assessment

The **Data** Confluence space (OneData) is well-represented in the local wiki ecosystem for foundational topics but has emerging gaps in newer capabilities.

| Topic | Data Space Page | Local Wiki Coverage | Gap |
|-------|---------------|--------------------|----|
| OneData Onboarding | 3260589876 | guidelines/01 ✅ | None — well synthesized |
| Workspace & Environment | 3171550398 | guidelines/02 ✅ | Minor URL discrepancy |
| Scope and Tokens | 2841290029 | guidelines/04 ✅ | None |
| Genie AI Interaction Details | 4059704161 | ❌ NOT INGESTED | Fresh content (Jun 2026), high value |
| Genie MCP Testing Guide | 4091811288 | ❌ NOT INGESTED | Fresh content (Jun 2026), high value |

### 6.2 Workspace Access and Onboarding Gaps

**What works well:**
- `guidelines/01-onboarding-and-access.md` provides a complete 5-step provisioning flow
- Key contacts (AJ Sharma, Samir Khanal, Szabi Nagy) are documented
- Entitlements (Immuta, Alation) are listed with exact names
- Group naming convention is clear: `(business-unit)-(team)-(project/function)`

**Gaps identified:**

| Gap | Impact | Recommendation |
|-----|--------|---------------|
| No mention of SASE/SWG entitlement for Kiro CLI | Engineers can't use Kiro CLI from corporate network | Add `SASE_SWG_EXTERNAL_GBL_BU_CDO_GAIN_MULTI_GENAI_READONLY` to entitlements table in guidelines/01 |
| Default workspace assignment unclear | "scnext dev + scnext prod" — but guidelines/02 lists `share1-dev` URLs | Clarify: scnext = share1? Different name, same workspace? |
| EU onboarding path not detailed | EU engineers follow same steps? Different workspace URLs? | Add EU-specific notes to guidelines/01 (at minimum: confirm same process applies) |
| Time-to-access not validated | "~5 business days" in guidelines/01 — is this current? | Verify with recent onboardees. Add "Your mileage may vary" if inconsistent. |
| No "verify everything works" checklist | After onboarding, how do you confirm full access? | Add post-onboarding verification section (similar to databricks/wiki/03 Step 5) |

### 6.3 Cluster Configuration Gaps

**What works well:**
- `guidelines/02` documents 4 compute options (shared, serverless, personal via Jenkins, job clusters)
- `databricks/wiki/07` provides detailed sizing, policies, Photon guidance
- Runtime requirement (≥15.4 LTS for CSC) is prominently documented

**Gaps identified:**

| Gap | Impact | Recommendation |
|-----|--------|---------------|
| No GPU cluster guidance for LLM fine-tuning | Teams approved for fine-tuning have no cluster config reference | Add GPU instance types (p3, g5) and ML Runtime selection to guidelines/02 |
| No LLM-specific cluster sizing | How many workers for batch inference on 1M records? | Add "LLM workload sizing" section to guidelines/02 or databricks/wiki/07 |
| Serverless limitations not documented | "Best option for LLM development" but doesn't mention limitations (no custom libraries, no GPU) | Add caveats: serverless doesn't support custom Docker images, GPU workloads, or certain library versions |
| Cluster policy names not listed | Which policy should an LLM team attach to? | Document available policies by team type (data-engineering-standard, ml-training, etc.) |
| Cost comparison not actionable | databricks/wiki/07 shows DBU rates but no dollar estimates | Add approximate $/hour for common configurations (i3.xlarge × 4 workers ≈ $X/hr) |

### 6.4 OneData Platform Integration Points (Undocumented)

These are capabilities that exist in the Data space but have no representation in the LLM engineer's documentation:

1. **Immuta row/column security** — Mentioned in guidelines/00 overview but no guide on how LLM pipelines interact with Immuta-protected tables
2. **Alation data catalog** — Entitlement documented but no guidance on using Alation to discover training data
3. **SQL Warehouses for LLM evaluation** — No guide on using SQL warehouses for running evaluation queries against LLM output tables
4. **Databricks Vector Search** — Not mentioned anywhere despite being relevant for RAG on OneData

---

## 7. STALENESS MONITORING SCHEDULE

| Content | Check Frequency | Trigger Event | Owner |
|---------|----------------|---------------|-------|
| AIGW model list (guidelines/06) | **Weekly** | Model onboarded/retired | Wiki maintainer |
| Governance attendee list (guidelines/09) | Monthly | Org restructure | Wiki maintainer |
| Workspace URLs (guidelines/02) | Quarterly | Infrastructure migration | Platform team |
| OAuth scope/tenant ID (guidelines/04) | Quarterly | Azure AD change | Platform team |
| cdomlops source pages (all) | Monthly | Space deprecation progress | Wiki maintainer |
| Kiro CLI version (aws/wiki/04) | Monthly | New release | Wiki maintainer |
| AIDLC tooling references | Monthly | SDK/CLI updates | Framework owner |
| GAIN form alignment | Monthly | Form update by CDO | Wiki maintainer |
| Genie MCP status (GENAI-4229) | Bi-weekly | POC → Pilot transition | Data team |

---

## 8. APPENDIX: AUTHORITY HIERARCHY

When sources conflict, resolve using this tier:

| Tier | Source | Scope | Rule |
|------|--------|-------|------|
| 1 | **LDW** (Lifion 1NAS AI/ML) | Technical architecture, AI Gateway, agent framework | Wins for architecture decisions |
| 1 | **ADPI** (ADP Spark) | GSO approvals, AI Studio, deployment procedures | Wins for process/governance |
| 2 | **cdomlops** (CDO-MLOps) | Arize, model registration, clusters | Valid but deprecated — always date-stamp |
| 2 | **DCL** (ADP Data Solutions) | MCP Server deployment, cost patterns | Verify currency before citing |
| 3 | **DMTeam** (DMT) | Model evaluation, AIGW catalog | Reference for metrics, verify model lists |
| 3 | **Data** (ADP Data Platform) | OneData onboarding, workspaces | Authoritative for platform access |
| 3 | **ADPDPE** (DataPlatform Engineering) | SP tokens, CDC, streaming | Platform operations context |
| 3 | **OCV** (EC360 Client Connect) | DABs evaluation, job scheduling | Team-specific patterns |

**Conflict Resolution:**
- LDW vs ADPI → LDW wins for tech, ADPI wins for process
- cdomlops vs LDW → LDW wins (cdomlops deprecated)
- No source covers topic → Flag as gap, do NOT invent guidance

---

## 9. SUMMARY SCORECARD

| Dimension | Score | Rationale |
|-----------|-------|-----------|
| **Onboarding completeness** | 8/10 | Solid flow, minor gaps (EU, SASE, verification) |
| **LLM development guidance** | 6/10 | AIGW confusion, retired models, no RAG guide |
| **Governance clarity** | 7/10 | Process well-documented, form outdated, Genie gap |
| **Production readiness** | 4/10 | No prod model list, no cost info, workaround risks |
| **Cross-source consistency** | 5/10 | URL mismatches, dual-AIGW, numbering conflicts |
| **Freshness** | 5/10 | Critical content stale (models), good content current |
| **Discoverability** | 7/10 | Good navigation in guidelines/, broken link in wiki/ |
| **AWS patterns coverage** | 3/10 | 73% stubs, one complete page |

**Overall: 5.6/10** — Adequate for experienced engineers who already know what to skip; dangerous for new engineers who follow docs literally.

---

*End of Comprehensive Analysis Report*  
*Generated: 2026-07-27 | Next review due: 2026-08-27*
