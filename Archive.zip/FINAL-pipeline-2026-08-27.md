# FINAL — Pipeline Contract

> **Purpose:** canonical executable behavior for global acquisition, per-wiki processing, publication, terminal reporting, and crash recovery.
> **Owns:** `PIPE-G-*`, `PIPE-W-*`, `PIPE-EXIT-*`, `PIPE-REC-*`.
> **Siblings:** [architecture](FINAL-architecture-2026-08-26.md) owns principles and topology; [implementation plan](FINAL-implementation-plan-2026-08-26.md) owns stages, packages, decisions, thresholds, and acceptance strategy; [index](FINAL-INDEX.md) owns set membership; [todo](FINAL-todo-2026-08-27.md) owns mutable delivery state; [contracts](FINAL-contracts-2026-08-27.md) owns machine shapes; [runbooks](FINAL-runbooks-2026-08-27.md) owns human procedures.
> **Last updated:** 2026-08-27.
> **One fact, one home:** this file references exact `TH-*` IDs but never owns their values, names contract IDs but never duplicates their schemas, and names operator actions but leaves their stop/rollback checklists to `RB-*`.

`MUST`, `MUST NOT`, `SHOULD`, and `MAY` are normative. This is the target contract; where the existing scripts differ, the implementation-plan package and TODO card identify the migration.

## Contract map

- Global phases: `PIPE-G-01`, `PIPE-G-02`, `PIPE-G-03`, `PIPE-G-04`, `PIPE-G-05`, `PIPE-G-06`, and `PIPE-G-07` cover identity/preflight → acquisition → wiki join → approval → evidence-first publication → global backup/finalization.
- Wiki phases: `PIPE-W-01`, `PIPE-W-02`, `PIPE-W-03`, `PIPE-W-04`, `PIPE-W-05`, `PIPE-W-06`, `PIPE-W-07`, and `PIPE-W-08` cover workspace → total proceed decision → optional DEEP discovery → staged bridge → sequential roles → blocking gates → verifier/candidate → every-branch reporting.
- Exit phases: `PIPE-EXIT-01`, `PIPE-EXIT-02`, `PIPE-EXIT-03`, `PIPE-EXIT-04`, `PIPE-EXIT-05`, and `PIPE-EXIT-06` own result transport, dispositions, process failure, finalization, aggregation, and process exit.
- Recovery phases: `PIPE-REC-01`, `PIPE-REC-02`, `PIPE-REC-03`, `PIPE-REC-04`, `PIPE-REC-05`, `PIPE-REC-06`, `PIPE-REC-07`, and `PIPE-REC-08` own atomic acquisition, WIP preservation, release journal/CAS, resume/rollback, safe cleanup, and the backup boundary.

## `PIPE-G-01` — identity and path grammar

`SCHEMA-CFG-00` is the sole owner of identifier grammar and scope. The launcher creates its global-invocation `run_id` before any mutable action; every wiki phase in that invocation uses it. Acquisition and publication retain independent typed identities so either can be resumed by a later invocation.

| Name | Canonical type owner | Pipeline rule |
|---|---|---|
| `run_id` | `SCHEMA-CFG-00.run_id` | one per global invocation; shared by its global and per-wiki results |
| `batch_id` | `SCHEMA-CFG-00.batch_id` | one per acquisition batch that reaches staging |
| `release_id` | `SCHEMA-CFG-00.release_id` | created only when a release proposal is materialized |

| Artifact | Canonical path or name |
|---|---|
| run root | `state/runs/<run_id>/` |
| global run data | `state/runs/<run_id>/global/` |
| wiki run data | `state/runs/<run_id>/wikis/<wiki>/` |
| run-local release journal projection | `state/runs/<origin_run_id>/global/release/journal-projection.jsonl` |
| authoritative committed release journal | `state/releases/journals/<release_id>.jsonl` (`SCHEMA-REL-02`) |
| control worktree | hidden sibling `<control-parent>/.<control-repo>.wt-control-<run_id>/` |
| wiki worktree | hidden sibling `<wiki-parent>/.<wiki-repo>.wt-<run_id>/` |
| root candidate branch | `pipeline/evidence-<run_id>` in the control-plane repository |
| wiki candidate branch | `pipeline/run-<run_id>` inside that wiki repository |

`SCHEMA-CFG-07`, `SCHEMA-CFG-08`, and `SCHEMA-CFG-09` bind, resolve, and attest the authoritative control root. For each repository, the orchestrator obtains the canonical repository root, canonicalizes its existing parent separately, derives the leaf only from a validated typed identifier and repository slug, and proves the prospective worktree's parent is byte-for-byte that canonical parent. The worktree path MUST NOT exist or be a symlink before `git worktree add`. A path under the repository itself, under a generic temporary directory, through a symlink escape, or under another discovered checkout is invalid.

A resume or rollback command gets a new `run_id`, records `origin_run_id` and `release_id`, and appends through the guarded `SCHEMA-REL-02` writer to the committed journal. The run-local file is only a validated staging/projection and is never recovery authority. A completed `run-result/1` is immutable; resumption never reopens or overwrites it.

## `PIPE-G-02` — preflight and configuration

`orchestrator/run-pipeline.sh` is the global entry point. It reads the opaque `root_id` from desired deployment configuration, runs exactly `wiki config resolve-root --root-id <root_id> --json`, validates the ephemeral result as `SCHEMA-CFG-08`, persists only its redacted `SCHEMA-CFG-09` attestation bound to the invocation `run_id`, and changes to no other discovered checkout. The resolved path is consumed in memory, never persisted. The launcher verifies the persisted attestation equals the ephemeral attestation after removing only the ephemeral path/resolution wrapper, verifies the attested control-plane root is clean, and runs `wiki doctor --json` before acquisition. Pre-existing root work yields `preflight_blocked` without mutation. Doctor errors that make execution unsafe stop mutation; warnings are carried into the summary and result. `SCHEMA-CFG-03` solely owns doctor result and process-exit behavior.

Configuration precedence is explicit CLI input → versioned runtime configuration → documented default. An unknown key or an empty required value is an error, not an implicit shell default.

| Concern | Canonical owner | Pipeline use |
|---|---|---|
| root, host, user, scheduler | `orchestrator/deploy.yaml`, `SCHEMA-CFG-07`, `SCHEMA-CFG-08`, `SCHEMA-CFG-09`, and plan decision 1 | select and attest the sole authoritative deployment without persisting its resolved path |
| interpreter and tool paths | `orchestrator/runtime.env` | invoke pinned executables without ambient-PATH discovery |
| wiki scope and source spaces | `orchestrator/wiki-config/<wiki>.env` | build typed per-wiki inputs |
| source cadence, class, provider | `state/source-registry.yaml` | select due observations |
| gate and autonomy switches | `orchestrator/enforcement.env` plus plan decisions 4 and 17 | fail closed when missing or contradictory |
| mutable numeric values | exact plan §9/§9.2 `TH-*`, materialized into versioned runtime config | scripts consume IDs; this file contains no fallback literal |
| contract versions | the registered IDs in `FINAL-contracts-2026-08-27.md` | reject unknown incompatible major versions |

The process records the effective configuration digest, framework version, executable versions, enabled capabilities, mode (`LIGHT` or `DEEP`), requested wiki set, expected root head, and scheduler receipt before work begins. Secrets and credential contents are excluded; only availability/profile identifiers are recorded.

The pre-mutation Stage −1 gate accepts only the successful `SCHEMA-CFG-10` variant: nonempty verified repository bundles, passed empty-directory restore, passed verification, null failure, `evidence_status=not_available_pre_stage3`, and a non-null `deployment_seed_receipt` whose RFC 8785 hashes and `PRESERVE-00` → `RUNTIME-01` binding validate. The seed fixes disabled automerge and the reserved job IDs without carrying deploy-file bytes; `RUNTIME-01` remains sole owner of `orchestrator/deploy.yaml`. It neither requires nor fabricates evidence paths or an event high-water mark. Once Stage-3 evidence persistence is enabled, backup readiness accepts only the successful `SCHEMA-CFG-13` variant with stable heads, passed verification, all three evidence families (`raw/objects/**`, `raw/_index/**`, and `state/events/**`), and event high-water; a preservation receipt never upgrades into that receipt by inference.

## `PIPE-G-03` — acquisition before the wiki loop

Acquisition executes once per global run, including a quiet run, because it is the source of new work. A scoped manual invocation uses the same component and state machine with a restricted source set.

| Step | Component | Inputs | Durable output / result |
|---|---|---|---|
| acquire | acquisition lock manager | root, owner token, host, PID, process-start identity | validated lock receipt; stale owner is quarantined, never overwritten |
| plan | registry selector | registry cadence, `TH-TGT-004`, `TH-TGT-005`, requested scope | run-local `SCHEMA-SO-07` acquisition plan and `batch_id`; the selected set may be empty |
| observe | `SourceProvider` implementations | response-independent planned-attempt identities, typed locators, and auth-profile identifiers | one staged `SCHEMA-SO-02` acquisition row per planned attempt; accepted content also yields `SCHEMA-SO-01` plus `SCHEMA-SO-05`; a content-bearing policy/identity rejection yields content-free `SCHEMA-SO-06`; an unavailable or unauthorized response with no attempted payload yields neither mapping nor quarantine receipt |
| classify | freshness engine | observations and prior completed batch | acquisition/source-condition classification; no per-wiki semantic claim yet |
| validate | schema, secret, size, and identity gates | staged plan/object/event/index/envelope/marker set | pass evidence or a typed failure row for every planned source |
| commit batch | acquisition committer | validated staged set, clean root base | accepted `SCHEMA-SO-01`/`SCHEMA-SO-05` pairs, applicable `SCHEMA-SO-06` rejection receipts, the possibly empty JSONL segment of `SCHEMA-SO-02` acquisition events bound by `SCHEMA-SO-08`, and `SCHEMA-SO-09` completion marker in the control worktree |
| derive | `build-views.py` | completed event segments in the control worktree | gitignored candidate views, rebuilt deterministically |
| report | phase-result writer | receipts and errors | schema-valid `run-result/1` phase result |

Source failure does not discard the batch or masquerade as unchanged. It produces an observation failure row, feeds `TH-TGT-009` or `TH-TGT-010`, and can make a wiki unhealthy. Acquisition exhausts only the bounded retries allowed by source policy and `PIPE-EXIT-03`. Attempt identity is allocated from the immutable plan before network response, so timeout, denial, malformed bytes, rejection, and retry cannot choose or change their identity from response content; the response-dependent facts, including `confirmed_removed_threshold`, are independently bound by `SCHEMA-SO-02.result_sha256`. `confirmed_removed` is legal only when `previous_success_ref` and `previous_success_sha256` resolve to a prior successful observation for the same registered source and normalized endpoint, `confirmed_removed_threshold` equals the run's materialized plan §9 `TH-TGT-050` policy value, and the contract counts that exact number of qualifying independent observations; otherwise removal remains suspected.

A zero-due selection is a successful acquisition transaction, not an absent batch. `SCHEMA-SO-07` records `selection=none_due` with empty requested scope and sources; the committer writes the exact zero-byte event segment and a `SCHEMA-SO-08` envelope with zero records and null first/last event IDs, then a `SCHEMA-SO-09` marker with zero planned/terminal counts and empty object, index, and quarantine inventories. It creates no fabricated `SCHEMA-SO-01`, `SCHEMA-SO-02`, `SCHEMA-SO-05`, or `SCHEMA-SO-06` row. Views and the global join consume that completed marker and can therefore distinguish “no source due” from launcher failure or an incomplete batch.

After the marker validates, the orchestrator uses an isolated index to commit only completed objects, the event segment and its envelope, `_index`, quarantine receipts, and marker paths on the root candidate branch; views are excluded. The acquisition lock protects staging promotion and this candidate checkpoint, not a human approval wait. It is released only by the matching owner token after that checkpoint or a recoverable torn-batch checkpoint is durable. Publication concurrency is separately fenced by `PIPE-REC-04`.

```mermaid
flowchart LR
  P[SCHEMA-SO-07 plan fixes every due attempt] --> D{due attempts?}
  D -->|none| Z[empty SCHEMA-SO-08 segment envelope]
  D -->|one or more| A{attempt result}
  A -->|accepted object| O[SCHEMA-SO-01 object plus SCHEMA-SO-05 non-null mapping]
  A -->|payload rejected| Q[content-free SCHEMA-SO-06, no SO-05 row]
  A -->|unavailable or unauthorized with no payload| N[SCHEMA-SO-02 only, no SO-05 or SO-06]
  O --> E[SCHEMA-SO-02 acquisition row in event segment]
  Q --> E
  N --> E
  E --> S[SCHEMA-SO-08 segment envelope]
  Z --> M[SCHEMA-SO-09 completion marker published last]
  S --> M
  M --> V[SCHEMA-SO-04 views derived from completed events]
```

No view, semantic assessment, or presentation state is an input to the object/event/marker commit. Every nonempty planned attempt has exactly one `SCHEMA-SO-02` row in the segment. `SCHEMA-SO-05` exists if and only if that row has a non-null accepted `object_sha256`. A content-bearing rejection with a `SCHEMA-SO-06.finding_class` produces that content-free receipt and no mapping; a content-free unavailable/unauthorized event produces neither receipt nor mapping. A consumer starts view derivation only after `SCHEMA-SO-09` validates the plan, segment/envelope, accepted-object/index inventory, the exact possibly-empty quarantine inventory, and their cardinalities. The view builder then projects every event row, including unavailable/unauthorized/rejected rows, and projects the explicit empty batch without pretending that a fetch occurred.

## `PIPE-REC-01` — acquisition crash consistency

The acquisition committer uses a same-filesystem staging directory under the run root and promotes only into a control worktree created from the recorded root base. It never dirties the authoritative root worktree. Consumers ignore a batch until its completion marker validates.

1. Write the `SCHEMA-SO-07` plan first, including every response-independent planned-attempt identity. For each due attempt, write exactly one `SCHEMA-SO-02` row; accepted bytes additionally write `SCHEMA-SO-01` and their non-null `SCHEMA-SO-05` mapping, a content-bearing policy/identity rejection writes content-free `SCHEMA-SO-06`, and a content-free unavailable/unauthorized outcome writes neither. Neither nonaccepted branch writes an index row. Write `SCHEMA-SO-08` even for the zero-due empty segment; flush every file and containing directory.
2. Validate each artifact against its registered contract, content identity, secret policy, and the plan's complete source/attempt cardinality.
3. Promote immutable objects without replacing an existing different object. An identical object is an idempotent no-op.
4. Promote only batch-tagged `SCHEMA-SO-05` records whose event has a non-null accepted object, without modifying prior records; promote content-free `SCHEMA-SO-06` only for rows whose rejected payload and finding class satisfy that contract.
5. Promote the JSONL event segment and its `SCHEMA-SO-08` envelope.
6. Atomically publish the `SCHEMA-SO-09` marker last. It binds the digests and exact inventories of the plan, segment envelope/bytes, index records, referenced objects, and quarantine receipts; every inventory is explicitly empty in a zero-due batch.
7. Rebuild views from completed events. Views are never release members and never recovery authority.

A crash before step 6 leaves an invisible incomplete batch. Recovery validates the surviving staged/final files against `SCHEMA-SO-01`, `SCHEMA-SO-02`, `SCHEMA-SO-05`, `SCHEMA-SO-06`, `SCHEMA-SO-07`, and `SCHEMA-SO-08`, then either resumes the first missing promotion or writes a `SCHEMA-SO-06` receipt and isolates the whole incomplete set. It never edits a previously completed batch. A crash after step 6 validates `SCHEMA-SO-09`, re-runs view construction, and produces no new acquisition event. The `SCHEMA-SO-02` identity preimage and retry reconciliation rule are checked before every promotion.

Operator interfaces are exact: `wiki acquisition inspect --batch <batch_id> --json` is read-only and returns `SCHEMA-CFG-17`; `wiki acquisition resume --batch <batch_id> --json` runs this idempotent recovery under the acquisition lock and returns a validated `SCHEMA-CFG-17` post-action inspection.

## `PIPE-G-04` — sequential wiki loop and join

The global runner processes managed wikis sequentially. The configured stagger occurs only between consecutive wiki starts; target window/stagger are `TH-TGT-021` and `TH-TGT-022`, while the copied live stagger is `TH-LIVE-014`. `local_laptop` is never in this loop.

```mermaid
flowchart TD
  START[run identity and doctor] --> ACQ[acquire and complete observation batch]
  ACQ --> LOOP{next managed wiki?}
  LOOP -->|yes| WIKI[PIPE-W-01 through PIPE-W-08]
  WIKI --> LOOP
  LOOP -->|no| JOIN[aggregate wiki dispositions]
  JOIN --> PREP[prepare release proposal]
  PREP --> WAIT{approval required?}
  WAIT -->|yes| HELD[record awaiting approval and finalize invocation]
  WAIT -->|no or approved| APPLY[apply release under publication lock]
  APPLY --> FINAL[summary alerts backup and terminal result]
  HELD --> FINAL
```

Each wiki receives the same `batch_id`, effective-config digest, typed `EVIDENCE_ROOT` pointing at the control worktree, root expected head, and its own base commit. A wiki failure does not erase completed results from earlier wikis. The join blocks publication of the entire release set if any affected wiki is not candidate-ready; quiet and unhealthy wikis are represented explicitly rather than omitted.

## Per-wiki contract

### `PIPE-W-01` — base, allowlist, and isolated workspace

`.kiro/pipeline/wiki-nightly.sh` begins with a read-only status check of the real wiki repository. Pre-existing tracked or untracked user work yields `preflight_blocked`; the pipeline records it and touches nothing there.

For a clean repository the orchestrator records the exact base commit, writes a human-readable `allowlist.spec`, compiles it to a canonical NUL-delimited `allowlist.paths0`, and creates the sibling worktree from that base. Patterns are resolved only against repository-relative paths; generated bundles, git metadata, raw evidence, inbox state, steering policy, and paths outside `wiki/**` are excluded unless a narrower phase contract explicitly owns them. Protected pages can only yield proposals.

The orchestrator is the only git mutator. Agents cannot commit, switch branches, alter the real index, or write outside their phase roots. Parent-relative framework links are resolved and checked inside the sibling worktree before any agent starts.

### `PIPE-W-02` — total proceed classification

Preflight consumes the completed batch, prior views, approved proposals, requested mode, and current wiki tree. A proposal is selectable only in a legal `SCHEMA-CP-02` lifecycle state; this pipeline defines no implicit `deferred` proposal state and accepts no uncontracted deferred/backlog input. It emits exactly one disposition class before any token-spending phase.

| Class | Meaning | LLM work | Next step |
|---|---|---|---|
| actionable | evidence-bearing drift, confirmed removal, conflict, approved proposal, or explicit DEEP work | allowed | `PIPE-W-03` or `PIPE-W-04` |
| quiet | healthy inputs and no actionable work | none | `PIPE-W-08` |
| unhealthy | unavailable, unauthorized, incomplete/partial, or otherwise untrusted required input | none | bounded retry if eligible, then `PIPE-W-08` with alert |
| blocked | dirty base, invalid configuration, missing capability, or broken completed-batch binding | none | `PIPE-W-08` with failure evidence |

First observation is never silently treated as confirmed drift when source health is inadequate. Core freshness state and diagnostic banners are provided by `SCHEMA-SO-04`; this phase consumes that total mapping and does not invent additional status labels.

### `PIPE-W-03` — LIGHT/DEEP branch

DEEP runs registry-aware discovery and emits source candidates as proposals. LIGHT bypasses discovery directly to extraction/triage. Nightly URL-change detection in existing registered sources is acquisition, not DEEP discovery.

```mermaid
flowchart TD
  P[PIPE-W-02 actionable] --> MODE{mode}
  MODE -->|DEEP| D[registry-aware discovery]
  MODE -->|LIGHT| BYPASS[LIGHT bypass]
  D --> X[PIPE-W-04 extraction and staging]
  BYPASS --> X
  Q[quiet] --> REPORT[PIPE-W-08]
  U[unhealthy or blocked] --> REPORT
```

Discovery scope is derived from wiki configuration and ownership policy, and its result is schema-valid input to proposal staging. It cannot publish a page or mutate the source registry by itself.

### `PIPE-W-04` — extraction, capture triage, and the bridge

The ingestor reads only immutable objects referenced by this batch and writes extraction results in its run directory. Inbox proposals are read by the orchestrator-side capture triager, never by the ingestor or writer.

The stager selects proposals whose target wiki, base commit, approval state, and policy permit this run. It renders the single fenced handoff through the contract-owned renderer and writes typed proposal records plus `handoff.md` under the wiki run path. Source-derived quotes exist only inside the fenced handoff; proposal records carry span/hash references, not an unfenced instruction-bearing quote.

The writer is given only `HANDOFF_PATH`, `PROPOSALS_DIR`, the worktree `wiki/**`, and the permitted steering subset. It has no route to `raw/`, `state/inbox/`, the network, git mutation, or arbitrary `.kiro/**`. `handoff-lint` and hostile-source fixtures are owned by `SCHEMA-RR-04` and plan §11.

### `PIPE-W-05` — authoring sequence

Token-spending roles are downstream and sequential:

1. Writer edits allowed wiki paths in the worktree from staged proposals and handoff data.
2. Auditor reads the resulting tree and writes only audit artifacts under the run path.
3. Advisor converts findings into typed triage outcomes under the run path.
4. Librarian may edit allowed `wiki/**` paths in the same worktree but has no git-mutating command and no steering write.

Every role emits one full `run-result/1` envelope as the only stdout frame; stderr is diagnostic text and is never parsed as authority. The orchestrator validates and atomically persists canonical JSON as `<phase>-result.json`; agent-written result files are not trusted as transport. A failed or malformed result stops subsequent mutating roles and routes to `PIPE-REC-02` and `PIPE-W-08`.

### `PIPE-W-06` — blocking gates before verifier

After the final content mutation, the orchestrator freezes the candidate input and runs every blocking deterministic gate inside the worktree:

| Gate family | Required evidence |
|---|---|
| path scope | tracked changes, deletions, renames, and allowed untracked files are a subset of `allowlist.paths0` |
| content safety | candidate and preservable WIP pass secret and PII policy; source text passes handoff grammar |
| wiki quality | frontmatter, links, canonical ownership, placement policy when enforced, timeless rules when enforced, and filename collision checks |
| navigation | `index-coverage-lint.sh` proves every eligible active page is indexed |
| transaction | immutable evidence paths are untouched by the wiki candidate; base and input digests still match |
| contracts | every machine artifact produced by the run validates against its declared schema version |
| CT | the complete `ct-gate.sh` blocking set passes before verification |

Warnings are recorded and summarized but do not silently become pass evidence. Any blocking failure yields `gate_failed`; verifier is not run. No content mutation is allowed after these gates.

### `PIPE-W-07` — verifier and candidate binding

The orchestrator computes the frozen diff digest and candidate tree digest, then invokes the no-write verifier. Acceptance requires a schema-valid verifier envelope bound to the current `run_id`, role, phase, attempt, wiki, base commit, batch/input digest, prompt digest, capability-set digest, diff digest, and candidate tree digest. Its evidence spans must resolve to the pinned inputs.

Semantic verification is blocking: acceptance requires `verification.verdict=pass`, an empty `checks_failed`, every policy-required check in `checks_run`, all current-run bindings and evidence spans valid, every deterministic gate passed, and the approval policy satisfied. A verdict string alone can never authorize publication, but `verdict=fail` or any failed/missing required check vetoes this candidate. Wrong-run, stale-base, stale-input, wrong-prompt, wrong-capability, wrong-diff/tree/span, replay, or post-verifier tree changes are independent rejection conditions under `SCHEMA-RR-02`.

Only after acceptance does the orchestrator populate an isolated temporary index from the explicit NUL-delimited allowed-path set and create the candidate commit. It verifies that the candidate commit tree equals the verifier-bound tree. The candidate commit and branch are immutable inputs to `PIPE-G-05`; later edits require a new attempt and reverification.

### `PIPE-W-08` — per-wiki finalizer on every branch

This phase always runs, including quiet, unhealthy, blocked, cancelled, and candidate-ready paths. It performs no authored-content mutation.

- Generate deterministic health counts from completed events and phase results.
- Generate `morning-summary.md`; optional navigator prose may decorate, never replace, the counts.
- Regenerate the source-monitor candidate from registry policy and views.
- Emit alerts for unhealthy sources under `TH-TGT-009` and `TH-TGT-010`; blocking failures, stale locks, mixed releases, backup failures, and dead-man failures alert directly from their typed receipts.
- Write the wiki terminal `run-result/1`, including `status`, `disposition`, phase receipts, candidate commit if any, and alert receipts.
- Preserve or quarantine the worktree through `PIPE-REC-02` and `PIPE-REC-07`.

Quiet therefore means no LLM spend, not no output. Unhealthy means no writer wake-up, not no summary or alert.

## `PIPE-REC-02` — scoped WIP and failure evidence

On role failure, gate failure, timeout, or cancellation, the orchestrator inventories changed tracked files and untracked files with NUL-safe git output, canonicalizes every path, and intersects it with `allowlist.paths0`. Out-of-scope residue is an incident and is never packaged as a candidate.

Before persistence, candidate content is scanned for secrets and prohibited personal data. If clean, an isolated temporary index initialized from the base is populated only from the explicit allowed path list; its binary diff becomes `wip.patch`, including allowed new files and deletions. `wip-manifest.json` binds base, paths, modes, and hashes. If unsafe, only a redacted failure receipt and content hashes are retained; the content is quarantined under restricted permissions according to the security policy.

The real repository index and pre-existing user work are never modified. Repository-wide staging, hard reset, forced checkout, and recursive filesystem deletion are forbidden. A clean candidate branch may be retained for diagnosis, but it cannot be published without a fresh successful gate/verifier binding.

## `PIPE-G-05` — release proposal and approval

The join creates a release only when acquisition is completed and every affected wiki is candidate-ready. It writes `SCHEMA-REL-00` at `state/runs/<origin_run_id>/global/release-proposal.json`, then creates the initial `SCHEMA-REL-02` `prepare` event on the dedicated root release-candidate branch. That event carries the proposal digest and expected heads, with both `manifest_sha256` and `authorization_receipt_sha256` null: neither the approval nor the exact final-manifest bytes exist yet. The proposal is immutable run evidence; the authoritative journal is the committed `state/releases/journals/<release_id>.jsonl`. The run-local journal projection may be replaced from the committed journal but never the reverse. The proposal binds:

- `release_id`, `origin_run_id`, `batch_id`, framework/config/contract digests;
- expected current-release id and expected head of the control-plane root and every affected wiki;
- the root evidence candidate commit containing completed raw objects, acquisition events, segment envelope, `_index` records, and completion marker, plus the exact `evidence_tree_sha256` preimage defined by `PIPE-G-06`;
- each verified wiki candidate commit, base commit, diff/tree digest, `gates_digest`, and `verification_digest`;
- the approval-independent `final_artifacts` inventory known at proposal time; approval-dependent journal, manifest, pointer, and attestation bytes are excluded because their exact hashes do not yet exist, and disposable monitor/health views are excluded;
- required approval class and policy, with no approval-receipt field and no field that names the proposal's containing commit.

`proposal_sha256` is the SHA-256 of the RFC 8785 canonical `SCHEMA-REL-00` bytes with the `proposal_sha256` field omitted. The resulting digest is stored in that field and carried by journal events, any approval, and the final manifest; it never hashes itself. When `approval_class` is `human` or `policy`, `SCHEMA-REL-06` binds that exact digest, the release and proposal identities, decision, actor/authority, and time. After that receipt exists, `SCHEMA-REL-01` binds both `proposal_sha256` and its `approval_receipt_sha256`; for the contractually approval-free class, that latter field is null. A change to the evidence candidate, any member, expected head, approval policy, or proposal byte creates a new proposal digest and invalidates any old receipt.

Semantic change waits for human approval under plan decisions 4 and 12. The scheduled invocation does not hold a process or lock while waiting: it commits the `prepared` journal checkpoint on the release-candidate branch, records terminal disposition `awaiting_approval`, sends the summary, and exits through `PIPE-G-07`. Human and policy approvals atomically commit the exact `SCHEMA-REL-06` receipt at its canonical append-only path together with the guarded `approval_received` journal event; that event binds the receipt digest in `authorization_receipt_sha256` while `manifest_sha256` remains null. Policy-permitted unattended semantic changes follow the same journal and publication path with a machine-policy receipt; they do not omit the approval binding.

## `PIPE-REC-03` — release journal

The authoritative journal is the append-only, committed `state/releases/journals/<release_id>.jsonl`. Each event is validated as `SCHEMA-REL-02`, appended to a temporary copy made from the exact current committed bytes, flushed, and committed by the orchestrator on the release-candidate branch or authoritative root under expected-head CAS. After publication begins, every state transition/checkpoint is made durable in a root commit before the next repository mutation. Backup includes the committed journal and any validated later candidate-branch checkpoint. A current state is projected only after entry-chain, request-id, sequence, proposal/manifest digest, actor/guard, and head validation. `SCHEMA-REL-02` is the sole owner of state names, legal transitions, actors, guards, and checkpoint shape; this file owns only when the pipeline requests those transitions.

```mermaid
sequenceDiagram
  participant O as Orchestrator
  participant J as SCHEMA-REL-02 journal
  participant A as Approval authority
  participant P as Publisher
  O->>J: prepare none → prepared; manifest/auth null
  alt approval required
    O-->>O: finish run as awaiting_approval; release remains prepared
    A->>J: approval_received prepared → prepared; REL-06 bound, manifest null
  end
  O->>J: validate prepared → validated; immutable manifest bound
  P->>J: request validated → applying
  loop evidence and each wiki repository
    P->>J: request applying → applying checkpoint
  end
  P->>J: request applying → committed
  P->>J: request committed → pointer_advanced
  opt uncertain post-mutation failure
    P->>J: request applying or committed → mixed
  end
```

Approval waiting is a `SCHEMA-RR-01` global-run disposition, not a second release state. Resume requests `mixed → applying`; rollback requests the `rolling_back` and `rolled_back` transitions; a pre-mutation rejection requests `aborted` or `superseded`. The exact guards and allowed source states remain in `SCHEMA-REL-02`. A gitignored run-local projection, log line, backup copy, or in-memory transition can never substitute for the committed event.

`wiki release inspect --id <release_id> --json` is the read-only status interface and returns `SCHEMA-REL-09`. It validates the authoritative committed journal chain and `SCHEMA-REL-00`, validates `SCHEMA-REL-01`, `SCHEMA-REL-03`, `SCHEMA-REL-06`, and `SCHEMA-REL-08` whenever each is present, compares all repository heads and the current pointer, and reports the only legal next actions.

## `PIPE-REC-04` — publication lock, CAS, and mixed state

Human approval is resolved before acquiring the publication lock. The lock carries owner token, host, PID, process-start identity, `release_id`, and expected current-release id. It is held from the first head update through final pointer advancement or a durable mixed/blocked checkpoint.

Before every repository update, the publisher compares the actual head with the journal's expected head and confirms no unresolved `mixed` journal touches that repository. A mismatch requests `aborted` before mutation or `mixed` after a prior repository was applied, subject to the guards in `SCHEMA-REL-02`. No force operation is permitted. Lock release requires the matching token; stale-lock recovery first inspects process identity and all journals.

The accepted-release predicate—not a pointer file in isolation—is the visibility boundary. A reader accepts a release only when `current-release.json`, the committed `SCHEMA-REL-02` tail at `pointer_advanced`, and a valid `SCHEMA-REL-08` attestation all name and hash the same manifest/pointer bytes and all bound heads verify. Until that predicate holds, the newly written pointer bytes are provisional and the reader uses the last previously accepted release recorded by the validated previous pointer/journal. Repository heads and provisional pointer bytes may therefore be temporarily mixed after a publication fault without making the new release visible. Mixed or merely `committed` state is an integrity incident requiring resume or rollback; it is never counted as successful closure.

## `PIPE-G-06` — evidence-first publication without self-reference

Publication has one canonical order:

1. Revalidate `SCHEMA-REL-00`, expected pointer, expected repository heads, candidate/gate/verification digests, backup readiness, and the committed journal chain. For `human` or `policy`, also revalidate the exact `SCHEMA-REL-06` receipt and its committed `approval_received` event; for `none`, require both approval digest and approval event absent. Construct and freeze the exact non-self-referential `SCHEMA-REL-01` bytes and digest only now, using the approval receipt digest or contractually null value. Append/commit `prepared → validated` with that first non-null manifest digest on the release-candidate branch, acquire the publication lock, then append/commit `validated → applying` with the same digest before any authoritative-head mutation.
2. CAS-apply the root **evidence commit** first. It contains the completed `SCHEMA-SO-01`, `SCHEMA-SO-02`, `SCHEMA-SO-05`, `SCHEMA-SO-08`, and `SCHEMA-SO-09` artifacts, any allowed `SCHEMA-SO-06` receipt, and any allowlisted proposal disposition/event selected by `SCHEMA-REL-00`; it contains no view, release proposal, approval, release journal, manifest, pointer, root attestation, or run scratch. Append the root `applying → applying` checkpoint to the authoritative journal and commit that append on the root before touching a wiki.
3. Apply each verified wiki candidate sequentially. After each head update, verify the resulting head/tree and append/commit exactly one `applying → applying` checkpoint on the root before the next wiki mutation. A wiki can therefore reference an evidence commit already ancestral to the root head.
4. Reverify all applied wiki trees, evidence artifacts, proposal/approval bindings, batch marker, and expected heads. Require the frozen `SCHEMA-REL-01` bytes/digest to remain unchanged; at `state/releases/<release_id>.json` those bytes bind the earlier evidence commit/tree digest, exact proposal and approval digests, and applied member commits, and contain no field for their own containing commit. Construct and validate the `SCHEMA-REL-03` previous/current pointer pair against the still-current generation before either pointer is written.
5. Create one finalization root commit containing `SCHEMA-REL-01`, the applicable committed `SCHEMA-REL-06` approval and `SCHEMA-REL-07` rollback authorization receipts, proposal disposition events, `previous-release.json`, provisional `current-release.json` bytes, and the authoritative journal's `applying → committed` event. A receipt type that does not apply is absent rather than fabricated. Disposable monitor/health/catalog views remain outside the commit. CAS-apply this finalization commit. The provisional pointer is not accepted by readers under `PIPE-REC-04` while the journal tail is only `committed` or `SCHEMA-REL-08` is absent.
6. Derive `SCHEMA-REL-08` from the applied finalization commit, using the same positive `sequence` in both the record and `state/releases/attestations/<release_id>-<sequence>.json`, and verify that commit contains the exact manifest and pointer bytes and descends from the bound evidence commit. The attestation is an after-the-fact binding and is not part of the manifest preimage.
7. Append/commit `committed → pointer_advanced` and `SCHEMA-REL-08` on the root in one CAS update. Verify journal, pointer generation, finalization commit, attestation, and all heads; only that verified tuple makes the provisional pointer accepted, after which the lock is released by owner token.

The `evidence_tree_sha256` preimage is exact and non-self-referential: RFC 8785 canonical JSON array of `{path,sha256}` sorted by UTF-8 path bytes for completed raw objects, `_index`, event segments/envelopes/markers, proposal dispositions, and other allowlisted evidence-commit files as they exist in the named evidence commit. It excludes the release proposal, final manifest, release journal, approval/rollback/root attestations, current/previous pointers, every `state/runs/**` path, disposable views, and the containing commit ID. The proposal and final manifest both carry the evidence commit and this digest; the final manifest additionally carries `proposal_sha256` and `approval_receipt_sha256`.

Views are rebuilt locally after the completed event commit and again after restore; they are never committed. Blocking index coverage is `PIPE-W-06`, never a post-publication gate. Post-publication checks are diagnostic and can open an incident but cannot retroactively validate an unverified candidate.

A crash after step 5 but before step 7 leaves a recoverable `committed` release: the physical pointer bytes may name it, but readers reject that tuple and continue using the last accepted release. Resume verifies the unchanged finalization commit, derives and validates `SCHEMA-REL-08`, and performs only step 7. A mismatch records `mixed` and never falls through to acceptance. A crash after the step-7 CAS is recovered by inspection: if the attestation/journal/pointer tuple validates, only reporting and backup remain; otherwise the release is mixed. Fault fixtures MUST cover both sides of the step-5 CAS and both sides of the step-7 CAS.

## `PIPE-REC-05` — resume

Resume has two exact command forms selected only by immutable `SCHEMA-REL-00.approval_class`: `wiki release resume --id <release_id> --json` for `none`, and `wiki release resume --id <release_id> --approval <approval-receipt.json> --json` for `human` or `policy`. The `none` form rejects an approval option and requires both `SCHEMA-REL-06` and `approval_received` absent; the other form requires a matching `SCHEMA-REL-06` and committed `approval_received` event. Both start a new invocation, validate the proposal, acquire the publication lock only after authorization is settled, and recompute state from the committed `SCHEMA-REL-02` journal plus actual heads. They skip checkpoints whose expected result already matches, retry only the first incomplete idempotent action, refuse an unexplained head, and return `SCHEMA-REL-09` with `operation=resume`; its `exit_code` is process authority and the structured result is validated before persistence.

A resume after evidence application continues with the first unapplied wiki. A resume after all wiki applications re-verifies the set and creates the final manifest/pointer commit. A resume after pointer advancement performs only finalization and backup. New content, a changed base, or a changed candidate requires a new release proposal rather than resume.

## `PIPE-REC-06` — rollback

`wiki release rollback --id <release_id> --authorization <rollback-authorization.json> --json` creates an audited rollback release. It validates the two-party `SCHEMA-REL-07` authorization and never moves a branch backward. Under the publication lock it verifies current heads, creates revert candidates for every applied wiki in reverse application order, then prepares a root revert candidate. It gates and verifies the rollback candidates, publishes a rollback manifest and pointer through `PIPE-G-06`, and checkpoints `rolled_back`.

Evidence deletion, index rewriting, backup mutation, and non-resurrection behavior are not implied by rollback. While plan decision #20 is unresolved, rollback preserves and isolates acquired evidence and reverses only publication references and authored content; it stops and escalates if that cannot be done without deciding the policy. After the decision, only the selected schema-versioned branch may authorize additional behavior. This pipeline makes no unconditional purge, hold, or retention rule. Human steps and stop conditions are in `RB-ROLLBACK-01`, `RB-ROLLBACK-02`, and `RB-RESTORE-04`.

## `PIPE-REC-07` — cleanup

Cleanup is automation-only and recoverable. It operates on an explicit inventory whose root, run sentinel, owner id, age policy name, backup receipt, and absence from active journals all validate. Candidate worktrees and run artifacts move to a quarantine/archive area before any later disposal; the pipeline never selects the `state/runs` root and never follows symlinks.

Run-evidence retention uses `TH-TGT-011`. An unresolved release, missing backup receipt, secret quarantine, active process, or unknown path blocks cleanup. While decision #20 is pending, any hold signal also selects preserve/isolate/stop and therefore blocks cleanup; after that decision, cleanup follows only the selected schema-versioned policy. Cleanup emits an inventory and receipt even when it takes no action.

## Exit phases — results, failures, and finalization

### `PIPE-EXIT-01` — phase transport

Every scheduled or invoked pipeline phase produces one schema-valid `run-result/1`. The producer→transport map is exhaustive:

| Producer | Sole result transport | Persistence authority |
|---|---|---|
| model-backed agent role | exactly one UTF-8 `run-result/1` JSON object plus LF on stdout; stderr is diagnostics only | orchestrator |
| deterministic gate or orchestrator phase | typed `trusted_return` value on the private in-process call boundary; it cannot select a path | orchestrator |
| deployment scheduler wrapper | the registered `SCHEMA-CFG-11`, `SCHEMA-CFG-12`, `SCHEMA-CFG-13`, or `SCHEMA-CFG-14` receipt channel selected by `SCHEMA-CFG-04`; never an agent/run-local file | scheduler wrapper named by the contract |

An external deterministic executable may emit raw diagnostics or tool-specific structured output to its in-process adapter, but it never directly emits or persists `run-result/1`; the adapter validates those bytes and returns the deterministic envelope through `trusted_return`. The orchestrator validates identity and schema before using an output, writes canonical JSON plus LF to a same-directory temporary regular file, flushes file and directory, and atomically renames it to the registered run-relative path. No agent or deterministic child may write, nominate, or later edit a persisted result path. Missing/extra agent frames, stdout contamination, malformed output, stale identity, an output-path hash mismatch, or bytes observed after process exit are phase failures.

### `PIPE-EXIT-02` — terminal dispositions

`SCHEMA-RR-01` solely owns the total legal `scope × status × disposition` mapping for phase, wiki, and global results. The pipeline selects one of those pairs and MUST NOT add a display-only disposition. A no-work phase is represented by its legal phase receipt with reason and input digest, never by absence.

### `PIPE-EXIT-03` — retry, timeout, and cancellation

Retry is allowed only when the failure class is contractually retryable, the operation is idempotent, and the phase names its applicable budget: `TH-TGT-004`, `TH-TGT-005`, `TH-TGT-021`, `TH-TGT-031`, or `TH-TGT-032`. Backoff belongs to source policy. Validation, policy, authorization, schema, secret, PII, dirty-tree, wrong-head, and verifier-binding failures are not blindly retried.

Each external process runs in its own process group. On deadline or cancellation the orchestrator sends graceful termination to the group, waits the configured grace policy, escalates to group termination, verifies no descendant remains, and records command, phase, attempt, deadline policy name, final signal/exit, and captured-output digests. No later mutating phase starts until child absence is proved.

### `PIPE-EXIT-04` — every-branch finalizer

One idempotent finalizer is installed before the first mutation. On normal return and trappable termination it records the active phase, closes or checkpoints held locks, preserves safe WIP, runs `PIPE-W-08` for every started wiki, writes alerts, records release state, writes a backup request under `PIPE-REC-08`, and persists the global terminal result. A secondary finalizer failure is appended without erasing the primary failure. Launcher death and untrappable termination can bypass this finalizer; `job.deadman.independent` detects the missing receipt instead of assuming the finalizer ran.

### `PIPE-EXIT-05` — aggregation

The global result lists every requested wiki with a terminal disposition and joins scheduler receipt → run → batch → release if any. Publication requires all affected candidates to pass. The exact global pair comes from `SCHEMA-RR-01`: a noncritical unhealthy input selects `degraded + unhealthy`; a required/critical unhealthy input that prevents the requested work selects `failed + unhealthy`; an approval wait selects `succeeded + awaiting_approval`; mixed publication and failure to durably create a required backup request select their legal failed pairs. A later independent-backup failure writes its own job result/receipt and alert and never rewrites the immutable pipeline result. No alternative disposition is invented to encode severity.

### `PIPE-EXIT-06` — process exit

The launcher derives process exit from the persisted **global-scope** `SCHEMA-RR-01` pair only after the result is flushed. Scheduled, manual, prose, and JSON modes use the same complete table:

| Global status | Global disposition | Process exit |
|---|---|---:|
| `succeeded` | `published` | 0 |
| `succeeded` | `quiet` | 0 |
| `succeeded` | `awaiting_approval` | 0 |
| `succeeded` | `rolled_back` | 0 |
| `degraded` | `unhealthy` | 2 |
| `failed` | `unhealthy` | 1 |
| `failed` | `preflight_blocked` | 1 |
| `failed` | `gate_failed` | 1 |
| `failed` | `verifier_rejected` | 1 |
| `failed` | `timed_out` | 124 |
| `failed` | `mixed_release` | 1 |
| `failed` | `backup_failed` | 1 |
| `cancelled` | `cancelled` | 130 |
| `cancelled` | `timed_out` | 124 |

An illegal pair or a result that the still-running launcher cannot parse exits 70 and is a contract incident. If the launcher itself dies before interpreting a result, the scheduler records the native process outcome; the pipeline cannot synthesize an exit or terminal result, and `job.deadman.independent` handles the missing completion receipt.

The public commands and exit authorities are exact; a wrapper MUST NOT infer success from readable prose or substitute another schema:

| Command | Required structured result | Exit authority |
|---|---|---|
| `orchestrator/run-pipeline.sh --json` | persisted global-scope `SCHEMA-RR-01` | the complete table above |
| `wiki config resolve-root --root-id <root_id> --json` | success is the ephemeral, schema-valid `SCHEMA-CFG-08` for the requested root; a failed resolution emits no accepted success object | process 0 only for that success; 1 for a completed rejection/miss; 3 when resolution cannot complete |
| `wiki doctor --json` or `wiki doctor --probe --json` | `SCHEMA-CFG-03` | its `exit_code`; process and embedded exits MUST agree |
| `wiki preservation create --run-id <run_id> --json` | persisted, schema-valid `SCHEMA-CFG-10` for that run | process 0 only for `status=succeeded` and `verification_status=passed`; 1 for a complete valid failed receipt; 3 if a complete valid receipt cannot be produced or persisted |
| `wiki deployment job run --job-id <job-id> --run-id <run_id> --json` | `SCHEMA-CFG-15` | its `exit_code` |
| `wiki deployment job inspect --job-id <job-id> --json`, `wiki deployment job enable --job-id <job-id> --json`, or `wiki deployment job disable --job-id <job-id> --json` | `SCHEMA-CFG-16` | its `exit_code` |
| `wiki acquisition inspect --batch <batch_id> --json` or `wiki acquisition resume --batch <batch_id> --json` | `SCHEMA-CFG-17` | its `exit_code` |
| `wiki release inspect --id <release_id> --json`; `wiki release resume --id <release_id> [--approval <receipt>] --json` with the option present only for proposal class `human`/`policy`; or `wiki release rollback --id <release_id> --authorization <receipt> --json` | `SCHEMA-REL-09` | its `exit_code` |
| `wiki query owner --kind <wiki\|topic\|page> --id <subject_id> --json` or MCP `get_topic_owner({subject_kind,subject_id})` | `SCHEMA-CFG-02 tool=get_topic_owner`, whose `data` is `SCHEMA-CFG-19` | CLI process and embedded `exit_code` use the `SCHEMA-CFG-02` mapping below; MCP transport has no process exit and MUST preserve the same embedded code |
| `wiki contract validate --schema <wire-name> --input <relative-file> --json`, `wiki config resolve --target-ref <target_ref> --json`, `wiki alert inspect --id <alert_id> --json`, `wiki alert acknowledge --id <alert_id> --note-file <regular-file> --json`, `wiki alert retry --id <alert_id> --json`, or `BACKUP_SNAPSHOT=<resolved-snapshot> RESTORE_ROOT=<empty-dir> GIT_CORE_SYMLINKS=false make restore-test` | `SCHEMA-CFG-02` with the matching `tool` discriminator | its `exit_code`: `ok=0`, `partial=2`, completed invalid/rejected `error=1`, cannot-complete `error=3`; `contract_validate` is `ok` only when `data.valid=true` |

The unescaped `SCHEMA-CFG-19` IR command spelling is exactly `wiki query owner --kind <wiki|topic|page> --id <subject_id> --json; MCP get_topic_owner({subject_kind,subject_id})`; the backslashes in the table cell merely escape Markdown column separators.

The closed `SCHEMA-CFG-02` operation registry covered by the last two rows is exactly: `list_wikis`, `search_pages`, `get_page`, `get_topic_owner`, `get_backlinks`, `get_overlap_signals`, `get_boundary_signals`, `get_stale_pages`, `get_questions`, `trace_page_sources`, `get_changelog`, `get_pipeline_health`, `proposal_status`, `capture_question`, `capture_note`, `capture_url`, `capture_file`, `synthesize_support`, `contract_validate`, `resolve_target`, `alert_inspect`, `alert_acknowledge`, `alert_retry`, and `restore_test`. Every registered CLI or MCP adapter for one of those operations MUST return that discriminator and its mapped `data` shape; the table does not authorize an unregistered alias. For every CLI adapter, process exit MUST equal embedded `exit_code`. For MCP, the validated envelope's embedded code is authoritative even though there is no operating-system process exit at the caller. The total mapping is `status=ok → 0`, `status=partial → 2`, completed `status=error → 1`, and could-not-complete `status=error → 3`; no other pair is legal.

An operator may validate a persisted result with `wiki contract validate --schema <wire-name> --input <relative-or-operator-file> --json`; that validator returns `SCHEMA-CFG-02` and does not replace the command's own exit authority. Outer `status=ok` alone is insufficient: acceptance requires process exit and embedded `exit_code` zero, `tool=contract_validate`, the requested wire/schema binding, `data.valid=true`, and empty `failed_rule_ids` and `errors`.

## `PIPE-G-07` — reporting and terminal result

When it runs, the global finalizer assembles deterministic counts, per-wiki summaries, acquisition/source failures, held approvals, release state, cost/token availability, and alerts. Before the terminal result is sealed, it atomically persists a `SCHEMA-CFG-18` backup request binding the latest durable run, batch, release, committed journal sequence, exact repository heads, event high-water mark, `backup_surface=shared_stage3`, the configured `target_ref`, exactly the requested roots `raw/objects`, `raw/_index`, and `state/events`, `restore_required=true`, and its own request digest. A request is an immutable snapshot demand, not proof that bytes were backed up. Failure to durably validate that request selects the `SCHEMA-RR-01` global `failed + backup_failed` pair; after a valid request exists, later independent-job failure cannot rewrite the immutable pipeline result. Optional prose cannot change the machine result.

## `PIPE-REC-08` — independent backup and dead-man boundary

`SCHEMA-CFG-04.jobs` MUST configure three distinct scheduler entries: `job.pipeline.nightly`, `job.backup.independent`, and `job.deadman.independent`. Neither independent job is a child, descendant, `trap`, or post-command of the pipeline process. Receipt path, required fields, age-policy reference, missing-receipt action, alert route, and launcher identity are exactly the corresponding `SCHEMA-CFG-04` fields.

For `job.pipeline.nightly`, the scheduler protocol is executable and ordered. The wrapper (1) atomically persists and flushes the `SCHEMA-CFG-11` start variant with `child_status=not_checked` before launching the child; (2) waits for that exact child and validates a global `SCHEMA-RR-01` if one exists; (3) for a present result, constructs the complete `SCHEMA-CFG-12` join except `scheduler_completion_sha256`, hashes that acyclic RFC 8785 projection, and atomically persists the completion with `child_status=present`, that hash as `child_receipt_digest`, and the native exit; for no result it persists the completion with `child_status=missing`, null child digest, and the native exit; and only then (4) hashes the full completion, inserts that value as `SCHEMA-CFG-12.scheduler_completion_sha256`, and persists `SCHEMA-CFG-12` as `succeeded`/`failed` or `missing`. `global_result_sha256` independently binds the actual global result; the child digest never aliases it and never hashes a value that includes itself. If the launcher child dies but the wrapper survives, steps 3 and 4 still run with `status=missing`; no pipeline finalizer or terminal result is invented. If the wrapper dies, only the flushed start exists—there is no completion and no `SCHEMA-CFG-12`—and the independent dead-man detects that exact absence. `SCHEMA-CFG-15` is the discriminated result returned by a manual job run and carries its matching concrete receipt; `SCHEMA-CFG-16` is the discriminated inspect/state-mutation result and carries the same typed receipt union or explicit null when none exists.

`job.backup.independent` consumes outstanding `SCHEMA-CFG-18` requests and also runs on its own schedule. Lock creation is serialized by the lock coordinator: the backup snapshot lock conflicts with acquisition and publication locks, and those mutators reciprocally refuse to start while the snapshot lock exists. `on_busy` behavior comes from the job config. Once fenced, the job rereads and validates the request, requires its repository heads and event high-water to match the snapshot preimage, and snapshots the exact request-bound bytes, including any `SCHEMA-SO-07` plan, terminal results, `SCHEMA-REL-00` proposal, approval/authorization material, raw objects/index/events, and committed journal. `SCHEMA-CFG-13` embeds the exact request and digest; its `snapshot-manifest/1` binds target/snapshot, repositories, evidence paths, event high-water, capture time, and manifest digest; its outer inventories must equal the manifest; and its complete lock receipt/digest must prove this job/run/request acquired the snapshot lock. The job runs `make backup`, verifies every no-follow-opened manifest byte and bundle head, rechecks heads and event high-water, runs the required `SCHEMA-CFG-02 restore_test`, and only then writes the success receipt containing that passed restore receipt. Changed state, unequal source/restored inventory digests, a missing requested root, or any extra/unlisted byte invalidates the attempt.

Shared recovery evidence and the unmanaged `local_laptop` repository use distinct access domains. The `SCHEMA-CFG-18`/`SCHEMA-CFG-13` Stage-3 path is `shared_stage3` only: every repository row is `surface=shared_repository`, and its snapshot/receipt/evidence inventories MUST NOT contain personal catalog content, `local_laptop`, or a `private_repository` row. The `SCHEMA-CFG-10` preservation topology separately inventories the `local_laptop` repository bundle as `surface=private_repository` with its private access-policy reference and target/partition; all other preservation rows are shared. Therefore the `make backup` adapter MUST route the local bundle directly to that private domain and every shared bundle/evidence byte to the shared snapshot; an implementation that writes both surfaces beneath one enumerable snapshot fails before `SCHEMA-CFG-13`. No private pathname or inventory member appears in the shared Stage-3 receipt, and neither partition upgrades private content into shared evidence. Run-scratch snapshot material is backup payload, never release-journal authority. Backup scope and recovery checks are owned by `RB-RESTORE-00`, `RB-RESTORE-01`, `RB-RESTORE-02`, `RB-RESTORE-03`, and `RB-RESTORE-04`; `make restore-test` remains the acceptance interface and MUST verify the complete restored inventory plus its emitted receipt.

`job.deadman.independent` joins `SCHEMA-CFG-11` scheduler starts/completions, `SCHEMA-CFG-12` pipeline joins, and `SCHEMA-CFG-13` backup verification without acquiring a mutation lock. A launcher-death join has start + completion + `SCHEMA-CFG-12 status=missing`; wrapper death has start only. The dead-man records whichever exact condition exists in `SCHEMA-CFG-14`, writes a durable alert to the configured route, marks deployment health failed, and blocks cleanup and widened autonomy. It never fabricates a missing result or completion, claims that a finalizer survived an untrappable kill, clears a lock, advances a release, or infers that unrecorded work succeeded. A missing `SCHEMA-CFG-14` receipt is itself surfaced by scheduler state and the next `SCHEMA-CFG-03` doctor check.

If the pipeline dies, the backup job may preserve the last durable heads and incomplete journals once the lock policy proves a stable snapshot; the receipt labels that artifact as a recovery checkpoint, not a successful pipeline release. A backup failure never rewrites or rolls back an already valid current pointer and never mutates an immutable earlier run result. It produces its own failure receipt and alert, leaves the pointer truthful, and blocks `PIPE-REC-07` cleanup until the applicable `RB-RESTORE-01`, `RB-RESTORE-02`, or `RB-RESTORE-03` recovery succeeds.

Operator interfaces are fixed: `wiki deployment job inspect --job-id <job-id> --json`, `wiki deployment job disable --job-id <job-id> --json`, and `wiki deployment job enable --job-id <job-id> --json` return `SCHEMA-CFG-16` with the matching operation; `wiki deployment job run --job-id <job-id> --run-id <run_id> --json` returns `SCHEMA-CFG-15`. A state mutation succeeds only when both desired and observed `enabled` values equal the request. The receipt discriminator selects `SCHEMA-CFG-11`, `SCHEMA-CFG-12`, `SCHEMA-CFG-13`, or `SCHEMA-CFG-14`; snapshot and bundle locations are relative and resolved absolute paths are forbidden. Job IDs must be the reserved `SCHEMA-CFG-04` values, and `run_id` must validate against `SCHEMA-CFG-00`. Manual execution uses the identical lock, receipt, alert, and missing-receipt rules; it is not a bypass. Alert investigation and recovery order belong to `RB-ALERT-01`, `RB-ALERT-02`, `RB-RESTORE-01`, `RB-RESTORE-02`, `RB-RESTORE-03`, and `RB-RESTORE-04`.

## Mutation-boundary acceptance matrix

This table maps pipeline boundaries to the acceptance strategy; detailed fixture payloads and thresholds stay in plan §11 and §9.

| Boundary | Fault point | Required invariant | Acceptance owner |
|---|---|---|---|
| acquisition staging | any object/event/index write | incomplete batch invisible; inspect/resume is deterministic | `PIPE-REC-01`; plan §11 A/C/E |
| completion marker | immediately before/after publish | no partial batch appears completed; view rebuild is identical | `PIPE-REC-01`; plan §11 A/C |
| workspace creation | before/after worktree and allowlist | real repo and user work unchanged | `PIPE-W-01`; plan §11 C |
| each agent | timeout, malformed result, surviving child | later mutators do not run; terminal receipt and safe WIP exist | `PIPE-EXIT-01`, `PIPE-EXIT-03`, `PIPE-REC-02`; plan §11 A/C |
| candidate freeze | gate/verifier/candidate boundary | same base/input/diff/tree is gated, verified, and committed | `PIPE-W-06`, `PIPE-W-07`; plan §11 A/C |
| approval | wait, stale receipt, changed proposal | no lock or head mutation while held; stale approval rejected | `PIPE-G-05`; plan §11 C |
| evidence apply | before/after root head update | pointer remains previous; dependent wiki never precedes evidence | `PIPE-G-06`, `PIPE-REC-04`; plan §11 C |
| each wiki apply | before/after each head update | checkpoint matches actual head; mixed state detected | `PIPE-REC-03`, `PIPE-REC-04`; plan §11 C |
| final manifest/pointer/attestation | before/after finalization CAS and acceptance CAS | manifest has no self-reference; provisional pointer is invisible until attestation plus `pointer_advanced` validate | `PIPE-G-06`, `PIPE-REC-04`; plan §11 C |
| resume | after every journal state | repeated resume is idempotent or fails closed on unexplained head | `PIPE-REC-05`; plan §11 C/E |
| rollback | each revert candidate and pointer | no reset; rollback itself is gated, verified, and journaled | `PIPE-REC-06`; plan §11 C/E |
| independent backup | interruption, corrupt artifact, missing target or receipt | cleanup blocked, dead-man alert durable, release pointer still truthful | `PIPE-REC-08`, `SCHEMA-CFG-04`; plan §11 C/E |
| global finalizer | primary/secondary failure or launcher death | surviving finalizer preserves both causes; otherwise dead-man proves the receipt is missing | `PIPE-EXIT-04`, `PIPE-EXIT-05`, `SCHEMA-CFG-04`; plan §11 C/E |

The named fault suite extends `mock-kiro-cli.sh` without renaming existing scenarios. It must cover quiet, unhealthy, LIGHT bypass, DEEP discovery, wrong-run/input/diff bindings, hostile handoff, allowed untracked new files, dirty user state, torn acquisition, every publication checkpoint, process-group survival, approval wait/resume, backup interruption, and prior-release rollback.

## Invariants implementers may not weaken

- Acquisition and reporting run even when no wiki proceeds.
- Unhealthy evidence never wakes the writer and never displays as fresh or unchanged.
- LIGHT bypasses discovery; writer and auditor remain sequential.
- Writer sees one typed, fenced bridge and cannot read raw evidence or inbox state.
- Every blocking deterministic gate, including index coverage and CT, precedes verifier and publication.
- Verifier acceptance is bound to the exact current base, inputs, diff, and tree; its verdict text is not sufficient.
- Evidence is applied before dependent wiki commits; the final manifest and pointer are applied after all wiki heads verify.
- The accepted current-pointer tuple never names a mixed release; provisional pointer bytes without attestation and `pointer_advanced` remain invisible. Mixed heads are detectable recovery state, not successful closure.
- Every in-process branch reaches summary, monitor, alert evaluation, durable result, and backup request; independent jobs detect launcher death and perform backup.
- Recovery uses append-only checkpoints, expected-head comparison, resume, and revert; it never discards unexplained work.
- Views are disposable event projections, never committed release authority.
- Threshold values, schema fields, task status, and operator procedure prose remain in their owning siblings.
