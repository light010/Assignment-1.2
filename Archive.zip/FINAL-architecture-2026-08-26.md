# FINAL — Target Architecture

> **Purpose:** canonical system intent: principles, verified as-built evidence, target invariants and topology, permission boundaries, and the user capability contract.
> **Owns:** numeric §§0–5, `AB-*`/`AB-STR-*` adjudications in Appendix B, and the whole-set source register in Appendix C.
> **Siblings:** [index](FINAL-INDEX.md) owns set membership and namespaces; [implementation plan](FINAL-implementation-plan-2026-08-26.md) owns stages, packages, decisions, thresholds, uncertainties, acceptance, and history; [todo](FINAL-todo-2026-08-27.md) owns mutable delivery state; [pipeline](FINAL-pipeline-2026-08-27.md) owns execution, locking, exits, publication, and recovery; [contracts](FINAL-contracts-2026-08-27.md) owns machine shapes and transitions; [runbooks](FINAL-runbooks-2026-08-27.md) owns human procedures.
> **Last updated:** 2026-08-27.
> **One fact, one home:** this file states WHAT and WHY. Exact execution is `PIPE-*`, exact machine data is `SCHEMA-*`, mutable values are `TH-*`, delivery is package/`T-*`, and operator action is `RB-*`.

The whole set supersedes the retired design/review/build artifacts recorded in plan Appendix A. Retired files are history, not live dependencies. The measured checkout is an analysis copy identified only by the redacted evidence records in Appendix C; the authoritative deployment is the owner decision in plan §8 and is resolved through `SCHEMA-CFG-04`, `SCHEMA-CFG-07`, `SCHEMA-CFG-08`, and `SCHEMA-CFG-09`, never by discovering an arbitrary checkout.

---

## Contents

0. [Principles](#0-principles)
1. [What exists and is kept](#1-what-exists-and-is-kept)
2. [Verified gaps and defects](#2-verified-gaps-and-defects)
3. [Target architecture](#3-target-architecture)
4. [Pipeline: orchestrator, phases, agents](#4-pipeline-orchestrator-phases-agents)
5. [What a user can do](#5-what-a-user-can-do)
- [Appendix B — Completed adjudications](#appendix-b--completed-adjudications)
- [Appendix C — Sources](#appendix-c--sources)
- [Whole-set membership and ownership](FINAL-INDEX.md)
- In the plan: §6 Delivery roadmap · §7 Work packages · §8 Owner decisions · §9 Thresholds · §9.2 as-built values · §10 uncertainties · §11 acceptance · Appendix A history

---

## 0. Principles

1. **Markdown in git is the authored truth.** Everything else is evidence, policy, or a rebuildable view.
2. **Evidence is immutable and separately governed.** `raw/` is written by connectors only, content-addressed, full-hash, and never by an LLM. Persistence beyond fixtures is blocked by decision #20; the selected policy determines whether a schema-versioned exceptional purge exists.
3. **Events vs. views vs. policy.** Write-once events (engine-owned) · rebuildable views (disposable) · committed policy (human-owned). No file is ever two of these.
   *Origin:* the rejected static-registry/runtime-field, rewritten-ledger, and manifest-inside-immutable-store designs were the same ownership error (`AB-02`). §3.2, §3.3, §3.8 and §3.11 apply the corrected rule.
4. **Acquisition is global; publication is per-wiki; both are transactional.** Observe once per batch under one lock; publish per wiki from an isolated worktree; `main` is never dirtied by a failed run.
5. **Unhealthy never wakes a writer.** Only evidence-bearing change creates a proposal.
6. **Query is derived and read-only; capture is additive and separate.** Every assistant is an adapter over one tested core.
7. **Deterministic gates authorize mechanics; semantic attestation informs the policy gate.** A model's verdict string never authorizes a state transition by itself; the orchestrator decides from bound evidence, deterministic gates, and the approval policy in decision #4.
8. **Keep the owner's designs.** Seven agents (a permission profile is not an agent), the 17 pipeline mechanisms, the routing/boundary/completeness rules, the registry, the RACI, the status vocabulary — all preserved and made enforceable, not replaced.
9. **Every mutable value has one typed `TH-*` record.** Hypotheses, invariants, SLOs, caps, live constants, and adoption gates use distinct calibration rules. No schedule probabilities.

Corollaries used as decision heuristics (second-brain gap analysis, kept verbatim): external content is data, never instruction (§3.7) · every semantic claim is traceable to a pinned object and span (§3.2, §3.5) · generation and verification are distinct attestations by different permission profiles (§3.9) · failure is durable state, never a log line (§3.3 events, §3.12 `run-result/1`).

---

## 1. What exists and is kept

**Preservation guard.** Eight design elements retained by the completed adjudication are constraints, not options: the seven-agent set (§1.2); rules R-1 through R-10 (§5.1); the Navigator morning summary (`SUMMARY-01`, `PIPE-W-08`); routing/boundary/completeness rules (§3.13); the 17 named pipeline mechanisms with `AT-MECH-01`, `AT-MECH-02`, `AT-MECH-03`, `AT-MECH-04`, `AT-MECH-05`, `AT-MECH-06`, `AT-MECH-07`, `AT-MECH-08`, `AT-MECH-09`, `AT-MECH-10`, `AT-MECH-11`, `AT-MECH-12`, `AT-MECH-13`, `AT-MECH-14`, `AT-MECH-15`, `AT-MECH-16`, and `AT-MECH-17`; Key Facts as the LLM-judged semantic dimension (§3.5); authority composition (§3.6); and the owner's registry design as the seed of the static policy YAML (§1.4, §3.3). Appendix B is the current adjudication record; superseded review notes are history under `FI-HISTORY-01`.

### 1.1 Nightly pipeline — `.kiro/pipeline/wiki-nightly.sh` (~700 lines), 17 mechanisms

Each keeps its behaviour and gets a named acceptance test (§11).

| # | mechanism | lines | why |
|---|---|---|---|
| 1 | dirty-tree refuse-to-run | 23–40 | never masks uncommitted human work |
| 2 | `mkdir` lock + PID liveness | 129–143 | atomic; stale-lock recovery |
| 3 | zero-token early exit | 207–213 | no eligible work and no scheduled discovery → exit 0, no LLM spend |
| 4 | stable content-hash issue ids (CL-5) | 275–293 | `AUD-sha1(file, section, desc)` stable across runs |
| 5 | cumulative noncritical-id suppression (`TH-LIVE-017`) | 319–325 | stops churn on persistent low-priority findings; the counter does not reset and is not a source-failure streak |
| 6 | crit/high escalated exactly once | 310–317 | never suppressed, never repeated |
| 7 | suppression circuit breaker (`TH-LIVE-015`) | 334–338 | clears the suppression list when the ratio trips; it does not reset the cumulative noise tracker |
| 8 | fix-gate HALT on score regression | 627–629 | auto-fix stops when issues increase |
| — | (5–8 together are the owner's *one throttle system*: they bound finding repetition; cumulative suppression and circuit behavior are `TH-LIVE-015` and `TH-LIVE-017`, while recipe action caps are `TH-TGT-035`, `TH-TGT-036`, and `TH-TGT-037`) | | |
| 9 | two-run recovery for the gate (`TH-LIVE-020`; target `TH-TGT-077`) | 632–637 | the live fix gate re-enables after two non-negative issue deltas; the target requires two eligible healthy runs and preserves the incident approval gate |
| 10 | branch → verify → merge (CL-0a) | 503–574 | rollback on verify FAIL; merge only with `AUTOMERGE_ENABLED` + CT-gate |
| 11 | CT-DoD gate with `ENFORCE_*` flags | `orchestrator/ct-gate.sh`, `enforcement.env` | warn-first, flip per check |
| 12 | post-writer changed-files recompute | 244–249 | auditor sees this run's edits |
| 13 | empty-cycle guard | 533–537 | no empty merge commits |
| 14 | per-wiki stagger (`TH-LIVE-014`) | `orchestrator/run-pipeline.sh:115-117` | no MCP/rate-limit contention; serialization is a separate invariant |
| 15 | outcomes rotation (`TH-LIVE-016`) | 616–618 | bounded disk |
| 16 | `LC_ALL=C grep -a` stub gate | 651 | survives emoji placeholders |
| 17 | `unbuffer` PTY for `kiro-cli` under launchd | 106–107 | headless agents actually run |

`CL-n` labels (CL-0a, CL-5, CL-8) are the identifiers the script's own comments and the owner's hardening changelog use for these mechanisms; kept verbatim so tests and grep stay anchored [UNCERTAIN: the expansion of "CL" is not stated in the repo].

Phases as built: pre-run → 0 pre-flight (deterministic) → 0.5 discovery (Sunday) → 1 ingest → 1.5 writer (conditional on `proceed=true`) → 1.9 audit → noise tracker → H-P1, H-W6, H-P5 → 2 triage → 3 librarian (on branch) → 4 verify → CT-gate → merge/keep → end loops (outcomes, quality-gate delta, stub ratio, metrics) → post-run (crosslinks, llms). `run-pipeline.sh:84-110`: `RC=99` → "❌ FAIL".

### 1.2 Seven agents — and why seven

The measured `.kiro/agents/*.json` set contains navigator, ingestor, writer, auditor, advisor, librarian, and researcher profiles (`AC-EV-07`). The unavailable historical rationale for combining adjacent roles is not an implementation dependency. **Constraint kept:** the verifier is a second permission profile using the auditor rubric, not an eighth cognitive role; `VER-01` generates and proves that profile rather than relying on a missing historical file.

### 1.3 Deterministic control plane — `orchestrator/` (23 scripts + 6 Python, 4,081 lines measured in the analysis copy; an earlier 5,445 figure could not be reproduced)

`validate.sh` (BLOCKING: links, frontmatter, registration, one-canonical, prompt-drift; ADVISORY: orphans, stubs, collisions, timeless, boundary, changelog) · `ct-gate.sh` · `enforce-readiness.sh` · `allocate-filename.sh` · `generate-llms.sh` (`llms.txt` + twins + `llms-full.txt`) · `generate-completeness.sh` · `generate-ownership-index.sh` · `minhash-overlap` · `boundary-lint` · `check-prompt-drift.sh` (OK / SUPERSET / DRIFT — the model every subsequent drift check extends) · `changelog-lint.sh` · `link-check.sh` · `timeless-lint.sh` · `source-hash*.sh` + `source_hash_lib.py` + `hp5-drift-check.py` · `backup-bundles.sh` · `bootstrap-wiki.sh` + `validate-wiki-setup.sh` (NW-DoD; NW-DoD-6 = every `AGENTS.md` build/validate command exits 0 in `--dry-run`) · `migrate-frontmatter.sh` (v0→v1; the measured 2026-08-26 copy has `schema_version` and `doc_type` on 127/127 pages) · `generate-llms.sh` groups `llms.txt` by `doc_type` (Explanation / How-to / Reference / Optional); a consumer-facing version stamp and "answers changed" changelog on `llms.txt` are excluded from this delivery contract · `mirror-onedata-docs.sh` (539 lines; a `raw/` layer in embryo) · the **1,035-line three-level test harness** `aidlc/.kiro/pipeline/test-pipeline.sh` + `tests/` with scenario-driven `mock-kiro-cli.sh` (`MOCK_SCENARIO`). The Python inventory is not stdlib-only: `minhash-overlap.py` imports `datasketch`, supplied in the measured installation by the external wiki-tools environment; `RUNTIME-01` must put target Python dependencies under the locked project.

### 1.4 The owner's designs the target absorbs

The dated quantities in this subsection are retained measurements of the 2026-08-26 source snapshot, not operative schedules, deadlines, caps, estimates, or authority rules. Runtime values exist only when plan §9 or §9.2 assigns an exact `TH-*` ID.

- **`.kiro/steering/onedata-sync-monitor.md`** (485 lines) — a source registry: velocity tiers (weekly / bi-weekly / monthly), Key Facts (three assertions per source), status vocabulary FRESH / STALE / CRITICAL / NOT STARTED / IN PROGRESS, CQL `lastModified` sweeps per space, Deep-Sync procedure, RACI (§4), escalation (same-day review → Kiro drafts → BLOCKING question → Slack `#data-platform-engineering`), §9 limitations (*"MCP tools don't return version numbers"*; Key Facts manual; pull-only; cross-space moves break CQL) and planned items (REST version script 2 h, Confluence watch 30 min, Key-Facts diff 4–6 h, dashboard). It becomes the *seed* of the policy registry and is regenerated as a view.
- **`routing-rules.md`** (Q1 which wiki / Q2 edit-create-link-split; the new-wiki trigger uses `TH-TGT-043` and `TH-TGT-044`, followed by human bootstrap) · **`wiki-boundary-rules.md`** (golden rule, litmus test, anti-patterns, grep patterns) · **`wiki-completeness-methodology.md`** (six-section open-questions template; Research → Documentation → Verification → Maintenance). Topic placement is distinct from source provenance and is not retired by the registry.
- **Authority snapshot**: `project-context.md` records the source-specific tier ordering, a dated revalidation rule, and the instruction to flag uncovered authority rather than invent it; `.kiro/steering/project-context.md` and the sync monitor record the OneData portal carve-out. These are source evidence for the normalized policy in §3.6, not runtime literals. `project-context.md:21` "KB → local wiki → Confluence" is lookup order, not authority.
- **Morning summary**: the completed adjudication retains the designed-but-unbuilt Navigator summary as `SUMMARY-01` and `PIPE-W-08` (`AC-EV-08`). No absent historical plan is a live dependency. Event-driven triggers, writer self-review loops, and worktrees-for-parallelism remain rejected; worktrees are adopted only for isolation.
- Seven Kiro knowledge bases; the assistant rules *Citation Required* and *Never Deflect* kept verbatim.
- `local_laptop`: unmanaged by the owner's decision (`AGENTS.md`); private.

### 1.5 Deliberately not added

Excluded from this delivery contract: reader feedback/broad usage analytics, an OKF-compatible export profile, an 8th agent, Ingestor ∥ Auditor parallelism, outbound owner notifications, Playwright by default, GitHub remotes, DVC/git-annex, multi-host locking, event-driven triggers, a second `index.md`, a universal metadata model, and an admin/mutation MCP. SQLite/FTS5, Docling, GROBID/OCR, vectors, LangGraph, Neo4j, DSPy, Semantica, vector databases, and Crawl4AI are not allocated packages; only the exact §6 Stage-6 adoption gates may produce a reviewed adopt/reject record.

---

## 2. Verified gaps and defects

### 2.1 Defects in the as-built system (present on the live machine too)

The table lists as-built defects. Distinct from these are six rejected design variants that would have shipped as real bugs — a "static" registry with engine fields, an "append-only" ledger that gets rewritten, observation running five times per night, a manifest inside a write-once tree, auth failures waking the writer, and `git add -A` in a failure trap; all are closed in §3 and recorded in plan Appendix A.

| # | defect | evidence |
|---|---|---|
| D-a | writer mutates `main` before a branch exists; the rollback path contains a destructive reset/clean sequence | `wiki-nightly.sh` 240 (`run_agent "writer"`) vs 504 (`WORK_BRANCH`); 559–572 |
| D-b | verify phase = the auditor with `wiki/**` write | `wiki-nightly.sh:515` `run_agent "verify" "auditor"`; `auditor.json` `toolsSettings.write.allowedPaths: ["wiki/**", …]`; no `verifier.json` |
| D-c | librarian may write `.kiro/steering/**` and run `git commit/checkout` | `librarian.json` |
| D-d | freshness false-green: 70/70 checks SKIP on an HTML login page (aidlc 4, aws 26, databricks 4, jenkins 32, bitbucket 4) and print `drift: 0` | `*/.kiro/hp5-drift-result.json`; `hp5-drift-check.py:29` "Fetch failures never change the exit code"; `source_hash_lib.py:50-56` classifies HTML as "transient". Structural cause: a violation of principle 7 — a missing capability reported as implicit PASS instead of explicit SKIP |
| D-e | 7 active Jenkins pages absent from `00-index.md` and the llms bundle: `01-platform-overview, 02-basket-management, 05-aws-lambda-jobs, 08-artifact-management, 09-cicd-patterns, 10-docker-images, 11-bitbucket-integration`. Why no gate caught it: the index was rebuilt one-page-per-slot during collision cleanup; the dropped pages stay cross-linked, so link-check and orphan-check pass — reachability was verified, index membership was not. The gate measured the wrong invariant (fixed by `index-coverage-lint.sh`, IDX-01) | `jenkins/wiki/00-index.md` |
| D-f | `owner: unassigned` × 127; `topics[]` empty; no `canonical:` | frontmatter |
| D-g | 22 NN collision slots / 15 deprecated pages. Jenkins numbers 01–10 all collide — two merged generations (a basket/pipeline set and an aws/databricks/docker set) — so onboarding runs the allocator plus a de-orphan pass, not a one-line dedup | `validate.sh` collision report; `RENUMBER-01` |
| D-h | secret scan is a skeleton (4 patterns, `"false"`) | `ct-gate.sh:72-75` |
| D-i | `#!/opt/homebrew/bin/bash` hardcoded; `wiki-nightly.sh:107` hardcodes `gtimeout … unbuffer kiro-cli --trust-all-tools` with no fallback | shebangs; line 107 |
| D-j | all 7 agent JSONs use `toolsSettings`, deprecated in Kiro CLI 3.0 / IDE 1.0 in favour of `permissions` | kiro.dev configuration-reference |
| D-k | no `pyproject.toml` / lock even though `minhash-overlap.py` imports `datasketch` from an external environment | tree; `minhash-overlap.py` imports |
| D-l | backup = git bundles only; will not cover `raw/` objects or `state/events/` | `backup-bundles.sh` |
| D-m | employee e-mails in a steering file | `onedata-sync-monitor.md:89` → remove |
| D-n | inline `[[ -x "$TOOL" ]]` guards silently skip the CT-DoD merge gate and crosslink pass when an executable bit is lost | `wiki-nightly.sh:350,366,525,693,696`; `RUNTIME-01` makes missing files fail loudly |
| D-o | `enforce-readiness.sh` does not assert that each gate is structurally able to fail, nor an owner-coverage floor | current script plus 127/127 `owner: unassigned`; `READY-01`, `TH-TGT-017`, `TH-TGT-018` |
| D-p | code samples cite packages that do not exist; no fenced-block validator | `aws/wiki/04` examples; `CODE-01` |
| D-q | all seven agent JSONs contain a 32-file AIDLC framing although they are shared across five wikis | `grep -n "32-file" .kiro/agents/*.json`; `RUNTIME-01` injects typed wiki config |

### 2.2 Structural gaps (G-1..G-12)

| # | gap | evidence |
|---|---|---|
| G-1 | **No `raw/` layer.** Karpathy's layer 1 is remote-only; `source-hash` proves a source changed but never *what* changed | mirror output outside the repo, destructively deleted each run |
| G-2 | **Two provenance systems that barely intersect.** Registry tracks 23 Confluence ids → **1** in any frontmatter `source[]`; 17 OneData GROUND-TRUTH sections → **0**; 11 pages cite InnerSpace, 22 cite OneCICD, all inline prose | frontmatter of 127 pages vs registry |
| G-3 | **Two freshness systems, neither aware of the other**: `hp5-drift-check` (nightly, hash, Confluence-only, 0 % coverage) and the sync-monitor (interactive, key facts, tiered, manual); version numbers captured by neither | `hp5-drift-result.json` ×5; monitor §9 |
| G-4 | **Only Confluence and public web are fetched.** InnerSpace, OneCICD, repos: no connector; the OneData mirror generalises with three variables but is wired nowhere | `mirror-onedata-docs.sh` |
| G-5 | Discovery never ran for jenkins or bitbucket; aws last 2026-06-24 | `*/.kiro/discovery-manifest.json` |
| G-6 | Kiro KB is not part of the nightly; per-agent isolated; seeded once; never refreshed; unreachable from Claude Code / Copilot | grep `knowledge`; kiro.dev |
| G-7 | Per-wiki steering inconsistent: aidlc 159 lines, aws 184, databricks 10, bitbucket 13, jenkins 13 | `wc -l` |
| G-8 | Handoff protocol is an injection vector independent of tooling (keys on `## WRITER INSTRUCTIONS`-style headings) | `write-handoff.template.md:13` |
| G-9 | Only the Kiro workspace has the configured ADP MCP servers; Claude Code and Copilot lack generated project guardrails/config | `source-hash.sh:24-28`; `reports/adp-skills-mcp-inventory-2026-08-14.md`; `FRAMEWORK-01` |
| G-10 | Two precedence statements never composed; AWS-only steering is Confluence-first with no portal carve-out | root vs `.kiro/steering/project-context.md` |
| G-11 | No token/cost accounting; no `DECISIONS.md`; no auth runbook; `local_laptop` policy undecided | `metrics.jsonl` |
| G-12 | No query surface over graph/frontmatter; crosslink JSON is a node list, so backlinks, rename safety, stale/owner/runbook filtering need repository scans | `orchestrator/crosslinks-inbox.json`; `QUERY-01` |

### 2.3 Not defects — copy artifacts of this checkout

Audit lesson from the completed review evidence: five of seven discarded claims came from agents treating this analysis copy as the production system. Every audit must state the deployment topology (live tree vs copy, what a copy loses) before the first agent instruction, or the agents will infer a broken system.

30 lost executable bits · 64 missing parent-relative symlinks in five child repos · account-specific paths in plists and two scripts · absent qualified Bash, timeout, PTY, and Kiro executables in the analysis environment. None is a work item because each is an artifact of the redacted analysis copy rather than a verified production defect.

---

## 3. Target architecture

End-to-end data flow (one nightly; details in the sections named on each edge):

```mermaid
flowchart LR
  subgraph SRC[Sources]
    CF[Confluence REST]
    PT[Portals ×3]
    RP[Repos]
    WB[Web]
    MN[wiki capture]
  end
  subgraph ACQ["PIPE-G-01 and PIPE-G-03 — one batch and global acquisition lock"]
    PL[SCHEMA-SO-07 acquisition plan]
    EG[§3.4 centralized egress guard<br/>KIRO-SEC-01R shared implementation owner]
    CN[PIPE-G-03 source acquisition]
    SG[§3.7 source pre-persistence classification<br/>KIRO-SEC-01R shared implementation owner]
  end
  subgraph CAP[SCHEMA-CP-04 atomic capture boundary]
    CG[§3.7 capture classification<br/>CAPTURE-01 enforcement adapter]
    CE[SCHEMA-CFG-02 rejected capture result<br/>no proposal id]
  end
  subgraph RAW[Evidence + state]
    OB[(SCHEMA-SO-01 raw objects)]
    EV[(SCHEMA-SO-02 acquisition events)]
    IX[(SCHEMA-SO-05 object index)]
    EN[(SCHEMA-SO-08 event envelope)]
    MK[(SCHEMA-SO-09 completion marker)]
    QA[(SCHEMA-SO-06 source quarantine receipt)]
    AS[(SCHEMA-SO-03 semantic assessments)]
    VW[SCHEMA-SO-04 derived views]
    IB[(SCHEMA-CP-01, SCHEMA-CP-02, and SCHEMA-CP-04 contribution state)]
  end
  subgraph PUB["PIPE-W-01 through PIPE-W-08 — per-wiki sibling workspace"]
    IN[PIPE-W-04 extraction and assessment]
    TP[SCHEMA-CP-03 staged proposal projection]
    ST[SCHEMA-RR-04 one fenced bridge]
    WR[PIPE-W-05 writer]
    LB[PIPE-W-05 librarian]
    VF[PIPE-W-07 and SCHEMA-RR-02 verifier]
    RM[SCHEMA-REL-01 and SCHEMA-REL-02 evidence-first release]
  end
  subgraph QRY[SCHEMA-CFG-02 read-only retrieval]
    CLI[wiki CLI query]
    MQ[wiki_mcp_query adapter]
  end
  subgraph CL[Clients]
    CC[Claude Code]
    CP[Copilot]
    KR[Kiro]
  end
  CF & PT & RP & WB --> PL --> EG --> CN --> SG
  SG -->|every planned attempt| EV --> EN --> MK
  SG -->|persisted payload| OB --> IX --> MK
  SG -->|rejected source bytes| QA --> MK
  PL -. plan digest .-> MK
  MK --> VW
  MN --> CG -->|allowed capture| IB
  CG -->|rejected shared capture| CE
  OB & MK & VW --> IN
  IN --> AS --> VW
  IN --> ST
  IB --> TP --> ST --> WR --> LB --> VF --> RM
  RM --> CR[canonical wiki repos]
  CR & VW --> CLI & MQ
  MQ --> CC & CP & KR
```

Read it with §0: the ACQ plane runs once per global batch, the PUB plane runs once per managed wiki, capture reaches only its atomic contribution boundary, and the query/client planes cannot write.

### 3.1 Planes × layers

Layers describe **storage ownership**; planes describe **execution and permission boundaries**. Both hold.

| layer | path | written by | invariant |
|---|---|---|---|
| **`raw/`** evidence | control-plane repo `raw/objects/**` (immutable) + `raw/_index/**` (segmented) | connectors only; never an LLM | Kiro `fs_write` deny + `raw-immutability-lint.sh` as **both** pre-commit hook (fast feedback only — hooks are bypassed by `--no-verify` and are not cloned or bundled) **and** BLOCKING CT/release-gate check (the enforcement) |
| **`wiki/`** canonical | `<wiki>/wiki/**` + per-wiki `log.md` | writer/librarian inside a worktree, behind deterministic gates + verifier | CT-gate · release manifest · `index-coverage-lint` |
| **policy** | `.kiro/steering/**`, `orchestrator/schemas/**`, `state/source-registry.yaml`, `.kiro/steering/authority.yaml`, `DECISIONS.md` | humans + orchestrator scripts | no agent write |
| **runtime state** | `state/events/**` (write-once), `state/views/**` (rebuildable), `state/inbox/**`, `state/releases/**`, `state/runs/**` (gitignored) | orchestrator (inbox dispositions are human-adjudicated, engine-written) | events never rewritten; views always rebuildable |

```mermaid
flowchart LR
    S[Sources] --> A[PIPE-G-03 global acquisition<br/>one lock and one batch id]
    A --> J[SCHEMA-SO-02 acquisition observations]
    A -->|persisted payload| E[SCHEMA-SO-01 immutable objects]
    E --> OIDX[SCHEMA-SO-05 object index] --> K[SCHEMA-SO-09<br/>completed batch boundary]
    J --> N[SCHEMA-SO-08 event envelope] --> K
    A -->|rejected source bytes| QR[SCHEMA-SO-06 source quarantine receipt] --> K
    K --> V[SCHEMA-SO-04 derived health]
    K --> W[PIPE-W-01 sibling workspace]
    W --> P[PIPE-W-04<br/>SCHEMA-SO-03 assessment and SCHEMA-CP-03 projection]
    P --> G[PIPE-W-06 deterministic gates] --> VFY[PIPE-W-07 bound semantic attestation] --> R[SCHEMA-REL-01 and SCHEMA-REL-02 release set] --> M[Canonical Markdown repos]
    M --> D[SCHEMA-CFG-01 catalog plus SCHEMA-SO-04 views]
    V --> D
    D --> C[SCHEMA-CFG-02 read-only CLI] & MCP[SCHEMA-CFG-02 read-only MCP adapters]
    U[User capture] --> INBOX[SCHEMA-CP-01, SCHEMA-CP-02, and SCHEMA-CP-04<br/>inbox-only contribution plane] --> P
```

### 3.2 `raw/` — the evidence store

`raw/objects/**` stores content-addressed, immutable payload bundles; `raw/_index/**` stores write-once observation-to-object mappings; `raw/quarantine/**` stores write-once, content-free rejection receipts. The object identity, compression identity, filenames, forbidden observation metadata, and payload validation are solely `SCHEMA-SO-01`. Acquisition records are solely `SCHEMA-SO-02`; their observation-to-object mappings are solely `SCHEMA-SO-05`.

The evidence invariant applies to all three write-once stores, not only `raw/objects`: Kiro denies them, and the blocking immutable-path gate rejects modification/deletion of objects, prior `_index` segments, quarantine receipts, completed event segments, or batch markers. Secret/PII policy runs before content persistence; rejected bodies are not copied into ordinary logs, patches, backups, or proposals. Locator, revision, attempt time, URL, ETag, authority, retention, and error facts are observation or policy facts and therefore never enter object metadata.

No symlink identifies “latest”; locator and current-health views are rebuilt from completed events. Full hashes are stored; display prefixes are presentation only. Decision #20 and `RETENTION-01` are a pre-Stage-3 persistence stop: until they close, only fixture evidence may exercise this store. The pending profile preserves and isolates evidence and gives page `legal_hold` only an autonomous edit/retire freeze; it does not infer purge consequences. `SCHEMA-CFG-01` and `RB-RESTORE-04` define that boundary. Storage caps, compression, growth, split, and recovery targets are `TH-TGT-012`, `TH-TGT-013`, `TH-TGT-014`, `TH-TGT-019`, and `TH-TGT-020`.

Legacy mirrors/manifests are imported once, archived recoverably, and replaced by generated projections only after the import receipt exists. Migration never uses autonomous deletion. The semantic ingest pattern—takeaways, contradiction flagging, per-source trace, and page log—remains, but the exact proposal and evidence forms are `SCHEMA-SO-03`, `SCHEMA-CP-01`, `SCHEMA-CP-02`, `SCHEMA-CP-03`, `SCHEMA-CP-04`, and `SCHEMA-RR-04`.

### 3.3 Source registry — policy, events, views

| file | owner | holds | written by |
|---|---|---|---|
| `state/source-registry.yaml` (committed, PR-reviewed; config schema `source-registry.schema.json`) | **humans** | identity, locator, kind, deployment/API profile, authority domain, RACI/contact, cadence policy, Key Facts, wiki references, connector, auth profile, retention class, status policy — **static fields only** | never by the pipeline; schema rejects runtime fields |
| `state/events/YYYY/MM/DD/<batch_id>.jsonl` | **the engine** | acquisition and later semantic-assessment records | write-once completed segments; retention is conditional on decision #20 and never implemented by rewriting a completed segment |
| `state/views/source-health-current.json`, `source-coverage-current.json` | `build-views.py` | last attempt, last success, next due/retry, consecutive failures, current revision, derived presentation | rebuilt from events any time |

`SCHEMA-CFG-01` is the only normative registry shape. It rejects runtime fields and the stale token `retain_class`; `retention_class` is canonical. Key Facts are bounded by `TH-TGT-045`. `wiki source status <ref>` and all health output join static policy to disposable views; neither side mutates the other.

`SCHEMA-SO-02` records connector-time acquisition facts. `SCHEMA-SO-03` records later per-wiki semantic assessments and Key-Facts comparisons. They share source/batch/observation identities but never overwrite or masquerade as one record. Durations, attempt cardinality, failures, and zero-denominator coverage behavior are explicit. Completed events are release members; views are gitignored and reconstructed only from completed events. The initial `SCHEMA-SO-04` variant is the only empty-event projection: `generated_from_batch`, `latest_attempt`, `latest_success`, `assessment_ref`, and `coverage_scope.batch_id` are null; acquisition is `not_attempted`; source condition is `unknown`; semantic state is `not_assessed`; core state is UNVERIFIED; diagnostic `DUE_UNKNOWN` is present; and its claim-coverage metric is null with `undefined_reason=zero_reachable`.

Registry/frontmatter reconciliation is additive and approval-gated. It preserves native `source[].id`, adds `source_ref` and normalizer provenance, and treats the existing truncated page `source_hash` as distinct from full object hashes. `protected` is delivered by the early `AUTH-02` milestone before Stage 3: absent-source and human-authored pages default to propose-only behavior. Source coverage and ownership/provenance gates are `TH-TGT-001`, `TH-TGT-017`, and `TH-TGT-018`; answer-accuracy and citation-recall evaluation remain the separate Stage-6 `TH-TGT-002` and `TH-TGT-003` contracts.

### 3.4 Connectors — `SourceProvider`, one interface, N implementations

Providers implement discover, observe, revision, and change-candidate capabilities behind one typed interface. The canonical package home is `src/wiki_core/providers/{base,confluence_rest,portal,repo,web,notes}.py`; any `orchestrator/` entry is a thin command adapter, never a second provider implementation. `RUNTIME-01` owns the locked Python environment, including `httpx`, Pydantic, parsing libraries, and the existing `datasketch` dependency.

Confluence REST, each of the three portal profiles, repo, web, and manual/note inputs have separate package rollout receipts. They emit `SCHEMA-SO-01` and `SCHEMA-SO-02`, never authored pages. REST deployment type and auth close only through `AR-16` and `T-AR-16`; interactive MCP revision exposure closes only through `AR-13` and `T-AR-13` and is not inferred from REST. Portal index/auth questions close through `AR-14` and `AR-15`. All connectors use scheduled pull; event-triggering remains rejected.

Connector configuration supplies proxy/CA/auth profile identifiers, pagination, rate policy, and `TH-TGT-004`, `TH-TGT-005`, `TH-TGT-006`, `TH-TGT-007`, `TH-TGT-008`, `TH-TGT-009`, `TH-TGT-010`, `TH-TGT-046`, `TH-TGT-047`, `TH-TGT-048`, and `TH-TGT-049`; secrets remain outside versioned configuration. Normalized content hashes are authoritative for change. ETag, search-index hash, sitemap dates, and HTTP metadata are hints retained in acquisition records, not object identity.

All ordinary URL acquisition, including `capture_url`, uses the same centralized egress guard as browser workers: allowlisted schemes/domains; initial and redirect target validation; rejection of loopback, private, link-local, metadata, and DNS-rebinding destinations; bounded body/redirect/depth; no caller-supplied profile, output path, hook, proxy/CDP endpoint, script, or webhook. Browser acquisition is a separately sandboxed fallback, never authority to relax TLS. Raw response, headers, final URL, and redirect-chain digest are preserved only after secret/PII policy permits persistence. LLM extraction produces a proposal; it never directly writes evidence or authored content.

### 3.5 Freshness — three dimensions, derived presentation

`freshness-engine.py` replaces both live `hp5-drift-check.py` fetches and the manual monitor. Stage 1 first makes missing/unusable evidence explicit; Stage 3 cuts over to completed acquisition and assessment events. Compatibility projections are disposable views and carry `generated_from_batch`; consumers never treat a missing view as an unchanged source.

| dimension | values |
|---|---|
| `acquisition` | `observed` · `partial` · `unavailable` · `unauthorized` |
| `source_condition` | `unchanged` · `drifted` · `suspected_removed` · `confirmed_removed` · `conflict` · `unknown` |
| `semantic` (Key Facts, LLM-judged) | `not_assessed` · `supported` · `mismatch` · `insufficient_evidence` |

Execution status lives in `run-result/1` (`status {succeeded, degraded, failed, cancelled}`); publication status lives in the proposal lifecycle `state` (§3.11, §3.12) — neither is a freshness dimension.

`SCHEMA-SO-04` owns the total derivation. CRITICAL outranks STALE; only an active, observed, unchanged, semantically supported source is FRESH; everything inadequately observed or assessed is UNVERIFIED. `CHECK`, `CHECK_FAILED`, `NOT_STARTED`, `IN_PROGRESS`, coverage, retry, and retirement labels are diagnostics, not additional core states. `partial` is always UNVERIFIED. Before the first completed batch, the schema-valid initial variant described in §3.3 projects each registered source as UNVERIFIED with `DUE_UNKNOWN`; no observed-variant fields are fabricated.

A failed attempt never overwrites success or advances cadence. A healthy first observation is actionable new evidence; an unhealthy first attempt is UNVERIFIED and never wakes a writer. Removal is suspected without a same-endpoint prior success and confirmed only by the evidence rule plus `TH-TGT-050`. Coverage has one unit and one scope. For one completed batch and one target wiki, `reachable` counts planned active source observations whose completed acquisition is `observed`; `claim_verified` counts the subset whose complete nonempty registered Key-Facts set has matching `SCHEMA-SO-03` rows with replay-valid evidence spans. A reachable source with zero registered Key Facts is not claim-verified. The value for `TH-TGT-001` is `claim_verified / reachable`; when `reachable=0`, it is null with `undefined_reason=zero_reachable`, never success. Revision-checked and evidence-retrieved are diagnostics and cannot close `AR-13`.

Key Facts remain semantic judgment recorded separately in `SCHEMA-SO-03`; a mismatch raises a review proposal and CRITICAL presentation but does not by itself authorize publication or retirement. Alerts use `TH-TGT-001`, `TH-TGT-009`, and `TH-TGT-010`. The live noise counter is not their implementation (`TH-LIVE-017` describes that cumulative counter); critical/high live alerts are immediate (`TH-LIVE-018`). Source retirement is owned by `RETIRE-01`, decision #20, `SCHEMA-CP-02`, `TH-TGT-034`, and `TH-TGT-050`.

New URL detection for already registered portal scopes is acquisition. Broader discovery runs only on the DEEP branch and emits proposals; neither path mutates registry policy directly. Completeness against the discoverable source is `TH-TGT-038`, distinct from freshness coverage.

### 3.6 Authority — one ladder, two levels

`.kiro/steering/authority.yaml` is the sole authority-policy path; `AUTH-02` generates project-context projections from it. Domain-specific authority outranks general authority:

```yaml
global_tier: {LDW: {rank: 1, scope: technical-architecture}, ADPI: {rank: 1, scope: process-approvals},
              cdomlops: {rank: 2, note: deprecated-date-check}, DCL: 2, DMTeam: 3, Data: 3, ADPDPE: 3, OCV: 3, web: 4}
domain_overrides:
  - {domain: onedata-platform,    trigger_tags: [onedata, onedatacicd, dabs, databricks-jobs], ground_truth: docs.onedata.us.caas.oneadp.com}
  - {domain: onecicd-platform,    trigger_tags: [onecicd, jenkins-pipeline, cicd],             ground_truth: docs.onecicd.us.caas.oneadp.com}
  - {domain: innerspace-platform, trigger_tags: [innerspace, particles, databricks-cli],        ground_truth: docs.innerspace.us.caas.oneadp.com}
manual_notes: rank by frontmatter confidence
```

Resolution is domain override → global tier → newer revision → `unresolved` (human). Sourced pages carry `authority_domain`; manual-only pages use null. Conflicts become review proposals with evidence and the applied policy rule; “newest wins” is never a universal automation. The minimal read-only resolver and `protected` migration ship before Stage 3; the full governance rollout remains Stage 5.

### 3.7 Injection defense

Capability is the primary boundary. Connectors alone write evidence. The ingestor reads batch-scoped immutable evidence and emits typed extraction/assessment facts. The orchestrator alone reads inbox state, stages approved `SCHEMA-CP-03` projections, and renders `SCHEMA-RR-04`. The writer receives exactly that one fenced source-text bridge plus quote-free proposal projections; it cannot read `raw/`, inbox, arbitrary `.kiro/**`, network, or git state. The librarian also cannot read raw/inbox or mutate git. The verifier has read-only candidate/run access and stdout transport only.

`SCHEMA-RR-04` is the byte-level handoff grammar and escaping/span oracle; `TH-TGT-007` and `TH-TGT-008` are its size caps. The blocking handoff, span, secret, PII, path, and capability gates run before the verifier. Source-derived instructions, metadata, filenames, and links are data, never capability grants.

`KIRO-SEC-01R` owns the shared pre-persistence classification and egress-guard implementation before any real connector can persist content; connector packages and `CAPTURE-01` own only their adapters/enforcement points and cannot weaken it. `AT-SEC-GUARD-01` accepts the shared library, while `AT-B-PII-EGRESS` accepts each consuming adapter. Classification is `internal-standard`, `internal-sensitive`, or `personal`. Personal content is allowed only in the private `local_laptop` catalog/inbox and is excluded from shared query, shared capture, shared staging, model input, managed-wiki patches/events/receipts/releases, shared evidence backup, and generated content bundles. The private `local_laptop` repository remains versioned and may be preserved by its private off-OneDrive repository-bundle backup without entering shared evidence or retrieval. A shared capture classified personal is rejected before identity publication and returns no ID. Promotion creates a new `internal-standard` or `internal-sensitive` proposal after redaction and human approval; it contains no private bytes or private-corpus reference. Logs, patches, events, snapshots, backups, prompts, and receipts use the same content policy: allow, redact, restrict/quarantine, or reject; they never retain prohibited bytes merely because the primary content was blocked. URL egress controls are the shared §3.4 policy and include PII, SSRF, redirect, and DNS-rebinding negative fixtures.

### 3.8 Publication transaction

The transaction invariant is two-level: one crash-consistent acquisition batch, then isolated per-wiki candidates, then one journaled release set. The exact executable contract is the complete phase list enumerated in §4.1 and `FI-PIPELINE-01`.

- Real worktrees remain clean; every candidate is created in a validated same-depth sibling from an exact base. The orchestrator is the only git mutator. Scope is compiled to an explicit NUL-safe path inventory, including allowed untracked files; repository-wide staging, reset, forced checkout, unsafe glob parsing, and recursive deletion are forbidden.
- Every blocking gate, including index coverage, content policy, immutable paths, contract validity, diff scope, CT, and current-input binding, runs before the verifier. No content changes after candidate freeze. The verifier is bound to the same base, input, prompt, capability set, diff, and tree that becomes the candidate commit.
- Failure is durable: clean scoped WIP may be preserved; unsafe bytes yield a redacted restricted receipt. Pre-existing user work and `main` are untouched. Timeout kills the entire child process group and proves descendants absent before later mutation.
- Publication is evidence-first. The root evidence commit contains completed objects, `_index`, and events—never views—before dependent wiki commits. A non-self-referential manifest and CAS pointer finalize the set. Readers accept `current-release.json` only when the bound `SCHEMA-REL-08` attestation validates and the authoritative `SCHEMA-REL-02` journal has reached `pointer_advanced`; pointer bytes alone in the intervening crash window are not a visible release. The publication lock spans the first head mutation through pointer advancement or a durable mixed checkpoint.
- Integrity is an invariant (`TH-TGT-029`), not a percentage target. A fault may temporarily leave explained mixed heads, but the current pointer remains on the last verified release; mixed is failed recovery state, not successful closure. Resume is idempotent, rollback is an audited revert release, and neither discards unexplained work.

Autonomous recipes are monotone, idempotent on a healthy wiki, bounded by `TH-TGT-035`, `TH-TGT-036`, and `TH-TGT-037`, loop-closed, fail-loud, reversible, veto-aware, and proposal-only for protected pages. Cleanup uses validated inventories and recoverable archive/quarantine; it never selects the run root or follows symlinks. Retention/purge behavior remains conditional on decision #20.

### 3.9 Verifier

`.kiro/agents/verifier.json` shares the auditor's cognitive rubric but is a distinct no-write permission profile. It reads only the frozen candidate, permitted policy, and run evidence; shell is limited to read-only diff/log/show/search/JSON inspection. It emits a full `SCHEMA-RR-01` verifier envelope on stdout with the `SCHEMA-RR-02` subtype. The orchestrator validates and persists it; the verifier never writes the attestation itself.

Authorization requires `verdict=pass`, zero failed required semantic checks, the deterministic gates, every current-run/base/input/prompt/capability/diff/tree binding, evidence-span replay, and decision #4 approval policy. A semantic `fail` vetoes the candidate and opens review; `pass` or free-form text cannot authorize publication without every other condition. Old-run replay, changed output, wrong base/input/diff/tree, missing checks, capability drift, or a post-verifier mutation rejects the candidate.

### 3.10 Retrieval and assistants

`src/wiki_core/` is one deterministic, file-backed catalog/search/backlink/ownership/source/freshness/questions/changelog/proposal core. `src/wiki_cli/` exposes it locally. `src/wiki_mcp_query/` imports only read-only capabilities; `src/wiki_mcp_capture/` is a separate inbox-only process. Query and capture return `SCHEMA-CFG-02`; file capture is represented across CLI, MCP, proposal evidence, and policy or is not advertised.

Search combines exact identifiers, split-identifier aliases, title/heading/summary/body ranking, and `file#heading` citations. It reads canonical wiki repos plus disposable views, never a release manifest as content. Backlinks, provenance, authority, freshness, questions, changes, and health are deterministic projections. `SCHEMA-CFG-19` is the dedicated ownership/routing/reviewer result used by CLI and MCP. Stage-1 functional and performance targets are `TH-TGT-015` and `TH-TGT-016`; answer-accuracy and citation-recall floors `TH-TGT-002` and `TH-TGT-003` are evaluated only from the reviewed `SCHEMA-REL-05` baseline. Stage-6 adoption gates are `TH-TGT-023`, `TH-TGT-024`, `TH-TGT-025`, `TH-TGT-026`, `TH-TGT-027`, and `TH-TGT-028`; none makes trigram mandatory.

MCP tools accept opaque IDs, not caller paths; resolve under the canonical root; reject traversal and symlink escape; bound output, time, pagination, and cancellation; sanitize errors; write protocol to stdout and logs to stderr; and treat annotations as hints, not authorization. An outage falls back to CLI/files. `SCHEMA-CFG-02` is the exact per-tool output and text-fallback source.

Cross-wiki synthesis is supported only when every material assertion has a cited supporting page/source and compatible freshness/authority. Conflicting authoritative evidence is shown as conflict; inadequate, private, stale-without-warning, or absent support yields explicit abstention. The system never blends unsupported snippets into an answer. `MCP-QUERY-01` owns fixtures for support, conflict, partial support, private exclusion, and abstention.

`framework-sync` generates owned sections for Claude Code, local VS Code Copilot, and Kiro from one neutral manifest (`SCHEMA-CFG-05`); it never writes user-global Kiro configuration or hosts pipeline roles in Claude/Copilot. Contract parity is tested with the versioned query corpus, not assumed client sameness. Copilot cloud/coding-agent remains outside decision #7. `local_laptop` is a separate private CLI catalog, excluded from shared MCP and generated content bundles; its private repository-bundle backup remains permitted, and promotion is a redacted approved proposal. Kiro KB is optional interactive convenience for navigator/researcher, never a pipeline dependency.

### 3.11 Capture and contribution

`wiki capture question|note|url|file` and the separate capture MCP create immutable `SCHEMA-CP-01` proposals only after policy validation and durable `SCHEMA-CP-04` publication. Retry deduplication uses the submission key; failed capture returns no proposal ID. `SCHEMA-CP-02` is the sole lifecycle state machine and append-only disposition record; maintainer CLI approve/reject/quarantine/supersede actions use its actors and guards. `wiki proposal status <id>` projects that event stream without exposing maintainer-only data.

Questions project only into a delimited generated region of `99-open-questions.md`; notes await review; URLs/files require the hardened snapshot/file policy. Arrival never authorizes publication. A personal note may remain in the private `local_laptop` catalog. Promotion has no shortcut: it creates a new internal-classification proposal after redaction and human approval, and no private bytes or reference reach shared retrieval or the writer.

The orchestrator—not ingestor—triages inbox records, selects eligible proposals, strips quotes/private fields into `SCHEMA-CP-03`, and renders source spans only through `SCHEMA-RR-04`. Writer `SCHEMA-RR-03` outcomes are candidates, not lifecycle mutation. `applied`, `verified`, and `done` occur only after their respective gates, committed release, and current pointer checkpoint. Proposal-throughput/latency evidence uses `TH-TGT-059` and `TH-TGT-060`.

### 3.12 Contracts and state

Decision #19 selects three runtime wire families: `run-result/1`, `source-observation/1`, and `change-proposal/1`. Their subtypes, shared IDs, tool/config/auth/framework shapes, freshness view, release manifest/journal/pointers, metric events, evaluation lineage, lifecycle legality, valid/invalid fixtures, and compatibility rules are exclusively the exact contracts registered by `FI-CONTRACTS-01`.

`FINAL-contracts-2026-08-27.md` contains one machine-readable `contract_ir: 2` block. `CONTRACT-01` mechanically generates JSON Schema, Pydantic/transition/byte validators, fixtures, and the version registry from that block; generated artifacts identify the source digest and are blocking drift-checked. Prose and generated files are not rival schema sources.

State categories remain architectural:

| Category | Examples | Authority |
|---|---|---|
| committed human policy | `state/source-registry.yaml`, `.kiro/steering/authority.yaml`, desired deployment | human-reviewed; pipeline cannot add runtime fields |
| committed immutable evidence/events | `raw/objects`, `_index`, completed `state/events` segments and markers | connectors/orchestrator; write-once gate |
| committed proposal/release history | inbox proposal identities, disposition events, `state/releases/<release_id>.json`, authoritative `state/releases/journals/<release_id>.jsonl`, approvals/attestations, and current/previous pointers | schema-guarded actors; append-only/CAS; any `state/runs/**` journal is only a non-authoritative staging projection |
| disposable views | `state/views/**`, generated health/monitor/catalog projections | rebuilt from committed sources; never release authority |
| gitignored run/observed state | `state/runs/<run_id>/**`, observed auth state | bounded, secret-filtered operational evidence |
| canonical authored content | each managed wiki `wiki/**` | verified, approved release only |

`RUNTIME-01` solely owns the committed desired `orchestrator/deploy.yaml`; `PRESERVE-00` records only the accepted Stage −1 `deployment_seed_receipt` and its `seed_sha256` in `SCHEMA-CFG-10` before that file is created. Observed auth state is gitignored. `.kiro/steering/authority.yaml` is the authority home. `orchestrator/schemas/**` is generated. Thresholds, retention durations, and stage assignment remain in the plan.

### 3.13 Routing, boundaries, completeness — kept and made enforceable

Tombstones carry `status: tombstoned`, a `superseded_by` or `archived_to` target, and a visible redirect/disclaimer. Exemptions are explicit so healing does not repopulate retired content. Grace, split-candidate, mandatory-split, and dependency-escalation values are `TH-TGT-034`, `TH-TGT-051` through `TH-TGT-054`. Retirement is proposal/lifecycle work under `RETIRE-01`; exact duplicates with an unambiguous canonical owner may become links, while semantic conflicts, structural merges, uncertain ownership, or high blast radius require human approval.

Q1/Q2 routing remains enforceable through registry references plus canonical/topic frontmatter and `canonical_conflicts[]`. New-wiki escalation uses `TH-TGT-043` and `TH-TGT-044`. Boundary signals remain advisory until the plan's placement rollout. Open-question sections are validated. Owner values come from decision #9; ownership → routing → reviewer remains R-9 and returns `SCHEMA-CFG-19`. The readiness meta-gate proves that every blocking gate can fail on its negative fixture and applies `TH-TGT-017` and `TH-TGT-018`; until the autonomy floor passes, decision #4 cannot widen. Code-sample lint validates package references against the approved registry and moves from advisory to blocking only through its package acceptance. Deprecated pages are adjudicated individually with aliases, backlinks, authority, disclaimer, and rollback evidence.

### 3.14 Portability and operations

- `DECISIONS.md` records rationale and changes to decisions, thresholds, enforcement, architecture choices, and AR closures. It does not duplicate the registers in this set.
- `SCHEMA-CFG-03` owns doctor shape/exit semantics; `PIPE-G-02` owns its pipeline use. Doctor checks the qualified runtime, desired deployment, scheduler jobs/receipts, auth readiness, git safety, locks, disk/backup, connector probes, `TH-TGT-055`, and `TH-TGT-056`; it never auto-fixes without an explicit operator request.
- `SCHEMA-CFG-04` separates desired deployment from observed auth/runtime state and defines independent pipeline, backup, and dead-man jobs. Backup/dead-man are not children of the pipeline and therefore detect launcher death rather than assuming the in-process finalizer ran.
- Zero-secret authentication is `RB-AUTH-01` and `RB-AUTH-02`; preservation/backup/restore is `RB-RESTORE-00`, `RB-RESTORE-01`, `RB-RESTORE-02`, `RB-RESTORE-03`, and `RB-RESTORE-04`; release recovery is `RB-ROLLBACK-01`, `RB-ROLLBACK-02`, and `RB-ROLLBACK-03`; containment/postmortem is `RB-INCIDENT-01` and `RB-INCIDENT-02`; alert handling is `RB-ALERT-01` and `RB-ALERT-02`. There is no separate auth-runbook file.
- Postmortems follow bad merge, post-publication injection/secret/PII, SLO/dead-man breach, corruption, unauthorized purge/hold violation, or unexplained state. Autonomy resumes only after a permanent guard/fixture, revalidated evidence, clean state, and the applicable `RB-INCIDENT-02` approvals.
- Cross-assistant contract (corrected from the second-brain gap analysis: pipeline roles run on **Kiro only**; Claude Code and Copilot are MCP query/capture **clients**, never role hosts):

  | concern | canonical source | Kiro (runner) | Claude Code (client) | VS Code Copilot (client) |
  |---|---|---|---|---|
  | global operating rules | `AGENTS.md` + steering | root/nested `AGENTS.md` + steering | thin `CLAUDE.md` importing `@AGENTS.md` | thin `.github/copilot-instructions.md` |
  | reusable workflow | `.kiro/` canonical + `framework-sync` materialised copies + `framework-version.json` | native | generated copy, `framework-check` OK/override/DRIFT | generated copy, same check |
  | role definitions | `.kiro/agents/*.json` (7 + verifier profile) | native | — (not a role host) | — |
  | permissions | capability matrix per role (§4.3) | `permissions` (deny wins) | `.claude/settings.json` permissions for the MCP client only | VS Code trust prompts |
  | automation | `run-pipeline.sh` → `kiro-cli` (single host, §8 #5) | native | none | none |
  | MCP config | `.mcp.json` (root) | `.kiro/settings/mcp.json` (workspace) | `.mcp.json` | `.vscode/mcp.json` |
  | output | exact `SCHEMA-RR-01`, `SCHEMA-RR-02`, `SCHEMA-RR-03`, `SCHEMA-RR-04`, `SCHEMA-CP-01`, `SCHEMA-CP-02`, `SCHEMA-CP-03`, and `SCHEMA-CP-04` contracts | native | capture proposal | capture proposal |
  | conformance | shared versioned fixtures (`EVAL-01`) | required | required | required |

  Provider files contain only discovery hints, tool wiring and true product-specific syntax; they must not fork wiki ownership, frontmatter, risk or merge policy.
- Framework distribution keeps local parent-relative symlinks and also emits `SCHEMA-CFG-05` regular-file materializations so a restored child wiki works with symlinks disabled. Drift is `OK`, approved override, or `DRIFT`; client files cannot fork ownership or merge policy.
- Stage −1 preservation covers repository bundles through `SCHEMA-CFG-10` and `RB-RESTORE-00` without fabricating evidence paths or an event high-water mark. Stage-3 shared backup separately covers the control plane, every managed wiki repository, raw objects, events, journals, and required run evidence through `SCHEMA-CFG-13` and `RB-RESTORE-01` at an opaque off-host target. The unmanaged `local_laptop` repository bundle is a distinct private access-controlled backup partition and inventory, never a shared `SCHEMA-CFG-13.evidence_paths` member or shared-manifest payload; aggregate operations may expose only its redacted opaque completion receipt. Decision #11 owns RPO/RTO; `TH-TGT-014` is the restore-test target. Independent occurrence/receipt, relative inventory, bundle-head verification, event high-water mark, corruption/interruption, empty-directory restore, and symlinkless restore are tested behavior.
- Cost fields are nullable until `AR-10`. `TH-TGT-031` and `TH-TGT-032` are per-run brakes; `TH-TGT-033` is the separate rolling budget. A rolling budget is never misused as an in-phase abort value.
- Page template: two-line orientation block + one-line-answer-first (from `local_laptop`).
- Prompts de-hardcoded: `WIKI_NAME / WIKI_BOUNDARY_TOPICS / WIKI_AUDIENCE / WIKI_SUMMARY / WIKI_STYLE` injected from `wiki-config/<slug>.env` at generation time (removes the "32-file AIDLC wiki" hardcode).

### 3.15 Kiro specifics

`KIRO-SEC-01R` rewrites all role profiles to the permission syntax proven against the installed version by `T-AR-09` and `T-AR-17`; it does not mechanically translate either deprecated `toolsSettings` or an unverified historical third shape. The verifier-write and raw/policy-write deny probes must fail headlessly.

Production commands contain no `--trust-all-tools`, regardless of the AR-09 probe outcome. The probe determines the migration/compatibility evidence and whether the old flag would have bypassed controls; it does not create an exception. Immutable-path, scope, content, schema, and release enforcement remain outside Kiro as independent deterministic gates.

---

## 4. Pipeline: orchestrator, phases, agents

### 4.1 `orchestrator/run-pipeline.sh` (global)

The global orchestrator establishes a typed invocation and desired configuration, performs one crash-consistent acquisition batch, then runs each managed wiki sequentially, joins every terminal disposition, prepares/approves a release, applies evidence before dependent wiki candidates, finalizes the manifest/pointer under CAS, and requests backup/reporting. Acquisition and reporting execute on quiet nights. The configured stagger occurs only between wiki starts, so five wikis incur four intervals (`TH-LIVE-014`); the target window and stagger are `TH-TGT-021` and `TH-TGT-022`.

`PIPE-G-01`, `PIPE-G-02`, `PIPE-G-03`, `PIPE-G-04`, `PIPE-G-05`, `PIPE-G-06`, `PIPE-G-07`, `PIPE-EXIT-01`, `PIPE-EXIT-02`, `PIPE-EXIT-03`, `PIPE-EXIT-04`, `PIPE-EXIT-05`, `PIPE-EXIT-06`, `PIPE-REC-01`, `PIPE-REC-02`, `PIPE-REC-03`, `PIPE-REC-04`, `PIPE-REC-05`, `PIPE-REC-06`, `PIPE-REC-07`, and `PIPE-REC-08` are the sole ordered phase, environment, lock, result, publication, and recovery contract. `SCHEMA-REL-02` is the sole release state machine. Completed events/raw/index/markers are committed evidence; views are never committed. Independent backup/dead-man jobs are outside the pipeline process.

### 4.2 `wiki-nightly.sh` — target phase graph (delta from as-built; nothing removed)

| phase | status | change |
|---|---|---|
| preflight/workspace | modified | clean real repo, exact base, explicit allowlist, same-depth sibling worktree (`PIPE-W-01`) |
| total proceed | modified | actionable, quiet, unhealthy, or blocked; every class finalizes (`PIPE-W-02`, `PIPE-W-08`) |
| discovery | modified | DEEP only; LIGHT bypasses; candidates are proposals (`PIPE-W-03`) |
| extraction/capture staging | modified | ingestor reads batch evidence; orchestrator alone reads inbox and renders the bridge (`PIPE-W-04`) |
| writer → audit → triage → librarian | kept/securitized | sequential, phase-scoped writes, no agent git mutation (`PIPE-W-05`) |
| deterministic gates | reordered | every blocking gate, including index coverage and CT, before verifier (`PIPE-W-06`) |
| verifier/candidate | modified | exact binding, no write, candidate created only after acceptance (`PIPE-W-07`) |
| summary/monitor/alerts/result | recovered | runs for actionable, quiet, unhealthy, blocked, cancel, and failure (`PIPE-W-08`) |

The writer and auditor remain sequential. On-demand ingest requests a scoped batch through the same acquisition component; capture only writes proposals. Exact schedules and stage delivery remain plan §6, not architecture.

```mermaid
flowchart TD
  R[PIPE-G-01 and PIPE-G-02 identity plus preflight] --> A[PIPE-G-03 completed acquisition]
  A --> L{PIPE-G-04 next wiki?}
  L -->|yes| P{PIPE-W-02 class}
  P -->|actionable DEEP| D[PIPE-W-03 discovery]
  P -->|actionable LIGHT| B[LIGHT bypass]
  D --> S[PIPE-W-04 staging]
  B --> S
  S --> W[PIPE-W-05 sequential roles]
  W --> G[PIPE-W-06 gates]
  G --> V[PIPE-W-07 verifier + candidate]
  P -->|quiet/unhealthy/blocked| F[PIPE-W-08 finalizer]
  V --> F
  F --> L
  L -->|no| J[PIPE-G-05 release proposal/approval]
  J --> E[PIPE-G-06 evidence-first publication]
  E --> X[PIPE-G-07 result + backup request]
```

### 4.3 Agents — seven roles, one added permission profile

| profile | role/zone | reads | writes/transport | shell/network |
|---|---|---|---|---|
| navigator | interactive/summary | canonical wikis, permitted steering, derived views/run summaries; optional KB | run-local prose only | read-only git/search; no source network |
| ingestor | extraction | batch-scoped immutable objects, registry/authority subset, existing wiki for comparison | assessment/proposal facts to run-local extraction root; **not handoff and not inbox** | no shell; scheduled REST is a connector, interactive MCP only outside pipeline |
| writer | publication | worktree `wiki/**`, permitted steering, `SCHEMA-CP-03`, `SCHEMA-RR-04` | allowed `wiki/**` in worktree; result on stdout | no shell, git, network, raw, inbox, or broad `.kiro` |
| auditor | audit | post-writer snapshot in the worktree, allowed policy | stdout result; orchestrator persists it | read-only diff/search only; later librarian mutation is allowed only before the separate verifier freeze |
| advisor | triage | audit result, wiki, allowed policy | run-local triage/disposition facts | none |
| librarian | publication repair | worktree `wiki/**`, approved triage, allowed policy | allowed `wiki/**`; result on stdout | read-only search/status only; **no `git add`/commit/checkout** |
| verifier | verification profile | frozen candidate, run evidence, permitted policy | stdout only; orchestrator persists | read-only diff/log/show/search/JSON; no write/network |
| researcher | interactive research | user-selected sources and wikis; optional KB | no pipeline/canonical write | governed web/Confluence/Jira tools |

The seven cognitive agents remain navigator, ingestor, writer, auditor, advisor, librarian, and researcher; verifier is the auditor rubric under a second permission profile, not an eighth agent. Connectors and the inbox stager are deterministic services, not agents. Permission profiles are generated from this authoritative matrix and tested by denied-action fixtures; prompt prose cannot widen them. Pipeline agents do not use `knowledge`.

---

## 5. What a user can do

Capabilities ranked by value to a user, with the package that unlocks each. Mutable stage allocation is intentionally absent and lives only in plan §6.

| capability | value | measured as-built state | unlocked by |
|---|---|---|---|
| answer a question with citations and freshness state | very high | partial (grep + KB) | `QUERY-01`, `MCP-QUERY-01` |
| "is this page still true?" | very high | **no** (70/70 false-green) | `SRC-00`, `FRESH-01R` |
| know what the wiki does *not* cover | high | buried in `99-open-questions.md` | `QUERY-01` |
| onboard in a day | high | partial (quick-start paths exist) | `QUERY-01` |
| capture what I just learned | high | **no** | `CAPTURE-01` |
| what changed since I last read? | medium-high | partial (changelog files exist) | `QUERY-01`, `SUMMARY-01` |
| who owns this / escalate | medium | **no** (127 `owner: unassigned`) | `AUTH-02`, `META-02` |
| what links here (rename safety) | medium | **no** | `QUERY-01` |

### 5.1 Interaction contract (enforced by the CLI and the MCP formatter)

R-1 freshness state before content · R-2 every "not found" offers capture · R-3 answer in three lines, warning in line one · R-4 question ≠ note · R-5 capture is a separate process from the read-only server · R-6 no `superseded_by` page without a disclaimer · R-7 the wiki never notifies source owners · R-8 doctor/health are prose (+ `--json`) · R-9 ownership → routing → reviewer · R-10 a failed run leaves `main` clean and evidence in a scoped patch.

```
$ wiki find "kubeDeploy credentialsId"
jenkins / 06-pipeline-library.md § kubeDeploy
  ⬜ UNVERIFIED — source unreachable in the cited batch (unauthorized · html_login)
  owner: onecicd-platform · ask: #data-platform-engineering · authority: platform-portal
  sources: confluence:ADPI:2172899693 (v42, observed 2026-08-19) · portal:onecicd:/jenkins-pipeline/vars/kubeDeploy/
  last verified 2026-08-19 · confidence basis: 2 source revisions, key facts supported
  links here: 03-aws-jobs.md · 13-job-catalog.md

$ wiki capture question "Does kubeDeploy require a pre-created namespace?" --wiki jenkins
Q-20260826-001 · submitted · appears in the generated section of jenkins/99-open-questions.md after a completed projection batch
$ wiki capture note "SASE firewall blocks files.pythonhosted.org — use the Artifactory mirror" --wiki local_laptop
N-20260826-002 · submitted · private · review: wiki proposal show N-20260826-002
```

Assistant sequence: `search_pages → get_page → get_topic_owner` → cite "page § section (state, observed date, owner, source)"; on miss → `get_questions` → suggest capture with the proposal id; stale → warning paragraph first, then content, then "verify with <owner>".

### 5.2 Capability delivery references

Mutable stage allocation lives only in plan §6; package scope lives only in §7. The architectural capability-to-package relationship is:

| Capability | Package owners |
|---|---|
| diagnose deployment/auth without secrets | `RUNTIME-01`, `DOCTOR-01`, `RB-AUTH-01`, `RB-AUTH-02` |
| truthful local navigation | `IDX-01`, `SRC-00`, `QUERY-01` |
| isolated, evidence-bound publication and recovery | `CONTRACT-01`, `KIRO-SEC-01R`, `VER-01`, `TXN-01R` |
| immutable Confluence evidence, freshness, summary, and trace | `RETENTION-01`, early `AUTH-02`, `CONFLUENCE-01`, `FRESH-01R`, `KEYFACTS-01`, `SUMMARY-01`, `MONITOR-01`, `BACKUP-01` |
| read-only assistants, capture, and portable framework | `MCP-QUERY-01`, `CAPTURE-01`, `FRAMEWORK-01` |
| multi-source governance and recovery drills | `PORTAL-01`, `PORTAL-02`, `PORTAL-03`, `REPO-01`, `WEB-01`, `DISCOVERY-01`, `META-02`, `AUTH-02`, `CODE-01`, `RENUMBER-01`, `RETIRE-01`, `READY-01`, `DRILL-01` |
| reproducible evaluation and evidence-gated upgrades | `EVAL-01` |

An engineer landing directly on a page is served by the answer-first template, visible freshness, citation, and owner. A later maintainer is served by `DECISIONS.md`, the exact runbooks in `FI-RUNBOOKS-01`, doctor, release journals, and the evidence/acceptance crosswalk.

---

## Appendix B — Completed adjudications

Each row is one adjudicated claim. “Rejected” means it must not re-enter implementation; “corrected” names the canonical replacement.

| ID | Claim | Verdict | Rationale | Canonical target |
|---|---|---|---|---|
| `AB-01` | one composite health score/trend | rejected | hides failure classes and recreates false-green behavior | §3.5, `SCHEMA-SO-04` |
| `AB-02` | one mutable registry containing runtime health | rejected | policy, immutable events, and views have different owners | §3.3, `SCHEMA-CFG-01`, `SCHEMA-SO-02`, `SCHEMA-SO-03`, `SCHEMA-SO-04` |
| `AB-03` | observe after early exit or once per wiki | rejected | quiet runs would miss work and repeat remote acquisition | §4.1, `PIPE-G-03` |
| `AB-04` | writer reads raw evidence or inbox | rejected | violates the extraction/publication boundary | §§3.7, 4.3, `PIPE-W-04` |
| `AB-05` | fixed XML/fence tags or schema-free handoff | rejected | source text can guess/break a fixed marker | `SCHEMA-RR-04` |
| `AB-06` | verifier loses wiki read access or writes its own attestation | corrected | verifier requires read-only candidate access and stdout transport, not write | §3.9, `SCHEMA-RR-02` |
| `AB-07` | pre-commit hook is release enforcement or co-equal authority | rejected | hook is bypassable feedback; blocking release gate is authoritative | §3.1, `PIPE-W-06` |
| `AB-08` | source Key Facts are regex-automatable | corrected | semantic judgment stays explicit; comparison record is mechanical | §3.5, `SCHEMA-SO-03` |
| `AB-09` | HEALTHY/DRIFT or a longer core-state ladder | rejected | core state is four values; other labels are diagnostics | §3.5, decision #14, `SCHEMA-SO-04` |
| `AB-10` | shared FTS/vector index required for client parity | rejected | clients adapt over the same deterministic core; adoption is evidence-gated | §3.10, `TH-TGT-023`, `TH-TGT-024`, `TH-TGT-025`, `TH-TGT-026`, `TH-TGT-027`, `TH-TGT-028` |
| `AB-11` | event-driven triggers, parallel writer/auditor, or writer self-review | rejected | not required; scheduled pull and downstream verification remain | §§1.5, 4.2 |
| `AB-12` | outbound source-owner notifications | rejected | RACI routes review; the wiki records/alerts maintainers, notifies no source owner | §§1.4, 3.5, R-7 |
| `AB-13` | portal provider has two implementation homes | corrected | provider lives under `src/wiki_core/providers`; orchestrator is an adapter | §3.4 |
| `AB-14` | REST revision evidence closes interactive MCP capability | rejected | AR-13 is MCP-specific | §3.4, plan §10 `AR-13` |
| `AB-15` | all Python utilities are stdlib-only | corrected | `minhash-overlap.py` imports `datasketch`; target deps are locked | §1.3, `RUNTIME-01` |
| `AB-16` | mixed release is acceptable closure or a 99% integrity SLI | rejected | mixed is failed recovery; pointer integrity is invariant | §3.8, `TH-TGT-029`, `PIPE-REC-04` |
| `AB-17` | `--trust-all-tools` may remain in production after a favorable probe | rejected | production flag removal is unconditional | §3.15, decision #17 |
| `AB-18` | diagrams or client/provider files may own behavior | rejected | diagrams stay beside canonical facts and add no facts; generated clients cannot fork policy | §§3–4, `SCHEMA-CFG-05` |
| `AB-STR-01` | no set index | accepted structural correction | membership/ownership needs a compact universal reader | `FINAL-INDEX.md`, `FI-SET-01` |
| `AB-STR-02` | keep mutable execution state inside plan §7 | rejected; companion accepted | delivery cards have different cadence; package scope remains in plan | `FINAL-todo-2026-08-27.md`; exact cards use `FI-NAMESPACE-01` |
| `AB-STR-03` | keep exact phase/recovery mechanics in architecture | rejected; companion accepted | execution contract has implementer/on-call reader and machine-like order | `FINAL-pipeline-2026-08-27.md`, `FI-PIPELINE-01` |
| `AB-STR-04` | keep field/schema detail in architecture or hand-maintained generated files | rejected; companion accepted | machine shapes need one IR and drift-generated artifacts | `FINAL-contracts-2026-08-27.md`; exact registry in `FI-CONTRACTS-01` |
| `AB-STR-05` | keep auth/restore/rollback procedures in architecture or separate auth file | rejected; companion accepted | operator checklists have distinct reader/cadence; one runbook home | `FINAL-runbooks-2026-08-27.md`; exact registry in `FI-RUNBOOKS-01` |
| `AB-STR-06` | create `FINAL-diagrams` | rejected | it would duplicate owning documents without a distinct fact set | diagrams remain with §3 and §4 and cite `FI-PIPELINE-01` and `FI-CONTRACTS-01` facts |

## Appendix C — Sources

**Repository:** `.kiro/pipeline/wiki-nightly.sh` · `orchestrator/run-pipeline.sh` · `.kiro/agents/*.json` · `.kiro/pipeline/prompts/*` · `.kiro/steering/{onedata-sync-monitor, project-context, routing-rules, wiki-boundary-rules, wiki-completeness-methodology, frontmatter-schema}.md` · `orchestrator/{mirror-onedata-docs.sh, source-hash*.sh, source_hash_lib.py, hp5-drift-check.py, ct-gate.sh, enforcement.env, backup-bundles.sh, bootstrap-wiki.sh}` · `*/.kiro/{discovery-manifest.json, hp5-drift-result.json, steering/project-context.md}` · `reports/adp-skills-mcp-inventory-2026-08-14.md` · `resolution-report.md` · `aidlc/.kiro/pipeline/{test-pipeline.sh, tests/*}` · frontmatter of 127 pages · the two scheduler property-list fixtures.

**External sources retained by the completed review (the retired review notes are history, so the authoritative URLs are carried here):**
- Kiro: custom-agents configuration reference <https://kiro.dev/docs/custom-agents/configuration-reference/> · MCP configuration <https://kiro.dev/docs/mcp/configuration/> · CLI chat configuration <https://kiro.dev/docs/cli/chat/configuration/> · experimental knowledge management <https://kiro.dev/docs/cli/experimental/knowledge-management/> · GitHub issue #7527 <https://github.com/kirodotdev/Kiro/issues/7527> (agent-config knowledge bases do not auto-index)
- Claude Code: MCP <https://code.claude.com/docs/en/mcp> · settings <https://code.claude.com/docs/en/settings>
- VS Code / Copilot: MCP servers <https://code.visualstudio.com/docs/agent-customization/mcp-servers> · custom instructions <https://code.visualstudio.com/docs/copilot/customization/custom-instructions> · cloud agent + MCP <https://docs.github.com/en/copilot/concepts/agents/cloud-agent/mcp-and-cloud-agent> · agent skills <https://docs.github.com/en/copilot/concepts/agents/about-agent-skills> (rejected as the portability vehicle, §3.14) · prompts/resources/sampling <https://devblogs.microsoft.com/visualstudio/mcp-prompts-resources-sampling/>
- MCP specification 2026-07-28 <https://modelcontextprotocol.io/specification/2026-07-28> · tools <https://modelcontextprotocol.io/specification/2026-07-28/server/tools>
- httpx proxies <https://www.python-httpx.org/advanced/proxies/> · timeouts <https://www.python-httpx.org/advanced/timeouts/>
- Confluence: DC REST examples <https://developer.atlassian.com/server/confluence/confluence-rest-api-examples/> · Cloud v2 pages <https://developer.atlassian.com/cloud/confluence/rest/v2/api-group-page/>
- git hooks <https://git-scm.com/docs/githooks>
- SQLite FTS5 <https://www.sqlite.org/fts5.html> · sqlite-vec <https://github.com/asg017/sqlite-vec> (releases, API reference) · LangGraph persistence <https://docs.langchain.com/oss/python/langgraph/persistence> · Docling <https://docling-project.github.io/docling/> · GROBID <https://grobid.readthedocs.io/en/latest/> · Crawl4AI <https://docs.crawl4ai.com/> · Semantica <https://github.com/semantica-agi/semantica> · late-interaction overview <https://weaviate.io/blog/late-interaction-overview> · hybrid RAG (graphs + BM25) <https://community.netapp.com/t5/Tech-ONTAP-Blogs/Hybrid-RAG-in-the-Real-World-Graphs-BM25-and-the-End-of-Black-Box-Retrieval/ba-p/464834> · RAG evaluation guide <https://www.getmaxim.ai/articles/rag-evaluation-a-complete-guide-for-2025/> · doc-drift detection in CI <https://understandingdata.com/posts/doc-drift-detection-ci/> · arXiv <https://arxiv.org/html/2605.17301v1>, <https://arxiv.org/html/2607.10491v1>, <https://arxiv.org/html/2507.03226v3>
- Gated-technology references (kept for the Stage-6 gates): Docling supported formats <https://docling-project.github.io/docling/usage/supported_formats/>, document model <https://docling-project.github.io/docling/concepts/docling_document/>, chunking <https://docling-project.github.io/docling/concepts/chunking/> · GROBID TEI encoding <https://grobid.readthedocs.io/en/latest/TEI-encoding-of-results/>, PDF coordinates <https://grobid.readthedocs.io/en/latest/Coordinates-in-PDF/> · OCRmyPDF <https://ocrmypdf.readthedocs.io/en/stable/introduction.html> · Crawl4AI quickstart <https://docs.crawl4ai.com/core/quickstart/>, changelog <https://github.com/unclecode/crawl4ai/blob/main/CHANGELOG.md> · LangGraph overview <https://docs.langchain.com/oss/python/langgraph/overview>, human-in-the-loop <https://docs.langchain.com/oss/python/langchain/human-in-the-loop> · DSPy <https://github.com/stanfordnlp/dspy>, metrics and evaluation <https://github.com/stanfordnlp/dspy/blob/main/docs/docs/diving-deeper/metrics-and-evaluation.md> · Neo4j getting started <https://neo4j.com/docs/getting-started/graph-database/> · Qdrant hybrid search <https://qdrant.tech/documentation/search/text-search/hybrid-search/> · Semantica changelog <https://github.com/semantica-agi/semantica/blob/main/CHANGELOG.md>, pyproject <https://github.com/semantica-agi/semantica/blob/main/pyproject.toml> · MCP server discovery <https://modelcontextprotocol.io/specification/2026-07-28/server/discover> · git bundle <https://git-scm.com/docs/git-bundle>, `core.symlinks` <https://git-scm.com/docs/git-config#Documentation/git-config.txt-coresymlinks>
- Portals: mkdocs sitemap template <https://github.com/mkdocs/mkdocs/blob/master/mkdocs/templates/sitemap.xml> · mkdocs-material #6107 <https://github.com/squidfunk/mkdocs-material/issues/6107> · trafilatura #553 <https://github.com/adbar/trafilatura/issues/553> · trafilatura core functions <https://trafilatura.readthedocs.io/en/latest/corefunctions.html> · Playwright auth <https://playwright.dev/python/docs/auth>
- llms.txt <https://llmstxt.org/> · state of llms.txt 2026 <https://presenc.ai/research/state-of-llms-txt-2026> · AGENTS.md guide <https://codersera.com/blog/agents-md-complete-guide-2026/> · symlink agents to Claude <https://www.ssw.com.au/rules/symlink-agents-to-claude> · MCP server documentation <https://www.gitbook.com/blog/what-is-mcp-server-documentation> · Wikipedia:Reliable_sources <https://en.wikipedia.org/wiki/Wikipedia:Reliable_sources>
- Karpathy `llm-wiki` gist <https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f> (commentary: <https://agentpedia.codes/blog/karpathy-llm-wiki-idea-file>) · aws-samples/sample-kiro-llm-wiki <https://github.com/aws-samples/sample-kiro-llm-wiki> (nine-step ingest, per-wiki `log.md`) · community forks, each a *pattern* not a spec: toolboxmd/karpathy-wiki <https://github.com/toolboxmd/karpathy-wiki> (lease/retry) · Ar9av/obsidian-wiki <https://github.com/Ar9av/obsidian-wiki> (claim-level evidence types) · frankchu91/mindbase-llm-wiki <https://github.com/frankchu91/mindbase-llm-wiki> (contradiction workflow) · byoniq/SecondBrain <https://github.com/byoniq/SecondBrain/blob/main/second-brain/README.md> · RepoWiki <https://github.com/he-yufeng/RepoWiki> · deepwiki-open <https://github.com/AsyncFuncAI/deepwiki-open> · obsidian-spaced-repetition-recall <https://github.com/open-spaced-repetition/obsidian-spaced-repetition-recall> · Open Knowledge Format v0.2 <https://github.com/GoogleCloudPlatform/knowledge-catalog/blob/main/okf/SPEC.md>

There is no authoritative “Karpathy wiki v2/v3” specification; community labels are patterns, never a compatibility target.

**Claim-to-evidence map (measurements are dated 2026-08-26 and are not mutable thresholds):**

| Claim ID | Claim | Primary source or retained input | Reproducer / qualification |
|---|---|---|---|
| `AC-EV-01` | Crawl4AI browser surfaces have had launch-argument injection/RCE and streaming SSRF vulnerabilities | vendor advisories [GHSA-r253-r9jw-qg44 / CVE-2026-57572](https://github.com/unclecode/crawl4ai/security/advisories/GHSA-r253-r9jw-qg44) and [GHSA-wm69-2pc3-rmmf / CVE-2026-57573](https://github.com/unclecode/crawl4ai/security/advisories/GHSA-wm69-2pc3-rmmf); [NVD CVE-2026-57573](https://nvd.nist.gov/vuln/detail/CVE-2026-57573) | supports hardened-worker/egress controls only; it does not prove the local deployment is affected. Scores are intentionally omitted because the prior report did not retain a single scoring authority. |
| `AC-EV-02` | identifier-heavy corpus needs explicit split/exact-identifier evaluation | the 127 `wiki/*.md` files in this analysis copy | the prior count was **984 distinct identifier tokens across source entries**, not 169 pages: manual and Confluence source entries overlap within 127 corpus pages. Reproduce with a versioned tokenizer script, grammar, input commit map, and output digest under `EVAL-01`; until that artifact exists, the count is calibration evidence, not a gate. |
| `AC-EV-03` | corpus byte size was 950,278 bytes | five generated `llms-full.txt` inputs in the analysis copy | sum exact byte counts from the five files and record input digests. The former ≈238k-token and “one model window” conclusions are withdrawn because no tokenizer, model limit, prompt overhead, or input hash was retained. |
| `AC-EV-04` | 127 corpus pages include overlapping manual and Confluence source entries | frontmatter of the 127 `wiki/*.md` files | parse each page once, then count `source[]` entries by type; never label the summed type entries as pages. |
| `AC-EV-05` | Confluence grounding is uneven by wiki | the same frontmatter inventory | retain the per-wiki numerator/denominator and source commit in the Stage-3 shadow receipt; this is calibration input, not a threshold. |
| `AC-EV-06` | Kiro agent-config knowledge bases do not reliably auto-index | Kiro issue #7527 URL above | optional KB refresh remains convenience only; `framework-check`, CLI, and MCP are the portability contract. |
| `AC-EV-07` | the measured role set has seven cognitive agent profiles | `.kiro/agents/*.json` in the analysis copy | enumerate and hash the seven role files in the `RUNTIME-01` preservation receipt; the unavailable historical role-merger rationale is not required. |
| `AC-EV-08` | the morning-summary capability is an explicit retained requirement | architecture preservation guard, completed `AB-*` adjudication, `SUMMARY-01`, and `PIPE-W-08` | this current architecture decision is accepted by `AT-PIPE-FINALIZE`. |

Search adoption policy belongs only to plan §9. `unicode61`, exact/split identifiers, BM25, or optional trigram are candidates to benchmark under `EVAL-01`; App. C evidence does not mandate trigram.
