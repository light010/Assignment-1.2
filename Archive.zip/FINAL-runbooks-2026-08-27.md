# FINAL — Operator Runbooks

> **Purpose:** executable, human-operated procedures for authentication, preservation, recovery, incidents, and alert handling.
> **Owns:** `RB-AUTH-*`, `RB-RESTORE-*`, `RB-ROLLBACK-*`, `RB-INCIDENT-*`, and `RB-ALERT-*`.
> **Siblings:** [architecture](FINAL-architecture-2026-08-26.md) owns invariants and capabilities; [implementation plan](FINAL-implementation-plan-2026-08-26.md) owns stages, packages, decisions, thresholds, uncertainties, and acceptance; [index](FINAL-INDEX.md) owns set membership; [todo](FINAL-todo-2026-08-27.md) owns delivery state; [pipeline](FINAL-pipeline-2026-08-27.md) owns execution, locking, finalization, and recovery; [contracts](FINAL-contracts-2026-08-27.md) owns machine shapes and transitions.
> **Last updated:** 2026-08-27.
> **One fact, one home:** this file owns operator actions, evidence checklists, and stop/abort conditions. It references plan §8 decisions and exact `TH-*` IDs without copying their values, and references `PIPE-*`/`SCHEMA-*` instead of restating mechanics or schemas.

## Operator safety and evidence convention

Use a trusted local terminal on the authoritative host from plan §8 decision #1. Never paste credentials, cookies, tokens, private source text, or CA contents into a command line, issue, log, chat, screenshot, or evidence receipt. Do not use shell tracing during authentication. Do not run a writer, acquisition resume, release resume, rollback, rotation, or purge while the applicable stop condition remains.

Resolve the authoritative checkout from the opaque `SCHEMA-CFG-04.root_id`; never accept a user-supplied filesystem root as equivalent authority. `SCHEMA-CFG-07` owns the gitignored local binding, `SCHEMA-CFG-08` owns the ephemeral resolution containing the absolute path, and `SCHEMA-CFG-09` owns the persisted redacted attestation. Pass the desired configuration's opaque root ID and an existing global invocation ID as arguments; the root ID is transport only and cannot select a different deployment because the procedure verifies it against the validated desired configuration, local binding attestation, repository head, and run-bound persisted attestation. The operator helper deliberately accepts only the ASCII subset of the `SCHEMA-CFG-00` safe-relative grammar, so backslash, control bytes, non-ASCII/non-NFC spellings, lexical traversal, and ambiguous separators fail closed. It canonicalizes the root and every existing target parent, rejects a symlink leaf, and permits an intermediate symlink only when physical resolution remains beneath the same canonical root; contracts that forbid every symlink component require their producer-side no-follow validator in addition to this read helper:

```bash
safe_relative_path() {
  local LC_ALL=C
  case ${1-} in
    ''|/*|.|./*|*/./*|*/.|..|../*|*/../*|*/..|*//*|*\\*|*[![:graph:]]*) return 1 ;;
  esac
}
canonical_existing_dir() {
  test "$#" -eq 1 && test -d "$1" && test ! -L "$1" || return 1
  (cd -- "$1" && pwd -P)
}
canonical_dir_beneath() {
  test "$#" -eq 2 || return 1
  safe_relative_path "$2" || return 1
  local root_real target_real
  root_real=$(canonical_existing_dir "$1") || return 1
  test -d "$root_real/$2" && test ! -L "$root_real/$2" || return 1
  target_real=$(canonical_existing_dir "$root_real/$2") || return 1
  case "$target_real" in "$root_real"/*) printf '%s\n' "$target_real" ;; *) return 1 ;; esac
}
canonical_file_beneath() {
  test "$#" -eq 2 || return 1
  safe_relative_path "$2" || return 1
  local root_real parent_rel leaf parent_real target
  root_real=$(canonical_existing_dir "$1") || return 1
  parent_rel=${2%/*}; leaf=${2##*/}; test "$leaf" != "$2" || parent_rel=.
  test "$leaf" != . && test "$leaf" != .. && test -n "$leaf" || return 1
  if test "$parent_rel" = .; then parent_real=$root_real; else parent_real=$(canonical_dir_beneath "$root_real" "$parent_rel") || return 1; fi
  target="$parent_real/$leaf"
  test -f "$target" && test ! -L "$target" || return 1
  case "$target" in "$root_real"/*) printf '%s\n' "$target" ;; *) return 1 ;; esac
}
deployment_root_id=${ROOT_ID:?ROOT_ID is required}; operator_run_id=${RUN_ID:?RUN_ID is required}
root_resolution_json=$(wiki config resolve-root --root-id "$deployment_root_id" --json) || exit 1
printf '%s' "$root_resolution_json" | jq -e --arg root "$deployment_root_id" '
  .schema=="root-resolution/1" and .root_id==$root and .resolved==true and
  (.resolved_path|type=="string") and (.attestation|type=="object") and
  (keys|sort)==["attestation","resolved","resolved_path","root_id","schema"] and
  (.attestation|keys|sort)==["checkout_marker_sha256","device_id_digest","head","repository_id","resolved_at","root_fingerprint"]
' >/dev/null || exit 1
deployment_root_candidate=$(printf '%s' "$root_resolution_json" | jq -er '.resolved_path') || exit 1
deployment_root_abs=$(canonical_existing_dir "$deployment_root_candidate") || exit 1
test "$deployment_root_abs" = "$deployment_root_candidate" || exit 1
unset deployment_root_candidate
cd -- "$deployment_root_abs" || exit 1
wiki_root_abs=$(git rev-parse --show-toplevel) || exit 1
wiki_root_abs=$(canonical_existing_dir "$wiki_root_abs") || exit 1
test "$wiki_root_abs" = "$deployment_root_abs" || exit 1
deploy_file_abs=$(canonical_file_beneath "$wiki_root_abs" orchestrator/deploy.yaml) || exit 1
configured_root_id=$(wiki config get --config orchestrator/deploy.yaml --field root_id) || exit 1
test "$configured_root_id" = "$deployment_root_id" || exit 1
unset configured_root_id
operator_run_dir=$(canonical_dir_beneath "$wiki_root_abs" "state/runs/$operator_run_id") || exit 1
root_attestation_abs=$(canonical_file_beneath "$operator_run_dir" global/root-attestation.json) || exit 1
operator_global_dir=$(canonical_dir_beneath "$operator_run_dir" global) || exit 1
operator_evidence_candidate="$operator_global_dir/operator"
if test -e "$operator_evidence_candidate"; then
  operator_evidence_dir=$(canonical_dir_beneath "$operator_global_dir" operator) || exit 1
else
  install -d -m 700 -- "$operator_evidence_candidate" || exit 1
  operator_evidence_dir=$(canonical_dir_beneath "$operator_global_dir" operator) || exit 1
fi
test "$(stat -f '%Lp' "$operator_evidence_dir")" = '700' || exit 1
test -z "$(find "$operator_evidence_dir" -type l -print -quit)" || exit 1
validate_contract_file() {
  test "$#" -eq 4 || return 1
  local wire=$1 schema_id=$2 input_ref input_abs output_leaf output_abs tmp_output tmp_leaf
  case "$3" in "$wiki_root_abs"/*) input_ref=${3#"$wiki_root_abs"/} ;; *) return 1 ;; esac
  safe_relative_path "$input_ref" || return 1
  input_abs=$(canonical_file_beneath "$wiki_root_abs" "$input_ref") || return 1
  test "$input_abs" = "$3" || return 1
  case "$4" in "$operator_evidence_dir"/*) output_leaf=${4#"$operator_evidence_dir"/} ;; *) return 1 ;; esac
  case "$output_leaf" in ''|*/*) return 1 ;; esac
  test ! -e "$4" && test ! -L "$4" || return 1
  tmp_output=$(mktemp "$operator_evidence_dir/.contract-validation.XXXXXX") || return 1
  tmp_leaf=${tmp_output##*/}
  tmp_output=$(canonical_file_beneath "$operator_evidence_dir" "$tmp_leaf") || return 1
  (cd -- "$wiki_root_abs" && wiki contract validate --schema "$wire" --input "$input_ref" --json) > "$tmp_output" || return 1
  jq -e --arg wire "$wire" --arg schema_id "$schema_id" '
    .schema=="tool-result/1" and .tool=="contract_validate" and .status=="ok" and .exit_code==0 and
    .data.schema_id==$schema_id and .data.wire==$wire and .data.valid==true and
    (.data.failed_rule_ids|type)=="array" and (.data.failed_rule_ids|length)==0 and
    (.data.errors|type)=="array" and (.data.errors|length)==0
  ' "$tmp_output" >/dev/null || return 1
  mv -n "$tmp_output" "$4" || return 1
  test ! -e "$tmp_output" || return 1
  output_abs=$(canonical_file_beneath "$operator_evidence_dir" "$output_leaf") || return 1
  test "$output_abs" = "$4" || return 1
}
snapshot_inventory_sha256_from_job_result() {
  test "$#" -eq 1 && test -f "$1" && test ! -L "$1" || return 1
  local canonical_projection digest_line digest
  canonical_projection=$(jq -cS '{
    repositories:.receipt.snapshot_manifest.repositories,
    evidence_paths:.receipt.snapshot_manifest.evidence_paths,
    event_high_water:.receipt.snapshot_manifest.event_high_water
  }' "$1") || return 1
  digest_line=$(printf '%s' "$canonical_projection" | shasum -a 256) || return 1
  digest=${digest_line%% *}
  [[ "$digest" =~ ^[0-9a-f]{64}$ ]] || return 1
  printf '%s\n' "$digest"
}
validate_contract_file root-attestation/1 SCHEMA-CFG-09 "$root_attestation_abs" \
  "$operator_evidence_dir/root-attestation-validation.json" || exit 1
validate_contract_file deployment-config/1 SCHEMA-CFG-04 "$deploy_file_abs" \
  "$operator_evidence_dir/deployment-config-validation.json" || exit 1
jq -e '.schema=="tool-result/1" and .status=="ok" and .exit_code==0 and .tool=="contract_validate" and
       .data.wire=="root-attestation/1" and .data.valid==true and
       (.data.failed_rule_ids|length)==0 and (.data.errors|length)==0' \
  "$operator_evidence_dir/root-attestation-validation.json" >/dev/null || exit 1
jq -e --arg root "$deployment_root_id" --arg run "$operator_run_id" '
  .schema=="root-attestation/1" and .root_id==$root and .run_id==$run
' \
  "$root_attestation_abs" >/dev/null || exit 1
attested_root_head=$(jq -er '.head' "$root_attestation_abs") || exit 1
test "$(git -C "$wiki_root_abs" rev-parse HEAD)" = "$attested_root_head" || exit 1
unset attested_root_head
jq -e --arg root "$deployment_root_id" --arg run "$operator_run_id" \
  --slurpfile persisted "$root_attestation_abs" '
  .schema=="root-resolution/1" and .root_id==$root and
  ($persisted[0].root_id==$root) and ($persisted[0].run_id==$run) and
  .attestation==($persisted[0]|del(.schema,.root_id,.run_id))
' <<<"$root_resolution_json" >/dev/null || exit 1
unset root_resolution_json
```

Preserve stdout, stderr, exit status, relative paths, hashes, and approval receipts under `operator_evidence_dir`; never store secret-bearing input, `SCHEMA-CFG-08`, or a resolved private path. A failed command is evidence, not permission to weaken TLS, bypass a gate, edit a release pointer, delete a lock, or use destructive Git recovery.

## RB-AUTH-01 — Zero-secret bootstrap

**Owner:** maintainer. The security owner joins for suspected disclosure; the source owner joins when connector entitlement is in question. There is no second auth-runbook home (`FI-HISTORY-01`).

**Preconditions**

- `wiki doctor` is installed by Stage 0 and emits `SCHEMA-CFG-03`; observed auth readiness is `SCHEMA-CFG-06`.
- The terminal is not recorded and `set -x` is off.
- The operator knows which connector is being enabled and its approved account.
- AR-16 and decision #18 determine the Confluence deployment/auth profile; AR-17 determines the installed Kiro login command. Do not guess either result.

**Procedure**

1. Capture the redacted baseline. Do not redirect output from any token-producing utility into the evidence directory.

   ```bash
   wiki doctor --json > "$operator_evidence_dir/doctor-before.json"
   doctor_before_rc=$?; printf '%s\n' "$doctor_before_rc" > "$operator_evidence_dir/doctor-before.exit"
   validate_contract_file doctor-result/1 SCHEMA-CFG-03 "$operator_evidence_dir/doctor-before.json" \
     "$operator_evidence_dir/doctor-before.validation.json" || exit 1
   jq -e --argjson rc "$doctor_before_rc" '.schema=="doctor-result/1" and .exit_code==$rc' \
     "$operator_evidence_dir/doctor-before.json" >/dev/null || exit 1
   test "$doctor_before_rc" -ne 3 || exit 1
   ```

2. For an OAP profile, obtain `~/.oap.json` only through the approved organizational bootstrap. Verify presence and restrictive mode without printing contents.

   ```bash
   operator_home_abs=$(canonical_existing_dir "${HOME:?}") || exit 1
   oap_profile_abs=$(canonical_file_beneath "$operator_home_abs" .oap.json) || exit 1
   test "$(stat -f '%Lp' "$oap_profile_abs")" = '600' || exit 1
   ```

3. Install or select the approved ADP CA bundle outside the repository. Let `wiki doctor` compare `SCHEMA-CFG-04` desired deployment with `SCHEMA-CFG-06` observed auth readiness and validate readability/trust-chain behavior. Never use an insecure-TLS flag, replace the CA with a downloaded guess, or record certificate private material.

4. Record product versions and run the connector probe through the same runtime the scheduler uses.

   ```bash
   kiro-cli --version > "$operator_evidence_dir/kiro-version.txt"
   wiki doctor --probe --json > "$operator_evidence_dir/doctor-probe.json"
   doctor_probe_rc=$?; printf '%s\n' "$doctor_probe_rc" > "$operator_evidence_dir/doctor-probe.exit"
   validate_contract_file doctor-result/1 SCHEMA-CFG-03 "$operator_evidence_dir/doctor-probe.json" \
     "$operator_evidence_dir/doctor-probe.validation.json" || exit 1
   jq -e --argjson rc "$doctor_probe_rc" '.schema=="doctor-result/1" and .exit_code==$rc' \
     "$operator_evidence_dir/doctor-probe.json" >/dev/null || exit 1
   test "$doctor_probe_rc" -ne 3 || exit 1
   ```

5. If Kiro reports an expired session, run only the login/refresh command recorded by the AR-17 closure for that installed version, interactively and without output capture. If Confluence token usability or deployment type is still unresolved, stop and close AR-16; a successful unrelated MCP query is not proof for REST.

6. Use a headed Playwright login only when the connector contract requires browser acquisition, policy permits it, and its hardened-worker controls are active. Complete the login in the visible browser; store only the connector's protected session state, never screenshots or copied cookies. Plain HTTP failure alone is not authorization to launch a browser flow while AR-14 or AR-15 remains open.

7. Rerun step 4. Expected observation: the intended profile is identified, required trust/auth probes pass, and unrelated unavailable profiles remain explicit rather than silently empty. Preserve both redacted probe receipts.

**Stop/abort:** any secret in output; wrong account or deployment profile; unexpected redirect/login HTML; TLS validation failure; ambiguous empty result; broad filesystem permissions; or probe output that does not name the tested capability. Quarantine the evidence receipt if it contains sensitive material and follow `RB-INCIDENT-01`.

## RB-AUTH-02 — Re-authentication and revocation

1. Contain repeated auth failures before retrying: pause only the affected connector; do not wake a writer and do not mark the source fresh.
2. Capture a redacted failing probe with `RB-AUTH-01` step 4 and correlate its event and terminal disposition with `PIPE-EXIT-01` and `PIPE-EXIT-04`.
3. Refresh interactively using the AR-closure command for the installed client. Never edit token JSON by hand or copy another user's profile.
4. Probe again. On success, resume acquisition through `PIPE-G-03`; on failure, keep the connector paused and alert the maintainer/source owner.
5. After suspected compromise, revoke at the identity provider first, quarantine the local profile without viewing it, re-bootstrap, and run `RB-INCIDENT-01`. A local file replacement alone does not close a credential incident.

Evidence: before/after redacted doctor receipts, exit receipts, installed-version record, connector identity/profile name, revocation ticket reference, and operator.

## RB-RESTORE-00 — Stage −1 pre-evidence preservation

**Owner:** recovery maintainer. This procedure runs before Stage-3 evidence paths or event high-water marks exist. It produces `SCHEMA-CFG-10` with `scope_kind=pre_evidence`; it MUST NOT synthesize `raw/objects`, `state/events`, an event watermark, or a `SCHEMA-CFG-13` evidence-backup receipt. `PRESERVE-00` constructs the nested `deployment_seed_receipt`, but does not create or carry bytes from `orchestrator/deploy.yaml`: the receipt binds the accepted seed to consumer and sole canonical-output owner `RUNTIME-01`.

Run the exact producer, preserve its structured output, and validate both stdout and the orchestrator-persisted receipt. The `deployment_seed_receipt` property is mandatory in every outer receipt, non-null on success, and may be null only in a failed receipt. A missing member, a success-time null, a seed/receipt digest mismatch, changed job order, enabled automerge, deploy bytes, or any owner/output mismatch stops Stage −1:

```bash
wiki preservation create --run-id "$operator_run_id" --json \
  > "$operator_evidence_dir/preservation-create.json"
preservation_rc=$?; printf '%s\n' "$preservation_rc" > "$operator_evidence_dir/preservation-create.exit"
preservation_receipt_abs=$(canonical_file_beneath "$operator_run_dir" global/preservation-receipt.json) || exit 1
validate_contract_file preservation-receipt/1 SCHEMA-CFG-10 "$operator_evidence_dir/preservation-create.json" \
  "$operator_evidence_dir/preservation-create.validation.json" || exit 1
validate_contract_file preservation-receipt/1 SCHEMA-CFG-10 "$preservation_receipt_abs" \
  "$operator_evidence_dir/preservation-persisted.validation.json" || exit 1
cmp -s "$operator_evidence_dir/preservation-create.json" "$preservation_receipt_abs" || exit 1
for validation_leaf in preservation-create.validation.json preservation-persisted.validation.json; do
  validation_abs=$(canonical_file_beneath "$operator_evidence_dir" "$validation_leaf") || exit 1
  jq -e '
    .schema=="tool-result/1" and .tool=="contract_validate" and .status=="ok" and .exit_code==0 and
    .data.schema_id=="SCHEMA-CFG-10" and .data.wire=="preservation-receipt/1" and
    .data.valid==true and (.data.failed_rule_ids|length)==0 and (.data.errors|length)==0
  ' "$validation_abs" >/dev/null || exit 1
done
jq -e --arg run "$operator_run_id" '
  .schema=="preservation-receipt/1" and .run_id==$run and .status=="succeeded" and
  .scope_kind=="pre_evidence" and .evidence_status=="not_available_pre_stage3" and
  .verification_status=="passed" and .failure==null and
  (.inventory_sha256|type=="string") and
  (.repository_bundles|length>0) and all(.repository_bundles[];.verified==true) and
  ([.repository_bundles[]|select(.repo_id=="local_laptop" and .surface=="private_repository" and
     (.access_policy_ref|type=="string"))]|length)==1 and
  all(.repository_bundles[]|select(.repo_id!="local_laptop");
      .surface=="shared_repository" and (.access_policy_ref|type=="string")) and
  (.deployment_seed_receipt|type)=="object" and
  .deployment_seed_receipt.schema=="deployment-seed-receipt/1" and
  .deployment_seed_receipt.producer_package=="PRESERVE-00" and
  .deployment_seed_receipt.consumer_package=="RUNTIME-01" and
  .deployment_seed_receipt.canonical_output=="orchestrator/deploy.yaml" and
  .deployment_seed_receipt.canonical_output_owner=="RUNTIME-01" and
  .deployment_seed_receipt.contains_canonical_output_bytes==false and
  .deployment_seed_receipt.seed.schema=="deployment-seed/1" and
  .deployment_seed_receipt.seed.automerge_enabled==false and
  .deployment_seed_receipt.seed.reserved_job_ids==[
    "job.pipeline.nightly","job.backup.independent","job.deadman.independent"
  ] and
  (.deployment_seed_receipt.seed_sha256|test("^[0-9a-f]{64}$")) and
  (.deployment_seed_receipt.receipt_sha256|test("^[0-9a-f]{64}$")) and
  .empty_restore.schema=="empty-restore-receipt/1" and .empty_restore.scope=="preservation" and
  .empty_restore.status=="passed" and
  .empty_restore.source_inventory_sha256==.empty_restore.restored_inventory_sha256 and
  ([.empty_restore.checks[]]|sort)==(["bundle_verify","clone_empty","event_replay","fsck","head_match","manifest_replay","no_symlink_escape"]|sort) and
  (.empty_restore.receipt_sha256|type=="string") and
  (.limitations|type=="array")
' "$preservation_receipt_abs" >/dev/null || exit 1
test "$preservation_rc" -eq 0 || exit 1
```

`SCHEMA-CFG-10.R003`, exercised by both successful validation results above, recomputes `seed_sha256` from RFC 8785 canonical `deployment_seed_receipt.seed` and `receipt_sha256` from the RFC 8785 canonical deployment-seed receipt with only `receipt_sha256` omitted. The canonical persisted handoff is the nested receipt inside `state/runs/<run_id>/global/preservation-receipt.json`; do not create a competing seed file. `RUNTIME-01` must consume that exact nested record, revalidate both hashes, and remains the only package allowed to create or own `orchestrator/deploy.yaml`.

Verify the receipt's target-relative bundle inventory by resolving each configured access domain in memory and applying `canonical_file_beneath` to every bundle before digest/head inspection. The single `local_laptop` row must resolve only in its private target or access-separated private partition under its named access policy; no shared bundle consumer may enumerate or read it. Every other row resolves in the shared repository partition. The empty-directory restore must reproduce every listed repository head with symlinks disabled and preserve that separation. Preserve the receipt, inventory digest, bundle-head proof, empty-restore receipt, and the two successful `SCHEMA-CFG-10` validation results. Missing or mismatched deployment-seed evidence is a failed Stage −1 attempt, never permission to infer or regenerate a seed. This closes only pre-mutation preservation; shared Stage-3 completion still requires `RB-RESTORE-01`, `SCHEMA-CFG-13`, completed evidence artifacts, and event high-water validation.

## RB-RESTORE-01 — Verified backup creation and inventory

**Owner:** maintainer. Decision #11 owns recovery target class; `TH-TGT-011`, `TH-TGT-012`, `TH-TGT-013`, `TH-TGT-014`, `TH-TGT-074`, `TH-TGT-075`, and `SCHEMA-CFG-04.jobs[].receipt.max_age_policy_ref` own applicable values. `PIPE-G-07` and `PIPE-REC-08` own the boundary.

This procedure is the shared Stage-3 evidence backup and produces `SCHEMA-CFG-13`; it is not the Stage −1 `SCHEMA-CFG-10` preservation receipt in `RB-RESTORE-00`. **Preconditions:** the shared target uses the at-rest control selected by decision #16 and repository identities are known. Resolve the backup job's `SCHEMA-CFG-04` `target_ref` in memory and reject a missing, local, read-only, in-tree, or private-repository target. Never persist `resolved_path`; the redacted evidence copy nulls it and is not itself a conforming resolver result. The private `local_laptop` bundle remains in the access-separated `SCHEMA-CFG-10` preservation topology and cannot enter this request, manifest, receipt, or restore. Decision #20 does not define whether backup rotation or purge is permitted; `RB-RESTORE-04` is the only pending-decision behavior.

```bash
backup_target_ref=$(wiki config get --config orchestrator/deploy.yaml --job-id job.backup.independent --field target_ref) || exit 1
backup_resolution_json=$(wiki config resolve --target-ref "$backup_target_ref" --json)
backup_resolution_rc=$?
printf '%s\n' "$backup_resolution_rc" > "$operator_evidence_dir/backup-target-resolution.exit"
printf '%s' "$backup_resolution_json" | jq -e --arg ref "$backup_target_ref" --argjson rc "$backup_resolution_rc" '
  .schema=="tool-result/1" and .tool=="resolve_target" and
  .exit_code==$rc and .page==null and (.request_id|type=="string") and
  (.generated_at|type=="string") and (.warnings|type=="array") and
  all(.warnings[];(keys|sort)==["code","redacted_message"] and
      (.code|type=="string") and (.redacted_message|type=="string")) and
  (keys|sort)==["data","exit_code","generated_at","page","request_id","schema","status","tool","warnings"] and
  ((.status=="ok" and .exit_code==0 and
    (.data|keys|sort)==["device_id_digest","off_host","reason_code","repository_scope","resolved","resolved_path","surface","target_id_digest","target_ref","writable"] and
    .data.target_ref==$ref and .data.resolved==true and .data.off_host==true and .data.writable==true and
    .data.surface=="shared_stage3" and .data.repository_scope=="shared_wikis_and_control_plane" and
    (.data.resolved_path|type=="string") and (.data.target_id_digest|test("^[0-9a-f]{64}$")) and
    (.data.device_id_digest|test("^[0-9a-f]{64}$")) and .data.reason_code==null) or
   (.status=="error" and .exit_code==1 and
    (.data|keys|sort)==["device_id_digest","off_host","reason_code","repository_scope","resolved","resolved_path","surface","target_id_digest","target_ref","writable"] and
    .data.target_ref==$ref and (.data.resolved|type)=="boolean" and (.data.off_host|type)=="boolean" and
    (.data.writable|type)=="boolean" and .data.resolved_path==null and
    (.data.surface|IN("shared_stage3","private_repository")) and
    (.data.repository_scope|IN("shared_wikis_and_control_plane","local_laptop_only")) and
    (.data.resolved==false or .data.writable==false) and (.data.reason_code|type=="string") and
    (.data.target_id_digest|test("^[0-9a-f]{64}$")) and (.data.device_id_digest|test("^[0-9a-f]{64}$"))) or
   (.status=="error" and .exit_code==3 and .data==null))
' >/dev/null || exit 1
printf '%s' "$backup_resolution_json" | jq 'if (.data|type)=="object" then .data.resolved_path=null else . end' \
  > "$operator_evidence_dir/backup-target-resolution.redacted.json" || exit 1
printf '%s' "$backup_resolution_json" | jq -e '
  .status=="ok" and .exit_code==0 and .data.resolved==true and .data.off_host==true and
  .data.writable==true and .data.surface=="shared_stage3" and
  .data.repository_scope=="shared_wikis_and_control_plane"
' >/dev/null || exit 1
test "$backup_resolution_rc" -eq 0 || exit 1
backup_parent_abs=$(printf '%s' "$backup_resolution_json" | jq -er '.data.resolved_path') || exit 1
backup_parent_candidate=$backup_parent_abs
backup_parent_abs=$(canonical_existing_dir "$backup_parent_candidate") || exit 1
test "$backup_parent_abs" = "$backup_parent_candidate" || exit 1
unset backup_resolution_json
case "$backup_parent_abs" in "$wiki_root_abs"|"$wiki_root_abs"/*) exit 1 ;; esac
backup_job_id=${BACKUP_JOB_ID:?BACKUP_JOB_ID is required}
test "$backup_job_id" = 'job.backup.independent' || exit 1
backup_request_rel="state/backup/requests/$operator_run_id.json"
backup_request_abs=$(canonical_file_beneath "$wiki_root_abs" "$backup_request_rel") || exit 1
validate_contract_file backup-request/1 SCHEMA-CFG-18 "$backup_request_abs" \
  "$operator_evidence_dir/backup-request.validation.json" || exit 1
backup_request_id=$(jq -er '.request_id' "$backup_request_abs") || exit 1
backup_request_sha256=$(jq -er '.request_sha256' "$backup_request_abs") || exit 1
jq -e --arg run "$operator_run_id" --arg target "$backup_target_ref" '
  .schema=="backup-request/1" and .run_id==$run and .backup_surface=="shared_stage3" and
  .target_ref==$target and
  (.requested_evidence_roots|sort)==(["raw/objects","raw/_index","state/events"]|sort) and
  .restore_required==true
' "$backup_request_abs" >/dev/null || exit 1
wiki deployment job run --job-id "$backup_job_id" --run-id "$operator_run_id" --json > "$operator_evidence_dir/backup-job-run.json"
backup_run_rc=$?; printf '%s\n' "$backup_run_rc" > "$operator_evidence_dir/backup-job-run.exit"
validate_contract_file deployment-job-result/1 SCHEMA-CFG-15 "$operator_evidence_dir/backup-job-run.json" \
  "$operator_evidence_dir/backup-job-run.validation.json" || exit 1
backup_receipt_rel="state/scheduler/receipts/job.backup.independent/$operator_run_id-backup.json"
backup_receipt_abs=$(canonical_file_beneath "$wiki_root_abs" "$backup_receipt_rel") || exit 1
validate_contract_file backup-receipt/1 SCHEMA-CFG-13 "$backup_receipt_abs" \
  "$operator_evidence_dir/backup-persisted.validation.json" || exit 1
jq -e --slurpfile persisted "$backup_receipt_abs" '.receipt==$persisted[0]' \
  "$operator_evidence_dir/backup-job-run.json" >/dev/null || exit 1
```

The target resolver uses the total `SCHEMA-CFG-02` mapping: resolved/writable is `status=ok`, embedded/process exit 0; a completed unresolved or non-writable decision is `status=error`, exit 1, null `resolved_path`, and a reason code; inability to run the resolution is `status=error`, exit 3. Either error stops before the backup job. Never persist the successful ephemeral path; only the null-path redacted projection and exit evidence above may remain.

Process success is not backup success. Require the exact request and invocation, passed verification, acquired request-bound lock receipt, canonical snapshot manifest, target-relative snapshot, verified shared repository rows, all three Stage-3 evidence families (`raw/objects/**`, `raw/_index/**`, and `state/events/**`), an event high-water mark, and a passed embedded restore receipt. A pre-Stage-3 snapshot lacking any family is preservation evidence, not a complete `RB-RESTORE-01` receipt.

`snapshot-manifest/1` is the sole payload inventory. It covers every repository bundle and evidence payload and excludes `receipts/**`; receipts contain `manifest_sha256` and are validated separately, so including them would create a self-reference. All manifest paths are target-relative and contain no absolute path. The restore preimage and domain are distinct: `snapshot_inventory_sha256 = SHA256(RFC8785({repositories:snapshot_manifest.repositories,evidence_paths:snapshot_manifest.evidence_paths,event_high_water:snapshot_manifest.event_high_water}))`. This value MUST NOT be derived from or substituted with `manifest_sha256`; coincidental digest equality would not waive projection validation. The common helper hashes that closed projection only after `SCHEMA-CFG-13` validation. Its `jq -cS` bytes are the RFC 8785 bytes for this schema-closed value because all object member names are fixed ASCII contract names, numeric members are schema integers, strings are emitted as UTF-8 JSON strings, and array order is preserved; `CONTRACT-01` must retain a known-answer parity test for this helper.

```bash
snapshot_inventory_sha256=$(snapshot_inventory_sha256_from_job_result \
  "$operator_evidence_dir/backup-job-run.json") || exit 1
jq -e --arg run "$operator_run_id" --arg job "$backup_job_id" --arg request "$backup_request_id" \
  --arg request_sha "$backup_request_sha256" --arg target "$backup_target_ref" \
  --arg snapshot_inventory_sha "$snapshot_inventory_sha256" --argjson rc "$backup_run_rc" \
  --slurpfile expected_request "$backup_request_abs" '
  .schema=="deployment-job-result/1" and .operation=="run" and .exit_code==0 and
  .exit_code==$rc and
  .run_id==$run and .job_id==$job and .status=="succeeded" and .receipt_kind=="backup" and
  .receipt.schema=="backup-receipt/1" and .receipt.run_id==$run and
  .receipt.request_id==$request and .receipt.request_sha256==$request_sha and
  .receipt.request==$expected_request[0] and .receipt.target_ref==$target and
  .receipt.verification_status=="passed" and .receipt.head_stability=="stable" and .receipt.failure==null and
  .receipt.snapshot_manifest.schema=="snapshot-manifest/1" and
  .receipt.snapshot_manifest.request_id==$request and .receipt.snapshot_manifest.request_sha256==$request_sha and
  .receipt.snapshot_manifest.target_ref==$target and
  .receipt.snapshot_rel==.receipt.snapshot_manifest.snapshot_rel and
  .receipt.manifest_sha256==.receipt.snapshot_manifest.manifest_sha256 and
  .receipt.repositories==.receipt.snapshot_manifest.repositories and
  .receipt.evidence_paths==.receipt.snapshot_manifest.evidence_paths and
  .receipt.event_high_water==.receipt.snapshot_manifest.event_high_water and
  .receipt.event_high_water==.receipt.request.event_high_water and
  (.receipt as $receipt|all($receipt.repositories[];
    $receipt.request.repository_heads[.repo_id]==.head)) and
  .receipt.lock_receipt.schema=="deployment-lock-receipt/1" and
  .receipt.lock_receipt.job_id==$job and .receipt.lock_receipt.run_id==$run and
  .receipt.lock_receipt.request_id==$request and .receipt.lock_receipt.status=="acquired" and
  (.receipt.lock_receipt_sha256|test("^[0-9a-f]{64}$")) and
  (.receipt.repositories|length>0) and
  all(.receipt.repositories[];.verified==true and .surface=="shared_repository" and .repo_id!="local_laptop" and
      (.access_policy_ref|type=="string")) and
  any(.receipt.evidence_paths[];.path|startswith("raw/objects/")) and
  any(.receipt.evidence_paths[];.path|startswith("raw/_index/")) and
  any(.receipt.evidence_paths[];.path|startswith("state/events/")) and
  (.receipt.event_high_water.segment|startswith("state/events/")) and
  .receipt.restore_test.schema=="empty-restore-receipt/1" and .receipt.restore_test.scope=="stage3" and
  .receipt.restore_test.request_id==$request and .receipt.restore_test.status=="passed" and
  .receipt.restore_test.source_inventory_sha256==$snapshot_inventory_sha and
  .receipt.restore_test.restored_inventory_sha256==$snapshot_inventory_sha and
  ([.receipt.restore_test.checks[]]|sort)==(["bundle_verify","clone_empty","event_replay","fsck","head_match","manifest_replay","no_symlink_escape"]|sort)
' "$operator_evidence_dir/backup-job-run.json" >/dev/null || exit 1
test "$backup_run_rc" -eq 0 || exit 1
snapshot_rel=$(jq -er '.receipt.snapshot_rel' "$operator_evidence_dir/backup-job-run.json") || exit 1
backup_snapshot_abs=$(canonical_dir_beneath "$backup_parent_abs" "$snapshot_rel") || exit 1
test -z "$(find "$backup_snapshot_abs" -type l -print -quit)" || exit 1
jq -j '(.receipt.snapshot_manifest.repositories[].bundle_rel),(.receipt.snapshot_manifest.evidence_paths[].path)|.,"\u0000"' \
  "$operator_evidence_dir/backup-job-run.json" | LC_ALL=C sort -zu \
  > "$operator_evidence_dir/backup-expected.paths0" || exit 1
(cd "$backup_snapshot_abs" && find . -type f ! -path './receipts/*' -print0 | \
  while IFS= read -r -d '' found_rel; do printf '%s\0' "${found_rel#./}"; done | LC_ALL=C sort -zu) \
  > "$operator_evidence_dir/backup-actual.paths0" || exit 1
cmp -s "$operator_evidence_dir/backup-expected.paths0" "$operator_evidence_dir/backup-actual.paths0" || exit 1
while IFS=$'\t' read -r payload_rel expected_sha; do
  payload_abs=$(canonical_file_beneath "$backup_snapshot_abs" "$payload_rel") || exit 1
  test "$(shasum -a 256 "$payload_abs" | awk '{print $1}')" = "$expected_sha" || exit 1
done < <(jq -r '(.receipt.snapshot_manifest.repositories[]|[.bundle_rel,.bundle_sha256]),
                  (.receipt.snapshot_manifest.evidence_paths[]|[.path,.sha256])|@tsv' \
  "$operator_evidence_dir/backup-job-run.json")
```

Verify every bundle digest/head without logging its absolute path:

```bash
while IFS=$'\t' read -r repo_id expected_head bundle_rel expected_sha; do
  bundle_abs=$(canonical_file_beneath "$backup_snapshot_abs" "$bundle_rel") || exit 1
  test "$(shasum -a 256 "$bundle_abs" | awk '{print $1}')" = "$expected_sha" || exit 1
  git bundle verify "$bundle_abs" >/dev/null 2>&1 || exit 1
  git bundle list-heads "$bundle_abs" | awk -v head="$expected_head" '$1==head{ok=1} END{exit !ok}' || exit 1
  printf '%s\t%s\n' "$repo_id" "$expected_head"
done < <(jq -r '.receipt.snapshot_manifest.repositories[]|[.repo_id,.head,.bundle_rel,.bundle_sha256]|@tsv' \
  "$operator_evidence_dir/backup-job-run.json") > "$operator_evidence_dir/bundle-heads-verified.tsv"
```

The canonical receipt is the redacted job result, persisted `SCHEMA-CFG-13`, complete expected/actual relative path comparison, every payload digest, and bundle-head proof. It binds the exact `SCHEMA-CFG-18` request, snapshot manifest/bytes, repository heads, evidence digests, event high-water, scheduler/lock receipts, and completed restore. The authoritative `SCHEMA-REL-02` journal remains repository authority; a run-scratch copy is only recovery payload. Any missing, extra, private-surface, or failed element triggers `RB-ALERT-01`; process death never implies a receipt.

## RB-RESTORE-02 — Empty-directory and symlinkless restore drill

Run only from a verified `RB-RESTORE-01` snapshot. Create a new directory; never restore over the live tree. `make restore-test` is conforming only when it implements `PIPE-REC-08`, hashes every expected restored regular file, rejects every missing, changed, extra, or symlinked path, and emits `SCHEMA-CFG-02 tool=restore_test` with its `empty-restore-receipt/1` in `data`. It never prints a resolved backup or restore path.

```bash
restore_parent_abs=$(canonical_existing_dir "${TMPDIR:?}") || exit 1
restore_candidate=$(mktemp -d "$restore_parent_abs/wiki-restore.${operator_run_id}.XXXXXX") || exit 1
restore_abs=$(canonical_existing_dir "$restore_candidate") || exit 1
case "$restore_abs" in "$restore_parent_abs"/*) ;; *) exit 1 ;; esac
BACKUP_SNAPSHOT="$backup_snapshot_abs" RESTORE_ROOT="$restore_abs" \
  GIT_CORE_SYMLINKS=false make restore-test \
  > "$operator_evidence_dir/restore-test.json" 2> "$operator_evidence_dir/restore-test.stderr"
restore_rc=$?; printf '%s\n' "$restore_rc" > "$operator_evidence_dir/restore-test.exit"
rg -F -- "$backup_snapshot_abs" "$operator_evidence_dir/restore-test.stderr" >/dev/null
backup_path_leak_rc=$?; test "$backup_path_leak_rc" -eq 1 || exit 1
rg -F -- "$restore_abs" "$operator_evidence_dir/restore-test.stderr" >/dev/null
restore_path_leak_rc=$?; test "$restore_path_leak_rc" -eq 1 || exit 1
validate_contract_file tool-result/1 SCHEMA-CFG-02 "$operator_evidence_dir/restore-test.json" \
  "$operator_evidence_dir/restore-test.validation.json" || exit 1
snapshot_inventory_sha256=$(snapshot_inventory_sha256_from_job_result \
  "$operator_evidence_dir/backup-job-run.json") || exit 1
jq -e --arg request "$backup_request_id" --arg snapshot_inventory_sha "$snapshot_inventory_sha256" \
  --argjson rc "$restore_rc" '
  .schema=="tool-result/1" and .tool=="restore_test" and .status=="ok" and
  .exit_code==0 and .exit_code==$rc and .page==null and
  .data.schema=="empty-restore-receipt/1" and .data.request_id==$request and
  .data.scope=="stage3" and .data.status=="passed" and
  .data.source_inventory_sha256==$snapshot_inventory_sha and
  .data.restored_inventory_sha256==$snapshot_inventory_sha and
  ([.data.checks[]]|sort)==(["bundle_verify","clone_empty","event_replay","fsck","head_match","manifest_replay","no_symlink_escape"]|sort) and
  (.data.restore_root_fingerprint|test("^[0-9a-f]{64}$")) and
  (.data.receipt_sha256|test("^[0-9a-f]{64}$"))
' "$operator_evidence_dir/restore-test.json" >/dev/null || exit 1
test "$restore_rc" -eq 0 || exit 1
jq '.data' "$operator_evidence_dir/restore-test.json" \
  > "$operator_evidence_dir/empty-restore-receipt.json" || exit 1
test -n "$(find "$restore_abs" -type f -print -quit)" || exit 1
test -z "$(find "$restore_abs" -type l -print -quit)" || exit 1
canonical_dir_beneath "$restore_abs" raw/objects >/dev/null || exit 1
canonical_dir_beneath "$restore_abs" state/events >/dev/null || exit 1
while IFS=$'\t' read -r evidence_rel expected_sha; do
  case "$evidence_rel" in raw/objects/*|raw/_index/*|raw/quarantine/*|state/events/*) ;; *) exit 1 ;; esac
  evidence_abs=$(canonical_file_beneath "$restore_abs" "$evidence_rel") || exit 1
  test "$(shasum -a 256 "$evidence_abs" | awk '{print $1}')" = "$expected_sha" || exit 1
done < <(jq -r '.receipt.evidence_paths[]|[.path,.sha256]|@tsv' \
  "$operator_evidence_dir/backup-job-run.json")
while IFS=$'\t' read -r repo_id expected_head; do
  case "$repo_id" in control-plane) restored_repo_abs="$restore_abs" ;; *[!a-z0-9_-]*|'') exit 1 ;; *) restored_repo_abs="$restore_abs/$repo_id" ;; esac
  if test "$repo_id" != control-plane; then restored_repo_abs=$(canonical_dir_beneath "$restore_abs" "$repo_id") || exit 1; fi
  test "$(git -C "$restored_repo_abs" rev-parse HEAD)" = "$expected_head" || exit 1
done < <(jq -r '.receipt.repositories[]|[.repo_id,.head]|@tsv' \
  "$operator_evidence_dir/backup-job-run.json")
event_segment=$(jq -er '.receipt.event_high_water.segment' "$operator_evidence_dir/backup-job-run.json") || exit 1
event_line=$(jq -er '.receipt.event_high_water.line' "$operator_evidence_dir/backup-job-run.json") || exit 1
event_id=$(jq -er '.receipt.event_high_water.event_id' "$operator_evidence_dir/backup-job-run.json") || exit 1
case "$event_segment" in state/events/*) ;; *) exit 1 ;; esac
[[ "$event_line" =~ ^[1-9][0-9]*$ ]] || exit 1
event_segment_abs=$(canonical_file_beneath "$restore_abs" "$event_segment") || exit 1
sed -n "${event_line}p" "$event_segment_abs" | jq -e --arg id "$event_id" '.event_id==$id' >/dev/null || exit 1
```

The outer validated tool result is the emitted receipt authority; extracting `.data` creates a convenient byte-for-byte operator evidence copy, not a second authority. Its `manifest_replay` check covers the complete restored regular-file inventory and forbids unlisted output; the explicit evidence, head, and event checks above are independent semantic spot proofs and never substitute for that complete replay. Expected observations also include rebuilt views and passing raw/index/schema/wiki/query/smoke checks. Record elapsed time against `TH-TGT-014` and `TH-TGT-075`; record backup recency against `TH-TGT-074`. Preserve failures; retain or recoverably archive successes—never delete here.

## RB-RESTORE-03 — Age, dead-man, and rotation control

`SCHEMA-CFG-04.jobs` configures backup and dead-man as scheduler entries independent of the pipeline process; `PIPE-G-07` and `PIPE-REC-08` own their lock and receipt behavior. Require the reserved job IDs as arguments and inspect both rather than assuming any process emitted a receipt:

```bash
backup_job_id=${BACKUP_JOB_ID:?BACKUP_JOB_ID is required}
deadman_job_id=${DEADMAN_JOB_ID:?DEADMAN_JOB_ID is required}
test "$backup_job_id" = 'job.backup.independent' || exit 1
test "$deadman_job_id" = 'job.deadman.independent' || exit 1
wiki deployment job inspect --job-id "$backup_job_id" --json \
  > "$operator_evidence_dir/backup-job.json"
backup_inspect_rc=$?; printf '%s\n' "$backup_inspect_rc" > "$operator_evidence_dir/backup-job.exit"
wiki deployment job inspect --job-id "$deadman_job_id" --json \
  > "$operator_evidence_dir/deadman-job.json"
deadman_inspect_rc=$?; printf '%s\n' "$deadman_inspect_rc" > "$operator_evidence_dir/deadman-job.exit"
validate_contract_file deployment-job-inspect-result/1 SCHEMA-CFG-16 "$operator_evidence_dir/backup-job.json" \
  "$operator_evidence_dir/backup-job.validation.json" || exit 1
validate_contract_file deployment-job-inspect-result/1 SCHEMA-CFG-16 "$operator_evidence_dir/deadman-job.json" \
  "$operator_evidence_dir/deadman-job.validation.json" || exit 1
jq -e --arg job "$backup_job_id" --argjson rc "$backup_inspect_rc" '
  .schema=="deployment-job-inspect-result/1" and .operation=="inspect" and
  .job_id==$job and .exit_code==$rc and
  ((.latest_receipt_kind==null and .latest_receipt==null) or
   (.latest_receipt_kind=="scheduler" and .latest_receipt.schema=="scheduler-receipt/1") or
   (.latest_receipt_kind=="backup" and .latest_receipt.schema=="backup-receipt/1"))
' "$operator_evidence_dir/backup-job.json" >/dev/null || exit 1
jq -e --arg job "$deadman_job_id" --argjson rc "$deadman_inspect_rc" '
  .schema=="deployment-job-inspect-result/1" and .operation=="inspect" and
  .job_id==$job and .exit_code==$rc and
  ((.latest_receipt_kind==null and .latest_receipt==null) or
   (.latest_receipt_kind=="scheduler" and .latest_receipt.schema=="scheduler-receipt/1") or
   (.latest_receipt_kind=="deadman" and .latest_receipt.schema=="deadman-receipt/1"))
' "$operator_evidence_dir/deadman-job.json" >/dev/null || exit 1
test "$backup_inspect_rc" -ne 3 && test "$deadman_inspect_rc" -ne 3 || exit 1
backup_needs_recovery=0
jq -e '.exit_code==0 and .latest_receipt_kind=="backup" and
       .latest_receipt.status=="succeeded" and .latest_receipt.verification_status=="passed" and
       .latest_receipt.head_stability=="stable"' \
  "$operator_evidence_dir/backup-job.json" >/dev/null || backup_needs_recovery=1
deadman_unhealthy=0
jq -e '.exit_code==0 and .latest_receipt_kind=="deadman" and
       .latest_receipt.status=="healthy" and .latest_receipt.deployment_health=="healthy"' \
  "$operator_evidence_dir/deadman-job.json" >/dev/null || deadman_unhealthy=1
```

Compare `SCHEMA-CFG-11` scheduler start/completion, `SCHEMA-CFG-12` pipeline completion, `SCHEMA-CFG-13` backup verification, and `SCHEMA-CFG-14` dead-man receipts using each job's `receipt.max_age_policy_ref`. Missing pipeline or backup completion never becomes an invented `run-result/1`: the dead-man job writes the configured durable alert and blocks cleanup/autonomy. `SCHEMA-CFG-16` may validly return exit 0 with a null or scheduler-only latest receipt, so `backup_needs_recovery` and `deadman_unhealthy` deliberately evaluate the typed receipt, not just process exit. When backup recovery is needed, inspect locks, preserve incomplete artifacts, run the exact command below, and validate/persist its discriminated result before accepting any checkpoint:

For a launcher-death incident, require a flushed `SCHEMA-CFG-11` pipeline start with `child_status=not_checked` and null native exit/digest. If the scheduler wrapper survived, require its completion with the native exit, `child_status=missing`, null child digest, then a `SCHEMA-CFG-12 status=missing` receipt with null global-result digest/exit/completion time and a non-null failure. The independent `SCHEMA-CFG-14` typed finding must bind the expected and observed start/completion/pipeline receipt digests, evaluation cutoff, age policy, and alert. If the wrapper also died, require the start plus explicit absence of both completion and `SCHEMA-CFG-12`, then the typed dead-man finding. Verify the dead-man scheduler entry has a distinct launcher identity from the pipeline. Stop if a purported successful pipeline receipt appears after an untrappable death without a valid global result, or if dead-man was configured as a pipeline child.

```bash
if test "$backup_needs_recovery" -eq 1; then
  wiki deployment job run --job-id "$backup_job_id" --run-id "$operator_run_id" --json \
    > "$operator_evidence_dir/backup-recovery-run.json"
  backup_recovery_rc=$?; printf '%s\n' "$backup_recovery_rc" > "$operator_evidence_dir/backup-recovery-run.exit"
  validate_contract_file deployment-job-result/1 SCHEMA-CFG-15 "$operator_evidence_dir/backup-recovery-run.json" \
    "$operator_evidence_dir/backup-recovery-run.validation.json" || exit 1
  jq -e --arg job "$backup_job_id" --arg run "$operator_run_id" --argjson rc "$backup_recovery_rc" '
    .schema=="deployment-job-result/1" and .operation=="run" and .job_id==$job and
    .run_id==$run and .status=="succeeded" and .exit_code==0 and .exit_code==$rc and
    .failure==null and .receipt_kind=="backup" and .receipt.schema=="backup-receipt/1" and
    .receipt.status=="succeeded" and .receipt.verification_status=="passed" and
    .receipt.head_stability=="stable" and .receipt.failure==null
  ' "$operator_evidence_dir/backup-recovery-run.json" >/dev/null || exit 1
  test "$backup_recovery_rc" -eq 0 || exit 1
  backup_recovery_receipt_rel="state/scheduler/receipts/job.backup.independent/$operator_run_id-backup.json"
  backup_recovery_receipt_abs=$(canonical_file_beneath "$wiki_root_abs" "$backup_recovery_receipt_rel") || exit 1
  validate_contract_file backup-receipt/1 SCHEMA-CFG-13 "$backup_recovery_receipt_abs" \
    "$operator_evidence_dir/backup-recovery-persisted.validation.json" || exit 1
  jq -e --slurpfile persisted "$backup_recovery_receipt_abs" '.receipt==$persisted[0]' \
    "$operator_evidence_dir/backup-recovery-run.json" >/dev/null || exit 1
fi
```

If the pipeline died, even a successful backup receipt is a recovery checkpoint until `SCHEMA-REL-09` independently proves release state. A missing or unhealthy dead-man receipt is always a stop condition; capture the canonical doctor result and retain the existing typed alert when present:

```bash
if test "$deadman_unhealthy" -eq 1; then
  wiki doctor --json > "$operator_evidence_dir/deadman-doctor.json"
  deadman_doctor_rc=$?; printf '%s\n' "$deadman_doctor_rc" > "$operator_evidence_dir/deadman-doctor.exit"
  validate_contract_file doctor-result/1 SCHEMA-CFG-03 "$operator_evidence_dir/deadman-doctor.json" \
    "$operator_evidence_dir/deadman-doctor.validation.json" || exit 1
  jq -e --argjson rc "$deadman_doctor_rc" '
    .schema=="doctor-result/1" and .exit_code==$rc
  ' "$operator_evidence_dir/deadman-doctor.json" >/dev/null || exit 1
  if jq -e '.latest_receipt_kind=="deadman" and .latest_receipt.status=="failed" and
            (.latest_receipt.alerts|length)>0' "$operator_evidence_dir/deadman-job.json" >/dev/null; then
    jq -r '.latest_receipt.alerts[]' "$operator_evidence_dir/deadman-job.json" \
      > "$operator_evidence_dir/deadman-alert-ids.txt" || exit 1
  fi
  exit 1
fi
```

Use every recorded alert ID with `RB-ALERT-01`; when none exists because the dead-man receipt itself is absent, alert through the configured deployment fallback and repair the scheduler before resuming autonomy. Never fabricate an alert ID for a missing dead-man receipt.

While decision #20 is pending, do not rotate. After it is resolved, rotation still requires a newer verified/restored snapshot, an explicit target-relative candidate, no incident dependency, and the selected schema policy. `PIPE-REC-07` permits recoverable archival only; this runbook authorizes no deletion.

## RB-RESTORE-04 — Pending decision #20

Decision #20 is unresolved. On any purge request, hold signal, or suspected confidential payload: preserve the object/event/index and backup material; isolate access without deleting or rewriting it; stop publication, rotation, and purge; and escalate to the maintainer and legal/privacy owner. Do not infer purge authority, approval count, hold precedence, backup treatment, or non-resurrection behavior. Those steps become operable only after decision #20 selects a schema-versioned policy; until then this runbook contains no purge command.

## RB-ROLLBACK-01 — Release inspection and stop decision

For a bad merge, wrong evidence binding, mixed release, pointer mismatch, or suspected corruption, stop new publication and inspect the durable journal. These commands are read-only:

```bash
release_id=${RELEASE_ID:?RELEASE_ID is required}
wiki release inspect --id "$release_id" --json > "$operator_evidence_dir/release-inspect.json"
release_inspect_rc=$?; printf '%s\n' "$release_inspect_rc" > "$operator_evidence_dir/release-inspect.exit"
validate_contract_file release-inspect-result/1 SCHEMA-REL-09 "$operator_evidence_dir/release-inspect.json" \
  "$operator_evidence_dir/release-inspect.validation.json" || exit 1
jq -e --arg id "$release_id" --argjson rc "$release_inspect_rc" '
  .schema=="release-inspect-result/1" and .operation=="inspect" and .release_id==$id and
  .exit_code==$rc and
  ((.integrity=="valid" and .exit_code==0) or
   (.integrity=="valid" and .reader_visibility=="recovery_only" and .exit_code==1) or
   (.integrity=="mixed" and .reader_visibility=="recovery_only" and .exit_code==1))
' "$operator_evidence_dir/release-inspect.json" >/dev/null || exit 1
journal_rel=$(jq -er '.journal.path' "$operator_evidence_dir/release-inspect.json") || exit 1
test "$journal_rel" = "state/releases/journals/$release_id.jsonl" || exit 1
journal_abs=$(canonical_file_beneath "$wiki_root_abs" "$journal_rel") || exit 1
git status --short > "$operator_evidence_dir/root-status.txt"
git worktree list --porcelain > "$operator_evidence_dir/worktrees.txt"
```

Verify `SCHEMA-REL-00`, `SCHEMA-REL-01`, the authoritative committed `SCHEMA-REL-02` journal, `SCHEMA-REL-03`, `SCHEMA-REL-06`, `SCHEMA-REL-08`, expected/actual heads, and checkpoint as defined by `PIPE-REC-03` and `PIPE-REC-04`. The journal path reported by `SCHEMA-REL-09` must be exactly `state/releases/journals/<release_id>.jsonl`; canonicalize its parent beneath `wiki_root_abs`, require a regular non-symlink file, and reject any run-local journal as authority. Stop if the ID is ambiguous, any manifest repo is dirty, evidence is missing, a head is outside the manifest, another release owns the lock, or the incident may involve secrets/PII/injection.

## RB-ROLLBACK-02 — Resume or audited rollback

Choose exactly one `RECOVERY_ACTION` after `RB-ROLLBACK-01`. **Resume** only when `SCHEMA-REL-09.legal_next_actions` contains `resume` and inspection proves the next checkpoint idempotent under `PIPE-REC-05`. The immutable `SCHEMA-REL-00.approval_class` selects the command form: `none` forbids an approval option/receipt/event, while `human` or `policy` requires its matching `SCHEMA-REL-06`. **Rollback** requires `rollback` in that same list and a `SCHEMA-REL-07` authorization carrying distinct maintainer and recovery-controller approvals; a reason file or either actor alone is insufficient.

```bash
recovery_action=${RECOVERY_ACTION:?RECOVERY_ACTION is required}
case "$recovery_action" in
  resume)
    jq -e '.legal_next_actions|index("resume")!=null' "$operator_evidence_dir/release-inspect.json" >/dev/null || exit 1
    proposal_rel=${RELEASE_PROPOSAL_REL:?RELEASE_PROPOSAL_REL is required}
    case "$proposal_rel" in state/runs/*/global/release-proposal.json) ;; *) exit 1 ;; esac
    proposal_abs=$(canonical_file_beneath "$wiki_root_abs" "$proposal_rel") || exit 1
    validate_contract_file release-proposal/1 SCHEMA-REL-00 "$proposal_abs" \
      "$operator_evidence_dir/release-proposal.validation.json" || exit 1
    proposal_origin_run_id=$(jq -er '.origin_run_id' "$proposal_abs") || exit 1
    test "$proposal_rel" = "state/runs/$proposal_origin_run_id/global/release-proposal.json" || exit 1
    jq -e --arg id "$release_id" '.schema=="release-proposal/1" and .release_id==$id' \
      "$proposal_abs" >/dev/null || exit 1
    approval_class=$(jq -er '.approval_class' "$proposal_abs") || exit 1
    case "$approval_class" in
      none)
        test -z "${APPROVAL_RECEIPT_REL-}" || exit 1
        jq -s -e 'all(.[]; .event_kind!="approval_received")' \
          "$journal_abs" >/dev/null || exit 1
        wiki release resume --id "$release_id" --json \
          > "$operator_evidence_dir/release-resume.json"
        ;;
      human|policy)
        approval_rel=${APPROVAL_RECEIPT_REL:?APPROVAL_RECEIPT_REL is required}
        approval_leaf=${approval_rel##*/}
        test "$approval_rel" = "state/releases/approvals/$approval_leaf" || exit 1
        case "$approval_leaf" in "$release_id"-*.json) ;; *) exit 1 ;; esac
        approval_abs=$(canonical_file_beneath "$wiki_root_abs" "$approval_rel") || exit 1
        validate_contract_file approval-receipt/1 SCHEMA-REL-06 "$approval_abs" \
          "$operator_evidence_dir/approval-receipt.validation.json" || exit 1
        proposal_sha256=$(jq -er '.proposal_sha256' "$proposal_abs") || exit 1
        jq -e --arg id "$release_id" --arg class "$approval_class" --arg proposal "$proposal_sha256" '
          .schema=="approval-receipt/1" and .release_id==$id and .approval_class==$class and
          .proposal_sha256==$proposal and .decision=="approve"
        ' "$approval_abs" >/dev/null || exit 1
        wiki release resume --id "$release_id" --approval "$approval_abs" --json \
          > "$operator_evidence_dir/release-resume.json"
        ;;
      *) exit 1 ;;
    esac
    recovery_rc=$?
    ;;
  rollback)
    authorization_rel=${ROLLBACK_AUTHORIZATION_REL:?ROLLBACK_AUTHORIZATION_REL is required}
    authorization_leaf=${authorization_rel##*/}
    test "$authorization_rel" = "state/releases/approvals/$authorization_leaf" || exit 1
    case "$authorization_leaf" in "$release_id"-rollback-*.json) ;; *) exit 1 ;; esac
    authorization_abs=$(canonical_file_beneath "$wiki_root_abs" "$authorization_rel") || exit 1
    validate_contract_file rollback-authorization/1 SCHEMA-REL-07 "$authorization_abs" \
      "$operator_evidence_dir/rollback-authorization.validation.json" || exit 1
    jq -e --arg id "$release_id" '
      .schema=="rollback-authorization/1" and .release_id==$id and
      ([.approvals[].role]|sort)==["maintainer","recovery_controller"] and
      ([.approvals[].actor_id]|unique|length)==2
    ' "$authorization_abs" >/dev/null || exit 1
    jq -e '.legal_next_actions|index("rollback")!=null' "$operator_evidence_dir/release-inspect.json" >/dev/null || exit 1
    wiki release rollback --id "$release_id" --authorization "$authorization_abs" --json \
      > "$operator_evidence_dir/release-rollback.json"
    recovery_rc=$?
    ;;
  *) exit 1 ;;
esac
printf '%s\n' "$recovery_rc" > "$operator_evidence_dir/release-$recovery_action.exit"
validate_contract_file release-inspect-result/1 SCHEMA-REL-09 "$operator_evidence_dir/release-$recovery_action.json" \
  "$operator_evidence_dir/release-$recovery_action.validation.json" || exit 1
jq -e --arg id "$release_id" --arg operation "$recovery_action" --argjson rc "$recovery_rc" '
  .schema=="release-inspect-result/1" and .release_id==$id and .operation==$operation and .exit_code==$rc
' "$operator_evidence_dir/release-$recovery_action.json" >/dev/null || exit 1
test "$recovery_rc" -eq 0 || exit 1
```

Never reset, force-update a branch, edit a pointer by hand, delete a worktree/lock, or use unscoped staging. Review each revert candidate against decision #12, run every blocking gate and the verifier, then use the approved release path. A mixed state remains an incident until `wiki release inspect` proves a terminal journal/pointer binding. Preserve inspections, approvals, receipts, heads, and disposition.

## RB-ROLLBACK-03 — Torn acquisition recovery

Do not repair object/event/index/view files manually. Inspect under `PIPE-REC-01`; resume only when staged facts and the commit marker validate:

```bash
batch_id=${BATCH_ID:?BATCH_ID is required}
wiki acquisition inspect --batch "$batch_id" --json > "$operator_evidence_dir/acquisition-inspect.json"
acquisition_inspect_rc=$?; printf '%s\n' "$acquisition_inspect_rc" > "$operator_evidence_dir/acquisition-inspect.exit"
validate_contract_file acquisition-inspect-result/1 SCHEMA-CFG-17 "$operator_evidence_dir/acquisition-inspect.json" \
  "$operator_evidence_dir/acquisition-inspect.validation.json" || exit 1
jq -e --arg batch "$batch_id" --argjson rc "$acquisition_inspect_rc" '
  .schema=="acquisition-inspect-result/1" and .operation=="inspect" and
  .batch_id==$batch and .exit_code==$rc and
  ((.status=="complete" and .exit_code==0) or
   (.status=="incomplete" and .exit_code==1 and (.legal_next_actions|index("resume")!=null)))
' "$operator_evidence_dir/acquisition-inspect.json" >/dev/null || exit 1
if jq -e '.status=="incomplete"' "$operator_evidence_dir/acquisition-inspect.json" >/dev/null; then
  wiki acquisition resume --batch "$batch_id" --json > "$operator_evidence_dir/acquisition-resume.json"
  acquisition_resume_rc=$?; printf '%s\n' "$acquisition_resume_rc" > "$operator_evidence_dir/acquisition-resume.exit"
  validate_contract_file acquisition-inspect-result/1 SCHEMA-CFG-17 "$operator_evidence_dir/acquisition-resume.json" \
    "$operator_evidence_dir/acquisition-resume.validation.json" || exit 1
  jq -e --arg batch "$batch_id" --argjson rc "$acquisition_resume_rc" '
    .schema=="acquisition-inspect-result/1" and .operation=="resume" and
    .batch_id==$batch and .exit_code==$rc and .status=="complete"
  ' "$operator_evidence_dir/acquisition-resume.json" >/dev/null || exit 1
  test "$acquisition_resume_rc" -eq 0 || exit 1
fi
```

If `SCHEMA-CFG-17` reports an invalid `SCHEMA-SO-01`, `SCHEMA-SO-02`, `SCHEMA-SO-05`, `SCHEMA-SO-06`, `SCHEMA-SO-07`, `SCHEMA-SO-08`, or `SCHEMA-SO-09` binding, preserve staging, record a failed terminal disposition, and alert. Rebuild `SCHEMA-SO-04` only after `SCHEMA-SO-09` validates and the completed batch is authoritative.

## RB-INCIDENT-01 — Containment and evidence preservation

Triggers include bad merge, post-publication injection/secret/PII discovery, SLO or dead-man breach, git corruption, unauthorized purge, legal-hold violation, or unexplained release/source-state mismatch.

1. Require and validate the logical pipeline job ID, inspect it, obtain operator approval, then disable only that job. This is reversible and intentionally scoped.

   ```bash
   pipeline_job_id=${JOB_ID:?JOB_ID is required}
   test "$pipeline_job_id" = 'job.pipeline.nightly' || exit 1
   wiki deployment job inspect --job-id "$pipeline_job_id" --json \
     > "$operator_evidence_dir/pipeline-job-before.json"
   inspect_before_rc=$?; printf '%s\n' "$inspect_before_rc" > "$operator_evidence_dir/pipeline-job-before.exit"
   validate_contract_file deployment-job-inspect-result/1 SCHEMA-CFG-16 "$operator_evidence_dir/pipeline-job-before.json" \
     "$operator_evidence_dir/pipeline-job-before.validation.json" || exit 1
   jq -e --arg job "$pipeline_job_id" --argjson rc "$inspect_before_rc" '
     .schema=="deployment-job-inspect-result/1" and .operation=="inspect" and
     .job_id==$job and .exit_code==$rc
   ' "$operator_evidence_dir/pipeline-job-before.json" >/dev/null || exit 1
   test "$inspect_before_rc" -ne 3 || exit 1
   wiki deployment job disable --job-id "$pipeline_job_id" --json \
     > "$operator_evidence_dir/pipeline-job-disable.json"
   disable_rc=$?; printf '%s\n' "$disable_rc" > "$operator_evidence_dir/pipeline-job-disable.exit"
   validate_contract_file deployment-job-inspect-result/1 SCHEMA-CFG-16 "$operator_evidence_dir/pipeline-job-disable.json" \
     "$operator_evidence_dir/pipeline-job-disable.validation.json" || exit 1
   jq -e --arg job "$pipeline_job_id" --argjson rc "$disable_rc" '
     .schema=="deployment-job-inspect-result/1" and .operation=="disable" and
     .job_id==$job and .exit_code==$rc and .desired.enabled==false and .observed.enabled==false
   ' "$operator_evidence_dir/pipeline-job-disable.json" >/dev/null || exit 1
   test "$disable_rc" -eq 0 || exit 1
   ```

2. Do not kill a process until its run/release ID and children are known. Preserve terminal results, journals, manifests, events, candidates, alerts, and statuses; never copy credentials or unredacted hostile payloads.
3. Use `RB-ROLLBACK-01` and `RB-ROLLBACK-02` for release recovery, `RB-ROLLBACK-03` for acquisition recovery, `RB-AUTH-02` for auth, and `RB-RESTORE-00`, `RB-RESTORE-01`, `RB-RESTORE-02`, `RB-RESTORE-03`, or `RB-RESTORE-04` for preservation/backup loss. Restrict quarantined security material to the security owner.
4. Record scope, detection, timeline, affected repos/sources, impact, containment, evidence hashes, decisions, and the missing guard. Create a `postmortems/` stub on killswitch or rollback.
5. Keep autonomy paused until `RB-INCIDENT-02` passes. Read-only query may continue only with known-safe evidence and explicit source state.

## RB-INCIDENT-02 — Postmortem and autonomy-resume gate

The maintainer owns closure; security approves injection/secret/PII cases; legal/privacy approves purge/hold cases; the source owner approves entitlement/source-integrity cases.

Resume requires a recorded root cause; merged deterministic guard/fixture; revalidated evidence; completed recovery; acknowledged alerts; no mixed release or torn batch; clean repos; successful doctor/shadow run; and preserved approvals. Re-enable only the job disabled by `RB-INCIDENT-01`, then inspect it:

```bash
fail_closed_disable_pipeline_job() {
  wiki deployment job disable --job-id "$pipeline_job_id" --json \
    > "$operator_evidence_dir/pipeline-job-failclosed-disable.json"
  failclosed_disable_rc=$?
  printf '%s\n' "$failclosed_disable_rc" > "$operator_evidence_dir/pipeline-job-failclosed-disable.exit"
  validate_contract_file deployment-job-inspect-result/1 SCHEMA-CFG-16 \
    "$operator_evidence_dir/pipeline-job-failclosed-disable.json" \
    "$operator_evidence_dir/pipeline-job-failclosed-disable.validation.json" || return 1
  jq -e --arg job "$pipeline_job_id" --argjson rc "$failclosed_disable_rc" '
    .schema=="deployment-job-inspect-result/1" and .operation=="disable" and
    .job_id==$job and .exit_code==$rc and .exit_code==0 and
    .desired.enabled==false and .observed.enabled==false
  ' "$operator_evidence_dir/pipeline-job-failclosed-disable.json" >/dev/null
}
wiki deployment job enable --job-id "$pipeline_job_id" --json \
  > "$operator_evidence_dir/pipeline-job-enable.json"
enable_rc=$?; printf '%s\n' "$enable_rc" > "$operator_evidence_dir/pipeline-job-enable.exit"
if ! validate_contract_file deployment-job-inspect-result/1 SCHEMA-CFG-16 "$operator_evidence_dir/pipeline-job-enable.json" \
  "$operator_evidence_dir/pipeline-job-enable.validation.json" ||
  ! jq -e --arg job "$pipeline_job_id" --argjson rc "$enable_rc" '
  .schema=="deployment-job-inspect-result/1" and .operation=="enable" and
  .job_id==$job and .exit_code==$rc and .exit_code==0 and
  .desired.enabled==true and .observed.enabled==true
' "$operator_evidence_dir/pipeline-job-enable.json" >/dev/null; then
  if ! fail_closed_disable_pipeline_job; then exit 1; fi
  exit 1
fi
wiki deployment job inspect --job-id "$pipeline_job_id" --json \
  > "$operator_evidence_dir/pipeline-job-after.json"
inspect_after_rc=$?; printf '%s\n' "$inspect_after_rc" > "$operator_evidence_dir/pipeline-job-after.exit"
if ! validate_contract_file deployment-job-inspect-result/1 SCHEMA-CFG-16 "$operator_evidence_dir/pipeline-job-after.json" \
  "$operator_evidence_dir/pipeline-job-after.validation.json" ||
  ! jq -e --arg job "$pipeline_job_id" --argjson rc "$inspect_after_rc" '
  .schema=="deployment-job-inspect-result/1" and .operation=="inspect" and
  .job_id==$job and .exit_code==$rc and .exit_code==0 and
  .desired.enabled==true and .observed.enabled==true
' "$operator_evidence_dir/pipeline-job-after.json" >/dev/null; then
  if ! fail_closed_disable_pipeline_job; then exit 1; fi
  exit 1
fi
```

Do not resume merely because symptoms stopped or a retry passed. Any invalid enable or post-enable inspection immediately invokes the validated disable operation above; if that compensation cannot prove desired and observed disabled, use scheduler-level containment and `RB-ALERT-01` while autonomy remains an incident.

## RB-ALERT-01 — Delivery, fallback, acknowledgement, and retry

`PIPE-EXIT-04` emits the durable alert; `PIPE-G-07` exposes backup/dead-man failure. The `SCHEMA-CFG-04` sink is primary and the append-only local log is fallback; delivery failure cannot erase the alert or alter run disposition.

1. Correlate alert, run/release/batch, class, source/wiki, occurrences, deliveries, and terminal result. Inspect the fallback read-only:

   ```bash
   alert_id=${ALERT_ID:?ALERT_ID is required}
   wiki alert inspect --id "$alert_id" --json \
     > "$operator_evidence_dir/alert-inspect.json"
   alert_inspect_rc=$?; printf '%s\n' "$alert_inspect_rc" > "$operator_evidence_dir/alert-inspect.exit"
   validate_contract_file tool-result/1 SCHEMA-CFG-02 "$operator_evidence_dir/alert-inspect.json" \
     "$operator_evidence_dir/alert-inspect.validation.json" || exit 1
   jq -e --arg id "$alert_id" --argjson rc "$alert_inspect_rc" '
     .schema=="tool-result/1" and .tool=="alert_inspect" and .status=="ok" and
     .exit_code==0 and .exit_code==$rc and .data.operation=="inspect" and
     .data.alert_id==$id and (.data.state|IN("pending","delivered","acknowledged","retry_scheduled","failed"))
   ' "$operator_evidence_dir/alert-inspect.json" >/dev/null || exit 1
   test "$alert_inspect_rc" -eq 0 || exit 1
   if test -e "$wiki_root_abs/.kiro/pipeline/alerts.log"; then
     alert_log_abs=$(canonical_file_beneath "$wiki_root_abs" .kiro/pipeline/alerts.log) || exit 1
     rg -n -F -- "$alert_id" "$alert_log_abs" \
       > "$operator_evidence_dir/alerts-matching-id.txt"
     alert_log_match_rc=$?
     test "$alert_log_match_rc" -eq 0 || test "$alert_log_match_rc" -eq 1 || exit 1
     printf '%s\n' "$alert_log_match_rc" > "$operator_evidence_dir/alerts-matching-id.exit"
   else
     printf '%s\n' 'fallback-log-absent' > "$operator_evidence_dir/alerts-matching-id.txt"
   fi
   ```

2. Acknowledge only after accepting ownership. Prepare a redacted note as the regular mode-0600 file `$operator_evidence_dir/alert-note.txt`, then run the exact operation and validate its canonical result:

   ```bash
   alert_note_abs=$(canonical_file_beneath "$operator_evidence_dir" alert-note.txt) || exit 1
   test "$(stat -f '%Lp' "$alert_note_abs")" = '600' || exit 1
   wiki alert acknowledge --id "$alert_id" --note-file "$alert_note_abs" --json \
     > "$operator_evidence_dir/alert-acknowledge.json"
   alert_ack_rc=$?; printf '%s\n' "$alert_ack_rc" > "$operator_evidence_dir/alert-acknowledge.exit"
   validate_contract_file tool-result/1 SCHEMA-CFG-02 "$operator_evidence_dir/alert-acknowledge.json" \
     "$operator_evidence_dir/alert-acknowledge.validation.json" || exit 1
   jq -e --arg id "$alert_id" --argjson rc "$alert_ack_rc" '
     .schema=="tool-result/1" and .tool=="alert_acknowledge" and .status=="ok" and
     .exit_code==0 and .exit_code==$rc and .data.operation=="acknowledge" and
     .data.alert_id==$id and .data.state=="acknowledged" and
     (.data.acknowledged_by|type=="string") and (.data.acknowledged_at|type=="string")
   ' "$operator_evidence_dir/alert-acknowledge.json" >/dev/null || exit 1
   test "$alert_ack_rc" -eq 0 || exit 1
   ```

   Ack suppresses duplicate delivery, never the condition or a distinct occurrence.

3. Retry only when the inspect result has `data.retryable=true` and the failure names an applicable budget; source recurrence uses `TH-TGT-009` or `TH-TGT-010`. With no named budget, stop. Auth, hold, purge, corruption, injection, secret/PII, and approval failures require disposition.

   ```bash
   jq -e '.data.retryable==true' "$operator_evidence_dir/alert-inspect.json" >/dev/null || exit 1
   wiki alert retry --id "$alert_id" --json > "$operator_evidence_dir/alert-retry.json"
   alert_retry_rc=$?; printf '%s\n' "$alert_retry_rc" > "$operator_evidence_dir/alert-retry.exit"
   validate_contract_file tool-result/1 SCHEMA-CFG-02 "$operator_evidence_dir/alert-retry.json" \
     "$operator_evidence_dir/alert-retry.validation.json" || exit 1
   jq -e --arg id "$alert_id" --argjson rc "$alert_retry_rc" '
     .schema=="tool-result/1" and .tool=="alert_retry" and .status=="ok" and
     .exit_code==0 and .exit_code==$rc and .data.operation=="retry" and
     .data.alert_id==$id and .data.state=="retry_scheduled" and .data.attempt>0
   ' "$operator_evidence_dir/alert-retry.json" >/dev/null || exit 1
   test "$alert_retry_rc" -eq 0 || exit 1
   ```
4. Escalate source recurrence under `TH-TGT-009` and `TH-TGT-010` and missing job receipts under `SCHEMA-CFG-04.jobs[].receipt.max_age_policy_ref`. If both sinks fail, dead-man is the recovery path under `PIPE-EXIT-05`.

All three alert commands use the total `SCHEMA-CFG-02` exit mapping in `PIPE-EXIT-06`: `ok=0`, `partial=2`, a completed invalid/rejected operation is `error=1`, and inability to complete is `error=3`. Preserve a nonzero result and stop; never interpret fallback-log text as a successful acknowledgement or scheduled retry.

Every operator-supplied `run_id`, `release_id`, `batch_id`, and `alert_id` above is parsed by its typed command and then rechecked in the validated result or persisted artifact. `SCHEMA-CFG-00` is the sole lexical owner; this runbook intentionally carries no duplicate identifier regex.

**Evidence checklist:** alert; sink/fallback receipts; ack actor/time; retry classification; escalation; linked incident/proposal; resolution; terminal disposition. Redact excerpts, headers, credential URLs, unnecessary user IDs, and auth material under `SCHEMA-CP-01` content policy and `SCHEMA-CP-03`; preserve hashes and opaque IDs.

## RB-ALERT-02 — Escalation ownership

The maintainer owns pipeline/release/restore/cost/dead-man alerts; the source owner owns entitlement/removal/integrity; security owns injection/secret/PII/egress/credential; legal/privacy owns purge/hold. Cross-domain incidents require all named owners. No “noise” closure is valid without durable disposition and, for source recurrence, a guard or evidence-backed recalibration of `TH-TGT-009` and `TH-TGT-010`.
