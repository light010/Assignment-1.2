"use client";

import { motion } from "motion/react";
import { useEffect, useRef } from "react";
import { labBus } from "@/lab/bus";

const entrance = { type: "spring", stiffness: 260, damping: 20 } as const;

/**
 * The headline hears the scene. When the probe picks up the photoacoustic signal, a pressure
 * wave leaves it and passes through the letters, pushing them apart and together the way a
 * longitudinal wave moves a medium.
 */
export function SoundHeadline({
  lines,
  originRef,
  reducedMotion,
}: {
  lines: readonly string[];
  /** The element the wave's coordinates are relative to (the scene canvas). */
  originRef: React.RefObject<HTMLElement | null>;
  reducedMotion: boolean;
}) {
  const headingRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    if (reducedMotion) return;
    let raf = 0;
    const off = labBus.on("wave", (wave) => {
      const origin = originRef.current?.getBoundingClientRect();
      if (!origin) return;
      const els = Array.from(headingRef.current?.querySelectorAll<HTMLSpanElement>(".sound-letter") ?? []);
      const centers = els.map((el) => {
        const r = el.getBoundingClientRect();
        const dx = r.left + r.width / 2 - origin.left - wave.x;
        const dy = r.top + r.height / 2 - origin.top - wave.y;
        const d = Math.hypot(dx, dy) || 1;
        return { dx: dx / d, dy: dy / d, d };
      });
      const lambda = Math.max(26, (els[0]?.getBoundingClientRect().height ?? 60) * 0.42);
      cancelAnimationFrame(raf);
      const tick = () => {
        const t = (performance.now() - wave.startedAt) / 1000;
        const front = t * wave.speed;
        const env = Math.max(0, 1 - t / 2.8) ** 1.2;
        let busy = false;
        for (let i = 0; i < els.length; i++) {
          const c = centers[i];
          const ph = (c.d - front) / lambda;
          const nw = ph > -5 && ph < 5 ? -ph * Math.exp(-0.5 * ph * ph) : 0;
          const amp = nw * env * 9;
          const el = els[i];
          if (Math.abs(amp) > 0.02) {
            busy = true;
            el.style.transform = `translate3d(${(c.dx * amp).toFixed(2)}px, ${(c.dy * amp * 0.6).toFixed(2)}px, 0)`;
            el.style.setProperty("--p", Math.max(0, nw * env).toFixed(3));
          } else if (el.style.transform) {
            el.style.transform = "";
            el.style.setProperty("--p", "0");
          }
          if (front < c.d + lambda * 5) busy = true;
        }
        if (busy && t < 4) raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    });
    return () => {
      off();
      cancelAnimationFrame(raf);
    };
  }, [originRef, reducedMotion]);

  const text = lines.join(" ");

  return (
    <h1 ref={headingRef} className="font-display display-optical text-hero text-balance font-[380] text-bone">
      <span className="sr-only">{text}</span>
      <span aria-hidden className="block">
        {lines.map((line, li) => (
          <span key={line} className="-mb-[0.14em] block overflow-hidden pb-[0.14em] pt-[0.08em]">
            <motion.span
              className="block"
              initial={{ y: "108%" }}
              animate={{ y: "0%" }}
              transition={{ ...entrance, delay: 0.12 + li * 0.11 }}
            >
              {line.split(" ").map((word, wi, arr) => (
                <span key={wi} className="inline-block whitespace-nowrap">
                  {Array.from(word).map((ch, ci) => (
                    <span key={ci} className="sound-letter inline-block will-change-transform">
                      {ch}
                    </span>
                  ))}
                  {wi < arr.length - 1 ? <span className="inline-block">&nbsp;</span> : null}
                </span>
              ))}
            </motion.span>
          </span>
        ))}
      </span>
    </h1>
  );
}
