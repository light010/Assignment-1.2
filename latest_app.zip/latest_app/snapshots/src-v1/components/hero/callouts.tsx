"use client";

import { useEffect, useRef, useState } from "react";
import type { StageId } from "@/content/profile";
import { labBus, type Anchor } from "@/lab/bus";

interface Callout {
  anchor: string;
  text: string;
  stages: StageId[];
  /** Which side of the anchor the label sits on. */
  side: "left" | "right";
  dy?: number;
}

const CALLOUTS: Callout[] = [
  { anchor: "core", text: "Light-absorbing core", stages: ["build"], side: "left", dy: -6 },
  { anchor: "matrix", text: "Drug-loaded shell", stages: ["build"], side: "right" },
  { anchor: "coat", text: "Cell-membrane coat", stages: ["build"], side: "left" },
  { anchor: "vessel", text: "Blood vessel", stages: ["deliver"], side: "right", dy: -4 },
  { anchor: "tumor", text: "Tumor", stages: ["deliver", "image"], side: "left" },
  { anchor: "light", text: "Light goes in", stages: ["image"], side: "right" },
  { anchor: "probe", text: "Sound comes back", stages: ["image"], side: "left" },
];

/**
 * Labels pinned to points in the 3D scene, plus the magnifier's leader lines.
 * Positions are written straight to the DOM every frame; React only handles which labels show.
 */
export function Callouts({ compact }: { compact: boolean }) {
  const [stage, setStage] = useState<StageId>("image");
  const [placed, setPlaced] = useState(false);
  const nodes = useRef<Record<string, HTMLDivElement | null>>({});
  const lineA = useRef<SVGLineElement>(null);
  const lineB = useRef<SVGLineElement>(null);
  const ring = useRef<SVGCircleElement>(null);

  useEffect(() => {
    let placedOnce = false;
    const offs = [
      labBus.on("stage", ({ stage }) => setStage(stage)),
      labBus.on("anchors", (a: Record<string, Anchor>) => {
        if (!placedOnce) {
          placedOnce = true;
          setPlaced(true);
        }
        for (const c of CALLOUTS) {
          const el = nodes.current[c.anchor];
          const p = a[c.anchor];
          if (!el || !p) continue;
          el.style.transform = `translate3d(${p.x.toFixed(1)}px, ${(p.y + (c.dy ?? 0)).toFixed(1)}px, 0)`;
        }
        const center = a.loupe;
        const edge = a.loupeEdge;
        const target = a.zoom;
        if (center && edge && target && lineA.current && lineB.current && ring.current) {
          const R = Math.hypot(edge.x - center.x, edge.y - center.y);
          const dx = target.x - center.x;
          const dy = target.y - center.y;
          const d = Math.hypot(dx, dy);
          if (d > R + 4) {
            // Tangent points from the target to the loupe circle
            const base = Math.atan2(dy, dx);
            const spread = Math.acos(Math.min(1, R / d));
            const t1 = base + spread;
            const t2 = base - spread;
            lineA.current.setAttribute("x1", (center.x + Math.cos(t1) * R).toFixed(1));
            lineA.current.setAttribute("y1", (center.y + Math.sin(t1) * R).toFixed(1));
            lineB.current.setAttribute("x1", (center.x + Math.cos(t2) * R).toFixed(1));
            lineB.current.setAttribute("y1", (center.y + Math.sin(t2) * R).toFixed(1));
            for (const l of [lineA.current, lineB.current]) {
              l.setAttribute("x2", target.x.toFixed(1));
              l.setAttribute("y2", target.y.toFixed(1));
            }
            ring.current.setAttribute("cx", target.x.toFixed(1));
            ring.current.setAttribute("cy", target.y.toFixed(1));
          }
        }
      }),
    ];
    return () => offs.forEach((off) => off());
  }, []);

  return (
    <div
      aria-hidden
      data-placed={placed}
      className="pointer-events-none absolute inset-0 overflow-hidden transition-opacity duration-700 data-[placed=false]:opacity-0"
    >
      <svg className="absolute inset-0 h-full w-full overflow-visible">
        <g className="text-bone" stroke="currentColor" fill="none">
          <line ref={lineA} strokeOpacity={0.28} strokeWidth={1} strokeDasharray="2 5" />
          <line ref={lineB} strokeOpacity={0.28} strokeWidth={1} strokeDasharray="2 5" />
          <circle ref={ring} r={7} strokeOpacity={0.6} strokeWidth={1} />
        </g>
      </svg>
      {CALLOUTS.map((c) => {
        const on = c.stages.includes(stage) && !(compact && c.anchor === "matrix");
        return (
          <div
            key={c.anchor}
            ref={(el) => {
              nodes.current[c.anchor] = el;
            }}
            className="absolute left-0 top-0 will-change-transform"
          >
            <div
              data-on={on}
              className={`absolute top-0 flex -translate-y-1/2 items-center gap-2 transition-[opacity,filter] duration-500 ease-[var(--ease-out-quint)] data-[on=false]:opacity-0 data-[on=false]:blur-[3px] ${
                c.side === "right" ? "left-0 flex-row" : "right-0 flex-row-reverse"
              }`}
            >
              <span className="relative -mx-[3.5px] size-[7px] shrink-0 rounded-full border border-bone/80 bg-void/60" />
              <span className="h-px w-5 bg-bone/40" />
              <span className="font-instrument whitespace-nowrap rounded-full border border-hairline bg-void/55 px-2.5 py-1 text-[0.75rem] font-medium text-bone backdrop-blur-md">
                {c.text}
              </span>
            </div>
          </div>
        );
      })}
    </div>
  );
}
