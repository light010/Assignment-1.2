"use client";

import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import type { Framing, LabEngine } from "@/lab/engine";
import { labBus } from "@/lab/bus";
import { REDUCED_MOTION_QUERY } from "@/lib/use-media";

interface LabCanvasProps {
  /** Clicking the scene itself fires a light pulse. */
  onPulse?: () => void;
  framing: Framing;
  onEngine: (engine: LabEngine | null) => void;
  /** Element whose pointer movement steers the camera and the cursor light. */
  pointerRoot: React.RefObject<HTMLElement | null>;
  className?: string;
}

function isLowPower() {
  const nav = navigator as Navigator & { deviceMemory?: number };
  const coarse = window.matchMedia("(pointer: coarse)").matches;
  const small = Math.min(window.innerWidth, window.innerHeight) < 600;
  return (nav.hardwareConcurrency ?? 8) <= 4 || (nav.deviceMemory ?? 8) <= 4 || (coarse && small);
}

let webgl2: boolean | undefined;
function supportsWebGL2() {
  if (webgl2 === undefined) {
    try {
      webgl2 = !!document.createElement("canvas").getContext("webgl2");
    } catch {
      webgl2 = false;
    }
  }
  return webgl2;
}
const noSubscribe = () => () => {};

export function LabCanvas({ framing, onEngine, pointerRoot, className, onPulse }: LabCanvasProps) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<LabEngine | null>(null);
  const framingRef = useRef(framing);
  const [status, setStatus] = useState<"loading" | "ready" | "fallback">("loading");
  const webgl = useSyncExternalStore(noSubscribe, supportsWebGL2, () => true);

  useEffect(() => {
    const wrap = wrapRef.current;
    const canvas = canvasRef.current;
    if (!wrap || !canvas || !supportsWebGL2()) return;

    let cancelled = false;
    let cleanup = () => {};

    import("@/lab/engine")
      .then(({ LabEngine }) => {
        if (cancelled) return;
        const lowPower = isLowPower();
        // Read directly (not via props) so hydration never rebuilds the engine.
        const reducedMotion = window.matchMedia(REDUCED_MOTION_QUERY).matches;
        const engine = new LabEngine(canvas, { reducedMotion, lowPower });
        engineRef.current = engine;
        // Full-bleed WebGL at 2x costs ~2x the fill for little visible gain under bloom and grain.
        const dprCap = lowPower ? 1.25 : 1.5;

        const measure = () => {
          const r = wrap.getBoundingClientRect();
          engine.setSize(r.width, r.height, Math.min(window.devicePixelRatio || 1, dprCap));
        };
        engine.setFraming(framingRef.current);
        measure();

        const ro = new ResizeObserver(measure);
        ro.observe(wrap);

        let inView = true;
        const syncActive = () => engine.setActive(inView && document.visibilityState === "visible");
        const io = new IntersectionObserver(
          ([entry]) => {
            inView = entry.isIntersecting;
            syncActive();
          },
          { rootMargin: "80px" },
        );
        io.observe(wrap);
        document.addEventListener("visibilitychange", syncActive);

        const root = pointerRoot.current ?? wrap;
        const onMove = (e: PointerEvent) => {
          if (e.pointerType === "touch") return;
          const r = wrap.getBoundingClientRect();
          engine.setPointer(((e.clientX - r.left) / r.width) * 2 - 1, -(((e.clientY - r.top) / r.height) * 2 - 1));
        };
        const onLeave = () => engine.setPointer(0, 0);
        root.addEventListener("pointermove", onMove, { passive: true });
        root.addEventListener("pointerleave", onLeave);

        // Reveal once two frames have landed, so the fade never shows an empty buffer.
        let shown = false;
        let frames = 0;
        const offFrame = labBus.on("frame", () => {
          if (shown || ++frames < 3) return;
          shown = true;
          setStatus("ready");
          labBus.emit("ready", { at: performance.now() });
        });

        onEngine(engine);
        if (process.env.NODE_ENV !== "production") (window as Window & { __lab?: LabEngine }).__lab = engine;
        cleanup = () => {
          offFrame();
          ro.disconnect();
          io.disconnect();
          document.removeEventListener("visibilitychange", syncActive);
          root.removeEventListener("pointermove", onMove);
          root.removeEventListener("pointerleave", onLeave);
          onEngine(null);
          engine.dispose();
          engineRef.current = null;
        };
      })
      .catch(() => {
        if (!cancelled) setStatus("fallback");
      });

    return () => {
      cancelled = true;
      cleanup();
    };
    // The engine is created once; framing updates flow through the effect below.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    framingRef.current = framing;
    engineRef.current?.setFraming(framing);
  }, [framing]);

  return (
    <div
      ref={wrapRef}
      className={`${className ?? ""} ${webgl ? "cursor-crosshair" : ""}`}
      data-status={webgl ? status : "fallback"}
      onClick={webgl ? onPulse : undefined}
    >
      <div
        aria-hidden
        className="absolute inset-0 bg-[radial-gradient(60%_55%_at_62%_48%,rgb(18_44_52/0.55),transparent_70%)]"
      />
      <canvas
        ref={canvasRef}
        aria-hidden
        className="absolute inset-0 block h-full w-full transition-opacity duration-[1400ms] ease-[var(--ease-out-quint)] data-[on=false]:opacity-0"
        data-on={status === "ready"}
      />
    </div>
  );
}
