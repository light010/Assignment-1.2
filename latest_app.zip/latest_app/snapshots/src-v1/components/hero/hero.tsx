"use client";

import { MotionConfig, motion, useMotionValueEvent, useScroll, useTransform } from "motion/react";
import { useEffect, useMemo, useRef, useState } from "react";
import { profile } from "@/content/profile";
import type { Framing, LabEngine } from "@/lab/engine";
import { useMedia, usePrefersReducedMotion } from "@/lib/use-media";
import { Callouts } from "./callouts";
import { LabCanvas } from "./lab-canvas";
import { ScanPanel } from "./scan-panel";
import { SoundHeadline } from "./sound-headline";
import { StageRail } from "./stage-rail";

const WIDE_QUERY = "(min-width: 60rem) and (min-aspect-ratio: 21/20)";

const NARROW_FRAMING: Framing = { focusX: 0.5, focusY: 0.53, usableW: 1.02, usableH: 0.98 };

const rise = { type: "spring", stiffness: 260, damping: 20 } as const;

/*
  Layout: on narrow screens the section is a single column (name, headline, scene window,
  controls, scan). From 60rem the scene goes full-bleed behind the copy and the scan
  panel docks bottom-right; `display: contents` lets the same DOM serve both orders.
*/
export function Hero() {
  const sectionRef = useRef<HTMLElement>(null);
  const sceneRef = useRef<HTMLDivElement>(null);
  const reducedMotion = usePrefersReducedMotion();
  const wide = useMedia(WIDE_QUERY);
  const [engine, setEngine] = useState<LabEngine | null>(null);
  const copyRef = useRef<HTMLDivElement>(null);
  const [region, setRegion] = useState({ left: 0.44, right: 1, short: false });

  // Frame the scene in whatever width the copy column leaves free.
  useEffect(() => {
    const copy = copyRef.current;
    const section = sectionRef.current;
    if (!wide || !copy || !section) return;
    const ro = new ResizeObserver(() => {
      const s = section.getBoundingClientRect();
      const c = copy.getBoundingClientRect();
      // Keep the subject inside the content grid (90rem) so it lines up with the nav on ultrawide screens.
      const gridRight = Math.min(s.width, (s.width + 1440) / 2);
      setRegion({
        left: Math.min(0.5, Math.max(0.2, (c.right - s.left + 24) / s.width)),
        right: Math.min(1, (gridRight + 0.1 * s.width) / s.width),
        short: window.innerHeight < 820,
      });
    });
    ro.observe(copy);
    ro.observe(section);
    return () => ro.disconnect();
  }, [wide]);

  const framing = useMemo<Framing>(
    () =>
      wide
        ? {
            focusX: region.left + (region.right - region.left) * 0.47,
            focusY: region.short ? 0.38 : 0.44,
            usableW: (region.right - region.left) * 0.97,
            usableH: region.short ? 0.7 : 0.8,
          }
        : NARROW_FRAMING,
    [wide, region],
  );

  const { scrollYProgress } = useScroll({ target: sectionRef, offset: ["start start", "end start"] });
  const textY = useTransform(scrollYProgress, [0, 1], ["0%", "-28%"]);
  const textOpacity = useTransform(scrollYProgress, [0, 0.55], [1, 0]);
  const sceneY = useTransform(scrollYProgress, [0, 1], ["0%", "22%"]);
  const sceneScale = useTransform(scrollYProgress, [0, 1], [1, 1.06]);
  const parallax = wide && !reducedMotion;

  useMotionValueEvent(scrollYProgress, "change", (v) => engine?.setScroll(v));
  useEffect(() => {
    engine?.setScroll(scrollYProgress.get());
  }, [engine, scrollYProgress]);

  // MotionConfig below drops the transform part of these for reduced-motion users.
  const enter = (delay: number, y = 14) => ({
    initial: { opacity: 0, y },
    animate: { opacity: 1, y: 0 },
    transition: { ...rise, delay },
  });

  return (
    <MotionConfig reducedMotion="user">
    <section
      ref={sectionRef}
      id="top"
      aria-label="Introduction"
      className="@container/hero relative isolate flex flex-col overflow-hidden bg-void wide:block wide:min-h-[max(100svh,44rem)]"
    >
      <header className="relative z-20 order-0 mx-auto flex w-full max-w-[90rem] items-center justify-between px-4 py-3 @min-[40rem]/hero:px-6 wide:px-10 wide:py-6">
        <motion.a
          href="#top"
          {...enter(0.05, -6)}
          className="font-display inline-flex min-h-11 items-center rounded-full text-[1.1875rem] italic text-bone outline-none focus-visible:ring-2 focus-visible:ring-echo"
        >
          {profile.name}
        </motion.a>
        <motion.nav aria-label="Primary" {...enter(0.12, -6)}>
          <ul className="flex items-center gap-0.5">
            {profile.nav.map((item) => (
              <li key={item.href} className={item.href === "#contact" ? "" : "hidden @min-[40rem]/hero:block"}>
                <a
                  href={item.href}
                  className="inline-flex min-h-11 items-center rounded-full px-3.5 text-[0.9375rem] text-bone-muted outline-none transition-colors duration-200 hover:bg-white/[0.06] hover:text-bone focus-visible:ring-2 focus-visible:ring-echo"
                >
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
        </motion.nav>
      </header>

      <motion.div
        ref={sceneRef}
        style={parallax ? { y: sceneY, scale: sceneScale } : undefined}
        className="relative z-0 order-2 mx-4 aspect-square overflow-hidden rounded-[22px] border border-hairline @min-[40rem]/hero:mx-6 @min-[40rem]/hero:aspect-[4/3] wide:absolute wide:inset-0 wide:m-0 wide:aspect-auto wide:rounded-none wide:border-0"
      >
        <LabCanvas
          onPulse={() => engine?.pulse()}
          framing={framing}
          onEngine={setEngine}
          pointerRoot={sectionRef}
          className="absolute inset-0"
        />
        <Callouts compact={!wide} />
      </motion.div>

      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 z-[1] hidden bg-[linear-gradient(90deg,var(--color-void)_0%,rgb(6_10_12/0.9)_30%,rgb(6_10_12/0.45)_48%,transparent_64%)] wide:block"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 z-[1] hidden h-40 bg-gradient-to-b from-void/85 to-transparent wide:block"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 bottom-0 z-[1] hidden h-[34%] bg-gradient-to-t from-void via-void/55 to-transparent wide:block"
      />

      <div className="contents wide:pointer-events-none wide:relative wide:z-10 wide:mx-auto wide:flex wide:min-h-[calc(max(100svh,44rem)-6.5rem)] wide:max-w-[90rem] wide:items-center wide:px-10 wide:pb-16">
        <motion.div
          ref={copyRef}
          style={parallax ? { y: textY, opacity: textOpacity } : undefined}
          className="contents wide:flex wide:max-w-[38rem] wide:flex-col"
        >
          <div className="pointer-events-auto relative z-10 order-1 px-4 pb-8 pt-8 @min-[40rem]/hero:px-6 wide:p-0">
            <SoundHeadline lines={profile.headline} originRef={sceneRef} reducedMotion={reducedMotion} />
            <motion.p {...enter(0.42)} className="mt-6 max-w-[42ch] text-pretty text-lede text-bone-muted wide:mt-7">
              {profile.lede}
            </motion.p>
          </div>
          <motion.div
            {...enter(0.6)}
            className="pointer-events-auto relative z-10 order-3 px-4 pt-6 @min-[40rem]/hero:px-6 wide:p-0 wide:pt-12"
          >
            <StageRail engine={engine} reducedMotion={reducedMotion} />
          </motion.div>
        </motion.div>
      </div>

      <motion.div
        {...enter(0.9, 18)}
        className="relative z-10 order-4 mx-4 mb-12 mt-8 max-w-[22rem] @min-[40rem]/hero:mx-6 wide:absolute wide:bottom-8 wide:right-[max(2.5rem,calc((100%-90rem)/2+2.5rem))] wide:m-0 wide:w-[clamp(13.5rem,26vh,18.5rem)]"
      >
        <ScanPanel />
      </motion.div>
    </section>
    </MotionConfig>
  );
}
