"use client";

import { useEffect, useRef } from "react";
import { labBus } from "@/lab/bus";
import { buildScanLayers } from "@/lab/scan-image";

const W = 400;
const H = 370;
const SWEEP = 1.3;

function toCanvas(img: ImageData) {
  const c = document.createElement("canvas");
  c.width = img.width;
  c.height = img.height;
  c.getContext("2d")!.putImageData(img, 0, 0);
  return c;
}

/**
 * The instrument's view: a live ultrasound B-mode with the photoacoustic map laid over it.
 * It refreshes when the probe fires, and the particle signal tracks how much drug reached the tumor.
 */
export function ScanPanel({ className }: { className?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const meterRef = useRef<HTMLSpanElement>(null);
  const liveRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let layers: { bmode: HTMLCanvasElement[]; tissue: HTMLCanvasElement; particles: HTMLCanvasElement } | null = null;
    let frameIndex = 0;
    let sweepStart = -1e9;
    let paStart = -1e9;
    let paFloor = 0;
    let paFadeFrom = -1e9;
    let accum = 1;
    let raf = 0;
    let dirty = true;

    const draw = (now: number) => {
      raf = 0;
      if (!layers) return;
      const sweepT = (now - sweepStart) / 1000;
      const sweeping = sweepT >= 0 && sweepT < SWEEP;
      const cur = layers.bmode[frameIndex];
      const prev = layers.bmode[(frameIndex + layers.bmode.length - 1) % layers.bmode.length];

      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = "source-over";
      if (sweeping) {
        const sx = Math.round((sweepT / SWEEP) * W);
        ctx.drawImage(prev, 0, 0);
        ctx.drawImage(cur, 0, 0, sx, H, 0, 0, sx, H);
      } else {
        ctx.drawImage(cur, 0, 0);
      }

      const paT = (now - paStart) / 1000;
      let pa = paT >= 0 ? Math.min(1, paT / 0.14) * (1 + 0.55 * Math.exp(-paT * 3)) : 0;
      const fadeT = (now - paFadeFrom) / 1000;
      if (fadeT >= 0 && fadeT < 1.2 && paFadeFrom > paStart) pa *= 1 - fadeT / 1.2;
      else if (paFadeFrom > paStart) pa = 0;
      pa = Math.max(pa, paFloor);

      if (pa > 0.002) {
        ctx.globalCompositeOperation = "lighter";
        ctx.globalAlpha = Math.min(1, pa) * 0.85;
        ctx.drawImage(layers.tissue, 0, 0);
        ctx.globalAlpha = Math.min(1, pa * (0.15 + 0.85 * accum));
        ctx.drawImage(layers.particles, 0, 0);
        ctx.globalCompositeOperation = "source-over";
        ctx.globalAlpha = 1;
      }

      if (sweeping) {
        const sx = (sweepT / SWEEP) * W;
        const grad = ctx.createLinearGradient(sx - 26, 0, sx + 2, 0);
        grad.addColorStop(0, "rgba(143,225,240,0)");
        grad.addColorStop(1, "rgba(143,225,240,0.55)");
        ctx.fillStyle = grad;
        ctx.fillRect(sx - 26, 0, 28, H);
      }

      // Depth ticks along the right edge
      ctx.fillStyle = "rgba(236,231,223,0.45)";
      for (let k = 1; k < 12; k++) {
        const y = (k / 12) * H;
        ctx.fillRect(W - (k % 3 === 0 ? 14 : 8), y, k % 3 === 0 ? 14 : 8, 1.5);
      }

      // Tumor-ROI photoacoustic signal, arbitrary units: what the instrument would actually report.
      if (meterRef.current) {
        const level = Math.min(1, pa) * (0.12 + 0.88 * accum);
        meterRef.current.style.transform = `scaleX(${level.toFixed(3)})`;
      }

      const animating = sweeping || (paT >= 0 && paT < 2) || (fadeT >= 0 && fadeT < 1.3);
      if (liveRef.current) liveRef.current.dataset.live = String(sweeping || (paT >= 0 && paT < 1.2));
      if (animating || dirty) {
        dirty = false;
        if (animating) raf = requestAnimationFrame(draw);
      }
    };

    const schedule = () => {
      dirty = true;
      if (!raf) raf = requestAnimationFrame(draw);
    };

    const build = () => {
      const l = buildScanLayers(W, H, 2);
      layers = { bmode: l.bmode.map(toCanvas), tissue: toCanvas(l.tissuePA), particles: toCanvas(l.particlePA) };
      schedule();
    };
    const ric = (window as Window & { requestIdleCallback?: (cb: () => void) => number }).requestIdleCallback;
    if (ric) ric(build);
    else setTimeout(build, 60);

    const offs = [
      labBus.on("ultrasound", ({ startedAt }) => {
        frameIndex = (frameIndex + 1) % 2;
        sweepStart = startedAt;
        schedule();
      }),
      labBus.on("wave", ({ startedAt }) => {
        paStart = startedAt;
        paFloor = 0;
        schedule();
      }),
      labBus.on("stage", ({ stage }) => {
        if (stage === "build") {
          paFadeFrom = performance.now();
          schedule();
        }
      }),
      labBus.on("frame", (f) => {
        if (Math.abs(f.accumulation - accum) > 0.01) {
          accum = f.accumulation;
          schedule();
        }
      }),
    ];

    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)");
    if (reduce.matches) {
      paFloor = 1;
      schedule();
    }

    return () => {
      offs.forEach((off) => off());
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <figure
      className={`@container/scan rounded-[18px] border border-hairline bg-glass p-2.5 shadow-[0_24px_60px_-20px_rgb(0_0_0/0.8)] backdrop-blur-xl ${className ?? ""}`}
    >
      <figcaption className="flex items-center justify-between gap-3 px-1.5 pb-2 pt-0.5">
        <span className="flex items-center gap-2 whitespace-nowrap text-[0.8125rem] font-medium text-bone">
          <span
            ref={liveRef}
            aria-hidden
            className="size-1.5 rounded-full bg-echo/50 transition-[background-color,box-shadow] duration-300 data-[live=true]:bg-echo data-[live=true]:shadow-[0_0_10px_2px_rgb(143_225_240/0.7)]"
          />
          Live scan
        </span>
        <span className="font-instrument flex items-center gap-2 whitespace-nowrap text-micro text-bone-muted">
          <span className="hidden @min-[17rem]/scan:inline">Tumor signal</span>
          <span className="@min-[17rem]/scan:hidden">Signal</span>
          <span aria-hidden className="relative h-1.5 w-10 overflow-hidden rounded-full bg-white/[0.08] @min-[17rem]/scan:w-12">
            <span
              ref={meterRef}
              style={{ transform: "scaleX(0)" }}
              className="absolute inset-0 origin-left rounded-full bg-gradient-to-r from-[#8a1a06] via-pulse to-[#fff3c4]"
            />
          </span>
        </span>
      </figcaption>
      <div className="relative overflow-hidden rounded-[11px] bg-black">
        <canvas
          ref={canvasRef}
          width={W}
          height={H}
          role="img"
          aria-label="Simulated ultrasound image of the tissue with a photoacoustic overlay showing where the particles collected in the tumor."
          className="block aspect-[400/370] w-full"
        />
        <div aria-hidden className="pointer-events-none absolute inset-0 rounded-[11px] shadow-[inset_0_0_0_1px_rgb(255_255_255/0.06),inset_0_0_40px_rgb(0_0_0/0.55)]" />
      </div>
      <div className="font-instrument flex flex-wrap items-center gap-x-3.5 gap-y-1 px-1.5 pb-0.5 pt-2 text-micro text-bone-muted">
        <span className="flex items-center gap-1.5">
          <span aria-hidden className="h-1.5 w-3 rounded-full bg-gradient-to-r from-[#3a3834] to-bone" />
          Ultrasound
        </span>
        <span className="flex items-center gap-1.5">
          <span aria-hidden className="h-1.5 w-3 rounded-full bg-gradient-to-r from-[#8a1a06] via-pulse to-[#fff3c4]" />
          Photoacoustic
        </span>
      </div>
    </figure>
  );
}
