"use client";

import { AnimatePresence, motion } from "motion/react";
import { Pause, Play, Zap } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { stages, type StageId } from "@/content/profile";
import { labBus } from "@/lab/bus";
import type { LabEngine } from "@/lab/engine";

const press = { type: "spring", stiffness: 420, damping: 26 } as const;

/**
 * The three skills double as the scene's controls: each tab jumps the story to that step,
 * and the thin bar under the active tab shows how far the step has played.
 */
export function StageRail({ engine, reducedMotion }: { engine: LabEngine | null; reducedMotion: boolean }) {
  const [stage, setStage] = useState<StageId>("image");
  const [playingEvent, setPlaying] = useState<boolean | null>(null);
  const playing = playingEvent ?? (engine ? engine.isPlaying() : true);
  const bars = useRef<Partial<Record<StageId, HTMLSpanElement | null>>>({});
  const tabs = useRef<Partial<Record<StageId, HTMLButtonElement | null>>>({});
  const resumeOnBlur = useRef(false);

  useEffect(() => {
    const offs = [
      labBus.on("stage", ({ stage }) => setStage(stage)),
      labBus.on("playing", ({ playing }) => setPlaying(playing)),
      labBus.on("frame", (f) => {
        for (const s of stages) {
          const bar = bars.current[s.id];
          if (!bar) continue;
          const v = s.id === f.stage ? Math.min(1, Math.max(0, f.stageProgress)) : 0;
          bar.style.transform = `scaleX(${v.toFixed(4)})`;
        }
      }),
    ];
    return () => offs.forEach((off) => off());
  }, []);

  const current = stages.find((s) => s.id === stage) ?? stages[0];

  const select = (id: StageId) => {
    engine?.goTo(id);
    setStage(id);
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    const i = stages.findIndex((s) => s.id === stage);
    let next = -1;
    if (e.key === "ArrowRight") next = (i + 1) % stages.length;
    if (e.key === "ArrowLeft") next = (i - 1 + stages.length) % stages.length;
    if (e.key === "Home") next = 0;
    if (e.key === "End") next = stages.length - 1;
    if (next < 0) return;
    e.preventDefault();
    const id = stages[next].id;
    select(id);
    tabs.current[id]?.focus();
  };

  // Keyboard users get a still scene while they read; pointer users keep the story moving.
  const onFocus = (e: React.FocusEvent) => {
    if (!engine || !(e.target as HTMLElement).matches(":focus-visible")) return;
    if (engine.isPlaying()) {
      resumeOnBlur.current = true;
      engine.setPlaying(false);
    }
  };
  const onBlur = (e: React.FocusEvent) => {
    if (e.currentTarget.contains(e.relatedTarget as Node)) return;
    if (resumeOnBlur.current && engine) engine.setPlaying(true);
    resumeOnBlur.current = false;
  };

  return (
    <div className="w-full max-w-[34rem]">
      <div
        role="tablist"
        aria-label="What I do, step by step"
        className="grid grid-cols-3 gap-1.5 rounded-[18px] border border-hairline bg-glass p-1.5 backdrop-blur-xl"
        onKeyDown={onKeyDown}
        onFocus={onFocus}
        onBlur={onBlur}
      >
        {stages.map((s) => {
          const selected = s.id === stage;
          return (
            <motion.button
              key={s.id}
              ref={(el) => {
                tabs.current[s.id] = el;
              }}
              role="tab"
              id={`stage-tab-${s.id}`}
              aria-selected={selected}
              aria-controls="stage-panel"
              tabIndex={selected ? 0 : -1}
              onClick={() => select(s.id)}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              transition={press}
              className="group relative flex min-h-14 flex-col items-start justify-center gap-0.5 overflow-hidden rounded-[13px] px-3.5 py-2.5 text-left outline-none transition-colors duration-300 focus-visible:ring-2 focus-visible:ring-echo focus-visible:ring-offset-2 focus-visible:ring-offset-void aria-selected:bg-white/[0.07]"
            >
              <span className="text-[0.9375rem] font-medium leading-tight text-bone-muted transition-colors group-aria-selected:text-bone">
                {s.label}
              </span>
              <span className="font-instrument text-micro text-bone-muted/90 transition-colors group-aria-selected:text-bone-muted">
                {s.skill}
              </span>
              <span aria-hidden className="absolute inset-x-3.5 bottom-1.5 h-px overflow-hidden rounded-full bg-white/[0.06]">
                <span
                  ref={(el) => {
                    bars.current[s.id] = el;
                  }}
                  style={{ transform: "scaleX(0)" }}
                  className="block h-full origin-left bg-echo/80"
                />
              </span>
            </motion.button>
          );
        })}
      </div>

      <div
        role="tabpanel"
        id="stage-panel"
        aria-labelledby={`stage-tab-${current.id}`}
        className="mt-4 min-h-[4.9em] px-1 text-caption text-bone-muted"
      >
        <AnimatePresence mode="wait" initial={false}>
          <motion.p
            key={current.id}
            initial={{ opacity: 0, y: 6, filter: reducedMotion ? "blur(0px)" : "blur(4px)" }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            exit={reducedMotion ? { opacity: 0 } : { opacity: 0, y: -4, filter: "blur(4px)" }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
            className="max-w-[52ch] text-pretty"
          >
            {current.caption}
          </motion.p>
        </AnimatePresence>
      </div>

      <div className="mt-3 flex items-center gap-2 px-0.5">
        <motion.button
          type="button"
          onClick={() => engine?.pulse()}
          disabled={!engine}
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
          transition={press}
          className="group relative inline-flex min-h-11 items-center gap-2 overflow-hidden rounded-full bg-bone px-5 text-[0.9375rem] font-medium text-void shadow-[0_0_0_1px_rgb(255_255_255/0.2),0_10px_30px_-10px_rgb(255_173_98/0.6)] outline-none focus-visible:ring-2 focus-visible:ring-echo focus-visible:ring-offset-2 focus-visible:ring-offset-void disabled:opacity-60"
        >
          <span
            aria-hidden
            className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-pulse/35 to-transparent transition-transform duration-700 ease-[var(--ease-out-quint)] group-hover:translate-x-full"
          />
          <Zap aria-hidden className="relative size-4 fill-pulse stroke-[#7a3d0a]" strokeWidth={1.5} />
          <span className="relative">Send a light pulse</span>
        </motion.button>
        <motion.button
          type="button"
          onClick={() => engine?.setPlaying(!playing)}
          disabled={!engine}
          aria-label={playing ? "Pause animation" : "Play animation"}
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
          transition={press}
          className="inline-flex size-11 items-center justify-center rounded-full border border-hairline bg-glass text-bone-muted backdrop-blur-xl outline-none transition-colors hover:text-bone focus-visible:ring-2 focus-visible:ring-echo focus-visible:ring-offset-2 focus-visible:ring-offset-void disabled:opacity-60"
        >
          {playing ? <Pause aria-hidden className="size-4" /> : <Play aria-hidden className="size-4" />}
        </motion.button>
      </div>
    </div>
  );
}
