import * as THREE from "three";
import { COLORS } from "../constants";
import { noiseGLSL } from "../glsl";

/*
  One nanoparticle, magnified and cut open (an octant removed, facing the viewer).
  Layers, inside out: light-absorbing crystal core, drug-loaded polymer matrix,
  lipid bilayer coat with surface proteins. A loupe ring frames it.
*/

const R_CORE = 0.3;
const R_GEL = 0.86;
const R_TAIL = 0.95;
const R_HEAD = 0.985;

const easeOut = (t: number) => 1 - Math.pow(1 - t, 3);
const easeInOut = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
const clamp01 = (t: number) => Math.min(1, Math.max(0, t));
const smooth = (a: number, b: number, t: number) => easeInOut(clamp01((t - a) / (b - a)));

export interface Assembly {
  core: number;
  gel: number;
  load: number;
  coat: number;
}

export function createNanoparticle({ lowPower }: { lowPower: boolean }) {
  const root = new THREE.Group();
  root.name = "nanoparticle";
  const spin = new THREE.Group();
  const body = new THREE.Group();
  root.add(spin);
  spin.add(body);
  body.quaternion.setFromUnitVectors(
    new THREE.Vector3(1, 1, 1).normalize(),
    new THREE.Vector3(0.18, 0.12, 1).normalize(),
  );

  // Octant cut planes, defined in body space and pushed to world space every frame
  const localPlanes = [
    new THREE.Plane(new THREE.Vector3(-1, 0, 0), 0),
    new THREE.Plane(new THREE.Vector3(0, -1, 0), 0),
    new THREE.Plane(new THREE.Vector3(0, 0, -1), 0),
  ];
  const worldPlanes = localPlanes.map((p) => p.clone());

  // Core: faceted absorber crystals
  const coreMat = new THREE.MeshPhysicalMaterial({
    color: 0x1d1a15,
    metalness: 0.88,
    roughness: 0.2,
    clearcoat: 1,
    clearcoatRoughness: 0.1,
    iridescence: 0.55,
    iridescenceIOR: 1.9,
    flatShading: true,
    emissive: new THREE.Color(COLORS.pulse),
    emissiveIntensity: 0,
  });
  const core = new THREE.Group();
  const crystal = new THREE.Mesh(new THREE.IcosahedronGeometry(0.2, 0), coreMat);
  crystal.rotation.set(0.4, 0.8, 0.2);
  core.add(crystal);
  const satellites: Array<[number, number, number, number]> = [
    [0.17, -0.1, 0.02, 0.095],
    [-0.12, 0.16, 0.05, 0.085],
    [0.02, 0.05, -0.19, 0.1],
    [-0.14, -0.13, -0.08, 0.08],
    [0.1, 0.12, 0.12, 0.07],
  ];
  for (const [x, y, z, r] of satellites) {
    const m = new THREE.Mesh(new THREE.OctahedronGeometry(r, 0), coreMat);
    m.position.set(x, y, z);
    m.rotation.set(x * 9, y * 7, z * 5);
    core.add(m);
  }
  body.add(core);

  // Polymer matrix (outer surface), visible between lipid heads and at the cut rim
  const gelMat = new THREE.MeshPhysicalMaterial({
    color: 0x2a8ea0,
    roughness: 0.22,
    clearcoat: 1,
    emissive: new THREE.Color(0x0e4c5a),
    emissiveIntensity: 0.6,
    clippingPlanes: worldPlanes,
    clipIntersection: true,
    side: THREE.DoubleSide,
  });
  const gel = new THREE.Mesh(new THREE.SphereGeometry(R_GEL, 64, 48), gelMat);
  body.add(gel);

  // Tail layer of the bilayer
  const tailMat = new THREE.MeshPhysicalMaterial({
    color: 0x6f5a78,
    roughness: 0.5,
    sheen: 0.6,
    sheenColor: new THREE.Color(0xd6b9ff),
    clippingPlanes: worldPlanes,
    clipIntersection: true,
    side: THREE.DoubleSide,
  });
  const tails = new THREE.Mesh(new THREE.SphereGeometry(R_TAIL, 64, 48), tailMat);
  body.add(tails);

  // Cross-section caps on the three cut planes
  const capUniforms = {
    uCore: { value: R_CORE },
    uGel: { value: R_GEL },
    uLoad: { value: 1 },
    uCoat: { value: 1 },
    uHeat: { value: 0 },
    uTime: { value: 0 },
  };
  const capMat = new THREE.MeshStandardMaterial({ roughness: 0.42, metalness: 0, side: THREE.DoubleSide });
  capMat.onBeforeCompile = (shader) => {
    Object.assign(shader.uniforms, capUniforms);
    shader.vertexShader = shader.vertexShader
      .replace("#include <common>", "#include <common>\nvarying vec2 vCap;")
      .replace("#include <uv_vertex>", "#include <uv_vertex>\nvCap = position.xy;");
    shader.fragmentShader = shader.fragmentShader
      .replace(
        "#include <common>",
        `#include <common>
        uniform float uCore, uGel, uLoad, uCoat, uHeat, uTime;
        varying vec2 vCap;
        ${noiseGLSL}
        vec3 capEmissive = vec3(0.0);`,
      )
      .replace(
        "#include <map_fragment>",
        `
        float r = length(vCap);
        float rOuter = uCoat > 0.5 ? ${R_HEAD.toFixed(3)} : uGel;
        if (r < uCore - 0.01 || r > rOuter) discard;
        float ang = atan(vCap.y, vCap.x);
        vec3 col;
        if (r < uGel) {
          vec3 net = labCells(vCap * 9.0);
          float fiber = 1.0 - smoothstep(0.015, 0.05, net.x);
          vec3 drug = labCells(vCap * 13.0 + 4.0);
          float dot1 = step(0.55, drug.z) * (1.0 - smoothstep(0.1, 0.16, drug.y)) * uLoad;
          float depth = smoothstep(uCore, uGel, r);
          col = mix(vec3(0.03, 0.2, 0.25), vec3(0.06, 0.34, 0.4), depth);
          col = mix(col, vec3(0.5, 0.86, 0.9), fiber * 0.5);
          col = mix(col, vec3(0.9, 0.3, 0.2), dot1);
          col = mix(col, vec3(0.6, 0.25, 0.06), uHeat * (1.0 - depth) * 0.8);
          capEmissive = vec3(0.02, 0.16, 0.19) * (0.6 + fiber) + vec3(1.0, 0.35, 0.18) * dot1 * 0.9;
          capEmissive += vec3(1.0, 0.45, 0.12) * uHeat * (1.0 - depth) * 1.6;
        } else {
          float band = (r - uGel) / (${R_HEAD.toFixed(3)} - uGel);
          float spacing = 0.064;
          float along = fract(ang * r / spacing) - 0.5;
          float inner = length(vec2((r - (uGel + 0.02)) / spacing, along)) ;
          float outer = length(vec2((r - (${R_HEAD.toFixed(3)} - 0.02)) / spacing, along));
          float heads = max(1.0 - smoothstep(0.3, 0.42, inner), 1.0 - smoothstep(0.3, 0.42, outer));
          float tailLines = smoothstep(0.35, 0.0, abs(fract(ang * r / (spacing * 0.5)) - 0.5)) * step(0.28, band) * step(band, 0.72);
          col = mix(vec3(0.23, 0.17, 0.27), vec3(0.42, 0.33, 0.47), tailLines);
          col = mix(col, vec3(0.86, 0.78, 0.86), heads);
          capEmissive = vec3(0.05, 0.03, 0.07) * heads;
        }
        diffuseColor.rgb = col;
        `,
      )
      .replace(
        "#include <emissivemap_fragment>",
        "#include <emissivemap_fragment>\ntotalEmissiveRadiance += capEmissive;",
      );
  };
  capMat.customProgramCacheKey = () => "lab-np-cap";

  const capGeo = new THREE.CircleGeometry(1, 96, 0, Math.PI / 2);
  const capZ = new THREE.Mesh(capGeo, capMat);
  const capX = new THREE.Mesh(capGeo, capMat);
  capX.rotation.y = -Math.PI / 2;
  const capY = new THREE.Mesh(capGeo, capMat);
  capY.rotation.x = Math.PI / 2;
  body.add(capZ, capX, capY);

  // Lipid heads + surface proteins (instanced), outside the removed octant
  const target = lowPower ? 1300 : 2600;
  const dirs: THREE.Vector3[] = [];
  const golden = Math.PI * (3 - Math.sqrt(5));
  for (let i = 0; i < target; i++) {
    const y = 1 - (i / (target - 1)) * 2;
    const rad = Math.sqrt(1 - y * y);
    const th = golden * i;
    const d = new THREE.Vector3(Math.cos(th) * rad, y, Math.sin(th) * rad);
    if (d.x > 0.012 && d.y > 0.012 && d.z > 0.012) continue;
    dirs.push(d);
  }
  const headGeo = new THREE.IcosahedronGeometry(lowPower ? 0.05 : 0.043, 1);
  const headMat = new THREE.MeshPhysicalMaterial({
    color: 0xffffff,
    roughness: 0.32,
    clearcoat: 0.6,
    clearcoatRoughness: 0.3,
    sheen: 0.8,
    sheenColor: new THREE.Color(0xd8c2ff),
    iridescence: 0.35,
  });
  const heads = new THREE.InstancedMesh(headGeo, headMat, dirs.length);
  heads.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  const headColor = new THREE.Color();
  const headScale = new Float32Array(dirs.length);
  const headDelay = new Float32Array(dirs.length);
  for (let i = 0; i < dirs.length; i++) {
    const d = dirs[i];
    const r = Math.random();
    if (r < 0.05) {
      headColor.set(COLORS.core);
      headScale[i] = 1.55;
    } else if (r < 0.1) {
      headColor.set(0x9ad8e2);
      headScale[i] = 1.3;
    } else {
      headColor.setHSL(0.85 + Math.random() * 0.06, 0.28, 0.8 + Math.random() * 0.08);
      headScale[i] = 0.92 + Math.random() * 0.16;
    }
    heads.setColorAt(i, headColor);
    headDelay[i] = (Math.atan2(d.z, d.x) / (Math.PI * 2) + 0.5) * 0.55 + (1 - d.y) * 0.12;
  }
  const maxDelay = headDelay.reduce((a, b) => Math.max(a, b), 0) + 0.42;
  heads.frustumCulled = false;
  body.add(heads);

  // Loupe: backing disc, rim, dial ticks, and the ring the particle "sings" into
  const loupeUniforms = {
    uTime: { value: 0 },
    uWave: { value: -100 },
    uRim: { value: new THREE.Color(COLORS.bone) },
    uEcho: { value: new THREE.Color(COLORS.echo) },
    uOpacity: { value: 1 },
  };
  const loupe = new THREE.Mesh(
    new THREE.PlaneGeometry(3.4, 3.4),
    new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      uniforms: loupeUniforms,
      vertexShader: /* glsl */ `
        varying vec2 vUv;
        void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
      `,
      fragmentShader: /* glsl */ `
        uniform float uTime, uWave, uOpacity;
        uniform vec3 uRim, uEcho;
        varying vec2 vUv;
        void main() {
          vec2 p = (vUv - 0.5) * 3.4;
          float r = length(p);
          float a = atan(p.y, p.x);
          float R = 1.2;
          float disc = 1.0 - smoothstep(R - 0.01, R + 0.01, r);
          vec3 col = mix(vec3(0.02, 0.05, 0.06), vec3(0.0, 0.012, 0.016), smoothstep(0.0, R, r));
          float alpha = disc * 0.72;
          float rim = smoothstep(0.012, 0.0, abs(r - R));
          col += uRim * rim * 1.1;
          alpha = max(alpha, rim);
          float tickA = fract((a + uTime * 0.03) / 6.28318 * 72.0);
          float major = step(0.5, fract((a + uTime * 0.03) / 6.28318 * 12.0 + 0.0415)) ;
          float tickLen = mix(0.045, 0.1, step(fract((a + uTime * 0.03) / 6.28318 * 12.0), 0.08));
          float tick = step(abs(tickA - 0.5), 0.07) * step(R + 0.03, r) * step(r, R + 0.03 + tickLen);
          col += uRim * tick * 0.55;
          alpha = max(alpha, tick * 0.55);
          float glare = smoothstep(0.03, 0.0, abs(r - (R - 0.06))) * smoothstep(0.3, 1.0, sin(a - 2.2)) * 0.35;
          col += vec3(1.0) * glare;
          float wt = uTime - uWave;
          if (wt > 0.0 && wt < 1.6) {
            float wr = R + wt * 0.8;
            float ring = exp(-pow((r - wr) / 0.03, 2.0)) * (1.0 - wt / 1.6);
            col += uEcho * ring * 2.0;
            alpha = max(alpha, ring);
          }
          gl_FragColor = vec4(col, alpha * uOpacity);
        }
      `,
    }),
  );
  loupe.position.z = -1.25;
  loupe.renderOrder = -1;
  root.add(loupe);

  const m = new THREE.Matrix4();
  const up = new THREE.Vector3(0, 1, 0);
  const q = new THREE.Quaternion();
  const p = new THREE.Vector3();
  const s = new THREE.Vector3();
  let lastCoat = -1;

  function layoutHeads(coat: number) {
    if (Math.abs(coat - lastCoat) < 1e-4) return;
    lastCoat = coat;
    for (let i = 0; i < dirs.length; i++) {
      const k = easeOut(clamp01((coat * (1 + maxDelay) - headDelay[i]) / 0.42));
      const r = R_HEAD + (1 - k) * 0.75;
      p.copy(dirs[i]).multiplyScalar(r);
      s.setScalar(headScale[i] * (0.2 + 0.8 * k) * (k > 0.001 ? 1 : 0));
      q.setFromUnitVectors(up, dirs[i]);
      m.compose(p, q, s);
      heads.setMatrixAt(i, m);
    }
    heads.instanceMatrix.needsUpdate = true;
    if (heads.instanceColor) heads.instanceColor.needsUpdate = true;
  }

  /** Build-stage choreography, seconds into the build stage. Outside it, fully assembled. */
  function assemblyAt(buildT: number | null): Assembly {
    if (buildT === null) return { core: 1, gel: 1, load: 1, coat: 1 };
    const apart = smooth(0.0, 0.9, buildT);
    const core = 1;
    const gelIn = smooth(1.5, 2.6, buildT);
    const loadIn = smooth(2.1, 2.9, buildT);
    const coatIn = smooth(2.7, 4.5, buildT);
    return {
      core,
      gel: Math.max(1 - apart, gelIn),
      load: Math.max(1 - apart, loadIn),
      coat: Math.max(1 - apart, coatIn),
    };
  }

  const anchors = {
    core: new THREE.Vector3(0.14, 0.14, 0.14),
    matrix: new THREE.Vector3(0.62, 0.0, 0.38),
    coat: new THREE.Vector3(-0.2, 0.96, 0.2),
  };
  const worldAnchor = new THREE.Vector3();

  function update(time: number, buildT: number | null, heat: number, waveT: number, camera: THREE.Camera) {
    root.lookAt(camera.position);
    spin.rotation.z = Math.sin(time * 0.12) * 0.22 + time * 0.02;

    const a = assemblyAt(buildT);
    const gelR = THREE.MathUtils.lerp(R_CORE + 0.02, R_GEL, a.gel);
    gel.scale.setScalar(gelR / R_GEL);
    gel.visible = a.gel > 0.02;
    tails.visible = a.coat > 0.35;
    tails.scale.setScalar(THREE.MathUtils.lerp(R_GEL, R_TAIL, clamp01((a.coat - 0.35) / 0.4)) / R_TAIL);
    capUniforms.uGel.value = gelR;
    capUniforms.uLoad.value = a.load;
    capUniforms.uCoat.value = a.coat > 0.6 ? 1 : 0;
    capUniforms.uHeat.value = heat;
    capUniforms.uTime.value = time;
    layoutHeads(a.coat);

    core.rotation.y = time * 0.15;
    coreMat.emissiveIntensity = heat * 5;
    loupeUniforms.uTime.value = time;
    loupeUniforms.uWave.value = waveT;

    root.updateMatrixWorld(true);
    for (let i = 0; i < 3; i++) worldPlanes[i].copy(localPlanes[i]).applyMatrix4(body.matrixWorld);
    return a;
  }

  function anchorWorld(name: keyof typeof anchors, out = worldAnchor) {
    return body.localToWorld(out.copy(anchors[name]));
  }

  return { root, update, anchorWorld, radius: 1.2 };
}
