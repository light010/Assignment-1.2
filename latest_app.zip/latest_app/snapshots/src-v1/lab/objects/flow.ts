import * as THREE from "three";
import { BLOCK, COLORS, FACE_Z, LEAK, PA_SOURCES, STAGE_WINDOWS, TUMOR, VESSEL } from "../constants";

/*
  Blood flow through the cut vessel: red blood cells, circulating nanoparticles, and a
  cohort of particles that leave through the leaky wall, settle in the tumor, and
  release their drug.
*/

const PIPE_HALF = (BLOCK.w - 0.07) / 2;
const TRAVEL = 1.5;
const EXIT = 0.75;
const SETTLE = 1.3;

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const easeOut = (t: number) => 1 - Math.pow(1 - t, 3);
const easeInOut = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
const clamp01 = (t: number) => Math.min(1, Math.max(0, t));

/** Biconcave disc (Evans–Fung profile), diameter 2 * radius. */
function createRBCGeometry(radius: number) {
  const pts: THREE.Vector2[] = [];
  const thickness = (u: number) => {
    const s = Math.sqrt(Math.max(0, 1 - u * u));
    return 2 * s * (0.0518 + 0.50065 * u * u - 0.2807 * u ** 4);
  };
  const steps = 12;
  for (let i = 0; i <= steps; i++) {
    const u = Math.sin((i / steps) * (Math.PI / 2));
    pts.push(new THREE.Vector2(u * radius, (thickness(u) * radius) / 2 + 0.0005));
  }
  for (let i = steps; i >= 0; i--) {
    const u = Math.sin((i / steps) * (Math.PI / 2));
    pts.push(new THREE.Vector2(u * radius, -(thickness(u) * radius) / 2 - 0.0005));
  }
  const geo = new THREE.LatheGeometry(pts, 28);
  geo.computeVertexNormals();
  return geo;
}

interface Cell {
  x: number;
  theta: number;
  rho: number;
  speed: number;
  spin: THREE.Quaternion;
  q: THREE.Quaternion;
}

interface Carrier {
  start: number;
  exitX: number;
  theta: number;
  rho: number;
  target: THREE.Vector3;
  jitter: number;
}

export function createFlow({ lowPower }: { lowPower: boolean }) {
  const rand = mulberry32(7);
  const group = new THREE.Group();
  group.name = "flow";

  // Red blood cells
  const rbcCount = lowPower ? 22 : 36;
  const rbcGeo = createRBCGeometry(0.13);
  const rbcMat = new THREE.MeshPhysicalMaterial({
    color: 0xa8141c,
    roughness: 0.38,
    clearcoat: 0.8,
    clearcoatRoughness: 0.22,
    sheen: 1,
    sheenColor: new THREE.Color(0xff5a48),
    sheenRoughness: 0.35,
    emissive: new THREE.Color(0x4a0508),
  });
  const rbcs = new THREE.InstancedMesh(rbcGeo, rbcMat, rbcCount);
  rbcs.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  rbcs.frustumCulled = false;
  const cells: Cell[] = [];
  for (let i = 0; i < rbcCount; i++) {
    const axis = new THREE.Vector3(rand() - 0.5, rand() - 0.5, rand() - 0.5).normalize();
    cells.push({
      x: -PIPE_HALF + rand() * PIPE_HALF * 2,
      theta: Math.PI / 2 + 0.25 + rand() * (Math.PI - 0.5),
      rho: 0.02 + rand() * 0.13,
      speed: 0,
      spin: new THREE.Quaternion().setFromAxisAngle(axis, 0.5 + rand() * 0.8),
      q: new THREE.Quaternion().setFromEuler(new THREE.Euler(rand() * 6, rand() * 6, rand() * 6)),
    });
  }
  group.add(rbcs);

  // Nanoparticles: circulating + carriers that extravasate
  const npCount = lowPower ? 22 : 34;
  const carrierCount = lowPower ? 24 : 36;
  const npGeo = new THREE.IcosahedronGeometry(0.029, 2);
  const npMat = new THREE.MeshStandardMaterial({
    color: 0xf1e9df,
    roughness: 0.22,
    metalness: 0.15,
    emissive: new THREE.Color(COLORS.core),
    emissiveIntensity: 0.55,
  });
  const nps = new THREE.InstancedMesh(npGeo, npMat, npCount + carrierCount);
  nps.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  nps.frustumCulled = false;
  const circulating = Array.from({ length: npCount }, () => ({
    x: -PIPE_HALF + rand() * PIPE_HALF * 2,
    theta: Math.PI / 2 + 0.1 + rand() * (Math.PI - 0.2),
    rho: rand() * (VESSEL.r - 0.05),
    phase: rand() * 10,
  }));

  const carriers: Carrier[] = [];
  const deliverLength = STAGE_WINDOWS.deliver[1] - STAGE_WINDOWS.deliver[0];
  for (let i = 0; i < carrierCount; i++) {
    const [sx, sy] = PA_SOURCES[i % PA_SOURCES.length];
    let tx = sx + (rand() - 0.5) * 0.36;
    let ty = sy + (rand() - 0.5) * 0.3;
    const d = Math.hypot(tx - TUMOR.x, (ty - TUMOR.y) * 1.1);
    if (d > TUMOR.r * 0.85) {
      const k = (TUMOR.r * 0.85) / d;
      tx = TUMOR.x + (tx - TUMOR.x) * k;
      ty = TUMOR.y + (ty - TUMOR.y) * k;
    }
    carriers.push({
      start: 0.15 + (i / carrierCount) * (deliverLength - TRAVEL - EXIT - SETTLE - 0.4) + rand() * 0.3,
      exitX: LEAK.x0 + 0.1 + rand() * (LEAK.x1 - LEAK.x0 - 0.2),
      theta: Math.PI + (rand() - 0.5) * 1.6,
      rho: 0.04 + rand() * 0.14,
      target: new THREE.Vector3(tx, ty, FACE_Z + 0.02),
      jitter: rand() * 100,
    });
  }
  group.add(nps);

  // Drug molecules released from settled carriers
  const perCarrier = lowPower ? 4 : 7;
  const dropCount = carrierCount * perCarrier;
  const dropPos = new Float32Array(dropCount * 3);
  const dropAlpha = new Float32Array(dropCount);
  const dropSeeds = Array.from({ length: dropCount }, () => ({
    dir: new THREE.Vector2(rand() - 0.5, rand() - 0.5).normalize(),
    delay: rand() * 2.2,
    speed: 0.18 + rand() * 0.22,
  }));
  const dropGeo = new THREE.BufferGeometry();
  dropGeo.setAttribute("position", new THREE.BufferAttribute(dropPos, 3).setUsage(THREE.DynamicDrawUsage));
  dropGeo.setAttribute("alpha", new THREE.BufferAttribute(dropAlpha, 1).setUsage(THREE.DynamicDrawUsage));
  const dropMat = new THREE.ShaderMaterial({
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    uniforms: {
      uColor: { value: new THREE.Color(0xff8a5c).multiplyScalar(2.2) },
      uScale: { value: 1 },
    },
    vertexShader: /* glsl */ `
      attribute float alpha;
      uniform float uScale;
      varying float vAlpha;
      void main() {
        vAlpha = alpha;
        vec4 mv = modelViewMatrix * vec4(position, 1.0);
        gl_PointSize = uScale * 7.0 / -mv.z * 10.0;
        gl_Position = projectionMatrix * mv;
      }
    `,
    fragmentShader: /* glsl */ `
      uniform vec3 uColor;
      varying float vAlpha;
      void main() {
        float d = length(gl_PointCoord - 0.5);
        float a = smoothstep(0.5, 0.1, d) * vAlpha;
        if (a < 0.01) discard;
        gl_FragColor = vec4(uColor * a, a);
      }
    `,
  });
  const drops = new THREE.Points(dropGeo, dropMat);
  drops.frustumCulled = false;
  group.add(drops);

  const m = new THREE.Matrix4();
  const pos = new THREE.Vector3();
  const scl = new THREE.Vector3();
  const tmpQ = new THREE.Quaternion();
  const identity = new THREE.Quaternion();
  const carrierPos = carriers.map(() => new THREE.Vector3());
  const carrierSettled = new Float32Array(carrierCount);

  function lumenPoint(x: number, theta: number, rho: number, out: THREE.Vector3) {
    return out.set(x, VESSEL.y + rho * Math.sin(theta), FACE_Z + rho * Math.cos(theta));
  }

  /**
   * @param time    timeline seconds (continuous)
   * @param loopT   seconds into the current loop
   * @param dt      timeline delta
   * @param heat    0..1 laser flash envelope
   * @param rate    flow speed multiplier
   */
  function update(time: number, loopT: number, dt: number, heat: number, rate: number) {
    // Red cells: parabolic (Poiseuille) velocity profile
    for (let i = 0; i < cells.length; i++) {
      const c = cells[i];
      const v = (0.95 * (1 - (c.rho / VESSEL.r) ** 2) + 0.2) * rate;
      c.x += v * dt;
      if (c.x > PIPE_HALF + 0.2) c.x -= PIPE_HALF * 2 + 0.4;
      tmpQ.copy(identity).slerp(c.spin, Math.min(1, dt * 1.2 * rate));
      c.q.multiply(tmpQ);
      lumenPoint(c.x, c.theta, c.rho, pos);
      const edge = clamp01((PIPE_HALF + 0.02 - Math.abs(c.x)) / 0.25);
      scl.setScalar(edge);
      m.compose(pos, c.q, scl);
      rbcs.setMatrixAt(i, m);
    }
    rbcs.instanceMatrix.needsUpdate = true;

    for (let i = 0; i < circulating.length; i++) {
      const p = circulating[i];
      const v = (1.1 * (1 - (p.rho / VESSEL.r) ** 2) + 0.25) * rate;
      p.x += v * dt;
      if (p.x > PIPE_HALF + 0.1) p.x -= PIPE_HALF * 2 + 0.2;
      lumenPoint(p.x, p.theta + Math.sin(time * 1.3 + p.phase) * 0.05, p.rho, pos);
      const edge = clamp01((PIPE_HALF - Math.abs(p.x)) / 0.2);
      scl.setScalar(edge);
      m.compose(pos, identity, scl);
      nps.setMatrixAt(i, m);
    }

    // Carriers: position along their journey, driven by time since the deliver stage began
    const inBuild = loopT < STAGE_WINDOWS.deliver[0];
    const deliverT = loopT - STAGE_WINDOWS.deliver[0];
    const clearFade = inBuild ? 1 - clamp01(loopT / 1.1) : 1;
    let accumulation = 0;

    for (let i = 0; i < carriers.length; i++) {
      const c = carriers[i];
      const out = carrierPos[i];
      let scale = 1;
      let settled = 0;
      if (inBuild) {
        out.copy(c.target);
        out.x += Math.sin(time * 0.9 + c.jitter) * 0.012;
        out.y += Math.cos(time * 0.8 + c.jitter) * 0.012;
        scale = clearFade;
        settled = clearFade;
      } else {
        const tau = deliverT - c.start;
        if (tau < 0) {
          scale = 0;
          out.set(-PIPE_HALF, VESSEL.y, FACE_Z - 0.1);
        } else if (tau < TRAVEL) {
          const k = easeInOut(tau / TRAVEL);
          lumenPoint(THREE.MathUtils.lerp(-PIPE_HALF, c.exitX, k), c.theta, c.rho, out);
          scale = clamp01((out.x + PIPE_HALF) / 0.2);
        } else if (tau < TRAVEL + EXIT) {
          const k = easeInOut((tau - TRAVEL) / EXIT);
          const a = lumenPoint(c.exitX, c.theta, c.rho, pos);
          out.set(
            c.exitX + k * 0.05,
            THREE.MathUtils.lerp(a.y, VESSEL.y - VESSEL.r - 0.1, k),
            THREE.MathUtils.lerp(a.z, FACE_Z + 0.02, k),
          );
        } else {
          const k = easeOut(clamp01((tau - TRAVEL - EXIT) / SETTLE));
          const sx = c.exitX + 0.05;
          const sy = VESSEL.y - VESSEL.r - 0.1;
          const cx = (sx + c.target.x) / 2 + 0.1;
          const cy = Math.min(sy, c.target.y) + 0.12;
          const u = 1 - k;
          out.set(
            u * u * sx + 2 * u * k * cx + k * k * c.target.x,
            u * u * sy + 2 * u * k * cy + k * k * c.target.y,
            FACE_Z + 0.02,
          );
          out.x += Math.sin(time * 0.9 + c.jitter) * 0.012 * k;
          out.y += Math.cos(time * 0.8 + c.jitter) * 0.012 * k;
          settled = k;
        }
      }
      carrierSettled[i] = settled;
      accumulation += settled;
      scl.setScalar(scale);
      m.compose(out, identity, scl);
      nps.setMatrixAt(npCount + i, m);
    }
    nps.instanceMatrix.needsUpdate = true;
    npMat.emissiveIntensity = 0.55 + heat * 3.2;

    // Drug release: molecules drift out of each settled carrier and fade
    const releaseClock = inBuild ? -1 : loopT - STAGE_WINDOWS.deliver[0];
    for (let i = 0; i < dropCount; i++) {
      const ci = Math.floor(i / perCarrier);
      const c = carriers[ci];
      const s = dropSeeds[i];
      const since = releaseClock - (c.start + TRAVEL + EXIT + SETTLE * 0.6) - s.delay;
      const life = ((since % 2.4) + 2.4) % 2.4;
      const active = since > 0 && carrierSettled[ci] > 0.5 ? 1 : 0;
      const k = life / 2.4;
      const r = s.speed * easeOut(k) * 1.1;
      const o = i * 3;
      dropPos[o] = carrierPos[ci].x + s.dir.x * r;
      dropPos[o + 1] = carrierPos[ci].y + s.dir.y * r;
      dropPos[o + 2] = FACE_Z + 0.03;
      dropAlpha[i] = active * Math.sin(Math.PI * k) * 0.9 * clearFade;
    }
    dropGeo.attributes.position.needsUpdate = true;
    dropGeo.attributes.alpha.needsUpdate = true;

    return accumulation / carriers.length;
  }

  return { group, update, npMaterial: npMat, dropMaterial: dropMat };
}
