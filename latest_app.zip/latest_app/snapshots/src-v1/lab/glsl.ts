/* Shared GLSL. All colours are linear-space; three.js converts on output. */

export const noiseGLSL = /* glsl */ `
float labHash12(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}
vec2 labHash22(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973));
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.xx + p3.yz) * p3.zy);
}
float labNoise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  float a = labHash12(i);
  float b = labHash12(i + vec2(1.0, 0.0));
  float c = labHash12(i + vec2(0.0, 1.0));
  float d = labHash12(i + vec2(1.0, 1.0));
  return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}
float labFbm(vec2 p) {
  float s = 0.0;
  float a = 0.5;
  for (int i = 0; i < 4; i++) {
    s += a * labNoise(p);
    p = p * 2.07 + vec2(17.3, 9.1);
    a *= 0.5;
  }
  return s;
}
/* Cellular pattern. x: distance to the cell wall, y: distance to the cell centre, z: cell hash. */
vec3 labCells(vec2 x) {
  vec2 n = floor(x);
  vec2 f = fract(x);
  float d1 = 8.0;
  float d2 = 8.0;
  float id = 0.0;
  for (int j = -1; j <= 1; j++) {
    for (int i = -1; i <= 1; i++) {
      vec2 g = vec2(float(i), float(j));
      vec2 o = 0.15 + 0.7 * labHash22(n + g);
      vec2 r = g + o - f;
      float d = dot(r, r);
      if (d < d1) {
        d2 = d1;
        d1 = d;
        id = labHash12(n + g + 3.7);
      } else if (d < d2) {
        d2 = d;
      }
    }
  }
  d1 = sqrt(d1);
  d2 = sqrt(d2);
  return vec3(0.5 * (d2 - d1), d1, id);
}
vec3 labPerturbNormal(vec3 surfPos, vec3 surfNorm, vec2 dHdxy, float faceDirection) {
  vec3 sigmaX = dFdx(surfPos);
  vec3 sigmaY = dFdy(surfPos);
  vec3 r1 = cross(sigmaY, surfNorm);
  vec3 r2 = cross(surfNorm, sigmaX);
  float det = dot(sigmaX, r1) * faceDirection;
  vec3 grad = sign(det) * (dHdxy.x * r1 + dHdxy.y * r2);
  return normalize(abs(det) * surfNorm - grad);
}
`;

/*
  The tissue block. One material shades every face by its normal:
  front = the cut cross-section (skin, dermis, cells, vessel, tumor, live wave field),
  top = skin with a patch of ultrasound gel under the probe, sides = cut tissue.
*/
export const tissueParsGLSL = /* glsl */ `
uniform float uTime;
uniform vec3 uBlock;
uniform vec2 uVessel;
uniform vec2 uLeak;
uniform vec3 uTumor;
uniform vec3 uProbe;
uniform float uAccum;
uniform float uLaserT;
uniform float uUsT;
uniform float uPAT;
uniform float uWaveSpeed;
uniform vec3 uSrc[6];
uniform vec3 uPulseColor;
uniform vec3 uEchoColor;
uniform vec3 uHeatColor;
uniform float uDim;

varying vec3 vLabPos;
varying vec3 vLabNormal;

${noiseGLSL}

struct LabTissue {
  vec3 albedo;
  float rough;
  float height;
  vec3 emissive;
};

float labTumorField(vec2 p) {
  vec2 d = p - uTumor.xy;
  float a = atan(d.y, d.x);
  float r = length(d * vec2(0.84, 1.0));
  float edge = uTumor.z * (1.0 + 0.09 * sin(a * 3.0 + 1.7) + 0.06 * sin(a * 5.0 - 0.4) + 0.24 * (labFbm(p * 2.4 + 3.1) - 0.5));
  return edge - r;
}

float labSourceHeat(vec2 p) {
  float h = 0.0;
  for (int i = 0; i < 6; i++) {
    vec2 d = p - uSrc[i].xy;
    h += uSrc[i].z * exp(-dot(d, d) / 0.045);
  }
  return h;
}

/* Pressure field on the cut face. Positive = compression, negative = rarefaction. */
float labAcoustic(vec2 p) {
  float field = 0.0;
  float depth = -p.y;

  float pt = uTime - uPAT;
  if (pt > 0.0 && pt < 3.2) {
    for (int i = 0; i < 6; i++) {
      float r = length(p - uSrc[i].xy);
      float ph = (r - uWaveSpeed * pt) / 0.06;
      float nwave = -ph * exp(-0.5 * ph * ph);
      field += uSrc[i].z * nwave * 0.62 / sqrt(r + 0.22);
    }
    field *= smoothstep(3.2, 1.7, pt) * step(p.y, -0.02);
  }

  float ut = uTime - uUsT;
  if (ut > 0.0 && ut < 2.8) {
    float spread = uProbe.y * (1.0 + depth * 0.22);
    float aperture = exp(-pow(abs(p.x - uProbe.x) / spread, 6.0));
    float front = -uWaveSpeed * ut;
    float ph = (p.y - front) / 0.03;
    // A real transmit pulse: a few carrier cycles under a Gaussian envelope
    field += 1.05 * aperture * exp(-0.5 * pow(ph / 2.2, 2.0)) * cos(ph * 1.9) * smoothstep(3.1, 1.6, depth);

    for (int k = 0; k < 3; k++) {
      float ry = k == 0 ? uVessel.x + uVessel.y : (k == 1 ? uVessel.x - uVessel.y : uTumor.y + uTumor.z * 0.82);
      float et = ut + ry / uWaveSpeed;
      if (et > 0.0) {
        float r = length(vec2((p.x - uProbe.x) * 0.5, p.y - ry));
        float ph2 = (r - uWaveSpeed * et) / 0.03;
        float amp = (k == 2 ? 0.62 : 0.48) * step(ry, p.y) * aperture;
        field += amp * exp(-0.5 * pow(ph2 / 1.8, 2.0)) * cos(ph2 * 1.9) / sqrt(r + 0.3);
      }
    }
  }
  return field;
}

/* px = pixel footprint in cell units, taken outside any branch so derivatives stay defined. */
vec3 labCellColor(vec2 cq, float px, float isTumor, out float nucleus, out float height) {
  vec3 c = labCells(cq);
  float wallLine = 1.0 - smoothstep(0.0, 0.07 + px, c.x);
  float nucR = mix(0.19, 0.33, isTumor) * mix(0.82 + 0.36 * c.z, 0.62 + 0.8 * c.z, isTumor);
  nucleus = 1.0 - smoothstep(nucR - px, nucR + px, c.y);
  float nucleolus = (1.0 - smoothstep(0.045 - px, 0.045 + px, c.y)) * isTumor;
  float chromatin = labNoise(cq * 7.0 + c.z * 19.0);
  float grain = labNoise(cq * 3.3 + 7.0);
  float dome = 1.0 - smoothstep(0.05, 0.62, c.y);
  vec3 cyto = isTumor > 0.5
    ? mix(vec3(0.3, 0.085, 0.24), vec3(0.42, 0.13, 0.33), c.z * 0.7 + grain * 0.3)
    : mix(vec3(0.66, 0.26, 0.3), vec3(0.78, 0.36, 0.38), c.z * 0.7 + grain * 0.3);
  vec3 nuc = isTumor > 0.5
    ? mix(vec3(0.07, 0.015, 0.13), vec3(0.16, 0.04, 0.26), chromatin)
    : mix(vec3(0.12, 0.035, 0.2), vec3(0.24, 0.08, 0.34), chromatin);
  vec3 col = cyto * (0.82 + 0.26 * dome);
  col = mix(col, col * 0.62, wallLine * 0.8);
  col = mix(col, nuc, nucleus * 0.92);
  col = mix(col, vec3(0.05, 0.01, 0.08), nucleolus * 0.8);
  height = dome * 0.8 + nucleus * 0.25 - wallLine * 0.3;
  return col;
}

LabTissue labFront(vec2 p) {
  LabTissue t;
  float depth = -p.y;
  vec2 warp = vec2(labFbm(p * 1.1), labFbm(p * 1.1 + 5.2)) - 0.5;
  vec2 q = p + warp * 0.24;

  float tf = labTumorField(p);
  float tumor = smoothstep(-0.05, 0.08, tf);
  float margin = exp(-tf * tf / 0.0018);

  // Histology: soft domed cells, eosin-pink cytoplasm, hematoxylin-purple nuclei.
  // Normal and tumor cells are separate patterns blended by the mask (blending the scale warps cells).
  vec2 cqN = q * 2.9;
  vec2 cqT = q * 5.1 + 17.0;
  float pxN = length(fwidth(cqN)) * 0.9 + 0.015;
  float pxT = length(fwidth(cqT)) * 0.9 + 0.015;
  float nucN, hN;
  vec3 colN = labCellColor(cqN, pxN, 0.0, nucN, hN);
  float nucT = nucN;
  float hT = hN;
  vec3 colT = colN;
  if (tumor > 0.001) {
    colT = labCellColor(cqT, pxT, 1.0, nucT, hT);
    hT += 0.35;
  }
  vec3 col = mix(colN, colT, tumor);
  float nucleus = mix(nucN, nucT, tumor);
  col = mix(col, col * vec3(0.55, 0.42, 0.62), margin * 0.7);

  float epi = 1.0 - smoothstep(0.05, 0.085, depth);
  float derm = (1.0 - smoothstep(0.28, 0.4, depth + warp.x * 0.1)) * (1.0 - epi);

  float fib = labNoise(vec2(q.x * 1.6, q.y * 11.0 + labFbm(q * 2.0) * 3.0));
  vec3 dermCol = mix(vec3(0.7, 0.34, 0.32), vec3(0.86, 0.5, 0.44), smoothstep(0.3, 0.8, fib));
  col = mix(col, dermCol, derm);
  vec3 epiCol = mix(vec3(0.4, 0.2, 0.14), vec3(0.52, 0.29, 0.2), labNoise(q * 24.0));
  col = mix(col, epiCol, epi);

  float h = mix(hN, hT, tumor) * (1.0 - derm - epi) + derm * fib * 0.25;

  vec3 cap = labCells(q * 1.5 + 11.0);
  float capillary = step(0.86, cap.z) * (1.0 - smoothstep(0.05, 0.075, cap.y)) * (1.0 - tumor) * step(0.5, depth);
  col = mix(col, vec3(0.34, 0.02, 0.03), capillary);

  float dy = p.y - uVessel.x;
  float ad = abs(dy);
  float wall = smoothstep(uVessel.y + 0.1, uVessel.y + 0.07, ad);
  float leakZone = step(uLeak.x, p.x) * step(p.x, uLeak.y) * step(dy, 0.0);
  float gap = leakZone * smoothstep(0.62, 0.8, abs(fract(p.x * 2.4 + 0.3) - 0.5) * 2.0);
  float innerEdge = exp(-pow((ad - uVessel.y - 0.012) / 0.012, 2.0));
  col = mix(col, vec3(0.42, 0.03, 0.05), wall * (1.0 - gap));
  col += vec3(0.5, 0.12, 0.12) * innerEdge * (1.0 - gap);
  col = mix(col, vec3(0.16, 0.01, 0.02), gap * smoothstep(uVessel.y + 0.11, uVessel.y, ad));
  h += wall * (1.0 - gap) * 0.4;

  vec3 em = col * 0.07;
  float lt = uTime - uLaserT;
  float laserEnv = lt > 0.0 ? exp(-lt * 5.0) : 0.0;
  float beamHalf = uProbe.y * 0.95 + depth * 0.65;
  float fluence = exp(-depth * 0.9) * exp(-pow((p.x - uProbe.x) / beamHalf, 2.0));
  em += uPulseColor * fluence * laserEnv * 0.55;

  float heatSpots = labSourceHeat(p) * tumor;
  em += uHeatColor * heatSpots * uAccum * (0.04 + 1.5 * laserEnv) * (1.0 - nucleus * 0.5);

  float field = labAcoustic(p);
  em += uEchoColor * max(field, 0.0) * 1.1;
  col *= 1.0 - 0.45 * clamp(-field, 0.0, 1.0);

  t.albedo = col * uDim;
  t.rough = mix(0.46, 0.38, tumor) - wall * 0.14 + nucleus * 0.06;
  t.height = h;
  t.emissive = em * uDim;
  return t;
}

LabTissue labSide(vec2 p, float withVessel) {
  LabTissue t;
  vec2 warp = vec2(labFbm(p * 1.2 + 2.0), labFbm(p * 1.2 + 7.3)) - 0.5;
  vec2 q = p + warp * 0.25;
  float depth = -p.y;
  vec2 cq = q * 2.6 + 13.0;
  float px = length(fwidth(cq)) + 0.02;
  vec3 c = labCells(cq);
  float wallLine = 1.0 - smoothstep(0.0, 0.1 + px, c.x);
  float nucleus = 1.0 - smoothstep(0.2 - px, 0.2 + px, c.y);
  float epi = 1.0 - smoothstep(0.05, 0.085, depth);
  float derm = (1.0 - smoothstep(0.28, 0.4, depth)) * (1.0 - epi);
  vec3 col = mix(vec3(0.46, 0.15, 0.18), vec3(0.54, 0.2, 0.22), labFbm(q * 2.0));
  col = mix(col, col * 0.8, wallLine * 0.5);
  col = mix(col, vec3(0.22, 0.07, 0.2), nucleus * 0.35);
  col = mix(col, vec3(0.6, 0.3, 0.28), derm);
  col = mix(col, vec3(0.38, 0.2, 0.14), epi);

  float dv = length(p - vec2(uBlock.z * 0.5, uVessel.x));
  float lumen = (1.0 - smoothstep(uVessel.y - 0.01, uVessel.y + 0.01, dv)) * withVessel;
  float wall = smoothstep(uVessel.y + 0.1, uVessel.y + 0.07, dv) * (1.0 - lumen) * withVessel;
  col = mix(col, vec3(0.14, 0.006, 0.012), lumen);
  col = mix(col, vec3(0.4, 0.03, 0.05), wall);

  t.albedo = col * uDim * 0.8;
  t.rough = 0.55 - lumen * 0.3;
  t.height = (1.0 - smoothstep(0.05, 0.6, c.y)) * 0.4 * (1.0 - derm - epi);
  t.emissive = col * 0.035 * uDim;
  return t;
}

LabTissue labTop(vec2 p) {
  LabTissue t;
  float n = labFbm(p * 4.0);
  vec2 pc = p * 19.0;
  float px = length(fwidth(pc)) + 0.02;
  vec3 pores = labCells(pc);
  float pore = 1.0 - smoothstep(0.05 - px, 0.05 + px, pores.y);
  float crease = smoothstep(0.03, 0.0, abs(labNoise(vec2(p.x * 1.3 + p.y * 0.7, p.y * 2.4)) - 0.5)) * 0.5;
  vec3 col = mix(vec3(0.52, 0.31, 0.24), vec3(0.62, 0.4, 0.31), n);
  col *= 1.0 - pore * 0.045 - crease * 0.05;

  vec2 gd = (p - uProbe.xz) / vec2(uProbe.y + 0.45, 0.66);
  float gel = 1.0 - smoothstep(0.75, 1.0, length(gd) + (labFbm(p * 3.0) - 0.5) * 0.35);
  col = mix(col, col * vec3(0.84, 0.88, 0.92), gel);

  t.albedo = col * uDim;
  t.rough = mix(0.5, 0.08, gel);
  t.height = n * 0.18 - pore * 0.12 - crease * 0.12 + gel * 0.15;
  t.emissive = col * 0.04 * uDim;
  return t;
}
`;

export const tissueMainGLSL = /* glsl */ `
  vec3 labN = normalize(vLabNormal);
  LabTissue labT;
  if (labN.z > 0.6) {
    if (abs(vLabPos.y - uVessel.x) < uVessel.y && abs(vLabPos.x) < uBlock.x * 0.5 - 0.035) discard;
    labT = labFront(vLabPos.xy);
  } else if (labN.y > 0.6) {
    labT = labTop(vLabPos.xz);
  } else if (abs(labN.x) > 0.6) {
    labT = labSide(vec2(vLabPos.z, vLabPos.y), 1.0);
  } else {
    labT = labSide(vec2(vLabPos.x, vLabPos.y), 0.0);
  }
  diffuseColor.rgb = labT.albedo;
`;
