import { PA_SOURCES, PROBE, TUMOR, VESSEL } from "./constants";

/*
  Procedural photoacoustic/ultrasound image of the same anatomy the 3D tissue shows.
  B-mode: echogenicity map x Rayleigh speckle, log-compressed, with posterior shadowing.
  Photoacoustic: optical absorbers (skin melanin, blood, particles) in a hot colormap.
*/

export const SCAN_FOV = { halfWidth: 1.6, depth: 2.95 };

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function hash(x: number, y: number) {
  const s = Math.sin(x * 127.1 + y * 311.7) * 43758.5453;
  return s - Math.floor(s);
}
function vnoise(x: number, y: number) {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const fx = x - ix;
  const fy = y - iy;
  const ux = fx * fx * (3 - 2 * fx);
  const uy = fy * fy * (3 - 2 * fy);
  const a = hash(ix, iy);
  const b = hash(ix + 1, iy);
  const c = hash(ix, iy + 1);
  const d = hash(ix + 1, iy + 1);
  return a + (b - a) * ux + (c - a) * uy + (a - b - c + d) * ux * uy;
}
function fbm(x: number, y: number) {
  let s = 0;
  let a = 0.5;
  for (let i = 0; i < 4; i++) {
    s += a * vnoise(x, y);
    x = x * 2.07 + 17.3;
    y = y * 2.07 + 9.1;
    a *= 0.5;
  }
  return s;
}

/** Mirrors labTumorField() in the tissue shader. */
export function tumorField(x: number, y: number) {
  const dx = x - TUMOR.x;
  const dy = y - TUMOR.y;
  const a = Math.atan2(dy, dx);
  const r = Math.hypot(dx * 0.84, dy);
  const edge =
    TUMOR.r * (1 + 0.09 * Math.sin(a * 3 + 1.7) + 0.06 * Math.sin(a * 5 - 0.4) + 0.24 * (fbm(x * 2.4 + 3.1, y * 2.4 + 3.1) - 0.5));
  return edge - r;
}

function gaussianField(w: number, h: number, rand: () => number) {
  const out = new Float32Array(w * h);
  for (let i = 0; i < w * h; i += 2) {
    const u = Math.max(1e-7, rand());
    const v = rand();
    const m = Math.sqrt(-2 * Math.log(u));
    out[i] = m * Math.cos(2 * Math.PI * v);
    if (i + 1 < out.length) out[i + 1] = m * Math.sin(2 * Math.PI * v);
  }
  // Correlate: the point-spread function is wider laterally than axially.
  const tmp = new Float32Array(w * h);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let s = 0;
      for (let k = -2; k <= 2; k++) {
        const xx = Math.min(w - 1, Math.max(0, x + k));
        s += out[y * w + xx] * (k === 0 ? 1 : Math.abs(k) === 1 ? 0.7 : 0.3);
      }
      tmp[y * w + x] = s;
    }
  }
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const up = tmp[Math.max(0, y - 1) * w + x];
      const dn = tmp[Math.min(h - 1, y + 1) * w + x];
      out[y * w + x] = tmp[y * w + x] + 0.35 * (up + dn);
    }
  }
  return out;
}

export interface ScanLayers {
  width: number;
  height: number;
  bmode: ImageData[];
  tissuePA: ImageData;
  particlePA: ImageData;
}

function hot(v: number): [number, number, number] {
  const t = Math.min(1, Math.max(0, v));
  const r = Math.min(1, t * 2.6);
  const g = Math.min(1, Math.max(0, t * 2.4 - 0.75));
  const b = Math.min(1, Math.max(0, t * 3.0 - 2.1));
  return [r * 255, g * 240 + 10 * g, b * 230 + 25 * b];
}

export function buildScanLayers(width: number, height: number, frames = 2): ScanLayers {
  const rand = mulberry32(11);
  const bone = [236, 231, 223];
  const echo = new Float32Array(width * height);
  const paT = new Float32Array(width * height);
  const paP = new Float32Array(width * height);

  // Particle signal: clumpy sub-clusters around each accumulation site, heavier at the rim
  const blobRand = mulberry32(29);
  const blobs: { x: number; y: number; sx: number; sy: number; w: number }[] = [];
  for (const [sx, sy, w] of PA_SOURCES) {
    for (let k = 0; k < 4; k++) {
      blobs.push({
        x: sx + (blobRand() - 0.5) * 0.34,
        y: sy + (blobRand() - 0.5) * 0.28,
        sx: 0.05 + blobRand() * 0.09,
        sy: 0.04 + blobRand() * 0.06,
        w: w * (0.35 + blobRand() * 0.65),
      });
    }
  }

  for (let j = 0; j < height; j++) {
    const depth = (j / (height - 1)) * SCAN_FOV.depth;
    const y = -depth;
    for (let i = 0; i < width; i++) {
      const x = PROBE.x + ((i / (width - 1)) * 2 - 1) * SCAN_FOV.halfWidth;
      const n = fbm(x * 3.1, y * 3.1);
      let e = 0.3 + 0.12 * n;

      if (depth < 0.035) e = 1.25;
      else if (depth < 0.34) e = 0.52 + 0.3 * Math.max(0, Math.sin(y * 70 + n * 6));

      const fasciaDepth = 0.6 + 0.05 * Math.sin(x * 2.1) + 0.03 * n;
      e += 0.5 * Math.exp(-(((depth - fasciaDepth) / 0.014) ** 2));
      const fascia2 = 2.62 + 0.06 * Math.sin(x * 1.3 + 1);
      e += 0.35 * Math.exp(-(((depth - fascia2) / 0.02) ** 2));

      const dv = Math.abs(y - VESSEL.y);
      if (dv < VESSEL.r - 0.01) e = 0.025;
      else if (dv < VESSEL.r + 0.035) e = 1.15;

      const tf = tumorField(x, y);
      if (tf > 0) e = 0.12 + 0.12 * fbm(x * 6, y * 6);
      e += 0.28 * Math.exp(-((tf / 0.035) ** 2));

      // Posterior acoustic shadow under the (attenuating) tumor
      const below = y < TUMOR.y && Math.abs(x - TUMOR.x) < TUMOR.r * 0.75;
      if (below && tf < 0) e *= 0.45 + 0.55 * Math.min(1, Math.abs(x - TUMOR.x) / (TUMOR.r * 0.75)) ** 2;

      e *= Math.exp(-depth * 0.22);
      echo[j * width + i] = e;

      // Photoacoustic absorbers
      let skin = Math.exp(-(((depth - 0.018) / 0.014) ** 2)) * (0.55 + 0.3 * n);
      const wall = Math.exp(-(((dv - VESSEL.r) / 0.035) ** 2)) * (0.55 + 0.45 * vnoise(x * 5, 1));
      skin += wall * 0.75;
      paT[j * width + i] = skin;

      let p = 0;
      for (const b of blobs) p += b.w * Math.exp(-(((x - b.x) / b.sx) ** 2 + ((y - b.y) / b.sy) ** 2));
      p *= Math.min(1, Math.max(0, (tf + 0.06) / 0.14));
      p *= 0.55 + 0.6 * fbm(x * 9 + 2, y * 9 + 5);
      paP[j * width + i] = p;
    }
  }

  const bmode: ImageData[] = [];
  for (let f = 0; f < frames; f++) {
    const g1 = gaussianField(width, height, rand);
    const g2 = gaussianField(width, height, rand);
    const img = new ImageData(width, height);
    for (let k = 0; k < width * height; k++) {
      const s = Math.sqrt(g1[k] * g1[k] + g2[k] * g2[k]) / 2.4;
      const amp = echo[k] * s;
      let v = (20 * Math.log10(amp + 1e-3) + 40) / 40;
      v = Math.min(1, Math.max(0, v)) ** 1.15;
      const o = k * 4;
      img.data[o] = bone[0] * v;
      img.data[o + 1] = bone[1] * v;
      img.data[o + 2] = bone[2] * v;
      img.data[o + 3] = 255;
    }
    bmode.push(img);
  }

  const toOverlay = (src: Float32Array, lo: number, hi: number) => {
    const img = new ImageData(width, height);
    for (let k = 0; k < width * height; k++) {
      const v = src[k];
      const a = Math.min(1, Math.max(0, (v - lo) / (hi - lo)));
      const [r, g, b] = hot(0.25 + v * 0.8);
      const o = k * 4;
      img.data[o] = r;
      img.data[o + 1] = g;
      img.data[o + 2] = b;
      img.data[o + 3] = Math.round(a * a * (3 - 2 * a) * 235);
    }
    return img;
  };

  return {
    width,
    height,
    bmode,
    tissuePA: toOverlay(paT, 0.18, 0.7),
    particlePA: toOverlay(paP, 0.1, 0.75),
  };
}
