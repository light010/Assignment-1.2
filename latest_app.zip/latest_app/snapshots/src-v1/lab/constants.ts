import type { StageId } from "@/content/profile";

/*
  World layout, in scene units. The tissue block's top (the skin) sits at y = 0 and
  its front face (the cut we look into) is the plane z = FACE_Z. The scan image and
  the tissue shader both read from these numbers so the image matches the anatomy.
*/
export const BLOCK = { w: 6.4, h: 3.0, d: 2.6, r: 0.05 } as const;
export const FACE_Z = BLOCK.d / 2;

export const VESSEL = { y: -0.92, r: 0.3 } as const;
/** Leaky stretch of the vessel wall, directly above the tumor. */
export const LEAK = { x0: 0.35, x1: 1.6 } as const;
export const TUMOR = { x: 0.98, y: -2.02, r: 0.74 } as const;
export const PROBE = { x: 0.98, halfAperture: 0.9 } as const;

/** Photoacoustic sources: where particles cluster inside the tumor (x, y, weight). */
export const PA_SOURCES: ReadonlyArray<readonly [number, number, number]> = [
  [0.72, -1.72, 1.0],
  [1.3, -1.86, 0.85],
  [0.9, -2.3, 0.9],
  [1.46, -2.38, 0.6],
  [0.46, -2.14, 0.7],
  [1.02, -1.36, 0.55],
];

/** Speed of sound in the scene, units per second of timeline time. */
export const WAVE_SPEED = 1.85;

/* Timeline: one loop tells the whole story once. */
export const STAGE_WINDOWS: Record<StageId, readonly [number, number]> = {
  build: [0, 5.2],
  deliver: [5.2, 10.8],
  image: [10.8, 17.2],
};
export const LOOP_LENGTH = 17.2;
/** Offsets inside the image stage. */
export const IMAGE_CUES = { ultrasound: 0.35, laser: 2.35 } as const;
/** First paint starts just before the light pulse, so the opening moment is light turning into sound. */
export const INTRO_TIME = STAGE_WINDOWS.image[0] + IMAGE_CUES.laser - 1.7;

export function stageAt(loopTime: number): StageId {
  if (loopTime < STAGE_WINDOWS.deliver[0]) return "build";
  if (loopTime < STAGE_WINDOWS.image[0]) return "deliver";
  return "image";
}

/* Linear-space colours for materials (hex values mirror the CSS tokens). */
export const COLORS = {
  void: 0x060a0c,
  bone: 0xece7df,
  pulse: 0xffad62,
  echo: 0x8fe1f0,
  tissue: 0xef7b8d,
  core: 0xd8b67c,
} as const;
