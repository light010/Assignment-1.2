import * as THREE from "three";
import { EffectComposer } from "three/addons/postprocessing/EffectComposer.js";
import { RenderPass } from "three/addons/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/addons/postprocessing/UnrealBloomPass.js";
import { OutputPass } from "three/addons/postprocessing/OutputPass.js";
import { ShaderPass } from "three/addons/postprocessing/ShaderPass.js";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import type { StageId } from "@/content/profile";
import { labBus, type Anchor } from "./bus";
import {
  COLORS,
  FACE_Z,
  IMAGE_CUES,
  INTRO_TIME,
  LOOP_LENGTH,
  PA_SOURCES,
  PROBE,
  STAGE_WINDOWS,
  TUMOR,
  VESSEL,
  WAVE_SPEED,
  stageAt,
} from "./constants";
import { createTissue } from "./objects/tissue";
import { createFlow } from "./objects/flow";
import { createProbe } from "./objects/probe";
import { createNanoparticle } from "./objects/nanoparticle";
import { createStage } from "./objects/stage";

export interface EngineOptions {
  reducedMotion: boolean;
  lowPower: boolean;
}

export interface Framing {
  /** Where the subject's centre should land, as a fraction of the canvas (0..1, CSS axes). */
  focusX: number;
  focusY: number;
  /** Fraction of the canvas the subject may occupy. */
  usableW: number;
  usableH: number;
}

/** Scene extent the camera must keep in frame (world units). */
const EXTENT = { w: 9.9, h: 7.0 };
const LOUPE_POS = new THREE.Vector3(4.05, 1.72, 1.5);
/** Seconds the light pulse takes to run down the fibre before the flash. */
const FIBER_TRAVEL = 0.62;
/** Nearest photoacoustic source to the probe: when its wave lands, the probe "hears" it. */
const ARRIVAL = Math.min(...PA_SOURCES.map(([, y]) => -y)) / WAVE_SPEED;

const finishShader = {
  uniforms: {
    tDiffuse: { value: null },
    uRes: { value: new THREE.Vector2(1, 1) },
    uCenter: { value: new THREE.Vector2(0, 0) },
    uRadius: { value: -1000 },
    uAmp: { value: 0 },
    uTime: { value: 0 },
    uVignette: { value: 0.55 },
    uEcho: { value: new THREE.Color(COLORS.echo) },
  },
  vertexShader: /* glsl */ `
    varying vec2 vUv;
    void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
  `,
  fragmentShader: /* glsl */ `
    uniform sampler2D tDiffuse;
    uniform vec2 uRes, uCenter;
    uniform float uRadius, uAmp, uTime, uVignette;
    uniform vec3 uEcho;
    varying vec2 vUv;
    void main() {
      vec2 px = vUv * uRes;
      vec2 d = px - uCenter;
      float r = length(d);
      float ph = (r - uRadius) / (22.0 * uRes.y / 900.0);
      float nw = -ph * exp(-0.5 * ph * ph);
      vec2 dir = r > 0.001 ? d / r : vec2(0.0);
      vec2 offs = dir * nw * uAmp * 6.0 / uRes;
      vec3 col;
      col.r = texture2D(tDiffuse, vUv + offs * 1.35).r;
      col.g = texture2D(tDiffuse, vUv + offs).g;
      col.b = texture2D(tDiffuse, vUv + offs * 0.7).b;
      col += uEcho * max(nw, 0.0) * uAmp * 0.07;
      vec2 q = (vUv - vec2(0.58, 0.5)) * vec2(1.0, 1.15);
      col *= 1.0 - uVignette * smoothstep(0.1, 0.62, length(q));
      float g = fract(sin(dot(px + fract(uTime) * 91.0, vec2(12.9898, 78.233))) * 43758.5453) - 0.5;
      col += g * 0.016;
      gl_FragColor = vec4(col, 1.0);
    }
  `,
};

export class LabEngine {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera: THREE.PerspectiveCamera;
  private composer: EffectComposer;
  private bloom: UnrealBloomPass;
  private finish: ShaderPass;
  private tissue: ReturnType<typeof createTissue>;
  private flow: ReturnType<typeof createFlow>;
  private probe: ReturnType<typeof createProbe>;
  private particle: ReturnType<typeof createNanoparticle>;
  private stage: ReturnType<typeof createStage>;
  private cursorLight: THREE.PointLight;
  private tumorLight: THREE.PointLight;

  private opts: EngineOptions;
  private size = { w: 1, h: 1, dpr: 1 };
  private framing: Framing = { focusX: 0.5, focusY: 0.5, usableW: 0.9, usableH: 0.9 };
  private baseDist = 16;

  private time = INTRO_TIME;
  private prevLoop = INTRO_TIME;
  private usT = -100;
  private laserT = -100;
  private paT = -100;
  private waveWall = -1e9;
  private waveEmitted = true;
  private currentStage: StageId = "image";
  private playing = true;
  private oneShotUntil = -1;
  private active = true;
  private raf = 0;
  private lastWall = 0;
  private disposed = false;

  private pointer = new THREE.Vector2();
  private pointerTarget = new THREE.Vector2();
  private scroll = 0;
  private scrollTarget = 0;
  private focusBias = new THREE.Vector3();
  private focusBiasTarget = new THREE.Vector3();

  /** Frames still owed after a change while paused (resize, seek, first paint). */
  private pendingFrames = 4;
  private frameTimes: number[] = [];
  private qualityStep = 0;

  private anchors: Record<string, Anchor> = {};
  private anchorWorld: Record<string, THREE.Vector3> = {
    probe: new THREE.Vector3(),
    light: new THREE.Vector3(),
    vessel: new THREE.Vector3(-1.9, VESSEL.y + VESSEL.r + 0.02, FACE_Z),
    tumor: new THREE.Vector3(TUMOR.x - 0.62, TUMOR.y - 0.5, FACE_Z),
    core: new THREE.Vector3(),
    matrix: new THREE.Vector3(),
    coat: new THREE.Vector3(),
    loupe: new THREE.Vector3(),
    loupeEdge: new THREE.Vector3(),
    zoom: new THREE.Vector3(2.25, VESSEL.y, FACE_Z - 0.08),
    array: new THREE.Vector3(PROBE.x, 0.3, FACE_Z + 0.05),
  };
  private v3 = new THREE.Vector3();

  constructor(canvas: HTMLCanvasElement, opts: EngineOptions) {
    this.opts = opts;
    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: false,
      alpha: false,
      powerPreference: "high-performance",
      stencil: false,
    });
    renderer.setClearColor(COLORS.void, 1);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    renderer.localClippingEnabled = true;
    this.renderer = renderer;

    this.camera = new THREE.PerspectiveCamera(26, 1, 0.5, 80);

    const pmrem = new THREE.PMREMGenerator(renderer);
    const room = new RoomEnvironment();
    this.scene.environment = pmrem.fromScene(room, 0.04).texture;
    this.scene.environmentIntensity = 0.32;
    room.traverse((o) => {
      const mesh = o as THREE.Mesh;
      mesh.geometry?.dispose?.();
    });
    pmrem.dispose();
    this.scene.background = new THREE.Color(COLORS.void);
    this.scene.fog = new THREE.Fog(COLORS.void, 18, 42);

    // Lights: a warm key with soft shadows, a cool rim, and a cursor-following fill
    const key = new THREE.SpotLight(0xfff0de, 520, 0, 0.42, 0.85, 2);
    key.position.set(-5.5, 11, 8.5);
    key.target.position.set(0.8, -1.6, 0.4);
    key.castShadow = true;
    key.shadow.mapSize.setScalar(opts.lowPower ? 1024 : 2048);
    key.shadow.bias = -0.0004;
    key.shadow.normalBias = 0.02;
    key.shadow.radius = 5;
    key.shadow.camera.near = 6;
    key.shadow.camera.far = 30;
    this.scene.add(key, key.target);

    const rim = new THREE.SpotLight(0x9fe6ff, 340, 0, 0.5, 0.9, 2);
    rim.position.set(9, 6.5, -7);
    rim.target.position.set(0.5, -0.5, 0);
    this.scene.add(rim, rim.target);

    const front = new THREE.DirectionalLight(0xffe7d6, 0.35);
    front.position.set(2, 1.5, 10);
    this.scene.add(front);

    this.scene.add(new THREE.HemisphereLight(0x9cc3cf, 0x1c0f0d, 0.35));

    this.cursorLight = new THREE.PointLight(0xffd2ad, 6, 5.5, 2);
    this.cursorLight.position.set(0.8, -1, FACE_Z + 1.2);
    this.scene.add(this.cursorLight);

    const vesselFill = new THREE.PointLight(0xff5a48, 2.4, 3.4, 2);
    vesselFill.position.set(0.4, VESSEL.y + 0.05, FACE_Z + 0.7);
    this.scene.add(vesselFill);

    this.tumorLight = new THREE.PointLight(0xff8a3c, 0, 3.2, 2);
    this.tumorLight.position.set(TUMOR.x, TUMOR.y + 0.1, FACE_Z + 0.45);
    this.scene.add(this.tumorLight);

    // Objects
    this.stage = createStage({ lowPower: opts.lowPower });
    this.tissue = createTissue();
    this.flow = createFlow({ lowPower: opts.lowPower });
    this.probe = createProbe();
    this.particle = createNanoparticle({ lowPower: opts.lowPower });
    this.particle.root.position.copy(LOUPE_POS);
    this.scene.add(this.stage.group, this.tissue.group, this.flow.group, this.probe.group, this.particle.root);
    this.anchorWorld.probe.copy(this.probe.anchors.probe);
    this.anchorWorld.light.copy(this.probe.anchors.light);

    // Post: HDR render (MSAA) -> bloom -> tone map -> finish (shock ripple, vignette, grain)
    const target = new THREE.WebGLRenderTarget(2, 2, {
      type: THREE.HalfFloatType,
      samples: opts.lowPower ? 0 : 4,
    });
    this.composer = new EffectComposer(renderer, target);
    this.composer.addPass(new RenderPass(this.scene, this.camera));
    this.bloom = new UnrealBloomPass(new THREE.Vector2(256, 256), 0.5, 0.5, 1.08);
    this.composer.addPass(this.bloom);
    this.composer.addPass(new OutputPass());
    this.finish = new ShaderPass(finishShader);
    this.composer.addPass(this.finish);

    if (opts.reducedMotion) {
      this.playing = false;
      this.time = STAGE_WINDOWS.image[0] + IMAGE_CUES.laser + 0.62;
      this.prevLoop = this.time;
      this.laserT = STAGE_WINDOWS.image[0] + IMAGE_CUES.laser;
      this.paT = this.laserT + 0.05;
    }

    this.lastWall = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  /* ---------- public API ---------- */

  setSize(w: number, h: number, dpr: number) {
    this.size = { w: Math.max(1, w), h: Math.max(1, h), dpr };
    this.applySize();
    this.pendingFrames = 2;
  }

  setFraming(framing: Framing) {
    this.framing = framing;
    this.applySize();
    this.pendingFrames = 2;
  }

  setPointer(nx: number, ny: number) {
    if (this.opts.reducedMotion) return;
    this.pointerTarget.set(THREE.MathUtils.clamp(nx, -1, 1), THREE.MathUtils.clamp(ny, -1, 1));
  }

  setScroll(p: number) {
    this.scrollTarget = this.opts.reducedMotion ? 0 : THREE.MathUtils.clamp(p, 0, 1);
  }

  setActive(active: boolean) {
    if (active === this.active) return;
    this.active = active;
    if (active && !this.disposed) {
      this.lastWall = performance.now();
      cancelAnimationFrame(this.raf);
      this.raf = requestAnimationFrame(this.loop);
    }
  }

  setPlaying(playing: boolean) {
    this.playing = playing;
    this.pendingFrames = 1;
    labBus.emit("playing", { playing });
  }

  isPlaying() {
    return this.playing;
  }

  /** Jump the story to a stage. */
  goTo(stage: StageId) {
    const loopBase = Math.floor(this.time / LOOP_LENGTH) * LOOP_LENGTH;
    this.time = loopBase + STAGE_WINDOWS[stage][0] + 0.001;
    this.prevLoop = this.time - 0.0005;
    if (stage === "build") {
      this.laserT = this.paT = this.usT = -100;
    }
    if (!this.playing) this.oneShotUntil = this.time + (stage === "image" ? 4.2 : 2.2);
    this.pendingFrames = 2;
    this.setStage(stage, true);
  }

  /** Fire a light pulse now (seeks to the pulse inside the image stage). */
  pulse() {
    const loopBase = Math.floor(this.time / LOOP_LENGTH) * LOOP_LENGTH;
    this.time = loopBase + STAGE_WINDOWS.image[0] + IMAGE_CUES.laser - FIBER_TRAVEL;
    this.prevLoop = this.time - 0.001;
    if (!this.playing) this.oneShotUntil = this.time + 3.8;
    this.setStage("image", true);
  }

  /** Dev/test helper: freeze the story at a given second of the loop, with cues applied. */
  scrub(loopTime: number) {
    const loopBase = Math.floor(this.time / LOOP_LENGTH) * LOOP_LENGTH;
    const t = loopBase + loopTime;
    const img = STAGE_WINDOWS.image[0];
    this.time = t;
    this.prevLoop = t;
    this.usT = loopTime >= img + IMAGE_CUES.ultrasound ? loopBase + img + IMAGE_CUES.ultrasound : -100;
    this.laserT = loopTime >= img + IMAGE_CUES.laser ? loopBase + img + IMAGE_CUES.laser : -100;
    this.paT = this.laserT > -100 ? this.laserT + 0.05 : -100;
    this.waveEmitted = true;
    this.playing = false;
    this.oneShotUntil = -1;
    this.pendingFrames = 3;
    this.setStage(stageAt(loopTime), true);
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.scene.traverse((o) => {
      const mesh = o as THREE.Mesh;
      if (mesh.geometry) mesh.geometry.dispose();
      const mat = mesh.material as THREE.Material | THREE.Material[] | undefined;
      if (Array.isArray(mat)) mat.forEach((m) => m.dispose());
      else mat?.dispose();
    });
    this.scene.environment?.dispose();
    this.composer.dispose();
    this.renderer.dispose();
  }

  /* ---------- internals ---------- */

  private applySize() {
    const { w, h, dpr } = this.size;
    const ratio = Math.max(0.75, dpr - this.qualityStep * 0.25);
    this.renderer.setPixelRatio(ratio);
    this.renderer.setSize(w, h, false);
    this.composer.setPixelRatio(ratio);
    this.composer.setSize(w, h);
    this.bloom.resolution.set(w * ratio * 0.5, h * ratio * 0.5);
    (this.finish.uniforms.uRes.value as THREE.Vector2).set(w * ratio, h * ratio);
    this.flow.dropMaterial.uniforms.uScale.value = ratio;
    this.stage.dustUniforms.uScale.value = ratio;

    const aspect = w / h;
    const f = this.framing;
    const tanV = Math.tan(THREE.MathUtils.degToRad(this.camera.fov / 2));
    const needV = EXTENT.h / 2 / (tanV * f.usableH);
    const needH = EXTENT.w / 2 / (tanV * aspect * f.usableW);
    this.baseDist = Math.max(needV, needH);
    const fog = this.scene.fog as THREE.Fog;
    fog.near = this.baseDist + 5;
    fog.far = this.baseDist + 30;
    this.camera.aspect = aspect;
    this.camera.setViewOffset(w, h, -(f.focusX - 0.5) * w, -(f.focusY - 0.5) * h, w, h);
    this.camera.updateProjectionMatrix();
  }

  private setStage(stage: StageId, user: boolean) {
    if (stage === this.currentStage && !user) return;
    this.currentStage = stage;
    labBus.emit("stage", { stage, user });
  }

  private crossed(cue: number, prev: number, now: number) {
    if (now >= prev) return prev < cue && now >= cue;
    return prev < cue || now >= cue;
  }

  private loop = (now: number) => {
    if (this.disposed) return;
    if (!this.active) return;
    this.raf = requestAnimationFrame(this.loop);

    const wallDt = Math.min(0.05, (now - this.lastWall) / 1000);
    this.lastWall = now;
    this.trackQuality(wallDt);

    const advancing = this.playing || this.time < this.oneShotUntil;
    const dt = advancing ? wallDt : 0;
    this.time += dt;

    const loopT = ((this.time % LOOP_LENGTH) + LOOP_LENGTH) % LOOP_LENGTH;
    const prev = ((this.prevLoop % LOOP_LENGTH) + LOOP_LENGTH) % LOOP_LENGTH;
    this.prevLoop = this.time;

    // Timeline cues
    const imgStart = STAGE_WINDOWS.image[0];
    if (dt > 0 && this.crossed(imgStart + IMAGE_CUES.ultrasound, prev, loopT)) {
      this.usT = this.time;
      labBus.emit("ultrasound", { startedAt: now });
    }
    if (dt > 0 && this.crossed(imgStart + IMAGE_CUES.laser, prev, loopT)) {
      this.laserT = this.time;
      this.paT = this.time + 0.05;
      this.waveEmitted = false;
      labBus.emit("laser", { startedAt: now });
    }
    if (!this.waveEmitted && this.time >= this.paT + ARRIVAL) {
      this.waveEmitted = true;
      this.emitWave(now);
    }
    if (dt > 0 && this.crossed(0.0001, prev, loopT)) {
      this.laserT = this.paT = -100;
    }

    const stage = stageAt(loopT);
    if (stage !== this.currentStage) this.setStage(stage, false);

    // Smooth inputs (frame-rate independent)
    const k = 1 - Math.exp(-wallDt * 3.2);
    this.pointer.lerp(this.pointerTarget, k);
    this.scroll += (this.scrollTarget - this.scroll) * (1 - Math.exp(-wallDt * 8));
    this.focusBiasTarget.set(
      stage === "build" ? 0.45 : stage === "image" ? 0.1 : -0.12,
      stage === "build" ? 0.22 : stage === "deliver" ? -0.18 : 0.02,
      0,
    );
    if (this.opts.reducedMotion) this.focusBiasTarget.set(0, 0, 0);
    this.focusBias.lerp(this.focusBiasTarget, 1 - Math.exp(-wallDt * 1.1));

    // Paused and nothing settling: skip the frame entirely (saves the GPU and the battery).
    const settling =
      this.pointer.distanceToSquared(this.pointerTarget) > 1e-7 ||
      Math.abs(this.scrollTarget - this.scroll) > 1e-4 ||
      this.focusBias.distanceToSquared(this.focusBiasTarget) > 1e-6;
    const rippling = !this.opts.reducedMotion && now - this.waveWall < 2600;
    if (!advancing && !settling && !rippling && this.pendingFrames <= 0) return;
    this.pendingFrames = Math.max(0, this.pendingFrames - 1);

    this.updateCamera();

    // Scene state
    const lt = this.time - this.laserT;
    const heat = lt > 0 ? Math.exp(-lt * 3.2) : 0;
    const buildT = stage === "build" ? loopT - STAGE_WINDOWS.build[0] : null;
    const flowRate = stage === "deliver" ? 1.25 : 0.85;
    const accumulation = this.flow.update(this.time, loopT, dt, heat, flowRate);

    const u = this.tissue.uniforms;
    u.uTime.value = this.time;
    u.uAccum.value = accumulation;
    u.uLaserT.value = this.laserT;
    u.uUsT.value = this.usT;
    u.uPAT.value = this.paT;
    u.uDim.value = THREE.MathUtils.lerp(u.uDim.value, stage === "build" ? 0.78 : 1, 1 - Math.exp(-wallDt * 2));

    const toLaser = imgStart + IMAGE_CUES.laser - loopT;
    // Eased so the pulse lingers on the stretch of fibre that's in frame (near the probe).
    const fiberU = toLaser >= 0 && toLaser < FIBER_TRAVEL ? Math.pow(toLaser / FIBER_TRAVEL, 1.8) : -1;
    const flash = this.probe.update(this.time, this.laserT, this.usT, this.paT, fiberU);
    this.particle.update(this.time, buildT, heat, this.paT, this.camera);
    this.stage.update(this.time, flash * 0.6);
    this.tumorLight.intensity = heat * accumulation * 5;

    // Cursor light rides the pointer across the cut face
    this.cursorLight.position.set(
      0.8 + this.pointer.x * 4.2,
      -1.2 + this.pointer.y * 1.8,
      FACE_Z + 1.25,
    );

    this.updateFinish(now);
    this.composer.render(wallDt);

    // HUD feeds
    const win = STAGE_WINDOWS[stage];
    const signalT = this.time - (this.paT + ARRIVAL);
    const signal = signalT > 0 ? Math.exp(-signalT * 1.6) : 0;
    labBus.emit("frame", {
      stage,
      stageProgress: (loopT - win[0]) / (win[1] - win[0]),
      accumulation,
      signal,
      time: this.time,
    });
    this.emitAnchors();
  };

  private updateCamera() {
    const drift = this.opts.reducedMotion ? 0 : Math.sin(this.time * 0.12) * 0.025;
    const az = 0.2 + this.pointer.x * 0.06 + drift;
    const el = 0.2 + this.pointer.y * -0.035 + this.scroll * 0.12;
    const dist = this.baseDist * (1 + this.scroll * 0.14) * 0.985;
    const target = this.v3.set(0.95, -0.35, 0.4).add(this.focusBias);
    this.camera.position.set(
      target.x + Math.sin(az) * Math.cos(el) * dist,
      target.y + Math.sin(el) * dist,
      target.z + Math.cos(az) * Math.cos(el) * dist,
    );
    this.camera.lookAt(target);
  }

  private emitWave(now: number) {
    const origin = this.project(this.anchorWorld.array);
    const pxPerUnit = this.size.h / (2 * this.baseDist * Math.tan(THREE.MathUtils.degToRad(this.camera.fov / 2)));
    labBus.emit("wave", {
      x: origin.x,
      y: origin.y,
      startedAt: now,
      speed: Math.max(520, pxPerUnit * WAVE_SPEED * 4.2),
    });
    this.waveWall = now;
    this.waveOrigin.set(origin.x, origin.y);
    this.waveSpeed = Math.max(520, pxPerUnit * WAVE_SPEED * 4.2);
  }

  private waveOrigin = new THREE.Vector2();
  private waveSpeed = 600;

  private updateFinish(now: number) {
    const u = this.finish.uniforms;
    u.uTime.value = now / 1000;
    const ratio = this.renderer.getPixelRatio();
    const t = (now - this.waveWall) / 1000;
    if (t >= 0 && t < 2.4 && !this.opts.reducedMotion) {
      (u.uCenter.value as THREE.Vector2).set(this.waveOrigin.x * ratio, (this.size.h - this.waveOrigin.y) * ratio);
      u.uRadius.value = t * this.waveSpeed * ratio;
      u.uAmp.value = (1 - t / 2.4) ** 1.5;
    } else {
      u.uAmp.value = 0;
    }
  }

  private project(world: THREE.Vector3): Anchor {
    const p = this.v3.copy(world).project(this.camera);
    return {
      x: (p.x * 0.5 + 0.5) * this.size.w,
      y: (-p.y * 0.5 + 0.5) * this.size.h,
      visible: p.z < 1 && p.x > -1.2 && p.x < 1.2 && p.y > -1.2 && p.y < 1.2,
    };
  }

  private emitAnchors() {
    const w = this.anchorWorld;
    this.particle.anchorWorld("core", w.core);
    this.particle.anchorWorld("matrix", w.matrix);
    this.particle.anchorWorld("coat", w.coat);
    w.loupe.copy(LOUPE_POS);
    const right = this.v3.setFromMatrixColumn(this.camera.matrixWorld, 0).multiplyScalar(this.particle.radius);
    w.loupeEdge.copy(LOUPE_POS).add(right);
    for (const name in w) {
      const a = this.project(w[name]);
      const slot = (this.anchors[name] ??= { x: 0, y: 0, visible: false });
      slot.x = a.x;
      slot.y = a.y;
      slot.visible = a.visible;
    }
    labBus.emit("anchors", this.anchors);
  }

  private trackQuality(dt: number) {
    if (dt <= 0) return;
    this.frameTimes.push(dt);
    if (this.frameTimes.length < 90) return;
    const avg = this.frameTimes.reduce((a, b) => a + b, 0) / this.frameTimes.length;
    this.frameTimes.length = 0;
    if (avg > 1 / 52 && this.qualityStep < 3 && this.size.dpr - this.qualityStep * 0.25 > 1) {
      this.qualityStep++;
      this.applySize();
    }
  }
}

