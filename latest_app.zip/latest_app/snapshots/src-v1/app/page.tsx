import { Hero } from "@/components/hero/hero";

export default function Home() {
  return (
    <main>
      <Hero />
      {/* Stand-ins for the rest of the site, so the hero's scroll behaviour can be judged in place. */}
      {[
        { id: "research", title: "Research" },
        { id: "publications", title: "Publications" },
        { id: "contact", title: "Contact" },
      ].map((s) => (
        <section key={s.id} id={s.id} className="mx-auto min-h-[60vh] max-w-[90rem] border-t border-hairline px-4 py-24 sm:px-6 lg:px-10">
          <h2 className="font-display text-4xl text-bone">{s.title}</h2>
          <p className="mt-4 max-w-[48ch] text-bone-faint">This section of your site continues here.</p>
        </section>
      ))}
    </main>
  );
}
