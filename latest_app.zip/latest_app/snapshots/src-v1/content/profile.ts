// Everything a visitor reads in the hero lives here, so copy edits never touch components.

export const profile = {
  name: "Madhavi Tripathi",
  shortRole: "bioengineer",
  headline: ["Built to deliver.", "Seen in sound."],
  lede: "I’m a bioengineer at Johns Hopkins. I build nanoparticles that carry drugs into tumors, then follow them through the body with photoacoustic and ultrasound imaging.",
  nav: [
    { label: "Research", href: "#research" },
    { label: "Publications", href: "#publications" },
    { label: "Contact", href: "#contact" },
  ],
} as const;

export type StageId = "build" | "deliver" | "image";

export const stages: ReadonlyArray<{
  id: StageId;
  label: string;
  skill: string;
  caption: string;
}> = [
  {
    id: "build",
    label: "Build",
    skill: "Nanoparticle design",
    caption:
      "A light-absorbing core, a drug-loaded shell, and a cell-membrane coat that helps the particle slip past the immune system.",
  },
  {
    id: "deliver",
    label: "Deliver",
    skill: "Targeted drug delivery",
    caption:
      "Carried by the bloodstream, particles squeeze through leaky tumor vessels, collect in the tumor, and release their drug there.",
  },
  {
    id: "image",
    label: "Image",
    skill: "Photoacoustic and ultrasound imaging",
    caption:
      "A short light pulse makes the particles swell and emit ultrasound. The probe listens and maps exactly where they went.",
  },
];
