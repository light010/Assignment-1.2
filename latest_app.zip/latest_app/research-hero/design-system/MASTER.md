# Design contract: the site and its lab

The hero's contract comes first, as written for the lab; the site-wide contract that extends it to Research,
Publications, About, and Contact follows under "The whole site". Details and rationale: `docs/site-plan/C-design-system.md`.

**Thesis.** A visitor should understand in one look that this researcher builds nanoparticles for drug
delivery and makes photoacoustic and ultrasound images better, then be able to try each skill in an
explorable lab where every control visibly changes the physics.

## Commitments

1. **The headline states the profile literally.** Two sentences, one per half of the work. Clever lines
   that need the lede to decode them are out.
2. **The scene is the evidence.** Every control changes the scene, the camera, a measured readout, and
   the caption, the way the lens lab's focus ring moves the plane of focus.
3. **Show the skill, not the tool.** Nanoparticles are built in order (core, gel and drug, membrane coat)
   with the size trade-off shown; imaging shows beamforming (delay-and-sum vs. short-lag spatial
   coherence), gCNR against a threshold, raw echoes, oxygenation mapping, and skin-tone clutter.
4. **Truthful by construction.** Readouts are measured from the rendered images, every picture is
   labeled "Simulated", and nothing names a job title, number, or result the researcher hasn't stated.

## Voice

- First person for the researcher's own work ("I engineer…"), present tense, active voice.
- Plain words first, then the term: show the effect ("clutter fills it with haze"), then name the method.
- Captions say what is on screen, why it happens, and, where something is measured, end with the value
  ("gCNR 0.93: reads as a cyst."), as the lens lab does ("Sharp zone: 1.5 cm.").
- Each element has one job: tab = where to go, control = what to change, readout = what was measured,
  caption = what you see and why, legend = how to read colors.
- American spelling, serial comma, sentence case. "and" in prose, never "+". Contractions are fine.
- No hype words, no exclamation marks, no emoji. One em dash at most per paragraph.
- Science over flourish: when a plainer word would be less accurate, accuracy wins (a coherence image
  makes a cyst "go dark", not "turn black"; coherence "cuts most clutter", it doesn't make it "drop away";
  lost light stays lost). The science and copy reviews that set these rules are summarized in the README.
- Keep hyphenated terms whole: captions join "B-mode" and "delay-and-sum" with word joiners (U+2060)
  so they never break at a hyphen.

## Glossary (one name per thing)

| Use | Not | Notes |
| --- | --- | --- |
| nanoparticle, particle | nanocarrier, NP | "nanomaterials" only in the headline |
| light-absorbing core, cores | crystal, absorber | "crystal cores" once, in the Core caption |
| capping layer | shell, coating | |
| heat-responsive gel, gel carrier | thermoresponsive, hydrogel | "gel carrier" is the whole gel particle in Delivery |
| membrane coat (red blood cell membrane) | cell-membrane coat, cloak | |
| tumor rim, tumor center | tumor core | "core" belongs to the particle |
| pulsed / continuous light | laser, sustained, steady | matches the Light control |
| emit sound (a photoacoustic signal) | ring, ringing | "ringing" is the skin's reverberation clutter, an artifact |
| heat, heated, heat-responsive | warm, warmed, opens | a heated gel shrinks and squeezes the drug out; it never "opens" |
| taken apart | exploded | the Design view control and its caption |
| oxygenated / deoxygenated blood | oxygen-rich, oxygen-poor | green / red, per the researcher's convention |
| clutter | noise, haze (haze only to describe how clutter looks) | |
| delay-and-sum; B-mode image | standard beamformer | B-mode is the image delay-and-sum makes |
| coherence beamforming; short-lag spatial coherence | SLSC alone | name it in full where the raw echoes show it |
| gCNR, labeled "Contrast (gCNR)" | CNR, contrast ratio | the 0.76 cutoff applies only to coherence (SLSC) images, as in the study; B-mode gets the number, never a verdict |
| reads as a cyst / a solid mass | fluid / solid | verdicts use the lesion names, matching "Truth" |
| raw echoes, array elements, transducer array | channel data, RF | |

## Length budgets

| Element | Budget | Why |
| --- | --- | --- |
| Headline | one sentence per line, ≤ 28 characters each | four balanced lines on large screens, two in a chapter |
| Lede | ≤ 160 characters | three lines at the lede measure |
| Caption (per state) | ≤ 180 characters | three lines on desktop, so buttons below never jump |
| Tab hint | ≤ 20 characters | one line in a quarter-width tab |
| Control option | ≤ 14 characters | fits a three-way segment on a phone |
| Readout value | ≤ 18 characters | may wrap to two lines on a phone |
| 3D label | ≤ 24 characters | labels flip sides at the scene edge, but long ones crowd |

## Tokens (summary; the source of truth is `src/app/globals.css`)

- Color: void `#060a0c`, bone `#ece7df` (text, ultrasound grays), bone-muted `#aaa59d` (secondary text,
  7.7:1 on panels), pulse `#ffad62` (light and heat), echo `#8fe1f0` (sound), oxygenated `#4fdc8a`,
  deoxygenated `#ff4a4a`. Readout tones: good `#8fe8b0`, warn = pulse.
- Type: Newsreader (display, optical size 72) for the headline and name; Mona Sans for text, with a
  semi-condensed tabular cut for readouts and labels. Hero `clamp(2.75rem, 4.1vw + 1rem, 5.75rem)`,
  compact `clamp(2rem, 3.4vw, 3rem)`, lede `clamp(1.0625rem, 0.28vw + 0.96rem, 1.25rem)`, caption
  `0.9375rem`, micro `0.75rem`.
- Motion: springs (260/20) for entrances, 0.45 s ease-out for folds; reduced motion keeps fades, drops
  movement, and opens the scene paused.

## Anti-patterns for this hero

- A slogan headline that omits half the work (the first draft, "Built to deliver. Seen in sound.", never
  said "light").
- Sub-labels that repeat their label ("Ultrasound / Ultrasound imaging").
- Numbers that aren't measured from the scene, or a title the researcher hasn't used.
- Legends that don't explain the colors on screen.

## The whole site

**Thesis.** Below the lab, the site reads like a well-made paper: plain prose, a reference list you can act
on, and every picture saying where it came from. Committees, collaborators, and curious visitors should see
the two linked skills and be able to check them.

### Commitments

1. **The console grid, at page scale.** Every section repeats the hero console's label column: a label track
   (columns 1–3) for names, dates, years, and lab links; a reading track (at most 34em) for sentences; an
   aside track for evidence. One left axis shared with the hero headline; nothing is centered.
2. **Newsreader speaks, Mona Sans measures.** Sentences are Newsreader: headings, prose, paper titles,
   summaries, the email address. Things you operate or scan are Mona Sans: nav, controls, authors, meta.
   Years use Newsreader's figures (Mona Sans's tabular zero reads as θ).
3. **Hue is data.** Chrome is bone on void, and bone carries emphasis. Pulse, echo, oxygenated, and
   deoxygenated appear only when they encode light or heat, sound, or blood oxygen, and always with a shape
   and a word (● light for delivery, ●○ light and sound for photoacoustics, ○ sound alone for ultrasound).
   The same holds in the paper theme: each hue keeps its meaning in a darker ink (see "Two themes").
4. **Every picture says where it came from.** Lab renders say "Simulated" and never sit inside a paper
   block; paper figures, if added, sit on white plates labeled "From paper" with credit. No stock, no
   placeholders, no silhouettes.
5. **Controls change something visible, and motion comes from the lab.** Light first, then what it sets off: a
   control answers at once, and what it changed follows as a short glide, roll, sweep, or rise; each block below the
   lab plays one moment of its own when first scrolled to (see "Motion"). Nothing loops.

### Two themes: the lab and the paper

The owner asked for a light theme with a toggle (28 September 2026), an exception to this file's
anti-pattern, recorded here with its rules like the carousel's. **Dark is the lab** (the identity, and
the default: no stored choice and a dark system, no JavaScript, every test baseline, every poster);
**light is the paper** — the record printed, grown from the print palette but keeping the page's
layering: toned paper `#f4f2ee`, white plates (`--color-ink`), toned insets (`--color-panel`), cool ink
text. Every light value is computed against WCAG 2.2 before it ships (text ≥ 4.5:1 on paper and plates;
controls and focus ≥ 3:1 — print's 45% border alpha fails on screen and becomes 50%).

- **Instruments keep their screens.** The hero (`#top`, live or static) is pinned to the lab's palette in
  both themes — the scene, posters, console, callouts, and instrument panel are lit for a dark room — and
  the dark band casts a shadow on the paper below it, the seam where the lab ends. The Scholar chart's
  black well, the Recognition and Research renders, and the scan line (always crossing a dark render)
  stay dark everywhere. Charts drawn on the page itself (ranked bars, "Cited by" stems, topic glyphs)
  follow the theme, as printed figures.
- **The toggle** sits in the hero header, and in the section bar from `sm` up (the same control, one document
  state; under WCAG text spacing four links plus a toggle cannot hold one bar row on phones, so there the hero
  header's copy serves), after
  the skip link, `data-needs-js` (without JavaScript there is no choice to make, and the page is dark).
  Its icon is the state, read from `html[data-theme]` in CSS: a tilted crescent in the dark, the bite
  sliding off and rays reaching out in the light, on the site's spring. `aria-pressed` carries "Light
  theme" on or off.
- **First paint is the right theme.** The head's inline script resolves stored choice, else system
  preference; the choice persists in localStorage (guarded; storage may be absent), and the system is
  followed live only while no choice is stored. `theme-color` and `color-scheme` follow the theme.
- **The swap is the moment.** Everything below the lab crosses together in 350 ms (`--ease-in-out`) while
  the lab holds still; the toggle's own morph springs through it. Under reduced motion the change is a cut.
- Print stays print: it wins over the light theme by matching specificity later in the stylesheet.

### Layout

| Width | Columns | Gutter | Margin | Tracks |
| --- | --- | --- | --- | --- |
| < 48rem | 4 | 16 | 16 (24 from 40rem) | One column; the label track becomes a label row |
| 48–64rem | 8 | 20 | 24 | Label 1–3; reading 4–8 |
| 64–80rem | 12 | 24 | 40 | Label 1–3; reading 4–10; aside below |
| ≥ 80rem | 12 | 24 | 40 | Label 1–3; reading 4–8; aside 9–12 |

Container `max-w-[90rem]`. Sections sit `--space-section` apart (72→128 px), blocks `--space-block`
(48→80 px). Tracks are combined `col-[start/span_n]` utilities in `src/components/site/layout.tsx`
(`col-span-*` alone resets the start column). Reading measure: 60–80 characters on desktop, 45–55 on phones.

### Type scale below the hero (tokens in `globals.css`)

| Token | Role |
| --- | --- |
| `display` | The 404 heading |
| `h2` | Section headings |
| `deck` | One sentence under a section heading |
| `h3` | Theme titles, the bridge line, group headings |
| `title` | Paper titles, positions, recognition |
| `body` | Bios and theme bodies (serif, 18–20 px, line height 1.62) |
| `summary` | Paper summaries |
| `small`, `label` | Authors, meta, dates, labels (Mona Sans) |
| `email` | The email address in Contact |

### States

| State | Rule |
| --- | --- |
| Hover | Only with a hover-capable pointer, 150 to 500 ms. Text goes to bone, outlines to `line-strong`; a label link's echo rule runs across it from the left; a paper row lifts a shade; Scholar's tiles and the Research cards light up under the pointer and brighten their edge; a diagram replays its physics; chevrons and profile names lean 2 to 4 px the way they go. No scaling on hover. |
| Pressed | Pills and buttons press to 0.97 (the round step buttons to 0.94) and spring back |
| Focus | A 2 px echo ring with an offset, on every interactive element |
| Selected | Bone fill with void text (the segmented thumb) |
| Disabled | Not used: remove the control or say why |
| Targets | 44 × 44 px on touch; 36 px on fine pointers, with 8 px between pills |
| Copy | The copy icon turns into a check that draws itself and "Copied" replaces the label from below in a one-line window (the button keeps its width), for 2 s, announced politely; on failure the text is selected and the message says how to copy it |
| Empty | Anything without a confirmed item is left out, never "coming soon" |

### Research: three cards

Research is three directions as three cards, in the lab's order (delivery, photoacoustics, ultrasound), so each
card sits in the same sequence as its chapter of the lab. A card reads top to bottom in one pass: a physics glyph
(● light for delivery, ●○ light and sound for photoacoustics, ○ sound for ultrasound), the title, where the work
was done, the question, a body of at most 45 words, the skills as a hairline list, and one line of ways on ("In
the lab: …" and "See the papers"). No featured-paper cards and no second paragraph: the publication list follows
directly. Three columns from 1280 px; from 768 px each card lays out horizontally (name and question left, details
right); on phones the cards stack.

### Publications: an index you can act on, and the Google Scholar readout

The owner asked (28 September 2026) for a list that doesn't show every paper in full, with filters, short details
per paper, and a Google Scholar snapshot linked to the profile and kept current. So the list is an index:

- **Rows carry what a reader scans for:** the year (a year already given above is dimmed, so the column reads
  as a timeline) and the half of the work it belongs to (● delivery, ●○ imaging, the same marks as in the Show
  filter, which is their legend; nothing for other work), the title (it links to the paper), one line of facts
  (where it appeared, short; "First author" and free access where true), and on the right, always in the same
  place, Google Scholar's "Cited by N" over a small bar (a stem lying down, ending in the chart's dot) and
  "Summary", which opens the row in place: the summary, authors, role, links, and Cite on its own line. Closed
  rows stay findable (hidden until found).
- **Controls:** Show (All, Delivery, Imaging, First author, with counts and the marks) above the list, and Sort
  (Newest, Most cited) in the list's header beside the count ("5 of 15 publications", which is also what's
  announced), both in the address (`?show=`, `?sort=`). Links elsewhere on the page that filter the list ("See
  the imaging papers", the lab's evidence links) change it in place, move focus to the Publications heading, and
  say the count. No search box, year filter, or Apply button: for 15 papers they cost more than they give.
- **Length:** on screens at least 48rem wide and 40rem tall with a fine pointer, the list scrolls in its ink panel
  (at most 40rem or 64% of the screen; after the reader has used the list, fitted so the edge cuts into the next
  title) with a fade at the edge that has more, and "Show the whole list" lets it run with the page. Everywhere
  else (phones, landscape phones, touch tablets) five rows and "Show all N", the rest findable. The list is never
  a Tab stop of its own: every row has links. Without JavaScript the whole list is open, and no control that
  needs a script is drawn.
- **The readout is one of the lab's instruments, in three tiles** (the owner asked on 28 September 2026 for citations,
  h-index, and i10-index in tiles that highlight them): an ink panel with a header strip ("Google Scholar", and a lit
  dot with the date it was read, where the lab says "Simulated"; the dot goes out when the reading is more than three
  days old). **Citations** is the large tile: the total as a large Newsreader figure, Scholar's "since" figure under it
  ("98 since 2021"), and citations per year as a stem plot in a black well (one sample per year, as a sampled signal is
  drawn); a year still running is hollow and dashed and says "so far". **h-index** and **i10-index** sit side by side,
  each with its figure, what it counts in words ("7 papers each cited at least 7 times"), and the papers ranked by
  citations against the line that defines it (at the h-index, and at 10), the papers that count drawn bone and the rest
  faint, so the index can be seen being counted. A ranking is drawn only when it gives Scholar's own figure. All in
  bone: citations are neither light nor sound. The totals are Scholar's own, never the chart's sum. From 80rem the
  panel stands beside the list with the same edges (the list's panel matches its height, and it stays in view when the
  list runs long); below that it follows the list, the three tiles in one row where the panel is wide, so on a phone the
  papers come first.
- **Where the numbers come from:** `src/content/scholar.json`, a committed snapshot of the public profile page,
  refreshed every four hours by `.github/workflows/scholar.yml` (`docs/scholar-sync.md`). The page never calls
  Google; the numbers are in the HTML.

### Motion

The owner found the page below the lab "soulless" (28 September 2026) and asked for micro-animation. The rule is the
10K checklist's: motion that whispers, hand-made for this page, never a fade-up on everything.

- **Where it comes from: the lab.** Light arrives, then what it sets off. A control answers at once (a tone, a thumb
  under the choice), and the result follows: rows glide to their new places, a count swaps to its new value, a
  picture is acquired behind a crossing scan line (the way an image is scanned), a figure rises into its readout, a
  light pulse flashes before the sound it launches, echoes return later from deeper.
- **Never untrue, even in motion.** Nothing shows a value it isn't: a Scholar figure waits blank and rises into place
  (it never spins through other numbers); a count swaps whole; a chart waits at zero, the stems' dots on the baseline
  like an instrument reading nothing; no two titles ever show through each other while rows move.
- **One moment per block, once.** A block below the lab waits until it is first scrolled to, then plays its moment:
  section headings rise from behind their own line (as the lab's headline does); Recognition's picture is acquired
  (on phones too); each Research diagram plays its physics, the three a beat apart in the lab's order (the particle
  is built: cores, gel, drug, coat); the Scholar tiles raise their figures, the stems rise year by year, and each
  index's line draws across, lighting the papers that reach it as it passes; About's and Contact's rules draw
  across. Charts and pictures wait until they're well in view; when scrolling stops, anything still waiting on
  screen plays. The "Checked" dot pulses once, after the tiles, and not at all when the reading is stale. Nothing
  loops. A block already on screen when the page settles plays nothing.
- **Answers to input.** Show and Sort: the thumb glides (a light spring), carrying a dark copy of the labels clipped
  to it, so the label under it is legible in every frame; rows that move a short way glide over the rest, rows that
  arrive or travel far are uncovered in place; the list's height eases (not when it shrinks by more than half a
  screen, which would carry what you were using off it); after "Most cited", the "Cited by" bars run out to their
  counts. A row's Summary eases open (420 ms) and folds away faster (260 ms), inert while it folds; the chevron turns
  with it; Cite eases open where the browser can animate a disclosure. The section bar's underline and Recognition's
  marker glide to the new choice; Recognition's counter swaps. A Research diagram rested on (150 ms) or tapped
  replays without erasing: its traces dim and a bright copy runs along them; the particle heats, its gel tightens,
  and the drug moves out. Hover and pressed are in "States".
- **Tokens** (`globals.css`): ease-out-quint for arrivals, ease-out-expo for rises, ease-in-out for sweeps, and a
  light spring (about 2% overshoot, `linear()`, with a cubic fallback where it isn't supported) for thumbs, markers,
  chevrons, and the copy check. Feedback 150 to 250 ms (a count swaps in 220 ms); opening 400 to 520 ms, closing
  about 60% of that; a block's moment 1 to 2 s, staggered 35 to 150 ms.
- **Never hides what someone needs.** Only what is below the screen when the page settles ever waits, and only once the
  page's script has marked it (`<html data-reveals>`): without JavaScript, when printing, and with reduced motion,
  everything is at rest. Nothing waits on hydration, the lab, or the network. In-page links glide only once the page
  has loaded: a link into the page jumps to its place instead of gliding past everything above it.
- **Reduced motion is a cut.** Every reveal, glide, swap, fold, sweep, press, and replay is skipped; tone changes
  (color) stay.
- **The theme swap** (see "Two themes"): the toggle answers at once (its icon morphs on the spring, 450 ms), and
  the page crosses to the other theme in 350 ms, every surface on one clock, the lab holding still. Interrupted,
  it reverses from where it is (colors transition from current values). Reduced motion: a cut, no crossfade.
- **Not here:** parallax, scroll-jacking, smooth-scroll libraries, hover zoom, autoplaying carousels, marquees,
  cursor trails, and a fade-up on every element.

### Voice across the site

- "I" for skills and research; "we" in paper summaries, because every paper has co-authors; the owner's own
  part goes in a "My role" line, quoting the journal's CRediT roles where they exist. Third person only in the
  short bio and metadata.
- Present tense for skills, past tense for findings; a date on every position.
- Paper titles stay verbatim. Everything written around them names skills, not materials, drugs, or
  wavelengths, and keeps numbers out of prose (citations, citation counts, readouts, and the one threshold note
  excepted).
- "Read the paper" always leaves the site; "See the papers" always stays on it; "PDF" appears only when a free
  PDF exists. Status is text first ("First author", "Open access").
- Dates: "September 2026" in prose; "Sep 2026" in the timeline and Recent; "2026" in the publication list; ISO in
  data. "Johns Hopkins University", then "Johns
  Hopkins"; never "JHU" in prose.
- Additions to the glossary: "photoacoustic imaging" (never "optoacoustic"), "heating tumors with light" (never
  "PTT"), "first author". Kept for accuracy where the plain word would overstate: "complicated cysts" (the study
  excluded simple cysts), "temperature-responsive" (for gels that set at body temperature, which "heat-responsive"
  would exclude), "3D tumor models", and "COVID-19".
- Banned everywhere: "passionate", "cutting-edge", "novel", "breakthrough", "state-of-the-art", emoji,
  exclamation marks, and arrows appended to link text.

### Length budgets for the sections

| Element | Budget |
| --- | --- |
| Section deck | ≤ 140 characters |
| Research card body | ≤ 45 words, plus 3–5 skills of ≤ 48 characters |
| Paper summary | ≤ 240 characters |
| "My role" line | ≤ 90 characters when written by the owner; a CRediT list is quoted whole |
| Short bio | ≤ 60 words |
| Long bio | ≤ 160 words |
| Meta title and description | ≤ 60 and ≤ 155 characters |

`npm run check:copy` enforces these budgets, the glossary, and the banned words on every build.

### Anti-patterns for the site

- A single bright accent carrying the chrome. A light theme was the list's first entry until the owner chose one
  (28 September 2026); its rules are in "Two themes", and the lab never lightens.
- Content chopped into identical cards with shadows; rules between sections.
- All-caps eyebrows, numbered markers, middle-dot meta strings ("Lead Scientist · SynapSeek"), and labels
  built as "WORD — fragment".
- Stat counters, count-ups, and citation counts, with one exception the owner chose: the Google Scholar readout (its
  three tiles) and each paper's "Cited by" in Publications, as Scholar reports them, dated, linked to Scholar, and
  rising into place once when first seen. No other metric appears anywhere. "Scroll to discover".
- Placeholders and builder links ("Photos coming soon", "Add portrait", "Edit website").
- Carousels, with one exception the owner chose: Recognition and service, directly under the lab. It never
  moves on its own, shows every item's title without scrolling on wide screens, has visible Previous and Next
  controls, a position ("1 / 3"), arrow keys and swipe, and every picture says where it came from (the owner's
  photo with its credit, or a lab still labeled "Simulated").

