# Recognition photos (originals)

Put the owner's photos for the Recognition and service section here, one per item, named by the item's id in
`src/content/about.ts` (for example `iisc-best-thesis-2025.jpg`). Keep the full-resolution original; the site
never serves these files directly.

Then run `npm run photos`, and in `about.ts` add to that item:

```ts
photo: { alt: "What the photo shows, in one sentence.", credit: "Photo: who took it" },
```

Only use photos the owner has the right to publish, and credit the photographer.
