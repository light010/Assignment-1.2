# Website revamp plan: Madhavi Tripathi

A plan to carry the new hero through to a complete, premium research website, measured against your
standard (`premium-frontend-prompt.md`) and the $10K Checklist.

Six AI specialist agents worked on it separately: references, structure and content, design system, and
engineering for the site, plus a science reviewer and a copy reviewer for the hero. Their four site reports
are appendices A–D, appendix E is the audit of your current site, and the two reviewers' decisions are
recorded in the hero's README. A seventh agent then critiqued the assembled plan, and its fixes are in.

**How to read it.** Section 1 is the one-page version. Sections 2–8 are the plan. Section 9 lists what
only you can answer; nothing in the plan depends on a guess about you.

---

## 1. The one-page version

**Where things stand.**
- The hero is built and has been through two independent reviews that cross-checked each other: four
  explorable chapters (Design, Delivery, Photoacoustics, Ultrasound), with every claim checked against
  your papers.
- Your current site holds the right raw material (a verified list of 15 publications with summaries, a
  full career timeline, awards, updates, and contact links), but visitors can't see any of it: every
  address returns "login required" behind ChatGPT, and shared links preview as "ChatGPT".
- Its design reads as a template: Inter for everything, identical gradient cards, carousels of
  "Photos & videos coming soon", and all-caps numbered eyebrows. It fails four of the eight checklist
  items outright (see 2.1).

**What we'll build.** One long, fast page that reads like a well-kept research record after the lab:

```
Hero (the lab)  →  Research  →  Publications  →  About  →  Contact
                    two halves   15 items,        bio, timeline,   email, Scholar,
                    tied to the  filterable,      recognition,     ORCID, LinkedIn
                    lab chapters cite-ready       recent updates
```

plus a CV link, a citation file, generated share images, and a 404. Separate research-theme pages come
later, once figure permissions are sorted (section 3.5).

**The point of view.** *First the instrument, then the record.* The hero is a working instrument; the
page after it is a calm, carefully typeset record in the same dark palette, where color appears only
when it means something (light and heat, sound, oxygen), every claim is one click from its paper, and
nothing moves unless you move it.

**What happens next.** You answer the five questions marked "Needed first" in section 9. Then the
build runs in eight milestones (section 7): foundation, hero hardening, content and its pipeline, the
sections (starting with a slice we calibrate on desktop and phone and show you), search and sharing, hosting, the
quality regime, and launch. The engineering estimate is 15.5–21 working days.

---

## 2. What we found

### 2.1 Your current site, against the $10K Checklist

Read in your own Chrome after you signed in, at desktop and phone widths. Full inventory and
screenshots: appendix E.

| # | Checklist item | Current site | Verdict | What the new site does | How we'll verify it |
| --- | --- | --- | --- | --- | --- |
| 01 | Point of view, not a template | Dark navy with cyan, glass cards, gradient washes, carousels, numbered all-caps eyebrows: the common builder look | Fails | "First the instrument, then the record": a lab you can operate, then an editorial record in the same palette | Sweep 3: no section would fit another site unchanged |
| 02 | Typography that does work | Inter for everything, no display face | Fails (the checklist names Inter) | Newsreader for headings and all reading text; Mona Sans for navigation, controls, authors, and labels | Computed-font audit; line-length script (67 characters at 1440, 49 at 390) |
| 03 | Restrained color system | Navy, cyan plus blue, purple, and green card washes | Partial | Void and bone, with meaning-only colors (pulse = light/heat, echo = sound, green/red = oxygen) | Search for data colors outside figures and chips; measured contrast table |
| 04 | Hierarchy that breathes | Clear sections, but every section is cards in boxes; carousels hide content | Partial | Hairline rows and open space; nothing hidden in carousels | Heading outline check; spacing rhythm in the screenshot matrix |
| 05 | Imagery with intent | No images; portrait placeholder; "Photos & videos coming soon" on every achievement | Fails | Hero-engine renders labeled "Simulated", figures from your open-access papers with credit, and a real portrait (a photo you have, or a short shoot) | Asset register (4.6); alt-text audit |
| 06 | Motion that whispers | A draggable 3D carrier, carousels, hover glows | Partial | The lab is the only animated thing; everything else responds to you | No scroll-triggered animation in the code; reduced-motion pass |
| 07 | Mobile that's designed | Good phone header; otherwise desktop stacked; "Photo / acoustic" tab breaks; a scroll area inside the page for publications | Partial | Phone-specific header, list, and figure layouts (section 5.6) | Screenshots from 320 to 390 px; no sideways scroll; 44 px targets |
| 08 | The invisible expensive stuff | Login wall (401) for every visitor and crawler; skip link present; "ChatGPT" link previews | Fails | Public and static; key content painted within 2 s in a throttled phone test, and within Google's 2.5 s mark for real visitors; WCAG 2.2 AA; real metadata and share images | Throttled phone runs, Lighthouse, axe, keyboard pass, preview debuggers |

What to keep from it: the question-led research blurbs, the verified publication list and summaries,
the dated timeline, the awards and service, the updates, and "Copy email". What to drop: the login
wall, carousels, placeholders, vanity counters (citation totals), and builder links such as
"Add portrait", "Manage references", and "Edit website" (these may show only to you as the signed-in
owner; either way they won't exist in the new site).

### 2.2 The hero, and what it still needs

Done and verified: the four chapters with measured readouts, the guided tour, the headline and copy
from your line, the science and copy reviews, the style guide (`design-system/MASTER.md`), the name line
changed to your own descriptor, "Translational scientist", plain zeros in the readouts, and 44 px touch
targets. What the engineering measurements found (details in 6.1), fixed in milestones M0 and M1:

- On a throttled phone, your name, the nav, and the lab console stay invisible for 4–6 seconds (never,
  without JavaScript), because the entrance animation starts them at zero opacity in the server HTML.
- Preloaded fonts weigh twice as much as the code; the italic used only for your name is 147 KB.
- Computing the instrument images blocks the page for 1.4 seconds, so an early tap waits about a
  second.

One visible change comes with the fix: on devices without WebGL2, with Data Saver on, on a 2G
connection, or with little memory, the lab starts as a still image with a "Load the 3D lab" button instead
of loading on its own. Everything else about the lab stays the same.

And the smaller open items:

- A "Skip the lab" link (the lab puts about 15 controls before any content).
- Phone navigation: today only "Contact" shows below 40rem.
- Deep links into chapters (`#lab-ultrasound` and so on) and one evidence link per chapter, labeled by
  what the paper actually shows:
  - Ultrasound: "Read the study in Radiology Advances".
  - Photoacoustics, Blood oxygen map (where the skin-tone and beamformer controls act): "Read the
    skin-tone study in npj Imaging". It is named for what the paper covers, so it never reads as a paper
    about oxygen mapping; none of the 15 papers covers that, though your site lists it as part of your work.
  - Photoacoustics, Nanoparticles map: "See the papers behind this", because the delivery papers cover it.
  - Design and Delivery: "See the papers behind this".
- A static poster for devices without WebGL and for reduced motion.
- A generated share image from the hero.

### 2.3 What the references taught

Eight live sites were inspected on desktop and phone (appendix A), plus Dribbble, Awwwards, and
21st.dev (Pinterest blocks everything behind a login). What we adopt:

- **Publication rows** from Arc Institute and Jon Barron: title first, your name in bold, venue and
  year in a tabular column, one plain sentence on what the paper shows, and real links at least 44 px
  tall (Paper, PDF where free, Cite).
- **Long-form grammar** from Quanta and Distill for any explanatory text: a 60–68 character measure,
  figures with caption and credit, and end matter with how to cite.
- **The explain, show, cite rhythm** from Ciechanowski for future theme pages: a sentence, a live
  figure with one control, a sentence on what to notice.
- **Honesty markers** from the PULSE Lab page and Distill: "Last updated" stamps, license and credit
  lines.

What we reject: vanity counters, stock or composite photos, particle networks and scramble text,
content hidden until scrolled, hover-only reveals, carousels, promo rails, and consent banners (we ship
without trackers, so none is needed).

---

## 3. Audiences, journeys, and structure

### 3.1 Who visits and what they need

| Visitor | Needs in the first minute | What earns trust |
| --- | --- | --- |
| PI or hiring committee | Current role, the two halves, first-author work, CV | A correct, complete list; stated roles and dates |
| Collaborator | Methods, recent papers, a way to reach you | Lab demos tied to real papers; your stated role on each paper |
| Student or mentee | What you work on, in plain words; whether you mentor | Clarity; mentoring shown only if real |
| Clinician | The clinical question and finding, a readable paper | Plain summary, peer-reviewed venue, "Open access" label |
| Curious non-scientist | What you do | Honest "Simulated" labels; no jargon |

### 3.2 Journeys (acceptance tests for the build)

| Journey | Entry and action | Observable outcome | Data | Failure and recovery |
| --- | --- | --- | --- | --- |
| Assess fit in two minutes | Search your name → home → headline → Publications → "First author" → About → CV | Both halves stated in the first view; 7 first-author items marked; dated timeline; CV downloads with its size shown | Real (publications from Scholar and Crossref, timeline from your site) | A namesake ranks first: title, description, and structured data disambiguate. No CV yet: no link rendered |
| Check a method, then write | Research → "See it in the lab: Ultrasound" → switch beamformer → "Read the paper" → Back → Contact → Copy email | The chapter opens; the DOI opens the paper; Back returns to the lab, and Back again to Research; "Copied" is announced | Real DOI; simulated lab, labeled | No WebGL: the link still lands on the lab's static poster. Clipboard blocked: the address is selected with a hint |
| Read the evidence | A shared link to one paper's anchor | The entry is in view even if a filter is active in the address; plain summary; "Open access" | Real | Renamed paper: old anchors keep working via aliases |
| Share the site | Paste the link in a chat | The preview shows your name, headline, and image, never "ChatGPT" | Real | Old chatgpt.site links still land on a login page: unpublish it, or make it public with one line pointing here (Q12) |
| Cite a paper | Publications → Cite → Copy BibTeX | BibTeX on the clipboard, "Copied" | Built from the publication data | Clipboard blocked: the text is shown selected |

### 3.3 Site map

```
/                          one page
├─ #top                    hero (exists): #lab-design · #lab-delivery · #lab-photoacoustics · #lab-ultrasound
├─ #research               Nanomaterials for delivery · Light and sound for imaging (+ one bridge line)
├─ #publications           ?show=all|delivery|imaging|first-author   · one anchor per paper #pub-{id}
├─ #about                  bio · positions and education · recognition and service · recent updates
├─ #contact                email (visible, Copy) · Google Scholar · ORCID · LinkedIn · CV
└─ footer                  name and role · "The lab images are simulations for explanation" · credits · updated date
/cv                        → the CV PDF (only once you provide one)
/publications.bib          all papers as BibTeX, generated at build
/opengraph-image           1200×630 share image rendered from the hero
/sitemap.xml · /robots.txt · 404
reserved for later: /research/delivery · /research/imaging · /publications · /talks
```

Why one page: 15 papers and two themes fill about five screens after the hero; committees skim, and
anchors serve them without page loads; later sections link back into lab chapters, which is simplest on
one page; and one authoritative URL with structured data beats thin pages competing with publishers.
Split into pages when there are more than 40 papers or 10 talks.

### 3.4 Navigation

- Labels everywhere, in this order: **Research · Publications · About · Contact.** "Updates" and
  "Highlights" from the old site fold into About.
- Desktop: the hero header as now, plus About.
- Phone: no hamburger for four items. The header gets a second row of four text links, each at least
  44 px tall.
- After the hero leaves the screen, a slim section bar with the same four links fades in at the top
  (160 ms, never sliding; instantly under reduced motion) and marks where you are. Content anchors leave
  room for it, so nothing lands underneath. This is the only thing on the page that responds to scrolling.
- "Skip the lab" is the first thing a keyboard reaches.

### 3.5 Research-theme pages: later, not at launch

The references make a strong case for two long-form pages (`/research/delivery`, `/research/imaging`) in
an "explain, show, cite" rhythm, with paired simulated figures (delay-and-sum vs. coherence) and end
matter. We recommend building them after launch, because they need figures you have rights to and your
review of longer text, and the hero already carries the explanation. The URLs are reserved now so
nothing has to move later.

---

## 4. Content

### 4.1 Where every fact comes from

Your current site is the primary source: you wrote it. Scholar, Crossref, and publisher pages supply
bibliographic detail. Anything the two disagree on is listed for you to settle (section 9); nothing is
guessed.

| Content | Source | Status |
| --- | --- | --- |
| Name, "Translational scientist", headline, lede | Your site and the hero | Ready |
| Now: Lead Scientist, SynapSeek (remote), since February 2026 | Your site | Ready; how prominent it should be is question Q1 |
| Postdoctoral Research Fellow, PULSE Lab, Johns Hopkins, with Prof. Muyinatu A. Lediju Bell | Your site | Start month differs (your site: Dec 2024; ORCID and the lab's welcome post: Feb 2025), Q2 |
| PhD, Materials Engineering, IISc Bengaluru, advisor Prof. Ashok M. Raichur; Best Thesis Award and Gold Medal 2025 | Your site | Date differs (your site: March 2025; ORCID: December 2024), Q2 |
| Integrated M.Tech., Biomedical Engineering, IIIT Allahabad, 2018 | Your site | Ready |
| Women in Molecular Imaging Network leadership committee (2024 to present); convener, 36th Annual Symposium of Materials Engineering, IISc (2023); mentoring | Your site | Ready |
| 15 items: 14 with DOIs plus the thesis record; one also has a preprint | Scholar, Crossref, publishers (appendix B has the full table) | Ready; hand-curated because at least two other researchers publish as "Madhavi Tripathi" |
| One-line summaries per paper | Your site, checked against each abstract | Ready after a pass through the glossary |
| Updates (npj Imaging paper Sep 2026; SynapSeek Feb 2026; Best Thesis Award 2025; IISc feature Sep 2023) | Your site | Ready |
| Email, Google Scholar, ORCID 0000-0002-4736-9134, LinkedIn | Your site | Ready |
| Portrait, CV PDF, figure permissions, talks and posters | Not available | Q3 (portrait), Q9 (figures), Q10 (CV), Q11 (talks) |

### 4.2 Truth by construction

- Every statement about you is stored as a fact with its source and a "confirmed" flag. Unconfirmed
  facts never render in the production build; a check fails the build if a required one is missing.
- Numbers stay out of prose. They appear only in citations, the lab's measured readouts, and the one
  threshold note (0.76), which your paper states.
- No citation counts or h-index on the page; the Scholar link does that job without going stale.
- Paper titles stay verbatim, including material names. Everything written around them uses the skill
  vocabulary you asked for: no material names or wavelengths outside titles.
- Every image says what it is: "Simulated" for the lab and its renders, "From [paper], CC BY 4.0" for
  figures from your open-access papers.

### 4.3 Voice, extended from the hero

- "I" for skills and research; "we" in paper summaries, because every paper has co-authors; your own
  part goes in a "My role" line (from the journal's published contribution roles where they exist,
  otherwise your words). Third person only in the short bio and metadata, so search results name you.
- Present tense for skills, past tense for findings, and dates on every position.
- The glossary and length budgets in `design-system/MASTER.md` apply site-wide, with additions for the
  new sections (appendix B, 5.2–5.3): for example "photoacoustic imaging" (never "optoacoustic" in
  prose), "heating tumors with light" (never "PTT"), "first author".
- Banned: "passionate", "cutting-edge", "novel", "breakthrough", "state-of-the-art", emoji, and ↗ arrows
  appended to link text.
- Length budgets for the new sections, settling where appendices B and C differ:

  | Element | Budget |
  | --- | --- |
  | Section deck | ≤ 140 characters |
  | Theme body | ≤ 90 words, plus 4–5 "What I did" items |
  | Bridge line | ≤ 140 characters (one sentence at heading size) |
  | Paper summary | ≤ 240 characters |
  | "My role" line | ≤ 90 characters |
  | Short bio | ≤ 60 words |
  | Long bio | ≤ 160 words |
  | Meta title and description | ≤ 60 and ≤ 155 characters |

  In M0 these, and appendix C as reconciled here, go into `design-system/MASTER.md`, which today covers
  only the hero.

### 4.4 Section by section

**Research.** Deck: "Two halves of one practice: building particles that carry treatment, and making the
images that show what's inside." Two blocks titled with the headline's lines, each with a short body (≤ 70
words), four or five skills written as work done, links into the matching lab chapters, and one or two
featured papers. Between them, one bridge line on the shared physics (tissue and particles absorb
light, heat slightly, and send out sound: why a particle can double as an imaging agent, and why skin
tone matters). Your site's question-led blurbs ("How can a carrier respond when it matters?", "What can
the echoes tell us more clearly?") survive as the blocks' opening lines.

**Publications.** A deck, then "Show: All 15 · Delivery 6 · Imaging 5 · First author 7" (the lab's own
segmented control, with the filter kept in the address so it survives reload and sharing). Groups in
All: nanomaterials for delivery, light and sound for imaging, and "Other and earlier work" (4 items,
collapsed). Each entry: year and venue, title linked to the paper, full author list with your name in
bold, one sentence on what it shows, "First author" and "Open access" as words, "My role" where you are
a co-author, "In the lab" chips, and Paper, PDF (where free), Preprint, Cite. A closing line: "Checked
against Google Scholar and Crossref on [date]."

**About.** A two-paragraph first-person bio built from your current one, a "Copy short bio" button for
talk organizers, the dated timeline (Lead Scientist → Postdoctoral Research Fellow → PhD → Integrated
M.Tech.), recognition and service (Best Thesis Award and Gold Medal; Women in Molecular Imaging
leadership committee; symposium convener), a short dated "Recent" log, and the CV link. Sub-blocks
appear only when they hold at least one confirmed item, so there is never a "coming soon".

**Contact.** "Email is the best way to reach me, about a collaboration or any of the papers above."
The address as visible text plus "Copy email", then Google Scholar, ORCID, and LinkedIn as labeled
text links. No form: there is no server to receive it, and a form could show a false "sent".

**Footer.** Name and role; "The lab images are simulations for explanation, not measurements."; figure
credits; "Updated [month year]"; Back to top.

**404.** "Page not found. Nothing echoes back from this address." with three ways out.

### 4.5 Content model (for the build)

Typed content files, one per concern, so the hero's files stay as they are: `person.ts` (name, role,
positions, education, links, bios), `themes.ts`, `publications.ts`, `figures.ts`, and `about.ts`
(recognition, service, updates, talks). The full model with real example records is in appendix B,
section 4. A content check runs before every build: duplicate anchors, filter counts, unconfirmed
required facts, and links to the lab chapters.

### 4.6 Asset register

Every file the site shows, with its source and rights, kept up to date through the build.

| Asset | Source | Rights | Status | Owner |
| --- | --- | --- | --- | --- |
| Portrait | Your photo, or a short shoot to the brief in appendix C, 5.3 | Photographer's permission for web and press use; credit in the caption | Needed (Q3) | You |
| CV (PDF) | You | Your decision to publish | Needed (Q10) | You |
| Figures from CC BY papers (Radiology Advances, npj Imaging, Journal of Biomedical Optics) | Original files from the papers | CC BY 4.0 with full credit; courtesy check with the lab | Pending (Q9) | You and us |
| Figures from ACS and Elsevier papers | Your own unpublished images, or the publisher's author-reuse terms | Confirmed per figure; unknown means not published | Pending (Q9) | You |
| Lab stills and poster | Rendered from the hero's engine | Ours; labeled "Simulated" | Planned (M1) | Us |
| Share image | Rendered from the hero with your name and headline | Ours | Planned (M4) | Us |
| Favicon and icons | Existing `icon.svg`, plus a 180 px touch icon | Ours | Partly done | Us |
| Fonts | Newsreader and Mona Sans | SIL Open Font License; the reserved-name clause checked before shipping trimmed versions | In use | Us |

---

## 5. Design

The full specification, with wireframes for every section at 1440 and 390 px, measured contrast, and
component states, is appendix C. This section is the part you need to decide on and remember.

### 5.1 Direction for everything after the hero: three options

Your standard asks for three structurally different directions and a recommendation. All three keep the
hero exactly as it is; they differ in how the rest of the page is built, not just in color.

**A. The paper (recommended).**

```
│ Research                                             │
│ ● Nanomaterials    Body, 18–20 px serif      ┌─────┐ │
│   for delivery     What I did …              │ fig │ │
│   (Design)         …                         └─────┘ │
│ ──────────────────────────────────────────────────── │
│ 2025   Title of the paper, linked                    │
│        One sentence on what it shows                 │
│        Authors, your name in bold · venue · Cite     │
```

- *Composition.* The hero console's grid at page scale: a label track (names, dates, lab chips), a reading
  track of at most 34em, and an aside for evidence. One left edge shared with the headline; nothing
  centered; hairline rows instead of cards.
- *Type.* Newsreader carries every sentence, including headings, prose, paper titles, and the email. Mona
  Sans carries what you operate or scan: nav, controls, authors, meta.
- *Color and surfaces.* Bone on void. Hue appears only as data, with a shape and a word. Paper figures sit on
  white plates marked "From paper"; lab renders sit in black wells marked "Simulated".
- *Density and imagery.* Medium: about five screens after the hero, one or two figures per research half,
  no thumbnails in the publication list.
- *Interaction.* Filters, cite panels, and chips into the lab; nothing moves unless you act.
- *The idea that makes it yours.* The lab's controls become the page's grammar. The same segmented
  control filters your papers, and every claim links back into the chapter that shows it.
- *Audience fit and trade-off.* Serves committees who scan and collaborators who read. Quieter than the
  hero, on purpose.
- *Seen in.* Arc Institute's publication rows, Jon Barron's entry anatomy, Distill's end matter
  (appendix A).

**B. The instrument continues.**

```
│ ┌ Research console ───────────────────────────────┐ │
│ │ [Delivery | Imaging]   live mini-lab   readouts │ │
│ └─────────────────────────────────────────────────┘ │
│ ┌ Papers ─────────┐ ┌ Paper ──────────┐ ┌ Paper ──┐ │
│ │ before ⇄ after  │ │ before ⇄ after  │ │ …       │ │
│ └─────────────────┘ └─────────────────┘ └─────────┘ │
```

- *Composition.* Every section is an instrument panel on a dashboard grid: Research embeds live mini-labs,
  and papers are tiles with interactive before-and-after figures.
- *Type.* Mona Sans leads; Newsreader only for titles.
- *Color and surfaces.* Glass panels over void, readouts in the lab's colors.
- *Density and imagery.* High: live renders in most sections.
- *Interaction.* Everywhere: toggles, sliders, and comparisons in every section.
- *The idea.* The whole site as one explorable instrument.
- *Audience fit and trade-off.* The most "show the skill" of the three. But several 3D surfaces cost load
  time and battery, compete with the hero, and make long reading harder. It risks the dashboard look the
  references warned against.
- *Seen in.* Ciechanowski's explainers and your current site's widget.

**C. The monograph.**

```
            │ Research                       │  ¹ Figure: cyst vs mass
            │ One centered column of serif   │    (From paper)
            │ text, like a book page, with   │  ² Tripathi et al., 2025
            │ notes and figures in the       │
            │ margin¹ and citations²         │
```

- *Composition.* After the hero, the page becomes a book page: one centered column of about 36em with a
  wide right margin for side notes, figures, and citations. Sections read like chapters, with running heads.
- *Type.* Newsreader throughout, including captions; Mona Sans only for controls.
- *Color and surfaces.* Light paper after the dark hero, with dark plates only around figures. The warm
  accent darkens to a terracotta to stay readable on paper.
- *Density and imagery.* Low: long-form prose, with figures as margin plates.
- *Interaction.* Minimal: notes expand on phones; everything else is reading.
- *The idea.* Your work presented as a monograph, citation by citation.
- *Audience fit and trade-off.* Beautiful for sustained reading, but your text is short and committees scan.
  The dark-to-light switch after the full-bleed hero flashes. Cream with a terracotta accent is the most
  common generated-site look, and every color token forks.
- *Seen in.* Quanta's long-form layout and margin-note traditions (appendix A).

Recommendation: **A.** It carries the hero's identity through the site without competing with it, and it
serves the way your visitors actually use a research site. The print stylesheet gives printed publication
lists the light, book-like treatment that C would have given the screen.

### 5.2 Tokens (summary)

- **Interface colors.** Dark surfaces, bone text in four steps, and one accent:
  - surfaces: void `#060a0c` (page), ink `#0c1216` (panels), panel `#131b20` (hover)
  - text: bone `#ece7df` for headings and body prose (16.15:1), bone-soft `#d6d1c9` for summaries,
    authors, and captions (13.08:1), bone-muted `#aaa59d` for labels (8.12:1), bone-dim `#8f8a83` for
    non-essential text (5.80:1)
  - accent: echo `#8fe1f0` for the focus ring, link hover, and, in data, sound

  The current `bone-faint` (4.22:1) becomes non-text only.
- **Data colors.** Figures, legends, and glyphs only: pulse (light and heat), echo (sound), oxygenated
  green, deoxygenated red, and the lab's particle colors. Themes are marked by shape as well as hue (●
  for delivery, ●○ for imaging), because oxygenated and deoxygenated fall to 1.49:1 for readers with
  deuteranopia.
- **Type scale.**
  - h2 34→52 px; deck 21→26 px; h3 24→32 px; body 18→20 px at line height 1.62 (measured medians: 67
    characters a line at 1440, 49 at 390); summaries 17 px; labels 13 px.
  - Every fluid size stays within 2.5× of its minimum, so 200% zoom holds.
  - Years use Newsreader's figures: Mona Sans's tabular zero is slashed and reads like "θ", which is now
    fixed in the hero's readouts too.
- **Space and grid.** 72→128 px between sections; 4, 8, and 12 columns at phone, tablet, and desktop.
  Radii step 18 (panels), 14 (cells), 11 (wells), 4 (plates and the portrait). No shadows on page
  surfaces, and no rules between sections.
- **Links.** Underlined in prose (bone at 45%, echo on hover), a 2 px echo focus ring, and never an
  arrow or a new tab.
- **Light theme.** None. Your current site had a toggle; question Q15 asks whether dropping it is fine.

### 5.3 Components

Skip link, section bar, the Show control (the hero's segmented control), publication group and entry,
cite panel, theme block, lab chip, featured-paper card (with and without a figure), bridge line, bio
block with "Copy short bio", timeline, awards and service, recent updates, contact block, footer, and
404. Each has its hover, focus, pressed, selected, empty, and error states specified in appendix C,
section 3. Two rules apply to all of them:
- Nothing is ever shown disabled or "coming soon": it is omitted or explained.
- Every target is at least 44 px on touch.

### 5.4 Imagery

Three sources, each labeled where it appears:
1. **Lab renders ("Simulated").** Stills rendered from the hero's own engine in four chapter states.
   They serve as the hero's fallback when a device has no WebGL (today that area is an empty gradient),
   the share images, and optional short loops for talks.
2. **Figures from your papers ("From paper").**
   - Open-access CC BY figures are credited in full.
   - Figures from subscription papers need your own images or confirmed reuse rights.
   - Figures are never recolored or inverted, and they sit on white plates.
3. **One portrait.** A photography brief is in appendix C, section 5.3:
   - a soft single light and a dark background that grades into the page
   - skin graded for exposure and white balance only, with no smoothing or retouching of skin
   - chest-up, facing toward the bio

No stock, no AI-generated pictures, no icon collages, and no placeholders.

### 5.5 Motion

Below the hero, nothing moves unless you move it:
- presses and hovers in 90–150 ms
- the segmented thumb gliding as in the hero
- figure swaps cross-fading after they load, and the list fading when a filter changes (140 ms)
- disclosures and the enlarged-figure dialog opening in 180–200 ms
- the one exception: the section bar fading in when the hero leaves the screen (160 ms)

Banned outright: fade-up reveals on scroll, staggers, parallax outside the hero, count-ups, carousels,
marquees, custom cursors, tilt, hover zoom, and scramble text. Reduced motion turns every remaining
transition into an instant change.

### 5.6 Phones, designed rather than shrunk

- **Navigation.** The four links stay visible as a second header row: they fit from 360 px, and below
  that they wrap to two rows. After the hero, the same links sit in a slim bar that marks where you are.
  No hamburger for four items. The design spec's inline menu is the fallback if the slice review shows
  crowding.
- **Order.** Each section is reordered for the phone, rather than having its columns stacked: in
  Research, the claim, then the evidence, then the way into the lab.
- **Components.**
  - The Show control becomes a 2×2 grid.
  - Author names never split across lines.
  - Link targets are 44 px rows.
  - The portrait is square.
  - The email wraps anywhere rather than overflowing.
- **Checks.** Every layout is checked at 320, 360, 390, 768, 1024, 1280×760, 1440, and 2560.

---

## 6. Engineering

The full plan, with every measurement and the scripts that produced it, is appendix D. The numbers
below come from a production build in a throwaway copy, run in Chrome on a throttled phone profile
("Slow 4G", 4× slower CPU, 5 runs, medians) and on desktop. They are lab numbers, not field data.

### 6.1 What the hero costs today, and what changes

| Measure | Today (phone profile) | Target | How |
| --- | --- | --- | --- |
| First text painted (the lede) | 1.52 s | ≤ 1.5 s; name, nav, headline, lede, and a lab poster all painted by 2.0 s | Keep the lede as it is; inlining CSS measured 0.78 s |
| Name, nav, and lab console visible | ≈ 4–6 s, and never without JavaScript | At first paint | They ship invisible because the entrance animation starts at opacity 0 in the server HTML. Render them visible and animate from there. |
| Lab area before the 3D lab arrives | Empty from 1.5 to 6.6 s; empty for good without WebGL | A poster rendered from the lab (15–25 KB) | Rendered stills per section 5.4; the poster is the fallback for no WebGL and reduced motion |
| A tap while the lab starts | Waits about 1.1 s | ≤ 200 ms | Instrument math moved to a background worker (measured 376 ms off the main thread); three.js loads when idle and only on capable devices, with a "Load the 3D lab" button otherwise |
| Preloaded fonts | 368 KB, twice the JavaScript | ≤ 230 KB now, ≤ 170 KB later | Load the italic (used only for your name) separately: 224.5 KB, verified. Later, self-hosted trimmed fonts. |
| JavaScript on the page | 192.5 KB (130 KB is the framework floor) | ≤ 165 KB | Keep the animation library inside the hero only |
| Layout shift | 0.002 | ≤ 0.02 | Unchanged |

Accessibility baseline: axe finds one violation (the stand-in text color, now fixed). About 80 contrast
checks over the 3D scene can't be automated, so a rendered-contrast script samples the pixels behind each
label in every lab state.

### 6.2 Architecture

- **Static site.** Every page is prerendered at build time, and there is no server to maintain. The
  build fails if anything tries to need one.
- **Server components by default.** Small client pieces only where they're needed: the section bar,
  the publications filter, copy buttons, and figure comparisons, each with its own byte budget.
- **Content in typed files, not a CMS.** Your facts, papers, and updates are records the compiler
  checks. A pre-build check fails on:
  - an unconfirmed required fact
  - a duplicate or missing anchor
  - a wrong count
  - any leftover builder text ("Edit website", "Add portrait", "coming soon", "chatgpt.site")
- **Publications pipeline.** You curate the list by DOI, and a script fills in details from Crossref
  into a committed snapshot, so builds never depend on the network. It never imports by name: a
  Crossref search for your name returns 17 exact matches in the top 20, and only 2 are yours. A weekly
  check reads your ORCID record and flags any paper missing from the site.
- **Images.** AVIF and WebP at four widths, with `<picture>` fallbacks. Posters load first; everything
  below the fold loads lazily with reserved space.
- **Filter without JavaScript.** All 15 papers are in the page. The filter only hides rows, so without
  JavaScript you still get the full list.

### 6.3 Performance budgets, enforced in CI

| Budget | Limit |
| --- | --- |
| JavaScript on first load | Today 192.5 KB: CI warns above 185 KB until M1, then fails above the level M1 measures (target about 165 KB); ≤ 140 KB on other routes; three.js never in the first load |
| Fonts preloaded | ≤ 230 KB after the italic split, ≤ 170 KB after self-hosting |
| Poster | ≤ 30 KB AVIF, 45 KB WebP |
| Figures | ≤ 90 KB AVIF at 1200 px, lazy |
| Load (phone profile) | Name, nav, headline, lede, and poster painted ≤ 2.0 s; LCP target 1.8 s |
| Responsiveness | No main-thread task over 200 ms before the lab is ready; every tap ≤ 200 ms |
| Stability | Layout shift ≤ 0.02 |
| Real visitors (p75, phone and desktop separately) | LCP ≤ 2.5 s, INP ≤ 200 ms, CLS ≤ 0.1, from cookie-free analytics, reviewed monthly |

Byte budgets fail the build. Timing budgets fail only when more than 20% over, because shared CI
machines are noisy. Lighthouse runs with DevTools throttling: its simulated mode reports 4.35 s for a
page measured at 1.52 s.

### 6.4 Search and sharing

- **Title.** "Madhavi Tripathi · Translational scientist", and a third-person description so search
  results name you rather than a namesake.
- **Structured data.** A profile page whose main entity is you:
  - your role at SynapSeek and your alumni institutions
  - ORCID as an identifier; Google Scholar and LinkedIn as your other profiles
  - one scholarly-article record per paper, linked by DOI

  Only confirmed facts go in, and the email is never included, to limit harvesting.
- **Share image.** A 90 KB JPEG rendered from the hero, with your name, role, and headline, replacing
  the "ChatGPT" previews. It is checked in LinkedIn's and Facebook's preview debuggers before launch.
- **Other files.** A sitemap, a robots file, icons, a manifest, and a 404 page that search engines don't
  index.
- **The old site.** It returns "login required" to everyone, so there is nothing to redirect and no
  search ranking to lose, and until launch any link to it lands on a login page. After launch, unpublish
  it (recommended), or, if ChatGPT allows, make it public with one line pointing to the new site (Q12).
  A pointer on a private site would reach no one.

### 6.5 Hosting and operations

- **Hosting.** Cloudflare static hosting: $0, no non-commercial clause, security headers, automatic
  HTTPS, preview links for every change, and one-click rollback. Vercel's free plan excludes sites
  whose code a paid developer or consultant writes, which is why question Q17 asks about that.
- **Security headers.** A content security policy was tested against the live hero with zero
  violations: three.js needs no unsafe evaluation. Also HSTS, nosniff, a strict referrer policy, and no
  framing.
- **Domain.** Registered in your name, with registrar lock, auto-renew, DNSSEC, and two-factor sign-in
  on both accounts.
- **Monitoring.** Cookie-free analytics (or none, your choice), an uptime check every 5 minutes, and a
  daily production smoke test that opens an issue if anything breaks.
- **Updating without writing code.**
  - An "Add a paper" form in GitHub asks for the DOI, a one-line summary, and your role. It fills in the
    rest from Crossref and opens a preview link.
  - You check the preview and press "Merge" to publish.
  - It needs a GitHub account and that one approval step. You never edit a file by hand, although you
    can if you want to.
  - "Add an update" works the same way, and a one-page guide with screenshots covers both.
- **Versioning.** The project becomes a git repository you own, with protected releases, pinned
  dependency versions, and weekly grouped updates that merge only when CI is green.

### 6.6 Continuous checks (every change)

Types and lint, the content check, a glyph-coverage check (a few characters, such as the thin space and
µ, aren't in the fonts), and a copy lint against the style guide's budgets. Then:
- the build and byte budgets
- journey tests in Chromium, WebKit, and Firefox (deep links, filters surviving reload, back and forward,
  no JavaScript, reduced motion, zero console errors)
- axe in every lab state at 390 and 1440 px, rendered contrast, 320 px reflow, and text spacing
- screenshots at 320, 360, 390, 768, 1024, 1280×760, 1440, and 2560
- Lighthouse and tap-timing tests
- link checks
- header checks on each preview

### 6.7 Terms used in this plan

| Term | Meaning |
| --- | --- |
| LCP (largest contentful paint) | When the biggest piece of content first appears. Google's "good" mark is within 2.5 s. |
| INP (interaction to next paint) | How long the page takes to respond visibly after a tap or click. "Good" is within 200 ms. |
| CLS (cumulative layout shift) | How much the page jumps around while loading. "Good" is 0.1 or less. |
| p75 | The 75th percentile of real visits: three in four visitors do at least this well. |
| Throttled test, "lab" numbers | A test on one machine that imitates a slow phone and network. Useful for comparing builds, but not what real visitors experience ("field" numbers). |
| CI (continuous integration) | Checks that run automatically on every change and block anything that fails. |
| axe | An automated accessibility checker. |
| WebGL | The browser technology that draws the 3D lab. |
| Static site | Pages built ahead of time and served as files, with no server to maintain. |
| CSP, HSTS | Security headers: which sources the page may load from, and always-HTTPS. |
| Structured data (JSON-LD) | Invisible labels that tell search engines who you are and what each paper is. |
| Share image (Open Graph) | The picture and title shown when someone pastes your link into a chat or post. |
| DOI, ORCID | A paper's permanent identifier, and your permanent researcher identifier. |
| Stand-in text | The placeholder sections below the hero in the current prototype. |

---

## 7. Milestones

Each milestone ends with evidence you can look at (screenshots, a preview link, measurements), and the next
starts only when the previous one's exit checks pass. Effort is in engineering days, estimated by the
engineering specialist from the measured baseline.

| # | Milestone | What gets done | Exit check | Effort | Your part |
| --- | --- | --- | --- | --- | --- |
| M0 | Foundation and answers | Git repository you own, CI skeleton, byte-budget script, pinned versions, the italic font split; the measurement scripts moved into the repository; appendix C (as reconciled) and the length budgets in 4.3 folded into `design-system/MASTER.md` | CI green (JavaScript budget warning only, until M1); fonts ≤ 230 KB | 1 | Answer Q1–Q5 (about an hour) |
| M1 | Hero hardening | Visible header and console in the server HTML, lab poster and fallbacks, idle and capability-gated 3D, instrument math in a worker, skip link, phone navigation and section bar, chapter deep links and evidence links | Name, nav, headline, lede, and poster painted ≤ 2.0 s on the phone profile; every tap ≤ 200 ms | 3–4 | None |
| M2 | Content and pipeline | Typed content from your site, Scholar, and Crossref; the content check; the "Add a paper" form; the copy deck through both reviewers | 15 records validated; a dry-run "Add a paper" works | 2–3 | Approve the copy deck (about 30 minutes) |
| M3 | Sections, slice first | Research and Publications first, calibrated against the references at 390, 768, 1024, and 1440. That calibration is our checkpoint, not an approval step: you see the slice, and the build continues unless the direction needs to change. Then About, Contact, footer, section bar, 404, the figure pipeline, and a print stylesheet for the publication list. | Slice calibrated; all journeys in 3.2 pass; axe clean at every checked width; print preview checked | 4–6 | Look at the slice and flag anything that feels wrong |
| M4 | Search and sharing | Metadata, structured data, sitemap, robots, icons, the share image | Validators and preview debuggers pass | 1 | None |
| M5 | Hosting and operations | Cloudflare setup, headers, domain, HTTPS, analytics, uptime and smoke tests, a rollback drill | Preview checks green; rollback tested | 1 | Register the domain; create or approve the accounts |
| M6 | Quality regime | Three sweeps and four dustings (section 8), a real-phone pass, fixes | No open P0 or P1 defect; every pass signed off with evidence | 3–4 | Read the defect summary |
| M7 | Launch and handoff | DNS cutover, Search Console, the old-site decision, updated links elsewhere; a handoff report; a 28-day check of real-visitor numbers | Site live; previews correct; field numbers within budget, or reported unavailable if you chose no analytics | 0.5–1 | Unpublish the old site or make it point here; update Scholar, ORCID, LinkedIn |
| | **Total** | | | **15.5–21** | |

**The handoff report** at launch separates three things: what is implemented and verified (with the
evidence for each check), what is implemented but unverified (and why), and what is blocked (and on what).
It also records:
- the publish steps
- every account and its owner (domain registrar, Cloudflare, GitHub, Search Console), each with
  two-factor sign-in
- running costs: the domain at about $10–20 a year; hosting and analytics at $0
- who answers uptime and smoke-test alerts

**After launch (upkeep).**
- A monthly check that applies security-only updates.
- A quarterly check of your publication list against Scholar and ORCID.
- A 28-day review of real-visitor numbers. It includes a search for your name, which only makes sense
  once search engines have indexed the site.

Later, when you want them: the two research-theme pages (3.5), talks, and an HTML CV.

---

## 8. The quality regime: three sweeps, four dustings

Booker T. Washington's admission test at Hampton was a room. He swept it three times and dusted it four
times, and when the head teacher rubbed her handkerchief over the woodwork she found nothing. This site gets
the same treatment. Every release candidate goes through seven passes in order. Each has a lens, tools,
and a written result in the defect log (issue → route, state, viewport → fix → verification). A pass is done
when it finds nothing new, not when it has been run once.

**Sweep 1: structure and truth.**
- Every journey in 3.2 works from entry to outcome: direct address, refresh, back and forward, anchor
  links, filters in the address, 404, and no JavaScript.
- Every statement about you traces to its source or your written confirmation.
- Real vs. simulated is labeled wherever it matters.

**Sweep 2: interaction and access (WCAG 2.2 AA).**
- Keyboard only: visible focus, logical order, no traps, the skip link first.
- VoiceOver on macOS Safari and iOS: headings, landmarks, live captions, segmented controls, figure
  descriptions.
- Automated axe on every route and every lab state; the rendered-contrast script over the 3D scene.
- 200% zoom; reflow at 320 px; reduced motion; forced colors; touch targets of at least 44 px.

**Sweep 3: visual craftsmanship.**
- Screenshots at 320, 360, 390, 768, 1024, 1440, and 2560 wide, plus a short laptop (1280×760) and a
  landscape phone. The same screens go to your own phone and one mid-range Android.
- Three scales: composition (focal order, rhythm, density), components (alignment, states), details (real
  line breaks, short last lines, icon weight, border contrast, crops).
- Side by side with the chosen references at the same widths, comparing hierarchy and finish, not looks.

**Dusting 1: words.** The copy deck is generated from the content files (as it was for the hero) and linted
against the length budgets and glossary: American spelling, curly quotes, one name per thing, no banned
words, and every glyph covered by the fonts.

**Dusting 2: science.** An independent science reviewer checks every claim against your papers, and a copy
reviewer checks the rewrites. Each then vets the other's proposals before anything changes. This is the
process that caught the gCNR cutoff and the solid-mass behavior in the hero.

**Dusting 3: speed.** Byte budgets, throttled phone runs for paint times, layout shift, long tasks, and tap
delays, Lighthouse with DevTools throttling, and the real-phone run.

**Dusting 4: discoverability and sharing.** Titles and descriptions, share images in LinkedIn's and
Facebook's debuggers, structured data in the schema validator, sitemap and robots, a link checker, and
icons. The search for your name waits for the 28-day review, once the site is indexed. Rankings can't be
promised, only the signals that help them.

**The gate:** no open P0 or P1 defect, and every pass signed off with its evidence.

**How the reviewers work.**
- One implementation owner writes all code. Reviewer agents (art direction, UX and accessibility,
  engineering and performance, science, copy) never edit files.
- They review the brief, the design contract, and real evidence, and return prioritized fixes with exact
  wording or values.
- Disagreements go to a cross-review round in which each reviewer vets the other's proposals.
- Accuracy and the brief win over style.

---

## 9. Questions for you

**Needed first (these shape the build).**
- **Q1. What should the site do for you this year, and where does SynapSeek fit?** For example: academic
  job applications, collaborations, speaking invitations, or recruiting for your team. Your site says you
  now lead scientific and AI/ML strategy at SynapSeek. We recommend showing that role in About and the
  timeline, and keeping the hero and Research on nanomaterials and imaging, as you asked. Would you
  rather have a third research theme for it?
- **Q2. Two dates to settle.**
  - Postdoc start: December 2024 (your site), or February 2025 (ORCID and the lab's welcome post)?
  - PhD: March 2025 (your site), or December 2024 (ORCID)?
- **Q3. Portrait.** Do you have a recent photo you like, at least 1600 px on the short side, with the
  photographer's permission? If not, appendix C has a one-page brief for a short shoot that matches the site.
- **Q4. Domain.** Which domain would you like (for example, your name dot com)? We recommend registering it
  in your name, with you owning the accounts.
- **Q5. Direction after the hero.** Option A, B, or C in section 5.1? We recommend A.

**Needed before launch.**
- **Q6.** Keep the same public email as your current site (it has only ever been visible behind the login)?
  May we list LinkedIn alongside Google Scholar and ORCID?
- **Q7.** Which one or two papers to feature in each research half.
- **Q8.** A one-line "My role" for co-authored papers where the journal doesn't publish contribution roles
  (seven papers).
- **Q9.** May we reuse figures from your CC BY papers (Radiology Advances, npj Imaging, Journal of
  Biomedical Optics) with credit, and is that fine with Dr. Bell's lab? For the ACS and Elsevier papers,
  do you have your own images you can publish?
- **Q10.** A current CV as a PDF, and may it be public?
- **Q11.** Talks and posters you presented (title, event, date), if you'd like them listed.
- **Q12.** Your current ChatGPT site: unpublish it after launch (recommended), or, if ChatGPT allows,
  make it public with one line pointing to the new site?
- **Q13.** Analytics: none, or a cookie-free counter that also reports real load times?
- **Q14.** Keep "Other and earlier work" (the 2015–2022 papers outside the two halves) in a collapsed group?
- **Q15.** Your current site has a light/dark toggle. Is it fine for the new site to be dark only, with a
  light printed version of the publication list?
- **Q16.** Which GitHub account should own the code, and who should receive uptime alerts?
- **Q17.** Is anyone paid to build or maintain the site? That decides whether some free hosting plans are
  even allowed; the recommended one has no such clause.
- **Q18.** SynapSeek's web address for the structured data, or leave it out?
- **Q19.** Which phone do you use, so it's in the real-device pass?

**At launch, on your side.** Add the new address to your Scholar homepage field and update the affiliation
there (it still says Johns Hopkins). Update ORCID (it lists 4 of your 15 works), LinkedIn, your email
signature, and your Women in Molecular Imaging profile if it links a site. A complete ORCID also helps
search engines tell you apart from other Madhavi Tripathis.

---

## 10. Risks

| Risk | Effect | Mitigation |
| --- | --- | --- |
| The 3D lab's startup cost on mid-range phones (1.1 s tap delays measured) | The first taps feel broken | Worker, idle and capability gating, shader compile before first frame, poster first, a raw-tap test in CI |
| WebGL variance (blocklists, lost contexts, iOS memory) | A blank or crashed lab | Poster fallback, context-loss handling, low-power path; CI tests both paths |
| A namesake's papers leak into the list | A committee sees wrong work under your name | DOI-only curation, the confirmed-fact gate, the weekly ORCID check, a human merge |
| Facts go stale (roles, dates) | Wrong information in your name | One person file feeding everything; facts carry sources; the upkeep guide |
| Figure rights for subscription papers | Featured images can't be used | Your own images, simulated renders, or typographic cards |
| Contrast over the 3D scene regresses | Unreadable labels in some states | Rendered-contrast script in every lab state |
| Framework churn and experimental flags | Breakage on upgrade | Pinned versions; flags adopted only with a measured win and CI coverage |
| A non-developer edit breaks the build | The site stops updating | Form workflows, previews, required CI, rollback |
| Hosting terms or budget change | Forced move | The static build is portable to any host with header support |
| Scope creep (theme pages before launch) | Launch slips | Theme pages are post-launch by design; URLs reserved |
| The published email is harvested | More spam | Your current site showed it only behind the login, so this is its first public appearance. Show it as text with Copy, keep it out of structured data, and consider a contact-only address. |

---

## Appendices

Each appendix is a specialist's full report, kept as written so every decision above can be traced to its
evidence. Where the plan and an appendix differ, the plan is the reconciled decision.

| | Report | What's in it |
| --- | --- | --- |
| A | [References](A-references.md) | The four required sources, eight live sites inspected on desktop and phone, what to adopt and reject |
| B | [Structure and content](B-structure-and-content.md) | Full publication table with DOIs, journeys, site map, content model with example records, copy drafts, microcopy |
| C | [Design system](C-design-system.md) | Tokens with measured contrast, type scale, grid, component states, wireframes at 1440 and 390, imagery and portrait brief, motion rules |
| D | [Engineering](D-engineering.md) | Measured baseline, architecture, budgets, accessibility plan, search and sharing, hosting, CI, effort |
| E | [Your current site](E-current-site.md) | Content inventory in your words, and the desktop and phone audit |

The hero's own contract (voice, glossary, length budgets) is `design-system/MASTER.md`, and the accuracy
decisions from the science and copy reviews are in the project README.

Reconciled differences between the reports:
- **Phone navigation.** Visible links (appendix A) rather than a menu button (B, C, D); the menu stays
  as the fallback.
- **Research-theme pages.** After launch (B) rather than at launch (A).
- **Author lines and years.** The brighter `bone-soft` and Newsreader figures (C) rather than
  `bone-muted` and the tabular cut (B).
- **Section order after Research.** Publications before About, so evidence comes before biography.

Inside the appendices, the reports refer to each other by working number: 01 = A, 02 = B, 03 = C, 04 = D,
05 = E.

The measurement scripts and the baseline results are saved in `tools/perf/`. The other evidence files (93
reference captures, throwaway builds, renders) are in this work session's temporary scratch folder and are
not copied, so ask if you want any of them kept.
