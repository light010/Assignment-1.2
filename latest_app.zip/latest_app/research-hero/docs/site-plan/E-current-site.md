# The current site: content inventory and audit notes

Source: https://madhavi-tripathi.madhavi-tri16.chatgpt.site/, read in the client's own Chrome after they signed in
themselves (27 Sep 2026). Public visitors still get HTTP 401 and a "Continue with ChatGPT" login page.

## Facts it states (the client's own words; supersede earlier inferences)

- Title and og:title: "Madhavi Tripathi | Translational scientist"; description: "Nanomaterials for delivery. Light & sound for imaging."
- Hero: "Translational scientist" · H1 "Madhavi Tripathi." · "Nanomaterials for delivery. / Light & sound for imaging." ·
  lede "I develop nanomaterials for drug delivery and explore photoacoustic and ultrasound imaging—connecting how we deliver
  with how we see." · CTAs "Explore my research", "Google Scholar" · status line "Lead Scientist · SynapSeek · Remote".
- About ("Curiosity. A constant in motion."): "I am a translational scientist working across biomaterials, drug delivery,
  ultrasound, and photoacoustic imaging. I earned my Ph.D. in Materials Engineering at IISc and completed postdoctoral training
  in the PULSE Lab at Johns Hopkins University. My work connects material synthesis and biological evaluation with image
  reconstruction, quantitative analysis, and clinical imaging studies. I now lead scientific and AI/ML strategy at SynapSeek,
  developing reproducible workflows for a neuro-diagnostic mapping platform. Alongside research, I mentor junior scientists and
  serve on the Women in Molecular Imaging Network leadership committee."
- Timeline:
  - Feb 2026–present · Lead Scientist · SynapSeek · Remote · "Leading scientific and AI/ML strategy, data pipelines, model
    evaluation, and validation for a neuro-diagnostic mapping platform."
  - Dec 2024–Jan 2026 · Postdoctoral Research Fellow · PULSE Lab · Johns Hopkins University · "Ultrasound and photoacoustic image
    reconstruction, quantitative analysis, and breast-imaging studies with Prof. Muyinatu A. Lediju Bell."
    (ORCID says 2025-02 to 2026-01; the lab's welcome post is dated 1 Feb 2025: start month to confirm.)
  - March 2025 · Ph.D. in Materials Engineering · Indian Institute of Science, Bengaluru · "Doctoral research on nanotheranostic
    platforms for photoacoustic imaging and image-guided therapy. Best Thesis Award / Gold Medal, 2025. Advisor: Prof. Ashok M.
    Raichur." (ORCID lists the PhD as 2018-08 to 2024-12: degree date to confirm.)
  - July 2018 · Integrated M.Tech. in Biomedical Engineering · Indian Institute of Information Technology, Allahabad ·
    "A five-year foundation in biomedical engineering, bringing together engineering methods and biological questions."
- Achievements ("The work. The moments behind it."): IISc Best Thesis Award · Gold Medal (2025) · Women in Molecular Imaging
  leadership committee (2024–present) · Convener, 36th Annual Symposium of Materials Engineering, IISc (2023).
- Research ("Small scale. Wide possibilities." / "Responsive carriers. Optical contrast. Information carried by sound."):
  1. Nanomaterials & drug delivery · "How can a carrier respond when it matters?" · "Designing CuS, CuS–Au, and thermoresponsive
     nanogel platforms, from synthesis and characterization to drug delivery, 3D tumor models, and preclinical evaluation."
  2. Ultrasound imaging · "What can the echoes tell us more clearly?" · "Working with DAS and SLSC beamforming, RF-data analysis,
     and quantitative contrast metrics, including breast cyst and solid-mass characterization."
  3. Photoacoustic imaging · "How can light and sound reveal more?" · "Connecting contrast-agent development with sound-speed
     selection, oxygenation mapping, and target-detectability studies across simulations, phantoms, and clinical images."
- Scholar snapshot: profile affiliation Johns Hopkins University; 104 citations; 15 references; keywords; "Snapshot checked
  23 September 2026."
- Publications: the same 15 items as Scholar, each with authors, venue, a one-line summary, "Read paper"/"Read chapter"/"Read
  thesis", "Copy link"; filters by topic, year, sort; per-paper anchors (#paper-…).
- Updates: 04 Sep 2026 new npj Imaging paper · Feb 2026 joined SynapSeek as Lead Scientist · 2025 IISc Best Thesis Award ·
  11 Sep 2023 IISc feature "Hybrid nanoparticles in the spotlight"
  (https://www.iisc.ac.in/events/hybrid-nanoparticles-shine-new-light-on-targeting-cancer-cells/).
- Contact ("Good questions. New connections."): published email (visible, with Copy email), Google Scholar, ORCID
  0000-0002-4736-9134, LinkedIn /in/mtri16.
- Footer: "Madhavi Tripathi. / Materials. Delivery. Light & sound." and a visible "Edit website" link.

## Audit notes (observed)

- Access: the whole site is behind a ChatGPT login (401 for visitors, search engines, and link previews).
- Leftover builder affordances visible to visitors: "Add portrait" (links to /edit), "Edit website" in the footer.
- Unfilled states shown to visitors: portrait placeholder "MT / Portrait"; every achievement card says "Photos & videos coming
  soon"; the achievements carousel repeats items.
- Typography: Inter Variable for everything (fails $10K item 02); one family, no display face.
- Theme: dark navy (#080c14) with a cyan accent, light/dark toggle; radix tabs; one canvas widget ("The research, in motion":
  Drug delivery / Photoacoustic / Ultrasound, drag to rotate, three-step guide, tour).
- Structure: nav Highlights · Research · Publications · About · Updates · Connect · Scholar ↗ · theme toggle; skip link present;
  numbered section eyebrows (01–05) in all caps ("IN FOCUS", "RESEARCH DIRECTIONS", "UPDATES").
- Template tells per the design guidance: all-caps tracked eyebrows, middle-dot meta strings, "↗" suffixed links, carousels for
  three items, vanity counters (citations), a "Scroll to discover" cue.
- Good raw material to keep: the clear question-led research blurbs, the full timeline with advisors, the verified publication
  list with summaries, the achievements, the updates, and the contact block with Copy email.

## Visual audit (screenshots in the client's Chrome, desktop 1284 px and phone 406 px)

Desktop:
- Hero: portrait placeholder box beside the name; name set in Inter with the surname in a lighter tint (two-tone name);
  headline with a cyan left rule; cyan filled CTA; the "research in motion" card on the right (tabs, draggable 3D carrier,
  "Conceptual illustration · not to scale" label, three-step guide, tour).
- Achievements: a featured card plus two stacked cards, each with a "Photos & videos coming soon" media well; carousel
  1 / 3 with arrow buttons; "View all moments 3"; "Add photos & videos ↗".
- Research: three equal glass cards with icon tiles, numbered 01–03, blue/purple/green gradient washes, "Related references"
  counts and "Explore research ↗" (the SaaS-card pattern the design guidance calls generic).
- Publications: search field plus Topic / Year / Sort selects; "15 of 15 references"; entries with type badges ("Journal
  article", "Selected work"), authors, venue, one-line summary, "Read paper ↗", "Copy link"; status text "0 of 15 references
  have saved citation counts."; "Manage references & citation counts ↗".
- About: bio column plus a vertical timeline of cards (dates, role, org, description, "Learn more ↗").
- Connect: large gradient card, email pill with ↗, "Copy email", text links; footer tagline and "Edit website ↗".
- Builder links ("Add portrait", "Add photos & videos", "Manage references & citation counts", "Edit website") may appear only
  to the signed-in owner; we viewed it signed in, so treat them as owner-only unless the client says otherwise.

Phone (406 px): a designed header (logo, Scholar button, theme toggle, menu button) but otherwise the desktop stacked: the
portrait placeholder leads; the widget's "Photoacoustic" tab label breaks into "Photo / acoustic"; publications live in a
nested scroll area ("Scroll to explore, or expand the list"), a scroll trap on touch; internal status lines are visible
("Reference-level citation counts have not been added.").
