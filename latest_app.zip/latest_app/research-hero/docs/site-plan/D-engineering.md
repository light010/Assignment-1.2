# 04 · Engineering plan: the full site around the research hero

Role: principal engineer. 27 September 2026. Project: `research-hero/` (Next.js 16.3.6, React 19.2.8, Tailwind 4,
Motion 13.4.4, three 0.186.1). Tags: **[M]** measured with scripts in `plan/tools/`; **[B]** verified by building or
running a throwaway copy in `plan/tools/`; **[D]** installed Next docs (Appendix A); **[V]** screenshot inspected;
**[W]** web page read (URL given); **[S]** search snippet only. The project was not modified; the :3217 dev server was
left running. Lab numbers are one machine, one browser: not field data (§3).

## 0. Decisions at a glance

1. **Static export** (`output: "export"`) on **Cloudflare Workers static assets**: $0, no non-commercial clause,
   `_headers`/`_redirects`, free cookieless RUM with p75 LCP/INP/CLS. Vercel Hobby excludes sites built by "a paid
   employee or consultant" [W]. An export build with these metadata routes is verified [B] (§2.1).
2. **Fix the hero's loading path first.** The name, nav, and console are invisible until hydration (≈4–6 s on the
   mobile profile), fonts preload 368 KiB (twice the JS), and a 1.4 s main-thread task makes a tap wait 1.1 s [M].
   Fixes: visible server HTML, a poster in the lab frame, idle- and capability-gated three.js, instrument math in a Web
   Worker [B], and a split italic font call [B].
3. **Typed TS content modules** (IA model, `02-ia-content.md` §4); publications curated by DOI, enriched from Crossref
   into a committed snapshot; GitHub form workflows let the client add a paper without code.
4. **Budgets enforced in CI**: a per-route size script (Next 16 no longer prints sizes [B]), Lighthouse CI with DevTools
   throttling, Playwright perf, axe, and screenshot tests.
5. **Metadata and JSON-LD use the client's descriptor "Translational scientist" and her confirmed role** (Lead Scientist,
   SynapSeek), not the stale Scholar affiliation. A 90 KB static JPEG share card replaces the ChatGPT previews [B].
6. **The old chatgpt.site URL** returns 401 to everyone: nothing to redirect, no SEO equity. Unpublish it after launch or
   keep it private with a one-line pointer: the client's call (§5.5).

## 1. Baseline: the hero as it stands

### 1.1 Method

- **Build.** Clone in `plan/tools/hero-build`, `next build` (Turbopack), served by `next start -p 3291` (gzip). Sizes
  from `tools/budget-check.mjs`, which follows each prerendered HTML file's scripts, stylesheets, and font preloads
  (gzip -9, brotli 11; 1 KB = 1,024 B); composition from production source maps (`tools/attribute.mjs`).
- **Browser.** Playwright-core 1.63, local Chrome 153 headless, Metal GPU (the hero's `shot.mjs` flags); fresh context,
  cache disabled, every run.

| Profile | Viewport | Network (CDP `Network.emulateNetworkConditions`) | CPU (CDP) | Runs |
| --- | --- | --- | --- | --- |
| Mobile | 390×844, DPR 3, touch, Android user agent | 562.5 ms latency, 1.44 Mbps down, 675 kbps up (Lighthouse's DevTools "Slow 4G" values) | 4× (`Emulation.setCPUThrottlingRate`) | 5 |
| Mobile, 6× | same | same | 6× | 3 |
| Desktop | 1440×900, DPR 1 | 40 ms latency, 10 Mbps | 1× | 5 |

- **Measures** (`tools/measure.mjs`). PerformanceObservers installed before any page script: `largest-contentful-paint`
  (with element), `layout-shift` (largest session window), `longtask` and `long-animation-frame` (script attribution),
  `event` (threshold 16 ms); plus Resource Timing and the moment the canvas is revealed (`data-status="ready"`).
- **Taps during long tasks.** Playwright's `click()` waits for the main thread, so it can never land a tap inside a long
  task; `tools/inp-raw.mjs` sends raw CDP mouse events at fixed times instead.
- **Cross-checks.** Lighthouse 13.5.0, simulated and DevTools throttling (`tools/lh/`); axe-core 4.13 in five hero states
  at 390 and 1440 px (`tools/axe-results.json`); a CDP screencast filmstrip (`tools/filmstrip.png`) [V].
- **Caveat.** The host is an Apple M4 Pro (Lighthouse BenchmarkIndex ≈4,000), so 4× understates a mid-range phone; hence
  the 6× runs.

### 1.2 Bytes (production build) [M]

| Item | Size | Notes |
| --- | --- | --- |
| Initial JS on `/` | **192.5 KB gzip** / 166.4 brotli / 629.8 raw (7 scripts) | Composition: react-dom 62.3, Next runtime 52.2 (+ RSC client 6.0, react 2.8, turbopack 3.8), **Motion 41.2** (motion-dom 30.5, framer-motion 9.6), hero code ≈17 (instruments 4.8, chapters 3.5, hero 2.4, instrument panel 2.4) |
| Initial JS on a route with no client code (`/_not-found`) | 130.0 KB gzip | This is the Next 16 + React 19.2 floor. Every route pays it. |
| three.js chunk (lazy) | 663.5 KB raw, **168.9 KB gzip, 138.6 KB brotli** | 147.8 KB gzip of it is `three` itself; lab code is ≈10 KB |
| CSS | 1 file, 37.9 KB raw / 7.8 KB gzip | Render-blocking |
| Fonts | **3 preloaded woff2 = 376,972 B (368 KiB)** | Newsreader italic latin 147,060 B (used only for the name), Newsreader roman latin 131,848, Mona Sans latin 98,064. The six latin-ext and vietnamese files were not requested. |
| HTML `/` | 42,238 B raw / 6.1 KB gzip | |
| Total transferred, mobile run | 767,009 B | Includes the three.js chunk |

### 1.3 Timings [M]

| Metric (ms; median, range) | Mobile 4× | Mobile 6× | Desktop |
| --- | --- | --- | --- |
| FCP = LCP | **1,516** (1,516–1,524) | 1,520 | 252 (244–256) |
| LCP element | Lede `<span>` (358×107) | same | Lede (471×123) |
| CLS | 0.002 (font swap at 4.3 s) | 0.002 | 0.005 |
| Name and nav become visible | ≈4,000–4,800 (filmstrip) | – | – |
| Lab console becomes visible | ≈6,000 (filmstrip) | – | – |
| `load` | 4,494 | 4,515 | 1,169 |
| three.js request start → end | **4,552 → 6,081** | 4,617 → 6,145 | 552 → 733 |
| Lab ready (canvas revealed) | **6,625** (6,609–7,707) | 7,561 | 1,195 |
| Long tasks: count / longest | 4 / **1,416** | 5 / 2,102 | 3 / 349 |
| Blocking time (Σ over 50 ms, to ready + 4 s) | 1,805 (1,749–2,757) | 2,728 | 443 |
| Tap landing at 4.8 s (raw input) | **1,136–1,192** (input delay 1,131–1,183) | – | – |
| Second skin-tone tap, 150 ms after the first | **1,056–1,080** | – | – |
| Single scripted clicks through all chapters | 32–80 (one outlier: 312) | – | 32–72 |
| Lighthouse, DevTools throttling | Performance 69–70; LCP 1,521; TBT 2,636–2,696; TTI 7.2 s | – | – |
| Lighthouse, simulated throttling | Performance 49–56; LCP **4,354**; TBT 2.5–10.8 s | – | Performance 64–75; LCP 804–873 |

### 1.4 What the numbers mean

- **F1. LCP is the lede, not the headline.** The lede is visible in the server HTML, so LCP (1.52 s mobile) waits only
  on HTML and render-blocking CSS, not JS. The `<h1>` wraps each letter in an inline-block for the sound wave, so no text
  block in it is large enough to be the candidate. A poster will become the LCP element, so it gets a byte budget (§3).
- **F2. Name, nav, console, and instrument panel ship at `opacity:0`** (Motion's `initial` state is serialized into the
  server HTML). On mobile they appear after hydration (≈4–6 s). With JavaScript disabled [B], or under a CSP that
  blocks the inline scripts [B], they never appear, and keyboard users can tab into invisible links. LCP passes, but the
  "sub-2 s" intent fails.
- **F3. Fonts outweigh JS two to one.** The three preloads finish at 3.7–4.5 s on mobile, competing with hydration.
- **F4. The lab frame is empty from 1.5 to 6.6 s on mobile** [V filmstrip]. Without WebGL it stays an empty dark frame
  [V `tools/m4x-nowebgl.png`]. Reduced-motion visitors still download three.js.
- **F5. The main thread is the INP risk.** `InstrumentPanel` computes the overview photoacoustic image in a `setTimeout`
  just as the console appears (1.4 s at 4×, 2.1 s at 6×, 0.35 s desktop). The engine's first frame (shaders, bloom)
  adds 0.25–1.25 s, and each first visit to an instrument variant 0.16–1.1 s, so fast tapping yields INP above 1 s.
- **F6. Lighthouse's simulated LCP (4.35 s) contradicts both measured traces (1.52 s):** its model assumes the render
  waits on scripts. CI must use DevTools throttling for this page.
- **F7. Inlining CSS** (`experimental.inlineCss`, `tools/hero-inline` [B]) cut mobile LCP from 1,516 to **784 ms**, at
  the cost of HTML growing from 6.1 to 28.7 KB gzip as served (CSS duplicated in the RSC payload) and CSP allowing
  inline `<style>`.
- **F8. Accessibility.** axe's only violation is `bone-faint` text (4.21:1) in the stand-in sections. At 1440 px axe
  leaves 70–86 contrast checks "incomplete" (text over the canvas and glass), so automation cannot clear the hero (§4).
  Lighthouse: Accessibility 96, Best Practices 100, SEO 100.

## 2. Architecture

### 2.1 Routes (the IA's single page, `02-ia-content.md` §3)

| Route | Built from | Notes |
| --- | --- | --- |
| `/` | `app/page.tsx` (server) with client islands | Sections: hero, `#research`, `#publications` (`?show=`, `#pub-{id}`), `#about`, `#contact`; deep links `#lab-*` |
| `/cv` | `public/_redirects`: `/cv /madhavi-tripathi-cv.pdf 308` | Only once the PDF exists. `redirects()` in `next.config` does not work in an export [D static-exports]. |
| `/publications.bib` | Route handler with `export const dynamic = "force-static"` | Generated from `publications.ts`; `_headers` sets `Content-Type: text/plain; charset=utf-8` |
| `/opengraph-image.jpg` + `.alt.txt` | Static file convention in `app/` | 90 KB JPEG; emitted with its extension, plus `og:image:type/width/height/alt` [B] |
| `/sitemap.xml`, `/robots.txt`, `/manifest.webmanifest` | `app/*.ts` metadata routes | Each needs `export const dynamic = "force-static"`. Without it the build fails: `export const dynamic = "force-static"/export const revalidate not configured on route "/robots.txt" with "output: export"` [B] |
| `/icon.svg` (exists), `/apple-icon.png` (180×180, new) | App icon conventions [D app-icons] | |
| 404 | `app/not-found.tsx`, with `metadata.title` | Emits `out/404.html` with the title "Page not found · …" and `noindex` [B] |
| Reserved: `/publications`, `/talks`, `/notes` | – | If a dynamic segment ever has its own OG image, that image route needs its own `generateStaticParams` [B] |

The old site's `#paper-{slug}` anchors and `?topic=` filters need no aliases: nobody outside its login ever reached them.

### 2.2 Rendering

- **Everything is prerendered.** `output: "export"` turns any request-time API into a build error, which is the guard.
  No `cacheComponents`: there is no runtime data [D cacheComponents; caching-without-cache-components].
- **Server components by default.** Client islands and their gzip budgets: hero (as now), sticky header and section index
  (IntersectionObserver, ≤ 1.5 KB), menu (native `<dialog>`, ≤ 1 KB), publications filter (≤ 1.5 KB), copy buttons
  (≤ 0.5 KB), figure compare (≤ 1 KB).
- **Motion stays inside the hero.** Shared chrome must not import it (41 KB, the largest non-framework item). Try
  `LazyMotion` + `m` with async `domMax` in the hero (all three are exported by the installed Motion 13.4.4); measure the saving in M1.
- **SSR-first publications filter.** All 15 entries render on the server, each `<li>` carrying `data-themes`. A small
  client component inside `<Suspense>` (required for `useSearchParams` on a static page [D use-search-params]) reads
  `?show=`, sets `data-show` on the list, and CSS hides the rest; a polite live region says "Showing 6 of 15". Without JS
  the full list shows, and each change costs only a style recalculation.

### 2.3 Content storage: typed TS modules, not MDX

- **Why.** The site is structured records, not long prose: `Person`, `Publication`, `Theme`, `Figure`, and `Fact<T>`
  (`{value, source, confirmed}`, IA §4). The compiler checks every field, enum, and ID reference (themes, chapters,
  featured IDs, `CHAPTER_EVIDENCE` anchors), and counts, JSON-LD, BibTeX, and the sitemap derive from one source. MDX
  would add a compiler and a component-mapping surface and put untyped prose next to facts that must be confirmed.
- **Gatekeeping.** `scripts/check-content.ts` runs as `prebuild` and fails on an unconfirmed required fact, duplicate or
  missing IDs, wrong counts, or forbidden strings in content or built HTML: "Edit website", "Add portrait", "coming soon",
  "[TO CONFIRM]", `chatgpt.site`, "Lorem". The old site's builder affordances must never ship.
- **Glyph coverage.** A script checks every character in the content against the self-hosted font subsets (U+2192,
  U+2009, U+202F, µ, and ′ are missing today, `03-design-system.md` §2.2).

### 2.4 Publications pipeline (Scholar has no API)

1. **Curated source of truth:** `src/content/publications.ts`, 15 records with DOIs or record links plus the client's
   summaries, roles, themes, and chapters (IA §1.2, §4). Never import by name: my Crossref probe
   (`query.author=Madhavi Tripathi`) returned 17 exact-name matches in the top 20, of which only 2 are hers (both 2015
   items in the IA list); the rest are namesakes in nuclear medicine, neurology, and networking venues. Only 1 of the 20
   carried an author ORCID and 2 had abstracts, so summaries stay curated [M `tools/crossref-probe.json`].
2. **Enrichment** (`npm run enrich`): `scripts/enrich-publications.mts` fetches `https://api.crossref.org/works/{doi}`
   (the maintainer's contact in the User-Agent, never the client's), decodes entities and strips JATS markup (the probe
   returned `&amp;` in venue names), and writes the committed `publications.crossref.json`. Builds never touch the
   network, so they are reproducible and the diffs reviewable.
3. **Validation** (in `check-content`): DOI matches `^10\.\d{4,9}/\S+$`; curated and Crossref titles agree at ≥ 0.9
   after normalization unless an override is recorded; "Tripathi" is in the author list; years match; IDs are stable
   (`aliases` for renames); enums are valid; summaries and roles are `confirmed` before they render.
4. **ORCID watch:** a weekly GitHub Action reads `https://pub.orcid.org/v3.0/0000-0002-4736-9134/works` (the iD on her
   old site, `05-old-site.md`) and opens an issue for any DOI missing from the site. ORCID lists only 4 of the 15 works
   (IA), so the client should add the rest.
5. **Outputs:** the page list, ScholarlyArticle JSON-LD, and `/publications.bib`. No citation counts (IA §3.4).

### 2.5 Images

- **Loader.** The default `next/image` loader does not work in an export [D static-exports; image]. Use a `<Picture>`
  server component fed by the sharp pipeline in `03-design-system.md` §5.1 (AVIF q50 and WebP q72 at 480/768/1200/1600 w,
  manifest with width, height, alt, credit); `next/image` with `unoptimized` only for single-size images. `<picture>`
  gives art direction (wide versus stacked lab crop, the `wide` media query) and a real WebP fallback: Edge 111–120 is in
  Next 16's support matrix [D version-16] but lacks AVIF.
- **Measured poster candidates** (scene only, from the lab) [M `tools/posters/`]:

| Candidate | AVIF | WebP |
| --- | --- | --- |
| Desktop, 1600 w | 24.8 KB | 41.0 KB |
| Desktop, 1200 w | 16.4 KB | 25.8 KB |
| Phone frame, 1068 px (DPR 3) | 23.0 KB | 36.5 KB |
| Phone frame, 712 px | 15.5 KB | 23.4 KB |

- **Attributes.** The poster (LCP element) gets `fetchpriority="high"` and a `<link rel="preload" imagesrcset
  imagesizes>` (Next 16's `preload` replaces `priority` [D image]); everything below the fold is `loading="lazy"` with
  width and height. `sizes`: poster `(min-width: 60rem) and (min-aspect-ratio: 21/20) 100vw, calc(100vw - 2rem)`;
  figures `(min-width: 64rem) 40rem, calc(100vw - 2rem)`; portrait `(min-width: 64rem) 22rem, calc(100vw - 2rem)`.

### 2.6 Fonts

| Option | Newsreader roman | Newsreader italic | Mona Sans | Preloaded |
| --- | --- | --- | --- | --- |
| Now: one call carries both styles | 131,848 | 147,060, preloaded | 98,064 | **368 KiB** |
| **A (M1, day 1):** a second `Newsreader({ style: "italic", weight: "400", preload: false })` call [B] | 131,848 | 24,408, not preloaded | 98,064 | **224.5 KiB** |
| **B (M1):** self-hosted instances (fonttools, `next/font/local`): roman wght 350–500, opsz 16–72; Mona Sans wght 400–600, wdth 88–100; italic static 400 [M] | 104,052 | 24,248 | 60,060 | **160 KiB** |

Option A is safe: both calls declare `font-family: Newsreader` with different `font-style` values, so the name's italic
resolves unchanged [B]. Option B needs self-hosting, because `next/font/google` rejects weight ranges ("Unknown weight
350 500 for font Newsreader") [B]. Keep `display: "swap"` and `adjustFontFallback` (CLS at swap: 0.002). Both families
are OFL; check the Reserved Font Name clause before shipping modified instances.

### 2.7 The hero's lazy three.js boundary

- **Server HTML.** Name, nav, headline, lede, and console render visible; entrance motion moves to CSS keyframes that
  start from the visible state (or `initial={false}`). The lab frame holds the art-directed poster (`alt=""`; the captions
  carry the meaning).
- **When three.js loads:** after `load` plus `requestIdleCallback` (2 s timeout), with the frame within one viewport
  (IntersectionObserver), WebGL2 available, and no constraint signals (`saveData`, `effectiveType` `2g`/`slow-2g`,
  `deviceMemory` < 4 where reported). Otherwise the poster stays with a "Load the 3D lab (about 140 KB)" button. Controls,
  captions, readouts, and instrument images work before the engine exists.
- **Main thread.** Move the instrument math in `instruments.ts` to a module Worker
  (`new Worker(new URL("../lab/instruments.worker.ts", import.meta.url), { type: "module" })`). Turbopack emits a worker
  chunk, and the overview photoacoustic image computes there in 376 ms, its 617,600-byte buffer transferred back
  [B `tools/hero-fonts`; D lazy-loading]. The engine awaits `renderer.compileAsync(scene, camera)` (in three r186, with
  `KHR_parallel_shader_compile`) before the first render and yields between object builds.
- **Resilience.** `webglcontextlost` falls back to the poster; reduced motion keeps today's paused start; a no-JS render
  shows the poster and a readable console.
- **Acceptance (mobile profile):** header and poster painted ≤ 2.0 s; no long task > 200 ms before the lab is ready;
  raw-input taps ≤ 200 ms, including taps at 4.8 s and double taps.

## 3. Performance budgets and enforcement

| Budget | `/` | 404 and utility routes | Enforced by |
| --- | --- | --- | --- |
| Initial JS (gzip) | ≤ 185 KB (fail; today 192.5); ≤ 165 KB target after M1 | ≤ 140 KB | `check-budgets` (from `tools/budget-check.mjs`) |
| three.js in the initial chunks | Never | Never | `check-budgets` (signature scan) |
| Lazy lab chunk | ≤ 175 KB gzip | – | `check-budgets` |
| CSS / HTML (gzip) | ≤ 12 / ≤ 40 KB (≤ 60 KB with `inlineCss`) | ≤ 12 / ≤ 10 KB | `check-budgets` |
| Preloaded fonts | ≤ 230 KiB after option A; ≤ 170 KiB after option B | same | `check-budgets` |
| Poster (the LCP image) | ≤ 30 KB AVIF / 45 KB WebP per variant | – | Image-manifest check |
| Figures | ≤ 90 KB AVIF at 1200 w, lazy | – | Image-manifest check |
| Lab LCP, mobile profile | ≤ 1.8 s target, fail > 2.0 s | ≤ 1.5 s | LHCI (DevTools throttling, median of 3) and the Playwright perf spec |
| "Sub-2 s load" | Name, nav, headline, lede, and poster painted ≤ 2.0 s | same | Playwright screencast assertion |
| CLS (lab) | ≤ 0.02 | ≤ 0.02 | LHCI and Playwright |
| Main thread (lab, 4×) | No task > 200 ms before ready; TBT ≤ 600 ms (≤ 300 ms target) | TBT ≤ 150 ms | Playwright (longtask and LoAF) and LHCI |
| Taps (lab, 4×) | Every scripted and raw tap ≤ 200 ms | – | `inp-raw` spec |
| Field, p75 (mobile and desktop separately) | LCP ≤ 2.5 s, INP ≤ 200 ms, CLS ≤ 0.1 | same | Cloudflare Web Analytics, reviewed monthly |

Structural budgets (bytes, three.js placement, header visible at first paint) fail the build. Timing budgets fail only
when more than 20% over and warn otherwise, because shared CI runners are noisy; calibrate on five `main` runs first.
Lighthouse CI: `throttlingMethod: "devtools"`, `numberOfRuns: 3`, `staticDistDir: "./out"`; assert LCP ≤ 2000,
CLS ≤ 0.02, TBT ≤ 600, and accessibility and SEO categories = 1. Simulated mode's 4.35 s LCP (F6) would fail a
correct page.

## 4. Accessibility plan (WCAG 2.2 AA)

**Automated (every PR).**
- `@axe-core/playwright` (tags `wcag2a`, `wcag2aa`, `wcag21aa`, `wcag22aa`) on `/` in every lab chapter, with the menu
  open, in each `?show=` value, and on 404, at 390 and 1440 px. Any violation fails.
- A **rendered-contrast script** covers what axe leaves "incomplete" (text over the canvas, callouts, glass): for each
  text box, screenshot with that text hidden, sample the pixels behind it, and fail below 4.5:1 (3:1 for large text and
  UI boundaries). Run it in all four chapters and the tour's end state.
- No-JS render (`javaScriptEnabled: false`) with the header visible; 320 px reflow (`scrollWidth` ≤ viewport); WCAG 1.4.12
  text-spacing overrides with no clipping (the caption box is `min-h-[4.5em]`); reduced motion; `forced-colors: active`
  screenshots.

**Manual (each release candidate; who, device, and findings go in the defect log).**
- Keyboard only: "Skip the lab" comes first; focus order matches visual order across the `display: contents` hero; no
  traps in the menu dialog; focus never hidden under the sticky header (2.4.11, `scroll-padding-top`).
- VoiceOver on macOS Safari and iOS Safari (NVDA plus Firefox if a Windows machine is available, otherwise reported as not
  covered): headings, landmarks, radio groups announced as "radio button, 2 of 3", live captions, figure alternatives.
- 200% browser zoom at 1280 px, 320 px reflow, and OS reduced motion.

**Risks specific to this site**

| Risk | WCAG | Mitigation |
| --- | --- | --- |
| Name, nav, and console at `opacity:0` in the server HTML (F2) | 2.4.7, 1.3.1 | Visible in the server HTML; no-JS test |
| Text over WebGL and glass can't be auto-checked (F8) | 1.4.3, 1.4.11 | Rendered-contrast script and manual check in every state |
| Tour captions change every 5–8 s in a polite live region | 4.1.3 | Announce only changes the visitor makes; the tour posts one summary; Stop always reachable |
| Segmented controls built as button radios, reused for the filter | 4.1.2, 2.1.1 | Keep the APG radio-group roving focus (as today); SR spot check |
| Colour-only meaning: oxygenated/deoxygenated drops to 1.49:1 under deuteranopia (`03` §8); delivery chart lines | 1.4.1 | Direct text labels always; distinct line styles |
| `bone-faint` is ≈4.2:1 on void; the nearest passing tone is `#7c7872` (4.53:1) | 1.4.3 | Lint rule: no `text-bone-faint` on text smaller than 24 px |
| Segmented options are 36 px tall | 2.5.8 | Passes the 24 px AA minimum. The README claims 44 px: fix the claim or the size. |
| Auto-playing lab, headline wave, tour | 2.2.2 | The pause button already exists and reduced motion opens paused; keep both |
| Copy email | 4.1.3 | `role="status"` says "Copied"; when the Clipboard API is unavailable, select the text instead |

## 5. SEO and sharing

### 5.1 Metadata

| Route | Title | Canonical | Share card |
| --- | --- | --- | --- |
| `/` | `title.default` built from the client's descriptor, e.g. "Madhavi Tripathi · Translational scientist"; `template: "%s · Madhavi Tripathi"` | Absolute production URL; the same string in `og:url`, the sitemap, and the JSON-LD `@id` base | `og:type: "profile"` (`firstName`/`lastName` exist in the installed Next types); `opengraph-image.jpg` 1200×630 plus `.alt.txt`; `twitter:card` `summary_large_image` |
| 404 | "Page not found · Madhavi Tripathi" | None | Inherited; `noindex` is added automatically [D not-found; B] |

`metadataBase` comes from `SITE_URL` (relative URLs without it are a build error [D generate-metadata]); the
description is the IA's third-person line (§5.6). Set `alternates.canonical` per page through a `pageMetadata()` helper,
never in the root layout (every child would inherit it). Merging is shallow: a page-level `openGraph` replaces the root
one, and my export lost `og:site_name` and `og:locale` that way [B], so every page spreads a shared `openGraphBase`.
`profile.affiliation` ("Johns Hopkins University") feeds the header, `<title>`, and share card today; replace it everywhere
with the confirmed descriptor or role field.

### 5.2 JSON-LD

One `@graph` script in `app/page.tsx`, with `<` escaped as the docs require [D json-ld]:
- **`ProfilePage`** whose `mainEntity` is the `Person`
  [W https://developers.google.com/search/docs/appearance/structured-data/profile-page].
- **`Person`:** `name`; `description` ("Translational scientist working across biomaterials, drug delivery, ultrasound,
  and photoacoustic imaging", her words); `jobTitle` "Lead Scientist" and `worksFor` SynapSeek (Feb 2026–present, per her
  site; org `url` omitted until she supplies it); `alumniOf` Indian Institute of Science, Johns Hopkins University
  (postdoctoral training, her words), and IIIT Allahabad; `knowsAbout`; `award` only for confirmed items; ORCID as an
  `identifier` `PropertyValue`; `sameAs` ORCID, Google Scholar, and LinkedIn `/in/mtri16` (on her own contact block). No
  `email` field, to limit harvesting; the address stays visible on the page.
- **One node per publication** (`ScholarlyArticle`, `Chapter`, or `Thesis`): `@id` and `sameAs` = the DOI URL, `url` =
  `/#pub-{id}`, `author` including the Person `@id`, `datePublished`, `isPartOf`, and `license` for the CC BY items. My
  export prototype emits this shape for placeholder data [B].
- **Only confirmed facts:** the generator reads `Fact.confirmed`, so unconfirmed dates (postdoc start month, PhD year)
  stay out. Release checklist: Schema Markup Validator; a unit test that every `@id` resolves.

### 5.3 Share images (replacing the ChatGPT previews)

- **Chosen: a committed static JPEG.** `scripts/build-og.mts` renders an HTML template with the real woff2 fonts and a lab
  still in Playwright (`03` §5.1) and writes `app/opengraph-image.jpg` (q82, about 90 KB) plus `opengraph-image.alt.txt`.
  It ships with its extension and correct `og:image` tags [B]; CI fails if the hash of its inputs (name, headline, still)
  changes without a regenerated image.
- **Rejected: `next/og`.** `ImageResponse` with fonttools-made static TTF instances rendered the real fonts correctly
  [B `tools/og-prototype.png`, V], but it outputs only PNG (638 KB), is limited to ttf/otf/woff and flexbox
  [D image-response], and under an export writes an extensionless `out/opengraph-image` [B], while static hosts derive
  `Content-Type` from the file extension [W https://developers.cloudflare.com/workers/static-assets/headers/].
- **Release check:** LinkedIn Post Inspector (https://www.linkedin.com/post-inspector/) and the Facebook Sharing Debugger
  (https://developers.facebook.com/tools/debug/).

### 5.4 Sitemap, robots, icons, and previews

The sitemap lists `/`. `robots.txt` allows everything and names the sitemap; omit `host`, since my build emitted a
non-standard `Host:` line [B]. The manifest keeps `display: "browser"`; icons are `icon.svg` plus `apple-icon.png`.
Previews must not be indexed: a `_headers` rule `https://*.workers.dev/*` → `X-Robots-Tag: noindex` (absolute-URL rules
are supported [W https://developers.cloudflare.com/workers/static-assets/headers/]). After launch, verify the domain in
Google Search Console by DNS TXT and submit the sitemap.

### 5.5 Transition from the old site

The old site sits behind a ChatGPT login, so every path returns 401 to visitors, crawlers, and link previews
(`05-old-site.md`). There is no public SEO equity to carry over, and we control neither its server nor its headers, so
no redirect is possible. The client's call:
1. unpublish it once the new site is live (recommended: no second, private copy drifting out of date); or
2. keep it private, with its content replaced by a one-line pointer to the new domain for anyone who can still sign in.

The new site never links to chatgpt.site (the forbidden-string check enforces it). At launch the client updates the links
that point to her: the Scholar homepage field and affiliation (Scholar still shows Johns Hopkins), ORCID websites,
LinkedIn, her email signature, and the WIMIN profile if it lists a site.

## 6. Hosting and operations

| Option | Cost and terms | Headers and redirects | Field CWV | Verdict |
| --- | --- | --- | --- | --- |
| **Cloudflare Workers static assets + export** | "Requests to static assets are free and unlimited"; no commercial restriction on the limits page [W …/workers/static-assets/billing-and-limitations/] | `_headers` (≤ 100 rules), `_redirects` (301–308) [W …/static-assets/headers/, …/redirects/] | Web Analytics is free, uses no cookies or localStorage, and reports LCP/INP/CLS with p75 [W …/web-analytics/data-metrics/core-web-vitals/] | **Recommended** |
| Vercel Hobby, standard build | Free, but "non-commercial personal use only", and commercial includes "a paid employee or consultant writing the code" [W https://vercel.com/docs/limits/fair-use-guidelines] | `headers()`/`redirects()` in `next.config` (verified locally [B]) | Free Speed Insights reports the Real Experience Score only; per-metric CWV needs Plus on Pro [W …/speed-insights/limits-and-pricing] | Only if nobody is paid |
| Vercel Pro | Paid | same | Full, with Plus | If the client prefers managed Next hosting |
| GitHub Pages | Free | No response headers, so no CSP, `frame-ancestors`, or `X-Robots-Tag` [S https://github.com/orgs/community/discussions/54257] | None | Rejected |

`wrangler.jsonc`: `assets.directory: "./out"`, `not_found_handling: "404-page"` (serves `404.html` with a 404 status),
`html_handling: "auto-trailing-slash"` [W …/static-site-generation/]. Cloudflare Previews give each branch or PR its own URL
(public when enabled; Cloudflare Access can protect it) [W …/workers/configuration/previews/]; rollback redeploys a
previous version.

**Domain and HTTPS.** The client registers the domain in her own name (§9) and keeps DNS on Cloudflare, so certificates
are automatic. Turn on registrar lock, auto-renew, DNSSEC, and 2FA on both accounts. HSTS through `_headers`
(`max-age=31536000; includeSubDomains`); add `preload` only after a month without issues.

**Headers (`public/_headers`).** I tested each CSP variant on the hero [B `tools/csp-test.mjs`]:
- three.js needs no `unsafe-eval`.
- Without `'unsafe-inline'` in `script-src`, the inline RSC scripts are blocked: no hydration, an invisible nav, and no
  lab. Nonces need per-request rendering [D content-security-policy], so they are not available here.
- `style-src 'self'; style-src-attr 'unsafe-inline'` produced zero violations. If `inlineCss` is adopted, `style-src`
  needs `'unsafe-inline'`.

```
/*
  Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://static.cloudflareinsights.com; style-src 'self'; style-src-attr 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; connect-src 'self' https://cloudflareinsights.com; worker-src 'self'; object-src 'none'; base-uri 'self'; form-action 'none'; frame-ancestors 'none'; upgrade-insecure-requests
  Strict-Transport-Security: max-age=31536000; includeSubDomains
  X-Content-Type-Options: nosniff
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=(), usb=()
  Cross-Origin-Opener-Policy: same-origin
/_next/static/*
  Cache-Control: public, max-age=31536000, immutable
```

Confirm the analytics hostnames against the actual snippet at setup; the obsolete `interest-cohort` is left out. CI
checks these headers on the preview URL.

**Operations**

| Area | Plan |
| --- | --- |
| Analytics | Cloudflare Web Analytics, manual snippet loaded after `load` (≤ 8 KB budget), or none if the client prefers. It is the p75 source for §3. |
| Uptime | A free external HTTP monitor on `/` and `/robots.txt` every 5 minutes, with a keyword match on the name, alerting the maintainer |
| Errors | A daily Playwright smoke test against production (GitHub cron): page loads, no console errors, lab ready, poster present, links alive; failures open an issue. Add Sentry's lazy loader only if WebGL failures show up (it needs CSP additions). `instrumentation-client.ts` is available for a first-party hook [D]. |
| 404 | `app/not-found.tsx`: voice-consistent, three exits, `noindex`; served with status 404 by `not_found_handling` |

**Content updates, without code.** A GitHub **"Add a paper"** workflow (`workflow_dispatch` with a DOI field) runs
`enrich`, drafts the record with `confirmed: false`, and opens a PR. The client checks the preview URL, edits the summary
and role in GitHub's web editor, sets `confirmed: true`, and merges. "Add news" (date, text, link) works the same way.
Each content file starts with a copy-this template, `CONTENT.md` walks through both flows with screenshots, and branch
protection plus CI keep a malformed edit from shipping.

**Versioning and backups.** The project is not yet a git repository.
- Now: `git init`, commit the hero as the baseline, and push to a **client-owned** private GitHub repo; protect `main`
  (PRs and green CI) and tag each release.
- Keep original assets (portrait, figure sources, CV) in `assets/originals/`, or in Git LFS above 50 MB; mirror monthly
  to a second remote; Cloudflare keeps previous versions.
- Renovate or Dependabot weekly, grouped, merged only on green CI; pin exact versions (`motion`, `three`, and
  `lucide-react` use `^` today); Node 24 LTS in `.nvmrc` (Next 16 needs Node ≥ 20.9 [D version-16]).

## 7. QA and CI

| Job | When | What | Gate |
| --- | --- | --- | --- |
| Static | Every PR | `tsc --noEmit`; `eslint` (`next lint` is gone and `next build` no longer lints [D version-16]); `check-content`; glyph coverage; copy lint against `MASTER.md` budgets (owner's Dusting 1) | Fail |
| Build and budgets | Every PR | `next build` (export, with `.next/cache` cached [D ci-build-caching]); `check-budgets` | Fail |
| Journeys | Every PR | Playwright (Chromium, WebKit, Firefox) on `out/`: direct entry, refresh, back/forward, `?show=` reload and history, `#pub-*` and `#lab-*` deep links, 404, skip link, menu, copy email (clipboard permission), no-JS, reduced motion, zero console errors | Fail |
| Accessibility | Every PR | axe matrix, rendered contrast, 320 px reflow, text spacing | Fail |
| Visual | Every PR | Screenshots at **390, 768, 1024, 1440** (plus 2560 and 390×667 per the owner's draft), each lab chapter and menu state; canvas masked, poster compared; fonts ready and animations disabled; run in the Playwright Docker image for stable rendering | Fail; update on approval |
| Performance | Every PR | LHCI (DevTools throttling) and the Playwright perf and raw-input specs. GPU-less runners need `--use-angle=swiftshader --enable-unsafe-swiftshader` to run WebGL (verify on the runner). Test the no-WebGL path deliberately too. | Structural: fail. Timing: §3 |
| Links | Nightly and before release | lychee over `out/`; internal anchors on every PR; external 403s count as "unverifiable" (IA) | Internal: fail. External: warn |
| Preview | Each deploy | curl the preview URL for CSP, HSTS, `X-Robots-Tag`, `og:image` content type, and the 404 status | Fail |
| Production | Daily | Synthetic smoke (§6) | Opens an issue |

**The standard's three passes**, each logged as issue → route/state/viewport → fix → re-verification:
1. **Structure and truth:** the journeys job, `check-content`, and a manual read-through of every fact against its source.
2. **Interaction and accessibility:** the static, accessibility, and no-JS jobs, plus the manual keyboard, screen reader,
   zoom, and reduced-motion runs.
3. **Visual craft:** the screenshot matrix reviewed at three scales, one run on a real mid-range Android phone and on the
   client's own phone, and real link previews.

## 8. Risks and milestones

| Risk | Mitigation |
| --- | --- |
| The hero's main-thread cost on mid-range phones (1.1 s tap delays measured) | Worker, idle and capability gating, `compileAsync`, poster first; the raw-input CI test |
| WebGL variance (blocklists, context loss, iOS memory) | Poster fallback, `webglcontextlost` handling, low-power path, CI runs both paths |
| Namesake papers or unconfirmed facts reaching the page | DOI-only curation, `Fact.confirmed` gate, ORCID watcher, human merge |
| Next 16 churn and experimental flags (`inlineCss`, `sri`) | Pin exact versions; adopt a flag only with a measured win and CI coverage; read the upgrade guide on every bump |
| Export gaps (headers, redirects, and images need host config; metadata routes need `force-static`) | Everything verified in `tools/hero-export`; host files checked on each preview |
| Hosting terms change or budget changes | The export is portable: any host with headers support works (same `out/`) |
| A non-developer edit breaks the build | Form workflows, previews, required CI |
| The current affiliation is stale or inconsistent across Scholar, the site, and metadata | One `person.ts` source feeding everything; the client updates Scholar |
| Contrast over the canvas regresses silently | Rendered-contrast script in every lab chapter state |
| The published email gets harvested | She already publishes it (visible, with Copy email, on the old site); keep it out of JSON-LD |

| Milestone | Scope | Effort (engineering days) | Exit |
| --- | --- | --- | --- |
| M0 Foundation | Git and repo, CI skeleton, budget script, `.nvmrc`, pinned dependencies, font option A | 1 | Green CI; preloaded fonts ≤ 230 KiB |
| M1 Hero hardening | Visible header and console in the server HTML, poster pipeline and `<picture>`, gated three.js load, worker, `compileAsync`, Motion confinement, font option B, skip link, menu, `#lab-*` links, `bone-faint` fix; `inlineCss` trial | 3–4 | §2.7 acceptance and §3 budgets met |
| M2 Content and pipeline | Types and modules, `check-content`, enrichment and snapshot, ORCID watcher, `/publications.bib`, form workflows, `CONTENT.md` | 2–3 | 15 records validated; the "Add a paper" dry run works |
| M3 Sections | Research, Publications (filter, cite, anchors), About, Contact, footer, sticky index, 404, figure pipeline | 4–6 | Journeys and axe green at 4 widths |
| M4 SEO and sharing | Metadata helper, JSON-LD, sitemap, robots, manifest, icons, OG pipeline | 1 | Validators and link-preview tools pass |
| M5 Hosting and ops | Wrangler, `_headers`, `_redirects`, domain, HSTS, analytics, uptime, synthetic smoke, rollback drill | 1 | Preview checks green; rollback tested |
| M6 QA | Visual baselines, LHCI calibration, rendered-contrast tool, lychee, three passes, real devices, fixes | 3–4 | No open P0/P1 defects |
| M7 Launch | DNS cutover, Search Console, old-site decision, inbound links, 28-day RUM review | 0.5–1 | Field p75 within §3 |
| **Total** | | **15.5–21** | |

## 9. Questions for the client (engineering)

1. Which domain, and who owns the registrar and Cloudflare accounts? (Recommended: she does.)
2. Budget: $0 (Cloudflare), or paid hosting? Is anyone paid to build or maintain the site? That decides whether Vercel
   Hobby is even allowed.
3. Analytics: cookieless Cloudflare Web Analytics, or none?
4. Which GitHub account owns the repository, and who receives uptime and smoke-test alerts?
5. The old site: unpublish after launch, or keep it private with a pointer?
6. SynapSeek's URL for `worksFor` (or omit it)? Is LinkedIn in `sameAs` fine?
7. Will she update her Scholar affiliation and homepage, and add her missing works to ORCID, at launch?
8. Which phone does she use, so it can be included in the real-device pass?

## Appendix A. Next.js docs relied on

All paths are under `research-hero/node_modules/next/dist/docs/01-app/`:

- **Upgrading and deployment.** `02-guides/upgrading/version-16.md` covers:
  - browsers and Node version;
  - Turbopack by default;
  - async `params` for OG images and `id` for sitemaps;
  - the `next/image` changes;
  - separate dev and build output;
  - `next lint` removed.

  Also: `01-getting-started/17-deploying.md`, `02-guides/static-exports.md`.
- **Metadata.** `01-getting-started/14-metadata-and-og-images.md`, `03-api-reference/04-functions/generate-metadata.md`,
  and in `03-api-reference/03-file-conventions/01-metadata/`: `opengraph-image.md`, `sitemap.md`, `robots.md`,
  `manifest.md`, `app-icons.md`, `index.md`. Also `03-api-reference/04-functions/image-response.md` and
  `02-guides/json-ld.md`.
- **Fonts and images.** `03-api-reference/02-components/font.md`, `03-api-reference/02-components/image.md`.
- **Rendering and caching.** `03-api-reference/03-file-conventions/02-route-segment-config/index.md`,
  `02-guides/caching-without-cache-components.md`, `03-api-reference/05-config/01-next-config-js/cacheComponents.md`,
  `03-api-reference/04-functions/use-search-params.md`, `02-guides/lazy-loading.md`.
- **Security and config.** `02-guides/content-security-policy.md`, and in `03-api-reference/05-config/01-next-config-js/`:
  `inlineCss.md`, `output.md`, `redirects.md`, `headers.md`, `poweredByHeader.md`, `compress.md`.
- **Tooling and testing.** `02-guides/package-bundling.md`, `03-api-reference/06-cli/next.md`
  (`experimental-analyze`), `03-api-reference/03-file-conventions/not-found.md`,
  `03-api-reference/03-file-conventions/instrumentation-client.md`, `02-guides/testing/playwright.md`,
  `02-guides/ci-build-caching.md`.

## Appendix B. Evidence in `plan/tools/`

- **Scripts:** `measure.mjs`, `inp-raw.mjs`, `inp-stress.mjs`, `filmstrip.mjs`, `nojs.mjs`, `axe.mjs`,
  `csp-test.mjs`, `budget-check.mjs` (+ `budgets.example.json`), `attribute.mjs`, `still.mjs`, `poster.mjs`,
  `worker-check.mjs`, `fonts/analyze.py`, `fonts/og_static.py`.
- **Results:** `result-*.json`, `lh/*.json`, `axe-results.json`, `crossref-probe.json`.
- **Images:** `filmstrip.png`, `m4x.png`, `m4x-nowebgl.png`, `og-prototype.png`, `og-prototype-q82.jpg`, `posters/`.
- **Throwaway project copies:**
  - `hero-build` (baseline);
  - `hero-export` (static export with metadata routes and OG);
  - `hero-csp` (headers);
  - `hero-inline` (`inlineCss`);
  - `hero-fonts` (italic split and worker);
  - `hero-maps` (source maps).

  All servers I started are stopped. The copies can be deleted.
