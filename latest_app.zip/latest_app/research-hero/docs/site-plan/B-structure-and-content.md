# 02 · Information architecture and content plan (everything beyond the hero)

Role: IA and content strategy. Date of research: 27 September 2026. Evidence tags: **[T]** text read from a page, API
or file; **[V]** visually inspected screenshot; **[S]** search-result snippet, used only as a lead. Unknown facts are
marked **[TO CONFIRM]** and listed in section 6.

## 0. What matters most

1. **The current affiliation is unverified and may be stale.** The hero says "Johns Hopkins University" in the present
   tense. Google Scholar still shows Johns Hopkins with a verified jh.edu email [T]. The client's ORCID record lists
   "Postdoctoral Fellow, Electrical and Computer Engineering, Johns Hopkins University, 2025-02 to 2026-01" [T]. The
   PULSE Lab People page lists "Madhavi Tripathi, 2024-2025" under Alumni & Former Mentees → Postdocs [T]. Launch is
   blocked on question P0-1. Role, affiliation, and imaging-copy tense must come from one confirmed field.
2. **15 items, 14 DOIs, plus one preprint version.** By theme: 6 delivery, 5 imaging, and 4 other or earlier items.
   Seven are first-author, counting the sole-authored thesis. The client is second or third author on every imaging
   paper, but Radiology Advances publishes her CRediT roles (data curation, formal analysis, investigation, software,
   validation, and review and editing). The site should state roles, not only author position.
3. **Other researchers share the name.** At least two other researchers publish as "Madhavi Tripathi" (nuclear
   medicine PET/CT; e-learning) [T, Crossref]. OpenAlex also attaches a nuclear-medicine researcher's ORCID
   (0000-0003-1033-1690) to three of the client's papers [T]. Publications must be curated by hand, never imported by
   name. Metadata and JSON-LD `sameAs` must disambiguate.
4. **Three imaging papers are CC BY 4.0** (Radiology Advances, npj Imaging, and J. Biomed. Opt.), so their figures can
   be reused with credit. The delivery papers (ACS, Elsevier) are subscription-only, so featured images there need
   client-owned images or confirmed author rights.
5. **The thesis cannot be read publicly.** The IISc record returns "accessible only within the IISc network" [T].
6. **IA gaps in the current build.** On phones the header shows only "Contact" [V 14_mobile_top.png; T hero.tsx
   l.185]. Past the hero, no navigation remains, because the header scrolls away with it. No skip link bypasses the
   lab's ~15 controls. Placeholder text uses `bone-faint` (4.22:1 on void, which fails AA; `bone-muted` is 8.12:1).
7. **Decision.** A single long page with anchors, plus four small utility routes. Navigation: Research · Publications ·
   About · Contact.

## 1. Content inventory

Method:
- Scholar profile HTML with `pagesize=100` returned all 15 rows, so "show more" was unnecessary. I also read each
  item's detail page.
- Crossref supplied DOIs, dates, licenses, and publisher-deposited ORCIDs; OpenAlex supplied open-access status.
- The ORCID public API was read for its professional sections only, plus the publisher pages.
- PULSE Lab pages were read as DOM text in the browser pane, because curl and fetch got 403.
- No personal details were collected.

### 1.1 Profile facts (public, professional)

| Fact | Found | Source | Site status |
| --- | --- | --- | --- |
| Name | Madhavi Tripathi | Scholar [T] | Use |
| Scholar line | "Johns Hopkins University"; "Verified email at jh.edu"; no homepage link set | Scholar HTML [T] | Current? P0-1 |
| Scholar keywords | Bioengineering, Nanotheranostics, Bioimaging, Photothermal therapy, Optoacoustic imaging | Scholar [T] | Context only |
| Metrics (27 Sep 2026) | Citations 104 (98 since 2021), h-index 7 (6), i10-index 3 (3) | Scholar [T] | Do not display (3.4) |
| Postdoc | Postdoctoral Fellow, Dept. of Electrical and Computer Engineering, Johns Hopkins University, 2025-02 → 2026-01 | ORCID 0000-0002-4736-9134 [T] | End date conflicts with present-tense hero |
| Lab news | 02/01/2025 "Welcome to Madhavi Tripathi": joined as a postdoc after completing PhD requirements, Dept. of Materials Engineering, IISc Bengaluru | pulselab.jhu.edu post [T] | News item; PhD source |
| Lab roster | Alumni & Former Mentees → Postdocs: "Madhavi Tripathi, 2024-2025" (no later position listed) | pulselab.jhu.edu/people [T] | P0-1 |
| PhD | Indian Institute of Science, Dept. of Materials Engineering, "PhD", 2018-08 → 2024-12 | ORCID [T] | Year awarded P1-9 |
| Imaging-paper affiliation | Dept. of Electrical and Computer Engineering, Johns Hopkins University | Radiology Advances, npj Imaging, JBO (PMC) [T] | Use as history |
| 2015 affiliation | Dept. of Applied Science, IIIT Allahabad | JBM 2015 article page [T] | Degree P1-10 |
| ORCID | 0000-0002-4736-9134, deposited by publishers on 4 papers; the record lists 4 of 15 works | Crossref, ORCID [T] | Show if confirmed |
| Old site | Every path returns 401 (ChatGPT login) | curl, 27 Sep 2026 [T] | Content unavailable |

### 1.2 Publications: bibliographic record

Author lists are in citation form, with the client in bold. Titles are shown in the site's sentence case with wording
unchanged and formulas corrected (Crossref prints "Cus" for CuS in D3).

| ID | Year | Title | Authors | Venue and details | Type | DOI / URL |
| --- | --- | --- | --- | --- | --- | --- |
| D1 | [TO CONFIRM] | Thermoresponsive CuS based nanocomposites mimicking red blood cells for combinatorial therapy and photoacoustic imaging | **Tripathi M** | PhD thesis, Indian Institute of Science, Bengaluru | Thesis | etd.iisc.ac.in/handle/2005/6575 (IISc network only) |
| D2 | 2025 | Mucin-capped CuS nanoparticles for mitochondrial targeted NIR-II photothermal therapy and photoacoustic imaging | **Tripathi M**, Sharma A, Ajisafe VA, Sinharay S, Raichur AM | Journal of Drug Delivery Science and Technology 105, 106668 | Journal article | 10.1016/j.jddst.2025.106668; preprint 10.2139/ssrn.4972313 (SSRN, 2024) |
| D3 | 2024 | Effect of PVP molecular weights on the synthesis of ultrasmall CuS nanoflakes: synthesis, properties, and potential application for phototheranostics | **Tripathi M**, Sharma A, Sinharay S, Raichur AM | ACS Applied Bio Materials 7(3), 1671–1681 | Journal article | 10.1021/acsabm.3c01123 |
| D4 | 2023 | Seed-mediated galvanic synthesis of CuS–Au nanohybrids for photo-theranostic applications | **Tripathi M**, Padmanabhan S, Prakash J, Raichur AM | ACS Applied Nano Materials 6(16), 14861–14875 | Journal article | 10.1021/acsanm.3c02405 |
| D5 | 2023 | Thermoresponsive nanocomposite hydrogels: tunable systems for localized cancer theranostics | **Tripathi M**, Mafibaniasadi Z, Raichur AM | In *Functional Nanocomposite Hydrogels* (Elsevier), 453–477 | Book chapter | 10.1016/B978-0-323-99638-9.00019-8 |
| D6 | 2021 | Biopolymer matrix composite for drug delivery applications in cancer | Jain A, **Tripathi M**, Prajapati SK, Raichur AM | In *Encyclopedia of Materials: Composites* (Elsevier), 804–817 | Book chapter (reference entry) | 10.1016/B978-0-12-819724-0.00028-8 |
| I1 | 2026 | In vivo photoacoustic breast imaging and the interactive effects of skin tone, wavelength, beamformer, and depth on target detectability | Enslein J, **Tripathi M**, Panigrahi B, Myers K, Wei Chen J, Timaná J, Ambinder E, Bell MAL | npj Imaging (online 4 Sep 2026; no volume or article number shown yet) | Journal article | 10.1038/s44303-026-00193-4 |
| I2 | 2026 | Pigmentation-dependent skin injury thresholds with nanosecond single-pulse laser exposure | Arroyo J, Zhang J, **Tripathi M**, Zhang J, Venkatayogi N, Enslein J, Bell MAL | Journal of Biomedical Optics 31(8), 085001 | Journal article | 10.1117/1.JBO.31.8.085001; PMC13452404 |
| I3 | 2026 | Comparison of skin tone and target detectability in simulated, tissue-mimicking phantom, and clinical photoacoustic breast images | Enslein J, **Tripathi M**, Panigrahi B, Myers K, Bell MAL | Proc. SPIE 13851, Photons Plus Ultrasound: Imaging and Sensing 2026, 1385103; SPIE Photonics West, San Francisco, 17–22 Jan 2026 | Conference paper | 10.1117/12.3081139 |
| I4 | 2026 | Learning from skinless datasets to improve target detectability in photoacoustic breast imaging across skin tones | Drabek JU, **Tripathi M**, Enslein J, Myers K, Panigrahi B, Bell MAL | Proc. SPIE 13851, 138510N | Conference paper | 10.1117/12.3083562 |
| I5 | 2025 | Generalized contrast-to-noise ratio applied to short-lag spatial coherence ultrasound differentiates breast cysts from solid masses | Sharma A, Oluyemi ET, **Tripathi M**, Ambinder EB, Mullen LA, Panigrahi B, Rossi J, Venkatayogi N, Myers KS, Bell MAL | Radiology Advances 2(6), umaf037 (online 24 Oct 2025) | Journal article | 10.1093/radadv/umaf037 |
| O1 | 2022 | Curing behavior and mechanical properties of tetra-functional epoxy reinforced with polyethyleneimine-functionalized MXene | Wazalwar R, **Tripathi M**, Raichur AM | ACS Applied Polymer Materials 4(4), 2573–2584 | Journal article | 10.1021/acsapm.1c01876 |
| O2 | 2021 | Exploring the room for repurposed hydroxychloroquine to impede COVID-19: toxicities and multipronged combination approaches with pharmaceutical insights | Jain A, Prajapati SK, **Tripathi M**, Raichur AM, Kanwar JR | Expert Review of Clinical Pharmacology 14(6), 715–734 | Review | 10.1080/17512433.2021.1909473 |
| O3 | 2015 | Genotyping malaria parasites with DNA barcodes | **Tripathi M**, Das A | Tropical Medicine & International Health 20(12), 1636–1638 | Journal article (3 pp.; article type [TO CONFIRM]) | 10.1111/tmi.12594 |
| O4 | 2015 | Stem cell technologies in human health: boon or bane? | **Tripathi M**, Singh S | Journal of Biosciences and Medicines 3(11), 16–24 | Review [TO CONFIRM] | 10.4236/jbm.2015.311002 |

### 1.3 Publications: classification

| ID | Half | Hero chapter and state it supports | First author | Access | Links to show | Note |
| --- | --- | --- | --- | --- | --- | --- |
| D1 | Delivery | Design (all three layers); Delivery (gel carrier, continuous light); Photoacoustics (Nanoparticles) | Sole | Restricted | Thesis record | Abstract opens on lung cancer (NSCLC) and tyrosine kinase inhibitors |
| D2 | Delivery | Design: Core (capping layer); Delivery: continuous light; Photoacoustics: Nanoparticles | Yes | Subscription; preprint | Paper, Preprint | |
| D3 | Delivery | Design: Core (ultrasmall cores, capping layer) | Yes | Subscription | Paper | |
| D4 | Delivery | Design: Core; Delivery: Ultrasmall (abstract: larger hybrids limit deep-tumor use); Photoacoustics: Nanoparticles | Yes | Subscription | Paper | |
| D5 | Delivery | Design: Gel and drug; Delivery: Gel carrier | Yes | Subscription | Paper | Review chapter on heat-responsive nanogels |
| D6 | Delivery | Delivery (context) | No | Subscription | Paper | |
| I1 | Imaging | Photoacoustics: Skin tone × Beamformer | No | Open access, CC BY 4.0 | Paper | Listed under the journal's "Advances in Optoacoustic Imaging" collection |
| I2 | Imaging | Photoacoustics: Skin tone (safe pulsed-light dose) | No | Open access, CC BY 4.0 | Paper, PubMed Central | Swine skin study |
| I3 | Imaging | Photoacoustics: Skin tone × Beamformer | No | PDF hosted by the PULSE Lab (HTTP 200, 2.1 MB) | Paper, PDF | |
| I4 | Imaging | Photoacoustics: Skin tone | No | PDF hosted by the PULSE Lab (HTTP 200, 1.0 MB) | Paper, PDF | Machine-learning method, which the lab does not show |
| I5 | Imaging | Ultrasound: every state; the 0.76 threshold comes from this paper | No | Open access, CC BY 4.0 | Paper | CRediT roles published; 145 masses in 115 patients |
| O1 | Other (materials) | — | No | Subscription | Paper | OpenAlex's "open access" link points to an economics archive (mismatch; ignore) |
| O2 | Other (pharmacology) | — | No | Subscription | Paper | |
| O3 | Earlier | — | Yes | Free to read (publisher) | Paper | |
| O4 | Earlier | — | Yes | Open access, CC BY 4.0 | Paper | |

**Counts.** Types: 10 journal articles (2 of them reviews), 2 conference papers, 2 book chapters, and 1 thesis. The
hero's Photoacoustics "Blood oxygen" state has no supporting paper in this list, so no link from that state may imply
one. Crossref searches by ORCID and by co-author (Raichur, Bell) found nothing beyond Scholar except the SSRN preprint.

## 2. Audiences and journeys

### 2.1 Visitors

| Visitor | Arrives from | Needs in the first minute | What earns trust | Goes to |
| --- | --- | --- | --- | --- |
| PI or hiring committee | Application packet, search for her name | Current role, the two halves, first-author work, CV | Correct and complete list, stated roles, dates, and sources | Publications (First author), About, CV |
| Collaborator (nanomedicine, imaging engineering) | Scholar, a paper, a talk | Methods she has, recent papers, a way to reach her | Lab demos tied to real papers; CRediT roles | Research, Publications, Contact |
| Student or prospective mentee | Lab page, search | What she works on in plain words; whether she mentors | Clarity; mentoring information only if real | Research, About, Contact |
| Clinician (breast imaging, oncology) | Shared paper link, a colleague | The clinical question, the finding, a readable paper | Plain summary, peer-reviewed venue, open-access label | One publication entry |
| Curious non-scientist | Social or messaging share | What she does | Honest "Simulated" labels; no jargon | Hero tour, Research |

### 2.2 Journeys

| Journey | Entry and user action | Observable outcome | Real service or demo data | Relevant failure/recovery |
| --- | --- | --- | --- | --- |
| J1 Assess fit in two minutes (hiring committee) | Search "Madhavi Tripathi" → `/` → reads headline → Publications → Show: First author → About → Download CV | Both halves stated in the first view. The filter shows 7 items, each labeled "First author", with her name in bold. About shows the confirmed role with dates. The PDF downloads, with its size shown on the link. | Real: `publications.ts` from Scholar and Crossref. Role, bio, and CV come from the client (not yet received) | A namesake ranks first: title, description, and JSON-LD `sameAs` (ORCID, Scholar) disambiguate. No CV yet: the CV link is not rendered (no dead link). `?show=first-author` restores on reload, Back, and Forward; an unknown value falls back to All. |
| J2 Check a method, then get in touch (collaborator) | Scholar homepage link (after P2-18) → Research → "See it in the lab: Ultrasound" → switches Beamformer → "Read the paper" → Back → Contact → Copy email | The Ultrasound chapter opens with its gCNR readout. The DOI opens the Radiology Advances article. Back returns to the Research block. "Copied" is announced politely. | Real DOI and CRediT roles; the lab is simulated and labeled so | No WebGL2 or reduced motion: the chapter link still selects the chapter over the hero's fallback. Clipboard blocked: "Couldn't copy. Select the address to copy it." with the address selected. No mail app: the address is visible text. |
| J3 See what she does and whether to write (student) | Lab page or search → hero tour → Research → About → Contact | Plain-language halves; Teaching and mentoring only if provided; an email route | Real; mentoring from the client | No mentoring data: the sub-block is absent, with no "coming soon". No published email: Contact shows the profile links only. |
| J4 Read the evidence (clinician) | Shared `/#pub-sharma-2025-gcnr-slsc` → entry scrolls into view → reads summary → opens Paper | The entry is visible even if a filter was stored. Summary in plain words, labeled "Open access". | Real paper; summary drafted from the abstract (client approves) | Renamed slug: `aliases` keep old anchors working, and an unknown anchor leaves the page at top without error. Publisher outage: the DOI still resolves, and the PubMed Central link is offered where one exists (I2). |
| J5 Share and understand (non-scientist) | Link pasted in a chat → preview → tour → Research bridge line | The preview shows the name, headline, and image (not ChatGPT). Terms are explained on first use. | Real; imagery labeled "Simulated" | Old chatgpt.site links still 401 (outside our control): P2-17 and P2-18. A slow device opens the lab paused, and the text stays complete. |
| J6 Cite a paper (any) | Publications → Cite → Copy BibTeX | BibTeX on the clipboard; status "Copied" | Generated at build from `publications.ts` | Clipboard blocked: the text is shown selected in a read-only field. |

## 3. Information architecture

### 3.1 One long page, not multi-page

Five reasons fit this client:

- **The scope and the hero assume it.** The nav already points to `#research`, `#publications`, and `#contact`. Later
  sections link back into lab chapters, which is cheapest within one page.
- **The volume is small.** Fifteen items, two themes, and one bio fill about five screens after the hero on desktop.
- **Visitors skim.** Anchors and a persistent section index serve committees without page loads.
- **Performance.** Sections below the hero are static server components. three.js is already lazy and pauses
  off-screen.
- **Disambiguation.** One authoritative URL with JSON-LD beats thin per-paper pages that compete with publisher pages.

**When to split.** Move to multi-page when there are more than 40 publications or more than 10 talks. At that point
Publications moves to `/publications`, reusing the same component, and home keeps the featured items plus a link.
Reserve those names now.

### 3.2 Sitemap and URL scheme

```
/                                   Home (one page)
├─ #top                              Hero (exists): headline, lede, lab
│   └─ #lab-design · #lab-delivery · #lab-photoacoustics · #lab-ultrasound   chapter deep links (new)
├─ #research                         Research
│   ├─ #research-delivery             Nanomaterials for delivery
│   └─ #research-imaging              Light and sound for imaging
├─ #publications   (?show=all|delivery|imaging|first-author)
│   └─ #pub-{id}                      one anchor per item (15)
├─ #about                            About: bios, positions and education, optional sub-blocks
├─ #contact                          Contact
└─ footer
/cv                →  308 to /madhavi-tripathi-cv.pdf   (only when the PDF exists; otherwise 404)
/publications.bib  BibTeX for all items, generated at build (P2)
/opengraph-image   1200×630 share image (replaces ChatGPT-branded previews)
/sitemap.xml · /robots.txt · not-found (404)
Reserved, not built: /publications · /talks · /notes
```

URL rules:
- Anchor IDs are lowercase and hyphenated, and they never change. A renamed publication keeps its old ID in `aliases`.
- `show` is the only query parameter. It is read client-side inside a Suspense boundary so the page stays static.
  Unknown values mean All.
- Opening `#pub-{id}` resets `show` to All when the filter would hide that entry.
- `#lab-{slug}` maps delivery → `deliver` and photoacoustics → `photoacoustic`. Put the IDs on the chapter toggle
  buttons so the link still lands on the lab without JS. With JS, read the hash on mount and on `hashchange`, then
  select that chapter. After following a lab link, Back returns to the previous position.

### 3.3 Navigation

- **Labels.** Research · Publications · About · Contact. Add About to `profile.nav`. Keep the same order everywhere.
- **Skip link.** "Skip the lab" as the first focusable element, targeting `#research`. The lab puts about 15 stops
  before any content.
- **Phones.** Below the hero's 40rem breakpoint, the header shows a "Menu" button (`aria-expanded`,
  `aria-controls`) that opens an inline list of the four links. Escape and choosing a link both close it and return
  focus. Acceptance: every section is two taps or fewer from the top on a 360 px screen.
- **After the hero.** On all widths, a slim section index with the same labels appears once the hero leaves the
  viewport. It has `aria-label="Sections"` and puts `aria-current="location"` on the active section.
  `scroll-margin-top` equals its height, so focused content is never covered. Under reduced motion it has no slide.
- **Group order everywhere:** delivery before imaging, matching the headline, the chapters, and Research.

### 3.4 Sections

**Research (`#research`).**
- *Purpose:* state the two halves with evidence and wire each one to the lab.
- *Fields:* section deck; per theme, the title (mirroring a headline line), a "where and when" line, body, 4–5 skills,
  lab chips, and 1–2 featured papers (figure, plain summary, role, link); a bridge line placed between the two themes.
- *Empty state:* the section always renders. A featured paper without a cleared figure becomes a typographic card
  (title, summary, role). No stock images, and never a simulated lab image beside a real paper.
- *Premium, not generic:* skills read as work done, not keyword tags, and every claim is one click from its paper.
  The bridge line acts as a typographic hinge. Accent color is only a secondary cue (pulse for delivery, echo for
  imaging); text carries the meaning. "Selected work" lives here, so no separate gallery repeats the list.
- *Featured (proposed):* imaging I5 and I1 (both open access). Delivery D2 and D4, with D3 and D1 as alternates
  (client picks).

**Publications (`#publications`).**
- *Purpose:* the complete, correct record.
- *Fields:* entries per the model in section 4. A segmented "Show" control (All, Delivery, Imaging, First author) with
  derived counts, reusing the lab's segmented-control component. Groups in All: Nanomaterials for delivery (6), Light
  and sound for imaging (5), and "Other and earlier work" (4, collapsed). Reverse-chronological within groups; First
  author is a flat reverse-chronological list. A "checked on" line with the Scholar link.
- *Empty state:* "Nothing in this view yet." with a "Show all" button.
- *Without JS:* the full list renders and the control is hidden.
- *Premium, not generic:*
  - Hand-curated so no namesake items slip in; full author lists with her name in bold.
  - "First author" and "Open access" as text labels.
  - A "My role" line, from CRediT where published and otherwise the client's own words.
  - "In the lab" chips; Cite (plain text and BibTeX); stable anchors; years in the tabular cut, like the lab's
    readouts.
  - Deliberately left out: citation counts, impact factors, journal logos, and per-entry thumbnails.
  - Author, venue, and date lines use `bone-muted` (8.12:1), never `bone-faint`.

**About (`#about`).**
- *Purpose:* who she is, in order.
- *Fields:* headshot; short bio (third person, with a "Copy short bio" button for talk organizers); long bio (first
  person); "Positions and education" timeline with a source per row; CV link. Optional sub-blocks, each rendered only
  with at least one confirmed item: Talks (only talks she presented), Awards and fellowships, Teaching and mentoring,
  News (only when there are at least 2 items that aren't publications).
- *Empty state:* no headshot means a text-first layout, never a silhouette avatar.
- *Premium, not generic:* dated and sourced; no skill bars, no "passionate", no icon grids.

**Contact (`#contact`).**
- *Purpose:* one clear channel.
- *Fields:* deck; email as visible text plus "Copy email"; text-labeled links (Google Scholar, ORCID, and LinkedIn if
  confirmed); CV. PULSE Lab link only if she is still a member.
- *Empty state:* without a confirmed email, the profile links still render.
- *No form:* there is no backend, so a form could produce false "sent" states.

**Footer.**
- Name and confirmed role line.
- "The lab images are simulations for explanation, not measurements." (from the README)
- Figure credits (derived from the figures used).
- "Updated September 2026" (the content date), Back to top, and © year.

**404 (`not-found.tsx`).** Voice-consistent, short, with three exits (5.4).

**CV.** At launch, a PDF with a descriptive filename, linked from About and Contact, plus the `/cv` redirect for email
signatures. An HTML CV page is P2.

### 3.5 Wiring the hero to the themes and papers

Rule: **chapters link to papers, and papers link back to chapters.** Each chapter gets one evidence link below its
caption. The label says where it goes.

| Chapter | Evidence | Chapter link | Chips on the entries |
| --- | --- | --- | --- |
| Design | D3, D2, D4 (Core); D5, D1 (Gel and drug); D1 (Membrane coat) | "See the papers" → `/?show=delivery#publications` | "In the lab: Design" |
| Delivery | D4 (size limits deep reach), D1, D5, D6 | "See the papers" → `/?show=delivery#publications` | "In the lab: Delivery" |
| Photoacoustics | I1, I3, I4 (skin tone × beamformer); I2 (safe pulsed light); D2, D3, D4, D1 (Nanoparticles) | "Read the paper · npj Imaging, 2026" → doi.org/10.1038/s44303-026-00193-4 | "In the lab: Photoacoustics" |
| Ultrasound | I5 (source of the 0.76 threshold) | "Read the paper · Radiology Advances, 2025" → doi.org/10.1093/radadv/umaf037 | "In the lab: Ultrasound" |

The Research themes link to the same chapters ("See it in the lab: Design", and so on). The I5 entry carries the note
"The lab's 0.76 threshold comes from this study." (paper: "a gCNR threshold of 0.76 selected to distinguish fluid from
solid masses" [T]).

## 4. Content model

Files: keep `src/content/profile.ts` as the hero's API and derive it from `person.ts`, so hero components stay
untouched. Add `types.ts`, `person.ts`, `themes.ts`, `publications.ts`, `figures.ts`, and `about.ts` (talks, awards,
teaching, news). Add `CHAPTER_EVIDENCE` to `chapters.ts`.

```ts
// src/content/types.ts
import type { SkillChapter } from "@/lab/state"; // "design" | "deliver" | "photoacoustic" | "ultrasound"

export type ThemeId = "delivery" | "imaging";
export type PubType = "journal-article" | "review" | "conference-paper" | "book-chapter" | "thesis";
export type Access = "open-access" | "free-to-read" | "lab-pdf" | "subscription" | "restricted";
export type CreditRole =
  | "Conceptualization" | "Data curation" | "Formal analysis" | "Funding acquisition" | "Investigation"
  | "Methodology" | "Project administration" | "Resources" | "Software" | "Supervision" | "Validation"
  | "Visualization" | "Writing – original draft" | "Writing – review & editing";

/** A statement about the client. Unconfirmed facts never render in a production build. */
export interface Fact<T = string> {
  value: T;
  source?: string;    // URL we read it from
  confirmed: boolean; // true only after the client confirms
}

export interface Link {
  kind: "doi" | "pdf" | "preprint" | "pmc" | "record" | "scholar" | "orcid" | "lab" | "linkedin" | "email" | "cv";
  href: string;
  label: string;      // visible: "Paper", "PDF", "Preprint", "PubMed Central", "Thesis record"
  note?: string;      // e.g. "Hosted by the PULSE Lab", "IISc network only"
}

export interface Author { name: string /* citation form, "Tripathi M" */; me?: true }

export interface Publication {
  id: string;                       // slug and #pub-{id}; never renamed without an alias
  aliases?: string[];
  title: string;                    // wording verbatim; sentence case; formulas corrected
  authors: Author[];
  type: PubType;
  venue: string;
  details?: string;                 // "7(3), 1671–1681"
  publisher: string;
  published: { year: number | null; month?: number; day?: number }; // first public date; null = unknown
  doi?: string;
  links: Link[];
  access: Access;
  license?: "CC BY 4.0";
  themes: ThemeId[];                // [] = "Other and earlier work"
  chapters: SkillChapter[];         // renders "In the lab" chips
  role?: { credit: CreditRole[]; source: string } | { text: Fact };
  summary?: Fact;                   // plain language, ≤ 240 characters, "we" voice
  featured?: boolean;
  figureId?: string;
  note?: string;
}
// Derived, never stored: firstAuthor = authors[0]?.me === true; filter counts; group order.

export interface Figure {
  id: string; src: string; width: number; height: number; alt: string; caption: string;
  credit: string;                   // "From Sharma et al., Radiology Advances, 2025, fig. [n], cropped. CC BY 4.0."
  license: "CC BY 4.0" | "author-owned" | "permission-granted";
  sourceUrl: string;
  focal?: { x: number; y: number };
}

export interface Position { title: Fact; org: string; unit?: string; group?: string; start: Fact; end?: Fact }
export interface Education { degree: Fact; org: string; unit?: string; end?: Fact; thesisId?: string; advisors?: Fact<string[]> }

export interface Person {
  name: string;
  affiliation: Fact;                // the line under the name in the header
  role: Fact;
  bioShort: Fact;                   // third person, ≤ 50 words, copyable
  bioLong: Fact;                    // first person, ≤ 160 words
  next?: Fact;                      // "what's next", in the client's words
  headshot?: Figure;
  email?: Fact;
  ids: { orcid?: Fact; scholar: string };
  links: Link[];
  positions: Position[];
  education: Education[];
}

export interface ResearchTheme {
  id: ThemeId;
  title: string;                    // mirrors a headline line
  where: Fact;
  body: string;                     // ≤ 70 words
  skills: string[];                 // 4–5, ≤ 48 characters each
  chapters: SkillChapter[];
  featured: string[];               // publication ids, 1–2
  accent: "pulse" | "echo";         // secondary cue only
}

export interface Talk { id: string; title: string; event: string; city?: string; date: string;
  kind: "invited" | "oral" | "poster" | "seminar"; presenter: true; publicationId?: string; confirmed: boolean }
export interface Award { id: string; name: string; body: string; year: number; confirmed: boolean }
export interface NewsItem { id: string; date: string; text: string; href?: string; confirmed: boolean }
```

Example records (real data; unknowns flagged):

```ts
// src/content/publications.ts (5 of 15)
export const publications: Publication[] = [
  {
    id: "sharma-2025-gcnr-slsc",
    title: "Generalized contrast-to-noise ratio applied to short-lag spatial coherence ultrasound differentiates breast cysts from solid masses",
    authors: [{ name: "Sharma A" }, { name: "Oluyemi ET" }, { name: "Tripathi M", me: true }, { name: "Ambinder EB" },
      { name: "Mullen LA" }, { name: "Panigrahi B" }, { name: "Rossi J" }, { name: "Venkatayogi N" },
      { name: "Myers KS" }, { name: "Bell MAL" }],
    type: "journal-article",
    venue: "Radiology Advances",
    details: "2(6), umaf037",
    publisher: "Oxford University Press for the Radiological Society of North America",
    published: { year: 2025, month: 10, day: 24 },
    doi: "10.1093/radadv/umaf037",
    links: [{ kind: "doi", label: "Paper", href: "https://doi.org/10.1093/radadv/umaf037" }],
    access: "open-access",
    license: "CC BY 4.0",
    themes: ["imaging"],
    chapters: ["ultrasound"],
    role: {
      credit: ["Data curation", "Formal analysis", "Investigation", "Software", "Validation", "Writing – review & editing"],
      source: "https://academic.oup.com/radadv/article/2/6/umaf037/8300868",
    },
    summary: {
      value: "Cysts and solid masses can look alike in standard ultrasound images, which leads to false alarms. Measuring contrast (gCNR) on coherence-beamformed images separated them better than reading the standard images by eye.",
      source: "https://academic.oup.com/radadv/article/2/6/umaf037/8300868",
      confirmed: false, // drafted from the abstract's conclusion; client approves
    },
    featured: true,
    note: "The lab's 0.76 threshold comes from this study.",
  },
  {
    id: "enslein-2026-spie-skin-tone",
    title: "Comparison of skin tone and target detectability in simulated, tissue-mimicking phantom, and clinical photoacoustic breast images",
    authors: [{ name: "Enslein J" }, { name: "Tripathi M", me: true }, { name: "Panigrahi B" }, { name: "Myers K" }, { name: "Bell MAL" }],
    type: "conference-paper",
    venue: "Proc. SPIE 13851, Photons Plus Ultrasound: Imaging and Sensing 2026",
    details: "1385103",
    publisher: "SPIE",
    published: { year: 2026, month: 3, day: 4 },
    doi: "10.1117/12.3081139",
    links: [
      { kind: "doi", label: "Paper", href: "https://doi.org/10.1117/12.3081139" },
      { kind: "pdf", label: "PDF", href: "https://pulselab.jhu.edu/wp-content/uploads/2026/03/Enslein_SPIE_2026.pdf", note: "Hosted by the PULSE Lab" },
    ],
    access: "lab-pdf",
    themes: ["imaging"],
    chapters: ["photoacoustic"],
    role: { text: { value: "", confirmed: false } }, // [TO CONFIRM] one line from the client
  },
  {
    id: "tripathi-2025-mucin-capped",
    title: "Mucin-capped CuS nanoparticles for mitochondrial targeted NIR-II photothermal therapy and photoacoustic imaging",
    authors: [{ name: "Tripathi M", me: true }, { name: "Sharma A" }, { name: "Ajisafe VA" }, { name: "Sinharay S" }, { name: "Raichur AM" }],
    type: "journal-article",
    venue: "Journal of Drug Delivery Science and Technology",
    details: "105, 106668",
    publisher: "Elsevier",
    published: { year: 2025, month: 3 },
    doi: "10.1016/j.jddst.2025.106668",
    links: [
      { kind: "doi", label: "Paper", href: "https://doi.org/10.1016/j.jddst.2025.106668" },
      { kind: "preprint", label: "Preprint", href: "https://doi.org/10.2139/ssrn.4972313", note: "SSRN, 2024" },
    ],
    access: "subscription",
    themes: ["delivery"],
    chapters: ["design", "deliver", "photoacoustic"],
    summary: {
      value: "We capped ultrasmall light-absorbing particles with mucin, a natural molecule not used this way before, and tagged them to reach mitochondria. They stayed stable, heated under light, and gave photoacoustic contrast.",
      source: "https://doi.org/10.1016/j.jddst.2025.106668",
      confirmed: false,
    },
    featured: true,
  },
  {
    id: "tripathi-2024-ultrasmall-cores",
    title: "Effect of PVP molecular weights on the synthesis of ultrasmall CuS nanoflakes: synthesis, properties, and potential application for phototheranostics",
    authors: [{ name: "Tripathi M", me: true }, { name: "Sharma A" }, { name: "Sinharay S" }, { name: "Raichur AM" }],
    type: "journal-article",
    venue: "ACS Applied Bio Materials",
    details: "7(3), 1671–1681",
    publisher: "American Chemical Society",
    published: { year: 2024, month: 3, day: 6 },
    doi: "10.1021/acsabm.3c01123",
    links: [{ kind: "doi", label: "Paper", href: "https://doi.org/10.1021/acsabm.3c01123" }],
    access: "subscription",
    themes: ["delivery"],
    chapters: ["design"],
  },
  {
    id: "tripathi-phd-thesis",
    title: "Thermoresponsive CuS based nanocomposites mimicking red blood cells for combinatorial therapy and photoacoustic imaging",
    authors: [{ name: "Tripathi M", me: true }],
    type: "thesis",
    venue: "PhD thesis, Department of Materials Engineering, Indian Institute of Science, Bengaluru",
    publisher: "Indian Institute of Science",
    published: { year: null }, // [TO CONFIRM] year awarded (ORCID: PhD 2018-08 to 2024-12)
    links: [{ kind: "record", label: "Thesis record", href: "https://etd.iisc.ac.in/handle/2005/6575", note: "IISc network only" }],
    access: "restricted",
    themes: ["delivery"],
    chapters: ["design", "deliver", "photoacoustic"],
  },
];

// src/content/themes.ts (1 of 2)
export const imaging: ResearchTheme = {
  id: "imaging",
  title: "Light and sound for imaging",
  where: { value: "Postdoc, Johns Hopkins University, from 2025", source: "https://pulselab.jhu.edu/2025/02/01/welcome-to-madhavi-tripathi/", confirmed: false },
  body: "In Muyinatu Bell's PULSE Lab at Johns Hopkins, I work on making photoacoustic and ultrasound images of the breast clearer. We measure contrast objectively (gCNR) on coherence-beamformed ultrasound to tell cysts from solid masses. We also study how skin tone changes what photoacoustic imaging can detect, and how much pulsed light skin of different tones can safely take.",
  skills: ["Coherence (SLSC) and delay-and-sum beamforming", "Objective image-quality measures, such as gCNR",
    "Curating and analyzing patient imaging data", "Research software for image analysis", "Skin-tone effects in photoacoustic imaging"],
  chapters: ["photoacoustic", "ultrasound"],
  featured: ["sharma-2025-gcnr-slsc", "enslein-2026-npj-skin-tone"],
  accent: "echo",
};

// src/content/person.ts (excerpt)
export const person: Person = {
  name: "Madhavi Tripathi",
  affiliation: { value: "Johns Hopkins University", source: "https://scholar.google.com/citations?user=zZx1Td0AAAAJ&hl=en", confirmed: false },
  role: { value: "Postdoctoral Fellow, Electrical and Computer Engineering", source: "https://orcid.org/0000-0002-4736-9134", confirmed: false },
  bioShort: { value: "…see 5.4…", confirmed: false },
  bioLong: { value: "…see 5.4…", confirmed: false },
  ids: {
    orcid: { value: "0000-0002-4736-9134", source: "https://api.crossref.org/works/10.1093/radadv/umaf037", confirmed: false },
    scholar: "https://scholar.google.com/citations?user=zZx1Td0AAAAJ&hl=en",
  },
  links: [{ kind: "scholar", label: "Google Scholar", href: "https://scholar.google.com/citations?user=zZx1Td0AAAAJ&hl=en" }],
  positions: [{
    title: { value: "Postdoctoral Fellow", source: "https://orcid.org/0000-0002-4736-9134", confirmed: false },
    org: "Johns Hopkins University", unit: "Department of Electrical and Computer Engineering", group: "PULSE Lab (Muyinatu Bell)",
    start: { value: "2025-02", source: "https://pulselab.jhu.edu/2025/02/01/welcome-to-madhavi-tripathi/", confirmed: false },
    end: { value: "2026-01", source: "https://orcid.org/0000-0002-4736-9134", confirmed: false }, // conflicts with hero tense
  }],
  education: [{
    degree: { value: "PhD", source: "https://pulselab.jhu.edu/2025/02/01/welcome-to-madhavi-tripathi/", confirmed: false },
    org: "Indian Institute of Science, Bengaluru", unit: "Department of Materials Engineering",
    end: { value: "2024", source: "https://orcid.org/0000-0002-4736-9134", confirmed: false },
    thesisId: "tripathi-phd-thesis",
    advisors: { value: ["Ashok M. Raichur"], confirmed: false }, // per brief; IISc record not public
  }], // [TO CONFIRM] earlier degree(s): the 2015 JBM paper lists IIIT Allahabad, Dept. of Applied Science
};

// src/content/about.ts
export const news: NewsItem[] = [{
  id: "2025-02-pulse-lab", date: "2025-02-01",
  text: "Joined Muyinatu Bell's PULSE Lab at Johns Hopkins as a postdoctoral fellow.",
  href: "https://pulselab.jhu.edu/2025/02/01/welcome-to-madhavi-tripathi/", confirmed: false,
}];

// src/content/chapters.ts (addition)
export const CHAPTER_EVIDENCE: Record<SkillChapter, { label: "Read the paper" | "See the papers"; href: string; venue?: string }> = {
  design: { label: "See the papers", href: "/?show=delivery#publications" },
  deliver: { label: "See the papers", href: "/?show=delivery#publications" },
  photoacoustic: { label: "Read the paper", venue: "npj Imaging, 2026", href: "https://doi.org/10.1038/s44303-026-00193-4" },
  ultrasound: { label: "Read the paper", venue: "Radiology Advances, 2025", href: "https://doi.org/10.1093/radadv/umaf037" },
};
```

**Placeholder policy.**
- Content strings never contain "[TO CONFIRM]". Uncertainty lives in `confirmed: false` and `year: null`.
- In production, an unconfirmed `Fact` renders nothing, including its label, and layouts must hold without it.
- `scripts/check-content.ts` lists every unconfirmed fact. It fails `next build` when a required fact is unconfirmed
  (affiliation, role, bioShort, and email or profile links). It also fails on duplicate IDs, wrong counts, and missing
  anchors referenced from `CHAPTER_EVIDENCE`.
- Link checks treat 403 from publisher and lab hosts as "unverifiable", not broken. Those hosts block bots, but they
  returned 200 in a browser.

## 5. Copy plan

### 5.1 Voice rules, extended to the whole site (in addition to MASTER.md)

1. **Person.**
   - "I" for skills and for the theme bodies.
   - "We" in every paper summary, because every paper has co-authors. Individual credit goes only in the "My role"
     line.
   - Third person only in the short bio and in metadata descriptions (search snippets need the name).
2. **Tense.** Present for skills. Past for findings ("Measuring contrast … separated them"). The tense of a position
   follows the confirmed role (P0-1).
3. **The client's rule on materials.** Paper titles stay verbatim, including material names. Everything written
   around them uses the skill vocabulary: no material names, drug names, or wavelengths outside titles.
4. **Claims.** Every finding sentence traces to the paper's abstract or conclusion. No "first", "novel", "breakthrough",
   "cutting-edge", "state-of-the-art", or "passionate", even where a paper uses them.
5. **Numbers.** Keep them out of prose. Allowed in citations, the readout, and the one threshold note (0.76), which
   the paper states.
6. **Link labels promise a destination.**
   - "Read the paper" always leaves the site for the publisher.
   - "See the papers" always stays on the site.
   - "PDF" appears only when a free PDF exists.
7. **Status is text first.** "First author" and "Open access" are words; color is never the only signal.
8. **Dates.** "September 2026" in prose, "2026" in lists, ISO in data.
9. **Names at first mention.** "Johns Hopkins University", then "Johns Hopkins" (never "JHU" in prose). "Indian
   Institute of Science, Bengaluru", then "IISc". "Muyinatu Bell's PULSE Lab".

### 5.2 Glossary additions

| Use | Not | Notes |
| --- | --- | --- |
| photoacoustic imaging | optoacoustic | First use: "photoacoustic imaging, which listens for the sound tissue makes when it absorbs a short light pulse" |
| coherence beamforming; short-lag spatial coherence (SLSC) | SLSC alone | Full name once per section, as in the lab |
| gCNR, "an objective contrast measure (gCNR)" | CNR | Expand to "generalized contrast-to-noise ratio" once, in Research |
| heating tumors with light (photothermal therapy) | PTT | No acronym in prose |
| treat and image with one particle | theranostics, phototheranostic | Titles only |
| light-absorbing particles, cores | CuS, copper sulfide, nanoflakes, nanohybrids | Titles only |
| heat-responsive gel | thermoresponsive hydrogel, nanogel | Titles only |
| skin tone | skin color, complexion | "pigmentation" only when paraphrasing I2; ITA never in prose |
| cyst; solid mass | hypoechoic mass | "complicated cyst" only inside a citation |
| first author; co-author | lead author | |
| open access; preprint; thesis | OA; dissertation | |
| postdoctoral fellow | post-doc | Capitalize only as a title in the timeline |

### 5.3 Length budgets for the new elements

| Element | Budget |
| --- | --- |
| Section deck | ≤ 140 characters |
| Theme body | ≤ 70 words |
| Skill item | ≤ 48 characters |
| Bridge line | ≤ 220 characters |
| Paper summary | ≤ 240 characters, 2 sentences |
| "My role" line | ≤ 90 characters |
| Short bio / long bio | ≤ 50 / ≤ 160 words |
| Timeline row | ≤ 90 characters |
| Link or button label | ≤ 18 characters (the chapter evidence link ≤ 44 including the venue) |
| Meta title / description | ≤ 60 / ≤ 155 characters |

### 5.4 Draft copy

All drafts are unconfirmed until the client approves them.

**Research**
- H2 "Research". Deck (104 characters): "Two halves that meet in the tumor: particles that carry treatment in, and
  images that show what's there."
- **Nanomaterials for delivery**, where line "PhD, Indian Institute of Science, Bengaluru · 2018–2024 [TO CONFIRM]"
  (64 words): "I design nanoparticles in layers, and each layer has one job. Ultrasmall light-absorbing cores turn light
  into heat and sound. A heat-responsive gel holds a drug until it's warmed. A red blood cell membrane coat helps the
  particle circulate long enough to reach a tumor. So one particle can carry a drug, heat a tumor with light, and show
  up in a photoacoustic image."
- Delivery skills: "Ultrasmall light-absorbing nanoparticles" · "Capping layers for stability and targeting" ·
  "Heat-responsive gels for drug release" · "Red blood cell membrane coating" · "Photothermal and photoacoustic
  testing".
- Bridge (about 215 characters): "Both halves share one piece of physics. Tissue and particles absorb light, warm
  slightly, and send out sound. That's why a particle can double as an imaging agent, and why skin tone matters in
  photoacoustic imaging."
- **Light and sound for imaging**: the body and skills in the `themes.ts` record above. The tense of "I work" follows
  P0-1.

**Featured summaries** (I5 and D2 are in the records above)
- I1: "Photoacoustic breast images from patients with a wide range of skin tones show that skin tone, light color,
  beamformer, and depth interact. Coherence beamforming helped some combinations and not others."
- D4: "Hybrids that pair a light absorber with gold are usually too large to reach deep into tumors. We grew gold
  directly on ultrasmall particles to keep the hybrid small, for heat treatment and photoacoustic imaging."

**Publications**
- Deck: "Papers, book chapters, and my thesis, grouped by the two halves of my work. First-author work is marked."
- Footer line: "Checked against Google Scholar and Crossref on 27 September 2026." followed by "Google Scholar profile".

**About**
- Short bio (45 words): "Madhavi Tripathi builds nanoparticles for drug delivery and works on photoacoustic and
  ultrasound imaging. She earned her PhD from the Department of Materials Engineering at the Indian Institute of
  Science, Bengaluru, and [is/was — TO CONFIRM] a postdoctoral fellow in Muyinatu Bell's PULSE Lab at Johns Hopkins
  University."
- Long bio (about 95 words plus the client's line): "I did my PhD in the Department of Materials Engineering at the
  Indian Institute of Science, Bengaluru, [with Ashok M. Raichur — TO CONFIRM], building nanoparticles in layers that
  can carry a drug, heat a tumor with light, and show up in photoacoustic images. In February 2025 I joined Muyinatu
  Bell's PULSE Lab at Johns Hopkins University as a postdoctoral fellow in electrical and computer engineering. There
  I work on ultrasound and photoacoustic imaging of the breast, including how skin tone affects what light-based
  imaging can see. [TO CONFIRM: current role, and one or two sentences on what's next.]"

**Contact**
- Deck: "Email is the best way to reach me, about a collaboration or any of the papers above."

**404**
- H1 "Page not found". Body: "Nothing echoes back from this address. The page may have moved when this site was
  rebuilt." Links: "Home", "Publications", "Contact".

### 5.5 Microcopy

| Element | Copy | Notes |
| --- | --- | --- |
| Skip link | Skip the lab | → `#research` |
| Nav and section index | Research · Publications · About · Contact | Index `aria-label="Sections"` |
| Phone menu | Menu / Close | `aria-expanded` |
| Chapter evidence | See the papers / Read the paper · Radiology Advances, 2025 | External arrow is decorative; the accessible name includes the venue |
| Theme and entry chips | See it in the lab: Ultrasound / In the lab: Ultrasound | Accessible name "Open the Ultrasound chapter of the lab" |
| Filter | Show: All 15 · Delivery 6 · Imaging 5 · First author 7 | Radio group; polite status "Showing 7 first-author items." |
| Earlier work | Show 4 other and earlier items / Hide other and earlier items | Native disclosure |
| Entry labels | First author · Open access · My role: … | Text, never color only |
| Entry links | Paper · PDF · Preprint · PubMed Central · Thesis record · Cite | Thesis note: "Readable on the IISc network only." |
| Cite panel | Copy citation · Copy BibTeX → Copied | Failure: "Couldn't copy. Select the text to copy it." |
| About | Copy short bio → Copied; Download CV (PDF, {size}) | Size computed at build |
| Contact | Copy email → Copied | Same failure copy as above |
| Empty filter | Nothing in this view yet. · Show all | |
| Footer | The lab images are simulations for explanation, not measurements. · Back to top | |

### 5.6 Metadata

| Route | Title | Description | Share card |
| --- | --- | --- | --- |
| `/` | Madhavi Tripathi · Nanoparticles and photoacoustic imaging (58) | Madhavi Tripathi builds nanoparticles for drug delivery and works on photoacoustic and ultrasound imaging. Research, publications, and contact. (143) | og:title "Madhavi Tripathi"; og:description = the headline; image alt "Madhavi Tripathi: Nanomaterials for delivery. Light and sound for imaging." |
| 404 | Page not found · Madhavi Tripathi | — | `noindex` |

JSON-LD `Person`:
- `name`.
- `jobTitle` and `affiliation`, only when confirmed.
- `alumniOf`: Indian Institute of Science.
- `sameAs`: the ORCID (once confirmed) and the Scholar URL.
- `knowsAbout`: nanoparticle drug delivery, photothermal therapy, photoacoustic imaging, ultrasound imaging,
  beamforming.

Replace the current description (the first-person lede) with the third-person line so search results name her. This
also sets her apart from namesakes.

## 6. Questions for the client

**P0: blocks launch**
1. **Current position.** What is your current title, department, institution, and start date? This sets the hero line
   and the tense of the imaging copy. Evidence: ORCID shows the Johns Hopkins postdoc ending 2026-01, the PULSE Lab
   lists you with alumni postdocs, and Scholar still shows Johns Hopkins.
2. **Email.** Which address should we publish? Visible, or copy-only?
3. **Domain.** What domain do you want, and who registers and renews it?
4. **ORCID.** Please confirm 0000-0002-4736-9134 is yours and can be shown.
5. **Publications.**
   - Confirm all 15 Scholar items are yours.
   - Should we show "Other and earlier work"? (MXene epoxy 2022, hydroxychloroquine review 2021, malaria DNA barcodes
     2015, stem cell review 2015)
6. **Headshot.** A file at least 1600 px on the short side, permission to publish, and the photographer credit.

**P1: completes the sections**
7. Approve or edit the theme text, both bios, and the featured summaries. Choose the featured delivery papers. Add a
   "what's next" line in your own words.
8. **"My role" lines.**
   - Needed for: I1, I2, I3, I4, D6, O1, and O2.
   - Optional for first-author items, beyond the "First author" label.
9. **Thesis.** The year awarded, advisor name(s) as you want them written, and a public copy or abstract link, if one
   exists.
10. **Earlier degrees.** Names, fields, institutions, and years. Your 2015 paper lists IIIT Allahabad, Department of
    Applied Science.
11. **CV.** A current CV PDF, and whether it may be public.
12. **Figures.**
    - CC BY papers (I1, I2, I5) can be reused with credit. Is that also fine with Dr. Bell's lab?
    - For the ACS and Elsevier papers, either confirm reuse under your author rights or send your own unpublished
      images (micrographs, heating curves, photoacoustic images), with lab permission.
13. **Talks and posters you presented.** Title, event, city, date, and type.
14. **Awards, fellowships, and grants.** Name, awarding body, and year.
15. **Teaching and mentoring.** Details, only if you want this section.
16. **Links.**
    - LinkedIn: a search result shows linkedin.com/in/mtri16 titled "Postdoctoral Fellow@Johns Hopkins University |
      Photoacoustic Imaging" [S; not opened]. Confirm it's yours and whether to link it.
    - GitHub, code, or datasets.
    - Should the PULSE Lab still be linked?

**P2: polish and after launch**
17. **Old site.** Sign in and export its text. It was titled "Research & Ideas": was there an Ideas or writing section
    to keep? (`/notes` is reserved.) Then take it offline or leave a pointer.
18. **Links to update after launch.** Add the new URL to the Scholar homepage field, ORCID websites, your email
    signature, and LinkedIn.
19. **ORCID.** Add the 11 missing works to your ORCID record. It also helps indexes tell you apart from other Madhavi
    Tripathis.
20. **Analytics.** None, or a cookie-free option?
21. **Citation metrics.** Is it OK not to show them? (Our recommendation.)
22. **Name and pronouns.** Is "Madhavi Tripathi" the only name display you want? Pronouns are optional.

## 7. Content and IA acceptance checks (Pass 1)

- Every rendered statement about the client is `confirmed` or comes from bibliographic metadata. The production build
  fails on any unconfirmed required fact.
- 15 entries render. Each has a DOI or record link and her name in bold. Seven carry "First author", and the filter
  counts match the list.
- Each of the four `#lab-*` links opens its chapter. Without JS they land on the lab. Back returns to where the
  visitor was.
- `?show=` survives reload, Back, and Forward. An unknown value shows All. `#pub-{id}` reveals the entry under any
  stored filter.
- On a 360 px screen every section is reachable within two taps, and the section index appears after the hero.
- No text smaller than 24 px uses `bone-faint`. Heading order: h1 (hero), then h2 per section, then h3 per theme or
  group. Entries are list items, not headings.
- No links to chatgpt.site. The share preview shows the name and headline. The theme and summary copy contains no
  material names or wavelengths.

## Sources

- Scholar profile: https://scholar.google.com/citations?user=zZx1Td0AAAAJ&hl=en (with `pagesize=100`) and its 15
  `view_citation` pages [T].
- Crossref: `https://api.crossref.org/works/{doi}` for each DOI above; `?filter=orcid:0000-0002-4736-9134`;
  `query.author` searches [T].
- OpenAlex: `https://api.openalex.org/works/doi:{doi}` [T].
- ORCID: https://orcid.org/0000-0002-4736-9134 and https://orcid.org/0000-0003-1033-1690, read via pub.orcid.org v3.0
  [T].
- PULSE Lab:
  - https://pulselab.jhu.edu/people/ [T, browser DOM]
  - https://pulselab.jhu.edu/2025/02/01/welcome-to-madhavi-tripathi/ [T]
  - https://pulselab.jhu.edu/publications/ [T]
  - Lab PDFs, checked with HEAD requests (200, application/pdf) [T]
- Publishers:
  - https://academic.oup.com/radadv/article/2/6/umaf037/8300868 [T]
  - https://www.nature.com/articles/s44303-026-00193-4 [T, browser DOM]
  - https://pmc.ncbi.nlm.nih.gov/articles/PMC13452404/ [T]
  - https://www.scirp.org/journal/paperinformation?paperid=60892 [T]
- IISc thesis record: https://etd.iisc.ac.in/handle/2005/6575 ("accessible only within the IISc network") [T].
- SPIE session details for I3: https://spie.org/photonics-west/presentation/Comparison-of-skin-tone-and-target-detectability-in-simulated-tissue/13851-8
  [S].
- Old site: https://madhavi-tripathi.madhavi-tri16.chatgpt.site/ (401) [T].
- Hero:
  - `research-hero/src/content/{profile,chapters}.ts`, `design-system/MASTER.md`, `src/components/hero/hero.tsx`,
    `src/app/{page,layout}.tsx` [T]
  - `scratchpad/shots/review/01_overview.png` and `14_mobile_top.png` [V]
  - `scratchpad/shots/ref_src_dribbble_pubs_cci.png` (offset featured columns lift text-heavy regions) and
    `ref_src_awwwards_the-choudhary-laboratory.png` (the network-node hero and slogan to avoid) [V, static captures]
