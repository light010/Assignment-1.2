# 01 · Reference research (standard Phase 1 B), for everything after the hero

Researcher: reference agent, 2026-09-27. Scope: publications, research-theme pages, bio, news/talks, contact, footer, mobile navigation.
The hero is fixed: void/bone palette, Newsreader + Mona Sans, explorable lab.

**How to read the evidence tags.**
- **Seen:** rendered pixels I looked at.
- **Measured:** computed from the live DOM.
- **Interaction:** I clicked, hovered or typed and watched the result.
- **Read:** text, page source or a designer's case study, not verified visually.

**Tools.**
- `scratchpad/shot.mjs` with `"noEngine": true`, at desktop 1440×900 (full page) and phone 390×844 at 2×.
- The Browser pane, for interactions and for the one site that blocks headless Chrome.
- Files: 93 captures in `scratchpad/shots/ref_*.png`. Readable crops are in `scratchpad/plan/ref-crops/`. The capture wrapper is `scratchpad/plan/ref-tools/refshot.sh URL name`.

## 1. The four required sources

| Source | Status | Searches run | Opened and looked at | Blocker or limitation |
| --- | --- | --- | --- | --- |
| https://dribbble.com | **Inspected** | scientist portfolio website, research lab website, academic portfolio, publications list, science magazine editorial | Seven shot pages: Utah AME Lab dept. site; Bureau for Neural Architecture case study; ForLab; Minimalistic Academic Portfolio; Academic Researcher Personal website; Center for Court Innovation "Featured Publications"; plus search grids | Almost all results are static mockups or concepts. One (BfNA) links a live site, which I inspected as R8. |
| https://www.awwwards.com | **Inspected** | science, research, laboratory, scientist, researcher, professor, lab, biotech, publication; "neuroscience" and "physicist" returned nothing | Five detail pages: Choudhary Laboratory (2017), Temasek Life Sciences Lab (2025), Institut Pasteur Research (2017), Danish Scientists (2015), Applied Curiosity Research (2020) | Search matches site names. The research category is thin and dated, and none of these has a strong publications page. |
| https://www.pinterest.com | **Inaccessible** | academic researcher website design, scientist portfolio website | Only the search grid, as thumbnails under a modal | A mandatory "Log in to see more" modal appears in both headless Chrome and the Browser pane, and zero `/pin/` links are exposed. The brief forbids signing in, so nothing was inspected beyond thumbnails (`ref_src_pinterest_search_academic.png`). |
| https://21st.dev | **Inspected** | footer, timeline, navigation-menu, blog, publication, table, accordion | Six live component previews: Large Name Footer, Changelog, Navbar with Theme Toggle, Dynamic Island TOC, Tracing Beam, Kibo UI Table | Previews only. Registry code, licenses and a11y were not audited. "publication" returns unrelated components. |

**What the platforms taught, mostly as warnings (Seen).**
- The Dribbble "academic" concepts lead with vanity counters: 66 papers and 1304 citations in large type, and "$691M+", "962k sq.ft.", "2,600+" on the Utah lab.
- They also use cutout portraits, "Schedule a Call" buttons and stock soldiers or laptops.
- Awwwards research sites lean on plexus particle networks and a rainbow slogan (Choudhary), stock photos under blue overlays (Applied Curiosity), and a force-directed people graph (Pasteur).
- ForLab is neon green with all-caps monospace and invented specimen codes (R-0187, F-0333).
- Useful exceptions:
  - Temasek's bespoke hand-drawn lab illustration: imagery with intent.
  - CCI's type kicker ("FEATURED PUBLICATION", "PROGRAM UPDATE") over a left rule: a news pattern.
  - 21st.dev's Changelog (type badge, date, title, one line) as a news shape.
- Awards and likes did not predict usability. The strongest patterns came from working sites.

## 2. Live references

**Legend for "What was inspected".**
- **D:** desktop render (1440, full page unless noted).
- **M:** phone render (390).
- **I:** interaction.
- **R:** read or measured.

| Reference URL | What was inspected | Quality to adapt | Limitation to avoid | Decision for this project |
| --- | --- | --- | --- | --- |
| **R1 Jon Barron** (academic personal) https://jonbarron.info/ | D (23,432 px), M (38,493 px). I: hovering a row swaps the thumbnail from the input photo to the model output. R: 100 `onmouseover` rows with tabIndex −1. Measured Lato 14 px at about 69 characters per line (cpl). | Each paper reads media, **title**, all authors with his own name in black bold (others linked), *venue*, year, links, then one plain sentence on what it does. Key papers sit on a pale band. The bio is about 60 words plus a one-line contact row (Email / CV / Bio / Scholar). | The before/after is hover-only, so keyboard and touch users never see it. The table layout doesn't reflow: on phones a 160 px thumbnail leaves a narrow column, titles run 4–5 lines, and the page is 38k px. Award notes are red text. The template is widely forked ("Feel free to steal this website's source code"), which reads as a template. | **Adopt** the entry anatomy and one before/after per selected paper. Build it as a focusable two-state toggle using the hero's segmented control (e.g., "Delay-and-sum / Coherence"), labeled "Simulated". **Reject** the table layout, hover-only reveals and colored award text. |
| **R2 Zijie J. Wang** (academic personal) https://zijie.wang/ | D (6,024), M (10,984). I: clicking "BibTeX" expands an inline code block. R: "BibTeX" and "show more" are `div`s with no role, tabindex or aria-expanded. | A row of icon chips (Project, Demo, Video, PDF, Poster, Code, BibTeX). Venues are given in full plus acronym. Citation is disclosed inline. A dated News log (date column plus one line). On phones the card stacks thumbnail over text. "see all publications" leads to a full list. | The controls aren't keyboard-operable. The BibTeX block scrolls sideways with no Copy button. Pink highlighter on every keyword, plus emoji, dilutes emphasis. Link chips measure 24 px tall. "Went Viral" chips are self-promotion. | **Adopt** the link row as real `<a>`/`<button>` elements at least 44 px tall: DOI, PDF (open access only), PubMed, Cite. **Cite** is a `<button aria-expanded>` that reveals wrapped BibTeX plus **Copy**, with a polite live "Copied". **Reject** highlighter and emoji. |
| **R3 PULSE Lab, Muyinatu Bell** (the client's lab) https://pulselab.jhu.edu/publications/ and /research/ | Browser pane only: desktop (800 px pane), phone (375×812), menu opened. shot.mjs was **blocked** by Cloudflare ("Sorry, you have been blocked"; `ref_pulselab_probe.png`), so no saved captures. R: DOM. | A complete record: journal articles by year (2026 back to 2008), then conference proceedings. Review articles come first. A "last updated September 13, 2026" stamp. The Research page explains photoacoustics with one labeled schematic (light from a tool tip, vessel, generated sound, probe). | Citations lead with authors, so titles are buried. Lab members are marked with `<u>` underlines that aren't links. The only link per entry is "pdf" at 27×23 px. No filters or year index. On phones: about 50k px, two stacked "Menu" bars, and roughly 390 px of logos before content. | **Link to it** from the bio and Research as the lab context. **Adopt** the "Last updated" stamp and a separate row type for reviews. **Invert** the order: title first, own name marked by weight, never underline. For content: this page lists 2026 papers with "Tripathi M" (npj Imaging; J. Biomed. Opt. 31(8):085001). Reconcile against Scholar and invent nothing. |
| **R4 Arc Institute** (research institute) https://arcinstitute.org/ and /research | D (home 4,437; research 4,066), M with the menu open. I: search syncs to `?search=imaging` and shows "0 results… There are no posts." R: the menu is a Radix dialog (aria-expanded toggles, focus moves in). Measured: Tiempos Headline 40/48 weight 300; IBM Plex Sans 16/24 at about 82 cpl. | The best publication row seen: a meta column in mono ("08.2026 • Cell"), outlined tag chips (lab, REVIEW, COMPUTATIONAL), the paper's own figure, title, a 3–4 line abstract, and "Read ↗", separated by hairlines. Search keeps its state in the URL. The phone menu is a full-screen sheet with 32 px items. | The empty state gives no way back. The menu trigger is 32×24 px with no accessible name. The measure is too long. The footer is just © plus icons. Saturated blue floods whole sections. | **Primary publications pattern**, restyled into void/bone (see P1). Theme chips map to the hero chapters. Filters live in the URL. The empty state offers "Show all". **Reject** color-flooded bands. |
| **R5 Quanta Magazine** (science editorial) [article: corals and oxygen](https://www.quantamagazine.org/corals-spin-tiny-vortices-to-get-oxygen-but-not-if-its-too-hot-20260805/) and https://www.quantamagazine.org/ | D (article 12,629), M (17,126), phone menu opened, home at both sizes. Measured: Noe Display 40/46; body Merriweather 16/30 in a 560 px column (about 68 cpl). | The long-form grammar: a tracked kicker, serif headline, italic dek, byline and date, subheads, a margin pull quote, and captions with right-aligned credits. **Paired figures carry in-frame labels ("27C", "39C") and 10 µm scale bars, and stack on phones.** Illustration is commissioned, not stock. | A cookie banner covers about 40% of the first phone screen. Side rails carry book and newsletter promos. The menu trigger is 15×35 px, and focus stays on it when the overlay opens. | **Adopt** for research-theme pages: kicker, headline, dek, a 60–68 cpl measure, then figures with caption and credit. Use the paired-figure convention for delay-and-sum vs. coherence and B-mode vs. SLSC. **Reject** promo rails and anything that needs a consent banner. |
| **R6 Bartosz Ciechanowski** (interactive explainer) https://ciechanow.ski/cameras-and-lenses/ | D (three depths), M (three depths; page is 57,727 px). R: 251 slider parts with 0 focusable and 0 ARIA roles; 56 canvases; no reduced-motion rule found. Measured IBM Plex Sans 19.2/30.7 at about 58 cpl. | A steady rhythm: a sentence, a live figure with one control, then a sentence saying what to notice. The page turns black when the story "turns the lights off", so the theme change carries meaning. Figures scale cleanly on phones. | Sliders can't be used by keyboard or screen reader. There's no table of contents or progress indicator on a 49–58k px page. | **Adopt** the rhythm on theme pages, reusing the hero's segmented controls, readouts and captions. At most two live figures per page, paused off-screen, with static stills for reduced motion. **Reject** div sliders and endless single pages; add a section index. |
| **R7 Distill** (research articles) https://distill.pub/2017/feature-visualization/ and https://distill.pub/ | D (article 20,197: top, byline, appendix, footer), M (top, metadata, appendix), home at both sizes. Measured system UI 17/28.8 at about 84 cpl. | A metadata block (AUTHORS / AFFILIATIONS / PUBLISHED / DOI) that becomes 2×2 on phones. Captions open with a bold lead-in. The **appendix is a label/content grid**: resources, contributions, footnotes, references, corrections, reuse license, and citation with BibTeX. The home index is a date column, type badge (PEER-REVIEWED solid, EDITORIAL outline), title, authors, dek and an author-drawn diagram. | On hiatus since July 2021, so the design is frozen. The measure is too long. Citations are hover popovers. | **Adopt** the label/content grid as the end matter of each theme page and the Cite block. Use the index row for News and talks. **Reject** the 84 cpl measure. |
| **R8 Bureau for Neural Architecture** (dark research practice, found via Dribbble) https://bfna.fr/ and /project | D (four depths plus full page, 16,670 px), M (three depths). I: the "Publication" filter pill works and inverts. R: 31 elements at opacity 0 before reveal; 6 of 7 filter radios share `id="radio"`; no aria-live; footer HTML. | Closest match in mood: dark, scientific, restrained. A three-column hairline grid, numbered practice sections, one "breathing" dot mark, and filter pills built on **native radios**. Real project photos. | The full-page capture is mostly blank because entrance effects hide content. A letter-scramble effect makes the intro illegible mid-animation on both sizes. A spinning "View" sticker follows the cursor. Filters give no count and no URL state. **Placeholder `tel:(+1)23456788`**, and "info@bfna.fr" links to linkedin.com. Composite AR imagery and long empty scrolls. | **Adopt** only the numbered sections tied to the four chapters and native-radio filters (with count and URL). The hero's existing motion is the only identity motion. **Reject** hidden-until-scroll content, scramble text, cursor followers and unverified contact data. |

Also looked at, first viewport only and not counted: fredhohman.com, research.arcadiascience.com (types publications honestly, including "Informative failure"), andymatuschak.org.

## 3. Synthesis

### Principles that fit, and why
1. **Title first, own name marked, one plain sentence per paper** (R1, R2, R4). This is "show the skill" applied to papers: a PI or a student sees what each paper *shows* without opening it.
2. **Editorial long-form grammar** (R5, R7). Newsreader was built for this. Keep a 60–68 cpl measure; Distill's 84 and Arc's 82 are too long.
3. **Paired, labeled comparison figures** (R5, R1). These map directly onto the client's methods (delay-and-sum vs. coherence, B-mode vs. SLSC, oxygenated vs. deoxygenated). The hero's engine can render them, labeled "Simulated", so the site keeps one visual language instead of borrowing stock.
4. **A metadata and appendix grid** (R7). DOIs, license and citation build trust, in keeping with "truthful by construction".
5. **Theme filters in the URL** (R4). The hero chapters already give the taxonomy.
6. **Dark suits secondary pages when the content is always visible** (R8 shows both the appeal and the failure).

### What does not fit, and why
- **Flooded brand colors** (Arc blue). The palette is void/bone. Pulse, echo, green and red are reserved for meaning (light and heat, sound, oxygenation), so they can't be decoration.
- **Counters for citations, h-index or funding** (Dribbble concepts). The client asked for no numeric claims, and a Scholar link does this job.
- **Stock or composite photos** (Utah lab, Applied Curiosity, BfNA). The imagery is the lab itself (simulated) or figures the client has rights to.
- **Promo rails, newsletters, consultation CTAs** (Quanta, Arc, BfNA). The site has no sales CTA.
- **Stock "science" signifiers**: plexus particles, neon monospace HUDs, scramble text. The hero already feels like an instrument through controls that really work.
- **Forked academic templates** (Barron's fork, al-folio style). These fail checklist item 01, "point of view, not a template".

### Adoptable patterns (tokens from `src/app/globals.css`)
**P1 · Publications ("paper row").**
- Layout at 64rem and up: `grid-template-columns: 8rem minmax(0, 1fr) 11rem`, rows separated by `--color-hairline`.
- **Meta column:** year and journal in Mona Sans semi-condensed tabular, 0.8125rem, bone-muted. Below it, a type chip ("Journal article", "Proceedings", "Review") with a 1px hairline outline.
- **Title:** Newsreader 1.3125rem/1.25, bone, max 60ch, linked to the DOI.
- **Authors:** Mona Sans 0.875rem, bone-muted. The client's name is `<strong>` in bone and never underlined.
- **Venue:** italic.
- **"What it shows":** at most 160 characters, 0.9375rem.
- **Links:** DOI ↗, PDF (open access only), PubMed, Cite; each at least 44px tall.
- **Figure column:** only on selected rows, and only for simulated or rights-cleared images.
- **Grouping and filters:**
  - Group by year, with a year index on /publications.
  - Filters: All / Delivery / Imaging, as the hero's segmented control on native radios.
  - `?theme=`, with the result count in `aria-live="polite"`.
  - Empty state: "No papers tagged Imaging yet. Show all."
- **Home and freshness:** the home page shows 3–5 "Selected" rows. /publications ends with "Last updated {date} · Full list on Google Scholar ↗".
- **Phones:** one column, the meta line above the title, links wrap into two rows.

**P2 · Research-theme pages ("explain, show, cite").**
- Two pages, mirroring the headline halves: /research/delivery and /research/imaging.
- **Order:**
  - kicker (the chapter name)
  - Newsreader headline
  - a dek of at most 160 characters
  - 3–5 sections. Each ends in a labeled figure with caption and credit; captions end with the measured value, as the hero's do.
  - "Papers behind this" (P1 rows filtered to the theme)
  - a Distill-style appendix: Lab and collaborators, How these images were made (Simulated), Cite
- **Measure:** 62–68ch, body Mona Sans 1.0625rem/1.65. Figures break out to 60rem.
- **Section index:** sticky from 80rem up; a collapsible "On this page" `<details>` on phones.
- **Links to and from the hero:** each chapter can deep-link to its section. Optionally, figures open the hero in the matching state (`/?chapter=ultrasound`).

**P3 · Bio ("two paragraphs and a record").**
- 90–120 first-person words: training, then current work.
- Then a `<dl>` record: Now (Johns Hopkins, Bell lab ↗ PULSE), PhD (with A. M. Raichur; institution to confirm), Interests (Scholar's five, in plain words).
- Links: Scholar, ORCID, CV (PDF), email.
- Portrait optional: a real photo, 4:5, never a cutout or AI caricature.

**P4 · News and talks ("dated log").**
- Each row: date in Mona tabular ("Sep 2026"), a text type label (Paper · Talk · Poster · Award), one sentence and a link.
- Six rows on the home page, the rest on /news.
- Verified items only, no emoji.

**P5 · Contact ("plain and direct").**
- No form: nothing to spam and nothing to submit.
- An email shown as text with a **Copy** button (visible "Copied" confirmation), and one line on what she welcomes (collaborations, student questions; client to confirm).
- Links: Scholar, ORCID, PULSE Lab. Institutional details only.
- Acceptance: every `href` resolves, with no placeholders (a link check in CI).

**P6 · Footer ("colophon").**
- Name in Newsreader italic at the header size, not a giant wordmark (the 21st.dev "large name footer" trend).
- One-line profile, the nav again, contact links, "Lab images are simulated.", "Last updated", ©.
- One hairline above; no icon wall.

**P7 · Mobile navigation.**
- Today the hero shows only "Contact" below 40rem (`hero.tsx` line 185).
- For the site: below 40rem the header becomes two rows. Row 1 is name and affiliation. Row 2 is **Research · Publications · Contact** as three equal 44px text links; for three items, no hamburger.
- If a sheet ever becomes necessary:
  - a button at least 44×44 with an accessible name and `aria-expanded`
  - focus moves into the sheet and returns on close, and Escape closes it
  - full-screen on void with 2rem items
- The header reappears on scroll-up; theme pages get the section index from P2.

### Anti-patterns seen, to list in the contract
- **Vanity counters and "Hi, I am" with a cutout portrait** (Dribbble academic concepts).
- **Stock, AR-composite or military stock photos** (Utah lab, Applied Curiosity, BfNA).
- **Plexus particles, planets, rainbow gradients** (Choudhary).
- **Neon monospace HUD with fake codes** (ForLab).
- **Content hidden by entrance effects, scramble text, cursor-follower badges** (BfNA). This is AOS-style fade-up slop.
- **Accessibility failures:**
  - hover-only reveals, `div` buttons and unlabeled custom sliders (Barron, Wang, Ciechanowski)
  - duplicate IDs, filters with no count or URL state, empty states with no way back (BfNA, Arc)
  - underlines on non-links and 27×23 px links (PULSE)
  - unlabeled menu triggers of 15–32 px (Quanta, Arc)
- **Consent banners covering 40% of a phone screen** (Quanta). Ship without trackers so no banner is needed.
- **Placeholder contact data in production** (BfNA).
- **Component-library trends:** tracing beams, "Dynamic Island" tables of contents, giant wordmark footers (21st.dev).

### Questions for the client
1. Which 3–5 papers to feature? Can published figures be reused (check each license; CC BY if open access), or should we use simulated or code-native figures only?
2. Portrait, CV PDF, ORCID iD and a public email?
3. Verified news and talks items, with dates.
4. PhD institution and year (only "with A. M. Raichur" is known).
5. Access to the old site (401 ChatGPT wall) to inventory its content.
