# Design system (plan 03): extending the hero to the whole site

Design-system lead (agent 03), 2026-09-27. The project stayed read-only; I wrote files only under
`scratchpad/plan/`. This version includes the old-site audit (`05-old-site.md`) and follows the IA plan
(`02-ia-content.md` §3–4).

**Evidence**
- **Hero as rendered.** Viewed `shots/review/*`, `t6_*`, `t7_320`, and `i_scrolled`.
- **Contrast and colour vision.** WCAG 2 and APCA, including pixels sampled from the renders
  (`03-work/contrast.py`), and a Machado 2009 colour-vision simulation (`03-work/cvd.py`).
- **Font facts.** fontTools on the woff2 files next/font actually serves (`03-work/fontfeat.py`,
  `digits.py`).
- **Calibration specimen.** Real fonts and the proposed tokens, with per-line character counts at 1440,
  1280, 1024, 768, 390, and 320 (`03-work/specimen.html`, `shots/ds03_spec3_1440.png`,
  `ds03_spec3_390.png`).
- **Publication lengths.** Scholar, read as text, plus 05.
- **Not done by me.** Visual reference research (see `01-references.md`).

## 0. Reconciliation with the other plans

| Topic | Inputs | Decision |
| --- | --- | --- |
| Selected figures | Brief: its own section. 02: figures inside Research, no gallery. | **Follow 02.** Featured-paper cards go in Research (§4.1); a variant is in §4.2. |
| News and talks | Brief: its own section. 02: About sub-blocks. | **Follow 02** (§4.4). Three non-paper items don't justify a nav item. |
| Themes | Hero: 4 chapters. Old site: 3. 02: 2. | **Two**, mirroring the headline: Nanomaterials for delivery ● and Light and sound for imaging ●○ |
| Author lines | 02: `bone-muted` | **`bone-soft`**. Text that wraps and is read needs APCA Lc ≥ 60 (§2.1). |
| Year numerals | 02: "tabular cut" (Mona Sans) | **Newsreader's default figures.** Mona Sans's tabular zero reads as θ (§2.2). |
| Theme colour | 02: pulse for delivery, echo for imaging | **Glyphs**: ● pulse for delivery, ●○ pulse plus echo for imaging. Shape survives colour blindness. |
| Line under the name | Hero: "Johns Hopkins University" | **"Translational scientist"** (05). The Johns Hopkins postdoc ended in Jan 2026. |

## 1. Point of view

**Thesis.** The site should let PIs, committees, collaborators, students, and curious non-scientists see
one translational scientist's two linked skills and check them. The skills are designing nanomaterials
for delivery and making photoacoustic and ultrasound images clearer. The hero is the working instrument.
Everything below it reads like a well-made paper: plain prose, figures that say where they came from,
and a reference list you can act on.

**Visible commitments**
1. **Composition: the console grid.** The hero console pairs a label column with each control
   (`grid-cols-[5.5rem_1fr]` in `segmented.tsx`). Every section repeats that at page scale:
   - a label track (columns 1–3) for names, dates, years, and lab chips
   - a reading track (at most 34em) for sentences
   - an aside track for evidence

   There is one left axis shared with the hero headline, and nothing is centered.
2. **Typography: Newsreader speaks, Mona Sans measures.** Sentences are Newsreader: headings, prose,
   titles, summaries, the email address. Things you operate or scan are Mona Sans: nav, controls,
   captions, authors, meta. Labels and data use its semi-condensed cut.
3. **Colour: hue is data.** Chrome is bone on void, and bone carries interactive emphasis. Pulse, echo,
   oxygenated, and deoxygenated appear only when they encode light or heat, sound, or blood oxygen, and
   always with a shape and a word.
4. **Imagery: every picture says where it came from.**
   - Paper figures sit on white plates labeled *From paper*, with credit.
   - Engine renders sit in black wells labeled *Simulated*, never inside a paper block.
   - There is one credited portrait.
   - No stock, and no placeholders.
5. **Interaction: controls change something visible.**
   - "Show" is the hero's segmented control.
   - "In the lab" chips open hero chapters.
   - Below the hero, motion only answers input.

**Different from the hero.**
- **Calmer.** No WebGL, glass, blur, parallax, or ambient loops. Panels are flat ink.
- **Reading-first.** Serif body at 18–20 px in full bone. Measured median line length is 67 characters
  at 1440 and 49 at 390. Sections sit 72–128 px apart.

**The same as the hero.** The palette, both font families, the label column, the segmented control,
*Simulated* labeling, the echo focus ring, the radius family, and MASTER.md's voice, glossary, and length
budgets. §7 lists what this replaces from the old site: Inter, a navy and cyan scheme, a theme toggle,
carousels, placeholders, eyebrows, and ↗ links.

## 2. Tokens

### 2.1 Colour

| Token | Value | Role |
| --- | --- | --- |
| `void` | `#060a0c` | Page. The pinned brand black, cool-tinted like the scene. |
| `ink` | `#0c1216` | Panels, frames, short-bio card, cite panel, phone menu |
| `panel` **new** | `#131b20` | Hover or raised surface on ink |
| `well` **new** | `#000000` | Wells for simulated images |
| `plate` **new** | `#ffffff` | Behind paper figures; never text |
| `bone` | `#ece7df` | Headings, **body prose**, decks, titles, links, the client's name in author lists |
| `bone-soft` **new** | `#d6d1c9` | Captions, summaries, authors, role lines, the short bio, citations |
| `bone-muted` | `#aaa59d` | Labels, venue sentence, hints, provenance, credits, DOI, years |
| `bone-dim` **new** | `#8f8a83` | Non-essential text (updated date, ©). Replaces `bone-faint` for text. |
| `bone-faint` | `#77736d` | **Non-text only** |
| `line`, `line-strong` **new**, `line-control` **new** | bone at 12%, 24%, 42% | Hairlines; hover outlines; control boundaries |
| `echo` | `#8fe1f0` | Focus ring, link-hover underline, selection at 28%. Data: sound. |
| `pulse` | `#ffad62` | Warning. Data: light and heat. |
| `good` **new token** | `#8fe8b0` | Success (already a hero readout tone) |
| `alert` **new** | `#ff8a78` | Error text |

**Data palette (figures, legends, and glyphs only)**
- oxygenated `#4fdc8a`, deoxygenated `#ff4a4a`
- tissue `#ef7b8d`, core `#d8b67c`
- gel carrier `#6aa8ff`, large particle `#b9c2c8`, released drug `#ff5c4a`

**The interface uses four colours:** void, ink, bone and its steps, and echo.

**Measured contrast (WCAG 2 ratio; APCA Lc on void in brackets)**

| Text colour | void | ink | panel | well |
| --- | --- | --- | --- | --- |
| bone | 16.15 (−92.5) | 15.32 | 14.16 | 17.06 |
| bone-soft | 13.08 (−78.9) | 12.41 | 11.47 | 13.82 |
| bone-muted | 8.12 (−53.7) | 7.70 | 7.12 | 8.58 |
| bone-dim | 5.80 (−39.8) | 5.50 | 5.09 | 6.13 |
| bone-faint | **4.22** (−28.8) | **4.00** | **3.70** | 4.46 |
| echo | 13.44 | 12.75 | 11.78 | 14.20 |
| pulse | 10.80 | 10.24 | 9.46 | 11.41 |
| good | 13.57 | 12.87 | 11.90 | 14.34 |
| alert | 8.67 | 8.22 | 7.60 | 9.16 |
| oxygenated | 11.30 | 10.72 | 9.90 | 11.94 |
| deoxygenated | 5.99 | 5.68 | 5.25 | 6.33 |

**Other measured pairs**
- Void on bone: 16.15.
- Hint on a selected cell (`#4b4c4b`): 7.01.
- `line`: 1.29, so it is decorative only.
- `line-control`: 3.51 on void and 3.52 on ink, which meets WCAG 1.4.11.
- Echo on bone: **1.20**, so the ring is always offset onto void.
- Echo on a plate: **1.48**, so nothing focusable sits on a plate.

**Sampled render backgrounds**
- Hero lede zone `#131617`: bone-muted is 7.43.
- Readout glass `#101418`: 7.56.
- The flat sections render exactly `#060a0c`.

**APCA reading rules.** APCA's levels:
- Lc 90 preferred for body text at 14px/400 or larger.
- Lc 75 minimum at 18px/400 or larger.
- Lc 60 minimum for other readable content.
- Lc 30 for spot-readable text.

These sizes assume a 0.52 x-height. Newsreader's is 0.426, so it needs about 22% more size. That gives:

| Text | Colour |
| --- | --- |
| Body prose | **bone** (Lc 92.5). `bone-soft` would need about 22px to clear Lc 75, and 20px in bone read comfortably in the specimen. |
| Captions, summaries, authors | bone-soft (Lc 79) |
| Short labels only | bone-muted (Lc 54) |
| Non-essential text | bone-dim (Lc 40) |

WCAG 2.2 AA stays the compliance bar; every step passes it.

**Colour vision (Machado 2009)**
- Under deuteranopia, oxygenated vs deoxygenated falls to 1.49:1 (khaki vs olive), and pulse vs echo to
  1.10:1.
- So maps carry direct labels, and glyphs differ by shape: light ● is filled, sound ○ is a ring.
- Chart series also differ by line style.

**Light theme: no.** The old site had a toggle.
- Body text already reaches 16.15:1 (Lc 92.5) in off-white bone, at line-height 1.62 with 49–67
  characters per line.
- The prose is short (bio up to 220 words, themes 90–160 each), and Publications is a scanning task.
  Positive polarity does help sustained reading (Piepenbrock et al. 2013), so the print stylesheet
  provides it where it matters: printed publication lists.
- A light section would flash right after the full-bleed hero, and it would fork every token.
- On bone, pulse measures 1.50:1 and would have to become `#a64f00`. That is the cream-and-terracotta
  default.
- **One exception, figure-only: the white plate.** Journal figures are drawn for white and must never be
  inverted or recoloured.

### 2.2 Typography

**Font facts (latin woff2 as served)**
- **Newsreader**
  - `wght` 200–800 and `opsz` 6–72.
  - Features: only `liga pnum tnum`. No oldstyle figures, no small caps.
  - Figures are tabular by default, with a plain zero.
- **Mona Sans**
  - `wdth` 75–125 and `wght` 200–900. No italic served.
  - Figures are proportional by default. **The tabular zero is slashed**: "0.93" renders as "θ.93".
- **Missing glyphs.** Neither font has U+202F, U+2009, or U+2192. Mona Sans also lacks µ and ′.
- **Preload.** 377 KB in total. The italic alone is 147 KB, used only for the name.

**Roles**

| Role | Settings | Used for |
| --- | --- | --- |
| Voice | Newsreader, `font-optical-sizing: auto`, `proportional-nums` | Headings, prose, decks, titles, summaries, timeline roles, email |
| Aligned numbers | Newsreader default figures | The year column, so digits align |
| Name lockup | Newsreader italic | Header and footer name; journal names in prose |
| Instrument | Mona Sans, `wdth` 100 | Nav, buttons, segments, captions, authors, meta |
| Label | Mona Sans at 88% width, proportional figures, +0.01em | Labels, chips, provenance, DOI, dates |

**Scale.** Every fluid maximum is at most 2.5× its minimum (Barvian's zoom-safe rule). Roselli warns no
formula is guaranteed, so 200% zoom is still tested.

| Token | Size | LH | Tracking | Weight, colour | Notes |
| --- | --- | --- | --- | --- | --- |
| `text-hero` (exists) | `clamp(min(2.75rem,12.5vw), 4.1vw + 1rem, 5rem)` | 0.95 | −0.022em | 380 | Hero only |
| `text-display` | `clamp(2.75rem, 2rem + 3.2vw, 4.5rem)` (44→72) | 1.0 | −0.02em | 380 | 404 h1 |
| `text-h2` | `clamp(2.125rem, 1.6rem + 2vw, 3.25rem)` (34→52) | 1.04 | −0.016em | 380 | One per section; balanced |
| `text-deck` | `clamp(1.3125rem, 1.15rem + .6vw, 1.625rem)` (21→26) | 1.38 | −0.004em | 360, bone | Max 30em, at most 140 characters; measured 58 / 37–39 characters per line |
| `text-h3` | `clamp(1.5rem, 1.3rem + .7vw, 2rem)` (24→32) | 1.12 | −0.01em | 400 | Theme and group heads; bridge line |
| `text-title` | `clamp(1.125rem, 1.05rem + .3vw, 1.25rem)` (18→20) | 1.34 | −0.003em | 420, bone | Paper, timeline, and news titles; max 38em |
| `text-body` | `clamp(1.125rem, 1.05rem + .3vw, 1.25rem)` (18→20) | 1.62 | 0 | 400, bone | Max 34em; paragraph gap 0.9em. Measured medians: 67 / 59 / 67 / 58 / 49 / 37 characters at 1440 / 1280 / 1024 / 768 / 390 / 320. |
| `text-summary` | `1.0625rem` | 1.5 | 0 | 400, bone-soft | Paper summaries, at most 240 characters |
| `text-caption` (exists) | `0.9375rem` | 1.5 | 0 | 400, bone-soft | Mona Sans; at most 180 characters |
| `text-ui` | `0.9375rem` | 1.5 | 0 | 400/500 | Nav, buttons |
| `text-small` | `0.875rem` | 1.5 | 0 | 400 | Authors and roles (soft); venue (muted) |
| `text-label` | `0.8125rem` | 1.3 | +0.01em | 400, muted | Semi-condensed |
| `text-micro` (exists) | `0.75rem` | 1.3 | +0.01em | 400 | Legends inside figures |
| `text-email` | `clamp(1.5rem, 1.1rem + 1.6vw, 2.5rem)` | 1.2 | −0.012em | 380 | `overflow-wrap: anywhere` |

**Characters**
- Lining figures only, and no `tnum` on Mona Sans.
- Unspaced en-dash ranges ("Feb 2026–present").
- U+2212 for minus.
- U+00A0 between a number and its unit, and inside each author name ("J Enslein" split at 390 in the
  specimen).

**Links**
- **In prose.** The underline is the marker, since body text is also bone.
  - Default: 1 px underline in bone at 45%, offset .22em.
  - Hover: the underline turns echo.
  - Focus: 2 px echo ring, offset 3 px.
  - Visited: the same as default.
- **List titles.** Underline only on hover or focus.
- **Never:** arrows, ↗, or new tabs.
- **PDF links.** Hidden text names the title, and the size is shown when known.

### 2.3 Space and grid

**Spacing** uses a 4 px base:

| Token | Value | Use |
| --- | --- | --- |
| `--space-section` | `clamp(4.5rem, 3rem + 6vw, 8rem)` | 72→128 |
| `--space-block` | `clamp(3rem, 2rem + 3vw, 5rem)` | 48→80 |
| `--space-stack` | 1.5rem | |
| `--space-tight` | 0.5rem | |
| `--header-h` | 3.5rem | `scroll-padding-top: calc(var(--header-h) + 1rem)` |

**Grid**

| Width | Columns | Gutter | Margin | Tracks |
| --- | --- | --- | --- | --- |
| < 48rem | 4 | 16 | 16 (24 from 40rem, as the hero) | Single column; the label track becomes a label row |
| 48–64rem | 8 | 20 | 24 | Label 1–3; reading 4–8 (443 px at 768) |
| 64–80rem | 12 | 24 | 40 | Label 1–3 (218 px); reading 4–10 (541 px); aside below |
| ≥ 80rem | 12 | 24 | 40 | Label 1–3 (282–322); reading 4–8 (486–553); aside 9–12 (384–436) |

- The container is `max-w-[90rem]`.
- The label track never drops below 218 px, because "Photoacoustics" at h3 size needs 181 px.
- Components that move between tracks use `@container`, as the hero does.

### 2.4 Shape, depth, and icons

**Radii**

| Radius | Where |
| --- | --- |
| 22 | Hero phone scene only |
| 18 | Panels and frames |
| 14 | Grid cells, cite panel |
| 11 | Wells, inside an 18 px frame with 10 px padding |
| 4 | Plates and portrait (printed things) |
| full | Pills |

- **Borders.** `line` only inside groups and on the footer rule. No rules between sections.
- **Shadows.** None on page surfaces. The Enlarge dialog uses `0 24px 60px -20px rgb(0 0 0/.8)`. The
  echo glow belongs only to the hero's tour button.
- **Icons.** lucide-react: 16 px with text, 20 px in 44 px buttons, `strokeWidth={1.75}`, `aria-hidden`.
  - Allowed: Menu, X, Copy, Check, ChevronDown, Maximize2, Play, Pause.
  - No brand logos.

### 2.5 Tailwind v4 additions to `globals.css`

```css
@theme {
  --color-panel: #131b20; --color-well: #000000; --color-plate: #ffffff;
  --color-bone-soft: #d6d1c9; --color-bone-dim: #8f8a83;
  --color-line-strong: rgb(236 231 223 / 0.24); --color-line-control: rgb(236 231 223 / 0.42);
  --color-oxygenated: #4fdc8a; --color-deoxygenated: #ff4a4a; --color-good: #8fe8b0; --color-alert: #ff8a78;
  --text-display: clamp(2.75rem, 2rem + 3.2vw, 4.5rem); --text-display--line-height: 1; --text-display--letter-spacing: -0.02em;
  --text-h2: clamp(2.125rem, 1.6rem + 2vw, 3.25rem); --text-h2--line-height: 1.04; --text-h2--letter-spacing: -0.016em;
  --text-deck: clamp(1.3125rem, 1.15rem + 0.6vw, 1.625rem); --text-deck--line-height: 1.38;
  --text-h3: clamp(1.5rem, 1.3rem + 0.7vw, 2rem); --text-h3--line-height: 1.12; --text-h3--letter-spacing: -0.01em;
  --text-title: clamp(1.125rem, 1.05rem + 0.3vw, 1.25rem); --text-title--line-height: 1.34;
  --text-body: clamp(1.125rem, 1.05rem + 0.3vw, 1.25rem); --text-body--line-height: 1.62;
  --text-summary: 1.0625rem; --text-summary--line-height: 1.5;
  --text-small: 0.875rem; --text-small--line-height: 1.5;
  --text-label: 0.8125rem; --text-label--line-height: 1.3; --text-label--letter-spacing: 0.01em;
  --radius-panel: 18px; --radius-cell: 14px; --radius-well: 11px; --radius-plate: 4px;
}
@theme inline {
  --font-serif: var(--font-newsreader), ui-serif, Georgia, serif; /* reading text */
  --color-fg: var(--color-bone); --color-fg-soft: var(--color-bone-soft);
  --color-fg-muted: var(--color-bone-muted); --color-fg-dim: var(--color-bone-dim); --color-focus: var(--color-echo);
}
:root { --space-section: clamp(4.5rem, 3rem + 6vw, 8rem); --space-block: clamp(3rem, 2rem + 3vw, 5rem); --header-h: 3.5rem; }
html { scroll-padding-top: calc(var(--header-h) + 1rem); }
@media (prefers-reduced-motion: no-preference) { html { scroll-behavior: smooth; } }
.font-instrument { font-variant-numeric: normal; font-feature-settings: normal; } /* plain zero, §8.1 */
```

Reference the spacing variables with Tailwind's variable shorthand, for example `pt-(--space-section)`.
Check it against the installed version.

## 3. Components

**Global state rules**

| State | Rule |
| --- | --- |
| Hover | Only under `(hover: hover)`, 150 ms `--ease-out-quint`. Text goes to bone. Fills go to bone at 6% on void, or `panel` on ink. Outlines go to `line-strong`. Underlines go to echo. No hover scaling. |
| Focus-visible | 2 px echo ring, 3 px offset |
| Active | Scale 0.98 over 90 ms. Links turn echo. |
| Selected | Bone fill with void text (the hero's thumb) |
| Disabled | Not used: remove the control or explain why |
| Targets | At least 44×44 on touch. On fine pointers, 32 px visible inside a 44 px hit area, with 8 px between pills. |

**Inventory**

| Component | Anatomy | States beyond the global rules | Loading / empty / error |
| --- | --- | --- | --- |
| **Skip link** | "Skip the lab" to `#research`; a bone pill shown on focus | n/a | n/a |
| **Section index** | 56 px void bar with `line` below. Name in Newsreader italic 17, then four links in Mona 15, muted. `aria-label="Sections"`; `inert` until the hero header leaves the viewport. | Current: bone with a 1 px underline, `aria-current="location"` | n/a |
| **Phone menu** | "Menu" (`aria-expanded`) in the hero header and the index. An inline ink panel holds four links in Newsreader 28 with 52 px rows, then the email. | Reads "Close" with X. Esc or a link closes it and returns focus. | n/a |
| **Section header** | `<h2 id>`, optional deck, `scroll-margin-top` | n/a | n/a |
| **Theme block** | Label track: glyph, h3, where-and-when, lab chips. Reading track: body, then "What I did" (4–5 sentences). Aside: 1–2 featured papers. | n/a | No cleared figure: a typographic card |
| **Lab chip** | Outline pill "In the lab: Design" linking to `#lab-design` | Opens the chapter, scrolls up (a jump under reduced motion), focuses the chapter button | n/a |
| **Featured paper, figure** | Ink frame with a plate in a 4:3 `contain` stage. Strip: "From paper" and an optional panel segment. Summary as caption, "My role: …", credit in 02's format, "Read the paper". | Enlarge (44 px) opens a `<dialog>` at full resolution, with pinch-zoom; focus returns on close | Stage reserved; the old image stays until `decode()`. On failure: "Figure unavailable. Read the paper." |
| **Featured paper, text** | Ink panel with 20 px padding: title, summary, role, link | n/a | n/a |
| **Bridge line** | One `text-h3` sentence, bone, at most 120 characters, with `--space-block` around it. No ornament. | n/a | n/a |
| **Show control** | Hero `Segmented` with All 15, Delivery 6, Imaging 5, First author N (counts derived); a 2×2 grid on phones; `?show=` via `replaceState` | Arrow keys, as in `segmented.tsx` | Without JS: hidden, and the full list shows. Empty: "Nothing in this view yet." with [Show all]. |
| **Publication group** | Glyph, h3, "6 papers". "Other and earlier work" is a collapsed disclosure. | Chevron rotates | n/a |
| **Publication item** | `<li id="pub-…">`. Year (Newsreader 20) in the label track. Then the title (links to the DOI), summary, authors (the client in bone 600), "Journal article in [venue]", and "My role: …". Last, a row: First author and Open access labels (only when true), chips, [PDF] or [Preprint] if allowed, [Cite], and the DOI as a label. | Title gets an echo underline | No PDF: the pill is omitted, never disabled |
| **Cite panel** | Ink, 14 px: the citation (bone-soft), then [Copy citation] [Copy BibTeX] [Copy link] | "Copied" with Check for 2 s, announced politely | "Couldn't copy. Select the text and copy it." |
| **Bio block** | Portrait (4:5; 1:1 on phones) with credit, first-person bio, short-bio card (third person, [Copy short bio]), CV link | Copy states as in the cite panel | No portrait: text-first, never a silhouette |
| **Timeline** | `<ol>`, newest end date first. Rows: dates (label, `<time>`), title, organization and place (muted), one-line description (soft), "Source" link. | n/a | Unconfirmed rows don't render |
| **Awards and service** | Year, title, context. A photo only if supplied, with credit. **No carousel.** | n/a | Omitted when empty |
| **News list** | Date and type ("Role", "Award", "Feature", "Paper") in the label track, the title, an optional link. First 6 shown, the rest behind "Show N older items". | Disclosure | Rendered only with 2 or more non-paper items |
| **Contact block** | Deck; email (`text-email`) and [Copy email]; Google Scholar, ORCID 0000-0002-4736-9134, LinkedIn; CV | Copy states | No email: profile links only |
| **Footer** | Rule; name and "Translational scientist"; the simulations note (02); derived figure credits; "Updated September 2026" and © in bone-dim; Back to top | n/a | n/a |
| **Back to top** | A footer link, plus the index name linking to `#top` (focus goes to the hero `h1`). **No floating button** (WCAG 2.4.11). | n/a | n/a |
| **404** | Index bar, `text-display` h1, copy per 02 §5.4, three exits, status 404 | n/a | It is the error state |

## 4. Compositions

- **Desktop 1440:** 40 px margins; label track at columns 1–3, reading at 4–8, aside at 9–12.
- **Phone 390:** 16 px margins; 358 px of content.
- Brackets mark placeholders. (S) marks rows from Scholar. "Confirm" marks dates that 05 leaves open.

### 4.0 Seam: hero into Research, plus the section index

```
1440 ┌──────────────────────────────────────────────────────────────────────────────────────────┐
     │ Madhavi Tripathi                                 Research  Publications  About  Contact  │ hero header
     │ Translational scientist                                                                  │ (was JHU)
     │ Nanomaterials                      [ full-bleed lab scene, WebGL ]                        │
     │ for delivery. …                                                                           │
     │ [Design][Delivery][Photoacoustics][Ultrasound]                   ┌ Photoacoustic image ─┐ │
     │ caption   (Take the tour) (II)                                   │ [well]     Simulated │ │
     │░░░░░░░░░░░░░░░░░ existing bottom 30%: scene fades into void ░░░░░└──────────────────────┘░│
     └──────────────────────────────────────────────────────────────────────────────────────────┘
       no rule at the seam: the gradient is the edge; the engine pauses off-screen (existing)
                                                                           ↕ --space-section (128)
       Research                              ← h2 52px, x = hero headline x
       [deck ≤ 140 characters]

     once the hero header leaves the viewport (opacity 160 ms, no slide):
     ┌──────────────────────────────────────────────────────────────────────────────────────────┐
     │ Madhavi Tripathi                             Research  Publications  About  Contact       │ 56px void
     └──────────────────────────────────────────────────────────────────────────────────── line ┘
```

```
390 ┌──────────────────────────────────────┐
    │ Madhavi Tripathi     Contact  (Menu) │ Menu added to the hero header
    │ Translational scientist              │
    │ Nanomaterials / for delivery. / …    │
    │ ┌ scene r22 ───────────────────────┐ │
    │ └──────────────────────────────────┘ │
    │ [Design    ][Delivery   ]            │
    │ [Photoac.  ][Ultrasound ]  (Tour)(II)│
    │ ┌ Photoacoustic image ─────────────┐ │
    │ │ [well]                 Simulated │ │ hero ends (mb-12)
    │ └──────────────────────────────────┘ │
    │                                      │ ↕ 72
    │ Research                             │ h2 34px at x=16
    │ [deck, 21px, 37–39 ch/line]          │
    └──────────────────────────────────────┘
    index after the hero:  │ Madhavi Tripathi            (Menu) │ 56px
```

### 4.1 Research: two themes with featured papers

```
1440   ├── label 1–3 (322) ──────┤  ├── reading 4–8 (553) ─────────────────┤  ├── aside 9–12 (436) ──┤
       Research
       [deck ≤ 140 characters]
                                                                                           ↕ 48
       ● Nanomaterials              [Body: what and why, 90–160 words,         ┌ ink frame r18 ───────┐
         for delivery               Newsreader 20/1.62, bone, 60–72 ch]        │ ┌ plate r4, 4:3 ───┐ │
       [PhD research, IISc,                                                    │ │ figure exactly   │ │
        years: confirm]             What I did                  ← label        │ │ as published     │ │
                                    [Work done, one sentence]                  │ └──────────────────┘ │
       In the lab                   [Work done]                                │ From paper   (a│b)  │
       (Design) (Delivery)          [4–5 items, Newsreader 18]                 └──────────────────────┘
                                                                               [Plain summary ≤180]
                                                                               My role: [text]
                                                                               [credit, label size]
                                                                               Read the paper
                                                                                           ↕ 24
                                                                               ┌ ink r18, no figure ──┐
                                                                               │ [Title]              │
                                                                               │ [Summary] [My role]  │
                                                                               │ Read the paper       │
                                                                               └──────────────────────┘
                                                                                           ↕ 80
                                    [Bridge line: text-h3, bone, ≤120 characters, the hinge
                                     between the halves (copy per 02)]
                                                                                           ↕ 80
       ●○ Light and sound           [Body]                                     [featured paper figure card]
          for imaging               What I did …                               [second featured paper]
       [Postdoc, PULSE Lab, Johns
        Hopkins, dates: confirm]
       In the lab
       (Photoacoustics) (Ultrasound)
```

On phones the order is designed rather than shrunk: the claim, then the evidence, then the way into the
lab.

```
390 ● Nanomaterials for delivery       h3 24
    [PhD research, IISc, years]        label
    [Body, 18px, median 49 ch]
    What I did
    [Work done]
    [Work done]
    ┌──────────────────────────────────┐
    │ ┌ plate, 4:3 ──────────────────┐ │ featured paper
    │ └──────────────────────────────┘ │
    │ From paper            (a │ b)    │
    └──────────────────────────────────┘
    [Plain summary]  My role: [text]
    [credit]  Read the paper
    In the lab  (Design) (Delivery)    chips after the evidence
                                        ↕ 48
    [Bridge line, 24px]
                                        ↕ 48
    ●○ Light and sound for imaging …
```

### 4.2 Figures: inside Research, with a variant if a separate section is kept

This variant uses the hero's chapter buttons and instrument panel at page scale, with one plate in view
at a time. Tab titles are at most 16 characters; the specimen showed longer titles breaking at their
hyphen on phones.

```
1440   Selected figures
       [deck]
       ┌───────────────────────┐   ┌─────────────── ink frame r18, cols 4–10 ─────────────────┐
       │ Cyst or solid         │   │ ┌─────────────── plate r4, 4:3 stage ──────────────────┐ │
       │ Ultrasound            │   │ │     figure exactly as published                      │ │
       └───────────────────────┘   │ └──────────────────────────────────────────────────────┘ │
         Skin tone                 │ From paper                           ( Panel a│Panel b ) │
         Photoacoustics            └──────────────────────────────────────────────────────────┘
         [≤16-ch title]            [caption ≤180]   [credit]   Read the paper   (Enlarge)
         [theme]                                                     cols 11–12 stay empty

390 tablist as a 2×2 grid (ink r18, titles ≤16 ch) above the frame; caption, credit, and Enlarge below
```

### 4.3 Publications

Real lengths:
- 15 items; titles up to about 155 characters.
- Longest venue: "Photons Plus Ultrasound: Imaging and Sensing 2026".
- Types: journal, conference, chapter, thesis.
- The client appears both as first author and as a middle author.

```
1440   Publications
       [deck]
                                                                                  ↕ 32
       Show                     (▓All 15▓ │ Delivery 6 │ Imaging 5 │ First author N)   ← hero Segmented
       Checked against Google Scholar on [date]. Google Scholar profile              ← label, muted
                                                                                  ↕ 48
       ● Nanomaterials for delivery                                        6 papers  ← group h3
       2025                     Mucin-capped CuS nanoparticles for mitochondrial targeted NIR-II
       (Newsreader 20,          photothermal therapy and photoacoustic imaging (S)   ← title, DOI link
        plain zero)             [Plain summary ≤240, Newsreader 17, bone-soft]
                                M Tripathi, A Sharma, VA Ajisafe, S Sinharay, AM Raichur  ← bone-soft
                                Journal article in Journal of Drug Delivery Science and Technology
                                My role: [CRediT roles or the client's words]
                                First author  [Open access]  (In the lab: Delivery) (PDF) (Cite)  DOI 10.…
                                ─────────────────────────────────────────────────────────── line
       2024                     Effect of PVP molecular weights on the synthesis of ultrasmall CuS
                                nanoflakes: synthesis, properties, and potential application … (S)
                                                                                  ↕ 64
       ●○ Light and sound for imaging                                     5 papers
       2026                     In vivo photoacoustic breast imaging and the interactive effects of
                                skin tone, wavelength, beamformer, and depth on target detectability (S)
                                …
                                                                                  ↕ 64
       (Other and earlier work, 4 papers ⌄)                                ← disclosure, collapsed
```

```
390 Publications
    [deck]
    ┌────────────────┬─────────────────┐  Show: 2×2 radio grid
    │▓ All 15       ▓│ Delivery 6      │
    │ Imaging 5      │ First author N  │
    └────────────────┴─────────────────┘
    Checked against Google Scholar on [date].
                                        ↕ 32
    ● Nanomaterials for delivery        h3 24
    6 papers
    2025                                year, Newsreader 18
    Mucin-capped CuS nanoparticles for  title 18
    mitochondrial targeted NIR-II …
    [Plain summary]                     17px
    M Tripathi, A Sharma, VA Ajisafe,   names never split
    S Sinharay, AM Raichur
    Journal article in Journal of Drug
    Delivery Science and Technology
    My role: [text]
    First author  [Open access]
    (In the lab: Delivery)
    (PDF)  (Cite)                        44px targets
    DOI 10.…
    ──────────────────────────────────
```

### 4.4 About, with timeline, awards, and news

The entries are the client's own, from 05.

```
1440   About
                                                                                  ↕ 32
       ┌────────────────────┐   [Long bio, first person, 90–160 words,      ┌ ink r18: Short bio ────┐
       │ portrait 4:5       │    text-body, bone]                           │ [Third person, ≤90     │
       │ 322×402, r4        │                                               │  words, Mona 15,       │
       │ (text-first layout │   CV (PDF, [size])                            │  bone-soft]            │
       │  until one exists) │                                               │ (Copy short bio)       │
       └────────────────────┘                                               └────────────────────────┘
       Photograph: [name], [year]
                                                                                  ↕ 64
       Positions and education                                          ← h3
       Feb 2026–present         Lead Scientist                          ← text-title
                                SynapSeek, remote                       ← small, muted
                                Leading scientific and AI/ML strategy, data pipelines, …       Source
                                ─────────────────────────────────────────────────────
       Dec 2024–Jan 2026        Postdoctoral Research Fellow
       (start: confirm)         PULSE Lab, Johns Hopkins University
                                … with Prof. Muyinatu A. Lediju Bell.                          Source
                                ─────────────────────────────────────────────────────
       Mar 2025 (confirm)       PhD in Materials Engineering
                                Indian Institute of Science, Bengaluru
                                … Advisor: Prof. Ashok M. Raichur.                             Source
                                ─────────────────────────────────────────────────────
       Jul 2018                 Integrated M.Tech. in Biomedical Engineering
                                Indian Institute of Information Technology, Allahabad
                                                                                  ↕ 64
       Awards and service                                               ← h3
       2025                     Best Thesis Award and Gold Medal, Indian Institute of Science
       2024–present             Leadership committee, Women in Molecular Imaging Network
       2023                     Convener, 36th Annual Symposium of Materials Engineering, IISc
                                                                                  ↕ 64
       News                                                             ← h3 (2+ non-paper items)
       Sep 2026   Paper         [npj Imaging paper title]                      Read the paper
       Feb 2026   Role          Joined SynapSeek as Lead Scientist
       Sep 2023   Feature       IISc feature: Hybrid nanoparticles in the spotlight   Read the feature
```

The Best Thesis Award appears in both old-site lists; keep it in Awards only.

```
390 About
    [portrait 1:1, 358×358, only when it exists]
    [Long bio, 18px]
    ┌ ink r18: Short bio ──────────────┐
    │ [third-person bio]               │
    │ (Copy short bio)                 │
    └──────────────────────────────────┘
    CV (PDF)
    Positions and education
    Feb 2026–present                    date as a label row
    Lead Scientist                      title 18
    SynapSeek, remote
    [description]  Source
    ──────────────────────────────────
    Awards and service
    2025
    Best Thesis Award and Gold Medal …
    News
    Sep 2026  Paper
    [title]  Read the paper
```

### 4.5 Contact

```
1440   Contact
                                [Deck: who should write and about what]
                                [published email address]                    (Copy email)  ← text-email 40
                                                                                  ↕ 32
                                Profiles                              CV
                                Google Scholar                        CV (PDF, [size]), when it exists
                                ORCID 0000-0002-4736-9134
                                LinkedIn

390 Contact / [Deck] / [email, 24px, wraps anywhere] / (Copy email, 44px) /
    Google Scholar / ORCID 0000-0002-4736-9134 / LinkedIn / CV   ← 44px rows, stacked
```

### 4.6 Footer, phone menu, and 404

```
1440 ──────────────────────────────────────────────────────────────────────────────────── line
     Madhavi Tripathi           The lab images are simulations for explanation,        Back to top
     Translational scientist    not measurements.                                      Google Scholar
                                Figures: [derived credit list, label size]             Email
                                Updated September 2026. © 2026 Madhavi Tripathi       (bone-dim)

390 menu open (inline, non-modal)        404 (1440 and 390 share this order)
    ┌──────────────────────────────────┐   [h1, text-display, copy per 02 §5.4]
    │ Madhavi Tripathi        (Close ×)│   [one sentence]
    ├──────────────────────────────────┤   Research   Publications   Contact
    │ Research                         │   [footer]
    │ Publications                     │   Newsreader 28, 52px rows
    │ About                            │
    │ Contact                          │
    │ [email]                          │
    └──────────────────────────────────┘
```

## 5. Imagery

There are three sources: engine renders, paper figures, and one portrait.

**Banned:** stock, AI-generated pictures, icon collages, gradient blobs, inverted or recoloured figures,
hover-zoom, and "coming soon" slots.

### 5.1 Engine renders (Simulated)

**Pipeline**
1. A development-only `app/render/page.tsx` (it calls `notFound()` in production) mounts `LabCanvas`
   with no UI, takes its state from the query string, and renders at a pixel ratio of 2.
2. Playwright (as in `shot.mjs`) captures each state after 3 frames.
3. `sharp` writes AVIF (q50) and WebP (q72) at 480, 768, 1200, and 1600 px wide, into `public/renders/`.
4. A manifest goes in `src/content/figures.ts`.
5. Budget: 1200 px AVIF at 90 KB or less.

The images in `instruments.ts` are 400×386; show them at 400 CSS px or less.

**Placement.** Per 02, never beside a real paper:

| Still (engine state) | Use |
| --- | --- |
| Overview (default) | OG image, 1200×630: name in Newsreader italic, "Translational scientist", the headline, and the still. It comes from an HTML template, because Next's `ImageResponse` takes only ttf, otf, and woff (`…/04-functions/image-response.md`, line 52). It replaces the ChatGPT-branded preview. |
| `design: {step:"coat", view:"exploded"}` | **Hero fallback without WebGL2** (today an empty gradient); share card |
| `deliver: {particle:"gel", elapsed:"hours", light:"continuous"}` | Hero fallback; share card |
| `photoacoustic: {map:"oxygenation", skin:"darker", beamformer:"coherence"}` | Hero fallback; share card |
| `ultrasound: {lesion:"cyst", beamformer:"coherence", view:"image"}` | Hero fallback; share card; an optional 404 crop |

**Loops** run 4–6 s, one per chapter (build, release, pulse and wave, transmit sweep), in MP4 and WebM at
1.2 MB or less. They are for talks and social posts. On the site they are only a user-started low-power
alternative, if the hero owner wants one.

### 5.2 Paper figures (From paper)

**Selection**
- The featured papers are 02's picks: imaging I5 and I1 (open access); delivery D2 and D4, with D3 and D1
  as alternates.
- Choose figures that show skill: coherence vs delay-and-sum with gCNR, detectability across skin tones,
  build steps, release under light.
- Oxygenated is green and deoxygenated is red.

**Files**
- Request originals, not PDF screenshots.
- Line art as PNG or SVG; images as AVIF or WebP.
- Labels inside a figure must stay at least 11 px on screen; otherwise the figure is shown through
  Enlarge only.

**Register**

| Paper (DOI) | Fig. | License from the article page | Basis | Status | Credit | Alt |
| --- | --- | --- | --- | --- | --- | --- |
| [DOI] | [n][panel] | CC BY 4.0 / publisher | CC BY: attribution and a license link. Otherwise: the author-reuse policy, or permission. | requested / cleared | "From [Authors], [Journal], [Year], fig. [n][, cropped]. [License]." | [written] |

**Rules**
- Never alter data pixels.
- Crop only at panel edges, and say so in the credit.
- An unknown license means the figure is not published.

### 5.3 Portrait brief

The old site shows a placeholder, so no portrait exists yet. About stays text-first until one does.

- **Deliverables.** 3 selects at 3200×4000 px or more, sRGB, as TIFF and JPEG. The face sits inside the
  central 60%, so 4:5 and 1:1 both work.
- **Setting.** A lab bench the client chooses (with permission, instruments off, no patient data or
  identifiable colleagues), or a charcoal seamless backdrop. The background is lit 3–4 stops under the
  key, so it grades into void.
- **Light.**
  - One large soft key at about 45° camera-left, slightly above eye level.
  - Bounce fill 1.5–2 stops under the key.
  - An optional faint cool background light. No gels on skin.
- **Grade.**
  - White balance from a ColorChecker frame.
  - **Grade skin for exposure and white balance only.** The client studies skin-tone bias in imaging.
    No smoothing, no reshaping.
  - Background toward `#060a0c`–`#0b1013`. Highlights capped near bone.
- **Framing.** Chest-up, eyes on the upper third, subject on the left facing slightly right, toward the
  bio. 85–105 mm equivalent, f/2.8–4. Mix direct-gaze and at-work frames.
- **Wardrobe.** Solid mid-tones. No pure white or black, no fine stripes, no logos.
- **Rights.** Web, Open Graph, and press use. The credit appears in the caption.

### 5.4 Alt text

1. What is shown and what to notice, in 150 characters or fewer. Never "Image of…". Renders start with
   "Simulated".
2. For paper figures, give the finding, not a tour of the panels. The credit goes in the caption.
   Complex plots get a "Describe this figure" disclosure.
3. A compare toggle updates the alt, as `instrument-panel.tsx` does.
4. The portrait alt is the name and setting only. Decorative images get `alt=""`.
5. Only numbers visible in the image.

## 6. Motion that whispers

| Trigger | Motion | Timing | Reduced motion |
| --- | --- | --- | --- |
| Hover or press | Tone and underline; press scales to 0.98 | 150 ms; press 90 ms | Colour only |
| Segment or panel toggle | Thumb glides (`layoutId`) | Spring 420/30, the hero's value | Instant |
| Figure swap | Cross-fade after decode; heights reserved | 240 ms | Instant |
| Show change | List fades in; count updates at once | 140 ms opacity | Instant |
| Disclosures and phone menu | Height (`interpolate-size`, else Motion) | 200 ms | Instant |
| Enlarge dialog, section index | Opacity | 180/120 ms, 160 ms | Kept |
| Copy | Check icon and "Copied" for 2 s | Instant | Same |
| Anchors | Native smooth scroll | Browser | Jump |

- **Never animates:** scroll-entry effects, headings, numbers, images on hover, backgrounds, the cursor,
  route transitions, or anything below the hero without input.
- **Banned:** fade-up reveals (AOS), staggers, parallax outside the hero, smooth-scroll libraries,
  pinned scroll-telling, marquees, typewriter or scramble text, count-ups, magnetic buttons, custom
  cursors, tilt, hover zoom, glass below the hero, blobs, grain, skeleton shimmer, carousels, confetti,
  decorative Lottie, and page wipes.

## 7. The $10K Checklist and anti-patterns

| # | Item | Met by | Verified by |
| --- | --- | --- | --- |
| 01 | Point of view | Console grid from the hero; hue is data; provenance by surface; hero controls reused | Pass 3: no section would fit another site unchanged |
| 02 | Typography | Newsreader with Mona Sans (Inter removed); scale; measure | Line-length script (67 at 1440, 49 at 390); computed-font audit |
| 03 | Restrained colour | Four interface colours; data hues only in figures, glyphs, and legends | Grep for data colours outside figure and chip components; §2.1 table |
| 04 | Hierarchy that breathes | h2 at 52/34 vs the hero's 80/44; 72–128 px sections; one axis | Rhythm check; heading outline h1 → h4 |
| 05 | Imagery with intent | Paper figures, renders placed per §5.1, one portrait, all labeled | Register; alt audit |
| 06 | Motion whispers | Input-only, 90–240 ms | Zero `whileInView`; reduced-motion pass |
| 07 | Mobile designed | Phone order per section, 2×2 grids, square portrait, inline menu | Screenshots at 390 and 320; no overflow, verified 320–1440; 44 px targets |
| 08 | The invisible expensive stuff | LCP ≤ 2.0 s desktop lab and ≤ 2.5 s p75 mobile (hero text); CLS ≤ 0.1; INP ≤ 200 ms; italic not preloaded; skip link; landmarks; measured contrast; title, canonical, OG, JSON-LD `Person`; print stylesheet | Lighthouse (lab), keyboard pass, axe, OG debugger |

**Anti-patterns**

| Anti-pattern | Seen on the old site (05) | Rule |
| --- | --- | --- |
| Cream and terracotta | none | No light theme |
| Dark with a single bright accent | Navy with a cyan accent | Bone carries emphasis; echo is focus and sound only |
| Broadsheet pastiche | none | Radii kept; no rules between sections |
| SaaS card kit | Achievement cards | Rows; one frame per figure; no surface shadows |
| All-caps eyebrows, numbered markers | "01 IN FOCUS" … "05" | Sentence case; numbers only as dates |
| Middle-dot meta | "Lead Scientist · SynapSeek · Remote" | "SynapSeek, remote" |
| Arrow suffixes | "Scholar ↗" | None |
| Monospace data, one accented word, "WORD — fragment" | none | Semi-condensed sans; never; no dashes in labels |
| Carousels, placeholders, builder links | Achievement carousel, "Photos & videos coming soon", "Add portrait", "Edit website" | Lists; omit anything unfilled |
| Stat counters, "Scroll to discover" | Both | None; link to Scholar |
| Stock photos, logo rows, fade-up on scroll | none | §5 and §6 |

## 8. Findings for the build owner

1. **The hero readout zero reads as θ.** `.font-instrument` sets `tabular-nums`, so gCNR "0.93" renders
   close to "θ.93".
   - Fix: the last rule in §2.5.
   - The same applies to 02's year column: use Newsreader instead.
2. **The stand-ins in `page.tsx` fail contrast.** They set paragraphs in `bone-faint`, 4.22:1, which
   fails WCAG 1.4.3.
3. **The phone hero header shows only Contact.** Add Menu. Also change the lockup to "Translational
   scientist".
4. **There is no skip link.** Keyboard users meet about 15 lab controls first.
5. **Without WebGL2 the hero stage is an empty gradient.** Use the §5.1 stills.
6. **Preload is 377 KB.** The italic is 147 KB for the name alone.
7. **Keep the direct labels on oxygenation maps.** Oxygenated vs deoxygenated falls to 1.49:1 under
   deuteranopia.

## 9. Questions for the client

1. Is dropping the old light/dark toggle acceptable? A print stylesheet replaces it.
2. The portrait: a new shoot to §5.3, or an existing photo with credit and rights?
3. Featured-paper figures: which figure for each skill, the original files, and the license for each.
4. Dates to confirm:
   - the postdoc start (Dec 2024 or Feb 2025)
   - the PhD date (Mar 2025, or Dec 2024 per ORCID)
5. Which email to publish, and does a CV PDF exist?
6. Which awards and updates to keep, and have any talks been given?

## 10. Sources

- Premium standard: `/Users/praka/Downloads/premium-frontend-prompt.md`. Hero contract:
  `design-system/MASTER.md`. Plans: `02-ia-content.md`, `05-old-site.md`.
- Google Scholar, read as text on 2026-09-27: https://scholar.google.com/citations?user=zZx1Td0AAAAJ&hl=en
- APCA levels and the x-height note: https://git.apcacontrast.com/documentation/APCA_in_a_Nutshell.html
- Barvian (2023): "The maximum value must be less than or equal to 2.5 times the minimum value."
  https://www.smashingmagazine.com/2023/11/addressing-accessibility-concerns-fluid-type/
- Roselli (2019, updated 2025), "Responsive Type and Zoom":
  https://adrianroselli.com/2019/12/responsive-type-and-zoom.html
- Piepenbrock, Mayr, Mund, and Buchner (2013), *Ergonomics* 56(7), 1116–1124 (Crossref-verified):
  https://doi.org/10.1080/00140139.2013.790485
- Machado, Oliveira, and Fernandes (2009), *IEEE TVCG*: https://doi.org/10.1109/TVCG.2009.113
- CC BY 4.0: https://creativecommons.org/licenses/by/4.0/
- Next 16 `ImageResponse` fonts:
  `node_modules/next/dist/docs/01-app/03-api-reference/04-functions/image-response.md`, line 52.
