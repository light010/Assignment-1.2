# Google Scholar figures on the site

The site shows citation figures from the owner's public Google Scholar profile,
<https://scholar.google.com/citations?user=zZx1Td0AAAAJ&hl=en>. A script reads that one page and saves the figures
in the site's code as a file, `src/content/scholar.json`, and the site is built from that file. Visitors' browsers
never contact Google, and every figure carries the date Scholar was read.

## What is read, and why it is allowed

Google's robots.txt for Scholar (<https://scholar.google.com/robots.txt>, read on 28 September 2026) allows automated
reading of profile pages and disallows paging through a profile's article list:

```text
Disallow: /citations?
Allow: /citations?user=
Disallow: /citations?*cstart=
```

So each run makes one request, for `/citations?user=zZx1Td0AAAAJ&hl=en`, and no other:

- no second page (`cstart=`), no retries, no proxies;
- a User-Agent that says what it is, `madhavi-tripathi-site/0.2 (research website citation snapshot)`, not a
  browser's;
- no headless browser, and no attempt to solve or get around a CAPTCHA. If Google answers with one, or with an
  "unusual traffic" page, the run stops.

The page lists up to 20 articles, and the profile has 15, so one page holds them all. If the profile grows past 20,
the script warns that the least-cited ones are missing; with a SerpApi key (below) it asks SerpApi instead, which
lists up to 100.

## How often

Every 4 hours, at 41 minutes past the hour (UTC), in GitHub Actions (`.github/workflows/scholar.yml`). The file is
committed when anything Scholar shows has changed, and otherwise about once a day, so while reads succeed the date on
the site is rarely more than a day old. The commit updates the site when the repository is connected to Cloudflare
Workers Builds, which builds and deploys on every push to the production branch.

## What the site gets

- The profile's totals: citations, h-index, and i10-index, all-time and "since 2021" (Scholar's recent window).
- Citations per year, oldest first. The current year is partial.
- For each article: Scholar's title, authors, venue, and year; its "Cited by" count, with a link to Scholar's list
  of citing works; and which of the site's papers it is.
- When Scholar was last read (`checkedAt`), and whether the figures came from the profile page or from SerpApi.

The Publications section shows the all-time citations with the count since 2021, the h-index and i10-index, the
per-year chart (the running year marked "so far"), each paper's "Cited by" with its link, and the date the figures
were read ("Checked Sep 28, 2026"), with a link to the profile. It never shows Scholar's titles: the site's own
curated titles stay.

## When Google refuses

Google often refuses automated requests from cloud servers, GitHub's included. When it does, the run keeps the last
snapshot, the site keeps showing it with its date, and the run ends with a warning rather than an error. Once the
snapshot is more than 3 days old, the workflow opens an issue labeled `scholar-stale` that explains the two fixes;
it closes itself after the next successful read.

1. **Add a SerpApi key** (next section). Refused reads then go through SerpApi.
2. **Run it from your own computer**, where Google rarely refuses one request: in `latest_app/research-hero`, run
   `npm run scholar`, then commit and push `src/content/scholar.json`.

## SerpApi (optional)

SerpApi (<https://serpapi.com>) is a paid service that reads Google Scholar and returns a profile's figures as data
(its Google Scholar Author API). With a repository secret named `SERPAPI_API_KEY`, a run makes one SerpApi search when
Google refuses, when the page can't be parsed, or when the page lists only part of the profile. Runs where the page
reads cleanly don't use it.

- **Cost.** SerpApi's free plan includes 250 searches a month, at most 50 an hour (its pricing page, read on
  28 September 2026); paid plans start at $25 a month for 1,000. The workflow runs 6 times a day, so even if every
  run needed SerpApi, that is about 180 searches a month, within the free plan. SerpApi counts only successful
  searches.
- **Setting it up.** GitHub → the repository → Settings → Secrets and variables → Actions → New repository secret,
  named `SERPAPI_API_KEY`, with the key from your SerpApi account. On your computer:
  `SERPAPI_API_KEY=<key> npm run scholar`.
- The key is read from the environment only; the script never prints it or the address it calls.
- When SerpApi covers for a page that couldn't be parsed, the run shows a warning: the parser needs an update.
- This path is tested against SerpApi's documented response format, not yet against a live key.

## What is checked

Before writing, the script refuses, and writes nothing, when:

- the page is not the owner's profile (a different id, or a name other than Madhavi Tripathi);
- it lists no articles, or shows figures that can't all be true;
- its read time is in the future, or earlier than the committed snapshot's;
- total citations or the number of articles fell by more than 10% since the last snapshot. That usually means a
  parsing fault, or a namesake's papers that Scholar had merged into the profile and then removed.

If a refused drop is real, accept it once: on your computer, `npm run scholar -- --force`; on GitHub, Actions →
Google Scholar snapshot → Run workflow, with "force" ticked.

Every build checks the committed file offline (`npm run check:scholar`, part of `npm run build`): its format; that
it is the profile named in `src/content/person.ts`; that each paper it links to exists in
`src/content/publications.ts`; and that no paper is linked twice. It also warns, without failing, about Scholar
entries the site doesn't list, site papers that Scholar doesn't list, links that today's matching would make
differently, and a snapshot older than 14 days.

When a paper is removed from `publications.ts` or its id changes, the check fails until the snapshot is paired again.
`npm run scholar -- --rematch` does that without asking Scholar; commit the result with the change.

Scholar entries that the site doesn't show are listed in an issue labeled `scholar-watch`, which the workflow keeps
up to date and closes once the list is empty. If you close it yourself, it stays closed until the list changes.
Other researchers publish as "Madhavi Tripathi", and Scholar sometimes adds their papers to a profile: confirm a
paper is the owner's before adding it to the site.

Scholar entries are matched to the site's papers by title (ignoring case, punctuation, and accents) and year. In
`scripts/lib/scholar.mts`, `OVERRIDES` pairs by hand a paper that Scholar shows under a different title or year, and
`IGNORED` lists entries that are the owner's but stay off the site on purpose, so the issue leaves them out.

## Running it by hand

```bash
npm run scholar                   # read Scholar once; write src/content/scholar.json if anything changed
npm run check:scholar             # check the committed snapshot, offline
npm run scholar -- --rematch      # pair the snapshot with publications.ts again, offline
npm run test:unit                 # the unit tests, offline
node scripts/scholar-sync.mts --from saved-profile.html   # parse a profile page saved from a browser (HTML only)
```

Exit status: 0, written or unchanged; 1, a check failed and nothing was written; 2, wrong options; 3, Google refused
or didn't answer and no fallback worked, so the last snapshot is kept. The script needs Node 22.18 or later and
nothing from `npm install`.

## Files

| File | What it is |
| --- | --- |
| `src/content/scholar.json` | The snapshot. Written by the script; edits by hand are overwritten by the next run. |
| `src/content/scholar.ts` | Its types, the `scholar` object, and `scholarFor(pubId)` for the pages. |
| `scripts/scholar-sync.mts` | The script: reading, the SerpApi fallback, writing, `--check`, and `--rematch`. |
| `scripts/lib/scholar.mts` | Parsing, matching, and checks, with no network; `OVERRIDES` and `IGNORED` live here. |
| `tests/unit/scholar.test.mts` | Unit tests, on the fixtures in `tests/fixtures/`. |
| `.github/workflows/scholar.yml` | The schedule, the commit, and the two issues. GitHub runs workflows only from the repository root's `.github/workflows/`, so it must be copied there. |
