# Science review

Independent science review (nanomedicine; photoacoustic and ultrasound imaging) of every scientific statement the
content files put on the page, as listed in `docs/copy-deck.md`: Research, Publications, About, the lab's captions,
readouts and labels, and the lab's evidence links. Checked against the owner's papers on 27 September 2026.
Nothing under `src/` was edited; nothing was committed.

## Summary

| Severity | Count | Findings |
| --- | --- | --- |
| P0: false or unsupported | 0 | none |
| P1: misleading or imprecise | 1 | S1 |
| P2: nuance | 7 | S2 to S8 (S7 and S8 are rule and site-accuracy points, not science) |

The site is accurate. The one misleading sentence is in the imaging theme body. It says the skin study measured how
much pulsed light skin "can safely take". The study actually measured the dose that injures pig skin (S1).

The requested checks all pass:

- "A study of 29 patients" is correct.
- "In a swine model" is correct.
- The 0.76 note is correct: the study chose 0.76 as the gCNR cutoff for coherence (SLSC) images.
- Both SPIE summaries are accurate. The Drabek one is imprecise (S5).
- The delivery summaries are accurate as far as the readable sources go.

A section proposing "we"-voice summaries for all 15 publications follows the findings.

## How each paper was read

| Paper | What I read | Source |
| --- | --- | --- |
| Enslein 2026, npj Imaging | Full text (accelerated-preview PDF, CC BY), including author contributions | https://doi.org/10.1038/s44303-026-00193-4 |
| Arroyo 2026, J. Biomed. Opt. | Full text | https://pmc.ncbi.nlm.nih.gov/articles/PMC13452404/ |
| Sharma 2025, Radiology Advances | Full text, including CRediT contributions | https://pmc.ncbi.nlm.nih.gov/articles/PMC12709606/ |
| Enslein 2026, SPIE | Abstract (OpenAlex, Semantic Scholar) | https://doi.org/10.1117/12.3081139 |
| Drabek 2026, SPIE | Abstract (Semantic Scholar) | https://doi.org/10.1117/12.3083562 |
| Tripathi 2025, mucin | Abstract content through a search-engine index. The publisher blocks automated access, so this is not the page itself. | https://doi.org/10.1016/j.jddst.2025.106668 |
| Tripathi 2024, nanoflakes | Abstract (OpenAlex) | https://doi.org/10.1021/acsabm.3c01123 |
| Tripathi 2023, nanohybrids | Abstract (OpenAlex), plus the IISc feature | https://doi.org/10.1021/acsanm.3c02405, https://www.iisc.ac.in/events/hybrid-nanoparticles-shine-new-light-on-targeting-cancer-cells/ |
| Tripathi, PhD thesis | Title only. The record is IISc-network only (HTTP 403 outside). | https://etd.iisc.ac.in/handle/2005/6575 |
| Tripathi 2023, hydrogels chapter | Title only. No abstract in Crossref, OpenAlex or Semantic Scholar, and ScienceDirect blocks automated access. | https://doi.org/10.1016/B978-0-323-99638-9.00019-8 |
| Jain 2021, biopolymer chapter | Abstract content through a search-engine index | https://doi.org/10.1016/B978-0-12-819724-0.00028-8 |
| Wazalwar 2022, epoxy composite | Abstract (OpenAlex) | https://doi.org/10.1021/acsapm.1c01876 |
| Jain 2021, drug-repurposing review | Abstract (OpenAlex) | https://doi.org/10.1080/17512433.2021.1909473 |
| Tripathi 2015, malaria | Full text of the three-page commentary (OpenAlex) | https://doi.org/10.1111/tmi.12594 |
| Tripathi 2015, stem cells | Abstract (OpenAlex) | https://doi.org/10.4236/jbm.2015.311002 |

## Findings

### S1 · P1 · `themes.ts`, imaging theme, `body`

**Current:** "In Muyinatu Bell’s PULSE Lab at Johns Hopkins, I worked on making photoacoustic and ultrasound images of the breast
clearer. We measured contrast objectively (gCNR) on coherence-beamformed ultrasound to tell cysts from solid masses, and
studied how skin tone changes what photoacoustic imaging can detect, and how much pulsed light skin of different tones
can safely take."

**Problem:** The skin study did not measure a safe dose. It measured ED50 injury thresholds in pig skin of three
pigmentation types. An ED50 is the laser dose at which half of the exposed sites show visible injury, and darker skin
reached it at a lower dose. Safety limits sit about an order of magnitude below such thresholds. The paper uses its
thresholds only to discuss those safety margins.

So "can safely take" names the opposite quantity (safety, not injury), and it reads as human skin. The paper defines
ED50 as the exposure that "produces a visible injury in 50% of exposed sites"
(https://pmc.ncbi.nlm.nih.gov/articles/PMC13452404/).

**Proposed** (58 words; only the last clause changes): "In Muyinatu Bell’s PULSE Lab at Johns Hopkins, I worked on
making photoacoustic and ultrasound images of the breast clearer. We measured contrast objectively (gCNR) on
coherence-beamformed ultrasound to tell cysts from solid masses, and studied how skin tone changes what photoacoustic
imaging can detect, and how much pulsed light it takes to injure skin of different tones."

### S2 · P2 · `themes.ts`, `BRIDGE`

**Current:** "Both halves share one piece of physics: absorbed light turns into heat and sound."

**Problem:** Absorbed light always becomes heat. It becomes sound only when it arrives in short pulses, fast enough for
the heated tissue to expand and launch a pressure wave. Continuous light gives heat and no sound. The lab's own Light
control teaches exactly this split: Pulsed gives an imaging signal, Continuous gives heat.

The bridge is the one place the site states the shared physics as a principle, so it should be exact. The npj paper
notes that photoacoustic imaging "uses pulsed laser light at targeted wavelengths to excite chromophores"
(https://doi.org/10.1038/s44303-026-00193-4).

**Proposed** (100/140): "Both halves share one piece of physics: absorbed light turns into heat, and pulsed light into
sound."

The design readout "Turns light into: Heat and sound" can stay, because the Delivery chapter makes the
pulsed/continuous split explicit.

### S3 · P2 · `chapters.ts`, `caption()`, Photoacoustics, Show = Blood oxygen, Skin tone = Lighter, Beamformer = Coherence

**Current:** "Oxygen shifts which colors blood absorbs, so imaging with a few colors maps blood oxygen. Lighter skin adds little
clutter, so coherence changes little here."

**Problem:** This caption contradicts two things:

- **The sibling caption.** The Nanoparticles caption for the same skin tone and beamformer says "Lighter skin adds
  little clutter, but coherence still brings out faint targets."
- **The rendered image.** The coherence display lifts faint vessels in both maps.

The npj study supports the Nanoparticles wording. In patients, coherence (SLSC) beat delay-and-sum for deep targets
across skin tones, and the gap was largest under darker skin. So under lighter skin coherence helps less, but it still
helps. In the paper's light-skin example, targets that were faint with delay-and-sum were more visible with SLSC. Its
summary finding: "deep in vivo target detectability is consistently greater with SLSC rather than DAS"
(https://doi.org/10.1038/s44303-026-00193-4).

**Proposed** (169/180): "Oxygen shifts which colors blood absorbs, so imaging with a few colors maps blood oxygen.
Lighter skin adds little clutter, but coherence still brings out faint vessels."

### S4 · P2 · `chapters.ts`, `caption()`, Ultrasound, Lesion = Solid mass, Beamformer = Delay-and-sum, View = Image

**Current:** "A solid mass also looks dark in B-mode, which is why cysts and solid masses get confused."

**Problem:** This overgeneralizes. The confusion the study addresses is between complicated cysts and dark
(hypoechoic) solid masses. Not every solid mass is dark, and the study excluded masses with bright (hyperechoic)
content. The paper describes cysts overlapping "with the sonographic appearance of hypoechoic solid masses due to
acoustic clutter" (https://pmc.ncbi.nlm.nih.gov/articles/PMC12709606/).

**Proposed** (93, or at most 104 with the gCNR suffix, against 180): "Many solid masses also look dark in B-mode, which
is why cysts and solid masses get confused."

### S5 · P2 · `publications.ts`, `drabek-2026-spie`, `summary`

**Current:** "Investigates a conditional generative adversarial network trained on simulated skinless models to reduce
skin-related clutter in photoacoustic images."

**Problem:** The summary reads as if the network was trained on skinless models alone. In fact:

- It was trained on simulated raw channel data, with skin-free versions of the same simulations as the target output.
- It works on channel data, before beamforming.
- It was tested on a single patient, as a feasibility demonstration.

The abstract states that "ground truth channel data were generated by replacing the skin layer with water"
(https://doi.org/10.1117/12.3083562).

**Proposed** (smallest fix, 174/240): "Investigates a conditional generative adversarial network, trained on simulations
with the skin removed as the target, to reduce skin-related clutter in photoacoustic images." A "we" version is under
Proposed summaries.

### S6 · P2 · `chapters.ts`, `readouts()`, Delivery, Particle = Ultrasmall, After = Hours, Retention "Low"

**Current:** The Retention readout shows "Low". The caption reads "…but without a carrier they soon leave."

**Problem:** The chapter's evidence link opens the delivery papers, and one of them reports the opposite at this time
point. According to the article's abstract, the owner's mucin-capped particles showed significant tumor uptake and
retention for up to about seven hours in vivo. Those particles were ultrasmall and not in a gel carrier, though they
carried a mitochondria tag (https://doi.org/10.1016/j.jddst.2025.106668, abstract read through the search index).

"Low" at Hours therefore reads against the owner's own result. The size trade-off itself is textbook and is the
owner's framing: ultrasmall particles reach deep but wash out, and large ones stall at the rim. "Washed out" at "A day"
doesn't conflict with anything.

**Proposed** (optional): change the Retention value at Hours from "Low" to "Fading". "A day" keeps "Washed out" and the
captions stay as they are. Confirm against the paper's in vivo figure first.

### S7 · P2 · `about.ts`, update `2023-09-iisc-feature`, `text` (messaging rule, not accuracy)

**Current:** "IISc tells the story behind the copper sulfide and gold nanohybrids and their potential for light-based
applications."

**Problem:** The sentence is accurate, but it names two materials outside a title, which breaks the owner's rule. The
IISc feature describes hybrid particles under 8 nm that heat under light and "absorb light and generate ultrasound
waves" (https://www.iisc.ac.in/events/hybrid-nanoparticles-shine-new-light-on-targeting-cancer-cells/).

**Proposed** (108): "IISc tells the story behind the ultrasmall hybrid nanoparticles and how they turn light into heat and
sound."

### S8 · P2 · `site.ts`, `DECKS.publications` (site accuracy, not science)

**Current:** "Papers, book chapters, and my thesis, grouped by the two halves of my work. First-author work is marked."

**Problem:** The list has a third group, "Other and earlier work" (`src/components/site/publications.tsx`). It holds
four items that belong to neither half.

**Proposed** (123/140): "Papers, book chapters, and my thesis, grouped by the two halves of my work, then earlier work.
First-author work is marked."

## The requested checks

### Paper summaries

- **"A study of 29 patients"** (`enslein-2026-npj-imaging`): **correct.** The in vivo data came from 29 patients, with 34
  masses. Don't carry "29" into the SPIE companion paper, which used 20 patients. The number rule applies, so the
  proposed summary drops it.
- **SPIE summaries:**
  - `enslein-2026-spie` is **accurate**: simulated, phantom and patient data, beamformed with delay-and-sum and SLSC.
  - `drabek-2026-spie` is **imprecise**; see S5.
- **"In a swine model"** (`arroyo-2026-jbo`): **correct.** The study used three swine with different pigmentation. The
  summary's "informing photoacoustic imaging research" is also supported: the paper names photoacoustic imaging as the
  modality its thresholds matter most for.
- **The note "The lab’s 0.76 threshold comes from this study."** (`sharma-2025-gcnr-slsc`): **correct.**
  - A previous study had found gCNR cutoffs from 0.62 to 0.85 acceptable. Within that range, this study chose 0.76
    for gCNR on SLSC images, to identify as many cysts as possible without calling cancers cysts.
  - A value above the cutoff means fluid, that is, a cyst.
  - The lab applies the cutoff the same way: ≥ 0.76 reads as a cyst, on coherence images only. B-mode images get the
    number but no verdict, because the study compared against radiologists reading B-mode by eye. The study also
    computed gCNR on B-mode images, but only as a comparison; the cutoff belongs to SLSC.
- **Delivery summaries:**
  - `tripathi-2025-mucin` is accurate but incomplete: it leaves out the mitochondria tag and the 3D-model and in vivo
    results, and it names materials.
  - `tripathi-2024-nanoflakes` is accurate.
  - `tripathi-2023-nanohybrids` is accurate. "Ultrasmall" is right: the mean size was 8 nm.
  - `tripathi-phd-thesis` is consistent with the thesis title.
  - `tripathi-2023-hydrogels` is consistent with the chapter title.
  - Rewrites are under Proposed summaries.

### Evidence links in the lab

| Where | Link | Verdict |
| --- | --- | --- |
| Ultrasound, every state | "Read the study in Radiology Advances" | **Strongly supported.** The paper covers B-mode against SLSC, gCNR, and the 0.76 cutoff. In its SLSC images, cysts are darker (less coherent) than the surrounding tissue, and solid masses are about as coherent as it (Figs. 3–5). |
| Photoacoustics, Blood oxygen | "Read the skin-tone study in npj Imaging" | **Supported, with the label as written.** See the notes after this table. |
| Photoacoustics, Nanoparticles | "See the papers behind this" (delivery) | **Supported** for "particles absorb far more light than tissue and stand out". See the notes after this table. |
| Design | "See the papers behind this" | **Supported** for the cores and the capping layer: the nanoflakes paper shows capped particles under 10 nm that are crystalline and compatible with cells, and the mucin and nanohybrid papers agree. The gel-and-drug and membrane-coat steps rest on the thesis, which I couldn't read, and on the hydrogels chapter title (see Could not verify). |
| Delivery | "See the papers behind this" | **Partly supported.** The nanohybrid abstract says larger hybrids limit use deep in tumors (large particles stall). The mucin paper shows ultrasmall particles penetrating 3D tumor models (deep reach). Washout of ultrasmall particles is textbook but not shown in these abstracts (S6). Heat-triggered release rests on the thesis. |
| Overview 3D label "A nanoparticle, cut open" | none | **Correct.** The overview renders the fully built particle (cores, gel and drug, membrane coat; `step: "coat"`, `view: "cut"` in `engine.ts`) with an octant cut away, magnified in the loupe. |

**Notes on the Blood oxygen link.**

- The study measured how target detectability depends on skin tone, wavelength, beamformer and depth. It did not map
  oxygen.
- Its discussion supports the chapter anyway:
  - Oxygen-saturation measurement needs at least two wavelengths, and loses accuracy under darker skin when one
    wavelength fails.
  - Current unmixing uses signal amplitude only. That backs the caption "oxygen still comes from the delay-and-sum
    signal".
- Keep "skin-tone study" in the label.
- Caveat for later copy: coherence helped deep targets only. For shallow targets (under 5 mm), delay-and-sum did
  better. The lab shows deep targets only, so nothing needs to change, but copy must not generalize the benefit to all
  depths.

**Notes on the Nanoparticles link.**

- The delivery papers support the particles' photoacoustic contrast:
  - The nanoflakes paper reports strong light-to-heat and light-to-sound response.
  - The nanohybrid paper shows a photoacoustic signal through about 1 cm of ex vivo tissue.
  - The mucin paper shows photoacoustic contrast and tumor uptake in vivo.
- The skin-tone and coherence behavior in this state comes from the imaging papers, which this link doesn't open. That
  is acceptable; linking to all papers is optional.

### Bio and positions

- **Consistent:** the bio, short bio, positions, education and recognition agree with one another.
  - PhD, then a completed postdoc, then Lead Scientist since February 2026.
  - The Women in Molecular Imaging Network role runs 2024 to present, which matches "serve on".
- **Independent check:** the J. Biomed. Opt. author biography gives the IISc PhD as 2025 and the IIIT Allahabad
  integrated M.Tech. as 2018.
- **Dates:** the postdoc start (December 2024) is earlier than the degree date (March 2025). That fits the December 2024
  thesis defense recorded in `person.ts`, and no sentence on the site contradicts it.

## Verified as correct

### Research

- **Deck:** correct.
- **Delivery body:** "Ultrasmall light-absorbing cores turn light into heat and sound" is supported by all three
  particle papers (nanoflakes, nanohybrids, mucin), each with particles under 10 nm. The rest of the body is under
  Could not verify, item 1.
- **Imaging body:** the gCNR-on-SLSC claim and the skin-tone detectability claim are correct. The last clause is S1.
- **Questions:** these are the owner's own words from her site, not factual claims.
- **Delivery skills:**
  - Skills 1 and 5 are correct. The mucin paper shows 3D spheroids and in vivo testing.
  - Skill 2, "Capping layers for stability and targeting", is fair. In the mucin paper the mitochondria targeting came
    from a tag attached to the capped particle, not from the cap itself.
  - Skills 3 and 4 are under Could not verify, item 1.
- **Imaging skills:**
  - Skill 1 is correct. The npj contributions list M.T. under image reconstruction, and Radiology Advances credits her
    with Software.
  - Skill 2 is correct. Radiology Advances says M.T. implemented the ROC and Fleiss' κ statistics.
  - Skills 3 and 5 are correct.
  - In skill 4, "target detectability" is correct (npj and SPIE). "Oxygenation mapping" is under Could not verify,
    item 5.

### Publications

- All 15 summaries are accurate against what I could read. S5 is imprecise.
- The `sharma-2025` "My role" list matches the published CRediT contributions exactly.

### Lab captions

I spot-checked these against the full texts that are new to this review. They hold, so the points the README records
as settled stand:

- **Melanin:** it absorbs light at the skin surface and leaves less for deep targets. In the paper, the skin then acts as
  a sound source whose clutter buries what lies below.
- **Skin clutter:** "Coherence cuts most skin clutter" holds. In the phantom, the latex skin's delay-and-sum signal is
  resolved by SLSC, and skin is less visible in SLSC images.
- **"Lost light stays lost":** holds. Detecting shallow targets depends on enough light reaching them, whichever
  beamformer is used.
- **Oxygen:** oxygen mapping needs several colors of light, and the oxygen estimate still comes from delay-and-sum.
- **Ultrasound:**
  - Clutter fills cysts in B-mode.
  - In SLSC, cysts go dark while solid masses blend in.
  - gCNR values near 1 mean fluid.
- **Delivery:** large particles stall at the rim, and ultrasmall particles reach deep.

## Could not verify

1. **The thesis.** Its record is readable only on the IISc network. These claims rest on its title and on the owner's
   own account:
   - a heat-responsive gel that releases a drug when heated;
   - a red blood cell membrane coat that "helps the particle circulate long enough to reach a tumor";
   - "one particle can carry a drug, heat a tumor with light, and show up in a photoacoustic image";
   - the hero lede's "carry drugs into tumors". The only in vivo tumor result in the abstracts I could read is the
     mucin particles, which carried no drug.

   Ask the owner to confirm one point in particular. Does "mimicking red blood cells" in the thesis title mean a red
   blood cell membrane coat, as the Design chapter shows? It could instead mean a red-blood-cell-like shape or
   stiffness. If it does, a whole lab step is wrong.

2. **The mucin paper.** ScienceDirect refuses automated access, and the SSRN preprint sits behind a bot check, which I
   did not attempt. I read the abstract's content through a search-engine index, and two independent queries agreed.
   Check against the article before publishing the proposed summary. The index gave:
   - a mucin cap for stability;
   - particles under 10 nm, crystalline, absorbing in the second near-infrared window;
   - a rhodamine tag for mitochondria;
   - in 2D cells and 3D spheroids: deep penetration and photothermal killing;
   - in vivo: tumor uptake and retention up to about seven hours, accumulating in hypoxic regions.

3. **The hydrogels chapter.** I found no abstract anywhere I could reach, so the summary is checked against the title
   only.

4. **The biopolymer chapter.** I read the abstract's content only through a search index.

5. **Oxygenation mapping (imaging skill 4).** No paper in the list maps oxygen; the npj paper discusses it only. The
   mucin abstract's accumulation "in hypoxic regions" suggests the owner's delivery work used multispectral oxygen
   maps, since that is the usual way to locate hypoxia. If so, that paper is the natural evidence for the lab's Blood
   oxygen state. Confirm with the owner before linking it.

6. **The SPIE papers and the ACS and Taylor & Francis articles.** Full texts are subscription-only, so I read abstracts
   only.

## Proposed summaries

These are drafts for all 15 papers, requested by the lead, for the copy editor to vet for voice. The same rules apply
to each:

- "We" voice. The thesis uses "I", because it has a single author.
- What we did, then what we found, in the past tense.
- The glossary's skill vocabulary.
- No material, drug or wavelength names.
- At most 240 characters.
- No numbers, except two I kept and flag: "3D" in the mucin summary, which the skills list uses too, and "COVID-19", a
  disease name the summary needs.
- None of the hype words the voice rules ban.

Each draft was checked against the source in the last column.

| Paper | Proposed summary | Characters | Checked against |
| --- | --- | --- | --- |
| `enslein-2026-npj-imaging` | We imaged breast masses with photoacoustics in patients of many skin tones. Skin tone, wavelength, beamformer, and depth interacted: coherence beamforming (SLSC) helped deep targets under darker skin; delay-and-sum did better near the skin. | 240 | https://doi.org/10.1038/s44303-026-00193-4 (full text) |
| `arroyo-2026-jbo` | We measured the pulsed-laser dose that visibly injures pig skin of different pigmentation. Darker skin was injured at a lower dose than lighter skin, which matters for photoacoustic systems run close to safety limits. | 217 | https://pmc.ncbi.nlm.nih.gov/articles/PMC13452404/ (full text) |
| `enslein-2026-spie` | We compared how well targets showed under different skin tones in simulated, phantom, and patient photoacoustic breast images. Under darker skin, coherence beamforming (SLSC) gave deep targets a clearer signal than delay-and-sum. | 229 | https://doi.org/10.1117/12.3081139 (abstract) |
| `drabek-2026-spie` | We trained a generative neural network to strip skin clutter from raw photoacoustic data, using simulations with the skin taken out as its goal. In simulations and an early patient test, targets became easier to detect. | 219 | https://doi.org/10.1117/12.3083562 (abstract) |
| `sharma-2025-gcnr-slsc` | We measured contrast objectively (gCNR) on coherence-beamformed (SLSC) breast ultrasound. It told complicated cysts from solid masses more accurately, and with more agreement among radiologists, than reading B-mode images by eye. | 229 | https://pmc.ncbi.nlm.nih.gov/articles/PMC12709606/ (full text) |
| `tripathi-2025-mucin` | We capped ultrasmall light-absorbing particles with a natural biomolecule and tagged them for mitochondria. With light they killed cancer cells and gave photoacoustic contrast; they penetrated 3D tumor models and stayed in tumors for hours. | 240 | https://doi.org/10.1016/j.jddst.2025.106668 (abstract through the search index; see Could not verify, item 2) |
| `tripathi-2024-nanoflakes` | We tested how the length of the capping polymer changes ultrasmall light-absorbing particles. All stayed ultrasmall, crystalline, and gentle on cells, and heated under light; the shortest polymer gave the strongest photoacoustic signal. | 236 | https://doi.org/10.1021/acsabm.3c01123 (abstract) |
| `tripathi-phd-thesis` | I built heat-responsive gel particles that carry light-absorbing cores and mimic red blood cells, to combine drug delivery, heating tumors with light, and photoacoustic imaging. | 177 | https://etd.iisc.ac.in/handle/2005/6575 (title only) |
| `tripathi-2023-nanohybrids` | We grew metal seeds on ultrasmall light-absorbing particles so the hybrids stayed ultrasmall. They heated under light, gave a photoacoustic signal through tissue, and were more toxic to lung cancer cells than either part alone. | 227 | https://doi.org/10.1021/acsanm.3c02405 (abstract) |
| `tripathi-2023-hydrogels` | We reviewed temperature-responsive gels that hold nanoparticles, and how they can be tuned to treat and image tumors locally. | 125 | https://doi.org/10.1016/B978-0-323-99638-9.00019-8 (title only) |
| `wazalwar-2022-mxene-epoxy` | We added surface-treated two-dimensional nanosheets to an aerospace-grade resin. A small amount helped it cure and made it stronger and tougher; more clumped, and the gains fell. Untreated sheets did little. | 207 | https://doi.org/10.1021/acsapm.1c01876 (abstract) |
| `jain-2021-biopolymer` | We reviewed how natural and synthetic biopolymer composites can carry cancer drugs: their properties, targeting, stimulus-triggered release, preparation, and uses in treatment and diagnosis. | 190 | https://doi.org/10.1016/B978-0-12-819724-0.00028-8 (abstract through the search index) |
| `jain-2021-hydroxychloroquine` | We reviewed the toxicity of a repurposed antimalarial drug proposed for COVID-19, along with new delivery approaches, computer modeling, and drug combinations that might make it safer and more effective. | 203 | https://doi.org/10.1080/17512433.2021.1909473 (abstract) |
| `tripathi-2015-malaria` | We discussed genotyping malaria parasites with DNA barcodes, panels of genetic markers, and argued that current panels leave out parasites from India and other regions, so they can’t yet type parasites worldwide. | 212 | https://doi.org/10.1111/tmi.12594 (full text) |
| `tripathi-2015-stem-cells` | We reviewed stem cell technologies, from embryonic and induced pluripotent stem cells to cord blood banking, weighing their promise for human health against ethical questions and the need for closer evaluation. | 210 | https://doi.org/10.4236/jbm.2015.311002 (abstract) |

### Notes on the drafts

The plain words map back to the papers' terms as follows:

- **npj:** the summary is at the 240-character budget. "Wavelength" is used as a word, never with a value. "Near
  the skin" means the paper's shallow targets, under 5 mm.
- **J. Biomed. Opt.:** "pig" means swine. "Visibly injures" is ED50. The accepted exception for "laser" still applies.
- **SPIE (Enslein):** "under darker skin" means the brown and dark skin tones. "Clearer signal" means a higher
  signal-to-noise ratio.
- **SPIE (Drabek):** "generative neural network" means a conditional GAN. "An early patient test" means the single in
  vivo case. I avoided "first" because it is on the banned list.
- **Radiology Advances:** keeps "complicated cysts". Simple cysts were excluded from the analysis, so "cysts" alone
  would overstate the finding.
- **Mucin:** "a natural biomolecule" is mucin, and "tagged them for mitochondria" is the rhodamine B tag. The in vivo
  clause comes from the search-indexed abstract.
- **Nanoflakes:**
  - "Length of the capping polymer" means the polymer's molecular weight.
  - "Shortest" is the lowest molecular weight, which gave the best photoacoustic signal.
  - All particles stayed under 10 nm, were crystalline and compatible with cells, and heated under light.
- **Thesis:**
  - Checked against the title only.
  - "Gel particles" follows the owner's own "thermoresponsive nanogel" wording from her site.
  - No findings are stated, because I couldn't read any.
- **Nanohybrids:**
  - "Metal seeds" means gold.
  - "Through tissue" means ex vivo chicken breast at about 1 to 1.5 cm.
  - The final clause rests on the paper's cell-damage (oxidative-stress) and cell-death assays in lung cancer cells.
- **Hydrogels chapter:** uses "temperature-responsive" rather than the glossary's "heat-responsive". Gels in this field
  include ones that set at body temperature, so "heat-responsive" would narrow the chapter's scope. Checked against the
  title only.
- **Epoxy composite:** it stays accurate without the names, which the title carries anyway:
  - "two-dimensional nanosheets" is MXene;
  - "aerospace-grade resin" is the tetra-functional epoxy;
  - "surface-treated" is polyethyleneimine-functionalized.
- **Biopolymer chapter:** "biopolymer" names a class of materials, not a specific one. It is the chapter's subject, so it
  stays.
- **Drug-repurposing review:** "a repurposed antimalarial drug" replaces the drug's name and stays accurate, because the
  title names the drug. "Computer modeling" is the review's pharmacokinetic and pharmacodynamic modeling.
- **Malaria:** "panels of genetic markers" means SNP panels.

## Evidence notes for the vetting round

These are short facts to check the copy editor's proposals against. They stay in this file; don't put numbers from
here into site prose.

**npj Imaging (Enslein 2026)**

- **Cohort:** 29 patients and 34 masses, 7 of them malignant. Skin tones ran from ITA −78° to 71°. Two wavelengths,
  from the only FDA-approved photoacoustic system in the US.
- **Shallow targets (under 5 mm):** delay-and-sum did better. At the longer wavelength, detectability was 0.80 with
  delay-and-sum and 0.33 with SLSC. No shallow targets were visible at 757 nm when ITA was below 14°.
- **Deep targets (5 mm or more):** SLSC matched or beat delay-and-sum overall (0.81 against 0.80). It was clearly better
  when ITA was 0 or below (0.85 against 0.74). Beamformer choice mattered more than wavelength.
- **Mechanism:** melanin means less light below the epidermis, and the skin itself becomes a sound source that causes
  clutter. SLSC depends less on the amount of light, and the broad skin signal is weaker in SLSC.
- **Oxygen:** discussion only.
- **M.T.'s role:** patient data acquisition, image reconstruction, and comments on the manuscript. J.E. did all the
  analyses.
- **Copy must not say:** that coherence helps all targets, or that the study mapped oxygen.

**J. Biomed. Opt. (Arroyo 2026)**

- **Measure:** ED50, visible redness at 50% of sites. Three swine; single nanosecond pulses at 750 nm.
- **Result:** ED50 was 27.7% lower in the dark swine than in the light one. The lightest swine showed no redness in the
  tested range.
- **Safety limits:** they sit about ten times below ED50.
- **Copy must not say:** "safe dose" or "human skin".

**SPIE (Enslein 2026)**

- **Cohort:** 20 patients.
- **Result:** with SLSC, deep targets under darker skin (ITA 0 or below) had higher signal-to-noise in simulation,
  phantom and patients alike.

**SPIE (Drabek 2026)**

- **Method:** a cGAN on simulated channel data, with skin replaced by water in the ground truth.
- **Test:** one in vivo case, with skin ITA −9° and areola −72°.
- **Result:** channel-data gCNR rose. SLSC gCNR rose in simulation (dark to tan skin) but barely moved in vivo (0.95 to
  0.96).
- **Status:** a feasibility demonstration.

**Radiology Advances (Sharma 2025)**

- **Cohort:** 145 masses in 115 women. The statistics compare 16 complicated cysts with 96 solid masses.
- **Accuracy:** AUC was 0.96 for gCNR on SLSC, against a mean lower bound of 0.67 for B-mode readings. gCNR on B-mode
  scored 0.80.
- **Agreement:** κ rose from 0.40 to 0.59 at the 0.76 cutoff.
- **At 0.76:** 8 of 16 complicated cysts were identified, 95 of 96 solid masses were correctly not called cysts, and no
  cancers were misclassified. The cutoff favors specificity, so copy must not say that coherence "reliably finds cysts".
- **Limit:** masses within 5 mm of the skin are unsuitable for SLSC.
- **M.T.'s CRediT roles:** Data curation, Formal analysis, Investigation, Software, Validation, and Writing – review &
  editing. She implemented the ROC and κ statistics.

**Nanoflakes (2024)**

- **Particles:** polymer-capped, in three polymer molecular weights. All were under 10 nm, crystalline, and absorbed
  most strongly near 1020 nm.
- **Results:**
  - the lowest molecular weight gave the best photoacoustic signal;
  - photothermal efficiency reached 51%;
  - the particles were compatible with cells, and cells died more by apoptosis than by necrosis.

**Nanohybrids (2023)**

- **Particles:** gold grown on the core particles, mean size 8 nm.
- **Results:**
  - photothermal efficiency was 25%, and the particles were photostable;
  - the photoacoustic signal had higher signal-to-noise;
  - ex vivo tests used chicken breast at 1 to 1.5 cm;
  - in lung cancer cells, the hybrids caused more oxidative-stress damage and cell death than their parts alone.
- **Credit:** co-first author with S. Padmanabhan, per the IISc feature.

**Across the list**

No readable source shows in vivo drug delivery or circulation with a membrane coat. Those depend on the thesis.

## Vetting round

This round vets the copy editor's review (`docs/reviews/copy-review.md`, C1 to C33, plus its notes on my drafts) for
scientific accuracy. It covers every proposal that changes meaning; pure interface, layout, code and punctuation
findings are skipped. Where the editor and I proposed changes to the same string, the agreed wording carries both.
Nothing under `src/` was edited.

There are no science disagreements that block the copy review. I changed three of the editor's texts and corrected
one note:

- **C3:** "nanoparticles that both treat and image cancer" becomes "designed to treat and image cancer". No readable
  work treats cancer in patients.
- **C20:** "image-guided therapy" is the owner's phrase, and no readable paper shows it. The owner should confirm it or
  use the alternative given in the table.
- **Nanohybrid draft:** the editor rightly flagged my wording, but the suspected fix points the wrong way. The seeds
  were metal, bound to the light-absorbing particles, not the particles themselves.
- **The editor's "checked and passed" note on the lede** needs a correction; see after the table.

### Verdicts on the copy review

| Finding | Verdict | Final text, or the reason |
| --- | --- | --- |
| C1, lab evidence links | Agree | "Read the paper in Radiology Advances" and "Read the skin-tone paper in npj Imaging". Same papers; keeping "skin-tone" stops the second link reading as an oxygen-mapping paper. |
| C3, award context | Agree with change | "Indian Institute of Science, for doctoral research on nanoparticles designed to treat and image cancer" (102). The readable work kills cancer cells in the lab and images particles in tissue and in vivo. It doesn't treat cancer in patients, so "designed to" keeps the claim to what was shown. |
| C4, WIMIN context | No science objection | Cutting the line loses no scientific content. |
| C5, imaging body | Agree | Carries S1 and splits the sentence. Final text is in the table below. |
| C6, imaging "where" | No science objection | "Postdoctoral research, Johns Hopkins University". The body still names the PULSE Lab. |
| C8, list heading | No science objection | "Skills" describes the list accurately. The items stay the owner's words. |
| C9, delivery skill 4 | Agree | "Red blood cell membrane coats" means the same. The standing caveat from Could not verify, item 1 applies: the owner confirms the thesis particle has a membrane coat. |
| C11, role on featured cards | Agree, with exact text | If the npj card gets a role line, use "Patient data acquisition, image reconstruction, and manuscript review". It comes from the paper's author contributions, which are not a CRediT list, and the owner confirms. Leave out analysis: the paper says "J.E. performed all data analyses". |
| C14, publications deck | Agree; supersedes S8 | "Papers, book chapters, and my thesis, grouped by the two halves of my work, then other and earlier work." (104/140). Its "then other and earlier work" matches the list's actual third group. |
| C15, thesis venue | Agree | "PhD thesis, Indian Institute of Science, Bengaluru" is accurate. |
| C18, 0.76 note | Agree | "The interactive lab uses this study’s 0.76 threshold." (53). Accurate: the study chose 0.76 for gCNR on coherence (SLSC) images, and the lab applies it only there. |
| C19, summaries | See the next section | My drafts, revised after the editor's flags. |
| C20, PhD description | Agree; owner's call on one phrase | "Doctoral research on nanoparticles for photoacoustic imaging and image-guided therapy, advised by Prof. Ashok M. Raichur." (121). "Nanoparticles" is accurate. The readable papers show imaging and light-triggered therapy, but none uses the images to guide treatment. If the thesis doesn't either, use the alternative in the table below. |
| C21, Recent row | No science objection | None. |
| C23, npj update | Agree | "Our paper in npj Imaging examines how skin tone and imaging choices interact." (77). Accurate. It doesn't repeat the new summary, which states the finding. |
| C24, IISc update | Agree; supersedes S7 | "The Indian Institute of Science featured our ultrasmall hybrid nanoparticles, which turn light into heat and sound." (115). The feature describes particles under 8 nm that heat under light and "absorb light and generate ultrasound waves". "Our" fits: she is co-first author. |
| C26, M.Tech. description | No science objection | "A five-year program combining undergraduate and graduate study." The owner confirms the program's structure. |
| C27, bio pair order | Agree | "I am a translational scientist working across biomaterials, drug delivery, and photoacoustic and ultrasound imaging." Changing the order changes no meaning. |
| C32, page title | No science objection (owner's call) | "Madhavi Tripathi · Nanoparticles and photoacoustic imaging" is accurate, though it leaves out ultrasound. |
| C33, MASTER.md example | Agree | "gCNR 0.93: reads as a cyst." The README gives 0.93 as the lab's coherence-cyst value, and a coherence image at or above 0.76 reads as a cyst. |
| C2, C7, C10, C12, C13, C16, C17, C22, C25, C28, C29, C30, C31 | Skipped | Interface, layout, code or punctuation, with no change in meaning. C13's point is also factually right: the "6 papers" group holds a thesis and two book chapters. |

**A correction to the editor's "Checked and passed" note.** The note calls the lede the owner's line from her old
site. Only the closing clause, "connecting how we deliver with how we see", is hers; her old lede described
developing nanomaterials for drug delivery. The lede's "carry drugs into tumors" is still unverified (Could not verify,
item 1). I propose no change, but the owner should confirm it.

### Answers to the editor's flags on my drafts

- **npj, agree.** The finding now leads, and "interacted" is gone:

  "We imaged breast masses with photoacoustics in patients of many skin tones. Under darker skin, coherence beamforming
  (SLSC) made deep targets easier to detect, while delay-and-sum did better for targets near the skin." (217)

  I left wavelength out on purpose. In patients, deep-target results were similar at both wavelengths, so a plain
  sentence saying a longer wavelength helped deep targets would be wrong. The paper states that "among the deeper
  targets, detectability results from each wavelength are comparable per beamformer"
  (https://doi.org/10.1038/s44303-026-00193-4).

- **Sharma, agree.** "It" is gone:

  "We applied an objective contrast measure (gCNR) to coherence-beamformed (SLSC) breast ultrasound. The measure told
  complicated cysts from solid masses more accurately, and with more radiologist agreement, than reading B-mode images
  by eye." (239)

  "Complicated cysts" stays because the analysis excluded simple cysts. Record it in the deck as an accepted exception,
  as the editor suggests.

- **Nanohybrids.** The editor is right that "grew metal seeds on" is wrong. The suspected fix, that the
  light-absorbing particles were the seeds, isn't what this paper did either. The abstract describes three steps:
  1. The two reducing agents were used "to form Au nanoseeds" (https://doi.org/10.1021/acsanm.3c02405).
  2. Hydrogen bonding between the seeds' coating and the particles' polymer cap bound the seeds to the particles.
  3. Galvanic reduction then grew gold from the seeds on the particle surface, keeping the hybrids near 8 nm.

  Revised:

  "We grew metal from seeds bound to ultrasmall light-absorbing particles, keeping the hybrids ultrasmall. Under light
  they heated and gave a photoacoustic signal through tissue, and they harmed lung cancer cells more than either part
  alone." (238)

- **Malaria, agree.** The gloss is in parentheses and the sentence is split:

  "We discussed genotyping malaria parasites with DNA barcodes (panels of genetic markers). We argued that current
  panels leave out parasites from India and other regions, so they can’t yet reliably tell parasite strains apart
  worldwide." (234)

- **Drabek, agree.** "As its goal" is gone:

  "We trained a generative neural network, on paired simulations with and without skin, to strip skin clutter from raw
  photoacoustic data. In simulations and an early patient test, targets became easier to detect." (210)

- **Hydrogels, agree.** Record "temperature-responsive" as an accepted exception.
- **Epoxy, confirmed.** "Aerospace-grade" is the paper's own framing: its abstract calls the nanosheets "toughening
  agents for aerospace-grade epoxy composites" (https://doi.org/10.1021/acsapm.1c01876).
- **S2, S3, S4 and S6:** no change.

Record four exceptions in the copy deck's accepted list, next to the existing "laser" one for the J. Biomed. Opt.
summary:

- "complicated cysts" (Sharma);
- "temperature-responsive" (hydrogels chapter);
- "3D" (mucin), a name rather than a measurement;
- "COVID-19" (drug-repurposing review), also a name.

### Agreed text (science)

This is the exact wording I endorse. The budgets are those in MASTER.md and the plan: summaries ≤ 240 characters,
bridge and decks ≤ 140, theme bodies ≤ 90 words, captions ≤ 180, readouts ≤ 18, skills ≤ 48.

| Item | Where | Agreed text | Length |
| --- | --- | --- | --- |
| S1, with C5 | `themes.ts`, imaging `body` | In Muyinatu Bell’s PULSE Lab at Johns Hopkins, I worked on making photoacoustic and ultrasound images of the breast clearer. We measured contrast objectively (gCNR) on coherence-beamformed ultrasound to tell cysts from solid masses. We also studied how skin tone changes what photoacoustic imaging can detect, and how much pulsed light it takes to injure skin of different tones. | 59 words / 90 |
| S2 | `themes.ts`, `BRIDGE` | Both halves share one piece of physics: absorbed light turns into heat, and pulsed light into sound. | 100 / 140 |
| S3 | `chapters.ts`, caption: Blood oxygen, Lighter, Coherence | Oxygen shifts which colors blood absorbs, so imaging with a few colors maps blood oxygen. Lighter skin adds little clutter, but coherence still brings out faint vessels. | 169 / 180 |
| S4 | `chapters.ts`, caption: Solid mass, Delay-and-sum, Image | Many solid masses also look dark in B-mode, which is why cysts and solid masses get confused. | 93 / 180 (104 with the gCNR suffix) |
| S5 | `publications.ts`, `drabek-2026-spie` | Superseded by the Drabek summary below. | n/a |
| S6 (optional) | `chapters.ts`, readout: Ultrasmall, Hours, Retention | Fading | 6 / 18; check the mucin paper's in vivo figure first |
| S7, with C24 | `about.ts`, update `2023-09-iisc-feature` | The Indian Institute of Science featured our ultrasmall hybrid nanoparticles, which turn light into heat and sound. | 115 |
| S8, with C14 | `site.ts`, `DECKS.publications` | Papers, book chapters, and my thesis, grouped by the two halves of my work, then other and earlier work. | 104 / 140 |
| C1 | `chapters.ts`, `evidence()` | Read the paper in Radiology Advances / Read the skin-tone paper in npj Imaging | 36; 39 |
| C3 | `about.ts`, `recognition[0].context` | Indian Institute of Science, for doctoral research on nanoparticles designed to treat and image cancer | 102 |
| C6 | `themes.ts`, imaging `where` | Postdoctoral research, Johns Hopkins University | 47 |
| C8 | `research.tsx`, list heading | Skills | 6 |
| C9 | `themes.ts`, delivery skill 4 | Red blood cell membrane coats | 29 / 48 |
| C11 (if added; owner confirms) | `publications.ts`, npj `role` | Patient data acquisition, image reconstruction, and manuscript review | 69 |
| C15 | Thesis venue line | PhD thesis, Indian Institute of Science, Bengaluru | 50 |
| C18 | `publications.ts`, `sharma-2025-gcnr-slsc.note` | The interactive lab uses this study’s 0.76 threshold. | 53 |
| C20 (owner confirms "image-guided") | `person.ts`, `education[0].description` | Doctoral research on nanoparticles for photoacoustic imaging and image-guided therapy, advised by Prof. Ashok M. Raichur. Alternative: Doctoral research on nanoparticles for photoacoustic imaging and light-activated therapy, advised by Prof. Ashok M. Raichur. | 121; alternative 124 |
| C23 | `about.ts`, update `2026-09-npj-imaging` | Our paper in npj Imaging examines how skin tone and imaging choices interact. | 77 |
| C26 (owner confirms) | `person.ts`, `education[1].description` | A five-year program combining undergraduate and graduate study. | 63 |
| C27 | `person.ts`, bio sentence 1 | I am a translational scientist working across biomaterials, drug delivery, and photoacoustic and ultrasound imaging. | 116 |
| C32 (owner's call) | `layout.tsx`, page title | Madhavi Tripathi · Nanoparticles and photoacoustic imaging | 58 / 60 |
| C33 | `MASTER.md`, voice example | gCNR 0.93: reads as a cyst. | 27 |
| Summary | `enslein-2026-npj-imaging` | We imaged breast masses with photoacoustics in patients of many skin tones. Under darker skin, coherence beamforming (SLSC) made deep targets easier to detect, while delay-and-sum did better for targets near the skin. | 217 / 240 |
| Summary | `arroyo-2026-jbo` | We measured the pulsed-laser dose that visibly injures pig skin of different pigmentation. Darker skin was injured at a lower dose than lighter skin, which matters for photoacoustic systems run close to safety limits. | 217 / 240 |
| Summary | `enslein-2026-spie` | We compared how well targets showed under different skin tones in simulated, phantom, and patient photoacoustic breast images. Under darker skin, coherence beamforming (SLSC) gave deep targets a clearer signal than delay-and-sum. | 229 / 240 |
| Summary | `drabek-2026-spie` | We trained a generative neural network, on paired simulations with and without skin, to strip skin clutter from raw photoacoustic data. In simulations and an early patient test, targets became easier to detect. | 210 / 240 |
| Summary | `sharma-2025-gcnr-slsc` | We applied an objective contrast measure (gCNR) to coherence-beamformed (SLSC) breast ultrasound. The measure told complicated cysts from solid masses more accurately, and with more radiologist agreement, than reading B-mode images by eye. | 239 / 240 |
| Summary | `tripathi-2025-mucin` | We capped ultrasmall light-absorbing particles with a natural biomolecule and tagged them for mitochondria. With light they killed cancer cells and gave photoacoustic contrast; they penetrated 3D tumor models and stayed in tumors for hours. | 240 / 240; check the in vivo clause against the article (Could not verify, item 2) |
| Summary | `tripathi-2024-nanoflakes` | We tested how the length of the capping polymer changes ultrasmall light-absorbing particles. All stayed ultrasmall, crystalline, and gentle on cells, and heated under light; the shortest polymer gave the strongest photoacoustic signal. | 236 / 240 |
| Summary | `tripathi-phd-thesis` | I built heat-responsive gel particles that carry light-absorbing cores and mimic red blood cells, to combine drug delivery, heating tumors with light, and photoacoustic imaging. | 177 / 240; checked against the title only |
| Summary | `tripathi-2023-nanohybrids` | We grew metal from seeds bound to ultrasmall light-absorbing particles, keeping the hybrids ultrasmall. Under light they heated and gave a photoacoustic signal through tissue, and they harmed lung cancer cells more than either part alone. | 238 / 240 |
| Summary | `tripathi-2023-hydrogels` | We reviewed temperature-responsive gels that hold nanoparticles, and how they can be tuned to treat and image tumors locally. | 125 / 240; checked against the title only |
| Summary | `wazalwar-2022-mxene-epoxy` | We added surface-treated two-dimensional nanosheets to an aerospace-grade resin. A small amount helped it cure and made it stronger and tougher; more clumped, and the gains fell. Untreated sheets did little. | 207 / 240 |
| Summary | `jain-2021-biopolymer` | We reviewed how natural and synthetic biopolymer composites can carry cancer drugs: their properties, targeting, stimulus-triggered release, preparation, and uses in treatment and diagnosis. | 190 / 240 |
| Summary | `jain-2021-hydroxychloroquine` | We reviewed the toxicity of a repurposed antimalarial drug proposed for COVID-19, along with new delivery approaches, computer modeling, and drug combinations that might make it safer and more effective. | 203 / 240 |
| Summary | `tripathi-2015-malaria` | We discussed genotyping malaria parasites with DNA barcodes (panels of genetic markers). We argued that current panels leave out parasites from India and other regions, so they can’t yet reliably tell parasite strains apart worldwide. | 234 / 240 |
| Summary | `tripathi-2015-stem-cells` | We reviewed stem cell technologies, from embryonic and induced pluripotent stem cells to cord blood banking, weighing their promise for human health against ethical questions and the need for closer evaluation. | 210 / 240 |

## Final answers

These answer the copy editor's four open questions (`copy-review.md`, "Vetting round"). The four texts below replace
the matching rows of "Agreed text (science)". I also accept the editor's three changes that keep the meaning; all are
accurate:

- "target visibility" in `enslein-2026-spie` (223);
- "gel carriers that hold" in `tripathi-phd-thesis` (175);
- "with more, the sheets clumped and the gains fell" in `wazalwar-2022-mxene-epoxy` (223).

**1. npj summary: yes, the editor's semicolon version applies.**

The delay-and-sum advantage for targets near the skin is not tied to darker skin. In patients, delay-and-sum with either
wavelength "produced the greatest detectability across the majority of ITA values considered"
(https://doi.org/10.1038/s44303-026-00193-4). It won on average at both wavelengths.

The exception is the darkest skin. There, shallow targets often weren't visible at all: none at the shorter
wavelength when ITA was below 14°, and few at the longer one. So neither beamformer won there, and nothing contradicts
the clause.

Final (212 / 240): "We imaged breast masses with photoacoustics in patients of many skin tones. Under darker skin,
coherence beamforming (SLSC) made deep targets easier to detect; for targets near the skin, delay-and-sum did better."

**2. Drabek summary: "reduce" is the accurate word, and the patient test showed feasibility only.**

- **The verb.** The network's training target was skin-free data, but the demonstrated effect was partial: target
  contrast in the raw data rose, and clutter wasn't removed. The authors call the work "initial demonstration of
  feasibility … promising to mitigate melanin-induced artifacts" (https://doi.org/10.1117/12.3083562).
- **The patient.** In the single patient, target contrast in the raw channel data rose from 0.13 to 0.39. Contrast in
  the coherence image was already near its ceiling and barely moved, from 0.95 to 0.96. So "targets became easier to
  detect" holds for the simulations, but not for the final patient image.

Final (228 / 240): "We trained a generative neural network, on paired simulations with and without skin, to reduce skin
clutter in raw photoacoustic data. Targets became easier to detect in simulations, and an early patient test showed it
can work."

**3. Nanohybrids: "under light" doesn't cover the harm, so use the 237 version.**

The abstract doesn't say the cells were lit. It attributes the effect to reactive oxygen species: "In vitro
experiments suggest ROS-mediated anticancer effects on lung cancer cells"
(https://doi.org/10.1021/acsanm.3c02405). The same abstract also credits one of the reducing agents with an anticancer
role of its own, which is chemical, not light-driven.

The IISc feature, too, lists the particles' reactive oxygen as a property separate from heating under light. Since
light-triggered harm isn't shown, the harm must stay outside "under light".

Final (237 / 240): "We grew metal from seeds bound to ultrasmall light-absorbing particles, keeping the hybrids ultrasmall.
They heated under light, gave a photoacoustic signal through tissue, and were more toxic to lung cancer cells than
either part alone."

**4. Imaging theme body: yes, say "pig skin".**

The study reports thresholds "in a swine model"
(https://pmc.ncbi.nlm.nih.gov/articles/PMC13452404/). Without "pig", "how much pulsed light it takes to injure skin"
can read as experiments that injured people's skin. That is wrong, and it matters. "Of different tones" still fits:
the paper sorts the swine by skin tone (ITA) as well as by pigmentation.

Final (60 words / 90): "In Muyinatu Bell’s PULSE Lab at Johns Hopkins, I worked on making photoacoustic and ultrasound
images of the breast clearer. We measured contrast objectively (gCNR) on coherence-beamformed ultrasound to tell cysts
from solid masses. We also studied how skin tone changes what photoacoustic imaging can detect, and how much pulsed
light it takes to injure pig skin of different tones."

## Three-card Research

This is an accuracy check of `directions` in `src/content/themes.ts`, the three Research cards, as of 28 September
2026. Voice is the copy editor's. Every text is within budget: bodies ≤ 45 words, skills ≤ 48 characters.

| Item | Verdict | Exact text, or why |
| --- | --- | --- |
| Delivery, body | Agree with change | "I design nanoparticles in layers, each with one job: light-absorbing cores turn light into heat and sound, a heat-responsive gel holds a drug until it’s heated, and a red blood cell membrane coat helps the particle circulate longer." (38 words). Every particle circulates; the coat lengthens that time. The lab says the same ("keeps it circulating longer"; readout "Circulate longer"). The coat itself still needs the owner's confirmation (Could not verify, item 1). |
| Delivery, where, question and skills | Agree | Unchanged from the vetted texts. |
| Photoacoustic, where | Agree | "Indian Institute of Science and Johns Hopkins University" (56). The owner's photoacoustic work spans both: the particle papers at IISc, and the skin-tone and injury studies at Johns Hopkins. |
| Photoacoustic, question | Agree | The owner's own words. |
| Photoacoustic, body | Agree | As written (43 words). Its first sentence states the physics precisely: pulsed light, absorbed by tissue or particles, becomes sound. The second sentence keeps the vetted "pig skin" clause. |
| Photoacoustic, skill 1 | Agree | "Nanoparticles as photoacoustic contrast agents" (46). The nanohybrid, nanoflake and mucin papers each test photoacoustic signal. |
| Photoacoustic, skill 2 | Agree | "Sound-speed selection in image reconstruction" (45). This is the right gloss: reconstruction assumes a speed of sound to turn arrival times into positions, and choosing it well sharpens targets. The term of art appears in the title "Automatic sound speed selection in photoacoustic image reconstruction using an autofocus approach" (https://doi.org/10.1117/1.3619139). None of the 15 papers shows this skill; it is the owner's claim. |
| Photoacoustic, skill 3 | Agree | "Oxygenation mapping and target detectability" (44). Target detectability is supported by the npj and SPIE papers. Oxygenation mapping is the owner's claim (Could not verify, item 5). |
| Photoacoustic, skill 4 | Agree | "Simulation, phantom, and clinical studies" (41). |
| Ultrasound, where | Agree | "Postdoctoral research, Johns Hopkins University" (47). |
| Ultrasound, question | Agree | The owner's own words. |
| Ultrasound, body | Agree | As written (25 words). It matches the Radiology Advances study. "Breast cysts" is fine at this level; the summary keeps "complicated cysts". |
| Ultrasound, skills 1 to 4 | Agree | As written. "Breast cyst and solid-mass characterization" (43) is the owner's old-site wording and matches the study. |

**Notes**

- **The bridge line is gone** from `src/`, so S2 no longer applies. The photoacoustic body's first sentence now carries
  the pulsed-light physics, and that is enough for the delivery body's "turn light into heat and sound".
- **Optional, not a correction:** the owner's photoacoustic work also used coherence (SLSC) beamforming, in the npj and
  SPIE papers, but the beamforming skill appears only on the ultrasound card. Adding it to the photoacoustic card would
  be accurate if she wants it there.
