# Copy review

An editor's and UX writer's pass over every word on the page before launch: the lab, Recognition and service,
Research, Publications, About, Contact, the footer, the 404, and the metadata. Reviewed on 27 September 2026
against `design-system/MASTER.md`, `docs/site-plan/PLAN.md` §4.3–4.4, and `docs/site-plan/B-structure-and-content.md` §5.
Nothing under `src/` was edited and nothing was committed. I regenerated `docs/copy-deck.md` once, as the lead allowed.

**How it was read.** The copy deck, then every component that holds its own strings, then the running page at
http://localhost:3217 in headless Chrome at 1440 × 900 and 390 × 844 with reduced motion. I clicked every lab
chapter and control state that changes words, used the Show filter by mouse and keyboard, opened the citation
panel, forced a clipboard failure, and loaded the 404.

**The site changed while I worked.** These landed during the review and are reflected below: the Recognition and
service rail under the lab, lab-hosted PDFs on the two SPIE papers, the CRediT role as the journal prints it, the
About thesis link's "(IISc network only)", the IISc update without material names, the site-wide half of
MASTER.md, and a rewritten README. Two findings I had drafted were fixed by these changes and are dropped. Line
numbers are as of about 23:45. For about a minute the page returned a 500 from an in-progress import in
`instrument-panel.tsx`; it cleared on its own.

**The science review** (`docs/reviews/science-review.md`, S1–S8) is cross-referenced here, not repeated. Where a
voice fix and a science fix touch the same sentence, the proposed text below carries both.

**Severity.** P1 breaks a rule or confuses; P2 improves. "Owner's call" marks the owner's own words (summaries, bios,
résumé lines, research questions, skill vocabulary). Paper titles are verbatim and untouched throughout.

## The ten changes that would most raise the quality

1. **Make the Show filter filter (C12).** Clicking an option changes the address and announces a count, but the
   list and the selected option never move. A committee's main tool on the page does nothing, and the live status
   tells screen-reader users it worked.
2. **Give every paper summary a finding (C19).** All 15 say what a paper "explores", "investigates", or "examines";
   none says what it found, and six name materials. The science reviewer's drafts fix this; I vet them next.
3. **Show recognition as a list, not a carousel (C2).** The rail shows one of three items at a glance, and the
   style guide bans carousels below the hero.
4. **One noun for the publication list (C13).** "items", "papers", and "work" count the same things, and "6 papers"
   counts a thesis and two book chapters. Drop the repeated counts; make "Hide them" say what it hides.
5. **Untangle the imaging body's last sentence (C5).** "pulsed light skin" reads as "light skin", and the clause
   is also scientifically wrong (S1).
6. **Show her part on the featured cards (C11, C10).** The imaging half's featured paper shows "Open access" but
   not her CRediT roles; its title also behaves differently from every other paper title.
7. **Take the theranostic jargon out of the About and Recognition lines (C20, C3).** It breaks the owner's own
   titles-only rule.
8. **Make the copy-failure message true and typographically right (C29).** It says "The text is selected" when
   nothing is, and it has the page's only straight apostrophe.
9. **Give the lab chips accessible names that match what they show (C7).** Voice-control users can't say "In the
   lab: Design" and hit it.
10. **Trim Recent (C21, C22).** One row repeats the row above it, and each row carries a label ("paper", "role")
    that its own link already says.

## The 30-second skim

- **What she does: yes.** The headline, the lede, the two Research titles, and the skill lists say it in
  seconds.
- **What she found: no.** Every summary describes a process, and the Research bodies describe methods. The
  science reviewer's rewrites (C19) are the fix; one finding per paper is enough.
- **What she led: partly.** "First author" marks seven items. The imaging half shows her part once, the CRediT
  line on the Radiology Advances entry, and not on its featured card (C11). The imaging body says only "I worked
  on". The owner's own "My role" lines for the other imaging papers (B §6, item 8) would do more here than any
  rewording.
- **Rhythm.** Research scans well: title, where, question, body, skills, two cards. Publications is dense but
  regular, and three cuts speed it up: the group counts (C13), the "Journal article in" prefix (C15), and the
  second Scholar link (C17). The recognition rail (C2) is the one place a skim misses content.

## One name per thing

| Thing | Names on the page | Verdict |
| --- | --- | --- |
| The two halves | "Nanomaterials for delivery", "Light and sound for imaging" (Research, group headings); "Delivery", "Imaging" (filter) | **Keep.** Each short form maps onto the heading its filter shows. "Delivery" also names a lab tab. That's tolerable: the tab belongs to that half, and its "See the papers behind this" link lands on the Delivery filter. |
| The lab's four parts | Tabs; "In the lab: X" chips and links; "Pick a skill to look closer"; screen-reader labels say "chapter" | **Change the hidden word** (C7). The visible names agree. |
| Photoacoustics | Tab and chip "Photoacoustics"; prose "photoacoustic imaging", "photoacoustic image" | **Keep.** A lab part's name against the field in prose, and it fits the tab at 390 px. |
| The publication set | "items" (filter status), "papers" (group counts, disclosure), "work" (deck, "Other and earlier work"), "Publications" (section) | **Change** (C13). |
| A paper at its publisher | "Read the paper" (featured cards, Recent); "Read the study in Radiology Advances" and "Read the skin-tone study in npj Imaging" (lab) | **Change the lab's two** (C1). |
| "The lab" | The hero ("Skip the lab", "In the lab:", the footer note) against the PULSE Lab (Research, About, the PDF note) | **Keep.** Fix the one sentence where they collide (C18). |
| Membrane coat | "Membrane coat" (lab), "membrane coat" (Research body), "membrane coatings" (skill) | **Change** (C9). |
| Target visibility | "Target visibility" (readout), "target visibility" (summaries), "target detectability" (skill 4, three titles) | **Keep.** The skills list uses terms of art, as the accepted "channel data" exception already allows. |
| Blood oxygen | "Blood oxygen" (control), "maps blood oxygen" (caption), "Oxygenated", "Deoxygenated" (legend), "Oxygenation mapping" (skill) | **Keep,** for the same reason. |
| The imaging pair's order | "photoacoustic and ultrasound" (lede, short bio, description, tab order); "ultrasound, and photoacoustic imaging" (bio sentence 1, JSON-LD) | **Change** (C27). |
| Theranostics | Titles only, by the glossary; also "nanotheranostic" (PhD row) and "cancer theranostics" (award) | **Change** (C20, C3). The summaries are in C19. |
| The Scholar profile | "Google Scholar profile" (Publications); "Google Scholar" (Contact, footer) | **Change** (C17). |
| Dates in lists | Timeline "Feb 2026–present"; Recent "4 Sep 2026", "Feb 2026", "11 Sep 2023"; MASTER.md says "2026" in lists, `format.ts` says "Sep 2026" | **Change** (C22, C33). |
| Muyinatu Bell | "Muyinatu Bell’s PULSE Lab" (Research); "Prof. Muyinatu A. Lediju Bell" (About); full names in author lists | **Keep.** Formal in the timeline, as her résumé has it; conversational in prose; author lists verbatim. |
| Free to read | "Open access", "Free to read", "Free PDF" | **Keep.** These are three different facts. "Free PDF" sits beside "PDF (PULSE Lab)", a mild echo that earns its place as a status word. |
| Nanomaterials | The headline, plus the two titles that mirror its lines | **Keep.** |

## Findings

### Hero and lab

The lab has been through two reviews and holds up. Every caption, readout, hint, option, and 3D label is within
budget, on-glossary, and in voice. One consistency point:

**C1 · P2 · Lab evidence links say "study" where the rest of the site says "paper"**
- **Where:** `src/content/chapters.ts:504` and `:506` (`evidence()`)
- **Now:** "Read the study in Radiology Advances"; "Read the skin-tone study in npj Imaging"
- **Why:** These two papers are "Read the paper" on their featured cards and in Recent. The rule ties "Read the
  paper" to leaving the site (B §5.1, item 6; MASTER.md). The verb already follows the rule; the noun should too.
  The science review asks to keep "skin-tone" in the second label, and this does.
- **Proposed:** "Read the paper in Radiology Advances" (36); "Read the skin-tone paper in npj Imaging" (39)

### Recognition and service (the new rail)

**C2 · P1 · A carousel for three items**
- **Where:** `src/components/site/recognition-rail.tsx` (whole component), rendered by `recognition.tsx`
- **Now:** A horizontal rail with Previous and Next buttons and a "1 / 3" counter. At 1440 px the second card is
  cut mid-word ("Leadership committee, Wome…") and the third is off-screen; at 390 px one card shows.
- **Why:** MASTER.md bans carousels below the hero ("Never below the hero: … carousels"; anti-patterns: "Carousels").
  PLAN §2.1 row 04 promises "nothing hidden in carousels", and the components table in C-design-system.md §3
  (line 336) specifies awards and service as "Year, title, context. … **No carousel.**" A committee skimming sees one of three items, and the cut-off text
  reads as a rendering fault.
- **Proposed:** Keep the section where it is, under the lab, and set the three items as rows (year in the label
  track, then title and context), the way About showed them before today. If the owner chose the rail, record the
  exception in MASTER.md so the guide and the page agree. The rail's own strings are fine as they stand.

**C3 · P1 · Owner's call · "cancer theranostics" in the award context**
- **Where:** `src/content/about.ts:11` (`recognition[0].context`)
- **Now:** "Indian Institute of Science, for doctoral research in materials engineering and cancer theranostics"
- **Why:** The glossary gives "treat and image with one particle" and reserves "theranostics" for titles
  (B §5.2). MASTER.md adds that copy around titles names skills.
- **Proposed** (100): "Indian Institute of Science, for doctoral research on nanoparticles that both treat and image cancer"

**C4 · P2 · Owner's call · The WIMIN context restates the title**
- **Where:** `src/content/about.ts:18` (`recognition[1].context`)
- **Now:** "Contributing to a community of women working in molecular imaging"
- **Why:** The network's name already says this, so the line adds nothing.
- **Proposed:** Cut the line; the title and "2024–present" carry the row. If the owner wants a line, it should say
  what she does on the committee, in her words.

### Research

**C5 · P1 · Imaging body: a garden path, and a 37-word sentence**
- **Where:** `src/content/themes.ts:37` (`themes[1].body`)
- **Now:** "…to tell cysts from solid masses, and studied how skin tone changes what photoacoustic imaging can detect, and
  how much pulsed light skin of different tones can safely take."
- **Why:** "pulsed light skin" parses as "light skin", which the Skin tone control has just taught readers to read as a
  tone, so they backtrack. Two "and how…" clauses hang on one long sentence. S1 separately shows "can safely take"
  is wrong: the study measured the dose that injures pig skin. The proposal uses S1's wording, which also removes
  the garden path, and splits the sentence.
- **Proposed** (59 words / 90): "In Muyinatu Bell’s PULSE Lab at Johns Hopkins, I worked on making photoacoustic and
  ultrasound images of the breast clearer. We measured contrast objectively (gCNR) on coherence-beamformed
  ultrasound to tell cysts from solid masses. We also studied how skin tone changes what photoacoustic imaging can
  detect, and how much pulsed light it takes to injure skin of different tones."

**C6 · P2 · The imaging "where" line repeats the body's first clause**
- **Where:** `src/content/themes.ts:35` (`themes[1].where`)
- **Now:** "Postdoctoral research, PULSE Lab, Johns Hopkins University", then the body opens "In Muyinatu Bell’s PULSE Lab
  at Johns Hopkins, …"
- **Why:** The label repeats the content directly under it. Trimming the label also makes it parallel to "PhD
  research, Indian Institute of Science", and follows the naming rule: "Johns Hopkins University" first, then
  "Johns Hopkins".
- **Proposed** (47): "Postdoctoral research, Johns Hopkins University"

**C7 · P1 · Lab chips' accessible names don't contain their visible labels**
- **Where:** `src/components/site/layout.tsx:62` (`LabChip`, used in Research); `src/components/site/publications.tsx:152`
  (the inline links in each entry)
- **Now:** Visible "In the lab: Design"; accessible name "Open the Design chapter of the lab"
- **Why:** WCAG 2.5.3 (Label in Name): a voice-control user who says what they see ("click In the lab Design")
  misses. The name also brings in "chapter", a word no sighted visitor meets; the page calls these skills ("Pick a
  skill to look closer").
- **Proposed:** On `LabChip`, drop the `aria-label`, so the visible "In the lab: Design" is the name. On the
  inline entry links, whose visible text is just "Design", set the name to "In the lab: Design".

**C8 · P2 · "What I did" heads a list of topics**
- **Where:** `src/components/site/research.tsx:46`; the budget row in MASTER.md ("What I did" items)
- **Now:** "What I did" above noun phrases: "Ultrasmall light-absorbing nanoparticles", "Raw channel data analysis"
- **Why:** The plan wanted items "written as work done" (PLAN §4.4). The items are the owner's skill vocabulary,
  written as topics, so a past-tense heading reads oddly over them. The voice rule also puts skills in the present
  tense.
- **Proposed:** Retitle the list "Skills" and update the MASTER.md row. The items stay the owner's words.

**C9 · P2 · Owner's call · "coatings" where the glossary says "coat"**
- **Where:** `src/content/themes.ts:26` (delivery skill 4)
- **Now:** "Red blood cell membrane coatings"
- **Why:** The glossary's name is "membrane coat", and "coating" is on its "Not" list. The lab and the body both say
  "coat".
- **Proposed** (29 / 48): "Red blood cell membrane coats"

**C10 · P2 · A featured title goes somewhere different from every other paper title**
- **Where:** `src/components/site/featured-paper.tsx:18`
- **Now:** The featured card's title jumps to the entry below (`#pub-…`), while "Read the paper" in the same card
  leaves the site. Every paper title in Publications opens the publisher.
- **Why:** The same-looking element does two different things, and neither says which. Visitors treat paper titles
  as links to the paper.
- **Proposed:** Link the featured title to the DOI too, and keep "Read the paper". The rule is then simple: a
  paper's title opens the paper.

**C11 · P2 · The featured cards leave out her part**
- **Where:** `src/components/site/featured-paper.tsx:22–23`
- **Now:** Year and venue, title, summary, then "First author" or "Open access". The Radiology Advances card shows
  "Open access" but not the CRediT line its list entry carries.
- **Why:** For the imaging half, the featured cards are where a committee looks for what she did. The component's
  own comment promises "the owner's part", and B §3.4 lists "role" among a featured paper's fields.
- **Proposed:** Under the summary, render "My role: …" whenever `paper.role` exists; the text is unchanged. The
  science review's evidence notes say the npj paper's author contributions credit her with patient data
  acquisition and image reconstruction. A "My role" line there, confirmed by the owner, would give the second
  imaging card her part too.

### Publications

**C12 · P1 · The Show filter doesn't filter, and its status says it did** (a code bug, found in passing)
- **Where:** `src/components/site/show-filter.tsx:42` and `:61`
- **Now:** Click "Imaging" and the address becomes `?show=imaging` and the status announces "Showing 5 of 15
  items.", but the list doesn't change and "All" stays selected. The arrow keys always step from the stale choice,
  so repeated presses never get past the next option. A fresh load with `?show=…` does work.
- **Why:** Both calls pass `history.state`, which carries Next's internal `__NA` marker, to `history.replaceState`.
  Next's patched `replaceState` treats a call with that marker as its own and skips syncing `useSearchParams`
  (`node_modules/next/dist/client/components/app-router.js`, around lines 255–275). The component never sees the
  new value. Beyond the broken control, the live status tells screen-reader users something false.
- **Proposed:** Change both calls to `history.replaceState(null, "", url)`; Next copies its own state into the new
  entry. Then re-test that clicking, the arrow keys, Back and Forward, and the `#pub-…` reveal all update the list
  and the selected option together.

**C13 · P1 · Three nouns for one list, and counts said twice**
- **Where:** `src/components/site/show-filter.tsx:65` (status); `src/components/site/publications.tsx:76` (group count),
  `:81–82` (disclosure)
- **Now:** Status "Showing all 15 items." and "Showing 6 of 15 items."; beside each group heading "6 papers",
  "5 papers", "4 papers"; the disclosure reads "Show the 4 papers" and then "Hide them".
- **Why:**
  - The "6 papers" group holds a thesis and two book chapters, so the label is wrong.
  - The counts repeat the filter directly above ("Delivery 6"); for the last group, the button repeats it too.
  - "Hide them" means nothing on its own. Screen readers announce the button alone, and the confirmation should
    use the same words as the action.
- **Proposed:**
  - Status: "Showing all 15 publications." (28) and "Showing 6 of 15 publications." (29)
  - Delete the group count labels.
  - Disclosure: "Show the 4 papers" and "Hide the 4 papers" (17). All four in that group are papers.

**C14 · P2 · The deck promises two groups; the list has three (agrees with S8)**
- **Where:** `src/content/site.ts:21` (`DECKS.publications`)
- **Now:** "Papers, book chapters, and my thesis, grouped by the two halves of my work. First-author work is marked."
- **Why:** The list has a third group, "Other and earlier work" (S8). S8's fix adds a clause and leaves "work" three
  times in two sentences. The second sentence also repeats the "First author 7" filter option directly below it.
- **Proposed** (104 / 140): "Papers, book chapters, and my thesis, grouped by the two halves of my work, then other and
  earlier work."

**C15 · P2 · "Journal article in Journal of…", and the thesis loses "PhD"**
- **Where:** `src/components/site/publications.tsx:129–131`
- **Now:** "Journal article in Journal of Drug Delivery Science and Technology, 105, 106668" (and the same stutter for
  Journal of Biomedical Optics); "Thesis, Indian Institute of Science, Bengaluru"
- **Why:** Repeated words slow a skim. The code strips "PhD thesis, " from the stored venue and prints "Thesis, ",
  which drops the degree a committee cares about.
- **Proposed:**
  - Journal articles, the common case: print no type, just "Journal of Drug Delivery Science and Technology,
    105, 106668".
  - Keep "Book chapter in", "Conference paper in", and "Review in".
  - Thesis: print the stored venue, "PhD thesis, Indian Institute of Science, Bengaluru" (50).

**C16 · P2 · "Paper" is in the data and the deck, but not on the page**
- **Where:** `src/content/publications.ts:11` (`label: "Paper"`); `src/components/site/publications.tsx:101`
  (filters it out)
- **Now:** The deck lists a "Paper" link for 14 entries, but none renders. The title is the only way to the paper,
  and its underline appears only on hover, so on a phone nothing says a title is a link.
- **Why:** Labels should say what happens, and the deck should match the page it describes. Without "Paper", the
  Journal of Biomedical Optics entry offers only "PubMed Central" and "Cite".
- **Proposed:** Render "Paper" as the first link in each entry's row, in the plan's order (Paper, PDF, Preprint,
  PubMed Central, Thesis record, Cite). If the lead would rather keep the rows lean, drop "Paper" from the data so
  the deck stops listing it.

**C17 · P2 · A second Scholar link that repeats its own sentence**
- **Where:** `src/components/site/publications.tsx:51–54`
- **Now:** "Checked against Google Scholar and Crossref in September 2026. Google Scholar profile"
- **Why:** The link text repeats the sentence before it. The page links the same profile three times (here,
  Contact, footer).
- **Proposed** (62): "Checked against Google Scholar and Crossref in September 2026.", with "Google Scholar" linked in the
  sentence and the separate link deleted.

**C18 · P2 · "The lab’s 0.76 threshold" can mean the PULSE Lab's**
- **Where:** `src/content/publications.ts:154` (`sharma-2025-gcnr-slsc.note`)
- **Now:** "The lab’s 0.76 threshold comes from this study."
- **Why:** The line sits under an author list from Muyinatu Bell's PULSE Lab, so "the lab" can read as that lab. The
  science review confirms the fact; only the reference is loose.
- **Proposed** (53): "The interactive lab uses this study’s 0.76 threshold."

**C19 · P1 · Owner's call · Every summary breaks the summary rules**
- **Where:** `src/content/publications.ts`, all 15 `summary` fields; the four featured ones are also on Research's cards
- **Now:**
  - Verb-first fragments with no subject: "Explores…", "Investigates…", "Evaluates…", "Compares…", "Studies how…",
    "Combines…", "Examines…", "Discusses…", "Reviews…".
  - Five switch to a noun phrase: "A study of…", "A chapter on…", "A chapter examining…", "A literature review
    of…", "Doctoral research on…".
  - Six name materials or drugs (the deck flags them), one has a number ("29 patients"), and several use terms the
    glossary keeps to titles ("phototheranostic", "photothermal therapy" without plain words first).
- **Why:**
  - "We" belongs in summaries (PLAN §4.3), and findings take the past tense.
  - The owner's rule keeps materials in titles only.
  - None of the 15 says what was found, which is the committee's second question.
- **Proposed:** The science reviewer is drafting all 15 (`science-review.md`, "Proposed summaries"). One form for all
  of them, and my vetting criteria, are under "Notes for the vetting round" below. I'm not rewriting them here.

### About

**C20 · P1 · Owner's call · "nanotheranostic platforms"**
- **Where:** `src/content/person.ts:71` (`education[0].description`)
- **Now:** "Doctoral research on nanotheranostic platforms for photoacoustic imaging and image-guided therapy, advised by
  Prof. Ashok M. Raichur."
- **Why:** The glossary keeps "theranostic" for titles (B §5.2), and "platforms" is vague.
- **Proposed** (121): "Doctoral research on nanoparticles for photoacoustic imaging and image-guided therapy, advised by
  Prof. Ashok M. Raichur."

**C21 · P2 · Recent repeats the timeline directly above it**
- **Where:** `src/content/about.ts:40–47` (update `2026-02-synapseek`)
- **Now:** "Lead Scientist at SynapSeek. Leading scientific and AI/ML strategy for a neuro-diagnostic mapping platform."
- **Why:** The first timeline row says the same thing a screen earlier, and the bio and short bio say it too: four
  mentions in one section. The Best Thesis Award update from the old site was already dropped for this reason.
- **Proposed:** Cut this row, leaving two in Recent. For a stronger cut, drop Recent entirely and put "Read the
  feature" on the nanohybrids entry. B §3.4 shows News only with two or more items that aren't publications, and
  without this row there is one.

**C22 · P2 · Recent's row labels repeat their links, and the dates mix precision**
- **Where:** `src/components/site/about.tsx:97–98`
- **Now:** "4 Sep 2026, paper", "Feb 2026, role", "11 Sep 2023, feature"
- **Why:**
  - The suffixes repeat what the title and link already say ("Read the paper", "Read the feature"), and "role"
    doesn't read as a category.
  - Two rows give a day and one gives only a month.
  - MASTER.md and `format.ts` disagree about dates in lists (C33).
- **Proposed:** "Sep 2026", "Sep 2023" (and "Feb 2026" if that row stays), month and year like the timeline, with
  no suffix.

**C23 · P2 · "New work" goes stale, and the line repeats the summary**
- **Where:** `src/content/about.ts:36`
- **Now:** "New work in npj Imaging examines how skin tone and imaging choices interact."
- **Why:** The date beside it already says it's recent. "We" and "our" are the voice for co-authored papers.
- **Proposed** (77): "Our paper in npj Imaging examines how skin tone and imaging choices interact." Recheck it once the new
  summary lands, so the two don't say the same thing.

**C24 · P2 · The IISc update: public-relations phrasing (with S7)**
- **Where:** `src/content/about.ts:53`
- **Now:** "IISc tells the story behind our hybrid nanoparticles and their potential for light-based applications."
- **Why:** "tells the story behind" and "potential for light-based applications" are vague. S7 gives the specific,
  accurate content: the feature describes particles that turn light into heat and sound. The initialism also
  appears here before any full name nearby.
- **Proposed** (115): "The Indian Institute of Science featured our ultrasmall hybrid nanoparticles, which turn light into
  heat and sound." The title "Hybrid nanoparticles in the spotlight" is the owner's, from her old site; keep it.

**C25 · P2 · A link labeled with the line above it**
- **Where:** `src/content/person.ts:60` (`positions[1].link.label`)
- **Now:** "PULSE Lab", directly under "PULSE Lab, Johns Hopkins University", linking to the lab's People page
- **Why:** The label should say where the link goes, not repeat the organization line.
- **Proposed** (21): "PULSE Lab people page"

**C26 · P2 · Owner's call · The M.Tech. line restates the degree**
- **Where:** `src/content/person.ts:79`
- **Now:** "A five-year foundation in biomedical engineering, bringing together engineering methods and biological questions."
- **Why:** The second half describes biomedical engineering itself. What a US committee may not know is what
  "Integrated M.Tech." means.
- **Proposed** (63; owner to confirm): "A five-year program combining undergraduate and graduate study."

**C27 · P2 · Owner's call · Small style points in the bio and timeline**
- **Where:** `src/content/person.ts:26` (bio sentence 1), `src/lib/jsonld.ts:55`, `src/content/person.ts:26, 46, 49`,
  `src/content/about.ts:45`
- **Now and proposed:**
  - **Pair order.** The site everywhere says "photoacoustic and ultrasound". Bio sentence 1 and the JSON-LD
    description say "ultrasound, and photoacoustic imaging". Proposed (bio stays at 91 words): "I am a
    translational scientist working across biomaterials, drug delivery, and photoacoustic and ultrasound
    imaging." Mirror the order in `jsonld.ts:55`.
  - **"neuro-diagnostic" to "neurodiagnostic",** three places. American usage closes combining forms (neuroscience,
    neurodiagnostic). Keep the hyphen only if SynapSeek styles it that way.
  - **"SynapSeek, Remote" to "SynapSeek, remote".** Sentence case; `person.now.place` is already lowercase.

### Contact

**C28 · P2 · A stray comma in the deck**
- **Where:** `src/content/site.ts:22` (`DECKS.contact`)
- **Now:** "Email is the best way to reach me, about a collaboration or any of the papers above."
- **Why:** "reach me about …" is one phrase, so the comma makes the second half read as an afterthought.
- **Proposed** (83 / 140): "Email is the best way to reach me about a collaboration or any of the papers above."

### Interface text

**C29 · P1 · The copy-failure message: a straight apostrophe, and a false claim for "Copy link"**
- **Where:** `src/components/site/copy-button.tsx:60`; triggered from `cite-panel.tsx:39` ("Copy link", no `selectId`)
- **Now:** "Couldn't copy. The text is selected: copy it with your keyboard or menu."
- **Why:**
  - The straight apostrophe breaks the curly-quote rule. It is the only one on the page, and the linter can't see
    it (C30).
  - For "Copy link", nothing is selected, and the link appears nowhere on the page. Verified with a forced failure:
    the message showed with nothing selected.
  - The message otherwise has the right shape: what happened, then what to do, with no apology.
- **Proposed:**
  - With an element to select: "Couldn’t copy. The text is selected: copy it with your keyboard or menu." (72; the
    same text with a curly ’)
  - Without one: "Couldn’t copy. Select the link and copy it: {link}", with the address rendered as selectable text in
    the message.

**C30 · P2 · Interface strings live where the copy check can't see them**
- **Where:** `src/components/site/*.tsx` and `src/components/hero/lab-console.tsx`: the filter status, group counts,
  disclosure, "Cite", the copy labels and failure message, "What I did", "Featured papers", "Short bio, for talks
  and programs", "Positions and education", "Recent", "Profiles", the footer, "Zoom out", the tour labels, and
  "Skip the lab"
- **Now:** The README says the build lints every string, but `scripts/copy-deck.mts` reads only `src/content/*`.
  That gap is how "Couldn't" shipped.
- **Proposed:** Move interface strings to `src/content/ui.ts` and add them to the deck, so the budgets, glossary, and
  typography checks cover them.

### Footer and 404

**C31 · P2 · The 404 explains lab images on a page with no lab**
- **Where:** `src/components/site/footer.tsx:16`, as rendered by `src/app/not-found.tsx`
- **Now:** "The lab images are simulations for explanation, not measurements." under "Page not found"
- **Why:** A label with nothing to refer to. The 404's own copy is right: what happened, three ways out, no apology.
- **Proposed:** Give `Footer` a prop that leaves out the note, and use it on the 404.

### Metadata

**C32 · P2 · Owner's call · The title doesn't tell her from her namesakes**
- **Where:** `src/app/layout.tsx:36`
- **Now:** "Madhavi Tripathi, translational scientist" (41 / 60)
- **Why:** B §0, item 3 records at least two other researchers who publish as Madhavi Tripathi, one in nuclear
  medicine (PET/CT). "Translational scientist" fits her too. The search title is the strongest disambiguator on
  the page.
- **Proposed** (58 / 60; B §5.6): "Madhavi Tripathi · Nanoparticles and photoacoustic imaging". The header's role line
  stays "Translational scientist". Owner's call, because it sets her descriptor aside in search results.

### Documentation

**C33 · P2 · Two lines in MASTER.md contradict the site**
- **Where:** `design-system/MASTER.md:27` and `:170`; `src/lib/format.ts:5`
- **Now:**
  - The Voice example reads "gCNR 0.52: reads as solid." That value is a B-mode one, and B-mode gets no verdict.
    Verdicts also use the lesion names (MASTER's own glossary; README accuracy notes).
  - The date rule reads '"2026" in lists'. `format.ts` says '"Sep 2026" in lists', and the timeline needs months.
- **Proposed:**
  - Example: "gCNR 0.93: reads as a cyst."
  - Date rule: "Dates: ‘September 2026’ in prose; ‘Sep 2026’ in the timeline and Recent; ‘2026’ in the publication
    list; ISO in data."

## Checked and passed

These need no second look:

- **Budgets.**
  - Headline 27/28 and 28/28; lede 154/160.
  - Captions up to 179/180 with the deck's sample values, 173 with the real coherence value.
  - Tab hints up to 19/20; options up to 13/14; readouts up to 18/18 ("Heat, drug release"); 3D labels up to 24/24.
  - Decks 115, 104, and 84 of 140; theme bodies 64 and 57 words of 90; skills up to 46/48; bridge 81/140.
  - Summaries up to 150/240; short bio 46/60 words; bio 90/160 words.
  - Meta title 41/60 and description 143/155. The CRediT line is quoted whole, which MASTER.md now allows.
- **Typography and voice.**
  - No exclamation marks, emoji, "→" or "↗", or all-caps labels.
  - One em dash in the lede, and one inside the quoted CRediT role.
  - American spelling, serial commas, and sentence case throughout. Curly quotes everywhere in the content files.
- **Actions and their confirmations.**
  - "Take the tour" and "Stop the tour"; "Zoom out"; "Pause animation" and "Play animation".
  - "Copy email", "Copy short bio", "Copy citation", "Copy BibTeX", and "Copy link" all confirm with "Copied".
  - "Cite", "Skip the lab", and "Back to top".
- **Link promises.**
  - "Read the paper" and "Read the feature" leave the site; "See the papers behind this" stays.
  - "PDF" appears only where a free PDF exists, with its host named.
- **Status is text:** "First author", "Open access", "Free to read", "Free PDF".
- **Labels:** "Simulated" is on every lab picture, and the footer note says the same.
- **Navigation:** labels and order are identical in the header, the phone row, and the section bar.
- **Settled wording left alone:** the README accuracy notes, the deck's three accepted exceptions, the lede (the
  owner's line from her old site), and the research questions (hers).

## Notes for the vetting round

**The standard for every summary.** For vetting the science reviewer's drafts:

- **Form.**
  - One pattern for all 15: what we did or asked, then what we found, in one or two sentences, within 240
    characters.
  - Reviews and chapters: "We reviewed…" plus what they cover.
  - The thesis: "I…", since it has one author.
- **Person and tense.**
  - "We" for co-authored work. Her own part goes in "My role", never in the summary.
  - Past tense for findings; present only for standing facts.
- **Materials.**
  - No material, drug, or wavelength names outside titles.
  - Also no "nanoflakes" or "nanohybrids" (titles only, B §5.2), no "theranostic" or "phototheranostic", and no
    "PTT".
  - "Photothermal therapy" only after plain words, or not at all.
- **Numbers.** None. "0.76" stays in the note; "3D" and "COVID-19" are names.
- **Glossary.**
  - Particles: membrane coat; heat-responsive gel or gel carrier; light-absorbing particles or cores; capping
    layer.
  - Imaging: coherence beamforming, with short-lag spatial coherence (SLSC) spelled out once; gCNR as "an
    objective contrast measure (gCNR)"; clutter; cyst and solid mass.
  - Skin: "skin tone" ("pigmentation" only for the swine study); pulsed and continuous light (the "laser"
    exception stands for `arroyo-2026-jbo`).
- **Banned.** "novel", "first" as a claim, "breakthrough", and the rest of the list. B's own old mucin draft said
  "not used this way before", which is a novelty claim.
- **Card test.** The four featured summaries (mucin, nanohybrids, Sharma, npj) must read on their own in a narrow
  card, without echoing their titles.
- **Knock-on edits.** Once the summaries land, recheck the Recent lines (C23, C24) against them.

**First-pass flags on the drafts in `science-review.md`.** These are notes for the round, not rewrites:

- **npj.** It sits at 240/240. The colon-then-semicolon chain is dense, and "interacted" alone is vague; the real
  finding is the clause after the colon.
- **Sharma.**
  - In "It told complicated cysts…", "It" has no clear antecedent.
  - "Complicated cysts" breaks B §5.2's citations-only rule. The science note shows why accuracy needs it, and
    MASTER.md lets accuracy win, so accept it and record the exception in the deck.
- **Nanohybrids.** "We grew metal seeds on ultrasmall light-absorbing particles": seeds aren't grown on things. In
  a seed-mediated synthesis the light-absorbing particles are usually the seeds. Ask the science reviewer before
  rewording.
- **Malaria.** "with DNA barcodes, panels of genetic markers, and argued…" reads as a list of three. The appositive
  needs parentheses, or the sentence needs splitting.
- **Drabek.** "using simulations with the skin taken out as its goal": "as its goal" is hard to parse.
- **Hydrogels.** "temperature-responsive" instead of the glossary's "heat-responsive" is justified in the science
  notes. Accept it, and record it as an exception.
- **Epoxy.** Confirm that "aerospace-grade resin" is the paper's framing, not decoration.
- **S2, S3, S4, and S6** are within budget and in voice: bridge 100/140, captions 169 and 104 of 180, readout
  "Fading" 6/18.

**Calls I considered and kept, so the next round stays consistent:**

- **Lab.**
  - "Zoom out" pairs with "Pick a skill to look closer".
  - "After: Minutes / Hours / A day".
  - "Light’s effect: None yet" nudges the visitor to try Light.
  - "See the papers behind this".
  - "Cyst or solid?" is settled.
- **Research.**
  - The deck's "what’s inside".
  - The imaging question "How can light and sound reveal more?" is the owner's, from her old site's
    photoacoustic blurb.
  - The delivery body's present tense describes a skill; the imaging body's past tense describes a finished
    postdoc.
- **Publications.**
  - The filter's "Delivery" and "Imaging".
  - "Free PDF" beside "PDF (PULSE Lab)".
- **About.** "Short bio, for talks and programs", and "Tripathi" rather than a pronoun in the short bio (pronouns
  are the owner's call, B §6, item 22).
- **404.** The echo line, which the plan approved.
- **Co-first authorship.** The science and content reviews note that the nanohybrids paper had co-first authors.
  If the owner wants that shown, "Co-first author" fits the same slot and stays accurate. That is her call, and
  the filter count doesn't change.

## Vetting round

This round vets the science review as saved at 23:47 (`docs/reviews/science-review.md`): findings S1–S8 and the 15
summaries in its "Agreed text (science)" table. That table already folds in the science reviewer's answers to my
first-pass flags, so I vetted the revised texts, not the first drafts.

Verdicts:
- **Agree.**
- **Agree with change,** with the exact text, used only where the meaning stays the same.
- **Question,** where a change could shift meaning. It goes to the science reviewer rather than being made.
- **Disagree,** with the reason.

Every final text below was counted and run through the copy deck's rules. The only hit is the accepted "laser" in
`arroyo-2026-jbo`.

**Where things stand.**
- The lead is fixing C7, C12, and C29 in code.
- C2 is closed. The owner chose an image-led carousel under the lab, and MASTER.md now records the exception; advice
  for it is below.
- C8, C13, C16, C17, C29, and C30 are already in `src/content/ui.ts` as agreed.
- The science review accepted all my content proposals. It changed C3 and C11, and added an alternative for C20.
- I accept its correction of my note on the lede. Only "connecting how we deliver with how we see" is the owner's
  old wording, and "carry drugs into tumors" still needs her confirmation.

### Disagreements, in short

- **On facts:** none.
- **Three questions** on the science reviewer's revised summaries, each about scope or claim strength:
  - npj: does "Under darker skin" govern the delay-and-sum clause too?
  - Drabek: "strip" against the owner's "reduce", and whether the patient test showed easier detection or only
    feasibility.
  - Nanohybrids: is the cell harm under light?
- **One more question,** from S1's own problem statement: should the imaging body say "pig skin"?
- **Four changes that keep the meaning:** "target visibility" (enslein-spie), "gel carriers that hold" (thesis),
  "with more, the sheets clumped" (epoxy), and a lowercase role line (C11).
- **On S8,** my earlier objection is resolved: the science review adopted C14's wording.

### S1–S8

| Item | Verdict | Exact text or question | Length |
| --- | --- | --- | --- |
| S1, imaging body (with C5) | Agree; one question | The text is in the table below. S1's problem statement says the old clause "reads as human skin", but the fix still says "skin of different tones". Should the clause end "…it takes to injure pig skin of different tones" (60 words)? | 59 words / 90 |
| S2, bridge | Agree | No change | 100 / 140 |
| S3, Photoacoustics caption | Agree | No change | 169 / 180 |
| S4, Ultrasound caption | Agree | Keep the word joiner in "B-mode" | 93 / 180 (104 with the value) |
| S5, Drabek stopgap | Agree it is superseded | Use the Drabek summary | n/a |
| S6, Retention readout | Agree, on the science reviewer's condition | "Fading" | 6 / 18 |
| S7, IISc update (with C24) | Agree | No change | 115 |
| S8, Publications deck (with C14) | Agree | The science review adopted C14's wording | 104 / 140 |

### The 15 summaries

| Paper | Verdict | Change or question | Length |
| --- | --- | --- | --- |
| `enslein-2026-npj-imaging` | Agree; one question | "Under darker skin" opens a sentence whose second clause, joined by "while", is about targets near the skin, so it reads as if delay-and-sum won there under darker skin. The evidence notes give the delay-and-sum result for shallow targets overall. If it held across skin tones, a semicolon keeps the two conditions apart: "…made deep targets easier to detect; for targets near the skin, delay-and-sum did better." (212) | 217 / 240 |
| `arroyo-2026-jbo` | Agree | No change. "Laser" is the accepted exception, and "pigmentation" is allowed for this paper. | 217 / 240 |
| `enslein-2026-spie` | Agree with change | "how well targets showed" becomes "target visibility": "We compared target visibility under different skin tones in simulated, phantom, and patient photoacoustic breast images." "Showed" reads as a verb missing its object. "Target visibility" is the lab's readout name and the owner's own wording. The second sentence is unchanged. | 223 / 240 |
| `drabek-2026-spie` | Agree; two questions | (1) Should "to strip skin clutter from" become "to reduce skin clutter in"? "Strip" claims more than the owner's original and S5's own "reduce", and the style guide warns against clutter that simply "drops away". (2) The evidence notes say coherence gCNR barely moved in the patient (0.95 to 0.96). If only the channel-data measure rose there, should sentence 2 read "Targets became easier to detect in simulations, and an early patient test showed it can work." (228)? | 210 / 240 |
| `sharma-2025-gcnr-slsc` | Agree | "The measure" fixes the antecedent. "Applied … to" follows the title, and the card no longer repeats the imaging body beside it. At 239 there is no room for later edits. | 239 / 240 |
| `tripathi-2025-mucin` | Agree | No change, pending the science reviewer's own check of the in vivo clause against the article | 240 / 240 |
| `tripathi-2024-nanoflakes` | Agree | No change | 236 / 240 |
| `tripathi-phd-thesis` | Agree with change | "gel particles that carry" becomes "gel carriers that hold". The glossary calls the whole gel particle a "gel carrier", and the lab shows it "holding its cores". | 175 / 240 |
| `tripathi-2023-nanohybrids` | Agree with sentence 1; one question | In "Under light they heated and gave a photoacoustic signal through tissue, and they harmed lung cancer cells…", it's unclear whether the harm happened under light. If not, use your earlier sentence 2: "They heated under light, gave a photoacoustic signal through tissue, and were more toxic to lung cancer cells than either part alone." (summary 237). If so: "Under light they heated, gave a photoacoustic signal through tissue, and harmed lung cancer cells more than either part alone." (summary 230). | 238 / 240 |
| `tripathi-2023-hydrogels` | Agree | No change. "Temperature-responsive" stays, as the science notes explain. | 125 / 240 |
| `wazalwar-2022-mxene-epoxy` | Agree with change | "more clumped, and the gains fell" becomes "with more, the sheets clumped and the gains fell"; "more clumped" reads as "it became more clumped". "Aerospace-grade" is confirmed as the paper's own term. | 223 / 240 |
| `jain-2021-biopolymer` | Agree | No change | 190 / 240 |
| `jain-2021-hydroxychloroquine` | Agree | No change. I considered "repurposed for COVID-19" and dropped it, because it implies the repurposing worked. | 203 / 240 |
| `tripathi-2015-malaria` | Agree | No change. The split and the parentheses fix the list misreading. | 234 / 240 |
| `tripathi-2015-stem-cells` | Agree | No change | 210 / 240 |

**Across the set.**
- Every summary now opens with "we" (the thesis with "I") and a past-tense verb.
- Each says what was done, then what was found. The reviews and the commentary report what they cover and invent no
  findings.
- No materials, and no numbers except the names "3D" and "COVID-19". Once these ship, the deck's warnings fall to the
  accepted "laser".
- The four featured summaries read on their own in a card.

**Recording the exceptions.** The science review asks for four entries in the deck's accepted list: "complicated
cysts", "temperature-responsive", "3D", and "COVID-19". That list only silences warnings that fire, and none of these
four does. "3D" and "COVID-19" are already excluded from the number check, and no rule matches the other two. Record
them as glossary notes in MASTER.md instead. When the new hydrogels summary lands, delete the deck's old "hydrogels"
exception, which will then match nothing.

### Reconciliation with the science review

- **C5 and S1:** one text, with S1's clause and C5's split. The pig-skin question is still open.
- **C14 and S8:** one text, C14's wording, which the science review adopted.
- **C24 and S7:** one text, S7's facts in C24's sentence.
- **C3:** I take the science wording, "designed to treat and image cancer" (102). It keeps the claim to what was
  shown.
- **C11:** I take the science wording, which leaves out analysis as the paper does. I set it in sentence case after
  the colon: "My role: patient data acquisition, image reconstruction, and manuscript review" (78 / 90). The CRediT
  line keeps its taxonomy capitals. Store the line as one string, since `role.credit` joins items with commas and
  would drop the "and".
- **C20:** I agree with the owner's-call alternative ("…and light-activated therapy…", 124), for use if
  "image-guided" isn't hers to claim.
- **C23:** I keep "Our paper in npj Imaging examines how skin tone and imaging choices interact." (77), which the
  science review endorses. The new summary states the finding, so this line no longer repeats it.
- **C1:** the science review agrees with both link labels.
- **C9:** the wording stands. The fact behind it, a membrane coat in the thesis, is still the owner's to confirm.

### New interface strings in `ui.ts`

These match the agreed texts:
- "Skills".
- "Showing all 15 publications." and "Showing 6 of 15 publications.".
- "Show the 4 papers" and "Hide the 4 papers".
- The checked line, with "Google Scholar" linked.
- "Paper".
- The copy messages, now with curly apostrophes.

The new "All citations as BibTeX" and the static hero's "Simulated. The interactive lab couldn’t start in this
browser." both say what they are and what happened. One change:

- **`UI.copy.failedLoad`:** "Couldn’t load it. Every citation is in one file:" becomes "Couldn’t load the BibTeX.
  Every citation is in one file:" (56). The status is announced on its own, and there "it" has nothing to refer to.

### The image-led Recognition carousel

These add to the exception MASTER.md now records (position, controls, credits):

- **Stills only where they show the recognized work.**
  - The thesis award can carry the Design still. Put "Simulated" on the image, as the lab's panels do, with a
    caption that says how it relates.
  - If the owner confirms the membrane coat (science review, Could not verify, item 1): "The particle this thesis
    built, taken apart" (43).
  - Until then: "A particle built in layers, as in this thesis" (45).
  - The two service slides get the owner's photo or no image. A lab still there would suggest the service was that
    science.
- **Credits:** the same place and form on every slide: "Photo: {credit as the source asks}", e.g. "Photo: Indian
  Institute of Science" (34). Keep credits to 40 characters, one line.
- **Alt text:** what the photo shows (who, where, the occasion), without praise, and without repeating the slide's
  title. For stills, reuse the alt text in `renders.ts`.
- **Text stays live text:** year, kind ("Award", "Service"), title (the slide's heading), context, and caption.
  Nothing is baked into an image.
- **Lengths:** titles at most 56 characters (the longest now), context at most 102 (C3's line), captions one line
  (about 50 characters at card width).
- **The peek:** let the next card show its image, not its words, so no line is cut mid-word at rest.
- **Position and controls:** the visible "1 / 3" is fine beside the spoken "2 of 3: …", because each reader meets
  only one of them. Keep "Previous" and "Next". If the rail ever stops wrapping, remove the end button rather than
  disabling it, as MASTER.md requires.

### Agreed text (copy)

The exact wording I endorse, all within budget:
- **"= science"** means it matches the science review's table word for word.
- **"Question"** means the science text stands until the question above is answered.

| Item | Where | Agreed text | Length | Status |
| --- | --- | --- | --- | --- |
| C1 | `chapters.ts:504`, `:506` | Read the skin-tone paper in npj Imaging / Read the paper in Radiology Advances | 39; 36 | Agreed, = science |
| C3 | `about.ts:11` | Indian Institute of Science, for doctoral research on nanoparticles designed to treat and image cancer | 102 | Owner's call, = science |
| C4 | `about.ts:18` | Cut the line | n/a | Owner's call |
| C5 + S1 | `themes.ts:37` | In Muyinatu Bell’s PULSE Lab at Johns Hopkins, I worked on making photoacoustic and ultrasound images of the breast clearer. We measured contrast objectively (gCNR) on coherence-beamformed ultrasound to tell cysts from solid masses. We also studied how skin tone changes what photoacoustic imaging can detect, and how much pulsed light it takes to injure skin of different tones. | 59 words / 90 | = science; question open ("pig skin") |
| C6 | `themes.ts:35` | Postdoctoral research, Johns Hopkins University | 47 | Agreed, = science |
| C7 | `layout.tsx:62`; `publications.tsx:152` | Chips: the visible "In the lab: Design" is the name. Entry links: In the lab: Design / In the lab: Delivery / In the lab: Photoacoustics / In the lab: Ultrasound | up to 26 | Lead fixing |
| C8 | `ui.ts`, `research.skills` | Skills | 6 | Done |
| C9 | `themes.ts:26` | Red blood cell membrane coats | 29 / 48 | Owner's call, = science |
| C11 | Featured npj card; npj `role` | My role: patient data acquisition, image reconstruction, and manuscript review | 78 / 90 | Owner confirms; = science apart from the capital |
| C13 | `ui.ts`, `publications` | Showing all 15 publications. / Showing 6 of 15 publications. / Show the 4 papers / Hide the 4 papers. The group counts are deleted. | 28; 29; 17; 17 | Done |
| C14 + S8 | `site.ts:21` | Papers, book chapters, and my thesis, grouped by the two halves of my work, then other and earlier work. | 104 / 140 | Agreed, = science |
| C15 | `publications.tsx:129–131` | Journal articles: the venue line alone. Thesis: PhD thesis, Indian Institute of Science, Bengaluru | 50 | Agreed, = science |
| C16 | `ui.ts`, `publications.paper` | Paper | 5 | Done |
| C17 | `ui.ts`, `publications.checked` | Checked against Google Scholar and Crossref in September 2026. ("Google Scholar" linked) | 62 | Done |
| C18 | `publications.ts:154` | The interactive lab uses this study’s 0.76 threshold. | 53 | Agreed, = science |
| C20 | `person.ts:71` | Doctoral research on nanoparticles for photoacoustic imaging and image-guided therapy, advised by Prof. Ashok M. Raichur. If "image-guided" isn't confirmed: Doctoral research on nanoparticles for photoacoustic imaging and light-activated therapy, advised by Prof. Ashok M. Raichur. | 121; 124 | Owner's call, = science |
| C21 | `about.ts:40–47` | Cut the SynapSeek row | n/a | Agreed |
| C22 | Recent dates (`about.tsx:97–98`) | Sep 2026 / Sep 2023, with no kind suffix | 8 | Agreed |
| C23 | `about.ts:36` | Our paper in npj Imaging examines how skin tone and imaging choices interact. | 77 | Agreed, = science |
| C24 + S7 | `about.ts:53` | The Indian Institute of Science featured our ultrasmall hybrid nanoparticles, which turn light into heat and sound. | 115 | Agreed, = science |
| C25 | `person.ts:60` | PULSE Lab people page | 21 | Agreed |
| C26 | `person.ts:79` | A five-year program combining undergraduate and graduate study. | 63 | Owner confirms, = science |
| C27 | `person.ts:26`; `jsonld.ts:55` | I am a translational scientist working across biomaterials, drug delivery, and photoacoustic and ultrasound imaging. / JSON-LD: Translational scientist working across biomaterials, drug delivery, and photoacoustic and ultrasound imaging. Also "neurodiagnostic" and "SynapSeek, remote". | 116; 109 | Owner's call; bio = science |
| C28 | `site.ts:22` | Email is the best way to reach me about a collaboration or any of the papers above. | 83 / 140 | Agreed |
| C29 | `ui.ts`, `copy` | Couldn’t copy. The text is selected: copy it with your keyboard or menu. / Couldn’t copy. Select it here and copy it with your keyboard or menu: {text} / Couldn’t load the BibTeX. Every citation is in one file: | 72; 69 plus the text; 56 | Done, except the last line |
| C32 | `layout.tsx:36` | Madhavi Tripathi · Nanoparticles and photoacoustic imaging | 58 / 60 | Owner's call, = science |
| C33 | `MASTER.md:27`, `:170` | gCNR 0.93: reads as a cyst. / Dates: "September 2026" in prose; "Sep 2026" in the timeline and Recent; "2026" in the publication list; ISO in data. | 27 | Agreed; the example = science |
| S2 | `themes.ts:13` | Both halves share one piece of physics: absorbed light turns into heat, and pulsed light into sound. | 100 / 140 | Agreed, = science |
| S3 | `chapters.ts:209` | Oxygen shifts which colors blood absorbs, so imaging with a few colors maps blood oxygen. Lighter skin adds little clutter, but coherence still brings out faint vessels. | 169 / 180 | Agreed, = science |
| S4 | `chapters.ts:248` | Many solid masses also look dark in B-mode, which is why cysts and solid masses get confused. | 93 / 180 (104 with the value) | Agreed, = science |
| S5 | `publications.ts`, `drabek-2026-spie` | Superseded by the Drabek summary | n/a | Agreed |
| S6 | `chapters.ts:310` | Fading | 6 / 18 | Optional; the science reviewer checks the figure first |
| Summary | `enslein-2026-npj-imaging` | We imaged breast masses with photoacoustics in patients of many skin tones. Under darker skin, coherence beamforming (SLSC) made deep targets easier to detect, while delay-and-sum did better for targets near the skin. | 217 / 240 | = science; question open (scope) |
| Summary | `arroyo-2026-jbo` | We measured the pulsed-laser dose that visibly injures pig skin of different pigmentation. Darker skin was injured at a lower dose than lighter skin, which matters for photoacoustic systems run close to safety limits. | 217 / 240 | Agreed, = science |
| Summary | `enslein-2026-spie` | We compared target visibility under different skin tones in simulated, phantom, and patient photoacoustic breast images. Under darker skin, coherence beamforming (SLSC) gave deep targets a clearer signal than delay-and-sum. | 223 / 240 | Agreed with change ("target visibility") |
| Summary | `drabek-2026-spie` | We trained a generative neural network, on paired simulations with and without skin, to strip skin clutter from raw photoacoustic data. In simulations and an early patient test, targets became easier to detect. | 210 / 240 | = science; two questions open |
| Summary | `sharma-2025-gcnr-slsc` | We applied an objective contrast measure (gCNR) to coherence-beamformed (SLSC) breast ultrasound. The measure told complicated cysts from solid masses more accurately, and with more radiologist agreement, than reading B-mode images by eye. | 239 / 240 | Agreed, = science |
| Summary | `tripathi-2025-mucin` | We capped ultrasmall light-absorbing particles with a natural biomolecule and tagged them for mitochondria. With light they killed cancer cells and gave photoacoustic contrast; they penetrated 3D tumor models and stayed in tumors for hours. | 240 / 240 | = science; in vivo clause to check |
| Summary | `tripathi-2024-nanoflakes` | We tested how the length of the capping polymer changes ultrasmall light-absorbing particles. All stayed ultrasmall, crystalline, and gentle on cells, and heated under light; the shortest polymer gave the strongest photoacoustic signal. | 236 / 240 | Agreed, = science |
| Summary | `tripathi-phd-thesis` | I built heat-responsive gel carriers that hold light-absorbing cores and mimic red blood cells, to combine drug delivery, heating tumors with light, and photoacoustic imaging. | 175 / 240 | Agreed with change ("gel carriers that hold") |
| Summary | `tripathi-2023-nanohybrids` | We grew metal from seeds bound to ultrasmall light-absorbing particles, keeping the hybrids ultrasmall. Under light they heated and gave a photoacoustic signal through tissue, and they harmed lung cancer cells more than either part alone. | 238 / 240 | = science; question open (light) |
| Summary | `tripathi-2023-hydrogels` | We reviewed temperature-responsive gels that hold nanoparticles, and how they can be tuned to treat and image tumors locally. | 125 / 240 | Agreed, = science |
| Summary | `wazalwar-2022-mxene-epoxy` | We added surface-treated two-dimensional nanosheets to an aerospace-grade resin. A small amount helped it cure and made it stronger and tougher; with more, the sheets clumped and the gains fell. Untreated sheets did little. | 223 / 240 | Agreed with change ("with more, the sheets clumped") |
| Summary | `jain-2021-biopolymer` | We reviewed how natural and synthetic biopolymer composites can carry cancer drugs: their properties, targeting, stimulus-triggered release, preparation, and uses in treatment and diagnosis. | 190 / 240 | Agreed, = science |
| Summary | `jain-2021-hydroxychloroquine` | We reviewed the toxicity of a repurposed antimalarial drug proposed for COVID-19, along with new delivery approaches, computer modeling, and drug combinations that might make it safer and more effective. | 203 / 240 | Agreed, = science |
| Summary | `tripathi-2015-malaria` | We discussed genotyping malaria parasites with DNA barcodes (panels of genetic markers). We argued that current panels leave out parasites from India and other regions, so they can’t yet reliably tell parasite strains apart worldwide. | 234 / 240 | Agreed, = science |
| Summary | `tripathi-2015-stem-cells` | We reviewed stem cell technologies, from embryonic and induced pluripotent stem cells to cord blood banking, weighing their promise for human health against ethical questions and the need for closer evaluation. | 210 / 240 | Agreed, = science |

## Three-card Research

Vetted on 28 September against `src/content/themes.ts` (`directions`), `src/components/site/research.tsx`, and
`ui.ts`. I viewed the section at 1440, 1024, and 390 px. The three cards read far more easily than the two-block
layout: one pass per card, the same order in each, and nothing competing beside them. Every body is within its
45-word limit (37, 43, and 25 words), and every skill is within 48 characters. The fixes below are mostly cuts.

| Item | Verdict | Exact text, or the reason |
| --- | --- | --- |
| Titles | Agree | "Nanomaterials for delivery", "Photoacoustic imaging", "Ultrasound imaging". The first mirrors the headline and the publications group that "See the papers" opens. The other two use the field names, as prose does; their lab links keep the tab names ("Photoacoustics", "Ultrasound"). |
| Where lines | Agree | "PhD research, Indian Institute of Science" and "Postdoctoral research, Johns Hopkins University" match. The photoacoustic line, "Indian Institute of Science and Johns Hopkins University", is the only one without a stage word. Optional, for parallel scanning: "PhD and postdoctoral research" (29). The places are already named on the cards either side, and its body says "At Johns Hopkins". |
| Questions | Agree | All three are the owner's. Two are now back on the blurbs they came from on her old site: photoacoustic ("How can light and sound reveal more?") and ultrasound ("What can the echoes tell us more clearly?"). |
| Delivery body | Agree with change | "…and a red blood cell membrane coat helps the particle circulate longer." (38 words) "Circulate" alone reads as if the coat makes circulation possible. "Longer" is the lab's own word (the readout "Circulate longer"; the taken-apart caption "keeps it circulating longer"). |
| Photoacoustic body | Agree with change | "…we studied how skin tone changes what photoacoustic imaging can detect, and how much pulsed light it takes to injure pig skin of different tones." (43 words; this restores the agreed S1 wording) "That imaging" is vague. It also follows "sound we can image", so the sentence has two "we"s meaning different people. The opening sentence carries the bridge physics well: "Pulsed light absorbed in tissue, or by my particles, turns into sound we can image." |
| Ultrasound body | Agree | "…which B-mode images can confuse" keeps S4's hedge. "Plain words first, then the term" covers "contrast objectively (gCNR)". Research no longer spells out gCNR or SLSC anywhere now that the featured cards are gone, but MASTER.md only asks for plain words first, and the full names appear in Publications and the lab. |
| Delivery skills | Agree with cuts; owner's call | Cut "Heat-responsive gels that release a drug" and "Red blood cell membrane coats": the body already names both layers, a line above. Keep "Ultrasmall light-absorbing nanoparticles", "Capping layers for stability and targeting", and "3D tumor models and preclinical testing"; each adds something the body doesn't say. |
| Photoacoustic skills | Agree | All four add to the body. "Nanoparticles as photoacoustic contrast agents" wraps to two lines on phones; it's within budget, so no change. |
| Ultrasound skills | Agree with one cut; owner's call | Cut "Breast cyst and solid-mass characterization": it restates the body's "to tell breast cysts from solid masses". Three remain. |
| "In the lab:" | Agree | This is the same prefix the publication entries use, and each chapter link is named "In the lab: {chapter}" (C7). |
| "See the papers" | Agree with change | Say which list opens: "See the delivery papers" (23) on the delivery card, "See the imaging papers" (22) on the other two. The ultrasound card's link opens the Imaging filter, where four of the five items are photoacoustic. As written it promises that card's papers, and two identical labels also lead to different lists. With the half named, the label matches the filter that lights up, and identical labels go to the same place. |
| The deck | Agree with change | "Two halves" over three cards makes the reader do the mapping. Proposed (132 / 140): "Two halves of one practice: building particles that carry treatment, and imaging what’s inside with light and sound, or sound alone." It keeps "two halves" (which the Publications deck still relies on), splits the second half the way the cards do, and reads onto the glyphs: ● light, ●○ light and sound, ○ sound. |

**Lighter still.** The cuts above take the three cards from 5, 4, and 4 skills to 3, 4, and 3, and remove the only
lines that repeat something on the same card. Nothing else is redundant: glyph, title, where, question, body, skills,
and links each answer a different question. Add "○ ultrasound (sound alone)" to MASTER.md's glyph line (●
delivery, ●○ imaging), since the cards now use a third glyph.

**For the science reviewer (might change meaning):**
- The delivery body still says the cores "turn light into heat and sound". S2 moved the bridge to "pulsed light into
  sound", and the photoacoustic card now says so. Is the unqualified phrase acceptable on the delivery card, as it was
  for the Design readout?
- "Sound-speed selection in image reconstruction" is the owner's skill, from her site. Like "Oxygenation mapping",
  no paper in the list shows it. Keep it as her claim?
- The proposed deck says "imaging what’s inside with light and sound, or sound alone". Any objection to that
  description of photoacoustics and ultrasound?

**Beyond wording.** Research now shows no findings and no first-author marks; those live only in Publications. That
is consistent with the owner's request for lighter cards. It means "what she found" and "what she led" are answered
one section down, so the "See … papers" links matter more.
