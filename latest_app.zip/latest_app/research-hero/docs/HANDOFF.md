# Handoff: the research site

State as of 28 September 2026. What was built, the decisions behind it, how to run and check it, what was verified
and how, and what is still open or waiting on the owner. The project is committed on the Chiku_website repository's
`construction/backend-units-1-5` branch (first as 3945e01, 28 September 2026); further commits and any push wait
for the owner's go-ahead.

## What was built

A one-page static site (Next.js 16 App Router, `output: "export"`, Tailwind v4, React 19), served from `out/` by any
static host; Cloudflare Workers static assets is configured (`wrangler.jsonc`, `public/_headers`, `public/_redirects`).

| Part | What it is |
| --- | --- |
| Lab hero | The interactive three.js lab (four chapters, tour, readouts, captions), with deep links `#lab-*`. If it fails, a static header with a lab still (labeled Simulated) takes its place and the page keeps working. |
| Recognition and service | Directly under the lab, at the owner's request. Wide screens: every item listed beside one picture panel (tabs; arrows, Previous/Next, "1 / 3"). Phones: a rail of cards, each with its own picture. Nothing moves on its own. Photos first; until they exist, the thesis award shows the lab's layered particle (Simulated) and service items show typographic plates. The chosen item's marker glides between rows; a new picture wipes in behind a crossing scan line from the side the step came from; the counter swaps. On phones each card's picture is acquired the same way when the rail is first seen. |
| Research | Three cards at the owner's request, in the lab's order: delivery (● light), photoacoustics (●○ light and sound), ultrasound (○ sound). Each: a small physics diagram, title, where, the owner's question, a ≤45-word body, skills, and ways on (into the lab, or to the filtered papers). Each diagram plays its physics once when first scrolled to, the three a beat apart: the particle is built (cores, gel, drug, coat), a light pulse flashes before its sound, echoes return later from deeper. Rested on (150 ms) or tapped, it replays without erasing: the particle heats, its gel tightens, and the drug moves out; a bright copy runs along each trace. |
| Publications | Redesigned at the owner's request (28 September 2026) as a compact index: each row shows the year and topic mark, the title (links to the paper), one line of facts (where it appeared; "First author" and free access where true), and on the right Google Scholar's "Cited by N" over "Summary", which opens the row in place (summary, authors, role, links, Cite). Show (with counts and the topic marks) sits above the list; Sort (Newest, Most cited) and the count sit in the list's header; both live in the address (`?show=`, `?sort=`). Wide screens bound the list to its panel, cut so the next title always peeks, with a fade where there's more; phones show five rows; "Show all N" lifts either limit. Stable `#pub-*` anchors open and land on their row. Without JavaScript the whole list is open. Motion (owner's request): the Show and Sort thumbs glide, with the labels they cover drawn dark in every frame; rows that move a short way glide over the rest, and rows that arrive or travel far are uncovered in place (rows are opaque, so two titles never show through each other); the list's height eases; Summary eases open and folds away faster; the count swaps; after "Most cited", each "Cited by" bar runs out to its count. |
| Google Scholar readout | Three tiles in an instrument panel (owner's request, 28 September 2026: citations, h-index, and i10-index "in appropriate tiles to highlight them"). Citations: the total, "98 since 2021", and citations per year as a stem plot in a black well (the running year hollow, "so far"). h-index and i10-index: the figure, what it counts in words, and the papers ranked by citations against the line that defines it, those that count drawn bright (drawn only when the ranking reproduces Scholar's figure). A lit dot beside "Checked Sep 28, 2026" goes out when the reading is over three days old. As each tile is first seen, its figure rises into place from blank (it never shows another number), the stems rise year by year from zero, and the line draws across, lighting the papers that reach it as it passes. Beside the list with the same edges from 1280 px (the list's panel matches its height where that still fits the screen; sticky while the whole list shows); after the list below that, the three tiles in one row where there's room. From `src/content/scholar.json`, a committed snapshot of the public profile page, refreshed every 4 hours by `.github/workflows/scholar.yml` (`docs/scholar-sync.md`). |
| About, Contact, footer | Bio, copyable short bio, dated positions and education, recent updates; email with Copy email; profiles. The rules between entries draw across when first seen; the email's underline sweeps in echo under the pointer; profile names lean in. |
| Motion below the lab | One system for the whole page (`design-system/MASTER.md`, "Motion"; the owner found the page "soulless, without micro animation"): section headings rise from behind their line when first scrolled to; one moment per block, once; gliding thumbs and markers (the section bar's underline too); copy buttons turn their icon into a check that draws itself and replace the label with "Copied" from below; pills press in; tiles and cards light up under a fine pointer. `src/components/site/reveals.tsx` marks blocks as they're reached; the rest is CSS and a few WAAPI animations. Reduced motion is a cut; without JavaScript or in print, nothing waits. |
| Machine-readable | `/publications.bib`, sitemap, robots, manifest, JSON-LD (`ProfilePage`, `Person`, one node per work), share image (1200×630, labeled Simulated), Apple icon, 404 with three exits. |
| Two themes | Owner's request (28 September 2026): a light theme with a toggle. Dark is the lab and the default; light is "the paper" — the record printed, its palette computed against WCAG 2.2 (`design-system/MASTER.md`, "Two themes"). The lab (`#top`, live or static), the Scholar chart's black well, the renders, and the scan line stay dark in both themes: instruments keep their screens, and the dark band casts a shadow on the paper below it. The toggle (hero header, and the section bar from sm up — under WCAG text spacing four links plus a toggle cannot hold one phone bar row — one document state, inline-SVG crescent↔sun on the site's spring) persists a choice in localStorage; until one is stored the system preference decides, resolved before first paint by the head's inline script, and followed live. The swap crosses in 350 ms on one clock; reduced motion cuts; without JavaScript there is no toggle and the page is dark. `theme-color` and `color-scheme` follow. Print wins over either theme. |

## Decisions worth knowing

- **Truth by construction.** Every statement about the owner is a `Fact` (value, source, confirmed); production renders
  only confirmed facts, and the build fails if a required one is unconfirmed. Papers are curated by DOI and checked
  against a committed Crossref snapshot on every build. Citation counts appear only as Google Scholar reports them
  (the owner's request), with the date they were read and a link to the profile; the chart never sums to a total.
- **Google Scholar, every 4 hours.** Scholar has no API; its robots.txt allows profile pages (`Allow:
  /citations?user=`) and forbids paging (`cstart=`), and the owner's 15 papers fit on the first page. So a workflow
  reads that one page every 4 hours with an honest User-Agent and no retries, commits the snapshot when a figure
  changed or at least daily, and the push redeploys the site. If Google refuses (likely at times from GitHub's
  servers), the last snapshot stays and the date says so; an optional SerpApi key is the fallback. Papers new on
  Scholar are listed in an issue, never added by themselves: other researchers publish under the same name.
- **Publications as an index.** Chosen after the owner found the full list "a knowledge dump". The references
  (DeepMind's publication index, Crosscheck's list and detail on Dribbble, 21st.dev's count tabs, the owner's old
  site) pointed to one line of short facts per paper, details on demand, counts on the filters, and a bounded
  list. Rows open in place rather than in a detail pane: 15 papers don't need a second layout, and phones need
  one anyway. The research also warned against scroll boxes on phones, so phones show five rows instead.
- **Words.** All 15 summaries were rewritten in "we" voice, saying what was done and found, with no material, drug,
  or wavelength names (the owner's rule), and each was checked against its paper by the science review, vetted for
  voice by the copy review, and cross-vetted (`docs/reviews/`).
- **Carousel exception.** MASTER.md bans carousels below the hero; the owner asked for one for recognition. The
  exception is recorded there with its rules (no autoplay, visible controls, position, keys and swipe, provenance
  on every picture). Research for it: 21st.dev (live components), Dribbble, and live award sections found through
  Awwwards; Pinterest was login-walled.
- **Research cards.** Chosen after the owner found the two-column Research "cognitively heavy". The reference research
  (Inceptive, Anthropic Research, Isomorphic Labs, BfNA, Arc) pointed to equal flat panels, short text, links pinned
  to the bottom, a subject-specific visual per card, and stacking on phones.
- **Motion, and the Scholar tiles.** The owner asked for highlighted tiles and for micro-animation; the old rule
  ("below the hero, motion only answers input") gave way to a stated system instead of effects: motion comes from the
  lab's physics (light first, then what it sets off; images acquired behind a scan line; figures that settle like
  readouts), one moment per block, nothing looping, every control answering with motion that shows what changed. The
  references (21st.dev's number tickers with a live dot and its sliding tabs, observed live; Dribbble's dark stat
  cards; the owner's old site, whose scroll reveals and hover borders were measured; Awwwards searches gave nothing
  specific; Pinterest is login-walled) set the vocabulary; the 10K checklist's "motion that whispers" set the bar.
  Nothing is hidden unless the page's script has run, so a failed or slow script never costs content. The index tiles
  draw the papers ranked by citations against the index's line, because "h-index 7" means little to most visitors
  and "7 papers each cited at least 7 times" can be seen.
- **The lab and the paper.** The light theme was this site's own anti-pattern until the owner asked for it
  (28 September 2026); the exception and its rules are in MASTER.md ("Two themes"). The palette derives from the
  print flip but keeps the layering print flattens (toned paper #f4f2ee under white plates, toned insets), and
  every value was computed against WCAG 2.2 before shipping: print's 45% border alpha sits at 2.7:1 on screen and
  became 50%, and every hue has a darker ink (echo #0c6a84 carries all focus rings at 5.5:1). About 20 hard-coded
  bone-alpha literals (underlines, tile edges, the section underline, the pointer light, the seg-thumb glow) were
  first converted to token-derived color-mix values in a sweep proven pixel-identical against the dark baselines,
  so the interaction layer flips with the theme. The hero stays dark by a scoped token pin (.lab-pin: the 3D
  scene, posters, and stills bake #060a0c in and cannot flip); the Scholar well and the thumb's ink glyphs re-pin
  locally. The crossfade crosses text and ground for ~80 ms at its midpoint, as every crossfade does; at 350 ms
  this was judged right, and reduced motion never sees it.
- **Budgets are enforced**, and meeting them shaped the code: BibTeX loads on demand; copy buttons mount when a Cite
  panel opens; repeated utility lists became `.pill`, `.label-link`; Tailwind scans `src/` only (it had been
  turning words in the plan documents into CSS); wave diagrams are drawn with one curve per hump. The JSON-LD is
  added to the exported page after the build (`scripts/inject-structured-data.mts`): rendered from React it
  shipped twice, once in the tag and once in the payload hydration reads, and moving it took 3.7 KB off the
  page, which paid for the new publication markup. The CSS budget moved from 12 to 13.5 KB for the publication
  index and the Scholar instrument (1.7 KB of styles with no cheaper form); against the build before, JavaScript
  is 1.2 KB lighter and HTML 0.5 KB lighter. It moved again, to 16.5 KB, for the tiles and the motion system (2.4 KB
  gzip of styles; the motion runs in CSS and a few Web Animations calls, so JavaScript grew only 2.2 KB). A second
  raise, after the reviews (CSS to 17 KB, HTML 40 to 41 KB), paid for the particle drawn in stages, the replay copies
  of the traces, the per-tile chart scales, and the gliding label copy. A third raise (CSS 17 to 18 KB; HTML 41 to 41.5 KB) paid for
  the light palette, the lab pin, the swap, the toggle's icon, and the service plates' drawn marks (+1.1 KB gzip
  CSS and +0.6 KB HTML in all; the marks ship once as symbols and are used by reference; the toggle added 0.8 KB
  JS, inside its budget).

## Run and check

```bash
npm install
npm run dev              # http://localhost:3217
npm run build            # content, Crossref, and copy checks → export → built-site check
npm run check:budgets
npm run serve            # out/ as the host serves it, http://localhost:3218
npx playwright test      # journeys, accessibility, visual (serves out/ on 3219)
npm run test:unit        # the Google Scholar parser and its safety checks
npm run scholar          # read the Scholar profile once and update src/content/scholar.json
```

Owner-facing editing is in the README ("Edit the content"): facts in `src/content/`, `npm run add-paper`,
`npm run photos` for recognition photos, `npm run copy-deck` for the words.

## Verified, and how

| Check | Result | Evidence |
| --- | --- | --- |
| Build gates | Pass: content consistent; 14 of 14 papers match Crossref; 403 strings with 0 copy errors and 0 warnings; the Google Scholar snapshot (profile, 15 of 15 papers matched); JSON-LD added to the page; built-site check (files, metadata, JSON-LD, anchors, glyph coverage) | `npm run build` output |
| Byte budgets (`/`) | JS 184 of 185 KB; CSS 17.6 of 18 KB; HTML 41.4 of 41.5 KB; preloaded fonts 224.5 of 230 KB; lazy three.js chunk 169.8 of 175 KB; three.js never in the initial load. The CSS budget went 12 → 13.5 KB for the publication index, 13.5 → 17 KB for the Scholar tiles and the motion system (HTML 40 → 41 KB), and 17 → 18 KB for the two themes (see "Budgets are enforced") | `npm run check:budgets` |
| Journeys and accessibility (Chromium) | 115 of 115 pass (163 of 163 with the visual suite, on the final build) (102 before the themes; +8 theme journeys: system default and first paint, flip/persist/meta and both copies agreeing, the swap attribute set and cleared and never under reduced motion, system-follow ending at a choice, no toggle without JavaScript, print winning over the light theme; +5 paper-theme a11y: axe on the overview, the busiest Publications state, and the 404 at 390 and 1440, and the full focus walk on paper): deep links (including malformed fragments and a text fragment into a closed summary), `?show=` and `?sort=` in every form, the count and announcements, rows opening in place, the list's length on wide screens, phones, and a touch tablet (findable rows past five, focus after Show all), the Scholar tiles and every row's count against the snapshot (terms, figures, words, the papers each index counts), a Research link filtering in place with focus and Back, history, skip link, section bar, Cite and every copy button, 404, `/publications.bib`, no-JS (every row open, no dead controls, no Tab stop, nothing waiting to appear), reduced motion (nothing waits, nothing below the lab moves), motion (a block waits below the screen, plays once, and comes to rest where it would have been; a link into a section lands with its heading in place; the thumbs and the section underline glide; a filter chosen mid-fold leaves the count right; the first Recognition row keeps its shape after load), zero console errors and CSP violations; axe (WCAG 2.2 A/AA) 0 violations; 320 px reflow; text spacing; focus visible at every Tab stop; forced colors | `tests/journeys.spec.ts`, `tests/a11y.spec.ts` |
| Science and copy | Every claim checked against the papers; both reviews cross-vetted each other's proposals | `docs/reviews/science-review.md`, `docs/reviews/copy-review.md` |
| Google Scholar pipeline | 60 of 60 unit tests (parser on a saved profile page, matching, block detection, the 10% drop guard, the 20-hour rule, SerpApi's documented response); one live read on 28 Sep 2026 matched the committed snapshot | `npm run test:unit`, `npm run check:scholar` |
| Publications reviews | Independent art-direction, UX and accessibility, and code reviews of the first build; every finding fixed or recorded (defect log below) | This handoff |
| Motion and tiles reviews | Independent motion and art-direction, accessibility, and engineering reviews of the first motion build (13, 10, and 12 findings, all reproduced with frame captures or scripts); every finding fixed (defect log below), except the double "Copied" (the button's name and the polite status both say it; kept, since the visible label must stay in the name), recorded under "Not verified" | This handoff |
| Motion evidence | Frame sequences of every moment at 1440 and 390 (reveals, thumbs mid-glide, re-sorting, folds, wipes, the copy check); layout shift across a full scroll 0.0045 on desktop and 0 on a phone | Captures made during the work; `restState` in the journeys |
| Content provenance | 14 DOIs against Crossref; 23 links checked, none broken | `docs/content-verification.md` |
| Visual | 48 of 48 pass; 97 baselines (89 dark, regenerated for the toggle in the header and bar, plus 8 paper-theme: fold, full page, Publications, and Research at 390 and 1440) regenerated on the final build (320, 360, 390, 768, 1024, 1280×760, 1440, 2560, landscape phone; each lab chapter; a paper open with Cite; Most cited; 404), reviewed, and stable on a second run. They are the reduced-motion rest state. At touch sizes, section captures show the mouse layout (a Playwright quirk, noted in the spec); the journeys check the touch behavior | `tests/visual.spec.ts`, `tests/__screenshots__/` |
| Hero performance (mobile profile, 4× CPU, median of 5) | Largest paint 3.15 → 1.72 s (the poster); longest task 1,413 → 77 ms; blocking time to lab ready 1,836 → 67 ms; taps 500–1,100 → 24–32 ms; CLS 0.002. Header and poster painted by 2.0 s | The hero agent's measurements with `tools/perf` on the export |
| Hero behavior | 38 of 38 functional checks: poster first; three.js only after load and idle, and only with WebGL2 and no data-saver, 2G, or low memory (otherwise a "Load the 3D lab (about 140 KB)" button); context loss brings the still back with a reload button; instrument math in a worker (identical results for all 54 states), with a main-thread fallback | Same |

## Fixed during review (defect log)

| Issue | Where | Fix | Verified by |
| --- | --- | --- | --- |
| Show filter changed the URL but not the list | Publications | `replaceState(null, …)`; filter rules moved out of the components layer | Journeys (click, keys, reload, history) |
| "First author" showed 10 of 7 | Publications | Same layer fix | Journeys |
| Deep link below the lab crashed the page | Hero (engine) | Hero agent; site-level error boundary added meanwhile | Direct-load check; fallback screenshot |
| 404 "Home" landed at the footer | 404 | `data-scroll-behavior="smooth"` (Next 16) | Journeys |
| Focus and selection invisible in forced colors | Site-wide | System-color rules for `:focus-visible` and checked/selected/pressed | a11y forced-colors test |
| Section bar focusable before hydration | Section bar | `inert` rendered in JSX | No-JS journey |
| Filtered deep link landed 2,754 px off | Publications | Re-scroll after the filter applies | Journeys |
| DOI overflowed at 320 px | Cite panel | `overflow-wrap: anywhere` | Reflow test |
| Printed page was light text on white | Print | Palette flipped at the source in `@media print` | Print PDF |
| Membrane coat cut at the card edge | Recognition, lab stills | A centered 3:2 still rendered for the card; the phone and wide framings of "Taken apart" fixed in the engine | Screenshots |
| Instrument math blocked taps for over a second | Hero | Moved to a worker; engine builds in steps with `compileAsync` | Tap timings above |
| Hero text clipped under WCAG text spacing; nav tight at 320 px | Hero | Labels wrap; headline clips only vertically; nav fits | a11y text-spacing and reflow tests |
| Plate text overflowed at 1024 | Recognition | Type scales with the panel (container units) | Overflow check at six widths |
| The full publication list read as "a knowledge dump" | Publications | Rebuilt as an index: short rows, Summary in place, Show and Sort, a bounded list | Owner request; journeys |
| The Scholar readout looked like a sidebar widget and left the section's corner empty | Publications | Rebuilt as an instrument panel beside the list, same edges, the chart in a black well | Art review; screenshots at seven widths |
| Choosing Imaging changed nothing visible (the newest five are imaging papers), and the marks had no words | Publications | A count in the list's header; the marks in the Show options (their legend) and in words for screen readers | Journeys (count); axe |
| Show options read as "Delivery6" to screen readers | Publications | One text node with its space | Journeys (accessible names) |
| Rows stayed closed without JavaScript and in print (Tailwind's `[hidden]` reset is `!important`) | Publications | Closed rows ship `data-closed`, hidden only under `<html data-js>`; scripts turn them into hidden until found | No-JS journey; print check |
| Fitting the list's height on load moved everything below it (a reload at #contact landed under the bar) | Publications | The limit is fitted only after the reader uses the list | Journeys (reload) |
| A malformed `%` escape in the address crashed the page | Publications, lab | Fragments that can't be decoded are read as they stand | Journeys (`#%`, `#pub-100%`, `#lab-%E2%80`) |
| "See the imaging papers" left focus in Research and said nothing | Research, lab, Publications | Plain links the list takes over: filter in place, focus the heading, announce the count | Journeys (focus, status, Back) |
| The list was its own Tab stop: Tab restarted from its first row after a deep link, and the fade hid its ring | Publications | No Tab stop of its own (every row has links) | Journeys; focus walk |
| Papers past a phone's first five couldn't be found | Publications | Hidden until found; a match shows the whole list | Journeys |
| A landscape phone got a 281 px scroll box | Publications | The box only on screens ≥ 48rem wide and ≥ 40rem tall with a fine pointer | Visual (landscape) |
| Browsers without `@media (scripting)` (Safari 16, Firefox 111–112) | Publications | Rules keyed on `<html data-js>`, set by an inline script | Code review |
| The chart and the bars vanished in print | Publications | `print-color-adjust: exact` on the drawn marks | Print check |
| JSON-LD shipped twice (in its tag and in React's payload) | Page | Added to the exported page after the build | `check-built`; budgets |
| The Show and Sort thumbs and the section bar's underline never glided (a resize observer, re-created on each change, placed them again at once) | Publications, section bar | The observer is created once and its first report skipped | Frame captures; "Motion answers input" journey |
| The chosen option's label was light on the arriving thumb for a moment | Publications | A copy of the options in void, clipped to the thumb and gliding with it | Frame captures at 16–300 ms, desktop and phone |
| Scholar's figures spun a full turn and showed false numbers on the way (745, 979 for 104), and showed the true one while waiting | Scholar readout | Figures rise into place from blank; nothing waiting ever shows a number | Frame captures; motion review |
| Rolling digits broke under WCAG text spacing (line height 1.5) | Scholar readout, list count, Recognition counter | The digits are the text; counts swap in a one-line window | a11y text-spacing test |
| The list's count rolled for 1.4 s and read "16" on the way | Publications | 220 ms swap, the old number out and the new in | Motion review |
| Re-sorting drew one title over another; rows that traveled far flew past the panel's edge | Publications | Short moves glide over the rest; far moves and arrivals are uncovered in place, opaque; travel capped | Frame captures |
| Changing the filter while a summary folded left a wrong count | Publications | The fold's end uses the latest measure | "Motion answers input" journey |
| A change during a glide measured from the moving rows | Publications | The last glides stop once their on-screen places are noted | Engineering review repro |
| "Show fewer" left the focused button far above the screen; Tab during a closing fold went into the closing panel | Publications | A big shrink isn't eased (the button is scrolled into view); a closing panel, and a closing Cite panel, is inert | Accessibility review repro |
| Recognition's plates had no background, so a new title showed over the old picture mid-wipe; the scan line ran ahead of its edge | Recognition | Panels on ink; the line and the edge share time and easing; inactive panels inert | Frame captures |
| The marker, rendered first in the tab list, changed the first row's spacing after load (a 17 px shift) | Recognition | Rendered after the rows | "Motion answers input" journey |
| On a phone, Next made the counter flicker between numbers | Recognition | The rail's observer waits while a step scrolls it | Engineering review repro |
| Tall blocks played their moment off screen; a link into the page could leave a block waiting on screen | Reveals | Charts and pictures reveal later; tiles one by one; when scrolling stops, anything waiting on screen plays | Motion journeys |
| A link into the page glided past everything above it on load | Page | Smooth scrolling turns on only once the page has loaded | Journeys (reduced motion control) |
| A stale "Checked" dot still pulsed green; the pulse ran 6 s | Scholar readout | No pulse when stale; one 1.2 s pulse after the tiles settle | Motion review |
| Under reduced motion: the copy check drew, the Summary chevron turned, underlines swept, presses scaled | Site-wide | All cut under reduced motion | Accessibility review |
| In forced colors: the selected tab's words kept their own colors on Highlight (older than this work); the index charts vanished | Recognition, Publications | Everything in a chosen control takes HighlightText; the charts take system colors | Accessibility review |
| Browsers without `linear()` (Safari before 17.2) lost every transition that used the spring | Site-wide | A cubic fallback | Engineering review |
| The delivery diagram's moment was a generic fade; hovering a card erased and redrew its traces | Research | The particle is built (cores, gel, drug, coat); rested on or tapped, a diagram replays without erasing (the particle heats, its gel tightens, the drug moves out; bright copies run along the traces) | Frame captures |
| The dev port collided with Playwright's QA server (3219), so a whole suite ran against `next dev` (no CSP header, different 404) and failed confusingly | Tooling | Dev stays on 3217 (`launch.json`); QA keeps 3219; noted here so nobody parks a server there again | Re-run against the export |
| The 404's header shares `id="top"` with the hero, so the first lab pin dragged it dark-on-paper (axe: 1.1:1) | 404, light theme | The pin became a `.lab-pin` class on the two hero sections only; the 404 flips whole | Paper-theme axe on the 404, both widths |
| Four links plus the toggle overlapped in the section bar at 320 px, and again at 390 px once WCAG text spacing inflated them (a 17 px overlap) | Section bar | Tighter link padding under 22.5rem and a smaller gap; below `sm` the bar's toggle yields to the hero header's copy | 320 px reflow; text-spacing test |
| The export minifies hex, so a print assertion on `#111111` read `#111` | Tests | The assertion accepts both forms | Print-over-light journey |
| The scene's window showed the section background until the poster decoded | Hero | The wrap paints `--lab-void` from first paint, in either theme | Code review; screenshots |
| A deep link or capture reached Recognition before its lazy picture had fetched: an empty plate where the particle belongs, first thing after the hero on a phone | Recognition | The first item's picture loads eagerly (a new `eager` option on Picture, without the poster's fetch priority); later items stay lazy | Handkerchief review; 390 px reload screenshots at 1 s |
| The service plates parked their title in the lower corner of a mostly empty card, reading unfinished beside the particle render | Recognition | The title holds the plate's center, as set type; meta stays at the top edge | Handkerchief review; plate captures, both themes |
| Even centered, the text plates repeated the adjacent entry verbatim with nothing of their own | Recognition | Each service plate carries a drawn mark in the diagrams' stroke language (a constellation for the network, a lattice for materials engineering) as quiet plate art — never a stand-in photo | Second fresh review; plate captures, both themes |
| The rail's peek severed glyphs at the bleed edge, and the last card left the previous card's tail showing | Recognition | A right-edge fade over the peek, and trailing padding equal to the peek so the last card snaps flush like every other | Second fresh review; snapped captures of cards 2 and 3 |
| A fresh reviewer read the first second below the hero as a reflow | Recognition | Rejected with instrumentation: zero layout-shift entries, CLS 0.0000 at 390 and 1440 across load (the measured 0-height box was the hidden desktop panel at phone width) | PerformanceObserver layout-shift run |


## Not verified, or still open

- **The light theme in WebKit and Firefox** is untested (those browsers aren't installed): `color-mix` and the
  relative-alpha tokens have full support there, but the toggle icon's `cx`/`cy` transitions and the crossfade
  are unseen outside Chromium; the icon falls back to a state change, never a wrong state.
- **The manifest and share image stay dark** in the light theme (a static export cannot vary them; the dark lab
  is the identity) — deliberate, not an omission.
- **The page thins below Publications at 1440** (a fresh-eyes review): About, positions, and Contact hold the
  center column while the aside rail sits empty for most of the back half. Worth revisiting when the owner's
  photos, portrait, and CV arrive — those are the natural aside content; re-composing before they exist would
  mean placeholders.
- **WebKit and Firefox** journeys are configured but skipped: those browsers aren't installed
  (`npx playwright install webkit firefox`, a download the owner should approve).
- **Visual baselines** (`tests/__screenshots__`, 39 MB) are macOS and Chrome 153 renders; regenerate them in the
  Playwright Docker image for CI.
- **Text over the 3D scene** can't be checked by axe; the rendered-contrast script in the plan isn't built.
- **Real devices, VoiceOver, 200% zoom** manual passes haven't been run.
- **Motion in Safari and Firefox** is untested (WebKit and Firefox aren't installed): `linear()` has a cubic fallback,
  `@property` (the "Cited by" bars after Most cited) needs Safari 16.4 or Firefox 128, and the Cite panel's ease uses
  `::details-content`, which only Chromium animates (elsewhere it simply opens).
- **"Copied" twice for screen readers:** the copy button's name becomes "Copied" and the polite status says "Copied";
  some screen readers may say it twice (not checked with one).
- **Initial JavaScript** is 182.5 KB: inside the 185 KB budget, above the 165 KB target (the motion below the lab
  added 2.2 KB; it uses no library). The rest is Motion's core
  (about 17 KB; CSS transitions for presses and folds would remove it), `next/link` on `/` (about 3.5 KB), and hero
  code. A design call, left open.
- **Phone poster** paints the 712 px crop first (keeps the largest paint under 2 s); it is slightly soft on 3× screens
  until the 3D lab takes over.
- **Google Scholar refresh:** the workflow has never run on GitHub (its YAML, shell, and issue steps were dry-run).
  Google often refuses requests from cloud servers; then the site keeps the last snapshot and its date, and after 3
  days an issue explains the two fixes (a SerpApi key, or `npm run scholar` on a personal computer). The SerpApi
  path is tested only against SerpApi's documented response. Details: `docs/scholar-sync.md`.
- **Publications without the main script:** if the inline script runs but the page's JavaScript then fails to load,
  closed summaries stay hidden behind buttons that do nothing (there is no timer to open them); with JavaScript
  off entirely, everything is open.
- The export also contains an unused `instruments.worker.*.ts` asset (Turbopack registers the worker URL as an asset
  too); nothing requests it, and `tsconfig.json` excludes `out/`.

## Waiting on the owner

- **Accounts and domain:** Cloudflare and GitHub (in the owner's name), the domain, then `NEXT_PUBLIC_SITE_URL`. For the
  4-hour Google Scholar refresh: the site in its own repository (or `.github/workflows/scholar.yml` copied to the
  repository root), connected to Cloudflare Workers Builds so each snapshot commit redeploys; optionally a
  `SERPAPI_API_KEY` secret (free plan, 250 searches a month) for when Google refuses GitHub's servers.
- **Photos** for each recognition (with the photographer's credit), a portrait, and the CV PDF (turns on `/cv`).
- **Confirmations:** the thesis particle's red blood cell membrane coat; the mucin paper's in vivo retention
  ("stayed in tumors for hours", left out until checked); "image-guided therapy" in the PhD line; SynapSeek's URL;
  analytics (Cloudflare Web Analytics or none); unpublishing the old site.
- **Optional wording calls:** the search title "Madhavi Tripathi · Nanoparticles and photoacoustic imaging" (tells her
  apart from namesakes); explaining the integrated M.Tech.
- **GitHub workflows** (`.github/workflows/`) run only from a repository root: move them when the site gets its own repo.
