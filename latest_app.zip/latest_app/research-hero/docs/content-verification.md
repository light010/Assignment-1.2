# Content verification: publications, links, and the publication pipeline

Checked on 27 September 2026. Every finding names its source. I did not edit anything in `src/content/*.ts`;
the owner should apply the corrections below.

## At a glance

- **Crossref:** all 14 records with a DOI match Crossref on title, year, authors (count, names, and order),
  the owner's position, and CC BY claims. **No bibliographic correction is needed.** One informational note
  concerns how Crossref splits Bell's name on the npj paper.
- **DOIs:** all 15 DOIs on the site resolve at doi.org with a 302 to the publisher. That is the 14 record DOIs
  plus the SSRN preprint.
- **Links:** I checked 23 URLs and found **none broken**. 9 are OK and 1 is restricted (the IISc thesis
  record). 13 are unverifiable because of bot protection: publishers, LinkedIn, and the PULSE Lab site.
- **SPIE 2026 PDFs:** both confirmed as HTTP 200 `application/pdf` on the PULSE Lab site (section 4).
- **CRediT roles:** all six roles are confirmed. The published wording of the sixth differs from the curated
  text (section 5).
- **Pipeline:** `scripts/enrich-publications.mts`, `scripts/add-paper.mts`, the snapshot
  `src/content/publications.crossref.json`, and two workflows in `.github/workflows/` (inside the app folder,
  see section 7.3).

## 1. Corrections and suggestions

### Changes to make

| # | File · record · field | Current | Correct or suggested | Source |
| --- | --- | --- | --- | --- |
| 1 | `publications.ts` · `sharma-2025-gcnr-slsc` · `role.credit[5]` | `"Writing – review and editing"` | `"Writing—review & editing"`, as the journal prints it (em dash, ampersand). The CRediT term itself is `"Writing – review & editing"`. The role is right; only the wording differs. | PubMed Central copy of the article, "Author contributions": https://pmc.ncbi.nlm.nih.gov/articles/PMC12709606/ |
| 2 | `publications.ts` · `enslein-2026-spie` · `access`, `links` | `access: "subscription"`, `links: [doi("10.1117/12.3081139")]` | Suggest `access: "lab-pdf"` and add `{ kind: "pdf", href: "https://pulselab.jhu.edu/wp-content/uploads/2026/03/Enslein_SPIE_2026.pdf", label: "PDF" }` | https://pulselab.jhu.edu/publications/ (section 4) |
| 3 | `publications.ts` · `drabek-2026-spie` · `access`, `links` | `access: "subscription"`, `links: [doi("10.1117/12.3083562")]` | Suggest `access: "lab-pdf"` and add `{ kind: "pdf", href: "https://pulselab.jhu.edu/wp-content/uploads/2026/03/Drabek_SPIE_2026.pdf", label: "PDF" }` | https://pulselab.jhu.edu/publications/ (section 4) |
| 4 | `person.ts` · `education[0].link` | `{ label: "Thesis record", href: "https://etd.iisc.ac.in/handle/2005/6575" }` | Outside IISc the page answers 403 with "This page is accessible only within the IISc network." `publications.ts` warns about this ("IISc network only"), but this link does not. Suggest the label `"Thesis record (IISc network only)"`, or drop the link here. | Checked with curl and in a browser |

Items 2 and 3 are the owner's call: the lab hosts the PDFs publicly, but I did not review SPIE's posting policy.

### Information only (no change required)

- **Bell's family name on the npj paper.** Crossref splits it as given "Muyinatu A. Lediju", family "Bell".
  - The other four papers with her, and PubMed, use "Lediju Bell". The owner's `family: "Lediju Bell"` on
    all five is consistent.
  - The checks print this as a note, not a failure.
  - Source: https://api.crossref.org/works/10.1038/s44303-026-00193-4
- **Co-first authorship.** IISc's feature says "Tripathi and Swathi Padmanabhan are co-first authors" of the
  nanohybrids paper (`tripathi-2023-nanohybrids`). The site's "First author" label is accurate, but the
  shared credit isn't shown.
  - Source: https://www.iisc.ac.in/events/hybrid-nanoparticles-shine-new-light-on-targeting-cancer-cells/
- **Postdoc dates.** The PULSE Lab people page lists "Madhavi Tripathi, 2024-2025" under Alumni.
  - That supports the résumé's December 2024 start. The résumé and ORCID give 2026-01 as the end.
  - No change: `person.ts` already treats the résumé as primary.
- **Details that Crossref lacks.**
  - The SPIE paper numbers "1385103" and "138510N" are not in Crossref (its `page` field says 8 and 56).
    NASA ADS bibcodes corroborate them: `2026SPIE13851E..03E` and `2026SPIE13851E..0ND` (volume 13851,
    papers 03 and 0N). The SPIE page itself sits behind a CAPTCHA.
  - JBO's "085001" is the article ID in its DOI (Crossref's `page` field is "1-15").
- **MXene paper.** OpenAlex lists a copy on IISc eprints (https://eprints.iisc.ac.in/71703/). It answered
  403 to a header-only request, so it is probably IISc-only. Unverified; no change.
- **Access claims.** Apart from that MXene copy, OpenAlex agrees with every `access` value:
  - gold CC BY for npj, JBO, and Radiology Advances;
  - diamond CC BY for the stem-cell review;
  - bronze (free to read) for the malaria paper, which backs `free-to-read`;
  - closed for the rest.

## 2. Crossref validation

Run with `npm run enrich` (live) or `node scripts/enrich-publications.mts --offline` (against the snapshot).
The final live run:

```text
Fetching 14 DOIs from Crossref...
Snapshot unchanged: src/content/publications.crossref.json

#   id                            title  year  authors  Tripathi  license     result
--  ----------------------------  -----  ----  -------  --------  ----------  ------
1   enslein-2026-npj-imaging      ok     2026  8/8      #2 name   CC BY 4.0   pass*
2   arroyo-2026-jbo               ok     2026  7/7      #3 name   CC BY 4.0   pass
3   enslein-2026-spie             ok     2026  5/5      #2 name   none        pass
4   drabek-2026-spie              ok     2026  6/6      #2 name   none        pass
5   sharma-2025-gcnr-slsc         ok     2025  10/10    #3 ORCID  CC BY 4.0   pass
6   tripathi-2025-mucin           ok     2025  5/5      #1 ORCID  none        pass
7   tripathi-2024-nanoflakes      ok     2024  4/4      #1 ORCID  none        pass
8   tripathi-2023-nanohybrids     ok     2023  4/4      #1 ORCID  none        pass
9   tripathi-2023-hydrogels       ok     2023  3/3      #1 name   none        pass
10  wazalwar-2022-mxene-epoxy     ok     2022  3/3      #2 name   none        pass
11  jain-2021-biopolymer          ok     2021  4/4      #2 name   none        pass
12  jain-2021-hydroxychloroquine  ok     2021  5/5      #3 name   none        pass
13  tripathi-2015-malaria         ok     2015  2/2      #1 name   free (n/a)  pass
14  tripathi-2015-stem-cells      ok     2015  2/2      #1 name   CC BY 4.0   pass

Notes (not failures):
  enslein-2026-npj-imaging  author #8 family: current "Lediju Bell"; Crossref "Bell"

Venue and details (information only):
  enslein-2026-npj-imaging        venue same; details none (none in Crossref)
  arroyo-2026-jbo                 venue same; details volume/issue ok; 085001 is the DOI's article ID (Crossref page 1-15)
  enslein-2026-spie               venue contains "Photons Plus Ultrasound: Imaging and Sensing 2026"; details 1385103 not in Crossref (page 8)
  drabek-2026-spie                venue contains "Photons Plus Ultrasound: Imaging and Sensing 2026"; details 138510N not in Crossref (page 56)
  sharma-2025-gcnr-slsc           venue same; details volume/issue ok; umaf037 matches
  tripathi-2025-mucin             venue same; details volume/issue ok; 106668 matches
  tripathi-2024-nanoflakes        venue same; details volume/issue ok; 1671-1681 matches
  tripathi-2023-nanohybrids       venue same; details volume/issue ok; 14861-14875 matches
  tripathi-2023-hydrogels         venue contains "Functional Nanocomposite Hydrogels"; details 453-477 matches
  wazalwar-2022-mxene-epoxy       venue same; details volume/issue ok; 2573-2584 matches
  jain-2021-biopolymer            venue contains "Encyclopedia of Materials: Composites"; details 804-817 matches
  jain-2021-hydroxychloroquine    venue same; details volume/issue ok; 715-734 matches
  tripathi-2015-malaria           venue same; details volume/issue ok; 1636-1638 matches
  tripathi-2015-stem-cells        venue same; details volume/issue ok; 16-24 matches

No DOI, not checked: tripathi-phd-thesis

14 checked against live Crossref: 14 pass, 0 fail. Owner ORCID 0000-0002-4736-9134.
```

How to read the Tripathi column:

- **"#3 ORCID"** means Crossref carries the owner's ORCID on that author (4 papers).
- **"#2 name"** means the name and position match, but Crossref has no ORCID to confirm it (10 papers).

## 3. Link check

**Method.** I checked every `href` in `publications.ts`, `person.ts`, and `about.ts`, plus the Scholar, ORCID,
and LinkedIn URLs, and every `doi()` call.

- Each URL got a GET with curl, following up to 15 redirects.
- Requests used a desktop Chrome User-Agent, a temporary cookie jar, and a 40-second timeout.
- Each DOI's first hop was also requested without following redirects.

**How to read the verdicts.**

- 401, 403, and 429 from publishers, LinkedIn, and pulselab.jhu.edu count as unverifiable, not broken.
- For the 200s I also checked what the page is.
- The PULSE Lab and IISc thesis pages were opened in a real browser too.

| # | URL | In | doi.org | Final status | Verdict |
| --- | --- | --- | --- | --- | --- |
| 1 | https://pmc.ncbi.nlm.nih.gov/articles/PMC13452404/ | publications |  | 200 pmc.ncbi.nlm.nih.gov | OK: the JBO paper (Europe PMC gives DOI 10.1117/1.jbo.31.8.085001) |
| 2 | https://academic.oup.com/radadv/article/2/6/umaf037/8300868 | publications |  | 403 academic.oup.com | Unverifiable: Cloudflare human check (not completed) |
| 3 | https://doi.org/10.2139/ssrn.4972313 | publications | 302 → www.ssrn.com | 403 www.ssrn.com | Unverifiable: publisher Cloudflare challenge; not broken |
| 4 | https://etd.iisc.ac.in/handle/2005/6575 | publications, person |  | 403 etd.iisc.ac.in | Restricted: "accessible only within the IISc network" (also in a browser) |
| 5 | https://doi.org/10.1038/s44303-026-00193-4 | publications, about | 302 → www.nature.com | 200 www.nature.com | OK: article page |
| 6 | https://doi.org/10.1117/1.JBO.31.8.085001 | publications | 302 → www.spiedigitallibrary.org | 200 www.spiedigitallibrary.org | Unverifiable: the 200 is an Imperva bot-block page ("Request unsuccessful"); a browser gets a reCAPTCHA. Not broken |
| 7 | https://doi.org/10.1117/12.3081139 | publications | 302 → www.spiedigitallibrary.org | 200 www.spiedigitallibrary.org | Unverifiable: the 200 is an Imperva bot-block page ("Request unsuccessful"); a browser gets a reCAPTCHA. Not broken |
| 8 | https://doi.org/10.1117/12.3083562 | publications | 302 → www.spiedigitallibrary.org | 200 www.spiedigitallibrary.org | Unverifiable: the 200 is an Imperva bot-block page ("Request unsuccessful"); a browser gets a reCAPTCHA. Not broken |
| 9 | https://doi.org/10.1093/radadv/umaf037 | publications | 302 → academic.oup.com | 403 academic.oup.com | Unverifiable: publisher Cloudflare challenge; not broken |
| 10 | https://doi.org/10.1016/j.jddst.2025.106668 | publications | 302 → linkinghub.elsevier.com | 200 linkinghub.elsevier.com | OK: Elsevier linking hub (script redirect to ScienceDirect) |
| 11 | https://doi.org/10.1021/acsabm.3c01123 | publications | 302 → pubs.acs.org | 403 pubs.acs.org | Unverifiable: publisher Cloudflare challenge; not broken |
| 12 | https://doi.org/10.1021/acsanm.3c02405 | publications | 302 → pubs.acs.org | 403 pubs.acs.org | Unverifiable: publisher Cloudflare challenge; not broken |
| 13 | https://doi.org/10.1016/B978-0-323-99638-9.00019-8 | publications | 302 → linkinghub.elsevier.com | 200 linkinghub.elsevier.com | OK: Elsevier linking hub (script redirect to ScienceDirect) |
| 14 | https://doi.org/10.1021/acsapm.1c01876 | publications | 302 → pubs.acs.org | 403 pubs.acs.org | Unverifiable: publisher Cloudflare challenge; not broken |
| 15 | https://doi.org/10.1016/B978-0-12-819724-0.00028-8 | publications | 302 → linkinghub.elsevier.com | 200 linkinghub.elsevier.com | OK: Elsevier linking hub (script redirect to ScienceDirect) |
| 16 | https://doi.org/10.1080/17512433.2021.1909473 | publications | 302 → www.tandfonline.com | 403 www.tandfonline.com | Unverifiable: publisher Cloudflare challenge; not broken |
| 17 | https://doi.org/10.1111/tmi.12594 | publications | 302 → onlinelibrary.wiley.com | 403 onlinelibrary.wiley.com | Unverifiable: publisher Cloudflare challenge; not broken |
| 18 | https://doi.org/10.4236/jbm.2015.311002 | publications | 302 → www.scirp.org | 200 www.scirp.org | OK: article page |
| 19 | https://scholar.google.com/citations?user=zZx1Td0AAAAJ&hl=en | person |  | 200 scholar.google.com | OK: profile page titled "Madhavi Tripathi" |
| 20 | https://www.linkedin.com/in/mtri16 | person |  | 999 www.linkedin.com | Unverifiable: LinkedIn answers 999 to automated clients; not broken |
| 21 | https://pulselab.jhu.edu/people/ | person |  | 403 pulselab.jhu.edu | Unverifiable to curl (Cloudflare); in a browser it loads and lists "Madhavi Tripathi, 2024-2025" under Alumni |
| 22 | https://www.iisc.ac.in/events/hybrid-nanoparticles-shine-new-light-on-targeting-cancer-cells/ | about |  | 200 www.iisc.ac.in | OK: feature dated 11 September 2023 |
| 23 | https://orcid.org/0000-0002-4736-9134 | person (ORCID iD) |  | 200 orcid.org | OK: public record name is Madhavi Tripathi |

## 4. SPIE 2026 papers: PDFs on the PULSE Lab site

curl gets HTTP 403 from https://pulselab.jhu.edu/publications/: a Cloudflare "Attention Required!" block page.
The page loads normally in a browser.

It lists both papers with a "[pdf]" link. I checked each link with a header-only request (HEAD) from the lab
page; nothing was downloaded. Both answer HTTP 200 with `content-type: application/pdf` and no redirect:

| DOI | Exact PDF URL | Size | Last modified |
| --- | --- | --- | --- |
| 10.1117/12.3081139 (Enslein et al.) | https://pulselab.jhu.edu/wp-content/uploads/2026/03/Enslein_SPIE_2026.pdf | 2,083,828 bytes | Sun, 08 Mar 2026 20:50:20 GMT |
| 10.1117/12.3083562 (Drabek et al.) | https://pulselab.jhu.edu/wp-content/uploads/2026/03/Drabek_SPIE_2026.pdf | 1,002,824 bytes | Sun, 08 Mar 2026 20:50:21 GMT |

Scripts will keep getting 403 from this site, so CI link checks should treat it as unverifiable. The page's
three other Tripathi entries (npj Imaging, JBO, Radiology Advances) link to the publishers, not to lab-hosted
PDFs. Their author lists match the curated order.

## 5. CRediT roles (Radiology Advances, 10.1093/radadv/umaf037)

The article's "Author contributions" section lists the owner as:

> Madhavi Tripathi (Data curation, Formal analysis, Investigation, Software, Validation, Writing—review & editing)

**How I read it.** The text is from the published version in PubMed Central
(https://pmc.ncbi.nlm.nih.gov/articles/PMC12709606/). The same text is in the JATS full text that Europe PMC
serves (https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12709606/fullTextXML), where the dash is U+2014.

**The publisher's page.** The OUP page (https://academic.oup.com/radadv/article/2/6/umaf037/8300868, the
`role.source`) shows automated clients a Cloudflare "Verify you are human" check. I did not complete it.
Please confirm on that page in a normal browser.

**Result.** The six curated roles are correct. Only the sixth is worded differently; see correction 1.

## 6. ORCID

https://pub.orcid.org/v3.0/0000-0002-4736-9134/works lists 4 works, all with DOIs, and all on the site. The
weekly watch would open no issue today.

Ten of the site's DOIs, plus the thesis, are not on ORCID. Adding them there would help indexes tell her
apart from other Madhavi Tripathis, as the site plan suggests. `--orcid` prints the list.

## 7. The pipeline

### 7.1 `scripts/enrich-publications.mts`

**Modes.**

- `npm run enrich` fetches every DOI from Crossref and writes the snapshot. Then it validates and prints the
  table above.
- `--offline` validates against the committed snapshot with no network, for CI.
- `--orcid [--orcid-id <iD>] [--report file.md]` lists DOIs on ORCID that the site lacks. It also writes
  `missing=<n>` to `$GITHUB_OUTPUT` for the workflow.
- `--file` and `--snapshot` point it at copies.

**Exit codes.** 0 when all checks pass, 1 on any mismatch or fetch failure, 2 on a usage error.

**Checks.**

- **Title:** equal after ignoring case, punctuation, dashes, markup, and diacritics.
- **Year:** Crossref's first-published year.
- **Authors:** same count, and the same names in the same order, after folding diacritics and initials.
  "Eniola T." matches Crossref's "Eniola T".
- **Tripathi:** the curated `me` author is a Madhavi (or M.) Tripathi at the same position.
  - A Crossref ORCID there must be the owner's.
  - The owner's iD is read from `person.ts`.
- **License:** a "CC BY 4.0" claim needs a CC BY 4.0 license in Crossref.
- **Information only:** venue, volume, issue, pages, type, and the curated `family`.

**Escape hatch.** Reviewed differences can be recorded in the script's `ACCEPTED` map, which is empty today.

**Crossref etiquette.**

- User-Agent `madhavi-tripathi-site/1.0 (+https://github.com/)`, with no email.
- At least 250 ms between requests (the public pool allows 5 per second).
- A 20-second timeout.
- Up to 5 attempts, with backoff and `Retry-After`. The first probe hit one 429.

**Snapshot.**

- `src/content/publications.crossref.json` maps DOI (as written in `publications.ts`) to
  `{title, container, volume, issue, page, articleNumber, published (ISO), type, license[], authors[]}`.
- Authors are `{given, family}`, plus `orcid` where Crossref has one. Keeping the ORCID lets the offline check
  catch namesakes.
- Keys are sorted, the indent is two spaces, and there is no timestamp. A re-run produced a byte-identical
  file.
- Markup is stripped and entities decoded: `<scp>DNA</scp>` becomes DNA, and `&amp;` becomes &.
- The snapshot is not rewritten if any DOI fails to fetch.

**Loading `publications.ts`.**

- The script imports the file through Node's type stripping.
- A `module.registerHooks` resolver maps `@/` and extensionless imports. It's only a safety net: the file has
  type-only imports today.
- The resolver needs Node 22.15 or later and is skipped on older versions; `.nvmrc` pins 24.
- The project's typecheck and ESLint pass on both scripts.

**Tests.** I planted errors in a copy of `publications.ts`, and each one failed with the field, both values,
and the Crossref URL:

- a one-letter title change;
- a wrong year;
- a misspelled author;
- the owner moved to another position;
- a dropped author;
- a CC BY claim on a subscription paper.

A name that matched only as initials passed with a note. A doctored snapshot copy also caught:

- a namesake ORCID;
- a paper with no Tripathi;
- a missing entry;
- a stale entry.

### 7.2 `scripts/add-paper.mts`

```bash
node scripts/add-paper.mts --doi 10.xxxx/yyy --summary "One sentence." [--role "Data curation, Software"] \
  [--themes delivery,imaging] [--chapters design,deliver,photoacoustic,ultrasound] [--selected]
# also: --slug <words>  --type <journal-article|review|conference-paper|book-chapter|thesis>  --file  --snapshot  --dry-run
```

**What it builds.** A record in the house style:

- **Id:** `<first author family>-<year>-<slug>`.
- **Authors:** display names with initials given a full stop, `me` for the owner, and `family` when the
  family name is more than one word.
- **Title:** Crossref's, with markup stripped and any final full stop removed. `check-content` rejects titles
  that end in a full stop.
- **Venue:** SPIE proceedings become "Proceedings of SPIE <vol>, <container>", and book chapters get
  "(Publisher)".
- **Details:** `vol(issue), pages|article`, or `pp. x–y` for chapters. SPIE journals get their article ID from
  the DOI.
- **Links:** `links: [doi(...)]`.
- **Access:** `"subscription"` unless Crossref lists CC BY 4.0. In that case it's `"open-access"` with
  `license: "CC BY 4.0"`. Any other Creative Commons license gives `"open-access"` without a label, plus a
  warning.
- **Role:** `--role` splits on commas into `role.credit`, with `source: https://doi.org/<doi>`. It warns about
  names that aren't CRediT roles.

**Where it goes.** Directly below the marker comment when the paper is newer than every record, the usual
case. An older paper goes above the first record that is older still.

This is one deliberate deviation from "always below the marker". `check-content` fails when the list isn't
newest first by year, and the ORCID watch will surface older papers.

**Other effects.**

- It adds the Crossref entry to the snapshot beside the edited file, so `--offline` passes.
- It re-imports the edited file to confirm the record reads back, and restores the file if it doesn't.
- In Actions, it writes `id`, `doi`, and `title` to `$GITHUB_OUTPUT`.

**Refusals (exit 1).** Tested on copies:

- a DOI already present, including in URL form or with different case;
- a DOI that appears only as another record's preprint link;
- an id already used;
- a DOI unknown to Crossref;
- a malformed DOI;
- an unknown theme or chapter ("delivery" as a chapter gets a hint);
- an empty summary;
- a missing marker;
- a paper with no Tripathi;
- a Madhavi Tripathi with another ORCID. Both of the nuclear-medicine namesake's papers are refused
  (10.1007/s00234-024-03434-8 and 10.1097/nm9.0000000000000029).

A namesake who has no ORCID in Crossref cannot be told apart. Such a paper is accepted with a "check before
merging" warning. The pull request review is the safeguard.

**Tests.** All ran on copies under `/private/tmp/claude-501/`. The real `publications.ts` was never written
by these tests; its checksum was checked after each run.

- **Round trip.** I re-derived all 14 records. Structure, authors, venue, details, access, and license come
  back as curated, except Bell's `family` on the npj paper, where Crossref splits the name differently. The
  only other differences are expected:
  - Crossref's Title Case, which triggers a warning;
  - links Crossref can't know (PMC, preprint);
  - SPIE paper numbers, which trigger a warning;
  - `free-to-read`;
  - line wrapping, because the file is hand-wrapped.
- **Placement.** Re-inserting 5 records at different ages restored the original order exactly, and the
  snapshot byte-for-byte.
- **Checks on the result.** An edited copy passes `tsc`. A sandbox copy of the app with a newly added record
  passes `enrich --offline` and the owner's `scripts/check-content.mts`.

### 7.3 Workflows

Both workflows are in `latest_app/research-hero/.github/workflows/`.

**Where they must live.** **GitHub only runs workflows from `.github/workflows` at the repository root**,
which is `/Users/praka/Workspace/Projects/Chiku_website/.github/`. I did not create anything there. To use
the workflows, copy both files to the root.

**Working directory.** Every step runs in `latest_app/research-hero`. Set it to `.` if the app becomes its
own repository.

**No remote yet.** The repository has no git remote, so neither workflow has run on GitHub.

- I parsed both files.
- I rehearsed the add-paper steps from the YAML in a sandbox, with `git` and `gh` stubbed: drafting, the
  offline check, the content check, and the pull-request body.

**`add-paper.yml`.**

- **Trigger and inputs:** `workflow_dispatch` with `doi`, `summary`, `role` (optional), `themes`, and
  `chapters`. The inputs reach the shell only through `env`.
- **Steps:** Node 24 → `add-paper.mts` → `enrich-publications.mts --offline` →
  `npm ci && npm run typecheck && npm run check:content` → branch `add-paper/<id>` → `gh pr create` with
  `GITHUB_TOKEN`. The pull request body carries a review checklist and the script output.
- **Actions:** pinned to full SHAs. `actions/checkout` is v7.0.1 `3d3c42e5aac5ba805825da76410c181273ba90b1`,
  and `actions/setup-node` is v7.0.0 `820762786026740c76f36085b0efc47a31fe5020`. There is no dependency cache
  in this write-enabled job.
- **Repository setting it needs:** Settings → Actions → General → "Allow GitHub Actions to create and approve
  pull requests".
- **Pull requests it opens:** because they come from `GITHUB_TOKEN`, they don't trigger other workflows. That
  is why the checks run before the pull request is opened.

**`publications-check.yml`.**

- **Snapshot job:** on `pull_request` (paths: the publication files and scripts) and weekly (Monday 06:17
  UTC), it runs `node scripts/enrich-publications.mts --offline`. It needs no npm install.
- **ORCID job:** weekly or manual only. It reads ORCID and opens one issue labeled `orcid-watch` listing DOIs
  on ORCID that are missing from the site. While the issue stays open, it is updated when the list changes,
  and it is closed once nothing is missing.
- **Schedule caveats:** scheduled runs use the default branch. GitHub pauses them after 60 days without
  activity in a public repository.

## 8. What I could not verify, and why

- **The OUP article page:** the CRediT source and the DOI landing page. It shows a Cloudflare interactive
  human check, which I did not complete. The roles were confirmed from PubMed Central instead; please confirm
  on OUP in a browser.
- **SPIE Digital Library pages** (3 DOIs), and so the SPIE paper numbers from the publisher. Scripts get an
  Imperva block and browsers a reCAPTCHA, which I did not complete. The paper numbers are corroborated by NASA
  ADS only.
- **ACS (3), Wiley, Taylor & Francis, and SSRN landing pages:** Cloudflare challenges. The DOIs resolve (302);
  the landing pages were not read.
- **LinkedIn** (`/in/mtri16`): it answers 999 to automated clients.
- **The IISc thesis record:** restricted to the IISc network.
- **The owner's identity on the 10 papers where Crossref has no ORCID for her:** these match on name and
  position only. ORCID confirms 4 papers.
- **The IISc eprints copy of the MXene paper:** 403.
- **Running the workflows on GitHub:** not possible without a remote (section 7.3).

## 9. Outside my files (suggestions)

- `package.json`: optionally add `"add-paper": "node scripts/add-paper.mts"` next to `"enrich"`.
- `add-paper.mts` imports `./enrich-publications.mts` with its extension. That relies on
  `allowImportingTsExtensions`, which `tsconfig.json` now sets. Keep it on.
