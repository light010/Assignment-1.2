import type { Metadata } from "next";
import { Hero } from "@/components/hero/hero";
import { About } from "@/components/site/about";
import { Contact } from "@/components/site/contact";
import { Footer } from "@/components/site/footer";
import { HeroBoundary } from "@/components/site/hero-boundary";
import { Publications } from "@/components/site/publications";
import { Recognition } from "@/components/site/recognition";
import { Research } from "@/components/site/research";
import { Reveals } from "@/components/site/reveals";
import { SectionBar } from "@/components/site/section-bar";
import { StaticHero } from "@/components/site/static-hero";
import { person } from "@/content/person";
import { UI } from "@/content/ui";

export const metadata: Metadata = {
  alternates: { canonical: "/" },
};

/*
  One page: the lab, then the record. Recognition and service first, in a compact rail, then Research,
  Publications, About, Contact, in the order a committee reads them: what, the evidence, who, how to reach.
  "Skip the lab" is the first thing a keyboard meets. The structured data (JSON-LD) is added to the exported
  page after the build (scripts/inject-structured-data.mts), so it isn't sent a second time in React's payload.
*/
export default function Home() {
  return (
    <>
      <a href="#recognition" className="skip-link">
        {UI.skipLink}
      </a>
      <main id="main">
        <HeroBoundary fallback={<StaticHero />}>
          <Hero />
        </HeroBoundary>
        <SectionBar name={person.name} />
        <Recognition />
        <Research />
        <Publications />
        <About />
        <Contact />
      </main>
      <Footer />
      <Reveals />
    </>
  );
}
