import type { Metadata } from "next";
import Link from "next/link";
import { GRID, SHELL } from "@/components/site/layout";
import { Footer } from "@/components/site/footer";
import { person } from "@/content/person";
import { UI } from "@/content/ui";

export const metadata: Metadata = {
  title: UI.notFound.title,
};

/** The error state, in the site's voice: what happened, and three ways out. */
export default function NotFound() {
  const exits = [
    { label: UI.notFound.home, href: "/" },
    { label: UI.publications.title, href: "/#publications" },
    { label: UI.contact.title, href: "/#contact" },
  ];
  return (
    <>
      <header id="top" className={`${SHELL} flex min-h-(--header-h) items-center border-b border-hairline`}>
        <Link href="/" className="inline-flex min-h-11 items-center rounded-lg font-display text-[1.0625rem] italic text-bone outline-none focus-visible:ring-2 focus-visible:ring-echo">
          {person.name}
        </Link>
      </header>
      <main id="main" className={`${SHELL} ${GRID} py-(--space-block)`}>
        <div className="col-span-full md:col-[1/span_7]">
          <h1 className="font-display display-optical text-display text-balance font-[380] text-bone">{UI.notFound.title}</h1>
          <p className="mt-6 max-w-[30em] font-display text-deck text-pretty text-bone">
            {UI.notFound.message}
          </p>
          <ul className="mt-8 flex flex-wrap gap-3">
            {exits.map((e) => (
              <li key={e.href}>
                <Link
                  href={e.href}
                  className="inline-flex min-h-11 items-center rounded-full border border-line-control px-5 text-[0.9375rem] text-bone-soft outline-none transition-colors duration-150 hover:border-bone hover:text-bone focus-visible:ring-2 focus-visible:ring-echo focus-visible:ring-offset-2 focus-visible:ring-offset-void"
                >
                  {e.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </main>
      <Footer labNote={false} />
    </>
  );
}
