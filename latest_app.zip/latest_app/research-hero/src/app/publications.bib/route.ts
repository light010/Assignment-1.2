import { publications } from "@/content/publications";
import { UPDATED } from "@/content/site";
import { bibtex } from "@/lib/format";

// Written to out/publications.bib at build time; the host serves it as plain text (public/_headers).
export const dynamic = "force-static";

export function GET() {
  const header = `% Publications of Madhavi Tripathi, checked against Crossref in ${UPDATED.label}.\n\n`;
  return new Response(header + publications.map(bibtex).join("\n\n") + "\n", {
    headers: { "Content-Type": "text/plain; charset=utf-8" },
  });
}
