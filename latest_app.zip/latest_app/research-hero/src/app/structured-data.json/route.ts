import { structuredData } from "@/lib/jsonld";

/*
  The home page's structured data (JSON-LD), written to out/structured-data.json at build time. It is not a page
  of its own: scripts/inject-structured-data.mts moves it into out/index.html and deletes this file. Rendered from
  React instead, the same 15 KB would ship twice (in the <script>, and again in the payload React hydrates from).
*/
export const dynamic = "force-static";

export function GET() {
  return new Response(structuredData(), { headers: { "Content-Type": "application/ld+json; charset=utf-8" } });
}
