import type { MetadataRoute } from "next";
import { person } from "@/content/person";

export const dynamic = "force-static";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: person.name,
    short_name: person.name,
    description: "Nanomaterials for delivery. Light and sound for imaging.",
    start_url: "/",
    display: "browser",
    background_color: "#060a0c",
    theme_color: "#060a0c",
    icons: [
      { src: "/icon.svg", type: "image/svg+xml", sizes: "any" },
      { src: "/apple-icon.png", type: "image/png", sizes: "180x180" },
    ],
  };
}
