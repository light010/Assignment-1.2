import type { Metadata, Viewport } from "next";
import { Mona_Sans, Newsreader } from "next/font/google";
import { person } from "@/content/person";
import { DESCRIPTION, SITE_URL } from "@/content/site";
import "./globals.css";

/*
  Fonts: the roman Newsreader and Mona Sans preload; the italic (used only for the name) loads on its
  own without a preload, which takes the preloaded fonts from 368 KB to about 225 KB. Both Newsreader
  calls declare the same family with different styles, so `italic` resolves to the real italic.
*/
const newsreader = Newsreader({
  subsets: ["latin"],
  axes: ["opsz"],
  style: ["normal"],
  variable: "--font-newsreader",
  display: "swap",
});

const newsreaderItalic = Newsreader({
  subsets: ["latin"],
  style: ["italic"],
  weight: "400",
  variable: "--font-newsreader-italic",
  display: "swap",
  preload: false,
});

const mona = Mona_Sans({
  subsets: ["latin"],
  axes: ["wdth"],
  variable: "--font-mona",
  display: "swap",
});

const title = `${person.name}, ${person.role.value.toLowerCase()}`;

// Page-level openGraph would replace this whole object (the merge is shallow), so pages set only
// what differs: their canonical address and, for the 404, noindex.
export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: { default: title, template: `%s · ${person.name}` },
  description: DESCRIPTION,
  applicationName: person.name,
  authors: [{ name: person.name }],
  openGraph: {
    type: "profile",
    siteName: person.name,
    title,
    description: DESCRIPTION,
    url: "/",
    locale: "en_US",
    firstName: "Madhavi",
    lastName: "Tripathi",
  },
  twitter: { card: "summary_large_image", title, description: DESCRIPTION },
  formatDetection: { email: false, telephone: false, address: false },
};

export const viewport: Viewport = {
  themeColor: "#060a0c",
  colorScheme: "dark",
};

/*
  "This page's script runs": set before first paint, so CSS can lay out what only works with JavaScript (the
  publication list's limits and closed rows) without a flash, and leave everything open when scripts are off.
  The theme is resolved in the same breath — a stored choice, else the system's preference — so a light-theme
  visitor never sees the dark paint first. Storage can be unavailable (private modes, blocked site data): then
  the system preference decides, and without JavaScript the page is dark, as its tests and posters assume.
  The attributes are added to <html> before React hydrates it, hence suppressHydrationWarning (one level deep).
*/
const SCRIPTED = `document.documentElement.setAttribute("data-js","");try{var t=localStorage.getItem("theme");if(t!=="light"&&t!=="dark")t=matchMedia("(prefers-color-scheme: light)").matches?"light":"dark";if(t==="light")document.documentElement.setAttribute("data-theme","light")}catch(e){}`;

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html
      lang="en"
      data-scroll-behavior="smooth"
      className={`${newsreader.variable} ${newsreaderItalic.variable} ${mona.variable}`}
      suppressHydrationWarning
    >
      <head>
        <script dangerouslySetInnerHTML={{ __html: SCRIPTED }} />
      </head>
      <body>{children}</body>
    </html>
  );
}
