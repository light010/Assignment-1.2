import type { MetadataRoute } from "next";
import { SITE_URL, UPDATED } from "@/content/site";

// Required for a static export: metadata routes must be marked static.
export const dynamic = "force-static";

export default function sitemap(): MetadataRoute.Sitemap {
  return [{ url: `${SITE_URL}/`, lastModified: UPDATED.iso, changeFrequency: "monthly", priority: 1 }];
}
