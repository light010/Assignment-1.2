"use client";

import { useSyncExternalStore } from "react";

/**
 * Media-query state that hydrates cleanly: the server snapshot is always false, and React
 * swaps in the real value right after hydration instead of throwing a mismatch.
 */
export function useMedia(query: string) {
  return useSyncExternalStore(
    (onChange) => {
      const m = window.matchMedia(query);
      m.addEventListener("change", onChange);
      return () => m.removeEventListener("change", onChange);
    },
    () => window.matchMedia(query).matches,
    () => false,
  );
}

export const REDUCED_MOTION_QUERY = "(prefers-reduced-motion: reduce)";

export function usePrefersReducedMotion() {
  return useMedia(REDUCED_MOTION_QUERY);
}
