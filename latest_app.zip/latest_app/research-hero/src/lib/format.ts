import type { Access, Author, Fact, PubType, Publication } from "@/content/types";

/*
  Formatting shared by the page, the citation panel, BibTeX, and structured data.
  Dates: "Sep 2026" in lists, "Sep 28, 2026" with a day (American order), "September 2026" in prose, ISO in
  data. Ranges use an unspaced en dash.
*/

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/** "2026-02" → "Feb 2026"; "2026-09-04" → "Sep 4, 2026". */
export function dateLabel(iso: string): string {
  const [y, m, d] = iso.split("-").map(Number);
  if (!m) return String(y);
  const month = MONTHS[m - 1];
  return d ? `${month} ${d}, ${y}` : `${month} ${y}`;
}

/** "Feb 2026–present", "Dec 2024–Jan 2026". */
export function rangeLabel(start: string, end?: string): string {
  return `${dateLabel(start)}–${end ? dateLabel(end) : "present"}`;
}

/** In production, only confirmed facts reach the page. */
export function shown<T>(fact: Fact<T> | undefined): fact is Fact<T> {
  if (!fact) return false;
  return fact.confirmed || process.env.NODE_ENV !== "production";
}

export const TYPE_LABEL: Record<PubType, string> = {
  "journal-article": "Journal article",
  review: "Review",
  "conference-paper": "Conference paper",
  "book-chapter": "Book chapter",
  thesis: "Thesis",
};

export const ACCESS_LABEL: Partial<Record<Access, string>> = {
  "open-access": "Open access",
  "free-to-read": "Free to read",
  "lab-pdf": "Free PDF",
};

export function familyName(a: Author): string {
  if (a.family) return a.family;
  const parts = a.name.trim().split(/\s+/);
  return parts[parts.length - 1];
}

export function givenNames(a: Author): string {
  const family = familyName(a);
  return a.name.slice(0, a.name.length - family.length).trim();
}

/** "In Journal of X, 7(3), 1671–1681" style venue line. */
export function venueLine(p: Publication): string {
  return p.details ? `${p.venue}, ${p.details}` : p.venue;
}

/** A plain citation for "Copy citation": authors, title, venue, year, DOI. */
export function citationText(p: Publication): string {
  const names = p.authors.map((a) => a.name);
  const authors =
    names.length === 1 ? names[0] : names.length === 2 ? `${names[0]} and ${names[1]}` : `${names.slice(0, -1).join(", ")}, and ${names.at(-1)}`;
  const where = p.type === "thesis" ? p.venue : venueLine(p);
  const link = p.doi ? ` https://doi.org/${p.doi}` : p.links[0] ? ` ${p.links[0].href}` : "";
  return `${authors}. ${p.title}. ${where} (${p.year}).${link}`;
}

const BIB_TYPE: Record<PubType, string> = {
  "journal-article": "article",
  review: "article",
  "conference-paper": "inproceedings",
  "book-chapter": "incollection",
  thesis: "phdthesis",
};

/** Protect capitals and formulas in titles, and escape the characters BibTeX treats specially. */
function bibText(s: string): string {
  return s
    .replace(/([&%$#_])/g, "\\$1")
    .replace(/\b([A-Za-z]*[A-Z][A-Za-z0-9–-]*[A-Z0-9][A-Za-z0-9–-]*)\b/g, "{$1}");
}

/** "7(3), 1671–1681" → volume, number, pages; "105, 106668" → volume, pages; "pp. 453–477" or "1385103" → pages. */
function bibDetails(details?: string): { volume?: string; number?: string; pages?: string } {
  if (!details) return {};
  const range = (s: string) => s.replace(/–/g, "--");
  const issue = details.match(/^(\d+)\((\d+)\),\s*(\S+)$/);
  if (issue) return { volume: issue[1], number: issue[2], pages: range(issue[3]) };
  const volume = details.match(/^(\d+),\s*(\S+)$/);
  if (volume) return { volume: volume[1], pages: range(volume[2]) };
  const pages = details.match(/^(?:pp\.\s*)?(\S+)$/);
  return pages ? { pages: range(pages[1]) } : {};
}

export function bibKey(p: Publication): string {
  return p.id.replace(/[^a-z0-9]+/gi, "_");
}

export function bibtex(p: Publication): string {
  const venueField =
    p.type === "conference-paper" || p.type === "book-chapter" ? "booktitle" : p.type === "thesis" ? "school" : "journal";
  const fields: Array<[string, string | undefined]> = [
    ["author", p.authors.map((a) => `${familyName(a)}, ${givenNames(a)}`).join(" and ")],
    ["title", bibText(p.title)],
    [venueField, bibText(p.venue)],
    ["volume", bibDetails(p.details).volume],
    ["number", bibDetails(p.details).number],
    ["pages", bibDetails(p.details).pages],
    ["year", String(p.year)],
    ["doi", p.doi],
    ["url", p.doi ? `https://doi.org/${p.doi}` : p.links[0]?.href],
  ];
  const body = fields
    .filter((f): f is [string, string] => Boolean(f[1]))
    .map(([k, v]) => `  ${k} = {${v}}`)
    .join(",\n");
  return `@${BIB_TYPE[p.type]}{${bibKey(p)},\n${body}\n}`;
}
