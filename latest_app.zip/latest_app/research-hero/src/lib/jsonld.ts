import { recognition } from "@/content/about";
import { person } from "@/content/person";
import { publications } from "@/content/publications";
import { SITE_URL, UPDATED } from "@/content/site";
import type { Publication } from "@/content/types";

/*
  Structured data: a profile page whose main entity is the person, and one record per paper linked
  by DOI. Only confirmed facts go in, and the email never does (to limit harvesting; it stays
  visible on the page).
*/

const personId = `${SITE_URL}/#person`;

function paperNode(p: Publication) {
  const type = p.type === "book-chapter" ? "Chapter" : p.type === "thesis" ? "Thesis" : "ScholarlyArticle";
  return {
    "@type": type,
    "@id": p.doi ? `https://doi.org/${p.doi}` : `${SITE_URL}/#pub-${p.id}`,
    url: `${SITE_URL}/#pub-${p.id}`,
    ...(p.doi ? { sameAs: `https://doi.org/${p.doi}` } : {}),
    name: p.title,
    headline: p.title.length > 110 ? `${p.title.slice(0, 107)}…` : p.title,
    author: p.authors.map((a) => (a.me ? { "@id": personId } : { "@type": "Person", name: a.name })),
    datePublished: String(p.year),
    ...(p.type === "thesis"
      ? { inSupportOf: "PhD", sourceOrganization: { "@type": "CollegeOrUniversity", name: "Indian Institute of Science" } }
      : { isPartOf: { "@type": p.type === "book-chapter" ? "Book" : "Periodical", name: p.venue.replace(/ \(.*\)$/, "") } }),
    ...(p.license ? { license: "https://creativecommons.org/licenses/by/4.0/" } : {}),
    description: p.summary,
  };
}

export function structuredData() {
  const sameAs = [
    person.links.orcid.confirmed ? `https://orcid.org/${person.links.orcid.value}` : null,
    person.links.scholar,
    person.links.linkedin.confirmed ? person.links.linkedin.value : null,
  ].filter(Boolean);

  const graph = [
    {
      "@type": "ProfilePage",
      "@id": `${SITE_URL}/#page`,
      url: `${SITE_URL}/`,
      name: person.name,
      dateModified: UPDATED.iso,
      mainEntity: { "@id": personId },
    },
    {
      "@type": "Person",
      "@id": personId,
      name: person.name,
      url: `${SITE_URL}/`,
      description: "Translational scientist working across biomaterials, drug delivery, and photoacoustic and ultrasound imaging.",
      ...(person.now.confirmed
        ? { jobTitle: person.now.value.title, worksFor: { "@type": "Organization", name: person.now.value.org } }
        : {}),
      alumniOf: [
        { "@type": "CollegeOrUniversity", name: "Indian Institute of Science" },
        { "@type": "CollegeOrUniversity", name: "Johns Hopkins University" },
        { "@type": "CollegeOrUniversity", name: "Indian Institute of Information Technology, Allahabad" },
      ],
      knowsAbout: [
        "Nanoparticle drug delivery",
        "Photothermal therapy",
        "Photoacoustic imaging",
        "Ultrasound imaging",
        "Coherence-based beamforming",
      ],
      award: recognition
        .filter((r) => r.kind === "award" && r.title.confirmed)
        .map((r) => (r.context ? `${r.title.value}, ${r.context.split(",")[0]} (${r.when})` : `${r.title.value} (${r.when})`)),
      ...(person.links.orcid.confirmed
        ? { identifier: { "@type": "PropertyValue", propertyID: "ORCID", value: person.links.orcid.value } }
        : {}),
      sameAs,
    },
    ...publications.map(paperNode),
  ];

  // "<" is escaped so no string in the data can close the script element.
  return JSON.stringify({ "@context": "https://schema.org", "@graph": graph }).replace(/</g, "\\u003c");
}
