import type { ReactNode } from "react";

/*
  Line-break care for titles and citations: a hyphenated compound up to the length of "photo-theranostic"
  ("single-pulse", "tissue-mimicking"), one with a short part ("NIR-II", "CuS–Au", "short-lag"), or a number
  range ("1671–1681") never splits across two lines. Longer ones ("polyethyleneimine-functionalized") may
  still break at the hyphen, as English allows, so nothing outruns a phone's column.
*/
const COMPOUND = /[^\s\-–]+(?:[-–][^\s\-–]+)+/g;
const SHORT_PART = 3;
const WHOLE = 17;

function tight(token: string): boolean {
  const parts = token.split(/[-–]/).map((p) => p.replace(/[^A-Za-z0-9]/g, ""));
  return token.length <= WHOLE || parts.every((p) => /^\d+$/.test(p)) || parts.some((p) => p.length <= SHORT_PART);
}

export function keepCompounds(text: string): ReactNode {
  const out: ReactNode[] = [];
  let last = 0;
  for (const m of text.matchAll(COMPOUND)) {
    if (!tight(m[0])) continue;
    out.push(
      text.slice(last, m.index),
      <span key={m.index} className="nowrap">
        {m[0]}
      </span>,
    );
    last = m.index + m[0].length;
  }
  if (out.length === 0) return text;
  out.push(text.slice(last));
  return out;
}
