"use client";

import { useCallback, useEffect, useRef, useState, useSyncExternalStore } from "react";
import type { Framing, LabEngine } from "@/lab/engine";
import { labBus } from "@/lab/bus";
import type { LabState } from "@/lab/state";
import { REDUCED_MOTION_QUERY } from "@/lib/use-media";
import { LabPoster } from "./lab-poster";

/**
 * Where the lab stands. The server HTML is "poster": a rendered still in the lab's frame.
 * - "loading": three.js is on its way, or the engine is being built; the still stays.
 * - "ready": frames are landing and the canvas has faded in over the still.
 * - "declined": the device asks to save data (Data Saver, a 2G connection, under 4 GB of memory), or
 *   the lab failed to load; the still stays, with a button to load the lab.
 * - "unsupported": no WebGL2; the still stays.
 * - "lost": the GPU dropped the WebGL context; back to the still, with a button to load the lab again.
 */
export type LabStatus = "poster" | "loading" | "ready" | "declined" | "unsupported" | "lost";

interface LabCanvasProps {
  /** The lab state the scene should show. */
  state: LabState;
  /** Clicking the scene itself fires a light pulse (or an ultrasound transmit). */
  onPulse?: () => void;
  framing: Framing;
  onEngine: (engine: LabEngine | null) => void;
  onStatus?: (status: LabStatus) => void;
  /** Element whose pointer movement steers the camera and the cursor light. */
  pointerRoot: React.RefObject<HTMLElement | null>;
  className?: string;
}

/** What the button costs: the lazy lab chunk (three.js and the scene), brotli-compressed as served. */
const LAB_SIZE = "about 140 KB";

function isLowPower() {
  const nav = navigator as Navigator & { deviceMemory?: number };
  const coarse = window.matchMedia("(pointer: coarse)").matches;
  const small = Math.min(window.innerWidth, window.innerHeight) < 600;
  return (nav.hardwareConcurrency ?? 8) <= 4 || (nav.deviceMemory ?? 8) <= 4 || (coarse && small);
}

/** Full-bleed WebGL at 2x costs ~2x the fill for little visible gain under bloom and grain. */
const pixelRatio = (lowPower: boolean) => Math.min(window.devicePixelRatio || 1, lowPower ? 1.25 : 1.5);

let webgl2: boolean | undefined;
function supportsWebGL2() {
  if (webgl2 === undefined) {
    try {
      const gl = document.createElement("canvas").getContext("webgl2");
      webgl2 = !!gl;
      gl?.getExtension("WEBGL_lose_context")?.loseContext();
    } catch {
      webgl2 = false;
    }
  }
  return webgl2;
}

/** Signals that the visitor would rather not spend data or memory on 3D: Data Saver, 2G, or under 4 GB. */
function prefersSaving() {
  const nav = navigator as Navigator & { connection?: { saveData?: boolean; effectiveType?: string }; deviceMemory?: number };
  const type = nav.connection?.effectiveType;
  return nav.connection?.saveData === true || type === "2g" || type === "slow-2g" || (nav.deviceMemory !== undefined && nav.deviceMemory < 4);
}

const noSubscribe = () => () => {};

/**
 * Calls `go` once, when the page has loaded, the browser has had an idle moment (or 2 s have passed),
 * and `el` is within one screen of the viewport with scrolling at rest: a link to #publications scrolls
 * smoothly past the lab, and shouldn't load it on the way. Returns a cancel function.
 */
function whenSettledAndNear(el: Element, go: () => void) {
  let idle = 0;
  let timer = 0;
  let near = false;
  let io: IntersectionObserver | undefined;
  const settle = () => {
    window.clearTimeout(timer);
    timer = window.setTimeout(() => {
      if (!near) return;
      stop();
      go();
    }, 150);
  };
  const watch = () => {
    io = new IntersectionObserver(
      (entries) => {
        near = entries.some((e) => e.isIntersecting);
        settle();
      },
      { rootMargin: "100% 0px" },
    );
    io.observe(el);
    window.addEventListener("scroll", settle, { passive: true });
  };
  const loaded = () => {
    if (typeof requestIdleCallback === "function") idle = requestIdleCallback(watch, { timeout: 2000 });
    else timer = window.setTimeout(watch, 200);
  };
  const stop = () => {
    window.removeEventListener("load", loaded);
    window.removeEventListener("scroll", settle);
    if (idle) cancelIdleCallback(idle);
    window.clearTimeout(timer);
    io?.disconnect();
  };
  if (document.readyState === "complete") loaded();
  else window.addEventListener("load", loaded, { once: true });
  return stop;
}

type Phase = "idle" | "loading" | "ready" | "lost" | "failed";

export function LabCanvas({ state, framing, onEngine, onStatus, pointerRoot, className, onPulse }: LabCanvasProps) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<LabEngine | null>(null);
  const framingRef = useRef(framing);
  const stateRef = useRef(state);
  const webgl = useSyncExternalStore(noSubscribe, supportsWebGL2, () => true);
  const saving = useSyncExternalStore(noSubscribe, prefersSaving, () => false);
  const [phase, setPhase] = useState<Phase>("idle");
  // Each start of the engine, on its own or from the button, gets a fresh canvas: a canvas whose
  // context was lost can't be trusted with a new one.
  const [attempt, setAttempt] = useState(0);
  const [asked, setAsked] = useState(false);

  const status: LabStatus = !webgl
    ? "unsupported"
    : phase === "idle"
      ? saving
        ? "declined"
        : "poster"
      : phase === "failed"
        ? "declined"
        : phase;

  useEffect(() => {
    onStatus?.(status);
  }, [status, onStatus]);

  const start = useCallback((byVisitor: boolean) => {
    setAsked(byVisitor);
    setAttempt((n) => (byVisitor ? n + 1 : n || 1));
    setPhase("loading");
  }, []);

  // Load on its own only when nothing argues against it, and only once the page has settled.
  useEffect(() => {
    const wrap = wrapRef.current;
    if (!wrap || !webgl || saving) return;
    return whenSettledAndNear(wrap, () => start(false));
  }, [webgl, saving, start]);

  useEffect(() => {
    const wrap = wrapRef.current;
    const canvas = canvasRef.current;
    if (!attempt || !wrap || !canvas) return;

    let cancelled = false;
    let teardown = () => {};

    const wire = (engine: LabEngine) => {
      engineRef.current = engine;
      const lowPower = isLowPower();
      const measure = () => {
        const r = wrap.getBoundingClientRect();
        engine.setSize(r.width, r.height, pixelRatio(lowPower));
      };
      engine.setFraming(framingRef.current);
      engine.setState(stateRef.current);
      measure();

      const ro = new ResizeObserver(measure);
      ro.observe(wrap);

      let inView = true;
      const syncActive = () => engine.setActive(inView && document.visibilityState === "visible");
      const io = new IntersectionObserver(
        ([entry]) => {
          inView = entry.isIntersecting;
          syncActive();
        },
        { rootMargin: "80px" },
      );
      io.observe(wrap);
      document.addEventListener("visibilitychange", syncActive);

      const root = pointerRoot.current ?? wrap;
      const onMove = (e: PointerEvent) => {
        if (e.pointerType === "touch") return;
        const r = wrap.getBoundingClientRect();
        engine.setPointer(((e.clientX - r.left) / r.width) * 2 - 1, -(((e.clientY - r.top) / r.height) * 2 - 1));
      };
      const onLeave = () => engine.setPointer(0, 0);
      root.addEventListener("pointermove", onMove, { passive: true });
      root.addEventListener("pointerleave", onLeave);

      // Reveal once a few frames have landed, so the fade never shows an empty buffer.
      let shown = false;
      let frames = 0;
      const offFrame = labBus.on("frame", () => {
        if (shown || ++frames < 3) return;
        shown = true;
        setPhase("ready");
        labBus.emit("ready", { at: performance.now() });
      });

      let torn = false;
      teardown = () => {
        if (torn) return;
        torn = true;
        offFrame();
        ro.disconnect();
        io.disconnect();
        document.removeEventListener("visibilitychange", syncActive);
        root.removeEventListener("pointermove", onMove);
        root.removeEventListener("pointerleave", onLeave);
        canvas.removeEventListener("webglcontextlost", onLost);
        onEngine(null);
        engine.dispose();
        engineRef.current = null;
        const w = window as Window & { __lab?: LabEngine };
        if (w.__lab === engine) delete w.__lab;
      };
      // The GPU can drop the context (a driver reset, memory pressure, too many tabs): the still comes
      // back, and the button offers to load the lab again.
      function onLost() {
        teardown();
        setPhase("lost");
      }
      canvas.addEventListener("webglcontextlost", onLost);

      onEngine(engine);
      if (process.env.NODE_ENV !== "production") {
        (window as Window & { __lab?: LabEngine }).__lab = engine;
        import("@/lab/instruments").then((m) => ((window as Window & { __instruments?: unknown }).__instruments = m));
      }
    };

    import("@/lab/engine")
      .then(async ({ LabEngine }) => {
        if (cancelled) return;
        // Read directly (not via props) so hydration never rebuilds the engine.
        const reducedMotion = window.matchMedia(REDUCED_MOTION_QUERY).matches;
        const lowPower = isLowPower();
        const r = wrap.getBoundingClientRect();
        const engine = await LabEngine.create(canvas, {
          reducedMotion,
          lowPower,
          size: { w: r.width, h: r.height, dpr: pixelRatio(lowPower) },
          framing: framingRef.current,
        });
        if (cancelled) engine.dispose();
        else wire(engine);
      })
      .catch(() => {
        if (!cancelled) setPhase("failed");
      });

    return () => {
      cancelled = true;
      teardown();
    };
    // Each attempt builds one engine; framing and state updates flow through the effects below.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [attempt]);

  useEffect(() => {
    framingRef.current = framing;
    engineRef.current?.setFraming(framing);
  }, [framing]);

  useEffect(() => {
    stateRef.current = state;
    engineRef.current?.setState(state);
  }, [state]);

  const ready = status === "ready";
  const offer = status === "declined" || status === "lost" || (asked && status === "loading");
  return (
    <div
      ref={wrapRef}
      /* The window into the lab is dark from first paint, before the poster decodes, in either theme. */
      className={`${className ?? ""} ${ready ? "cursor-crosshair" : ""} bg-(--lab-void)`}
      data-status={status}
      onClick={ready ? onPulse : undefined}
    >
      <div
        aria-hidden
        className="absolute inset-0 bg-[radial-gradient(60%_55%_at_62%_48%,rgb(18_44_52/0.55),transparent_70%)]"
      />
      {/* The still and the canvas share one box, so the hand-over is a crossfade with nothing moving. */}
      <div
        className="absolute inset-0 transition-opacity duration-[1400ms] ease-[var(--ease-out-quint)] data-[on=false]:opacity-0"
        data-on={!ready}
      >
        <LabPoster chapter={state.chapter} active={!ready} lasting={status === "unsupported"} />
      </div>
      <canvas
        key={attempt}
        ref={canvasRef}
        aria-hidden
        className="absolute inset-0 block h-full w-full transition-opacity duration-[1400ms] ease-[var(--ease-out-quint)] data-[on=false]:opacity-0"
        data-on={ready}
      />
      {offer ? (
        <button
          type="button"
          aria-disabled={status === "loading"}
          onClick={(e) => {
            e.stopPropagation();
            if (status !== "loading") start(true);
          }}
          // Centred on the scene's subject, wherever the framing puts it.
          style={{ left: `${framing.focusX * 100}%`, top: `${framing.focusY * 100}%`, transform: "translate(-50%, -50%)" }}
          className="absolute z-10 inline-flex min-h-11 items-center whitespace-nowrap rounded-full border border-hairline bg-glass px-4 text-[0.875rem] font-medium text-bone backdrop-blur-xl outline-none transition-colors hover:bg-white/[0.06] focus-visible:ring-2 focus-visible:ring-echo focus-visible:ring-offset-2 focus-visible:ring-offset-void pointer-fine:min-h-9"
        >
          {status === "loading" ? "Loading the 3D lab…" : status === "lost" ? "Reload the 3D lab" : `Load the 3D lab (${LAB_SIZE})`}
        </button>
      ) : null}
    </div>
  );
}
