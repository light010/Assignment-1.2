"use client";

import { useEffect, useRef, useState } from "react";
import { callouts, type CalloutDef } from "@/content/chapters";
import { labBus, type Anchor } from "@/lab/bus";
import type { LabState } from "@/lab/state";

/** Every anchor any chapter can label; each gets one pinned element. */
const ALL_ANCHORS = [
  "loupe",
  "tumor",
  "probe",
  "core",
  "capping",
  "gel",
  "drug",
  "coat",
  "protein",
  "xCore",
  "xGel",
  "xCoat",
  "leak",
  "rim",
  "tumorCore",
  "artery",
  "vein",
  "skin",
  "lesion",
  "array",
  "screen",
] as const;

/** Closest a label may come to the scene's edge before it flips to the anchor's other side. */
const EDGE = 8;

/**
 * Labels pinned to points in the 3D scene, plus the magnifier's leader lines in the overview.
 * Positions are written straight to the DOM every frame; React only decides which labels show.
 * A label that would run off the scene (a phone, a narrow window) flips to the other side.
 */
export function Callouts({ state, compact }: { state: LabState; compact: boolean }) {
  const [placed, setPlaced] = useState(false);
  const root = useRef<HTMLDivElement>(null);
  const nodes = useRef<Record<string, HTMLDivElement | null>>({});
  const labels = useRef<Record<string, HTMLDivElement | null>>({});
  const widths = useRef<Record<string, number>>({});
  const sceneWidth = useRef(0);
  const sides = useRef<Record<string, "left" | "right">>({});
  const lineA = useRef<SVGLineElement>(null);
  const lineB = useRef<SVGLineElement>(null);
  const ring = useRef<SVGCircleElement>(null);

  const defs = callouts(state);
  const byAnchor = new Map<string, CalloutDef>(defs.map((d) => [d.anchor, d]));
  const showLeaders = state.chapter === "overview";

  // The authored side of each visible label, for the frame loop below.
  useEffect(() => {
    sides.current = Object.fromEntries(defs.map((d) => [d.anchor, d.side]));
  });

  // Label and scene widths, measured only when they change (never inside the frame loop).
  useEffect(() => {
    const ro = new ResizeObserver((entries) => {
      for (const e of entries) {
        const el = e.target as HTMLElement;
        const width = e.borderBoxSize?.[0]?.inlineSize ?? e.contentRect.width;
        if (el === root.current) sceneWidth.current = width;
        else if (el.dataset.anchor) widths.current[el.dataset.anchor] = width;
      }
    });
    if (root.current) ro.observe(root.current);
    for (const name of ALL_ANCHORS) {
      const label = labels.current[name];
      if (label) ro.observe(label);
    }
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    let placedOnce = false;
    return labBus.on("anchors", (a: Record<string, Anchor>) => {
      if (!placedOnce) {
        placedOnce = true;
        setPlaced(true);
      }
      for (const name of ALL_ANCHORS) {
        const el = nodes.current[name];
        const p = a[name];
        if (!el || !p) continue;
        el.style.transform = `translate3d(${p.x.toFixed(1)}px, ${p.y.toFixed(1)}px, 0)`;
        el.dataset.inview = String(p.visible);
        const authored = sides.current[name] ?? "right";
        const w = widths.current[name] ?? 0;
        const side =
          authored === "left" && p.x - w < EDGE ? "right" : authored === "right" && p.x + w > sceneWidth.current - EDGE ? "left" : authored;
        if (el.dataset.side !== side) el.dataset.side = side;
      }
      const center = a.loupe;
      const edge = a.loupeEdge;
      const target = a.zoom;
      if (center && edge && target && lineA.current && lineB.current && ring.current) {
        const R = Math.hypot(edge.x - center.x, edge.y - center.y);
        const dx = target.x - center.x;
        const dy = target.y - center.y;
        const d = Math.hypot(dx, dy);
        if (d > R + 4) {
          const base = Math.atan2(dy, dx);
          const spread = Math.acos(Math.min(1, R / d));
          for (const [line, t] of [
            [lineA.current, base + spread],
            [lineB.current, base - spread],
          ] as const) {
            line.setAttribute("x1", (center.x + Math.cos(t) * R).toFixed(1));
            line.setAttribute("y1", (center.y + Math.sin(t) * R).toFixed(1));
            line.setAttribute("x2", target.x.toFixed(1));
            line.setAttribute("y2", target.y.toFixed(1));
          }
          ring.current.setAttribute("cx", target.x.toFixed(1));
          ring.current.setAttribute("cy", target.y.toFixed(1));
        }
      }
    });
  }, []);

  return (
    <div
      ref={root}
      aria-hidden
      data-placed={placed}
      className="pointer-events-none absolute inset-0 overflow-hidden transition-opacity duration-700 data-[placed=false]:opacity-0"
    >
      <svg className="absolute inset-0 h-full w-full overflow-visible">
        <g className="text-bone transition-opacity duration-500" style={{ opacity: showLeaders ? 1 : 0 }} stroke="currentColor" fill="none">
          <line ref={lineA} strokeOpacity={0.28} strokeWidth={1} strokeDasharray="2 5" />
          <line ref={lineB} strokeOpacity={0.28} strokeWidth={1} strokeDasharray="2 5" />
          <circle ref={ring} r={7} strokeOpacity={0.6} strokeWidth={1} />
        </g>
      </svg>
      {ALL_ANCHORS.map((anchor) => {
        const def = byAnchor.get(anchor);
        const on = !!def && !(compact && defs.length > 2 && anchor === defs[defs.length - 1].anchor);
        return (
          <div
            key={anchor}
            ref={(el) => {
              nodes.current[anchor] = el;
            }}
            data-side={def?.side ?? "right"}
            className="group absolute left-0 top-0 will-change-transform"
          >
            <div
              ref={(el) => {
                labels.current[anchor] = el;
              }}
              data-anchor={anchor}
              data-on={on}
              className="absolute top-0 flex -translate-y-1/2 items-center gap-2 transition-[opacity,filter] duration-500 ease-[var(--ease-out-quint)] group-data-[inview=false]:opacity-0 group-data-[side=left]:right-0 group-data-[side=left]:flex-row-reverse group-data-[side=right]:left-0 group-data-[side=right]:flex-row data-[on=false]:opacity-0 data-[on=false]:blur-[3px]"
            >
              <span className="relative -mx-[3.5px] size-[7px] shrink-0 rounded-full border border-bone/80 bg-void/60" />
              <span className="h-px w-5 bg-bone/40" />
              <span className="font-instrument whitespace-nowrap rounded-full border border-hairline bg-void/60 px-2.5 py-1 text-[0.75rem] font-medium text-bone backdrop-blur-md">
                {def?.text ?? ""}
              </span>
            </div>
          </div>
        );
      })}
    </div>
  );
}
