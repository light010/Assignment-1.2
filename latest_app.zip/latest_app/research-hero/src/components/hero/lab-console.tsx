"use client";

import { AnimatePresence, m } from "framer-motion";
import { Pause, Play, Route, Square } from "lucide-react";
import { LAB_SLUG } from "@/components/site/layout";
import { CHAPTERS, CHAPTER_ORDER, caption, evidence, readouts, type Metrics } from "@/content/chapters";
import type { LabState, SkillChapter } from "@/lab/state";
import { useMedia } from "@/lib/use-media";
import type { LabStatus } from "./lab-canvas";
import { Readouts } from "./readouts";
import { Segmented } from "./segmented";

const press = { type: "spring", stiffness: 420, damping: 26 } as const;
const swap = { duration: 0.32, ease: [0.22, 1, 0.36, 1] } as const;

interface LabConsoleProps {
  state: LabState;
  metrics: Metrics;
  onChapter: (chapter: SkillChapter | "overview") => void;
  onControl: (chapter: SkillChapter, key: string, value: string) => void;
  touring: boolean;
  tourProgress: number;
  onTour: () => void;
  playing: boolean;
  onPlaying: (playing: boolean) => void;
  /** Where the 3D lab stands: pausing only means something once it runs. */
  lab: LabStatus;
  /** The page has hydrated: the tour needs JavaScript, but not the 3D lab (stills stand in). */
  interactive: boolean;
}

/**
 * The lab's console: the four skills (each one a chapter with its own camera, controls,
 * readouts and caption), plus the tour and pause controls.
 */
export function LabConsole(props: LabConsoleProps) {
  const { state, metrics, onChapter, onControl, touring, tourProgress, onTour, playing, onPlaying, lab, interactive } = props;
  // No engine is coming without the visitor asking (or at all): nothing to pause.
  const still = lab === "unsupported" || lab === "declined" || lab === "lost";
  const chapter = state.chapter;
  const active = chapter === "overview" ? null : chapter;
  const text = caption(state, metrics);
  const proof = evidence(state);
  const items = readouts(state, metrics);
  // In forced colors the pressed chapter is painted Highlight (globals.css): its text takes HighlightText.
  const forced = useMedia("(forced-colors: active)");

  return (
    <div className="@container/copy w-full max-w-[36rem]">
      <div
        role="group"
        aria-label="What I do"
        className="grid grid-cols-4 gap-1 rounded-[18px] border border-hairline bg-glass p-1 backdrop-blur-xl @max-[30rem]/copy:grid-cols-2"
      >
        {CHAPTER_ORDER.map((id) => {
          const c = CHAPTERS[id];
          const on = active === id;
          return (
            <m.button
              key={id}
              id={LAB_SLUG[id]}
              type="button"
              aria-pressed={on}
              onClick={() => onChapter(on ? "overview" : id)}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              transition={press}
              className="group relative flex min-h-14 min-w-0 flex-col items-start justify-center gap-0.5 rounded-[14px] px-2.5 py-2 text-left outline-none transition-colors duration-300 focus-visible:ring-2 focus-visible:ring-echo aria-pressed:bg-bone"
            >
              {/* Wraps rather than truncates when a reader widens letter spacing (WCAG 1.4.12). */}
              <span
                className={`max-w-full text-[0.875rem] font-medium leading-tight [overflow-wrap:anywhere] ${forced ? "" : "text-bone group-aria-pressed:text-void"}`}
                style={{ hyphens: "auto", WebkitHyphens: "auto" }}
              >
                {c.label}
              </span>
              <span className={`font-instrument text-micro leading-snug ${forced ? "" : "text-bone-muted group-aria-pressed:text-void/70"}`}>{c.hint}</span>
            </m.button>
          );
        })}
      </div>

      <AnimatePresence mode="wait" initial={false}>
        {active ? (
          <m.div
            key={active}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={swap}
            className="mt-3 flex flex-col gap-2 rounded-[18px] border border-hairline bg-glass p-3 backdrop-blur-xl"
          >
            {CHAPTERS[active].controls.map((ctl) => (
              <Segmented
                key={ctl.key}
                label={ctl.label}
                options={ctl.options}
                value={(state[active] as unknown as Record<string, string>)[ctl.key]}
                onChange={(v) => onControl(active, ctl.key, v)}
              />
            ))}
          </m.div>
        ) : null}
      </AnimatePresence>

      {items.length ? (
        <div className="mt-3">
          <Readouts items={items} />
        </div>
      ) : null}

      <div aria-live="polite" className="mt-4 min-h-[4.5em] px-1 text-caption text-bone-muted">
        <AnimatePresence mode="wait" initial={false}>
          <m.p
            key={text}
            initial={{ opacity: 0, y: 5, filter: "blur(3px)" }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            exit={{ opacity: 0, y: -4, filter: "blur(3px)" }}
            transition={swap}
            className="max-w-[56ch] text-balance"
          >
            {text}
          </m.p>
        </AnimatePresence>
      </div>

      {proof ? (
        <p className="-mt-1 mb-1 px-1 text-caption">
          {proof.external ? (
            <a href={proof.href} className="prose-link inline-flex min-h-11 items-center text-bone-soft outline-none focus-visible:ring-2 focus-visible:ring-echo">
              {proof.label}
            </a>
          ) : (
            // A plain link: on this page the publication list takes it over (it filters in place and moves focus there).
            <a href={proof.href} className="prose-link inline-flex min-h-11 items-center text-bone-soft outline-none focus-visible:ring-2 focus-visible:ring-echo">
              {proof.label}
            </a>
          )}
        </p>
      ) : null}

      <div className="mt-3 flex flex-wrap items-center gap-2 px-0.5">
        <m.button
          type="button"
          onClick={onTour}
          disabled={!interactive}
          aria-pressed={touring}
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
          transition={press}
          className="relative inline-flex min-h-11 items-center gap-2 overflow-hidden rounded-full bg-bone px-5 text-[0.9375rem] font-medium text-void shadow-[0_0_0_1px_rgb(255_255_255/0.2),0_10px_30px_-10px_rgb(143_225_240/0.55)] outline-none focus-visible:ring-2 focus-visible:ring-echo focus-visible:ring-offset-2 focus-visible:ring-offset-void disabled:opacity-60"
        >
          {touring ? (
            <span aria-hidden className="absolute inset-y-0 left-0 bg-echo/35" style={{ width: `${Math.round(tourProgress * 100)}%` }} />
          ) : null}
          {touring ? <Square aria-hidden className="relative size-3.5 fill-void" /> : <Route aria-hidden className="relative size-4" />}
          <span className="relative">{touring ? "Stop the tour" : "Take the tour"}</span>
        </m.button>
        {active ? (
          <m.button
            type="button"
            onClick={() => onChapter("overview")}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            transition={press}
            className="inline-flex min-h-11 items-center rounded-full border border-hairline bg-glass px-4 text-[0.875rem] text-bone-muted backdrop-blur-xl outline-none transition-colors hover:text-bone focus-visible:ring-2 focus-visible:ring-echo"
          >
            Zoom out
          </m.button>
        ) : null}
        {still ? null : (
          <m.button
            type="button"
            onClick={() => onPlaying(!playing)}
            disabled={lab !== "ready"}
            aria-label={playing ? "Pause animation" : "Play animation"}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            transition={press}
            className="inline-flex size-11 items-center justify-center rounded-full border border-hairline bg-glass text-bone-muted backdrop-blur-xl outline-none transition-colors hover:text-bone focus-visible:ring-2 focus-visible:ring-echo disabled:opacity-60"
          >
            {playing ? <Pause aria-hidden className="size-4" /> : <Play aria-hidden className="size-4" />}
          </m.button>
        )}
      </div>
    </div>
  );
}
