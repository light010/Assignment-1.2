"use client";

import { AnimatePresence, m } from "framer-motion";
import { useEffect, useRef } from "react";
import { labBus } from "@/lab/bus";

const fold = { duration: 0.45, ease: [0.22, 1, 0.36, 1] } as const;
/**
 * The fold and the lines' rise clip top and bottom only: widened letter spacing (WCAG 1.4.12) must
 * never cut off the end of a line.
 */
const CLIP_Y = { overflowX: "visible", overflowY: "clip" } as const;

/**
 * The headline hears the scene. When the probe picks up the photoacoustic signal, a pressure
 * wave leaves it and passes through the letters, pushing them apart and together the way a
 * longitudinal wave moves a medium.
 */
export function SoundHeadline({
  lines,
  compact = false,
  originRef,
  reducedMotion,
}: {
  lines: readonly string[];
  /** One sentence per line at a smaller size, while a chapter is open on wide screens. */
  compact?: boolean;
  /** The element the wave's coordinates are relative to (the scene canvas). */
  originRef: React.RefObject<HTMLElement | null>;
  reducedMotion: boolean;
}) {
  const headingRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    if (reducedMotion) return;
    let raf = 0;
    const off = labBus.on("wave", (wave) => {
      const origin = originRef.current?.getBoundingClientRect();
      if (!origin) return;
      const els = Array.from(headingRef.current?.querySelectorAll<HTMLSpanElement>(".sound-letter") ?? []);
      const centers = els.map((el) => {
        const r = el.getBoundingClientRect();
        const dx = r.left + r.width / 2 - origin.left - wave.x;
        const dy = r.top + r.height / 2 - origin.top - wave.y;
        const d = Math.hypot(dx, dy) || 1;
        return { dx: dx / d, dy: dy / d, d };
      });
      const lambda = Math.max(26, (els[0]?.getBoundingClientRect().height ?? 60) * 0.42);
      cancelAnimationFrame(raf);
      const tick = () => {
        const t = (performance.now() - wave.startedAt) / 1000;
        const front = t * wave.speed;
        const env = Math.max(0, 1 - t / 2.8) ** 1.2;
        let busy = false;
        for (let i = 0; i < els.length; i++) {
          const c = centers[i];
          const ph = (c.d - front) / lambda;
          const nw = ph > -5 && ph < 5 ? -ph * Math.exp(-0.5 * ph * ph) : 0;
          const amp = nw * env * 9;
          const el = els[i];
          if (Math.abs(amp) > 0.02) {
            busy = true;
            el.style.transform = `translate3d(${(c.dx * amp).toFixed(2)}px, ${(c.dy * amp * 0.6).toFixed(2)}px, 0)`;
            el.style.setProperty("--p", Math.max(0, nw * env).toFixed(3));
          } else if (el.style.transform) {
            el.style.transform = "";
            el.style.setProperty("--p", "0");
          }
          if (front < c.d + lambda * 5) busy = true;
        }
        if (busy && t < 4) raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    });
    return () => {
      off();
      cancelAnimationFrame(raf);
    };
  }, [originRef, reducedMotion]);

  const text = lines.join(" ");
  const letters = (line: string) =>
    line.split(" ").map((word, wi, arr) => (
      <span key={wi} className="inline-block whitespace-nowrap">
        {Array.from(word).map((ch, ci) => (
          <span key={ci} className="sound-letter inline-block will-change-transform">
            {ch}
          </span>
        ))}
        {wi < arr.length - 1 ? <span className="inline-block">&nbsp;</span> : null}
      </span>
    ));

  // Both sizes fold by height, like the lede, so the console below glides instead of jumping.
  return (
    <h1 ref={headingRef} className="font-display display-optical text-balance font-[380] text-bone">
      <span className="sr-only">{text}</span>
      <AnimatePresence initial={false}>
        <m.span
          key={compact ? "compact" : "full"}
          aria-hidden
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          transition={fold}
          className={`-mb-[0.14em] block pb-[0.14em] ${compact ? "text-hero-compact" : "text-hero wide:[@media(max-height:50rem)]:text-[length:clamp(2.5rem,3.4vw+1rem,4.25rem)]"}`}
          style={CLIP_Y}
        >
          {lines.map((line, li) => (
            <span key={line} className="-mb-[0.14em] block pb-[0.14em] pt-[0.08em]" style={CLIP_Y}>
              {/* The lines rise from behind their own edge once, in CSS, so the headline is in the server
                  HTML and visible at first paint; reduced motion skips the rise. */}
              <span
                className={compact ? "block" : "line-in block"}
                style={compact ? undefined : ({ "--d": `${120 + li * 110}ms` } as React.CSSProperties)}
              >
                {letters(line)}
              </span>
            </span>
          ))}
        </m.span>
      </AnimatePresence>
    </h1>
  );
}
