"use client";

import { useState } from "react";
import { preload } from "react-dom";
import { Picture, type PictureSource } from "@/components/picture";
import { renders, type Render, type RenderId } from "@/content/renders";
import type { Chapter } from "@/lab/state";

/** The full-bleed layout (the `wide` variant in globals.css): the scene fills the hero behind the copy. */
export const WIDE_QUERY = "(min-width: 60rem) and (min-aspect-ratio: 21/20)";
/** Full bleed when wide, the inset card otherwise (D-engineering §2.5). */
const SIZES = `${WIDE_QUERY} 100vw, calc(100vw - 2rem)`;

const STILL: Record<Chapter, RenderId> = {
  overview: "overview",
  design: "design",
  deliver: "delivery",
  photoacoustic: "photoacoustics",
  ultrasound: "ultrasound",
};
const CHAPTER_STILLS: RenderId[] = ["design", "delivery", "photoacoustics", "ultrasound"];

function crops(id: RenderId) {
  const find = (framing: Render["framing"]) => renders.find((r) => r.id === id && r.framing === framing);
  const wide = find("wide");
  const phone = find("phone");
  return wide && phone ? { wide, phone } : null;
}

const srcset = (list: readonly PictureSource[]) => list.map((s) => `${s.src} ${s.w}w`).join(", ");

/**
 * The first paint's phone crop stops at 712 px (2x the card): at 3x the 1068 px file is twice the bytes
 * (about 41 KB against 22 KB AVIF) and lands after the 2 s mark on a slow phone, for detail the 3D lab
 * replaces seconds later. The poster budget (30 KB AVIF) is set for this width too.
 */
const FIRST_PAINT_MAX_W = 712;
const upTo = (sources: Render["sources"], max: number) => ({
  avif: sources.avif.filter((s) => s.w <= max),
  webp: sources.webp.filter((s) => s.w <= max),
});

/** One still, art-directed: the 16:10 crop on the full-bleed layout, the square crop in the phone card. */
function Still({ id, priority = false, full = true }: { id: RenderId; priority?: boolean; full?: boolean }) {
  const found = crops(id);
  if (!found) return null;
  const still = full ? found : { ...found, phone: { ...found.phone, sources: upTo(found.phone.sources, FIRST_PAINT_MAX_W) } };
  if (priority) {
    // The poster is the largest thing on the first screen: fetch it alongside the stylesheet, not after
    // the body is parsed. One hint per crop, each only where its crop applies, AVIF only (browsers
    // without AVIF skip the hint and find the WebP in the <picture>).
    for (const [crop, media] of [
      [still.wide, WIDE_QUERY],
      [still.phone, `not all and ${WIDE_QUERY}`],
    ] as const) {
      preload(crop.sources.avif[0].src, {
        as: "image",
        type: "image/avif",
        imageSrcSet: srcset(crop.sources.avif),
        imageSizes: SIZES,
        fetchPriority: "high",
        media,
      });
    }
  }
  return (
    <Picture
      sources={still.phone.sources}
      width={still.phone.width}
      height={still.phone.height}
      alt=""
      sizes={SIZES}
      art={[{ media: WIDE_QUERY, sources: still.wide.sources, width: still.wide.width, height: still.wide.height }]}
      priority={priority}
      className="absolute inset-0 block h-full w-full"
      style={{ objectFit: "cover" }}
    />
  );
}

/**
 * Rendered stills of the lab, in the lab's own frame. The server HTML shows the overview; until the
 * 3D lab takes over (or where it never does), each chapter shows its own still, fading in over the
 * overview once loaded. The captions carry the meaning, so the stills are decorative.
 */
export function LabPoster({ chapter, active, lasting }: { chapter: Chapter; active: boolean; lasting: boolean }) {
  const target = active ? STILL[chapter] : null;
  const [loaded, setLoaded] = useState<ReadonlySet<RenderId>>(() => new Set());
  return (
    <div aria-hidden className="absolute inset-0">
      {/* Where the still is all there will be (no WebGL2), it gets the sharpest crop once the page is up. */}
      <Still id="overview" priority full={lasting} />
      {CHAPTER_STILLS.filter((id) => id === target || loaded.has(id)).map((id) => (
        <div
          key={id}
          className="absolute inset-0 transition-opacity duration-500 ease-[var(--ease-out-quint)]"
          style={{ opacity: id === target && loaded.has(id) ? 1 : 0 }}
          // `load` doesn't bubble, but React sees it in the capture phase.
          onLoadCapture={() => setLoaded((set) => (set.has(id) ? set : new Set(set).add(id)))}
        >
          <Still id={id} />
        </div>
      ))}
    </div>
  );
}
