"use client";

import type { Readout } from "@/content/chapters";

/** Live instrument readouts, like the lens lab's focus / aperture / sharp-zone chips. */
export function Readouts({ items }: { items: Readout[] }) {
  if (!items.length) return null;
  return (
    <dl className="grid grid-cols-3 gap-1.5">
      {items.map((r) => (
        <div key={r.label} className="rounded-[14px] border border-hairline bg-glass px-3 py-2.5 backdrop-blur-xl">
          <dt className="font-instrument text-pretty text-micro text-bone-muted">{r.label}</dt>
          <dd
            data-tone={r.tone}
            className="font-instrument mt-0.5 text-pretty text-[0.9375rem] leading-snug font-semibold text-bone data-[tone=good]:text-[#8fe8b0] data-[tone=warn]:text-pulse"
          >
            {r.value}
          </dd>
          {r.meter !== undefined ? (
            <div aria-hidden className="relative mt-2 h-1 rounded-full bg-white/[0.08]">
              <div
                className="h-full rounded-full bg-echo transition-[width] duration-500 ease-[var(--ease-out-quint)]"
                style={{ width: `${Math.round(Math.min(1, Math.max(0, r.meter)) * 100)}%` }}
              />
              {r.threshold !== undefined ? (
                <div className="absolute -top-1 h-3 w-px bg-bone/80" style={{ left: `${r.threshold * 100}%` }} />
              ) : null}
            </div>
          ) : null}
        </div>
      ))}
    </dl>
  );
}
