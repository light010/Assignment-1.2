"use client";

import { AnimatePresence, LazyMotion, MotionConfig, m } from "framer-motion";
import { Suspense, lazy, useCallback, useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { CHAPTERS, CHAPTER_ORDER, caption, type Metrics } from "@/content/chapters";
import { profile } from "@/content/profile";
import { labBus } from "@/lab/bus";
import type { Framing, LabEngine } from "@/lab/engine";
import { peekInstrument, requestInstrument } from "@/lab/instrument-client";
import type { PaPicture, UsPicture } from "@/lab/instrument-shared";
import { DEFAULT_STATE, MELANIN, TOUR, type LabState, type SkillChapter } from "@/lab/state";
import { LAB_SLUG } from "@/components/site/layout";
import { useMedia, usePrefersReducedMotion } from "@/lib/use-media";
import { InstrumentPanel } from "./instrument-panel";
import { LabCanvas, type LabStatus } from "./lab-canvas";
import { LabConsole } from "./lab-console";
import { WIDE_QUERY } from "./lab-poster";
import { SoundHeadline } from "./sound-headline";
import { ThemeToggle } from "@/components/site/theme-toggle";

const NARROW_FRAMING: Framing = { focusX: 0.5, focusY: 0.53, usableW: 1.02, usableH: 0.98 };
/**
 * Motion's renderer, animations and gestures arrive in their own chunk after hydration
 * (motion-features.ts). Imported from framer-motion, the package motion/react re-exports: motion/react
 * also binds the full `motion` component at load, which would pull every feature into the first load.
 */
const motionFeatures = () => import("./motion-features").then((mod) => mod.default);
const noSubscribe = () => () => {};
/** Labels pinned to the 3D scene: nothing to pin until the engine runs, so they load with it. */
const loadCallouts = () => import("./callouts");
const Callouts = lazy(() => loadCallouts().then((mod) => ({ default: mod.Callouts })));

/** How long the tour stays on a state: time to read its caption at an easy pace, never under 5 s. */
function dwell(s: LabState) {
  const words = caption(s).split(/\s+/).length;
  return Math.max(5000, 1600 + words * 200);
}

const usRequest = (s: LabState) => ({ kind: "us", lesion: s.ultrasound.lesion, beamformer: s.ultrasound.beamformer }) as const;
const paRequest = (s: LabState) =>
  ({ kind: "pa", map: s.photoacoustic.map, melanin: MELANIN[s.photoacoustic.skin], beamformer: s.photoacoustic.beamformer }) as const;
const usMetrics = (img: UsPicture): Metrics => ({ gcnr: img.gcnr });
const paMetrics = (img: PaPicture): Metrics => ({ visibility: img.visibility, clutter: img.clutter, light: img.light });

/**
 * Numbers the instruments measure from the images they render, computed in the instrument worker. A
 * variant measured before shows its numbers at once; a new one keeps the last numbers until it lands.
 */
function useMetrics(state: LabState): Metrics {
  const [metrics, setMetrics] = useState<Metrics>({});
  const key =
    state.chapter === "ultrasound"
      ? `us:${state.ultrasound.lesion}:${state.ultrasound.beamformer}`
      : state.chapter === "photoacoustic"
        ? `pa:${state.photoacoustic.map}:${state.photoacoustic.skin}:${state.photoacoustic.beamformer}`
        : "";
  useEffect(() => {
    let live = true;
    const measured: Promise<Metrics> = key.startsWith("us")
      ? requestInstrument(usRequest(state)).then(usMetrics)
      : key.startsWith("pa")
        ? requestInstrument(paRequest(state)).then(paMetrics)
        : Promise.resolve({});
    measured.then((m) => live && setMetrics(m)).catch(() => {});
    return () => {
      live = false;
    };
    // The key captures everything the metrics depend on.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
  const cached = key.startsWith("us") ? peekInstrument(usRequest(state)) : key.startsWith("pa") ? peekInstrument(paRequest(state)) : undefined;
  if (!cached) return metrics;
  return "gcnr" in cached ? usMetrics(cached) : paMetrics(cached);
}

/** The lab's state for this tab, so Back from a paper returns to the same view when the page reloads. */
const SAVED = "lab-state";
/** Read once per page load, before the first save overwrites it. */
let saved: LabState | null | undefined;

function savedState(): LabState | null {
  saved ??= readSaved();
  return saved;
}

function readSaved(): LabState | null {
  try {
    const nav = performance.getEntriesByType("navigation")[0] as PerformanceNavigationTiming | undefined;
    if (nav?.type !== "back_forward") return null;
    const entry = JSON.parse(sessionStorage.getItem(SAVED) ?? "null") as LabState | null;
    if (!entry || (entry.chapter !== "overview" && !CHAPTER_ORDER.includes(entry.chapter))) return null;
    // Only a state every control can show: an old or edited entry is ignored.
    for (const id of CHAPTER_ORDER)
      for (const control of CHAPTERS[id].controls) {
        const value = (entry[id] as unknown as Record<string, string> | undefined)?.[control.key];
        if (!control.options.some((o) => o.value === value)) return null;
      }
    return entry;
  } catch {
    return null;
  }
}

/*
  Layout: on narrow screens the section is a single column (name, headline, scene window,
  console, instrument). From 60rem on landscape screens the scene goes full-bleed behind the
  copy and the instrument docks bottom-right; `display: contents` lets one DOM serve both.
*/
export function Hero() {
  const sectionRef = useRef<HTMLElement>(null);
  const sceneRef = useRef<HTMLDivElement>(null);
  const copyRef = useRef<HTMLDivElement>(null);
  const reducedMotion = usePrefersReducedMotion();
  const wide = useMedia(WIDE_QUERY);
  const [engine, setEngine] = useState<LabEngine | null>(null);
  const [state, setState] = useState<LabState>(DEFAULT_STATE);
  const [lab, setLab] = useState<LabStatus>("poster");
  // False in the server HTML and while hydrating; the controls that need JavaScript wait for it.
  const interactive = useSyncExternalStore(
    noSubscribe,
    () => true,
    () => false,
  );
  const [playingEvent, setPlaying] = useState<boolean | null>(null);
  const playing = playingEvent ?? (engine ? engine.isPlaying() : true);
  const [tour, setTour] = useState<{ on: boolean; index: number }>({ on: false, index: 0 });
  const metrics = useMetrics(state);
  const [region, setRegion] = useState({ left: 0.44, right: 1, short: false });

  useEffect(() => {
    if (lab === "loading") void loadCallouts();
  }, [lab]);

  useEffect(() => {
    return labBus.on("playing", ({ playing }) => setPlaying(playing));
  }, []);

  // Frame the scene in whatever width the copy column leaves free, inside the content grid.
  useEffect(() => {
    const copy = copyRef.current;
    const section = sectionRef.current;
    if (!wide || !copy || !section) return;
    const ro = new ResizeObserver(() => {
      const s = section.getBoundingClientRect();
      const c = copy.getBoundingClientRect();
      const gridRight = Math.min(s.width, (s.width + 1440) / 2);
      setRegion({
        left: Math.min(0.5, Math.max(0.2, (c.right - s.left + 24) / s.width)),
        right: Math.min(1, (gridRight + 0.1 * s.width) / s.width),
        short: window.innerHeight < 820,
      });
    });
    ro.observe(copy);
    ro.observe(section);
    return () => ro.disconnect();
  }, [wide]);

  const framing = useMemo<Framing>(
    () =>
      wide
        ? {
            focusX: region.left + (region.right - region.left) * 0.47,
            focusY: region.short ? 0.38 : 0.44,
            usableW: (region.right - region.left) * 0.97,
            usableH: region.short ? 0.7 : 0.8,
          }
        : NARROW_FRAMING,
    [wide, region],
  );

  // Guided tour: walks through the key states, stops the moment the visitor takes over.
  useEffect(() => {
    if (!tour.on) return;
    const id = window.setTimeout(() => {
      if (tour.index + 1 >= TOUR.length) {
        setTour({ on: false, index: 0 });
        setState((s) => ({ ...s, chapter: "overview" }));
      } else {
        setTour({ on: true, index: tour.index + 1 });
        setState((s) => TOUR[tour.index + 1](s));
      }
    }, dwell(state));
    return () => window.clearTimeout(id);
  }, [tour, state]);

  const stopTour = useCallback(() => setTour((t) => (t.on ? { on: false, index: 0 } : t)), []);

  // Back to this page after it was unloaded: pick up where the visitor left the lab (after hydration,
  // so the server HTML still matches). The state is saved for this tab on every change.
  useEffect(() => {
    const restored = savedState();
    if (!restored) return;
    const id = window.setTimeout(() => setState(restored), 0);
    return () => window.clearTimeout(id);
  }, []);
  useEffect(() => {
    try {
      sessionStorage.setItem(SAVED, JSON.stringify(state));
    } catch {
      // Storage can be unavailable (private modes, blocked site data); the lab works without it.
    }
  }, [state]);

  // Chapters have addresses (#lab-ultrasound): links from Research and Publications open them here.
  useEffect(() => {
    const byHash = Object.fromEntries(Object.entries(LAB_SLUG).map(([chapter, slug]) => [slug, chapter as SkillChapter]));
    const open = () => {
      // A malformed escape in the fragment ("#lab-%") is read as it stands rather than thrown.
      let hash = location.hash.slice(1);
      try {
        hash = decodeURIComponent(hash);
      } catch {}
      const chapter = byHash[hash];
      if (!chapter) return;
      stopTour();
      setState((s) => ({ ...s, chapter }));
      // Land on the whole hero, not on the chapter button halfway down it.
      requestAnimationFrame(() => sectionRef.current?.scrollIntoView({ block: "start", behavior: "instant" }));
    };
    open();
    window.addEventListener("hashchange", open);
    return () => window.removeEventListener("hashchange", open);
  }, [stopTour]);
  const toggleTour = () => {
    if (tour.on) stopTour();
    else {
      setTour({ on: true, index: 0 });
      setState((s) => TOUR[0](s));
    }
  };
  const onChapter = (chapter: SkillChapter | "overview") => {
    stopTour();
    setState((s) => ({ ...s, chapter }));
  };
  const onControl = (chapter: SkillChapter, key: string, value: string) => {
    stopTour();
    setState((s) => ({ ...s, chapter, [chapter]: { ...s[chapter], [key]: value } }));
  };

  // Scrolling away: the camera eases back, and on wide screens the copy lifts and fades while the
  // scene sinks and grows a little. Progress is 0 while the hero's top is at the top of the screen and
  // 1 once its bottom is; styles are written once per frame, straight to the DOM.
  const parallax = wide && !reducedMotion;
  useEffect(() => {
    const section = sectionRef.current;
    const scene = sceneRef.current;
    const copy = copyRef.current;
    if (!section || !scene || !copy) return;
    let raf = 0;
    const update = () => {
      raf = 0;
      const r = section.getBoundingClientRect();
      const p = Math.min(1, Math.max(0, -r.top / Math.max(1, r.height)));
      engine?.setScroll(p);
      if (!parallax) return;
      scene.style.transform = p > 0 ? `translateY(${22 * p}%) scale(${1 + 0.06 * p})` : "none";
      copy.style.transform = p > 0 ? `translateY(${-28 * p}%)` : "none";
      copy.style.opacity = String(Math.max(0, 1 - p / 0.55));
    };
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    const ro = new ResizeObserver(onScroll);
    ro.observe(section);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("scroll", onScroll);
      ro.disconnect();
      for (const el of [scene, copy]) el.style.transform = "";
      copy.style.opacity = "";
    };
  }, [parallax, engine]);

  // Wide screens 800 px tall or less (1366x768, 1280x720, 1024x768) tighten the vertical rhythm and the
  // headline a little, so the console and the instrument clear the bottom of the first screen.
  // The page-load rise is CSS (`.enter` in globals.css): it starts at first paint, needs no JavaScript,
  // and reduced motion turns it off. The server HTML never ships these elements hidden.
  const enter = (delayMs: number, risePx = 14) => ({ "--d": `${delayMs}ms`, "--rise": `${risePx}px` }) as React.CSSProperties;
  const inChapter = state.chapter !== "overview";

  return (
    <LazyMotion features={motionFeatures} strict>
      <MotionConfig reducedMotion="user">
      <section
        ref={sectionRef}
        id="top"
        aria-label="Introduction"
        className="lab-pin @container/hero relative isolate flex flex-col overflow-hidden bg-void wide:block wide:min-h-[max(100svh,46rem)]"
      >
        <header className="relative z-20 order-0 mx-auto flex w-full max-w-[90rem] flex-wrap items-center justify-between gap-y-1 px-4 py-3 @min-[40rem]/hero:px-6 wide:px-10 wide:py-6 wide:[@media(max-height:50rem)]:py-4">
          <a
            href="#top"
            style={enter(0, -6)}
            className={`enter inline-flex min-h-11 flex-col justify-center rounded-lg outline-none focus-visible:ring-2 focus-visible:ring-echo focus-visible:ring-offset-4 focus-visible:ring-offset-void`}
          >
            <span className="font-display text-[1.1875rem] leading-tight italic text-bone">{profile.name}</span>
            <span className="text-micro text-bone-muted">{profile.role}</span>
          </a>
          {/* Phones get all four links as a second row: four items don't need a hidden menu. */}
          <nav aria-label="Primary" style={enter(60, -6)} className={`enter -mx-2 w-[calc(100%+1rem)] @min-[40rem]/hero:mx-0 @min-[40rem]/hero:w-auto`}>
            <ul className="flex flex-wrap items-center justify-between @min-[40rem]/hero:justify-end @min-[40rem]/hero:gap-0.5">
              {profile.nav.map((item) => (
                <li key={item.href}>
                  <a
                    href={item.href}
                    className="inline-flex min-h-11 items-center rounded-full px-2 text-[0.9375rem] text-bone-muted outline-none transition-colors duration-200 hover:bg-white/[0.06] hover:text-bone focus-visible:ring-2 focus-visible:ring-echo max-[22.5rem]:px-1.5 max-[22.5rem]:text-[0.8125rem] @min-[40rem]/hero:px-3.5"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
              <li>
                <ThemeToggle style={enter(120, -6)} className="enter @min-[40rem]/hero:ml-1.5" />
              </li>
            </ul>
          </nav>
        </header>

        <div
          ref={sceneRef}
          className="relative z-0 order-2 mx-4 aspect-square overflow-hidden rounded-[22px] border border-hairline @min-[40rem]/hero:mx-6 @min-[40rem]/hero:aspect-[4/3] wide:absolute wide:inset-0 wide:m-0 wide:aspect-auto wide:rounded-none wide:border-0"
        >
          <LabCanvas
            state={state}
            onPulse={() => engine?.pulse()}
            framing={framing}
            onEngine={setEngine}
            onStatus={setLab}
            pointerRoot={sectionRef}
            className="absolute inset-0"
          />
          {lab === "ready" ? (
            <Suspense fallback={null}>
              <Callouts state={state} compact={!wide} />
            </Suspense>
          ) : null}
        </div>

        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 z-[1] hidden bg-[linear-gradient(90deg,var(--color-void)_0%,rgb(6_10_12/0.9)_30%,rgb(6_10_12/0.45)_48%,transparent_64%)] wide:block"
        />
        <div aria-hidden className="pointer-events-none absolute inset-x-0 top-0 z-[1] hidden h-40 bg-gradient-to-b from-void/85 to-transparent wide:block" />
        <div
          aria-hidden
          className="pointer-events-none absolute inset-x-0 bottom-0 z-[1] hidden h-[30%] bg-gradient-to-t from-void via-void/50 to-transparent wide:block"
        />

        <div className="contents wide:pointer-events-none wide:relative wide:z-10 wide:mx-auto wide:flex wide:min-h-[calc(max(100svh,46rem)-6.5rem)] wide:max-w-[90rem] wide:items-center wide:px-10 wide:pb-12 wide:[@media(max-height:50rem)]:pb-6">
          <div ref={copyRef} className="contents wide:flex wide:w-[min(36rem,44vw)] wide:flex-col">
            <div className="pointer-events-auto relative z-10 order-1 px-4 pb-8 pt-8 @min-[40rem]/hero:px-6 wide:p-0">
              <SoundHeadline lines={profile.headline} compact={wide && inChapter} originRef={sceneRef} reducedMotion={reducedMotion} />
              <AnimatePresence initial={false}>
                {!(wide && inChapter) ? (
                  <m.p
                    key="lede"
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
                    className="overflow-hidden"
                  >
                    <span style={enter(200)} className={`enter mt-6 block max-w-[42ch] text-pretty text-lede text-bone-muted wide:mt-7 wide:[@media(max-height:50rem)]:mt-4`}>
                      {profile.lede}
                    </span>
                  </m.p>
                ) : null}
              </AnimatePresence>
            </div>
            <div style={enter(280)} className={`enter pointer-events-auto relative z-10 order-3 px-4 pt-6 @min-[40rem]/hero:px-6 wide:p-0 wide:pt-9 wide:[@media(max-height:50rem)]:pt-5`}>
              <LabConsole
                state={state}
                metrics={metrics}
                onChapter={onChapter}
                onControl={onControl}
                touring={tour.on}
                tourProgress={(tour.index + 1) / TOUR.length}
                onTour={toggleTour}
                playing={playing}
                onPlaying={(p) => engine?.setPlaying(p)}
                lab={lab}
                interactive={interactive}
              />
            </div>
          </div>
        </div>

        <div
          style={enter(360, 18)}
          className={`enter relative z-10 order-4 mx-4 mb-12 mt-8 max-w-[22rem] @min-[40rem]/hero:mx-6 wide:absolute wide:bottom-8 wide:right-[max(2.5rem,calc((100%-90rem)/2+2.5rem))] wide:m-0 wide:w-[clamp(14rem,27vh,19rem)]`}
        >
          <InstrumentPanel state={state} />
        </div>
      </section>
      </MotionConfig>
    </LazyMotion>
  );
}
