"use client";

import { AnimatePresence, m } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { panelInfo } from "@/content/chapters";
import { labBus } from "@/lab/bus";
import { channels, micrograph, photoacoustic, ultrasound } from "@/lab/instrument-client";
import { IMG_H, IMG_W } from "@/lab/instrument-shared";
import { MELANIN, type LabState } from "@/lab/state";

/**
 * The instrument's output for whatever the visitor is looking at: an electron micrograph
 * while designing, a distribution plot while delivering, and the live photoacoustic or
 * ultrasound image (or raw channel data) while imaging.
 */
export function InstrumentPanel({ state, className }: { state: LabState; className?: string }) {
  const info = panelInfo(state);
  const showChart = state.chapter === "deliver";
  return (
    <figure
      className={`@container/panel rounded-[18px] border border-hairline bg-glass p-2.5 shadow-[0_24px_60px_-20px_rgb(0_0_0/0.8)] backdrop-blur-xl ${className ?? ""}`}
    >
      <figcaption className="flex items-center justify-between gap-3 px-1.5 pb-2 pt-0.5">
        <span className="flex min-w-0 items-center gap-2 whitespace-nowrap text-[0.8125rem] font-medium text-bone">
          <span aria-hidden className="size-1.5 shrink-0 rounded-full bg-echo shadow-[0_0_10px_2px_rgb(143_225_240/0.5)]" />
          <AnimatePresence mode="wait" initial={false}>
            <m.span
              key={info.title}
              initial={{ opacity: 0, y: 3 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -3 }}
              transition={{ duration: 0.2 }}
            >
              {info.title}
            </m.span>
          </AnimatePresence>
        </span>
      </figcaption>
      <div className="relative overflow-hidden rounded-[11px] bg-black">
        <div className="aspect-[400/386] w-full" />
        {showChart ? <DeliveryChart state={state} /> : <ImageView state={state} />}
        <div aria-hidden className="pointer-events-none absolute inset-0 rounded-[11px] shadow-[inset_0_0_0_1px_rgb(255_255_255/0.06),inset_0_0_40px_rgb(0_0_0/0.45)]" />
      </div>
      <div className="font-instrument flex flex-wrap items-center gap-x-3.5 gap-y-1 px-1.5 pb-0.5 pt-2 text-micro text-bone-muted">
        {info.legend.map((l) => (
          <span key={l.label} className="flex items-center gap-1.5">
            <span aria-hidden className={`h-1.5 w-3 shrink-0 rounded-full ${l.swatch}`} />
            {l.label}
          </span>
        ))}
        {/* Every picture here is a simulation for explanation, not measured data. */}
        <span className="ml-auto">Simulated</span>
      </div>
    </figure>
  );
}

function imageKey(s: LabState) {
  switch (s.chapter) {
    case "design":
      return `tem:${s.design.step}`;
    case "photoacoustic":
      return `pa:${s.photoacoustic.map}:${s.photoacoustic.skin}:${s.photoacoustic.beamformer}`;
    case "ultrasound":
      return `us:${s.ultrasound.lesion}:${s.ultrasound.beamformer}:${s.ultrasound.view}`;
    default:
      return "overview";
  }
}

function describe(s: LabState) {
  switch (s.chapter) {
    case "design":
      return "Simulated electron micrograph of the particles at this build step.";
    case "photoacoustic":
      return s.photoacoustic.map === "oxygenation"
        ? "Simulated photoacoustic image: oxygenated blood in green and deoxygenated blood in red over an ultrasound image."
        : "Simulated photoacoustic image: the nanoparticles in a hot color scale over an ultrasound image.";
    case "ultrasound":
      return s.ultrasound.view === "echoes"
        ? "Simulated raw echoes: one column per array element, with time running down."
        : `Simulated ${s.ultrasound.beamformer === "coherence" ? "coherence" : "B-mode"} ultrasound image of a ${s.ultrasound.lesion === "cyst" ? "cyst" : "solid mass"}, with lesion and background regions marked.`;
    default:
      return "Simulated photoacoustic image over an ultrasound image: oxygenated blood in green, deoxygenated blood in red, and the nanoparticles in a hot color scale.";
  }
}

/**
 * What the panel shows for a state: the pixels come from the instrument worker, the marks are drawn
 * here. The drawing code loads alongside the first picture, never ahead of it.
 */
async function picture(s: LabState): Promise<(ctx: CanvasRenderingContext2D) => void> {
  const draw = import("@/lab/instrument-draw");
  if (s.chapter === "design") {
    const [film, d] = await Promise.all([micrograph(s.design.step), draw]);
    return (ctx) => d.drawMicrograph(ctx, s.design.step, film, IMG_W, IMG_H);
  }
  if (s.chapter === "ultrasound") {
    const { lesion, beamformer } = s.ultrasound;
    if (s.ultrasound.view === "echoes") {
      const [echoes, d] = await Promise.all([channels(lesion), draw]);
      return (ctx) => d.drawChannelData(ctx, echoes, lesion, beamformer, IMG_W, IMG_H);
    }
    const [img, d] = await Promise.all([ultrasound(lesion, beamformer), draw]);
    return (ctx) => d.drawUltrasound(ctx, img, true);
  }
  const [img, d] = await Promise.all([
    s.chapter === "photoacoustic"
      ? photoacoustic(s.photoacoustic.map, MELANIN[s.photoacoustic.skin], s.photoacoustic.beamformer)
      : photoacoustic("both", 0, "standard"),
    draw,
  ]);
  return (ctx) => d.drawPhotoacoustic(ctx, img);
}

/** Two stacked canvases: the new image is drawn behind, then cross-faded in. */
function ImageView({ state }: { state: LabState }) {
  const a = useRef<HTMLCanvasElement>(null);
  const b = useRef<HTMLCanvasElement>(null);
  const [front, setFront] = useState<0 | 1>(0);
  const [sweep, setSweep] = useState(0);
  const [flash, setFlash] = useState(0);
  const frontRef = useRef<0 | 1>(0);
  const key = imageKey(state);
  const chapter = state.chapter;

  useEffect(() => {
    let live = true;
    let id = 0;
    // The worker computes while the click paints; drawing waits for a frame of its own.
    picture(state)
      .then((paint) => {
        if (!live) return;
        id = window.setTimeout(() => {
          const target = frontRef.current === 0 ? b.current : a.current;
          const ctx = target?.getContext("2d");
          if (!ctx) return;
          ctx.clearRect(0, 0, IMG_W, IMG_H);
          paint(ctx);
          frontRef.current = frontRef.current === 0 ? 1 : 0;
          setFront(frontRef.current);
        }, 16);
      })
      .catch(() => {});
    return () => {
      live = false;
      window.clearTimeout(id);
    };
    // The key captures everything the picture depends on.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  useEffect(() => {
    const offs = [
      labBus.on("ultrasound", () => setSweep((n) => n + 1)),
      labBus.on("laser", () => setFlash((n) => n + 1)),
    ];
    return () => offs.forEach((off) => off());
  }, []);

  const label = describe(state);
  const layer = (i: 0 | 1) => ({
    width: IMG_W,
    height: IMG_H,
    role: front === i ? "img" : undefined,
    "aria-label": front === i ? label : undefined,
    "aria-hidden": front === i ? undefined : true,
    className: "absolute inset-0 block h-full w-full transition-opacity duration-500 ease-[var(--ease-out-quint)]",
    style: { opacity: front === i ? 1 : 0 },
  });
  return (
    <>
      <canvas ref={a} {...layer(0)} />
      <canvas ref={b} {...layer(1)} />
      {chapter === "ultrasound" && state.ultrasound.view === "image" && sweep > 0 ? (
        <span
          key={`sweep-${sweep}`}
          aria-hidden
          className="scan-sweep pointer-events-none absolute inset-y-0 left-0 w-7 bg-gradient-to-r from-transparent to-echo/60"
        />
      ) : null}
      {(chapter === "photoacoustic" || chapter === "overview") && flash > 0 ? (
        <span key={`flash-${flash}`} aria-hidden className="scan-flash pointer-events-none absolute inset-0 bg-pulse/25 mix-blend-screen" />
      ) : null}
    </>
  );
}

/* ---------- delivery: where each kind of particle ends up ---------- */

const W = 400;
const H = 386;
const X0 = 34;
const X1 = 382;
const Y0 = 300;
const Y1 = 64;

function curve(kind: "large" | "ultrasmall" | "gel" | "released", s: LabState) {
  const t = s.deliver.elapsed;
  const time = t === "minutes" ? 0.3 : 1;
  const wash = kind === "ultrasmall" && t === "day" ? 0.22 : 1;
  const f = (x: number) => {
    switch (kind) {
      case "large":
        return 0.95 * Math.exp(-x / 0.12);
      case "ultrasmall":
        return 0.48 * (0.55 + 0.45 * Math.exp(-x / 0.55));
      case "gel":
        return 0.9 * Math.exp(-x / 0.16);
      case "released":
        return 0.62 * (0.45 + 0.55 * Math.exp(-x / 0.7));
    }
  };
  const pts: string[] = [];
  for (let i = 0; i <= 60; i++) {
    const x = i / 60;
    const y = f(x) * time * wash;
    pts.push(`${(X0 + x * (X1 - X0)).toFixed(1)},${(Y0 - y * (Y0 - Y1)).toFixed(1)}`);
  }
  return pts;
}

function DeliveryChart({ state }: { state: LabState }) {
  const sel = state.deliver.particle;
  const released = sel === "gel" && state.deliver.light === "continuous";
  const kinds = [
    { id: "large", color: "#b9c2c8" },
    { id: "ultrasmall", color: "#ffad62" },
    { id: "gel", color: "#6aa8ff" },
  ] as const;
  const selected = kinds.find((k) => k.id === sel)!;
  const selPts = curve(sel, state);
  const area = `M${X0},${Y0} L${selPts.join(" L")} L${X1},${Y0} Z`;
  const relPts = curve("released", state);
  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      role="img"
      aria-label={`Simulated chart of how far each kind of particle reaches from the vessel toward the tumor center. Selected: ${sel === "gel" ? "gel carrier" : `${sel} particles`}${released ? ", with drug released by heat" : ""}.`}
      className="absolute inset-0 h-full w-full"
    >
      <defs>
        <linearGradient id="deliver-fill" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor={selected.color} stopOpacity="0.32" />
          <stop offset="1" stopColor={selected.color} stopOpacity="0" />
        </linearGradient>
        <linearGradient id="deliver-depth" x1="0" x2="1" y1="0" y2="0">
          <stop offset="0" stopColor="#ef7b8d" stopOpacity="0.22" />
          <stop offset="1" stopColor="#8a5cf6" stopOpacity="0.22" />
        </linearGradient>
      </defs>
      <rect x={X0} y={Y0 + 16} width={X1 - X0} height="6" rx="3" fill="url(#deliver-depth)" />
      {[0.25, 0.5, 0.75].map((g) => (
        <line key={g} x1={X0} x2={X1} y1={Y0 - g * (Y0 - Y1)} y2={Y0 - g * (Y0 - Y1)} stroke="rgb(236 231 223 / 0.07)" />
      ))}
      <line x1={X0} x2={X1} y1={Y0} y2={Y0} stroke="rgb(236 231 223 / 0.3)" />
      <line x1={X0} x2={X0} y1={Y1 - 10} y2={Y0} stroke="rgb(236 231 223 / 0.3)" />
      <m.path d={area} fill="url(#deliver-fill)" initial={false} animate={{ d: area }} transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }} />
      {kinds.map((k) => {
        const pts = curve(k.id, state);
        const d = `M${pts.join(" L")}`;
        const on = k.id === sel;
        return (
          <m.path
            key={k.id}
            initial={false}
            animate={{ d, opacity: on ? 1 : 0.28 }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            fill="none"
            stroke={k.color}
            strokeWidth={on ? 3 : 1.5}
            strokeLinecap="round"
          />
        );
      })}
      <m.path
        initial={false}
        animate={{ d: `M${relPts.join(" L")}`, opacity: released ? 1 : 0, pathLength: released ? 1 : 0 }}
        transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
        fill="none"
        stroke="#ff5c4a"
        strokeWidth={2.5}
        strokeDasharray="6 5"
      />
      <text x={X0} y={Y0 + 40} className="fill-bone-muted" fontSize="14">
        Vessel
      </text>
      <text x={X1} y={Y0 + 40} textAnchor="end" className="fill-bone-muted" fontSize="14">
        Tumor center
      </text>
      <text x={X0 + 8} y={Y1 - 18} className="fill-bone-muted" fontSize="14">
        Particles
      </text>
      {released ? (
        <text x={X1} y={Y1 - 18} textAnchor="end" fill="#ff8a78" fontSize="14">
          Drug released by heat
        </text>
      ) : null}
    </svg>
  );
}
