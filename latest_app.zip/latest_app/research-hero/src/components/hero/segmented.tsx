"use client";

import { m } from "framer-motion";
import { useId, useRef } from "react";
import { useMedia } from "@/lib/use-media";

const press = { type: "spring", stiffness: 420, damping: 30 } as const;

/**
 * A labelled radio group drawn as a segmented control (the lens lab's control language).
 * Arrow keys move the choice; the thumb glides to the chosen option.
 */
export function Segmented({
  label,
  options,
  value,
  onChange,
}: {
  label: string;
  options: ReadonlyArray<{ value: string; label: string }>;
  value: string;
  onChange: (value: string) => void;
}) {
  const id = useId();
  const refs = useRef<Array<HTMLButtonElement | null>>([]);
  // In forced colors the checked option is painted Highlight (globals.css); the bone thumb would cover it.
  const forced = useMedia("(forced-colors: active)");
  const index = Math.max(0, options.findIndex((o) => o.value === value));

  const onKeyDown = (e: React.KeyboardEvent) => {
    let next = -1;
    if (e.key === "ArrowRight" || e.key === "ArrowDown") next = (index + 1) % options.length;
    if (e.key === "ArrowLeft" || e.key === "ArrowUp") next = (index - 1 + options.length) % options.length;
    if (next < 0) return;
    e.preventDefault();
    onChange(options[next].value);
    refs.current[next]?.focus();
  };

  return (
    <div className="grid grid-cols-[5.5rem_1fr] items-center gap-3 @max-[26rem]/copy:grid-cols-1 @max-[26rem]/copy:gap-1.5">
      <span id={id} className="font-instrument text-micro text-bone-muted">
        {label}
      </span>
      <div
        role="radiogroup"
        aria-labelledby={id}
        onKeyDown={onKeyDown}
        className="relative flex rounded-full border border-hairline bg-white/[0.03] p-1"
      >
        {options.map((o, i) => {
          const checked = i === index;
          return (
            <button
              key={o.value}
              ref={(el) => {
                refs.current[i] = el;
              }}
              type="button"
              role="radio"
              aria-checked={checked}
              tabIndex={checked ? 0 : -1}
              onClick={() => onChange(o.value)}
              className="relative z-10 min-h-9 flex-1 rounded-full pointer-coarse:min-h-11 px-3 text-[0.8125rem] font-medium text-bone-muted outline-none transition-colors duration-200 hover:text-bone focus-visible:ring-2 focus-visible:ring-echo aria-checked:text-void"
            >
              {checked && !forced ? (
                <m.span
                  layoutId={`thumb-${id}`}
                  transition={press}
                  className="absolute inset-0 -z-10 rounded-full bg-bone shadow-[0_4px_16px_-6px_rgb(236_231_223/0.5)]"
                />
              ) : null}
              <span className="relative whitespace-nowrap">{o.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
