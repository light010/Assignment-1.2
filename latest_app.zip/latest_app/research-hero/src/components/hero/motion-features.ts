import { domMax } from "framer-motion";

/*
  Motion's renderer, animations, gestures and layout animation (the segmented thumbs glide with
  `layoutId`, which needs domMax), loaded in their own chunk once the hero has hydrated. Until they
  arrive, the hero's `m` components render in their resting state; nothing waits on them.
*/
export default domMax;
