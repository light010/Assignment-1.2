"use client";

import { useSearchParams } from "next/navigation";
import { Suspense, useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, type KeyboardEvent, type ReactNode } from "react";
import { UI } from "@/content/ui";
import { Rolling } from "./rolling";

export type ShowValue = "all" | "delivery" | "imaging" | "first-author";
export type SortValue = "newest" | "cited";

interface Option<T extends string> {
  value: T;
  label: string;
  count?: number;
  /** The topic mark shown with the option, so the filter doubles as the legend for the rows' marks. */
  glyph?: "d" | "p";
}

const SORTS: Array<Option<SortValue>> = [
  { value: "newest", label: UI.publications.sortOptions.newest },
  { value: "cited", label: UI.publications.sortOptions.cited },
];

/** Rows shown before "Show all" where the list doesn't scroll in its panel. */
const PHONE_ROWS = 5;
/**
 * Where the list scrolls inside its panel: wide and tall enough, with a fine pointer. Everywhere else (phones,
 * landscape phones, touch tablets) it shows five rows and "Show all", so a finger never gets caught in a box.
 * The same query as in globals.css.
 */
const WIDE = "(min-width: 48rem) and (min-height: 40rem) and (pointer: fine)";
/** How much of the first row that doesn't fit stays in view: its year and the first line of its title. */
const PEEK = 56;

const isWide = () => matchMedia(WIDE).matches;
/** From 80rem the Google Scholar panel stands beside the list, and the list's panel matches its height. */
const BESIDE = "(min-width: 80rem)";

/** Motion that answers the controls (MASTER.md, "Motion"): skipped entirely when the reader asks for less. */
const moving = () => !matchMedia("(prefers-reduced-motion: reduce)").matches;
const SETTLE = "cubic-bezier(0.22, 1, 0.36, 1)";

/** The list's height limit, measured from the same CSS value (--limit on .pub-scroll) the stylesheet uses. */
function limit(el: HTMLElement): number {
  const probe = document.createElement("div");
  probe.style.cssText = "position:absolute;visibility:hidden;height:var(--limit)";
  el.append(probe);
  const height = probe.offsetHeight;
  probe.remove();
  return height;
}

const matches = (row: HTMLElement, show: ShowValue) =>
  show === "all" ||
  (show === "first-author" ? row.hasAttribute("data-first") : (row.dataset.themes ?? "").split(" ").includes(show));

/** A fragment can hold a malformed escape ("#pub-100%"): read it as it stands rather than fail. */
function decode(text: string): string {
  try {
    return decodeURIComponent(text);
  } catch {
    return text;
  }
}

/** The paper row the address points at (#pub-{id}), if it's in this list. */
function linkedRow(list: HTMLElement | null): HTMLElement | null {
  const id = decode(location.hash.slice(1));
  if (!id.startsWith("pub-")) return null;
  const row = document.getElementById(id);
  return row && list?.contains(row) ? row : null;
}

/** Where the browser supports it, hidden things stay findable (hidden="until-found"): find-in-page opens them. */
const findable = () => "onbeforematch" in document.body;

/**
 * Opens or closes one row's panel: the summary, authors, role, links, and Cite. Closed panels ship as
 * data-closed, which globals.css hides only where scripts run, so without JavaScript every row is open.
 */
function setOpen(row: HTMLElement, open: boolean) {
  const toggle = row.querySelector<HTMLButtonElement>(".pub-toggle");
  const panel = toggle ? document.getElementById(toggle.getAttribute("aria-controls") ?? "") : null;
  if (!toggle || !panel) return;
  toggle.setAttribute("aria-expanded", String(open));
  panel.removeAttribute("hidden");
  panel.removeAttribute("data-closed");
  panel.inert = false;
  if (open) return;
  if (findable()) panel.setAttribute("hidden", "until-found");
  else panel.setAttribute("data-closed", "");
}

/** Hides a row past the first five, keeping it findable where the browser can; or shows it. */
function setOver(row: HTMLElement, over: boolean) {
  if (!over) {
    row.removeAttribute("data-over");
    if (row.getAttribute("hidden") === "until-found") row.removeAttribute("hidden");
  } else if (findable()) row.setAttribute("hidden", "until-found");
  else row.setAttribute("data-over", "");
}

/** Reads ?show= and ?sort= through the router, so the list follows the address, including Back and Forward. */
function AddressState({ onChange }: { onChange: (show: string | null, sort: string | null) => void }) {
  const params = useSearchParams();
  const show = params.get("show");
  const sort = params.get("sort");
  useEffect(() => onChange(show, sort), [show, sort, onChange]);
  return null;
}

/** A keyboard radio group in the lab's segmented style: arrows, Home, and End move the choice and the focus. */
function Segmented<T extends string>({
  id,
  label,
  options,
  value,
  onChoose,
  wide = false,
}: {
  id: string;
  label: string;
  options: Array<Option<T>>;
  value: T;
  onChoose: (next: T) => void;
  /** Phones lay the options out two by two, the full width of the column. */
  wide?: boolean;
}) {
  const refs = useRef<Array<HTMLButtonElement | null>>([]);
  const group = useRef<HTMLDivElement>(null);
  const chosen = useRef(value);
  // The thumb glides to the chosen option, placed from the option's box. It jumps (no glide) the first time and when
  // the control's size changes (fonts, wrapping, the window), and glides when the choice changes.
  const [thumb, setThumb] = useState<{ x: number; y: number; w: number; h: number; r: string; jump: boolean } | null>(null);
  const place = useCallback(
    (jump: boolean) => {
      const el = refs.current[options.findIndex((o) => o.value === chosen.current)];
      if (!el || el.offsetParent === null) return;
      // A pill's radius computes to something enormous ("infinity" px): any radius past half its height is the same.
      const r = `${Math.min(9999, parseFloat(getComputedStyle(el).borderTopLeftRadius) || 0)}px`;
      setThumb((t) => ({ x: el.offsetLeft, y: el.offsetTop, w: el.offsetWidth, h: el.offsetHeight, r, jump: jump || !t }));
    },
    [options],
  );
  useLayoutEffect(() => {
    chosen.current = value;
    place(false);
  }, [value, place]);
  useEffect(() => {
    // Created once, and its first report (made on attaching) skipped: the layout effect has just placed the thumb,
    // and a second placement as a jump would cancel the glide.
    let attached = false;
    const ro = new ResizeObserver(() => {
      if (attached) place(true);
      attached = true;
    });
    if (group.current) ro.observe(group.current);
    return () => ro.disconnect();
  }, [place]);
  const onKeyDown = (e: KeyboardEvent) => {
    const index = options.findIndex((o) => o.value === value);
    const steps: Record<string, number> = { ArrowRight: index + 1, ArrowDown: index + 1, ArrowLeft: index - 1, ArrowUp: index - 1, Home: 0, End: options.length - 1 };
    const next = steps[e.key];
    if (next === undefined) return;
    e.preventDefault();
    const i = (next + options.length) % options.length;
    onChoose(options[i].value);
    refs.current[i]?.focus();
  };
  const layout = wide ? "grid w-full grid-cols-2 rounded-[var(--radius-cell)] sm:inline-flex sm:w-auto sm:rounded-full" : "inline-flex rounded-full";
  // The copy lays its options out as the group does (written out whole: Tailwind only makes classes it can read).
  const inkLayout = wide ? "grid grid-cols-2 sm:flex" : "flex";
  const shape = wide ? "rounded-[10px] sm:rounded-full" : "rounded-full";
  const option = "inline-flex min-h-11 items-center justify-center gap-2 px-4 text-[0.875rem] font-medium whitespace-nowrap pointer-fine:min-h-9";
  const face = (o: Option<T>) => (
    <>
      {o.glyph ? <span aria-hidden className="glyph" data-g={o.glyph} /> : null}
      {/* One text node with its space ("Delivery 6"), so no browser drops it from the name. */}
      <span>
        {o.count === undefined ? o.label : `${o.label} `}
        {o.count === undefined ? null : <span className="font-instrument opacity-80">{o.count}</span>}
      </span>
    </>
  );
  const at = thumb
    ? ({ "--x": `${thumb.x}px`, "--y": `${thumb.y}px`, "--w": `${thumb.w}px`, "--h": `${thumb.h}px`, "--r": thumb.r } as React.CSSProperties)
    : undefined;
  return (
    <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
      <span id={id} className="font-instrument text-label text-bone-muted">
        {label}
      </span>
      <div
        ref={group}
        role="radiogroup"
        aria-labelledby={id}
        onKeyDown={onKeyDown}
        data-thumb={thumb ? "" : undefined}
        data-jump={thumb?.jump ? "" : undefined}
        className={`${layout} relative gap-1 border border-line-control p-1`}
      >
        {thumb ? <span aria-hidden className={`seg-thumb ${shape}`} style={at} /> : null}
        {options.map((o, i) => {
          const checked = o.value === value;
          return (
            <button
              key={o.value}
              ref={(el) => {
                refs.current[i] = el;
              }}
              type="button"
              role="radio"
              aria-checked={checked}
              tabIndex={checked ? 0 : -1}
              onClick={() => onChoose(o.value)}
              className={`${option} ${shape} text-bone-soft outline-none transition-colors duration-150 hover:text-bone focus-visible:ring-2 focus-visible:ring-echo focus-visible:ring-offset-2 focus-visible:ring-offset-void aria-checked:bg-bone aria-checked:text-void`}
            >
              {face(o)}
            </button>
          );
        })}
        {/* The options again, in void, clipped to the thumb (globals.css, .seg-ink): drawing only, the words drawn by
            CSS (data-t), so no checker reads dark words on the ink where the clip never shows them. */}
        {thumb ? (
          <span aria-hidden className={`seg-ink ${inkLayout} gap-1 p-1`} style={at}>
            {options.map((o) => (
              <span key={o.value} className={`${option} ${shape}`}>
                {o.glyph ? <span className="glyph" data-g={o.glyph} /> : null}
                <span>
                  <span data-t={o.count === undefined ? o.label : `${o.label} `} />
                  {o.count === undefined ? null : <span data-t={String(o.count)} className="font-instrument opacity-80" />}
                </span>
              </span>
            ))}
          </span>
        ) : null}
      </div>
    </div>
  );
}

/**
 * The publication list's behavior, around rows rendered on the server: Show (a filter) above the list and Sort
 * (an order) in its header, both kept in the address; on wide screens a height limit with a fade at whichever
 * edge has more, and elsewhere five rows, each with a button to see everything; rows that open in place; links
 * to one paper (#pub-{id}) that clear whatever hides it, open it, and bring it into view; and in-page links that
 * filter the list (a Research card's, the lab's), which move focus and say what changed. Without JavaScript
 * the whole list is there, open.
 */
export function PublicationBrowser({
  options,
  total,
  footer,
  children,
}: {
  options: Array<Option<ShowValue>>;
  total: number;
  footer: ReactNode;
  children: ReactNode;
}) {
  const values = useMemo(() => options.map((o) => o.value), [options]);
  const [show, setShow] = useState<ShowValue>("all");
  const [sort, setSort] = useState<SortValue>("newest");
  const [all, setAll] = useState(false);
  // Until measured, the common case: a wide screen and more rows than fit.
  const [wide, setWide] = useState(true);
  const [more, setMore] = useState(true);
  const [shown, setShown] = useState(total);
  const [message, setMessage] = useState("");
  const [landing, setLanding] = useState(0);
  const region = useRef<HTMLDivElement>(null);
  const list = useRef<HTMLOListElement>(null);
  const button = useRef<HTMLButtonElement>(null);
  const order = useRef<HTMLElement[] | null>(null);
  const target = useRef<HTMLElement | null>(null);
  const focusNext = useRef<HTMLElement | null>(null);
  const arrived = useRef(false);
  // The height limit is fitted to the rows only once the reader has used the list: fitting it on load would
  // move everything below the list after the page has been laid out.
  const fitted = useRef(false);
  // Where the shown rows were, how tall the list was, the order, and where the Scholar panel stood, just before a
  // change (so the change can glide from there); the glides now running (a new change takes over from them); how many
  // folds and Cite eases are running (measuring waits for them); and a count of changes, so a fold that ends after
  // one doesn't scroll the list back to its row.
  const before = useRef<{ tops: Map<HTMLElement, number>; height: number; sort: SortValue; scholar: number | null } | null>(null);
  const glides = useRef<Animation[]>([]);
  const busy = useRef(0);
  const changes = useRef(0);
  const state = useRef({ show, sort });
  useLayoutEffect(() => {
    state.current = { show, sort };
  });

  const rows = () => (order.current ??= Array.from(list.current?.children ?? []) as HTMLElement[]);

  /**
   * Notes where everything is on screen before Show, Sort, or the list's length changes, so the change can glide from
   * there, then stops the glides still running: the new ones start from these places, measured without them.
   */
  const snapshot = useCallback(() => {
    changes.current += 1;
    const el = region.current;
    if (!el || !moving()) return;
    const tops = new Map<HTMLElement, number>();
    for (const row of list.current?.children ?? []) {
      const box = row.getBoundingClientRect();
      if (box.height > 0) tops.set(row as HTMLElement, box.top);
    }
    const scholar = el.closest(".pub-layout")?.querySelector<HTMLElement>(":scope > .scholar");
    before.current = { tops, height: el.offsetHeight, sort: state.current.sort, scholar: scholar ? scholar.getBoundingClientRect().top : null };
    for (const glide of glides.current) glide.cancel();
    glides.current = [];
  }, []);
  const visibleRows = useCallback(
    () => (Array.from(list.current?.children ?? []) as HTMLElement[]).filter((r) => matches(r, show)),
    [show],
  );

  /** Fades at the edges that have more to scroll (where the list scrolls in its panel). */
  const fade = useCallback(() => {
    const el = region.current;
    if (!el) return;
    const scrolls = isWide() && el.scrollHeight > el.clientHeight + 1;
    el.toggleAttribute("data-above", scrolls && el.scrollTop > 2);
    el.toggleAttribute("data-below", scrolls && el.scrollTop + el.clientHeight < el.scrollHeight - 2);
  }, []);

  /**
   * After any change to what the list shows: which rows repeat the year above them, which rows wait behind
   * "Show all", where the height limit falls, whether the button has anything to do, and the fades.
   */
  const measure = useCallback(() => {
    const el = region.current;
    const ol = list.current;
    if (!el || !ol) return;
    const visible = visibleRows();
    const w = isWide();
    setWide(w);
    setShown(visible.length);

    // In year order, a year already given above is dimmed, so the column reads as a timeline.
    let year = "";
    for (const row of visible) {
      row.toggleAttribute("data-same-year", sort === "newest" && row.dataset.year === year);
      year = row.dataset.year ?? "";
    }

    // Five rows where the list doesn't scroll; the rest stay findable (find-in-page shows them all).
    for (const row of rows()) setOver(row, !w && !all && matches(row, show) && visible.indexOf(row) >= PHONE_ROWS);

    if (w && !all && fitted.current) {
      // The limit cuts into a row, never between two (a list cut at a gap looks finished), and goes
      // entirely when less than a row would stay hidden.
      const height = ol.scrollHeight;
      const max = limit(el);
      const cut = visible.find((r) => r.offsetTop + r.offsetHeight > max);
      const last = visible.at(-1);
      let cap = cut ? Math.min(max, cut.offsetTop + PEEK) : height;
      if (!cut || !last || height - cap < last.offsetHeight) cap = height;
      el.style.setProperty("--cap", cap >= height ? "none" : `${Math.round(cap)}px`);
    } else {
      el.style.removeProperty("--cap");
    }

    // Beside the Google Scholar panel, the list's panel is as tall as it (the two share their edges): the list
    // fills what the panel leaves under its header, as long as the panel still fits on the screen under the
    // section bar (on a short laptop screen the Scholar panel runs on below instead). Measured without the fill,
    // so the list can shrink back.
    el.style.removeProperty("--fill");
    const scholar = w && !all && matchMedia(BESIDE).matches ? el.closest(".pub-layout")?.querySelector<HTMLElement>(":scope > .scholar") : null;
    const head = el.previousElementSibling as HTMLElement | null;
    if (scholar && head) {
      const fill = scholar.offsetHeight - head.offsetHeight;
      const room = innerHeight - head.offsetHeight - 88;
      if (fill > el.offsetHeight + 1 && fill <= room) el.style.setProperty("--fill", `${fill}px`);
    }

    if (w) setMore(all ? ol.scrollHeight > limit(el) + PEEK : el.scrollHeight > el.clientHeight + 1);
    else setMore(visible.length > PHONE_ROWS);
    fade();
  }, [show, sort, all, fade, visibleRows]);

  // The latest measure, for work that finishes after a later render (a fold, a Cite panel easing open).
  const measureRef = useRef(measure);
  useLayoutEffect(() => {
    measureRef.current = measure;
  });

  /** Brings a linked paper into view once the list has settled: the list's top at the top of the screen, the paper first in it. */
  const land = (row: HTMLElement) => {
    setOpen(row, true);
    target.current = row;
    if (!isWide()) setAll(true);
    setLanding((n) => n + 1);
  };

  const fromAddress = useCallback(
    (s: string | null, o: string | null) => {
      let next: ShowValue = s && values.includes(s as ShowValue) ? (s as ShowValue) : "all";
      const row = linkedRow(region.current);
      // A link to one paper wins over a filter in the same address that would hide it.
      if (row && !matches(row, next)) {
        next = "all";
        const url = new URL(location.href);
        url.searchParams.delete("show");
        history.replaceState(null, "", url);
      }
      const order: SortValue = o === "cited" ? "cited" : "newest";
      // Back and Forward glide like the controls do; arriving doesn't.
      if (arrived.current && (next !== state.current.show || order !== state.current.sort)) snapshot();
      setShow(next);
      setSort(order);
      // Arriving with a link to one paper: land on it once. Later changes to the address come from the controls.
      if (row && !arrived.current) land(row);
      arrived.current = true;
    },
    [values, snapshot],
  );

  /** Says how many papers a filter shows: "6 of 15 publications." */
  const announceCount = useCallback(
    (value: ShowValue) => setMessage(`${UI.publications.count(options.find((o) => o.value === value)?.count ?? total, total)}.`),
    [options, total],
  );

  const write = (nextShow: ShowValue, nextSort: SortValue) => {
    const url = new URL(location.href);
    if (nextShow === "all") url.searchParams.delete("show");
    else url.searchParams.set("show", nextShow);
    if (nextSort === "newest") url.searchParams.delete("sort");
    else url.searchParams.set("sort", nextSort);
    url.hash = "publications";
    // null, not history.state: given its own marker back, the router skips the update to useSearchParams.
    history.replaceState(null, "", url);
  };

  const chooseShow = (next: ShowValue) => {
    fitted.current = true;
    if (next !== show) snapshot();
    setShow(next);
    write(next, sort);
    announceCount(next);
  };

  const chooseSort = (next: SortValue) => {
    fitted.current = true;
    if (next !== sort) snapshot();
    setSort(next);
    write(show, next);
    setMessage(UI.publications.sorted[next]);
  };

  // Mark the list ready (the stylesheet's own five-row rule steps aside) and measure before the first paint.
  useLayoutEffect(() => {
    region.current?.setAttribute("data-ready", "");
  }, []);

  // Order: the server sends newest first; "Most cited" moves the same nodes (a stable sort, so ties stay newest first).
  useLayoutEffect(() => {
    const ol = list.current;
    if (!ol) return;
    const want = [...rows()];
    if (sort === "cited") want.sort((a, b) => Number(b.dataset.cited ?? 0) - Number(a.dataset.cited ?? 0));
    if (want.every((row, i) => ol.children[i] === row)) return;
    // moveBefore keeps focus and state where it exists; appendChild everywhere else.
    const moveBefore = (ol as HTMLOListElement & { moveBefore?: (node: Node, child: Node | null) => void }).moveBefore;
    for (const row of want) {
      try {
        if (moveBefore) moveBefore.call(ol, row, null);
        else ol.appendChild(row);
      } catch {
        ol.appendChild(row);
      }
    }
    // A new order starts from its first row.
    if (region.current) region.current.scrollTop = 0;
  }, [sort]);

  // After any change: measure; move focus where "Show all" asked; then finish a pending link to one paper.
  useLayoutEffect(() => {
    measure();
    const next = focusNext.current;
    if (next) {
      focusNext.current = null;
      next.focus();
    }
    const row = target.current;
    if (!row) return;
    target.current = null;
    requestAnimationFrame(() => {
      const el = region.current;
      if (!el) return;
      if (el.scrollHeight > el.clientHeight + 1) {
        // The list scrolls in its panel: the panel's top at the top of the screen, the paper first in it.
        el.scrollIntoView({ block: "start" });
        el.scrollTop += row.getBoundingClientRect().top - el.getBoundingClientRect().top - 8;
      } else {
        row.scrollIntoView({ block: "start" });
      }
      fade();
    });
  }, [measure, fade, sort, landing]);

  // A change glides from where things were (snapshot). Rows that stay and move a short way slide to their new places,
  // over the others; rows that arrive, or would travel far, are uncovered in place (opaque, so no two titles ever
  // show through each other). The list's height eases to its new one unless it shrinks by more than half a screen
  // (then it simply takes it, and what the reader was using stays in view). After "Most cited", each "Cited by" bar
  // in view runs out to its count; the Scholar panel glides to where the list's new length puts it.
  useLayoutEffect(() => {
    const was = before.current;
    before.current = null;
    const el = region.current;
    if (!was || !el) return;
    const add = (a: Animation) => glides.current.push(a);
    const reach = Math.min(260, innerHeight / 2);
    let arriving = 0;
    // In the new order, top to bottom, so rows are uncovered from the top of the list down.
    for (const row of Array.from(list.current?.children ?? []) as HTMLElement[]) {
      const box = row.getBoundingClientRect();
      if (box.height === 0 || box.bottom < 0 || box.top > innerHeight) continue;
      const from = was.tops.get(row);
      const dy = from === undefined ? 0 : from - box.top;
      if (from !== undefined && Math.abs(dy) <= reach) {
        if (Math.abs(dy) > 1)
          add(row.animate([{ translate: `0 ${dy}px`, zIndex: 1 }, { translate: "0 0", zIndex: 1 }], { duration: 480, easing: SETTLE }));
      } else {
        add(
          row.animate([{ clipPath: "inset(0 0 100% 0)", translate: `0 ${Math.sign(dy) * 12}px` }, { clipPath: "inset(0 0 0 0)", translate: "0 0" }], {
            duration: 380,
            delay: 20 + Math.min(arriving++, 6) * 35,
            easing: SETTLE,
            fill: "backwards",
          }),
        );
      }
    }
    const height = el.offsetHeight;
    if (Math.abs(was.height - height) > 1 && was.height - height < innerHeight / 2) {
      // A list that doesn't scroll in its panel would spill its rows while it eases: clip it until it's done.
      const spills = getComputedStyle(el).overflowY === "visible";
      if (spills) el.style.overflow = "clip";
      const ease = el.animate(
        [
          { height: `${was.height}px`, maxHeight: "none" },
          { height: `${height}px`, maxHeight: "none" },
        ],
        { duration: 480, easing: SETTLE },
      );
      ease.onfinish = ease.oncancel = () => {
        if (spills) el.style.overflow = "";
      };
      add(ease);
    }
    if (sort === "cited" && was.sort !== "cited") {
      let j = 0;
      for (const cites of el.querySelectorAll<HTMLElement>(".pub-cites")) {
        const box = cites.getBoundingClientRect();
        if (box.height === 0 || box.bottom < 0 || box.top > innerHeight) continue;
        add(cites.animate([{ "--k": 0 }, { "--k": 1 }], { duration: 900, delay: 250 + Math.min(j++, 8) * 60, easing: SETTLE, fill: "backwards" }));
      }
    }
    const scholar = el.closest(".pub-layout")?.querySelector<HTMLElement>(":scope > .scholar");
    if (scholar && was.scholar !== null) {
      const dy = was.scholar - scholar.getBoundingClientRect().top;
      if (Math.abs(dy) > 1) add(scholar.animate([{ translate: `0 ${dy}px` }, { translate: "0 0" }], { duration: 520, easing: SETTLE }));
    }
  }, [show, sort, all]);

  // Closed rows become hidden="until-found" where the browser supports it, so find-in-page and text-fragment
  // links open the row that holds the match (and "Show all", when the match is past the first five). Size changes
  // (a row opening) re-measure; a Cite panel that opens is brought into view inside the list.
  useEffect(() => {
    const el = region.current;
    if (!el) return;
    if (findable())
      for (const panel of el.querySelectorAll(".pub-more[data-closed]")) {
        panel.setAttribute("hidden", "until-found");
        panel.removeAttribute("data-closed");
      }
    const onMatch = (e: Event) => {
      const found = e.target as HTMLElement;
      if (found.classList.contains("pub-row")) {
        fitted.current = true;
        setAll(true);
      } else el.querySelector(`[aria-controls="${found.id}"]`)?.setAttribute("aria-expanded", "true");
    };
    // A Cite panel eases open (where the browser can animate a disclosure): measuring waits for it, and it is brought
    // into view once it has its full height.
    const onToggle = (e: Event) => {
      const details = e.target as HTMLDetailsElement;
      busy.current += 1;
      const settle = () => {
        window.clearTimeout(timer);
        details.removeEventListener("transitionend", settle);
        busy.current = Math.max(0, busy.current - 1);
        measureRef.current();
        if (details.open) details.scrollIntoView({ block: "nearest", behavior: moving() ? "smooth" : "auto" });
      };
      const timer = window.setTimeout(settle, moving() ? 450 : 0);
      details.addEventListener("transitionend", settle);
    };
    el.addEventListener("beforematch", onMatch, true);
    el.addEventListener("toggle", onToggle, true);
    // The rows' own size (a row opening, a reflow); the window's size sets the limit and the mode.
    const ro = new ResizeObserver(() => {
      if (!busy.current) measure();
    });
    if (list.current) ro.observe(list.current);
    window.addEventListener("resize", measure);
    return () => {
      el.removeEventListener("beforematch", onMatch, true);
      el.removeEventListener("toggle", onToggle, true);
      ro.disconnect();
      window.removeEventListener("resize", measure);
    };
  }, [measure]);

  // A later link to one paper (#pub-{id} while here) does the same as arriving with one.
  useEffect(() => {
    const onHash = () => {
      const row = linkedRow(region.current);
      if (!row) return;
      if (region.current && !matches(row, (region.current.dataset.show as ShowValue) ?? "all")) {
        setShow("all");
        const url = new URL(location.href);
        url.searchParams.delete("show");
        history.replaceState(null, "", url);
      }
      land(row);
    };
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  // In-page links that filter the list ("See the imaging papers", the lab's "See the papers behind this") are
  // plain links; here they change the address in place (keeping the order unless they set one), bring
  // Publications into view, move focus to its heading, and say how many papers show.
  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      const link = (e.target as Element | null)?.closest?.<HTMLAnchorElement>("a[href]");
      if (!link || link.target) return;
      const url = new URL(link.href);
      if (url.origin !== location.origin || url.pathname !== location.pathname || url.hash !== "#publications") return;
      if (!url.searchParams.has("show") && !url.searchParams.has("sort")) return;
      e.preventDefault();
      const next = new URL(location.href);
      const requested = url.searchParams.get("show");
      const value: ShowValue = requested && values.includes(requested as ShowValue) ? (requested as ShowValue) : "all";
      if (value === "all") next.searchParams.delete("show");
      else next.searchParams.set("show", value);
      const order = url.searchParams.get("sort");
      if (order) next.searchParams.set("sort", order);
      next.hash = "publications";
      // A new entry, as a link makes; null so the router follows it (useSearchParams, Back and Forward).
      history.pushState(null, "", next);
      fitted.current = true;
      if (value !== state.current.show) snapshot();
      setShow(value);
      announceCount(value);
      document.getElementById("publications")?.scrollIntoView({ block: "start" });
      document.getElementById("publications-title")?.focus({ preventScroll: true });
    };
    document.addEventListener("click", onClick);
    return () => document.removeEventListener("click", onClick);
  }, [values, announceCount, snapshot]);

  // Rows open in place, and an opened row is brought into view inside the list (clear of the fades).
  // Opening eases the panel down and fades it in; closing folds it away a little faster, then hides it.
  const onRowClick = (e: React.MouseEvent) => {
    const toggle = (e.target as HTMLElement).closest<HTMLButtonElement>(".pub-toggle");
    const row = toggle?.closest<HTMLElement>(".pub-row");
    if (!toggle || !row) return;
    const open = toggle.getAttribute("aria-expanded") !== "true";
    fitted.current = true;
    const panel = document.getElementById(toggle.getAttribute("aria-controls") ?? "");
    if (!panel || !moving()) {
      setOpen(row, open);
      if (open) requestAnimationFrame(() => row.scrollIntoView({ block: "nearest" }));
      return;
    }
    // Pressed again mid-fold: carry on from where the panel is, rather than snapping it open or shut first.
    const midway = panel.getAnimations().length ? panel.getBoundingClientRect().height : null;
    for (const running of panel.getAnimations()) running.cancel();
    const from = midway ?? (open ? 0 : panel.offsetHeight);
    // A closing panel is still drawn while it folds: inert keeps Tab from wandering into it.
    panel.inert = !open;
    if (open) setOpen(row, true);
    else toggle.setAttribute("aria-expanded", "false");
    const to = open ? panel.offsetHeight : 0;
    const change = changes.current;
    busy.current += 1;
    panel.style.overflow = "clip";
    const fold = panel.animate(
      [
        { height: `${from}px`, opacity: open ? 0 : 1 },
        { height: `${to}px`, opacity: open ? 1 : 0 },
      ],
      // A closing panel holds its folded state until it is hidden, so it never flashes open for a frame.
      { duration: open ? 420 : 260, easing: open ? SETTLE : "cubic-bezier(0.4, 0, 0.6, 1)", fill: open ? "none" : "forwards" },
    );
    const done = () => {
      busy.current = Math.max(0, busy.current - 1);
      panel.style.overflow = "";
    };
    fold.oncancel = done;
    fold.onfinish = () => {
      fold.oncancel = null;
      done();
      if (!open) {
        setOpen(row, false);
        fold.cancel();
      }
      // The list's limit may move now the row has its size: the latest measure (the filter may have changed meanwhile),
      // and the list eases to its new height.
      const el = region.current;
      const height = el?.offsetHeight ?? 0;
      measureRef.current();
      if (el && Math.abs(el.offsetHeight - height) > 1) {
        glides.current.push(el.animate([{ height: `${height}px`, maxHeight: "none" }, { height: `${el.offsetHeight}px`, maxHeight: "none" }], { duration: 320, easing: SETTLE }));
      }
      // Unless the list has changed since (a new order starts from its first row), bring the opened row into view.
      if (open && change === changes.current) row.scrollIntoView({ block: "nearest", behavior: "smooth" });
    };
  };

  // "Show all" (phones) or "Show the whole list" (wide screens) moves focus to the first paper it reveals;
  // "Show fewer" and "Collapse the list" keep focus on the button and keep it in view.
  const toggleAll = () => {
    fitted.current = true;
    snapshot();
    const el = region.current;
    if (!all && el) {
      const visible = visibleRows();
      const first = wide
        ? visible.find((r) => r.offsetTop + r.offsetHeight > el.scrollTop + el.clientHeight)
        : visible[PHONE_ROWS];
      focusNext.current = first?.querySelector<HTMLElement>("h3 a") ?? null;
    }
    setAll(!all);
    if (all) requestAnimationFrame(() => button.current?.scrollIntoView({ block: "nearest" }));
  };

  return (
    <>
      <Suspense fallback={null}>
        <AddressState onChange={fromAddress} />
      </Suspense>
      <div data-needs-js data-print="hide" className="mt-10">
        <Segmented id="show-label" label={UI.publications.show} options={options} value={show} onChoose={chooseShow} wide />
        <p role="status" className="sr-only">
          {message}
        </p>
      </div>

      <div className="pub-panel mt-4" data-reveal>
        <div className="panel-head">
          <p>
            <Rolling value={shown} />
            {UI.publications.count(shown, total).slice(String(shown).length)}
          </p>
          <div data-needs-js data-print="hide">
            <Segmented id="sort-label" label={UI.publications.sort} options={SORTS} value={sort} onChoose={chooseSort} />
          </div>
        </div>
        <div
          id="publication-list"
          ref={region}
          role="region"
          aria-label={UI.publications.list}
          data-show={show}
          data-all={all ? "" : undefined}
          className="pub-scroll"
          onScroll={fade}
          onClick={onRowClick}
        >
          <ol ref={list} className="pub-list">
            {children}
          </ol>
        </div>
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-x-6 gap-y-2">
        {more ? (
          <button ref={button} type="button" data-needs-js aria-controls="publication-list" aria-expanded={all} onClick={toggleAll} className="pill font-medium">
            {wide ? (all ? UI.publications.collapseList : UI.publications.expandList) : all ? UI.publications.showFewer : UI.publications.showAll(shown)}
          </button>
        ) : null}
        {footer}
      </div>
    </>
  );
}
