import type { ResearchDirection } from "@/content/types";

/*
  One small diagram per research direction, drawn from the lab's own physics so each card reads as a door into
  its chapter: the particle built in layers; a light pulse turning into sound; a transmitted pulse and its
  echoes. Hue is data, as everywhere: pulse orange is light and heat, echo cyan is sound. They are pictograms,
  not measurements, so they carry no "Simulated" label; the card's words carry the meaning (aria-hidden).
  When a card is first scrolled to, its diagram plays its physics once (.fig-* in globals.css): the particle is built
  (cores, then the gel around them, the drug, the membrane coat last) and smaller copies follow it in; a light pulse
  flashes before the sound it launches; echoes return later, and fainter, from deeper. Rested on or tapped, it plays
  again without erasing anything: the particle heats, its gel tightens, and the drug moves out; a bright copy runs
  along each trace.
*/

const W = 288;
const H = 72;
const BASE = 44;

/**
 * A wave drawn as one smooth hump per half-cycle (a quadratic curve each), so a path stays a few dozen
 * characters instead of a hundred sampled points. `envelope` sets each hump's height from its position (0..1).
 */
function wave(x0: number, width: number, halfCycles: number, amp: number, envelope: (t: number) => number) {
  const step = width / halfCycles;
  let d = `M${x0} ${BASE}`;
  for (let i = 0; i < halfCycles; i++) {
    const xs = x0 + i * step;
    const height = amp * envelope((i + 0.5) / halfCycles) * (i % 2 === 0 ? 1 : -1);
    // A quadratic's peak sits halfway to its control point, so the control goes twice as far.
    d += `Q${(xs + step / 2).toFixed(1)} ${(BASE - 2 * height).toFixed(1)} ${(xs + step).toFixed(1)} ${BASE}`;
  }
  return d;
}

/** A pulse under a Gaussian envelope: the transmitted burst and its echoes. */
const wavelet = (x0: number, width: number, amp: number, cycles: number) =>
  wave(x0, width, Math.round(cycles * 2), amp, (t) => Math.exp(-(((t - 0.5) / 0.28) ** 2)));

/** A ringing that decays: the pressure wave a light pulse launches. */
const ringdown = (x0: number, width: number, amp: number, cycles: number) =>
  wave(x0, width, Math.round(cycles * 2), amp, (t) => Math.exp(-3.2 * t));

const CORES: Array<[number, number]> = [
  [-6, -6],
  [6, -5],
  [0, 4],
  [-9, 5],
  [9, 6],
];
/** Drug beside the cores: where each sits, and which way it goes when the heated gel squeezes it out. */
const DRUG: Array<[x: number, y: number, out: string]> = [
  [-2, -13, "0 -6px"],
  [13, -2, "6px -1px"],
  [-14, -3, "-6px -1px"],
];

/** The particle: light-absorbing cores in a heat-responsive gel, drug beside them, and a dotted membrane coat. */
function Particle({ parts = false }: { parts?: boolean }) {
  const is = (name: string) => (parts ? name : undefined);
  return (
    <>
      <circle r="30" fill="none" stroke="var(--color-bone)" strokeOpacity="0.45" strokeWidth="1.25" strokeDasharray="1.5 3.5" className={is("fig-coat")} />
      <circle
        r="22"
        fill="var(--color-pulse)"
        fillOpacity="0.1"
        stroke="var(--color-pulse)"
        strokeOpacity="0.55"
        strokeWidth="1.25"
        pathLength={parts ? 1 : undefined}
        className={is("fig-ring")}
      />
      {CORES.map(([cx, cy], i) => (
        <circle
          key={`${cx},${cy}`}
          cx={cx}
          cy={cy}
          r="3.2"
          fill="var(--color-pulse)"
          className={is("fig-part")}
          style={parts ? ({ "--at": `${150 + i * 60}ms` } as React.CSSProperties) : undefined}
        />
      ))}
      {DRUG.map(([cx, cy, out]) => (
        <circle
          key={`${cx},${cy}`}
          cx={cx}
          cy={cy}
          r="1.3"
          fill="var(--color-bone)"
          fillOpacity="0.7"
          className={is("fig-drug")}
          style={parts ? ({ "--at": "800ms", "--out": out } as React.CSSProperties) : undefined}
        />
      ))}
    </>
  );
}

/** Smaller copies of the particle, further in: where each sits, its size, and how faint. */
const COPIES: Array<[x: number, y: number, scale: number, opacity: number]> = [
  [110, 44, 0.5, 0.7],
  [160, 28, 0.32, 0.5],
  [198, 46, 0.22, 0.35],
];

/** The ultrasound pulse and its echoes: x, width, amplitude, cycles, opacity, and when each is drawn (ms), later with depth. */
const ECHOES: Array<[number, number, number, number, number, number]> = [
  [4, 44, 26, 3, 1, 150],
  [118, 36, 13, 2.5, 0.8, 650],
  [196, 30, 7, 2, 0.55, 900],
  [252, 24, 3.5, 2, 0.35, 1100],
];

/** A trace and its bright copy, which runs along it when the diagram plays again. */
function Trace({ d, opacity, style }: { d: string; opacity?: number; style?: React.CSSProperties }) {
  return (
    <>
      <path d={d} pathLength={1} fill="none" stroke="var(--color-echo)" strokeOpacity={opacity} strokeWidth="1.5" strokeLinejoin="round" className="fig-trace" style={style} />
      <path d={d} pathLength={1} fill="none" stroke="var(--color-echo)" strokeWidth="1.75" strokeLinejoin="round" className="fig-glint" style={style} />
    </>
  );
}

export function DirectionFigure({ id }: { id: ResearchDirection["id"] }) {
  return (
    <svg aria-hidden viewBox={`0 0 ${W} ${H}`} className="fig block h-16 w-auto max-w-full overflow-visible" preserveAspectRatio="xMinYMid meet">
      {id === "delivery" ? (
        <>
          <symbol id="direction-particle" overflow="visible">
            <Particle />
          </symbol>
          <g transform="translate(36 36)">
            <Particle parts />
          </g>
          {COPIES.map(([x, y, scale, opacity], i) => (
            <use
              key={x}
              href="#direction-particle"
              transform={`translate(${x} ${y}) scale(${scale})`}
              opacity={opacity}
              className="fig-particle"
              style={{ "--i": i } as React.CSSProperties}
            />
          ))}
        </>
      ) : (
        <path d={`M0 ${BASE}H${W}`} stroke="var(--color-bone)" strokeOpacity="0.18" strokeWidth="1" />
      )}
      {id === "photoacoustic" ? (
        <>
          {/* The light pulse, then the sound it launches. */}
          <rect x="8" y="12" width="5" height={BASE - 12} rx="1" fill="var(--color-pulse)" className="fig-light" />
          <Trace d={ringdown(24, 264, 24, 6.5)} />
        </>
      ) : null}
      {id === "ultrasound"
        ? /* The transmitted pulse, then fainter echoes from deeper and deeper, each arriving later (--at). */
          ECHOES.map(([x, width, amp, cycles, opacity, at]) => (
            <Trace key={x} d={wavelet(x, width, amp, cycles)} opacity={opacity} style={{ "--at": `${at}ms`, "--dur": "450ms" } as React.CSSProperties} />
          ))
        : null}
    </svg>
  );
}
