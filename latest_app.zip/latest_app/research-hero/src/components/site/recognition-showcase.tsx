"use client";

import { ChevronLeft, ChevronRight } from "lucide-react";
import { useEffect, useLayoutEffect, useRef, useState, type KeyboardEvent, type PointerEvent } from "react";
import { Picture, type PictureSource } from "@/components/picture";
import { UI } from "@/content/ui";
import { usePrefersReducedMotion } from "@/lib/use-media";
import { Rolling } from "./rolling";

/** The picture change: a scan line crosses the panel and leaves the new picture behind (MASTER.md, "Motion"). */
const WIPE = { duration: 750, easing: "cubic-bezier(0.65, 0, 0.35, 1)" };

export interface ShowcaseMedia {
  /** "photo": the owner's picture of the moment; "still": a lab still of the work it recognizes. */
  kind: "photo" | "still";
  sources: { avif: readonly PictureSource[]; webp: readonly PictureSource[] };
  width: number;
  height: number;
  alt: string;
  /** "Photo: …" for a photo; for a still, how it relates to the item. */
  caption: string;
  /** Where the crop keeps its subject, as CSS object-position ("50% 50%" when unset). */
  focus?: string;
}

export interface ShowcaseItem {
  id: string;
  when: string;
  kind: string;
  title: string;
  context?: string;
  media: ShowcaseMedia | null;
}

/** "Leadership committee, Women in Molecular Imaging Network" → the network large, the role small. */
function plateLines(title: string) {
  const i = title.indexOf(", ");
  return i > 0 ? { large: title.slice(i + 2), small: title.slice(0, i) } : { large: title, small: "" };
}

/**
 * The item's picture, or its typographic plate. The parent sizes it (3:2) and is a size container. The plate
 * leaves out its kind and date where the text beside it already says them (the phone cards).
 */

/*
  A drawn mark for an item without a picture, in the diagrams' stroke language (never a stand-in photo):
  a small constellation for the network, a lattice for materials engineering. Quiet plate art in bone, so
  it prints as ink on the paper theme's white plates. Each mark is defined once (PlateDefs, below the
  showcase root) and used by reference on the wide plate and the phone card, so it ships once.
*/
const MARK: Record<string, { ref: string; box: string }> = {
  "wimin-committee": { ref: "#pm-net", box: "0 0 96 96" },
  "iisc-symposium-2023": { ref: "#pm-lat", box: "0 0 104 96" },
};
function PlateMark({ id }: { id: string }) {
  const mark = MARK[id];
  if (!mark) return null;
  return (
    <svg aria-hidden viewBox={mark.box} className="plate-mark">
      <use href={mark.ref} />
    </svg>
  );
}
function PlateDefs() {
  return (
    <svg aria-hidden width="0" height="0" className="absolute">
      <defs>
        <g id="pm-net" fill="none" stroke="currentColor" strokeWidth="1.5">
          <g strokeOpacity="0.4">
            <line x1="16" y1="64" x2="28" y2="42" />
            <line x1="28" y1="42" x2="44" y2="22" />
            <line x1="44" y1="22" x2="78" y2="40" />
            <line x1="78" y1="40" x2="60" y2="76" />
            <line x1="60" y1="76" x2="16" y2="64" />
            <line x1="28" y1="42" x2="60" y2="76" />
          </g>
          <g strokeOpacity="0.75">
            <circle cx="44" cy="22" r="5" />
            <circle cx="78" cy="40" r="3.5" />
            <circle cx="60" cy="76" r="5" />
            <circle cx="28" cy="42" r="2.5" />
          </g>
          <circle cx="16" cy="64" r="3.5" fill="currentColor" fillOpacity="0.8" stroke="none" />
        </g>
        <g id="pm-lat" fill="none" stroke="currentColor" strokeWidth="1.5">
          <g strokeOpacity="0.4">
            <polygon points="45.0,16.5 45.0,31.5 32.0,39.0 19.0,31.5 19.0,16.5 32.0,9.0" />
            <polygon points="73.0,16.5 73.0,31.5 60.0,39.0 47.0,31.5 47.0,16.5 60.0,9.0" />
            <polygon points="59.0,40.5 59.0,55.5 46.0,63.0 33.0,55.5 33.0,40.5 46.0,33.0" />
            <polygon points="87.0,40.5 87.0,55.5 74.0,63.0 61.0,55.5 61.0,40.5 74.0,33.0" />
            <polygon points="45.0,64.5 45.0,79.5 32.0,87.0 19.0,79.5 19.0,64.5 32.0,57.0" />
            <polygon points="73.0,64.5 73.0,79.5 60.0,87.0 47.0,79.5 47.0,64.5 60.0,57.0" />
          </g>
          <circle cx="46" cy="48" r="3" fill="currentColor" fillOpacity="0.8" stroke="none" />
        </g>
      </defs>
    </svg>
  );
}

function Media({ item, sizes, meta = true, eager = false }: { item: ShowcaseItem; sizes: string; meta?: boolean; eager?: boolean }) {
  if (item.media)
    return (
      <Picture
        sources={item.media.sources}
        width={item.media.width}
        height={item.media.height}
        alt={item.media.alt}
        sizes={sizes}
        eager={eager}
        className="size-full object-cover"
        style={{ objectPosition: item.media.focus ?? "50% 50%" }}
      />
    );
  const plate = plateLines(item.title);
  return (
    <div className="relative flex size-full flex-col p-[max(1.25rem,5cqi)]">
      <PlateMark id={item.id} />
      {meta ? (
        <p className="flex items-baseline justify-between gap-4 font-instrument text-label text-bone-muted">
          <span>{item.kind}</span>
          <span>{item.when}</span>
        </p>
      ) : null}
      {/* The title holds the plate's center, as set type, not a caption left in a corner. */}
      <div className="my-auto py-[5cqi]">
        <p className="font-display text-[clamp(1.25rem,6.6cqi,3.25rem)] leading-[1.08] tracking-[-0.012em] text-balance font-[380] text-bone">
          {plate.large}
        </p>
        {plate.small ? <p className="mt-3 text-small text-bone-soft">{plate.small}</p> : null}
      </div>
    </div>
  );
}

/** Under the picture: where it came from. */
function Provenance({ media }: { media: ShowcaseMedia | null }) {
  return (
    <>
      <span className="text-pretty">{media?.caption}</span>
      {media?.kind === "still" ? <span className="shrink-0 font-instrument text-label">{UI.recognition.simulated}</span> : null}
    </>
  );
}

/**
 * Recognition and service: every item listed, and one picture panel that follows the chosen one, the way
 * choosing a chapter in the lab above changes the scene. The list is a set of tabs (arrow keys move between
 * them); Previous and Next step through in order, and on a touch screen the picture can be swiped. Nothing
 * moves on its own. An item without a picture gets a typographic plate, never a stand-in photo. On phones the
 * list and panel become a rail of cards, each with its own picture, so the section stays within a screen.
 */
export function RecognitionShowcase({ items, sizes }: { items: ShowcaseItem[]; sizes: string }) {
  const [active, setActive] = useState(0);
  const [announcement, setAnnouncement] = useState("");
  const tabs = useRef<Array<HTMLButtonElement | null>>([]);
  const rail = useRef<HTMLOListElement>(null);
  const swipe = useRef<{ x: number; y: number } | null>(null);
  const reduced = usePrefersReducedMotion();
  const count = items.length;
  const current = items[active];
  const panels = useRef<HTMLDivElement>(null);
  const scan = useRef<HTMLSpanElement>(null);
  const tablist = useRef<HTMLDivElement>(null);
  // Which way the last step went (1 forward, -1 back), and the picture shown before it.
  const way = useRef(1);
  const shown = useRef(active);
  const [mark, setMark] = useState<{ y: number; h: number } | null>(null);

  // The chosen item's marker: one bone line that glides from row to row (each row keeps its own for hover).
  useLayoutEffect(() => {
    const place = () => {
      const tick = tabs.current[active]?.querySelector<HTMLElement>("[data-tick]");
      if (!tick || tick.offsetParent === null || !tablist.current) return;
      const box = tick.getBoundingClientRect();
      const top = tablist.current.getBoundingClientRect().top;
      setMark({ y: Math.round(box.top - top), h: Math.round(box.height) });
    };
    place();
    const ro = new ResizeObserver(place);
    if (tablist.current) ro.observe(tablist.current);
    return () => ro.disconnect();
  }, [active]);

  // A new picture wipes in over the old one, from the side the step came from, behind a crossing scan line.
  useLayoutEffect(() => {
    const from = shown.current;
    shown.current = active;
    const box = panels.current;
    if (from === active || reduced || !box || box.offsetParent === null) return;
    // A step taken mid-wipe starts its own from the picture now showing: earlier wipes end first.
    for (const panel of box.children) for (const running of panel.getAnimations()) running.cancel();
    const incoming = box.children[active] as HTMLElement | undefined;
    const outgoing = box.children[from] as HTMLElement | undefined;
    const forward = way.current > 0;
    incoming?.animate(
      [
        { clipPath: forward ? "inset(0 100% 0 0)" : "inset(0 0 0 100%)", zIndex: 2 },
        { clipPath: "inset(0 0 0 0)", zIndex: 2 },
      ],
      WIPE,
    );
    outgoing?.animate([{ opacity: 1, visibility: "visible" }, { opacity: 1, visibility: "visible" }], WIPE);
    // The line moves with the edge it uncovers, and fades only as it arrives.
    scan.current?.animate([{ left: forward ? "0%" : "100%" }, { left: forward ? "100%" : "0%" }], WIPE);
    scan.current?.animate([{ opacity: 1 }, { opacity: 1, offset: 0.85 }, { opacity: 0 }], { duration: WIPE.duration, easing: "linear" });
  }, [active, reduced]);

  // On phones the rail is showing: the card most in view is the current one, except while Previous or Next is
  // scrolling the rail (steered), when the cards passing by would set the counter back and forth.
  const steered = useRef(0);
  useEffect(() => {
    const root = rail.current?.parentElement;
    if (!root || !rail.current) return;
    const cards = Array.from(rail.current.children);
    const ratios = new Map<Element, number>();
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) ratios.set(e.target, e.intersectionRatio);
        if (root.offsetParent === null || steered.current) return;
        let best = 0;
        cards.forEach((c, i) => {
          if ((ratios.get(c) ?? 0) > (ratios.get(cards[best]) ?? 0) + 0.01) best = i;
        });
        setActive(best);
      },
      { root, threshold: [0, 0.5, 0.75, 1] },
    );
    cards.forEach((c) => io.observe(c));
    return () => io.disconnect();
  }, []);

  const select = (index: number, how: "tab" | "step") => {
    const next = (index + count) % count;
    way.current = index >= active ? 1 : -1;
    setActive(next);
    const scroller = rail.current?.parentElement;
    const card = rail.current?.children[next] as HTMLElement | undefined;
    if (scroller && card && scroller.offsetParent !== null) {
      const first = rail.current?.children[0] as HTMLElement;
      window.clearTimeout(steered.current);
      steered.current = window.setTimeout(() => (steered.current = 0), reduced ? 50 : 700);
      scroller.scrollTo({ left: card.offsetLeft - first.offsetLeft, behavior: reduced ? "auto" : "smooth" });
    }
    if (how === "tab") tabs.current[next]?.focus();
    // Tabs announce themselves on focus; the step buttons and swipes say where they went.
    else setAnnouncement(UI.recognition.position(next + 1, count, items[next].title));
  };

  const onTabKey = (e: KeyboardEvent<HTMLButtonElement>) => {
    const to: Record<string, number> = { ArrowDown: active + 1, ArrowRight: active + 1, ArrowUp: active - 1, ArrowLeft: active - 1, Home: 0, End: count - 1 };
    if (!(e.key in to)) return;
    e.preventDefault();
    select(to[e.key], "tab");
  };

  // A horizontal swipe on the picture steps through; vertical movement is left to the page.
  const onPointerDown = (e: PointerEvent) => {
    if (e.pointerType !== "mouse") swipe.current = { x: e.clientX, y: e.clientY };
  };
  const onPointerUp = (e: PointerEvent) => {
    const start = swipe.current;
    swipe.current = null;
    if (!start) return;
    const dx = e.clientX - start.x;
    if (Math.abs(dx) > 40 && Math.abs(dx) > 1.5 * Math.abs(e.clientY - start.y)) select(active + (dx < 0 ? 1 : -1), "step");
  };

  const stepButton =
    "group/step inline-flex size-11 items-center justify-center rounded-full border border-line-control text-bone-soft outline-none transition-[color,border-color,scale] duration-150 hover:border-bone hover:text-bone focus-visible:ring-2 focus-visible:ring-echo focus-visible:ring-offset-2 focus-visible:ring-offset-void active:scale-[0.94] motion-reduce:transition-none pointer-fine:size-9";
  // The chevron leans the way it goes.
  const nudge = "size-5 transition-transform duration-300 ease-[var(--ease-spring)] motion-reduce:transition-none";
  const fade = reduced ? "" : "transition-[opacity,visibility] duration-200 ease-[var(--ease-out-quint)]";

  return (
    <>
      <PlateDefs />
      <div
        data-reveal
        className="col-span-full flex items-center justify-between gap-4 md:col-[1/span_3] md:row-span-2 md:flex-col md:items-start md:justify-start lg:row-span-1"
      >
        <h2 id="recognition-title" className="font-display text-h3 text-balance font-[400] text-bone">
          <span className="rise">
            <span>{UI.recognition.title}</span>
          </span>
        </h2>
        {count > 1 ? (
          <div className="flex shrink-0 items-center gap-2 md:mt-6" data-print="hide">
            <button type="button" className={stepButton} onClick={() => select(active - 1, "step")} aria-controls="recognition-panels">
              <ChevronLeft aria-hidden className={`${nudge} group-hover/step:-translate-x-0.5`} strokeWidth={1.75} />
              <span className="sr-only">{UI.recognition.previous}</span>
            </button>
            <button type="button" className={stepButton} onClick={() => select(active + 1, "step")} aria-controls="recognition-panels">
              <ChevronRight aria-hidden className={`${nudge} group-hover/step:translate-x-0.5`} strokeWidth={1.75} />
              <span className="sr-only">{UI.recognition.next}</span>
            </button>
            <p aria-hidden className="ml-2 min-w-[3ch] font-instrument text-label text-bone-muted">
              <Rolling value={active + 1} /> / {count}
            </p>
          </div>
        ) : null}
        <p role="status" className="sr-only">
          {announcement}
        </p>
      </div>

      <figure data-reveal="late" className="hidden md:col-[4/span_5] md:block lg:col-[8/span_5] lg:row-start-1">
        <div className="relative">
        <div
          id="recognition-panels"
          ref={panels}
          className="acquire @container relative grid aspect-[3/2] touch-pan-y overflow-hidden rounded-[var(--radius-panel)] bg-ink select-none"
          onPointerDown={onPointerDown}
          onPointerUp={onPointerUp}
          onPointerCancel={() => (swipe.current = null)}
        >
          {items.map((item, i) => (
            <div
              key={item.id}
              id={`recognition-panel-${item.id}`}
              role="tabpanel"
              inert={i !== active}
              aria-labelledby={`recognition-tab-${item.id}`}
              className={`col-start-1 row-start-1 bg-ink ${fade} ${i === active ? "visible opacity-100" : "invisible opacity-0"}`}
            >
              <Media item={item} sizes={sizes} eager={i === 0} />
            </div>
          ))}
        </div>
        <span ref={scan} aria-hidden className="scan-line" />
        </div>
        <figcaption className="mt-3 flex min-h-[1.5em] items-baseline justify-between gap-4 text-small text-bone-muted">
          <Provenance media={current.media} />
        </figcaption>
      </figure>

      {/* Phones: a rail of cards, each with its own picture. The step buttons above move it. */}
      <div
        role="group"
        aria-label={UI.recognition.title}
        tabIndex={0}
        data-reveal="late"
        className="col-span-full -mr-4 snap-x snap-mandatory overflow-x-auto overscroll-x-contain pr-[15vw] outline-none [mask-image:linear-gradient(90deg,black_calc(100%-2.25rem),transparent)] [scrollbar-width:none] focus-visible:ring-2 focus-visible:ring-echo focus-visible:ring-offset-2 focus-visible:ring-offset-void sm:-mr-6 sm:pr-6 md:hidden [&::-webkit-scrollbar]:hidden"
      >
        <ol ref={rail} className="flex w-max gap-3">
          {items.map((item) => (
            <li key={item.id} className="w-[min(85vw,24rem)] shrink-0 snap-start">
              {/* Acquired behind a scan line when the rail is first seen, as the wide screens' picture is. */}
              <div className="relative">
                <div className="acquire @container grid aspect-[3/2] overflow-hidden rounded-[var(--radius-panel)] bg-ink">
                  <Media item={item} sizes="85vw" meta={false} eager={item.id === items[0].id} />
                </div>
                <span aria-hidden className="scan-line" />
              </div>
              {item.media ? (
                <p className="mt-2 flex items-baseline justify-between gap-3 text-small text-bone-muted">
                  <Provenance media={item.media} />
                </p>
              ) : null}
              <p className="mt-4 flex items-baseline justify-between gap-4">
                <span className="font-display text-title text-bone-soft">{item.when}</span>
                <span className="font-instrument text-label text-bone-muted">{item.kind}</span>
              </p>
              <h3 className="mt-1 font-display text-title text-balance font-[420] text-bone">{item.title}</h3>
              {item.context ? <p className="mt-1.5 text-small text-pretty text-bone-soft">{item.context}</p> : null}
            </li>
          ))}
        </ol>
      </div>

      <div
        ref={tablist}
        role="tablist"
        aria-label={UI.recognition.title}
        aria-orientation="vertical"
        data-marked={mark ? "" : undefined}
        className="relative hidden md:col-[4/span_5] md:flex md:flex-col lg:col-[4/span_4] lg:row-start-1"
      >
        {items.map((item, i) => {
          const on = i === active;
          return (
            <button
              key={item.id}
              ref={(el) => {
                tabs.current[i] = el;
              }}
              id={`recognition-tab-${item.id}`}
              type="button"
              role="tab"
              aria-selected={on}
              aria-controls={`recognition-panel-${item.id}`}
              aria-labelledby={`recognition-title-${item.id}`}
              aria-describedby={`recognition-meta-${item.id}`}
              tabIndex={on ? 0 : -1}
              onClick={() => select(i, "tab")}
              onKeyDown={onTabKey}
              className="group/row relative block w-full border-t border-hairline py-4 pr-2 pl-5 text-left outline-none transition-colors duration-150 first:border-t-0 first:pt-1 focus-visible:ring-2 focus-visible:ring-echo focus-visible:ring-inset motion-reduce:transition-none lg:py-5"
            >
              <span
                aria-hidden
                data-tick
                data-on={on ? "" : undefined}
                className="absolute top-4 bottom-4 left-0 w-0.5 rounded-full bg-transparent transition-colors duration-150 group-first/row:top-1 group-hover/row:bg-line-strong"
              />
              <span id={`recognition-meta-${item.id}`} className="flex items-baseline justify-between gap-4">
                <span className={`font-display text-title ${on ? "text-bone-soft" : "text-bone-muted"}`}>{item.when}</span>
                <span className="font-instrument text-label text-bone-muted">{item.kind}</span>
              </span>
              <span
                id={`recognition-title-${item.id}`}
                className={`mt-1 block font-display text-title text-balance font-[420] transition-colors duration-150 ${on ? "text-bone" : "text-bone-muted group-hover/row:text-bone-soft"}`}
              >
                {item.title}
              </span>
              {item.context ? (
                <span className={`mt-1.5 text-small text-pretty text-bone-soft ${on ? "block" : "hidden md:block md:text-bone-muted"}`}>{item.context}</span>
              ) : null}
            </button>
          );
        })}
        {/* After the rows, so their first:/last: variants still find the first and last row. */}
        {mark ? <span aria-hidden className="tab-mark" style={{ "--y": `${mark.y}px`, "--h": `${mark.h}px` } as React.CSSProperties} /> : null}
      </div>
    </>
  );
}
