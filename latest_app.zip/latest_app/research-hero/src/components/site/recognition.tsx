import { recognition } from "@/content/about";
import { recognitionPhotos } from "@/content/recognition-photos";
import { renders } from "@/content/renders";
import { UI } from "@/content/ui";
import { shown } from "@/lib/format";
import { GRID, SHELL } from "./layout";
import { RecognitionShowcase, type ShowcaseItem } from "./recognition-showcase";

/** The picture panel's width: five of twelve columns on wide screens, five of eight on tablets, full on phones. */
const SIZES = "(min-width: 90rem) 551px, (min-width: 64rem) 38vw, (min-width: 48rem) 58vw, calc(100vw - 2rem)";

/**
 * Recognition and service, directly under the lab: the awards and roles a committee looks for first. Each item
 * shows the owner's photo when there is one; until then, an item whose work the lab depicts can show that lab
 * still, labeled Simulated, and the rest get a typographic plate. Only confirmed items appear.
 */
export function Recognition() {
  const items: ShowcaseItem[] = recognition
    .filter((r) => shown(r.title))
    .map((r) => {
      const photo = r.photo ? recognitionPhotos[r.id] : undefined;
      // The 3:2 card still is framed for this panel; the wide one (subject to the right) is the fallback.
      const card = !photo && r.still ? renders.find((x) => x.id === r.still?.render && x.framing === "card") : undefined;
      const still = card ?? (!photo && r.still ? renders.find((x) => x.id === r.still?.render && x.framing === "wide") : undefined);
      return {
        id: r.id,
        when: r.when,
        kind: r.kind === "award" ? UI.recognition.award : UI.recognition.service,
        title: r.title.value,
        context: r.context,
        media:
          photo && r.photo
            ? { kind: "photo", sources: photo.sources, width: photo.width, height: photo.height, alt: r.photo.alt, caption: `Photo: ${r.photo.credit}` }
            : still && r.still
              ? { kind: "still", sources: still.sources, width: still.width, height: still.height, alt: still.alt, caption: r.still.caption, focus: card ? "50% 50%" : "100% 50%" }
              : null,
      };
    });
  if (items.length === 0) return null;
  return (
    <section id="recognition" aria-labelledby="recognition-title" className="pt-(--space-block)">
      <div className={`${SHELL} ${GRID} gap-y-6 lg:items-start`}>
        <RecognitionShowcase items={items} sizes={SIZES} />
      </div>
    </section>
  );
}
