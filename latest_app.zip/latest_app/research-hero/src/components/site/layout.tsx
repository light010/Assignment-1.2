import type { SkillChapter } from "@/lab/state";
import type { ThemeId } from "@/content/types";
import { UI } from "@/content/ui";

/*
  The console grid at page scale (design-system/MASTER.md, appendix C §2.3): a label track for names,
  dates, and lab chips; a reading track of at most 34em; an aside for evidence. One left edge,
  shared with the hero headline. Nothing is centered.
*/

export const SHELL = "mx-auto w-full max-w-[90rem] px-4 sm:px-6 lg:px-10";
export const GRID = "grid grid-cols-4 gap-x-4 md:grid-cols-8 md:gap-x-5 lg:grid-cols-12 lg:gap-x-6";
// Start and span in one declaration: a separate col-span-* would reset grid-column-start.
export const LABEL_TRACK = "col-span-full md:col-[1/span_3]";
export const READING_TRACK = "col-span-full md:col-[4/span_5] lg:col-[4/span_7] xl:col-[4/span_5]";
export const WIDE_TRACK = "col-span-full md:col-[4/span_5] lg:col-[4/span_9]";
export const ASIDE_TRACK = "col-span-full md:col-[4/span_5] lg:col-[4/span_7] xl:col-[9/span_4]";

/** Lab chapter anchors and names, shared by chips, evidence links, and the hero's deep links. */
export const LAB_SLUG: Record<SkillChapter, string> = {
  design: "lab-design",
  deliver: "lab-delivery",
  photoacoustic: "lab-photoacoustics",
  ultrasound: "lab-ultrasound",
};

export const LAB_NAME: Record<SkillChapter, string> = {
  design: "Design",
  deliver: "Delivery",
  photoacoustic: "Photoacoustics",
  ultrasound: "Ultrasound",
};

/**
 * Topic marks, the same in the Show filter and on every paper, so the filter is their legend: ● light for the
 * delivery half, ●○ light and sound for the imaging half. Shape carries the meaning as well as hue (pulse and
 * echo are hard to tell apart with color-vision deficiency), and the mark carries its word for screen readers.
 * Drawn in CSS (.glyph in globals.css) so each paper row stays small.
 */
export type Glyph = ThemeId;

const GLYPH_CODE: Record<Glyph, string> = { delivery: "d", imaging: "p" };

export function TopicGlyph({ glyph }: { glyph: Glyph }) {
  return (
    <>
      <span aria-hidden className="glyph" data-g={GLYPH_CODE[glyph]} />
      <span className="sr-only">{UI.publications.options[glyph]}</span>
    </>
  );
}

/** A paper's mark: the half of the work it belongs to, or none for other and earlier work. */
export function glyphFor(themes: ThemeId[]): Glyph | null {
  return themes.includes("delivery") ? "delivery" : themes.includes("imaging") ? "imaging" : null;
}

/** A section's heading and its one-sentence deck. When first scrolled to, the heading rises from behind its own line, as the lab's headline does (.rise in globals.css); the deck is simply there. */
export function SectionHeading({ id, title, deck, focusable = false }: { id: string; title: string; deck?: string; focusable?: boolean }) {
  return (
    <div className="col-span-full" data-reveal>
      <h2
        id={`${id}-title`}
        tabIndex={focusable ? -1 : undefined}
        className="font-display display-optical text-h2 text-balance font-[380] text-bone"
      >
        <span className="rise">
          <span>{title}</span>
        </span>
      </h2>
      {deck ? <p className="mt-4 max-w-[30em] font-display text-deck text-pretty text-bone">{deck}</p> : null}
    </div>
  );
}
