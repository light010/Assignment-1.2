import { Picture } from "@/components/picture";
import { profile } from "@/content/profile";
import { renders } from "@/content/renders";
import { UI } from "@/content/ui";
import { ThemeToggle } from "@/components/site/theme-toggle";

const WIDE = "(min-width: 60rem) and (min-aspect-ratio: 21/20)";

/**
 * The hero without the lab: name, navigation, headline, lede, and a still of the lab, labeled Simulated.
 * Shown only when the interactive hero fails (see HeroBoundary). Same words and anchors as the live hero.
 */
export function StaticHero() {
  const wide = renders.find((r) => r.id === "overview" && r.framing === "wide");
  const phone = renders.find((r) => r.id === "overview" && r.framing === "phone");
  return (
    <section id="top" aria-label="Introduction" className="lab-pin bg-void">
      <header className="mx-auto flex w-full max-w-[90rem] flex-wrap items-center justify-between gap-y-1 px-4 py-3 sm:px-6 lg:px-10 lg:py-6">
        <a href="#top" className="inline-flex min-h-11 flex-col justify-center rounded-lg outline-none focus-visible:ring-2 focus-visible:ring-echo">
          <span className="font-display text-[1.1875rem] leading-tight italic text-bone">{profile.name}</span>
          <span className="text-micro text-bone-muted">{profile.role}</span>
        </a>
        <nav aria-label="Primary" className="-mx-2 w-[calc(100%+1rem)] sm:mx-0 sm:w-auto">
          <ul className="flex items-center justify-between sm:justify-end sm:gap-0.5">
            {profile.nav.map((item) => (
              <li key={item.href}>
                <a
                  href={item.href}
                  className="inline-flex min-h-11 items-center rounded-full px-2 text-[0.9375rem] text-bone-muted outline-none transition-colors duration-200 hover:text-bone focus-visible:ring-2 focus-visible:ring-echo sm:px-3.5"
                >
                  {item.label}
                </a>
              </li>
            ))}
            <li>
              <ThemeToggle className="sm:ml-1.5" />
            </li>
          </ul>
        </nav>
      </header>
      <div className="mx-auto grid w-full max-w-[90rem] gap-8 px-4 pb-12 pt-8 sm:px-6 lg:grid-cols-[minmax(0,36rem)_1fr] lg:items-center lg:px-10">
        <div>
          <h1 className="font-display text-hero text-balance font-[380] text-bone">
            {profile.headline.map((line) => (
              <span key={line} className="block">
                {line}
              </span>
            ))}
          </h1>
          <p className="mt-6 max-w-[34em] text-lede text-pretty text-bone-soft">{profile.lede}</p>
        </div>
        {wide && phone ? (
          <figure>
            <div className="overflow-hidden rounded-[var(--radius-panel)] border border-hairline">
              <Picture
                sources={phone.sources}
                width={phone.width}
                height={phone.height}
                art={[{ media: WIDE, sources: wide.sources, width: wide.width, height: wide.height }]}
                sizes="(min-width: 60rem) 50vw, calc(100vw - 2rem)"
                alt={wide.alt}
                className="h-auto w-full"
              />
            </div>
            <figcaption className="mt-3 text-small text-bone-muted">{UI.staticHero.caption}</figcaption>
          </figure>
        ) : null}
      </div>
    </section>
  );
}
