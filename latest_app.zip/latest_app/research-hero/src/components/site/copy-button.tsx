"use client";

import { Check, Copy } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { UI } from "@/content/ui";

type CopyState = "idle" | "copied" | "failed";

/**
 * Copies text and says so: "Copied" for two seconds, announced politely. If the browser blocks the
 * clipboard, it selects the text on the page instead and says what to do next; when the text isn't on the
 * page (a link, or text loaded on demand), the message shows it, ready to select.
 */
export function CopyButton({
  text,
  label,
  selectId,
  compact = false,
  className = "",
}: {
  /** The text, or a function that returns it; return a string when it's at hand, so the copy stays in the click. */
  text: string | (() => string | Promise<string>);
  label: string;
  /** Element whose text is selected when the clipboard is unavailable. */
  selectId?: string;
  /** Pill size, beside the publication list's link pills: 36 px on fine pointers, 14 px text. */
  compact?: boolean;
  className?: string;
}) {
  const [state, setState] = useState<CopyState>("idle");
  const [shown, setShown] = useState<string | null>(null);
  const timer = useRef<number | undefined>(undefined);

  useEffect(() => () => window.clearTimeout(timer.current), []);

  const onClick = async () => {
    window.clearTimeout(timer.current);
    let value: string | null = typeof text === "string" ? text : null;
    try {
      if (value === null && typeof text === "function") {
        const got = text();
        value = typeof got === "string" ? got : await got;
      }
      setShown(value);
      await navigator.clipboard.writeText(value ?? "");
      setState("copied");
      timer.current = window.setTimeout(() => setState("idle"), 2000);
    } catch {
      const target = selectId ? document.getElementById(selectId) : null;
      if (target) {
        const range = document.createRange();
        range.selectNodeContents(target);
        const selection = window.getSelection();
        selection?.removeAllRanges();
        selection?.addRange(range);
      }
      setState("failed");
      timer.current = window.setTimeout(() => setState("idle"), 6000);
    }
  };

  return (
    <span className="inline-flex flex-wrap items-center gap-x-3 gap-y-1">
      {/* Both icons and both labels are drawn in one cell each (globals.css, "Copy buttons"): the copy icon turns
          into a check that draws itself and the label rolls up to "Copied", and the button keeps its width. The
          label that isn't showing is hidden from screen readers, so the button's name is always the one on screen. */}
      <button
        type="button"
        onClick={onClick}
        data-state={state}
        className={`inline-flex min-h-11 items-center gap-2 rounded-full border border-line-control text-bone-soft outline-none transition-[color,border-color,scale] duration-150 ease-[var(--ease-out-quint)] hover:border-bone hover:text-bone focus-visible:ring-2 focus-visible:ring-echo focus-visible:ring-offset-2 focus-visible:ring-offset-void active:scale-[0.97] ${compact ? "px-3.5 text-[0.875rem] pointer-fine:min-h-9" : "px-4 text-[0.9375rem]"} ${className}`}
      >
        <span aria-hidden className="copy-icon">
          <Copy className="size-4" strokeWidth={1.75} />
          <Check className="size-4" strokeWidth={1.75} />
        </span>
        <span className="copy-label">
          <span aria-hidden={state === "copied" ? true : undefined}>{label}</span>
          <span aria-hidden={state === "copied" ? undefined : true}>{UI.copy.done}</span>
        </span>
      </button>
      <span role="status" className={state === "failed" ? "text-small text-alert" : "sr-only"}>
        {state === "copied" ? UI.copy.done : null}
        {state === "failed" && selectId ? UI.copy.failedSelected : null}
        {state === "failed" && !selectId && shown ? (
          <>
            {UI.copy.failedShown} <span className="break-all whitespace-pre-wrap text-bone select-all">{shown}</span>
          </>
        ) : null}
        {state === "failed" && !selectId && !shown ? (
          <>
            {UI.copy.failedLoad}{" "}
            <a href="/publications.bib" className="prose-link text-bone">
              {UI.publications.allBibtex}
            </a>
          </>
        ) : null}
      </span>
    </span>
  );
}
