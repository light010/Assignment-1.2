"use client";

import { ChevronDown } from "lucide-react";
import { useRef, useState, useSyncExternalStore } from "react";
import { UI } from "@/content/ui";
import { CopyButton } from "./copy-button";

const noop = () => () => {};

/*
  BibTeX for every paper lives in one file, /publications.bib, built from the same records. Keeping it out
  of the page saves every visitor the bytes; opening a Cite panel fetches the file once, so by the time
  "Copy BibTeX" is pressed the entry is at hand and the copy happens inside the click, as Safari requires.
*/
let loaded: Map<string, string> | null = null;
let loading: Promise<Map<string, string>> | null = null;

function loadBib(): Promise<Map<string, string>> {
  loading ??= fetch("/publications.bib")
    .then((r) => {
      if (!r.ok) throw new Error(`publications.bib: ${r.status}`);
      return r.text();
    })
    .then((text) => {
      const entries = new Map<string, string>();
      for (const block of text.split(/\n(?=@)/)) {
        const key = block.match(/^@\w+\{([^,]+),/)?.[1];
        if (key) entries.set(key, block.trim());
      }
      loaded = entries;
      return entries;
    })
    .catch((error) => {
      loading = null;
      throw error;
    });
  return loading;
}

function bibEntry(key: string): string | Promise<string> {
  const pick = (entries: Map<string, string>) => {
    const entry = entries.get(key);
    if (!entry) throw new Error(`no BibTeX entry ${key}`);
    return entry;
  };
  return loaded ? pick(loaded) : loadBib().then(pick);
}

/**
 * "Cite": a native disclosure (it opens without JavaScript) holding the citation, with buttons that copy
 * it, its BibTeX, and a link to this entry. The buttons need JavaScript to work, so they're made the first
 * time the panel opens rather than shipped, unusable, inside every closed panel on the page.
 */
export function CitePanel({ id, citation, bibKey }: { id: string; citation: string; bibKey: string }) {
  // The entry's own address, known only in the browser.
  const link = useSyncExternalStore(
    noop,
    () => `${location.origin}${location.pathname}#pub-${id}`,
    () => `#pub-${id}`,
  );
  const [opened, setOpened] = useState(false);
  // While the panel eases shut its contents are still drawn: inert keeps Tab from wandering into them.
  const body = useRef<HTMLDivElement>(null);
  return (
    <details
      className="cite group/cite"
      onToggle={(e) => {
        const open = e.currentTarget.open;
        if (body.current) body.current.inert = !open;
        if (!open) return;
        setOpened(true);
        loadBib().catch(() => {});
      }}
    >
      <summary className="pill cursor-pointer list-none marker:hidden [&::-webkit-details-marker]:hidden">
        {UI.publications.cite}
        <ChevronDown aria-hidden className="size-4 transition-transform duration-200 group-open/cite:rotate-180 motion-reduce:transition-none" strokeWidth={1.75} />
      </summary>
      <div ref={body} className="mt-3 rounded-[var(--radius-cell)] bg-panel p-4" data-print="plain">
        <p id={`cite-${id}`} className="text-small text-pretty text-bone-soft [overflow-wrap:anywhere]">
          {citation}
        </p>
        {opened ? (
          <div className="mt-3 flex flex-wrap gap-2">
            <CopyButton text={citation} label={UI.publications.copyCitation} selectId={`cite-${id}`} compact />
            <CopyButton text={() => bibEntry(bibKey)} label={UI.publications.copyBibtex} compact />
            <CopyButton text={link} label={UI.publications.copyLink} compact />
          </div>
        ) : null}
      </div>
    </details>
  );
}
