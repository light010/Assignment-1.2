import { isFirstAuthor, publications } from "@/content/publications";
import { scholarFor } from "@/content/scholar";
import { DECKS } from "@/content/site";
import { UI } from "@/content/ui";
import type { Publication } from "@/content/types";
import { ACCESS_LABEL, TYPE_LABEL, bibKey, citationText } from "@/lib/format";
import { keepCompounds } from "@/lib/typeset";
import { CitePanel } from "./cite-panel";
import { LAB_NAME, LAB_SLUG, SHELL, SectionHeading, TopicGlyph, glyphFor } from "./layout";
import { PublicationBrowser, type ShowValue } from "./publication-browser";
import { ScholarReadout } from "./scholar-readout";

/**
 * Publications: the complete, correct record as a compact index, and the Google Scholar readout. A row carries
 * what a reader scans for (the year, the topic mark, the title, where it appeared, first author or free to read,
 * and Scholar's count of citing papers); "Summary" opens the summary, authors, role, links, and Cite in place.
 * Show and Sort work on these rows, which are all in the HTML. On wide screens the readout is an instrument
 * panel beside the list, its edges matching the list's; elsewhere it follows the list. Its figures are
 * refreshed from the profile every four hours (docs/scholar-sync.md).
 */
export function Publications() {
  // Newest first; a stable sort keeps the curated order within a year.
  const papers = [...publications].sort((a, b) => b.year - a.year);
  const maxCited = Math.max(1, ...papers.map((p) => scholarFor(p.id)?.citedBy ?? 0));
  const count = (fn: (p: Publication) => boolean) => papers.filter(fn).length;
  const options = (
    [
      { value: "all", label: UI.publications.options.all, count: papers.length },
      { value: "delivery", label: UI.publications.options.delivery, count: count((p) => p.themes.includes("delivery")), glyph: "d" },
      { value: "imaging", label: UI.publications.options.imaging, count: count((p) => p.themes.includes("imaging")), glyph: "p" },
      { value: "first-author", label: UI.publications.options["first-author"], count: count(isFirstAuthor) },
    ] satisfies Array<{ value: ShowValue; label: string; count: number; glyph?: "d" | "p" }>
  ).filter((o) => o.value === "all" || o.count > 0);

  return (
    <section id="publications" aria-labelledby="publications-title" className="pt-(--space-section)">
      <div className={`${SHELL} pub-layout`}>
        {/* The heading takes focus when an in-page link (a Research card's, the lab's) filters the list. */}
        <SectionHeading id="publications" title={UI.publications.title} deck={DECKS.publications} focusable />
        <PublicationBrowser
          options={options}
          total={papers.length}
          footer={
            <a href="/publications.bib" className="label-link hit text-small" data-print="hide">
              {UI.publications.allBibtex}
            </a>
          }
        >
          {papers.map((p) => (
            <PaperRow key={p.id} paper={p} maxCited={maxCited} />
          ))}
        </PublicationBrowser>
        <ScholarReadout />
      </div>
    </section>
  );
}

const LINK_ORDER = ["doi", "pdf", "preprint", "pmc", "record"];

/** Where it appeared, short: journals by name; everything else says what it is; the thesis names its school. */
function Venue({ paper: p }: { paper: Publication }) {
  const name = keepCompounds(p.venueShort ?? p.venue);
  if (p.type === "thesis") return <span>{name}</span>;
  const venue = <cite className="not-italic text-bone-soft">{name}</cite>;
  if (p.type === "journal-article") return venue;
  return (
    <span>
      {TYPE_LABEL[p.type]} in {venue}
    </span>
  );
}

function PaperRow({ paper: p, maxCited }: { paper: Publication; maxCited: number }) {
  const scholar = scholarFor(p.id);
  const cited = scholar?.citedBy ?? 0;
  const first = isFirstAuthor(p);
  const access = ACCESS_LABEL[p.access];
  const glyph = glyphFor(p.themes);
  const titleHref = p.doi ? `https://doi.org/${p.doi}` : p.links[0]?.href;
  // The paper, then free copies, then the record.
  const links = [...p.links].sort((a, b) => LINK_ORDER.indexOf(a.kind) - LINK_ORDER.indexOf(b.kind));
  const title = `t-${p.id}`;
  const panel = `m-${p.id}`;

  return (
    <li
      id={`pub-${p.id}`}
      className="pub-row"
      data-themes={p.themes.join(" ") || "other"}
      data-first={first ? "" : undefined}
      data-cited={cited}
      data-year={p.year}
    >
      <p className="pub-year">
        {p.year}
        {glyph ? <TopicGlyph glyph={glyph} /> : null}
      </p>
      <h3 id={title} className="pub-title font-display text-title font-[420] text-pretty text-bone">
        <a href={titleHref} className="title-link">
          {keepCompounds(p.title)}
        </a>
      </h3>
      <p className="pub-meta">
        <Venue paper={p} />
        {first ? <span className="text-bone">{UI.publications.firstAuthor}</span> : null}
        {access ? <span>{access}</span> : null}
      </p>
      {cited > 0 && scholar?.citedByUrl ? (
        <a
          href={scholar.citedByUrl}
          className="pub-cites"
          aria-describedby={title}
          data-print-url="off"
          style={{ "--c": (cited / maxCited).toFixed(3) } as React.CSSProperties}
        >
          <span>
            <span className="text-bone-muted">{UI.publications.citedBy}</span>
            {` ${cited}`}
          </span>
        </a>
      ) : null}
      {/* Named "Summary" and the paper's title, so fifteen of them can be told apart. */}
      <button type="button" id={`s-${p.id}`} className="pub-toggle" aria-expanded="false" aria-controls={panel} aria-labelledby={`s-${p.id} ${title}`} data-needs-js>
        {UI.publications.summary}
      </button>
      <div id={panel} className="pub-more" data-closed="">
        <p className="max-w-[36em] pt-3 font-display text-summary text-pretty text-bone-soft">{p.summary}</p>
        <p className="mt-3 text-small text-bone-soft">
          {p.authors.map((a, i) => (
            <span key={a.name + i}>
              {i > 0 ? ", " : ""}
              <span className="nowrap">{a.me ? <strong className="font-semibold text-bone">{a.name}</strong> : a.name}</span>
            </span>
          ))}
        </p>
        {p.type === "thesis" || !p.venueShort ? null : <p className="mt-1 text-small text-bone-muted">{keepCompounds(p.venue)}</p>}
        {p.role ? (
          <p className="mt-1 text-small text-bone-muted">
            {UI.publications.myRole} <span className="text-bone-soft">{p.role.credit.join(", ")}</span>
          </p>
        ) : null}
        {p.note ? <p className="mt-1 text-small text-bone-muted">{p.note}</p> : null}
        <div className="mt-4 flex flex-wrap items-start gap-2">
          {links.map((l) => (
            <a key={l.href} href={l.href} className="pill">
              {l.label}
              {l.note ? <span className="text-bone-muted">({l.note})</span> : null}
            </a>
          ))}
        </div>
        <div className="mt-3" data-print="hide">
          <CitePanel id={p.id} citation={citationText(p)} bibKey={bibKey(p)} />
        </div>
        {p.chapters.length ? (
          <p className="mt-3 font-instrument text-label text-bone-muted">
            {UI.publications.inLab}{" "}
            {p.chapters.map((c, i) => (
              <span key={c}>
                {i > 0 ? ", " : ""}
                <a href={`#${LAB_SLUG[c]}`} aria-label={`${UI.publications.inLab} ${LAB_NAME[c]}`} className="label-link">
                  {LAB_NAME[c]}
                </a>
              </span>
            ))}
          </p>
        ) : null}
      </div>
    </li>
  );
}
