"use client";

import { Component, type ErrorInfo, type ReactNode } from "react";

/**
 * The lab runs on the GPU and on more script than anything else here, so it is the likeliest part to fail
 * (a driver bug, a WebGL context the engine can't restore). If it does, the failure stays inside the hero:
 * the page swaps in the static header and every section below keeps working.
 */
export class HeroBoundary extends Component<{ fallback: ReactNode; children: ReactNode }, { failed: boolean }> {
  state = { failed: false };

  static getDerivedStateFromError() {
    return { failed: true };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("The lab stopped and the static header took its place.", error, info.componentStack);
  }

  render() {
    return this.state.failed ? this.props.fallback : this.props.children;
  }
}
