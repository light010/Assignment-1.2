/**
 * A readout figure that rises into place digit by digit, left first, when its block is first scrolled to
 * (globals.css, .rise-digits). While it waits the window is blank, so it never shows a number it isn't. The digits
 * are the text itself, so screen readers, find-in-page, and copying read the number as it is.
 */
export function RisingFigure({ value }: { value: number }) {
  const text = String(Math.max(0, Math.round(value)));
  return (
    <span className="rise-digits">
      {[...text].map((digit, i) => (
        <span key={i} style={{ "--i": i } as React.CSSProperties}>
          {digit}
        </span>
      ))}
    </span>
  );
}
