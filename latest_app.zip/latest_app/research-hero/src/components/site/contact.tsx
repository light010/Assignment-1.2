import { person } from "@/content/person";
import { DECKS } from "@/content/site";
import { UI } from "@/content/ui";
import { shown } from "@/lib/format";
import { CopyButton } from "./copy-button";
import { GRID, LABEL_TRACK, READING_TRACK, SHELL, SectionHeading, WIDE_TRACK } from "./layout";

/**
 * Contact: one clear channel. The address is visible text with a Copy button; there is no form, because
 * there is no server to receive one and a form could show a false "sent".
 */
export function Contact() {
  const profiles = [
    { label: "Google Scholar", href: person.links.scholar, detail: undefined },
    shown(person.links.orcid)
      ? { label: "ORCID", href: `https://orcid.org/${person.links.orcid.value}`, detail: person.links.orcid.value }
      : null,
    shown(person.links.linkedin) ? { label: "LinkedIn", href: person.links.linkedin.value, detail: undefined } : null,
  ].filter((p) => p !== null);

  return (
    <section id="contact" aria-labelledby="contact-title" className="pt-(--space-section)">
      <div className={`${SHELL} ${GRID} gap-y-6`}>
        <SectionHeading id="contact" title={UI.contact.title} deck={DECKS.contact} />
        {shown(person.email) ? (
          <div className={`${WIDE_TRACK} mt-2 flex flex-col items-start gap-4`}>
            <a
              id="contact-email"
              href={`mailto:${person.email.value}`}
              data-print-url="off"
              className="email-link font-display text-email [overflow-wrap:anywhere] font-[380] text-bone outline-none focus-visible:ring-2 focus-visible:ring-echo focus-visible:ring-offset-4 focus-visible:ring-offset-void"
            >
              {person.email.value}
            </a>
            <div data-print="hide">
              <CopyButton text={person.email.value} label={UI.contact.copyEmail} selectId="contact-email" />
            </div>
          </div>
        ) : null}
        <h3 className={`${LABEL_TRACK} mt-6 self-start font-instrument text-label text-bone-muted md:mt-12 md:pt-4`}>{UI.contact.profiles}</h3>
        <ul className={`draw-rules ${READING_TRACK} flex flex-col md:mt-12`} data-reveal>
          {profiles.map((p, i) => (
            <li key={p.label} className="border-t border-hairline first:border-t-0 md:first:border-t" style={{ "--i": i } as React.CSSProperties}>
              {/* Under the pointer the name leans in, the way the lab's chevrons do. */}
              <a
                href={p.href}
                className="group/profile flex min-h-12 items-baseline justify-between gap-4 py-3 text-bone outline-none focus-visible:ring-2 focus-visible:ring-echo"
              >
                <span className="font-display text-title transition-transform duration-300 ease-[var(--ease-spring)] group-hover/profile:translate-x-1 motion-reduce:transition-none">
                  {p.label}
                </span>
                {p.detail ? (
                  <span className="font-instrument text-label text-bone-muted transition-colors duration-200 group-hover/profile:text-bone-soft">{p.detail}</span>
                ) : null}
              </a>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
