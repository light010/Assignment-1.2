"use client";

import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import { SECTIONS } from "@/content/site";
import { ThemeToggle } from "@/components/site/theme-toggle";

/**
 * The section bar: once the hero has left the screen, the same four links fade in at the top and mark
 * where you are. It is the only thing on the page that responds to scrolling. While hidden it is inert,
 * so keyboard and screen-reader users never meet it underneath the hero.
 */
export function SectionBar({ name }: { name: string }) {
  const [visible, setVisible] = useState(false);
  const [current, setCurrent] = useState<string | null>(null);
  const links = useRef<HTMLDivElement>(null);
  // The underline glides from section to section, placed from the current link's text. It reappears in place rather
  // than gliding in from where it last was, and a change of size (the window, fonts) moves it without a glide.
  const [mark, setMark] = useState<{ x: number; w: number; jump: boolean } | null>(null);
  const marked = useRef(false);
  const place = useCallback((jump: boolean) => {
    const a = links.current?.querySelector<HTMLElement>('[aria-current="location"]');
    // Back in the lab: the underline fades where it is.
    if (!a) return void (marked.current = false);
    const appear = !marked.current;
    marked.current = true;
    const pad = parseFloat(getComputedStyle(a).paddingLeft) || 0;
    setMark((m) => ({ x: a.offsetLeft + pad, w: a.offsetWidth - 2 * pad, jump: jump || appear || !m }));
  }, []);
  useLayoutEffect(() => place(false), [current, place]);
  useEffect(() => {
    // Created once; its first report (made on attaching) is skipped, so it never turns a glide into a jump.
    let attached = false;
    const ro = new ResizeObserver(() => {
      if (attached) place(true);
      attached = true;
    });
    if (links.current) ro.observe(links.current);
    return () => ro.disconnect();
  }, [place]);

  useEffect(() => {
    const hero = document.getElementById("top");
    if (!hero) return;
    // Anchors land 72 px below the top (scroll-padding), leaving that much of the lab in view. An edge that merely
    // touches the margin still counts as intersecting, so the margin reaches 16 px past it.
    const io = new IntersectionObserver(([entry]) => setVisible(!entry.isIntersecting), { rootMargin: "-88px 0px 0px 0px" });
    io.observe(hero);
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    const sections = SECTIONS.map((s) => document.getElementById(s.id)).filter((el): el is HTMLElement => el !== null);
    // A section is current when it crosses a thin band a third of the way down the screen.
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) if (e.isIntersecting) setCurrent(e.target.id);
      },
      { rootMargin: "-33% 0px -66% 0px" },
    );
    sections.forEach((s) => io.observe(s));
    const hero = document.getElementById("top");
    const heroIo = hero
      ? new IntersectionObserver(([e]) => {
          if (e.isIntersecting) setCurrent(null);
        }, { rootMargin: "-33% 0px -66% 0px" })
      : null;
    if (hero) heroIo?.observe(hero);
    return () => {
      io.disconnect();
      heroIo?.disconnect();
    };
  }, []);

  return (
    <nav
      aria-label="Sections"
      inert={!visible}
      data-visible={visible}
      data-print="hide"
      className="fixed inset-x-0 top-0 z-50 h-(--header-h) border-b border-hairline bg-void/92 opacity-0 backdrop-blur-md transition-opacity duration-150 ease-[var(--ease-out-quint)] data-[visible=false]:pointer-events-none data-[visible=true]:opacity-100 motion-reduce:transition-none"
    >
      <div className="mx-auto flex h-full w-full max-w-[90rem] items-center justify-between gap-3 px-2 sm:gap-4 sm:px-6 lg:px-10">
        <a
          href="#top"
          className="hidden min-h-11 items-center rounded-lg font-display text-[1.0625rem] italic text-bone outline-none focus-visible:ring-2 focus-visible:ring-echo sm:inline-flex"
        >
          {name}
        </a>
        <div ref={links} className="relative min-w-0 flex-1 sm:flex-none">
        <ul className="flex w-full items-center justify-between sm:w-auto sm:justify-end sm:gap-1">
          {SECTIONS.map((s) => (
            <li key={s.id}>
              <a
                href={`#${s.id}`}
                aria-current={current === s.id ? "location" : undefined}
                className={`inline-flex min-h-11 items-center rounded-full px-2 text-[0.875rem] text-bone-muted outline-none transition-colors duration-150 hover:text-bone focus-visible:ring-2 focus-visible:ring-echo aria-[current=location]:text-bone max-[22.5rem]:px-1.5 max-[22.5rem]:text-[0.8125rem] sm:px-3.5 sm:text-[0.9375rem] ${mark ? "" : "aria-[current=location]:underline aria-[current=location]:decoration-bone/60 aria-[current=location]:underline-offset-[0.4em]"}`}
              >
                {s.label}
              </a>
            </li>
          ))}
        </ul>
          {mark ? (
            <span
              aria-hidden
              className="bar-mark"
              data-on={current ? "" : undefined}
              data-jump={mark.jump ? "" : undefined}
              style={{ "--x": `${mark.x}px`, "--w": `${mark.w}px` } as React.CSSProperties}
            />
          ) : null}
        </div>
        {/* Four links plus the toggle cannot hold one bar row on phones once WCAG text spacing inflates them
            (a 17 px overlap at 390): below sm the hero header's copy serves, a scroll to the top away. */}
        <ThemeToggle className="shrink-0 max-sm:hidden" />
      </div>
    </nav>
  );
}
