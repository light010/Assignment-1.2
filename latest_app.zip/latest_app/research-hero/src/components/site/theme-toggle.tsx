"use client";

import { useEffect, useId, useSyncExternalStore } from "react";
import { UI } from "@/content/ui";

const STORE = "theme";
/* The browser chrome follows the page: void around the lab, paper around the record. */
const CHROME = { dark: "#060a0c", light: "#f4f2ee" };

function apply(theme: "dark" | "light") {
  const root = document.documentElement;
  if (theme === "light") root.setAttribute("data-theme", "light");
  else root.removeAttribute("data-theme");
  document.querySelector('meta[name="theme-color"]')?.setAttribute("content", CHROME[theme]);
}

const isLight = () => document.documentElement.getAttribute("data-theme") === "light";

/*
  The theme lives on <html> (set before first paint by the inline script in layout.tsx), so the document is
  the store: both copies of the toggle subscribe to the attribute and can never disagree. While no choice is
  stored, the system preference is followed live; a choice ends that.
*/
function subscribe(onChange: () => void) {
  const watcher = new MutationObserver(onChange);
  watcher.observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
  const system = matchMedia("(prefers-color-scheme: light)");
  const follow = (e: MediaQueryListEvent) => {
    try {
      if (localStorage.getItem(STORE)) return;
    } catch {
      /* No storage means no stored choice: follow the system. */
    }
    apply(e.matches ? "light" : "dark");
  };
  system.addEventListener("change", follow);
  return () => {
    watcher.disconnect();
    system.removeEventListener("change", follow);
  };
}

/**
 * Dark is the lab, light is the paper. The icon reads `html[data-theme]` in CSS, so it is right from the
 * first frame; `aria-pressed` says whether "Light theme" is on. The click flips the document, remembers
 * the choice (storage can be unavailable; the theme still changes for this visit), and lets the page
 * cross in 350 ms (globals.css) — never under reduced motion, where the change is a cut.
 */
export function ThemeToggle({ className = "", style }: { className?: string; style?: React.CSSProperties }) {
  const mask = useId();
  const light = useSyncExternalStore(subscribe, isLight, () => false);
  // The pre-paint script can run before the meta tag exists: settle the browser chrome once, after mount.
  useEffect(() => {
    document.querySelector('meta[name="theme-color"]')?.setAttribute("content", CHROME[isLight() ? "light" : "dark"]);
  }, []);
  const flip = () => {
    const next = light ? "dark" : "light";
    const root = document.documentElement;
    if (matchMedia("(prefers-reduced-motion: no-preference)").matches) {
      root.setAttribute("data-theme-swap", "");
      window.setTimeout(() => root.removeAttribute("data-theme-swap"), 420);
    }
    apply(next);
    try {
      localStorage.setItem(STORE, next);
    } catch {
      /* The theme still changes for this visit. */
    }
  };
  return (
    <button
      type="button"
      data-needs-js
      aria-pressed={light}
      onClick={flip}
      style={style}
      className={`theme-toggle hit inline-flex min-h-11 min-w-11 items-center justify-center rounded-full text-bone-muted outline-none transition-colors duration-200 hover:text-bone focus-visible:ring-2 focus-visible:ring-echo pointer-fine:min-h-9 pointer-fine:min-w-9 ${className}`}
    >
      {/* The sun is the moon uncovered: one disc, its bite sliding away; the rays reach out once it is whole. */}
      <svg aria-hidden viewBox="0 0 24 24" className="size-5" fill="none">
        <mask id={mask}>
          <rect width="24" height="24" fill="#fff" />
          <circle className="tt-bite" cx="16.5" cy="7.5" r="5.5" fill="#000" />
        </mask>
        <circle cx="12" cy="12" r="5.4" fill="currentColor" mask={`url(#${mask})`} className="tt-core" />
        <g className="tt-rays" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
          <line x1="12" y1="2.2" x2="12" y2="4.4" />
          <line x1="12" y1="19.6" x2="12" y2="21.8" />
          <line x1="2.2" y1="12" x2="4.4" y2="12" />
          <line x1="19.6" y1="12" x2="21.8" y2="12" />
          <line x1="5.1" y1="5.1" x2="6.6" y2="6.6" />
          <line x1="17.4" y1="17.4" x2="18.9" y2="18.9" />
          <line x1="17.4" y1="6.6" x2="18.9" y2="5.1" />
          <line x1="5.1" y1="18.9" x2="6.6" y2="17.4" />
        </g>
      </svg>
      <span className="sr-only">{UI.theme.light}</span>
    </button>
  );
}
