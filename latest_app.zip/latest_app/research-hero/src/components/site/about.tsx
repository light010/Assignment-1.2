import { updates } from "@/content/about";
import { person } from "@/content/person";
import { UI } from "@/content/ui";
import { dateLabel, shown } from "@/lib/format";
import { CopyButton } from "./copy-button";
import { ASIDE_TRACK, GRID, LABEL_TRACK, READING_TRACK, SHELL, SectionHeading, WIDE_TRACK } from "./layout";

/**
 * About: who, in order. A first-person bio, a copyable third-person bio for talk organizers, the dated
 * record of positions and education, and recent updates. Recognition and service sit higher, directly
 * under the lab. Anything without a confirmed item is left out, so there is never a "coming soon".
 */
export function About() {
  const positions = person.positions.filter((p) => shown(p.title) && shown(p.start));
  const education = person.education.filter((e) => shown(e.degree) && shown(e.end));
  const recent = updates.filter((u) => u.confirmed || process.env.NODE_ENV !== "production");

  return (
    <section id="about" aria-labelledby="about-title" className="pt-(--space-section)">
      <div className={`${SHELL} ${GRID} gap-y-6`}>
        <SectionHeading id="about" title={UI.about.title} />

        <div className={`${LABEL_TRACK} hidden md:block`} aria-hidden />
        <div className={`${READING_TRACK} flex flex-col gap-5`}>
          {shown(person.bio)
            ? person.bio.value.split("\n\n").map((para) => (
                <p key={para.slice(0, 24)} className="font-display text-body text-pretty text-bone">
                  {para}
                </p>
              ))
            : null}
        </div>
        {shown(person.shortBio) ? (
          <aside
            className={`${ASIDE_TRACK} relative isolate self-start rounded-[var(--radius-panel)] bg-ink p-5`}
            aria-labelledby="short-bio-title"
            data-print="plain"
            data-spot
          >
            <h3 id="short-bio-title" className="font-instrument text-label text-bone-muted">
              {UI.about.shortBio}
            </h3>
            <p id="short-bio-text" className="mt-3 text-[0.9375rem] leading-relaxed text-pretty text-bone-soft">
              {person.shortBio.value}
            </p>
            <div className="mt-4" data-print="hide">
              <CopyButton text={person.shortBio.value} label={UI.about.copyShortBio} selectId="short-bio-text" />
            </div>
          </aside>
        ) : null}
      </div>

      <div className={`${SHELL} ${GRID} mt-(--space-block) gap-y-0`}>
        <h3 className={`col-span-full font-display text-h3 font-[400] text-bone`}>{UI.about.positions}</h3>
        {/* The rules between entries draw across, one after another, when the record is first scrolled to. */}
        <ol className="draw-rules col-span-full mt-4" data-reveal>
          {positions.map((p, i) => (
            <li key={p.title.value + p.org} className={`timeline-row ${GRID} border-t border-hairline py-6 first:border-t-0`} style={{ "--i": i } as React.CSSProperties}>
              <p className={`${LABEL_TRACK} font-instrument text-label text-bone-muted`}>
                <time dateTime={p.start.value}>{dateLabel(p.start.value)}</time>–
                {p.end ? <time dateTime={p.end.value}>{dateLabel(p.end.value)}</time> : "present"}
              </p>
              <div className={WIDE_TRACK}>
                <p className="font-display text-title font-[420] text-bone">{p.title.value}</p>
                <p className="mt-1 text-small text-bone-muted">
                  {[p.unit, p.org, p.place].filter(Boolean).join(", ")}
                </p>
                <p className="mt-2 max-w-[34rem] text-small text-pretty text-bone-soft">{p.description}</p>
                {p.link ? (
                  <a href={p.link.href} className="prose-link mt-2 inline-flex min-h-11 items-center text-small text-bone-soft outline-none focus-visible:ring-2 focus-visible:ring-echo">
                    {p.link.label}
                  </a>
                ) : null}
              </div>
            </li>
          ))}
          {education.map((e, i) => (
            <li key={e.degree.value} className={`timeline-row ${GRID} border-t border-hairline py-6`} style={{ "--i": positions.length + i } as React.CSSProperties}>
              <p className={`${LABEL_TRACK} font-instrument text-label text-bone-muted`}>
                <time dateTime={e.end.value}>{dateLabel(e.end.value)}</time>
              </p>
              <div className={WIDE_TRACK}>
                <p className="font-display text-title font-[420] text-bone">{e.degree.value}</p>
                <p className="mt-1 text-small text-bone-muted">{[e.org, e.place].filter(Boolean).join(", ")}</p>
                <p className="mt-2 max-w-[34rem] text-small text-pretty text-bone-soft">{e.description}</p>
                {e.link ? (
                  <a href={e.link.href} className="prose-link mt-2 inline-flex min-h-11 items-center text-small text-bone-soft outline-none focus-visible:ring-2 focus-visible:ring-echo">
                    {e.link.label}
                  </a>
                ) : null}
              </div>
            </li>
          ))}
        </ol>
      </div>

      {recent.length >= 2 ? (
        <div className={`${SHELL} ${GRID} mt-(--space-block) gap-y-0`}>
          <h3 className="col-span-full font-display text-h3 font-[400] text-bone">{UI.about.recent}</h3>
          <ol className="draw-rules col-span-full mt-4" data-reveal>
            {recent.map((u, i) => (
              <li key={u.id} className={`timeline-row ${GRID} border-t border-hairline py-5 first:border-t-0`} style={{ "--i": i } as React.CSSProperties}>
                <p className={`${LABEL_TRACK} font-instrument text-label text-bone-muted`}>
                  <time dateTime={u.date}>{dateLabel(u.date.slice(0, 7))}</time>
                </p>
                <div className={WIDE_TRACK}>
                  <p className="font-display text-title font-[420] text-bone">{u.title}</p>
                  <p className="mt-1 max-w-[34rem] text-small text-pretty text-bone-soft">{u.text}</p>
                  {u.link ? (
                    <a href={u.link.href} className="prose-link mt-1 inline-flex min-h-11 items-center text-small text-bone-soft outline-none focus-visible:ring-2 focus-visible:ring-echo">
                      {u.link.label}
                      <span className="sr-only">: {u.title}</span>
                    </a>
                  ) : null}
                </div>
              </li>
            ))}
          </ol>
        </div>
      ) : null}
    </section>
  );
}
