import { person } from "@/content/person";
import { scholar } from "@/content/scholar";
import { UI } from "@/content/ui";
import { dateLabel } from "@/lib/format";
import { RisingFigure } from "./digits";

/** Scholar's chart can run long; a dozen years fits a phone and still shows the trend. */
const YEARS_SHOWN = 12;
/** The index tiles rank the papers by citations; twenty covers any h-index the snapshot can show. */
const RANKED_SHOWN = 20;
/** Each index chart's scale runs to 2.5 times its line, so the line sits well clear of the baseline; taller bars are cut. */
const HEADROOM = 2.5;

type Vars = React.CSSProperties & Record<`--${string}`, string | number>;

/*
  The Google Scholar readout, built like one of the lab's instruments: a header naming the source with the date it
  was read (where the lab's readouts say "Simulated"), then three tiles. Citations holds the total, Scholar's
  "since" figure, and citations per year as a stem plot in a black well (one sample per year, the way a sampled
  signal is drawn). h-index and i10-index each hold the index, what it counts in words, and the papers ranked by
  citations against the line that defines it, the papers that count drawn bright. Hue stays out: citations are
  neither light nor sound. A year still running is hollow and dashed and says "so far", so it never reads as a
  decline.
  Everything comes from the committed snapshot at build time, so the numbers are in the HTML. As each tile first
  comes into view its figure rises into place from blank (never showing a number it isn't), the stems rise year by
  year from zero, and each index's line draws across, lighting the papers that reach it as it passes (globals.css,
  "Motion below the lab"); with reduced motion, all of it is simply there.
*/
export function ScholarReadout() {
  const { totals, recent, byYear, checkedAt, articles } = scholar;
  const years = byYear.slice(-YEARS_SHOWN);
  const max = Math.max(1, ...years.map((y) => y.citations));
  const checked = checkedAt.slice(0, 10);
  const running = Number(checked.slice(0, 4));
  const partial = years.at(-1)?.year === running;

  // Scholar's counts, ranked. A tile draws them only when they give Scholar's own index: a profile can list more
  // papers than the snapshot holds, and a drawing that disagrees with the figure beside it would be worse than none.
  const ranked = articles
    .map((a) => a.citedBy)
    .sort((a, b) => b - a)
    .slice(0, RANKED_SHOWN);
  const h = ranked.filter((c, i) => c >= i + 1).length;
  const i10 = ranked.filter((c) => c >= 10).length;

  return (
    <div className="scholar" data-reveal>
      <div className="panel-head">
        <p>{UI.scholar.label}</p>
        <p className="scholar-checked">
          <span aria-hidden className="live-dot" />
          <time dateTime={checkedAt} data-checked>
            {UI.scholar.checked(dateLabel(checked))}
          </time>
        </p>
      </div>
      <dl className="scholar-body">
        <div className="tile tile-cites" data-spot data-reveal="late">
          <dt className="tile-label">{UI.scholar.citations}</dt>
          <dd className="tile-figure">
            <RisingFigure value={totals.citations} />
          </dd>
          <dd className="tile-note">{UI.scholar.since(recent.citations, recent.since)}</dd>
          <dd className="tile-chart">
            <div className="scholar-well">
              <ol className="stems" aria-label={UI.scholar.perYear}>
                {years.map((y, i) => (
                  <li
                    key={y.year}
                    style={{ "--v": (y.citations / max).toFixed(3), "--i": i } as Vars}
                    data-partial={partial && y.year === running ? "" : undefined}
                  >
                    {/* In a narrow well the label shortens to "’18"; screen readers still hear the full year. */}
                    <span className="stem-year">
                      <span className="stem-year-full">{y.year}</span>
                      <span aria-hidden className="stem-year-short">{`’${String(y.year).slice(2)}`}</span>
                    </span>
                    <span className="stem-value">
                      {y.citations}
                      <span className="sr-only">{` ${UI.scholar.citationWord(y.citations)}${partial && y.year === running ? ` ${UI.scholar.soFar}` : ""}`}</span>
                    </span>
                  </li>
                ))}
              </ol>
            </div>
            <span aria-hidden className="tile-caption">
              {UI.scholar.perYear}
              {partial ? ` (${running} ${UI.scholar.soFar})` : ""}
            </span>
          </dd>
        </div>
        <IndexTile
          label={UI.scholar.hIndex}
          value={totals.hIndex}
          meaning={UI.scholar.hMeaning(totals.hIndex)}
          line={totals.hIndex}
          bars={h === totals.hIndex ? ranked.map((c, i) => ({ c, on: i < h })) : null}
        />
        <IndexTile
          label={UI.scholar.i10Index}
          value={totals.i10Index}
          meaning={UI.scholar.i10Meaning(totals.i10Index)}
          line={10}
          bars={i10 === totals.i10Index ? ranked.map((c) => ({ c, on: c >= 10 })) : null}
        />
      </dl>
      <p className="scholar-foot">
        <a href={person.links.scholar} className="label-link hit text-small">
          {UI.scholar.profile}
        </a>
      </p>
    </div>
  );
}

/**
 * One index: its figure, what it counts, and the ranked papers against its line (the value for the h-index, 10 for
 * the i10-index), those that count drawn bright. The scale runs to HEADROOM times the line; a bar taller than that is
 * cut, with a break near its top (data-over). The drawing repeats the words, so it is hidden from screen readers.
 */
function IndexTile({
  label,
  value,
  meaning,
  line,
  bars,
}: {
  label: string;
  value: number;
  meaning: string;
  line: number;
  bars: Array<{ c: number; on: boolean }> | null;
}) {
  const range = Math.max(1, line) * HEADROOM;
  return (
    <div className="tile" data-spot data-reveal="late">
      <dt className="tile-label">{label}</dt>
      <dd className="tile-figure">
        <RisingFigure value={value} />
      </dd>
      <dd className="tile-note">{meaning}</dd>
      {bars && bars.some((b) => b.on) ? (
        <dd aria-hidden className="ranks" data-line={line} style={{ "--t": (line / range).toFixed(3), "--n": bars.length } as Vars}>
          {bars.map(({ c, on }, i) => (
            <span
              key={i}
              data-on={on ? "" : undefined}
              data-over={c > range ? "" : undefined}
              style={{ "--v": Math.min(1, c / range).toFixed(3), "--i": i } as Vars}
            />
          ))}
        </dd>
      ) : null}
    </div>
  );
}
