import { person } from "@/content/person";
import { SIMULATION_NOTE, UPDATED } from "@/content/site";
import { UI } from "@/content/ui";
import { shown } from "@/lib/format";
import { GRID, SHELL } from "./layout";

/** The colophon: who, what the lab images are, when this was last updated, and the way back up. */
export function Footer({ labNote = true }: { labNote?: boolean }) {
  return (
    <footer className="mt-(--space-section) pb-12">
      <div className={`${SHELL} ${GRID} gap-y-6 border-t border-hairline pt-10`}>
        <div className="col-span-4 md:col-span-3">
          <p className="font-display text-[1.1875rem] italic text-bone">{person.name}</p>
          {shown(person.role) ? <p className="mt-1 text-small text-bone-muted">{person.role.value}</p> : null}
        </div>
        <div className="col-span-4 flex flex-col gap-2 text-small text-bone-muted md:col-span-5 lg:col-span-6">
          {labNote ? <p className="max-w-[34em] text-pretty">{SIMULATION_NOTE}</p> : null}
          <p className="text-bone-dim">
            {UI.footer.updated} <time dateTime={UPDATED.iso}>{UPDATED.label}</time>. © {UPDATED.iso.slice(0, 4)} {person.name}.
          </p>
        </div>
        <nav aria-label="Footer" className="col-span-4 md:col-span-8 lg:col-span-3" data-print="hide">
          <ul className="flex flex-wrap gap-x-5 lg:flex-col lg:items-end">
            <li>
              <a href="#top" className="inline-flex min-h-11 items-center text-small text-bone-soft underline decoration-bone/30 underline-offset-[0.22em] outline-none hover:decoration-echo focus-visible:ring-2 focus-visible:ring-echo">
                {UI.footer.backToTop}
              </a>
            </li>
            <li>
              <a href={person.links.scholar} className="inline-flex min-h-11 items-center text-small text-bone-soft underline decoration-bone/30 underline-offset-[0.22em] outline-none hover:decoration-echo focus-visible:ring-2 focus-visible:ring-echo">
                {UI.footer.scholar}
              </a>
            </li>
            {shown(person.email) ? (
              <li>
                <a href={`mailto:${person.email.value}`} className="inline-flex min-h-11 items-center text-small text-bone-soft underline decoration-bone/30 underline-offset-[0.22em] outline-none hover:decoration-echo focus-visible:ring-2 focus-visible:ring-echo">
                  {UI.footer.email}
                </a>
              </li>
            ) : null}
          </ul>
        </nav>
      </div>
    </footer>
  );
}
