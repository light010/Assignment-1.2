"use client";

import { useState } from "react";

/**
 * A count that answers a change: the old number leaves and the new one takes its place in a window one line tall
 * (globals.css, .rolling), upward when the count rises and downward when it falls, in 220 ms. The new number is the
 * text; the leaving one is drawing only, and with reduced motion it isn't drawn at all.
 */
export function Rolling({ value }: { value: number }) {
  const [roll, setRoll] = useState({ now: value, was: null as number | null, turns: 0 });
  // Derived from the previous render, as React recommends for values that follow a prop.
  if (roll.now !== value) setRoll({ now: value, was: roll.now, turns: roll.turns + 1 });
  return (
    <span className="rolling" data-down={roll.was !== null && roll.now < roll.was ? "" : undefined}>
      {roll.was !== null ? (
        <span key={`was-${roll.turns}`} aria-hidden className="roll-out" onAnimationEnd={() => setRoll((r) => ({ ...r, was: null }))}>
          {roll.was}
        </span>
      ) : null}
      <span key={`now-${roll.turns}`} className={roll.turns ? "roll-in" : undefined}>
        {roll.now}
      </span>
    </span>
  );
}
