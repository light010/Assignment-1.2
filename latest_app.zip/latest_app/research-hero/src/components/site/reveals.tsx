"use client";

import { useEffect } from "react";

/** A block reveals when its top comes 12% of the screen's height above the bottom edge; a picture or chart
 * (data-reveal="late") when it comes 30% above, so its moment plays where it can be seen. */
const MARGIN = "0px 0px -12% 0px";
const LATE = "0px 0px -30% 0px";
/** The Google Scholar workflow opens an issue after three days without a reading; the readout's dot goes out then too. */
const STALE_MS = 3 * 24 * 60 * 60 * 1000;

/**
 * The page's motion below the lab (design-system/MASTER.md, "Motion"), in one place:
 * - Reveals. Each [data-reveal] block (a section heading, a Scholar tile, a research card, a picture) is drawn at
 *   rest until it is scrolled to, then gets data-in="" and globals.css plays its one moment. A block inside another
 *   reveals no earlier than its container (its top is lower, so it always crosses the line later). Only what is
 *   below the screen when the page settles ever waits: anything already in view, or above it, is marked
 *   data-in="now" at once (it plays nothing), and only then does <html data-reveals> let the stylesheet hold the rest
 *   back. Without this script, with reduced motion, or when printing, nothing is held back.
 * - Smooth scrolling for in-page links (<html data-smooth>), turned on only once the page has loaded, so a link
 *   into the page jumps to its place instead of gliding past everything above it.
 * - A diagram replays its physics when tapped (data-replay; a pointer resting on it does the same in CSS).
 * - Light at the pointer: tiles and cards ([data-spot]) brighten under a fine pointer (--mx, --my).
 * - Freshness: the dot beside Scholar's "Checked" date goes out when the reading is more than three days old.
 */
export function Reveals() {
  useEffect(() => {
    const root = document.documentElement;
    for (const time of document.querySelectorAll<HTMLTimeElement>("[data-checked]")) {
      if (Date.now() - Date.parse(time.dateTime) > STALE_MS) time.parentElement?.setAttribute("data-stale", "");
    }

    let smooth = 0;
    const glide = () => (smooth = requestAnimationFrame(() => root.setAttribute("data-smooth", "")));
    if (document.readyState === "complete") glide();
    else addEventListener("load", glide, { once: true });

    const replay = (e: MouseEvent) => {
      const fig = (e.target as Element | null)?.closest?.<SVGElement>(".fig");
      if (!fig) return;
      fig.removeAttribute("data-replay");
      void fig.getBoundingClientRect();
      fig.setAttribute("data-replay", "");
    };
    document.addEventListener("click", replay);

    let frame = 0;
    let last: PointerEvent | null = null;
    const light = () => {
      frame = 0;
      const e = last;
      const spot = (e?.target as Element | null)?.closest?.<HTMLElement>("[data-spot]");
      if (!e || !spot) return;
      const box = spot.getBoundingClientRect();
      spot.style.setProperty("--mx", `${Math.round(e.clientX - box.left)}px`);
      spot.style.setProperty("--my", `${Math.round(e.clientY - box.top)}px`);
    };
    const onMove = (e: PointerEvent) => {
      if (e.pointerType !== "mouse") return;
      last = e;
      frame ||= requestAnimationFrame(light);
    };
    if (matchMedia("(hover: hover) and (pointer: fine)").matches) document.addEventListener("pointermove", onMove, { passive: true });

    const blocks = Array.from(document.querySelectorAll<HTMLElement>("[data-reveal]"));
    const show = (el: Element, now = false) => el.setAttribute("data-in", now ? "now" : "");
    const showAll = () => blocks.forEach((el) => el.hasAttribute("data-in") || show(el, true));
    const reduce = matchMedia("(prefers-reduced-motion: reduce)");
    const stop = () => {
      removeEventListener("load", glide);
      cancelAnimationFrame(smooth);
      document.removeEventListener("click", replay);
      document.removeEventListener("pointermove", onMove);
      cancelAnimationFrame(frame);
    };
    if (reduce.matches || !("IntersectionObserver" in window)) {
      showAll();
      return stop;
    }
    const watch = (rootMargin: string) => {
      const io: IntersectionObserver = new IntersectionObserver(
        (entries) => {
          for (const e of entries) {
            if (!e.isIntersecting) continue;
            show(e.target);
            io.unobserve(e.target);
          }
        },
        { rootMargin },
      );
      return io;
    };
    const soon = watch(MARGIN);
    const late = watch(LATE);
    for (const el of blocks) {
      if (el.getBoundingClientRect().top < innerHeight) show(el, true);
      else (el.dataset.reveal === "late" ? late : soon).observe(el);
    }
    root.setAttribute("data-reveals", "");
    addEventListener("beforeprint", showAll);
    reduce.addEventListener("change", showAll);

    // When scrolling stops (a link into the page, a fling), anything still waiting that is on screen plays: nothing
    // stays held where it can be seen, however it got there.
    let settle = 0;
    const onScroll = () => {
      window.clearTimeout(settle);
      settle = window.setTimeout(() => {
        for (const el of blocks) {
          if (el.hasAttribute("data-in")) continue;
          const box = el.getBoundingClientRect();
          if (box.top < innerHeight && box.bottom > 0) show(el);
        }
      }, 160);
    };
    addEventListener("scroll", onScroll, { passive: true });

    return () => {
      stop();
      soon.disconnect();
      late.disconnect();
      window.clearTimeout(settle);
      removeEventListener("scroll", onScroll);
      removeEventListener("beforeprint", showAll);
      reduce.removeEventListener("change", showAll);
      // Nothing may stay held once this script is gone (a reload of the component in development).
      root.removeAttribute("data-reveals");
    };
  }, []);
  return null;
}
