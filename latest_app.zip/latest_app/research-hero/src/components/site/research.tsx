import { RESEARCH_DECK, directions } from "@/content/themes";
import type { ResearchDirection } from "@/content/types";
import { UI } from "@/content/ui";
import { shown } from "@/lib/format";
import { keepCompounds } from "@/lib/typeset";
import { DirectionFigure } from "./direction-figure";
import { LAB_NAME, LAB_SLUG, SHELL, SectionHeading } from "./layout";

/**
 * Research: three directions as three cards, in the lab's own order, so each card and its chapter of the lab
 * sit in the same sequence. Each card reads top to bottom in one pass: what it is, the question, what was done,
 * the skills, and two ways on (into the lab, or down to the papers).
 */
export function Research() {
  return (
    <section id="research" aria-labelledby="research-title" className="pt-(--space-section)">
      <div className={SHELL}>
        <div className="grid grid-cols-4 gap-x-4 md:grid-cols-8 md:gap-x-5 lg:grid-cols-12 lg:gap-x-6">
          <SectionHeading id="research" title={UI.research.title} deck={RESEARCH_DECK} />
        </div>
        <ul className="mt-(--space-block) grid gap-4 xl:grid-cols-3 xl:gap-6">
          {directions.map((d, i) => (
            <DirectionCard key={d.id} direction={d} beat={i} />
          ))}
        </ul>
      </div>
    </section>
  );
}

/** `beat`: the card's place in the row, so side by side the three diagrams play a beat apart, in the lab's order. */
function DirectionCard({ direction: d, beat }: { direction: ResearchDirection; beat: number }) {
  return (
    <li
      id={`research-${d.id}`}
      data-reveal="late"
      data-spot
      style={{ "--card": beat } as React.CSSProperties}
      className="card relative isolate grid gap-x-10 gap-y-5 rounded-[var(--radius-panel)] bg-ink p-6 md:grid-cols-2 md:p-8 xl:flex xl:flex-col xl:gap-0"
    >
      <div>
        <DirectionFigure id={d.id} />
        <h3 className="mt-6 font-display text-h3 text-balance font-[400] text-bone">{d.title}</h3>
        {shown(d.where) ? <p className="mt-2 font-instrument text-label text-bone-muted">{d.where.value}</p> : null}
        <p className="mt-5 font-display text-title text-pretty text-bone xl:mt-6">{d.question}</p>
      </div>

      <div className="flex flex-col xl:mt-3 xl:grow">
        <p className="font-display text-summary text-pretty text-bone-soft">{keepCompounds(d.body)}</p>
        <ul className="mt-5 text-small text-bone-soft" aria-label={`${d.title}: ${UI.research.skills.toLowerCase()}`}>
          {d.skills.map((s) => (
            <li key={s} className="border-t border-hairline py-2 first:border-t-0 first:pt-1">
              {keepCompounds(s)}
            </li>
          ))}
        </ul>
        <p className="mt-5 flex flex-wrap items-baseline gap-x-5 gap-y-1 text-small text-bone-muted xl:mt-auto xl:pt-7">
          <span>
            {UI.research.inLab}:{" "}
            {d.chapters.map((c, i) => (
              <span key={c}>
                {i > 0 ? ", " : ""}
                <a href={`#${LAB_SLUG[c]}`} aria-label={`${UI.research.inLab}: ${LAB_NAME[c]}`} className="label-link">
                  {LAB_NAME[c]}
                </a>
              </span>
            ))}
          </span>
          {/* A plain link: the publication list takes it over (it filters in place and moves focus there). */}
          <a href={`/?show=${d.theme}#publications`} className="label-link">
            {UI.research.papers[d.theme]}
          </a>
        </p>
      </div>
    </li>
  );
}
