import type { CSSProperties } from "react";

/*
  Responsive images from the site's own pipelines: lab stills (src/content/renders.ts, scripts/render-stills.mts)
  and the owner's photos (src/content/recognition-photos.ts, scripts/recognition-photos.mts). AVIF first, WebP as
  the fallback every supported browser reads, and the intrinsic size always set so nothing shifts while it loads.
  next/image's optimizer doesn't run in a static export, and these files are already sized and compressed.
*/

export interface PictureSource {
  src: string;
  /** Intrinsic width, for the `w` descriptor. */
  w: number;
}

type Sources = { avif: readonly PictureSource[]; webp: readonly PictureSource[] };

export function Picture({
  sources,
  width,
  height,
  alt,
  sizes,
  art = [],
  className,
  style,
  priority = false,
  eager = false,
}: {
  /** Smallest first, per format. */
  sources: Sources;
  width: number;
  height: number;
  /** Empty when the words around the image already say what it shows. */
  alt: string;
  sizes: string;
  /**
   * Art direction: other crops for other screens, tried in order before the default sources. Each carries
   * its own intrinsic size, so the box is reserved correctly for whichever crop the browser picks.
   */
  art?: ReadonlyArray<{ media: string; sources: Sources; width: number; height: number; sizes?: string }>;
  className?: string;
  style?: CSSProperties;
  /** The first image a visitor sees: fetched early and never lazy. */
  priority?: boolean;
  /** Load now without competing for bandwidth: for pictures one screen down that captures and deep links reach at once. */
  eager?: boolean;
}) {
  const set = (list: readonly PictureSource[]) => list.map((s) => `${s.src} ${s.w}w`).join(", ");
  // A mid-size WebP for browsers that ignore srcset entirely.
  const fallback = sources.webp[Math.min(1, sources.webp.length - 1)];
  return (
    <picture>
      {art.flatMap((a) => [
        <source key={`${a.media}-avif`} media={a.media} type="image/avif" srcSet={set(a.sources.avif)} sizes={a.sizes ?? sizes} width={a.width} height={a.height} />,
        <source key={`${a.media}-webp`} media={a.media} type="image/webp" srcSet={set(a.sources.webp)} sizes={a.sizes ?? sizes} width={a.width} height={a.height} />,
      ])}
      <source type="image/avif" srcSet={set(sources.avif)} sizes={sizes} />
      <source type="image/webp" srcSet={set(sources.webp)} sizes={sizes} />
      <img
        src={fallback.src}
        srcSet={set(sources.webp)}
        sizes={sizes}
        width={width}
        height={height}
        alt={alt}
        loading={priority || eager ? "eager" : "lazy"}
        fetchPriority={priority ? "high" : "auto"}
        decoding="async"
        className={className}
        style={style}
      />
    </picture>
  );
}
