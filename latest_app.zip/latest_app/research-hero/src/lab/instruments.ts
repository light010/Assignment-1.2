import { ARTERY, CYST, FOV, NP_SITES, TUMOR, VEIN } from "./constants";
import {
  CH_APERTURE,
  CH_H,
  CH_T0,
  CH_T1,
  CH_W,
  IMG_H,
  IMG_W,
  MICROGRAPH_SEED,
  mulberry32,
  type ChannelPicture,
  type InstrumentRequest,
  type InstrumentResult,
  type MicrographFilm,
  type PaPicture,
  type Roi,
  type UsPicture,
} from "./instrument-shared";
import type { Beamformer, DesignStep, Lesion, PAMap } from "./state";

/*
  The instruments. Every picture is computed from the same anatomy as the 3D scene:
  - ultrasound: delay-and-sum B-mode vs short-lag spatial coherence (SLSC), with gCNR
    measured from the lesion and background histograms of the image actually shown;
  - photoacoustics: oxygenated (green) and deoxygenated (red) blood, or the particles
    (hot colormap), with melanin-dependent fluence loss and skin reverberation clutter;
  - raw channel data: per-element echoes, with the beamformer's view drawn on top;
  - electron micrographs of each build step.
  This is the math only. It runs in a module worker (instruments.worker.ts), or on the main thread
  when workers aren't available; either way it is reached through instrument-client.ts, which caches
  each variant, so nothing is recomputed while the scene is idle. The canvases are drawn on the page
  (instrument-draw.ts) from the pixels computed here.
*/

export { CH_H, CH_W, IMG_H, IMG_W };
export type { Roi };

/* ---------- small numeric helpers ---------- */

function hash(x: number, y: number) {
  const s = Math.sin(x * 127.1 + y * 311.7) * 43758.5453;
  return s - Math.floor(s);
}
function vnoise(x: number, y: number) {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const fx = x - ix;
  const fy = y - iy;
  const ux = fx * fx * (3 - 2 * fx);
  const uy = fy * fy * (3 - 2 * fy);
  const a = hash(ix, iy);
  const b = hash(ix + 1, iy);
  const c = hash(ix, iy + 1);
  const d = hash(ix + 1, iy + 1);
  return a + (b - a) * ux + (c - a) * uy + (a - b - c + d) * ux * uy;
}
function fbm(x: number, y: number) {
  let s = 0;
  let a = 0.5;
  for (let i = 0; i < 4; i++) {
    s += a * vnoise(x, y);
    x = x * 2.07 + 17.3;
    y = y * 2.07 + 9.1;
    a *= 0.5;
  }
  return s;
}
const clamp01 = (v: number) => Math.min(1, Math.max(0, v));
const smoothstep = (a: number, b: number, v: number) => {
  const t = clamp01((v - a) / (b - a));
  return t * t * (3 - 2 * t);
};

/** Mirrors labTumorField() in the tissue shader (shape, not exact noise). */
export function tumorField(x: number, y: number) {
  const dx = x - TUMOR.x;
  const dy = y - TUMOR.y;
  const a = Math.atan2(dy, dx);
  const r = Math.hypot(dx * 0.84, dy);
  const edge =
    TUMOR.r * (1 + 0.09 * Math.sin(a * 3 + 1.7) + 0.06 * Math.sin(a * 5 - 0.4) + 0.24 * (fbm(x * 2.4 + 3.1, y * 2.4 + 3.1) - 0.5));
  return edge - r;
}

/** Correlated Gaussian field: the point-spread function is wider laterally than axially. */
function gaussianField(w: number, h: number, rand: () => number, lateral = 2, axial = 1) {
  const out = new Float32Array(w * h);
  for (let i = 0; i < w * h; i += 2) {
    const u = Math.max(1e-7, rand());
    const v = rand();
    const m = Math.sqrt(-2 * Math.log(u));
    out[i] = m * Math.cos(2 * Math.PI * v);
    if (i + 1 < out.length) out[i + 1] = m * Math.sin(2 * Math.PI * v);
  }
  const tmp = new Float32Array(w * h);
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      let s = 0;
      for (let k = -lateral; k <= lateral; k++) s += out[y * w + Math.min(w - 1, Math.max(0, x + k))] * (1 - Math.abs(k) / (lateral + 1));
      tmp[y * w + x] = s;
    }
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      let s = 0;
      for (let k = -axial; k <= axial; k++) s += tmp[Math.min(h - 1, Math.max(0, y + k)) * w + x] * (1 - Math.abs(k) / (axial + 1));
      out[y * w + x] = s;
    }
  return out;
}

function boxBlur(src: Float32Array, w: number, h: number, r: number) {
  const tmp = new Float32Array(w * h);
  const out = new Float32Array(w * h);
  for (let y = 0; y < h; y++) {
    let acc = 0;
    for (let x = -r; x <= r; x++) acc += src[y * w + Math.min(w - 1, Math.max(0, x))];
    for (let x = 0; x < w; x++) {
      tmp[y * w + x] = acc / (2 * r + 1);
      acc += src[y * w + Math.min(w - 1, x + r + 1)] - src[y * w + Math.max(0, x - r)];
    }
  }
  for (let x = 0; x < w; x++) {
    let acc = 0;
    for (let y = -r; y <= r; y++) acc += tmp[Math.min(h - 1, Math.max(0, y)) * w + x];
    for (let y = 0; y < h; y++) {
      out[y * w + x] = acc / (2 * r + 1);
      acc += tmp[Math.min(h - 1, y + r + 1) * w + x] - tmp[Math.max(0, y - r) * w + x];
    }
  }
  return out;
}

/** Pixel <-> world mapping for an imaging plane centred on x0. */
function worldAt(i: number, j: number, x0: number, w = IMG_W, h = IMG_H) {
  return { x: x0 + ((i / (w - 1)) * 2 - 1) * FOV.halfWidth, y: -(j / (h - 1)) * FOV.depth };
}
function pixelOf(x: number, y: number, x0: number, w = IMG_W, h = IMG_H) {
  return { i: ((x - x0) / FOV.halfWidth + 1) * 0.5 * (w - 1), j: (-y / FOV.depth) * (h - 1) };
}

/* ---------- anatomy as the probe hears it ---------- */

interface Echo {
  /** Echogenicity (backscatter amplitude) 0..~1.2. */
  e: number;
  /** 1 inside the lesion. */
  lesion: number;
}

function echogenicity(x: number, y: number, lesion: Lesion | "both"): Echo {
  const depth = -y;
  const n = fbm(x * 3.1, y * 3.1);
  let e = 0.34 + 0.12 * n;
  if (depth < 0.035) e = 1.2;
  else if (depth < 0.34) e = 0.52 + 0.3 * Math.max(0, Math.sin(y * 70 + n * 6));
  const fascia = 0.6 + 0.05 * Math.sin(x * 2.1) + 0.03 * n;
  e += 0.5 * Math.exp(-(((depth - fascia) / 0.014) ** 2));
  e += 0.35 * Math.exp(-(((depth - (2.62 + 0.06 * Math.sin(x * 1.3 + 1))) / 0.02) ** 2));

  const da = Math.abs(y - ARTERY.y);
  if (da < ARTERY.r - 0.01) e = 0.02;
  else if (da < ARTERY.r + 0.035) e = 1.1;
  const dv = Math.hypot(x - VEIN.x, y - VEIN.y);
  if (dv < VEIN.r - 0.01) e = 0.03;
  else if (dv < VEIN.r + 0.03) e = Math.max(e, 0.9);

  let inside = 0;
  if (lesion === "cyst" || lesion === "both") {
    const dc = Math.hypot(x - CYST.x, y - CYST.y);
    if (dc < CYST.r) {
      e = 0;
      inside = 1;
    } else if (dc < CYST.r + 0.03 && y < CYST.y) e = Math.max(e, 1.1);
    // Posterior acoustic enhancement below the fluid
    if (y < CYST.y - CYST.r * 0.5 && Math.abs(x - CYST.x) < CYST.r * 0.8 && dc >= CYST.r) e *= 1.55;
  }
  if (lesion === "solid" || lesion === "both") {
    const tf = tumorField(x, y);
    if (tf > 0) {
      // Hypoechoic: dark in B-mode, much like a cluttered cyst (which is why the two get confused)
      e = 0.045 + 0.04 * fbm(x * 6, y * 6);
      inside = 1;
    }
    e += 0.2 * Math.exp(-((tf / 0.035) ** 2));
    if (y < TUMOR.y && Math.abs(x - TUMOR.x) < TUMOR.r * 0.75 && tf < 0)
      e *= 0.5 + 0.5 * Math.min(1, Math.abs(x - TUMOR.x) / (TUMOR.r * 0.75)) ** 2;
  }
  return { e: e * Math.exp(-depth * 0.2), lesion: inside };
}

/* ---------- gCNR ---------- */

/** Generalized CNR: 1 minus the overlap of the lesion and background intensity histograms. */
export function gcnr(img: Float32Array, w: number, a: Roi, b: Roi, bins = 48) {
  const ha = new Float32Array(bins);
  const hb = new Float32Array(bins);
  let na = 0;
  let nb = 0;
  for (let j = 0; j < IMG_H; j++)
    for (let i = 0; i < w; i++) {
      const v = img[j * w + i];
      const bin = Math.min(bins - 1, Math.floor(clamp01(v) * bins));
      if ((i - a.x) ** 2 + (j - a.y) ** 2 < a.r * a.r) {
        ha[bin]++;
        na++;
      } else if ((i - b.x) ** 2 + (j - b.y) ** 2 < b.r * b.r) {
        hb[bin]++;
        nb++;
      }
    }
  let overlap = 0;
  for (let k = 0; k < bins; k++) overlap += Math.min(ha[k] / Math.max(1, na), hb[k] / Math.max(1, nb));
  return 1 - overlap;
}

/* ---------- ultrasound: B-mode vs coherence ---------- */

export interface UsImage {
  values: Float32Array<ArrayBuffer>;
  lesionRoi: Roi;
  backgroundRoi: Roi;
  gcnr: number;
  centerX: number;
}

export function ultrasoundImage(lesion: Lesion, beamformer: Beamformer): UsImage {
  const x0 = lesion === "cyst" ? CYST.x : TUMOR.x;
  const w = IMG_W;
  const h = IMG_H;
  const rand = mulberry32(lesion === "cyst" ? 101 : 202);
  const g1 = gaussianField(w, h, rand, 2, 1);
  const g2 = gaussianField(w, h, rand, 2, 1);
  const c1 = gaussianField(w, h, rand, 3, 2);
  const values = new Float32Array(w * h);
  const echo = new Float32Array(w * h);
  const clutterAmp = new Float32Array(w * h);

  for (let j = 0; j < h; j++)
    for (let i = 0; i < w; i++) {
      const { x, y } = worldAt(i, j, x0);
      const { e } = echogenicity(x, y, lesion);
      const depth = -y;
      echo[j * w + i] = e;
      // Acoustic clutter: incoherent reverberation, strongest in the near field
      clutterAmp[j * w + i] = 0.11 + 0.1 * Math.exp(-depth * 1.4);
    }

  if (beamformer === "standard") {
    for (let k = 0; k < w * h; k++) {
      const speckle = Math.sqrt(g1[k] * g1[k] + g2[k] * g2[k]) / 2.4;
      const clutter = Math.abs(c1[k]) * clutterAmp[k] * 0.9;
      const amp = echo[k] * speckle + clutter;
      values[k] = clamp01((20 * Math.log10(amp + 1e-3) + 42) / 42) ** 1.1;
    }
  } else {
    // SLSC: coherence depends on signal-to-clutter, not on brightness. It is estimated over a
    // short-lag kernel, so it is smoother than speckle, noisier where coherence is low, and
    // fluid or clutter-only regions fall toward zero.
    // Tissue scatterers stay coherent however faint they are in B-mode, so a hypoechoic solid mass
    // blends in; only fluid (no scatterers) and clutter lose coherence.
    const coh = new Float32Array(w * h);
    for (let k = 0; k < w * h; k++) {
      const e = echo[k] > 0.025 ? Math.max(echo[k], 0.26) : echo[k];
      const s2 = e * e;
      const n2 = clutterAmp[k] * clutterAmp[k] * 0.55;
      const r = s2 / (s2 + n2);
      coh[k] = r + (0.07 + 0.13 * (1 - r)) * c1[k] * 0.9;
    }
    const smooth = boxBlur(coh, w, h, 2);
    const texture = boxBlur(g1, w, h, 2);
    for (let k = 0; k < w * h; k++) values[k] = clamp01(smooth[k] * (0.92 + 0.1 * texture[k]) - 0.03);
  }

  const L = lesion === "cyst" ? CYST : { x: TUMOR.x, y: TUMOR.y, r: TUMOR.r * 0.8 };
  const lc = pixelOf(L.x, L.y, x0);
  const pxPerUnit = (w - 1) / (FOV.halfWidth * 2);
  const lesionRoi = { x: lc.i, y: lc.j, r: L.r * 0.62 * pxPerUnit };
  // Background ROI: same depth and size, beside the lesion (away from the vein)
  const side = lesion === "cyst" ? 1 : 1;
  const bc = pixelOf(L.x + side * (L.r + 0.5), L.y, x0);
  const backgroundRoi = { x: Math.min(w - lesionRoi.r - 4, bc.i), y: bc.j, r: lesionRoi.r };
  return { values, lesionRoi, backgroundRoi, gcnr: gcnr(values, w, lesionRoi, backgroundRoi), centerX: x0 };
}

/* ---------- photoacoustics ---------- */

export interface PaImage {
  /** Greyscale ultrasound underlay, 0..1. */
  base: Float32Array<ArrayBuffer>;
  /** RGBA overlay: coloured absorbers + clutter. */
  overlay: Uint8ClampedArray<ArrayBuffer>;
  /** The same overlay with clutter toned down, for the in-scene hologram. */
  holo: Uint8ClampedArray<ArrayBuffer>;
  visibility: number;
  clutter: number;
  /** Share of the light that gets through the skin's melanin (1 for lighter skin), 0..1. */
  light: number;
  centerX: number;
}

/** The ultrasound underlay every photoacoustic variant shares: computed once, kept for the next variant. */
let paBase: Float32Array<ArrayBuffer> | null = null;

function hot(v: number): [number, number, number] {
  const t = clamp01(v);
  return [Math.min(1, t * 2.6) * 255, clamp01(t * 2.4 - 0.75) * 250, clamp01(t * 3 - 2.1) * 255];
}

export function photoacousticImage(map: PAMap | "both", melanin: number, beamformer: Beamformer): PaImage {
  const x0 = TUMOR.x;
  const w = IMG_W;
  const h = IMG_H;
  if (!paBase) {
    const rand = mulberry32(7);
    const g1 = gaussianField(w, h, rand, 2, 1);
    const g2 = gaussianField(w, h, rand, 2, 1);
    paBase = new Float32Array(w * h);
    for (let j = 0; j < h; j++)
      for (let i = 0; i < w; i++) {
        const { x, y } = worldAt(i, j, x0);
        const { e } = echogenicity(x, y, "solid");
        const k = j * w + i;
        const s = Math.sqrt(g1[k] * g1[k] + g2[k] * g2[k]) / 2.4;
        paBase[k] = clamp01((20 * Math.log10(e * s + 1e-3) + 40) / 40) ** 1.15 * 0.8;
      }
  }

  const rand = mulberry32(31 + Math.round(melanin * 10));
  // Clutter is correlated along the array (reverberation), so it smears into horizontal streaks
  const haze = gaussianField(w, h, rand, 14, 2);
  const coherent = beamformer === "coherence";
  const overlay = new Uint8ClampedArray(w * h * 4);
  const holo = new Uint8ClampedArray(w * h * 4);
  const blobRand = mulberry32(29);
  const blobs = NP_SITES.flatMap(([sx, sy, wt]) =>
    Array.from({ length: 4 }, () => ({
      x: sx + (blobRand() - 0.5) * 0.34,
      y: sy + (blobRand() - 0.5) * 0.28,
      sx: 0.05 + blobRand() * 0.09,
      sy: 0.04 + blobRand() * 0.06,
      w: wt * (0.35 + blobRand() * 0.65),
    })),
  );
  // Small vessels: oxygen-rich in healthy tissue, oxygen-poor (hypoxic) inside the tumor
  const micro = Array.from({ length: 30 }, () => {
    const inside = blobRand() < 0.45;
    const a = blobRand() * Math.PI * 2;
    const d = Math.sqrt(blobRand()) * TUMOR.r * 0.8;
    const x = inside ? TUMOR.x + Math.cos(a) * d : x0 + (blobRand() - 0.5) * 2.9;
    const y = inside ? TUMOR.y + Math.sin(a) * d * 0.9 : -0.55 - blobRand() * 2.2;
    const hypoxic = tumorField(x, y) > 0;
    return { x, y, r: 0.045 + blobRand() * 0.05, len: 0.08 + blobRand() * 0.16, ang: blobRand() * Math.PI, oxy: hypoxic ? 0.12 : 0.88 };
  });

  // Melanin sits in the outer skin: it takes a fixed share of the light at the surface, and tissue
  // attenuates what is left with depth.
  const skinTransmission = Math.exp(-2 * melanin);
  const skinAmp = 0.35 + 0.95 * melanin;
  // Coherence keeps weak but consistent signals: display saturates instead of scaling with fluence
  const shown = (v: number) => (coherent ? v / (v + 0.035) : v);
  let targetSum = 0;
  let targetN = 0;
  let clutterSum = 0;
  let clutterN = 0;
  const target = map === "particles" ? { x: TUMOR.x, y: TUMOR.y, r: TUMOR.r * 0.55 } : { x: VEIN.x, y: VEIN.y, r: VEIN.r };

  for (let j = 0; j < h; j++)
    for (let i = 0; i < w; i++) {
      const { x, y } = worldAt(i, j, x0);
      const depth = -y;
      const k = j * w + i;
      const fluence = Math.exp(-depth * 0.5) * skinTransmission;
      const texture = 0.8 + 0.35 * (fbm(x * 7 + 3, y * 7 + 1) - 0.5);

      let oxy = 0;
      let deoxy = 0;
      const da = Math.abs(y - ARTERY.y);
      oxy += (Math.exp(-(((da - ARTERY.r * 0.9) / 0.05) ** 2)) * 0.9 + (da < ARTERY.r ? 0.42 : 0)) * texture;
      const dv = Math.hypot(x - VEIN.x, y - VEIN.y);
      deoxy += (Math.exp(-(((dv - VEIN.r * 0.82) / 0.04) ** 2)) * 0.9 + (dv < VEIN.r ? 0.55 : 0)) * texture;
      for (const v of micro) {
        const ca = Math.cos(v.ang);
        const sa = Math.sin(v.ang);
        const u = (x - v.x) * ca + (y - v.y) * sa;
        const q = -(x - v.x) * sa + (y - v.y) * ca;
        const g = Math.exp(-((u / v.len) ** 2) - (q / (v.r * 0.55)) ** 2) * 0.9;
        oxy += g * v.oxy;
        deoxy += g * (1 - v.oxy);
      }
      let np = 0;
      for (const b of blobs) np += b.w * Math.exp(-(((x - b.x) / b.sx) ** 2 + ((y - b.y) / b.sy) ** 2));
      np *= clamp01((tumorField(x, y) + 0.06) / 0.14) * (0.55 + 0.6 * fbm(x * 9 + 2, y * 9 + 5));
      const skin = Math.exp(-(((depth - 0.02) / 0.016) ** 2)) * skinAmp;

      // Clutter from the ringing skin: reverberation bands under it, plus a soft haze; both grow with melanin
      let bands = 0;
      for (let r = 1; r <= 4; r++) bands += Math.exp(-(((depth - r * 0.34) / 0.026) ** 2)) * (0.9 / r) * (0.55 + 0.6 * fbm(x * 1.8 + r, r * 3.1));
      const clutterRaw = (bands * skinAmp * 0.6 + Math.abs(haze[k]) * (0.03 + 0.26 * melanin) * Math.exp(-depth * 0.35)) * (0.35 + 0.65 * melanin);
      const cl = clutterRaw * (coherent ? 0.1 : 1);

      const sO = shown(oxy * fluence);
      const sD = shown(deoxy * fluence);
      const sN = shown(np * fluence * 1.25);

      const dT = Math.hypot(x - target.x, y - target.y);
      if (dT < target.r) {
        targetSum += map === "particles" ? sN : sD;
        targetN++;
      } else if (Math.abs(depth + target.y) < target.r && dT < target.r * 3) {
        clutterSum += cl;
        clutterN++;
      }

      for (const [out, clutterK] of [
        [overlay, 1.15],
        [holo, 0.16],
      ] as const) {
        let r = 0;
        let g = 0;
        let b = 0;
        let a = 0;
        const add = (cr: number, cg: number, cb: number, v: number) => {
          const al = smoothstep(0.06, 0.45, v);
          r = r * (1 - al) + cr * al;
          g = g * (1 - al) + cg * al;
          b = b * (1 - al) + cb * al;
          a = Math.max(a, al);
        };
        add(214, 208, 198, cl * clutterK);
        if (map === "oxygenation" || map === "both") {
          add(79, 220, 138, sO * 0.95);
          add(255, 74, 74, sD * 0.95);
        }
        if (map === "particles" || map === "both") {
          const [hr, hg, hb] = hot(0.25 + sN * 0.85);
          add(hr, hg, hb, sN * 0.95);
        }
        add(236, 231, 223, skin * 0.75 * (coherent ? 0.75 : 1));
        out[k * 4] = r;
        out[k * 4 + 1] = g;
        out[k * 4 + 2] = b;
        out[k * 4 + 3] = a * 235;
      }
    }

  const targetMean = targetSum / Math.max(1, targetN);
  const clutterMean = clutterSum / Math.max(1, clutterN);
  return {
    base: paBase,
    overlay,
    holo,
    visibility: clamp01(targetMean / (targetMean + clutterMean * 1.6 + 0.03)),
    clutter: clamp01(clutterMean * 2.2),
    light: skinTransmission,
    centerX: x0,
  };
}

/* ---------- raw channel data ---------- */

/** Per-element RF echoes (signed, -1..1): element across, time (depth) down. */
export function channelData(lesion: Lesion): Float32Array<ArrayBuffer> {
  const rand = mulberry32(lesion === "cyst" ? 5 : 6);
  const L = lesion === "cyst" ? CYST : TUMOR;
  const x0 = L.x;
  const data = new Float32Array(CH_W * CH_H);
  const scatterers: Array<{ x: number; z: number; a: number }> = [];
  // Diffuse tissue scatterers around the lesion depth window, none inside fluid
  for (let n = 0; n < 150; n++) {
    const x = x0 + (rand() - 0.5) * 2.6;
    const z = 0.9 + rand() * 1.9;
    const inside = lesion === "cyst" ? Math.hypot(x - CYST.x, -z - CYST.y) < CYST.r : tumorField(x, -z) > 0;
    if (inside && lesion === "cyst") continue;
    scatterers.push({ x, z, a: (rand() - 0.5) * (inside ? 0.9 : 0.7) });
  }
  // Specular lesion walls and the artery wall
  for (let n = 0; n < 9; n++) {
    const a = Math.PI * (0.15 + 0.7 * (n / 8));
    scatterers.push({ x: L.x + Math.cos(a) * L.r, z: -(L.y + Math.sin(a) * L.r), a: 1.6 });
  }
  scatterers.push({ x: x0, z: -(ARTERY.y - ARTERY.r), a: 2.2 });
  for (const s of scatterers) {
    for (let e = 0; e < CH_W; e++) {
      const xe = x0 + ((e / (CH_W - 1)) * 2 - 1) * CH_APERTURE;
      const t = (s.z + Math.hypot(s.z, xe - s.x)) / 2;
      const row = ((t - CH_T0) / (CH_T1 - CH_T0)) * CH_H;
      const r0 = Math.floor(row);
      for (let dr = -4; dr <= 4; dr++) {
        const rr = r0 + dr;
        if (rr < 0 || rr >= CH_H) continue;
        const ph = rr - row;
        data[rr * CH_W + e] += s.a * Math.exp(-(ph * ph) / 5) * Math.cos(ph * 1.6);
      }
    }
  }
  // Incoherent clutter: independent on every element, strongest where the cyst sits
  for (let rr = 0; rr < CH_H; rr++) {
    const t = CH_T0 + (rr / CH_H) * (CH_T1 - CH_T0);
    const inLesionWindow = Math.abs(t - -L.y) < L.r ? 1 : 0;
    const amp = 0.08 + (lesion === "cyst" ? 0.3 : 0.06) * inLesionWindow;
    for (let e = 0; e < CH_W; e++) data[rr * CH_W + e] += (rand() - 0.5) * amp;
  }
  let peak = 0;
  for (const v of data) peak = Math.max(peak, Math.abs(v));
  for (let k = 0; k < data.length; k++) data[k] = Math.tanh((data[k] / peak) * 2.4);
  return data;
}

/** Normalised correlation of neighbouring elements over a short window at one depth row. */
export function neighbourCoherence(data: Float32Array, row: number, half = 6) {
  const out = new Float32Array(CH_W - 1);
  for (let e = 0; e < CH_W - 1; e++) {
    let ab = 0;
    let aa = 0;
    let bb = 0;
    for (let r = Math.max(0, row - half); r < Math.min(CH_H, row + half); r++) {
      const a = data[r * CH_W + e];
      const b = data[r * CH_W + e + 1];
      ab += a * b;
      aa += a * a;
      bb += b * b;
    }
    out[e] = ab / Math.sqrt(aa * bb + 1e-6);
  }
  return out;
}

/* ---------- electron micrographs ---------- */

/** The carbon support film: the per-pixel part of a micrograph. The particles are drawn on the page. */
export function micrographFilm(step: DesignStep, w = IMG_W, h = IMG_H) {
  const rand = mulberry32(MICROGRAPH_SEED[step]);
  const film = new Uint8ClampedArray(w * h * 4);
  for (let k = 0; k < w * h; k++) {
    const x = k % w;
    const y = Math.floor(k / w);
    const v = 150 + 22 * (fbm(x * 0.02, y * 0.02) - 0.5) + (rand() - 0.5) * 34;
    film[k * 4] = v;
    film[k * 4 + 1] = v;
    film[k * 4 + 2] = v;
    film[k * 4 + 3] = 255;
  }
  return film;
}

/* ---------- pictures, as the page shows them ---------- */

/** Bone-tinted greyscale, as the panel and the scene's imaging plane show it. */
export function ultrasoundPicture(lesion: Lesion, beamformer: Beamformer): UsPicture {
  const img = ultrasoundImage(lesion, beamformer);
  const pixels = new Uint8ClampedArray(IMG_W * IMG_H * 4);
  for (let k = 0; k < IMG_W * IMG_H; k++) {
    const v = img.values[k];
    pixels[k * 4] = 236 * v;
    pixels[k * 4 + 1] = 231 * v;
    pixels[k * 4 + 2] = 223 * v;
    pixels[k * 4 + 3] = 255;
  }
  return { pixels, lesionRoi: img.lesionRoi, backgroundRoi: img.backgroundRoi, gcnr: img.gcnr, centerX: img.centerX };
}

/** The overlay laid over its dimmed ultrasound underlay (the panel), plus the scene's hologram. */
export function photoacousticPicture(map: PAMap | "both", melanin: number, beamformer: Beamformer): PaPicture {
  const img = photoacousticImage(map, melanin, beamformer);
  const pixels = new Uint8ClampedArray(IMG_W * IMG_H * 4);
  for (let k = 0; k < IMG_W * IMG_H; k++) {
    const v = img.base[k] * 0.72;
    const a = img.overlay[k * 4 + 3] / 255;
    pixels[k * 4] = 236 * v * (1 - a) + img.overlay[k * 4] * a;
    pixels[k * 4 + 1] = 231 * v * (1 - a) + img.overlay[k * 4 + 1] * a;
    pixels[k * 4 + 2] = 223 * v * (1 - a) + img.overlay[k * 4 + 2] * a;
    pixels[k * 4 + 3] = 255;
  }
  return { pixels, holo: img.holo, visibility: img.visibility, clutter: img.clutter, light: img.light, centerX: img.centerX };
}

/** Channel data, and the short-lag coherence of neighbouring elements at the lesion's depth. */
export function channelPicture(lesion: Lesion): ChannelPicture {
  const data = channelData(lesion);
  const L = lesion === "cyst" ? CYST : TUMOR;
  const rowC = ((-L.y - CH_T0) / (CH_T1 - CH_T0)) * CH_H;
  return { data, coherence: neighbourCoherence(data, Math.round(rowC), 10) };
}

/** Answers one request; `transfer` lists the buffers that can move to the page without a copy. */
export function computeInstrument(request: InstrumentRequest): { result: InstrumentResult<InstrumentRequest>; transfer: ArrayBuffer[] } {
  switch (request.kind) {
    case "us": {
      const us = ultrasoundPicture(request.lesion, request.beamformer);
      return { result: us, transfer: [us.pixels.buffer] };
    }
    case "pa": {
      const pa = photoacousticPicture(request.map, request.melanin, request.beamformer);
      return { result: pa, transfer: [pa.pixels.buffer, pa.holo.buffer] };
    }
    case "ch": {
      const ch = channelPicture(request.lesion);
      return { result: ch, transfer: [ch.data.buffer, ch.coherence.buffer] };
    }
    case "tem": {
      const tem: MicrographFilm = { film: micrographFilm(request.step) };
      return { result: tem, transfer: [tem.film.buffer] };
    }
  }
}
