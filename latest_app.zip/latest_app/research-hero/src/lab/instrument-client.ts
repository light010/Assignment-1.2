import {
  requestKey,
  type ChannelPicture,
  type InstrumentRequest,
  type InstrumentResult,
  type MicrographFilm,
  type PaPicture,
  type UsPicture,
  type WorkerRequest,
  type WorkerResponse,
} from "./instrument-shared";
import type { Beamformer, DesignStep, Lesion, PAMap } from "./state";

/*
  The page's way to the instruments. Each picture is computed once, in a module worker, and cached
  here for the panel, the metrics and the 3D scene alike. Where workers aren't available, or the
  worker fails to load or crashes, the same math runs on this thread instead (loaded on demand), so
  readouts, captions and images always arrive.
*/

type Result = InstrumentResult<InstrumentRequest>;
type Job = { request: InstrumentRequest; resolve: (r: Result) => void; reject: (e: unknown) => void };

/** Settled pictures, for synchronous reads; and every request made, settled or not. */
const results = new Map<string, Result>();
const requests = new Map<string, Promise<Result>>();
const waiting = new Map<number, Job>();
let worker: Worker | null | undefined;
let nextId = 1;

let math: Promise<typeof import("./instruments")> | undefined;
/** The fallback: one picture per task, so several requests never stack into one long task. */
function computeHere(request: InstrumentRequest) {
  math ??= import("./instruments");
  return math.then((m) => new Promise<Result>((resolve) => setTimeout(() => resolve(m.computeInstrument(request).result), 0)));
}

function settle(job: Job, work: Promise<Result>) {
  work.then(job.resolve, job.reject);
}

function onMessage(e: MessageEvent<WorkerResponse>) {
  const job = waiting.get(e.data.id);
  if (!job) return;
  waiting.delete(e.data.id);
  settle(job, "error" in e.data ? computeHere(job.request) : Promise.resolve(e.data.result));
}

/** The worker didn't load, or crashed: everything it still owed is computed here. */
function onFailure() {
  worker?.terminate();
  worker = null;
  const jobs = [...waiting.values()];
  waiting.clear();
  for (const job of jobs) settle(job, computeHere(job.request));
}

function getWorker() {
  if (worker !== undefined) return worker;
  worker = null;
  if (typeof Worker === "undefined") return worker;
  try {
    const w = new Worker(new URL("./instruments.worker.ts", import.meta.url), { type: "module" });
    w.addEventListener("message", onMessage);
    w.addEventListener("error", onFailure);
    w.addEventListener("messageerror", onFailure);
    worker = w;
  } catch {
    worker = null;
  }
  return worker;
}

export function requestInstrument<R extends InstrumentRequest>(request: R): Promise<InstrumentResult<R>> {
  const key = requestKey(request);
  let pending = requests.get(key);
  if (!pending) {
    const w = getWorker();
    pending = w
      ? new Promise<Result>((resolve, reject) => {
          const id = nextId++;
          waiting.set(id, { request, resolve, reject });
          w.postMessage({ id, request } satisfies WorkerRequest);
        })
      : computeHere(request);
    requests.set(key, pending);
    // A request that failed can be made again.
    pending.then(
      (r) => results.set(key, r),
      () => requests.delete(key),
    );
  }
  return pending as Promise<InstrumentResult<R>>;
}

/** The picture, if it has already been computed. */
export function peekInstrument<R extends InstrumentRequest>(request: R): InstrumentResult<R> | undefined {
  return results.get(requestKey(request)) as InstrumentResult<R> | undefined;
}

export const ultrasound = (lesion: Lesion, beamformer: Beamformer): Promise<UsPicture> =>
  requestInstrument({ kind: "us", lesion, beamformer });
export const photoacoustic = (map: PAMap | "both", melanin: number, beamformer: Beamformer): Promise<PaPicture> =>
  requestInstrument({ kind: "pa", map, melanin, beamformer });
export const channels = (lesion: Lesion): Promise<ChannelPicture> => requestInstrument({ kind: "ch", lesion });
export const micrograph = (step: DesignStep): Promise<MicrographFilm> => requestInstrument({ kind: "tem", step });
