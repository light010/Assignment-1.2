/*
  The lab is a small state machine. React owns the state; the engine eases the scene,
  camera and instruments toward whatever the state says. Every control value is a
  physical change in the scene, the same way the lens lab's focus ring moves the plane.
*/

export type Chapter = "overview" | "design" | "deliver" | "photoacoustic" | "ultrasound";

export type DesignStep = "core" | "gel" | "coat";
export type DesignView = "cut" | "exploded";
export type Particle = "large" | "ultrasmall" | "gel";
export type Elapsed = "minutes" | "hours" | "day";
export type Light = "off" | "pulsed" | "continuous";
export type PAMap = "oxygenation" | "particles";
export type SkinTone = "lighter" | "medium" | "darker";
export type Beamformer = "standard" | "coherence";
export type Lesion = "cyst" | "solid";
export type UsView = "image" | "echoes";

export interface LabState {
  chapter: Chapter;
  design: { step: DesignStep; view: DesignView };
  deliver: { particle: Particle; elapsed: Elapsed; light: Light };
  photoacoustic: { map: PAMap; skin: SkinTone; beamformer: Beamformer };
  ultrasound: { lesion: Lesion; beamformer: Beamformer; view: UsView };
}

export const DEFAULT_STATE: LabState = {
  chapter: "overview",
  design: { step: "gel", view: "cut" },
  deliver: { particle: "gel", elapsed: "hours", light: "off" },
  photoacoustic: { map: "oxygenation", skin: "lighter", beamformer: "standard" },
  ultrasound: { lesion: "cyst", beamformer: "standard", view: "image" },
};

export type SkillChapter = Exclude<Chapter, "overview">;

export const MELANIN: Record<SkinTone, number> = { lighter: 0, medium: 0.5, darker: 1 };
export const ELAPSED: Record<Elapsed, number> = { minutes: 0.3, hours: 1, day: 2 };

/** Guided tour: the states a first-time visitor is walked through, in order. */
export const TOUR: ReadonlyArray<(s: LabState) => LabState> = [
  (s) => ({ ...s, chapter: "design", design: { step: "core", view: "cut" } }),
  (s) => ({ ...s, chapter: "design", design: { step: "gel", view: "cut" } }),
  (s) => ({ ...s, chapter: "design", design: { step: "coat", view: "cut" } }),
  (s) => ({ ...s, chapter: "design", design: { step: "coat", view: "exploded" } }),
  (s) => ({ ...s, chapter: "deliver", deliver: { particle: "large", elapsed: "hours", light: "off" } }),
  (s) => ({ ...s, chapter: "deliver", deliver: { particle: "ultrasmall", elapsed: "day", light: "off" } }),
  (s) => ({ ...s, chapter: "deliver", deliver: { particle: "gel", elapsed: "hours", light: "continuous" } }),
  (s) => ({ ...s, chapter: "photoacoustic", photoacoustic: { map: "oxygenation", skin: "lighter", beamformer: "standard" } }),
  (s) => ({ ...s, chapter: "photoacoustic", photoacoustic: { map: "particles", skin: "darker", beamformer: "standard" } }),
  (s) => ({ ...s, chapter: "photoacoustic", photoacoustic: { map: "particles", skin: "darker", beamformer: "coherence" } }),
  (s) => ({ ...s, chapter: "ultrasound", ultrasound: { lesion: "cyst", beamformer: "standard", view: "image" } }),
  (s) => ({ ...s, chapter: "ultrasound", ultrasound: { lesion: "cyst", beamformer: "coherence", view: "image" } }),
  (s) => ({ ...s, chapter: "ultrasound", ultrasound: { lesion: "solid", beamformer: "coherence", view: "echoes" } }),
];
