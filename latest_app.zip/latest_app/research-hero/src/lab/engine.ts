import * as THREE from "three";
import { EffectComposer } from "three/addons/postprocessing/EffectComposer.js";
import { RenderPass } from "three/addons/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/addons/postprocessing/UnrealBloomPass.js";
import { OutputPass } from "three/addons/postprocessing/OutputPass.js";
import { ShaderPass } from "three/addons/postprocessing/ShaderPass.js";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import { labBus, type Anchor } from "./bus";
import { ARTERY, COLORS, CYST, FACE_Z, LEAK, LOUPE_POS, NP_SITES, TUMOR, VEIN, WAVE_SPEED } from "./constants";
import { DEFAULT_STATE, MELANIN, type LabState } from "./state";
import { channels, photoacoustic, ultrasound } from "./instrument-client";
import { IMG_H, IMG_W, drawChannelData, drawHologram, drawUltrasound } from "./instrument-draw";
import { createTissue } from "./objects/tissue";
import { createFlow } from "./objects/flow";
import { createProbe } from "./objects/probe";
import { createNanoparticle } from "./objects/nanoparticle";
import { createStage } from "./objects/stage";
import { createEchoScreen, createImagingPlane } from "./objects/imaging";

export interface EngineOptions {
  reducedMotion: boolean;
  lowPower: boolean;
  /** The canvas's size and framing when the build starts, so the first frames render at the final size. */
  size?: { w: number; h: number; dpr: number };
  framing?: Framing;
}

export interface Framing {
  /** Where the subject's centre should land, as a fraction of the canvas (0..1, CSS axes). */
  focusX: number;
  focusY: number;
  /** Fraction of the canvas the subject may occupy. */
  usableW: number;
  usableH: number;
}

/** Scene extent the overview camera must keep in frame (world units). */
const EXTENT = { w: 9.9, h: 7.0 };
const LOUPE = new THREE.Vector3(...LOUPE_POS);
/** Seconds the light pulse takes to run down the fibre before the flash. */
const FIBER_TRAVEL = 0.62;
/**
 * Extent of the taken-apart particle as seen from its shot, along its own x axis: the cores' left edge
 * to the coat's right (measured on screen; the coat sits deeper, so it looks narrower than it is).
 */
const EXPLODED = { left: -2.35, right: 3.05 };

interface Shot {
  target: THREE.Vector3;
  az: number;
  el: number;
  dist: number;
}

const finishShader = {
  uniforms: {
    tDiffuse: { value: null },
    uRes: { value: new THREE.Vector2(1, 1) },
    uCenter: { value: new THREE.Vector2(0, 0) },
    uRadius: { value: -1000 },
    uAmp: { value: 0 },
    uTime: { value: 0 },
    uVignette: { value: 0.55 },
    uEcho: { value: new THREE.Color(COLORS.echo) },
  },
  vertexShader: /* glsl */ `
    varying vec2 vUv;
    void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
  `,
  fragmentShader: /* glsl */ `
    uniform sampler2D tDiffuse;
    uniform vec2 uRes, uCenter;
    uniform float uRadius, uAmp, uTime, uVignette;
    uniform vec3 uEcho;
    varying vec2 vUv;
    void main() {
      vec2 px = vUv * uRes;
      vec2 d = px - uCenter;
      float r = length(d);
      float ph = (r - uRadius) / (22.0 * uRes.y / 900.0);
      float nw = -ph * exp(-0.5 * ph * ph);
      vec2 dir = r > 0.001 ? d / r : vec2(0.0);
      vec2 offs = dir * nw * uAmp * 6.0 / uRes;
      vec3 col;
      col.r = texture2D(tDiffuse, vUv + offs * 1.35).r;
      col.g = texture2D(tDiffuse, vUv + offs).g;
      col.b = texture2D(tDiffuse, vUv + offs * 0.7).b;
      col += uEcho * max(nw, 0.0) * uAmp * 0.07;
      vec2 q = (vUv - vec2(0.58, 0.5)) * vec2(1.0, 1.15);
      col *= 1.0 - uVignette * smoothstep(0.1, 0.62, length(q));
      float g = fract(sin(dot(px + fract(uTime) * 91.0, vec2(12.9898, 78.233))) * 43758.5453) - 0.5;
      col += g * 0.016;
      gl_FragColor = vec4(col, 1.0);
    }
  `,
};

const approach = (v: number, goal: number, dt: number, rate: number) => v + (goal - v) * (1 - Math.exp(-dt * rate));

/** Hands the main thread back between build steps, so input is never kept waiting long. */
const yieldToMain = () =>
  new Promise<void>((resolve) => {
    const scheduler = (globalThis as { scheduler?: { yield?: () => Promise<void> } }).scheduler;
    if (scheduler?.yield) scheduler.yield().then(resolve, resolve);
    else setTimeout(resolve, 0);
  });

export class LabEngine {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera: THREE.PerspectiveCamera;
  // Built by build(), before the engine is handed out.
  private composer!: EffectComposer;
  private bloom!: UnrealBloomPass;
  private finish!: ShaderPass;
  private output!: OutputPass;
  private tissue!: ReturnType<typeof createTissue>;
  private flow!: ReturnType<typeof createFlow>;
  private probe!: ReturnType<typeof createProbe>;
  private particle!: ReturnType<typeof createNanoparticle>;
  private stage!: ReturnType<typeof createStage>;
  private plane!: ReturnType<typeof createImagingPlane>;
  private screen!: ReturnType<typeof createEchoScreen>;
  private cursorLight!: THREE.PointLight;
  private tumorLight!: THREE.PointLight;

  private opts: EngineOptions;
  private size = { w: 1, h: 1, dpr: 1 };
  private framing: Framing = { focusX: 0.5, focusY: 0.5, usableW: 0.9, usableH: 0.9 };
  private baseDist = 16;

  private state: LabState = DEFAULT_STATE;
  private time = 0;
  private laserT = -100;
  private paT = -100;
  private usT = -100;
  private nextPulse = 1.7;
  private nextUs = Infinity;
  private userPulse = true;
  private waveEmitted = true;
  private waveWall = -1e9;
  private waveOrigin = new THREE.Vector2();
  private waveSpeed = 600;
  private arrival = 0.7;

  private drive: Record<"melanin" | "heat" | "damage" | "dim" | "plane" | "screen" | "probeX" | "flash" | "lab", number> = {
    lab: 1,
    melanin: 0,
    heat: 0,
    damage: 0,
    dim: 1,
    plane: 0,
    screen: 0,
    probeX: TUMOR.x,
    flash: 0,
  };
  private cam: Shot = { target: new THREE.Vector3(0.95, -0.35, 0.4), az: 0.2, el: 0.2, dist: 1 };
  private goal: Shot = { target: new THREE.Vector3(0.95, -0.35, 0.4), az: 0.2, el: 0.2, dist: 1 };

  private playing = true;
  private active = true;
  private raf = 0;
  private lastWall = 0;
  private disposed = false;
  private pendingFrames = 4;
  private pointer = new THREE.Vector2();
  private pointerTarget = new THREE.Vector2();
  private scroll = 0;
  private scrollTarget = 0;
  private frameTimes: number[] = [];
  private qualityStep = 0;
  private flowSources: Array<[number, number, number]> = [];

  private anchors: Record<string, Anchor> = {};
  private anchorWorld: Record<string, THREE.Vector3> = {};
  private v3 = new THREE.Vector3();
  private v3b = new THREE.Vector3();

  /**
   * Builds the lab a piece at a time, yielding between pieces, and compiles every shader before the
   * first frame, so no single task holds the main thread for long. The canvas stays hidden until
   * frames land (LabCanvas reveals it).
   */
  static async create(canvas: HTMLCanvasElement, opts: EngineOptions) {
    const engine = new LabEngine(canvas, opts);
    await engine.build();
    return engine;
  }

  private constructor(canvas: HTMLCanvasElement, opts: EngineOptions) {
    this.opts = opts;
    const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, alpha: false, powerPreference: "high-performance", stencil: false });
    renderer.setClearColor(COLORS.void, 1);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    renderer.localClippingEnabled = true;
    this.renderer = renderer;
    this.camera = new THREE.PerspectiveCamera(26, 1, 0.3, 90);
  }

  private async build() {
    const { renderer, opts } = this;
    await yieldToMain();
    const pmrem = new THREE.PMREMGenerator(renderer);
    const room = new RoomEnvironment();
    this.scene.environment = pmrem.fromScene(room, 0.04).texture;
    this.scene.environmentIntensity = 0.32;
    room.traverse((o) => (o as THREE.Mesh).geometry?.dispose?.());
    pmrem.dispose();
    this.scene.background = new THREE.Color(COLORS.void);
    this.scene.fog = new THREE.Fog(COLORS.void, 18, 42);

    const key = new THREE.SpotLight(0xfff0de, 520, 0, 0.42, 0.85, 2);
    key.position.set(-5.5, 11, 8.5);
    key.target.position.set(0.8, -1.6, 0.4);
    key.castShadow = true;
    key.shadow.mapSize.setScalar(opts.lowPower ? 1024 : 2048);
    key.shadow.bias = -0.0004;
    key.shadow.normalBias = 0.02;
    key.shadow.radius = 5;
    key.shadow.camera.near = 6;
    key.shadow.camera.far = 30;
    this.scene.add(key, key.target);
    const rim = new THREE.SpotLight(0x9fe6ff, 340, 0, 0.5, 0.9, 2);
    rim.position.set(9, 6.5, -7);
    rim.target.position.set(0.5, -0.5, 0);
    this.scene.add(rim, rim.target);
    const front = new THREE.DirectionalLight(0xffe7d6, 0.35);
    front.position.set(2, 1.5, 10);
    this.scene.add(front);
    this.scene.add(new THREE.HemisphereLight(0x9cc3cf, 0x1c0f0d, 0.35));
    const particleKey = new THREE.PointLight(0xfff2e6, 6, 7, 2);
    particleKey.position.set(LOUPE.x - 1.6, LOUPE.y + 1.8, LOUPE.z + 2.4);
    this.scene.add(particleKey);
    this.cursorLight = new THREE.PointLight(0xffd2ad, 6, 5.5, 2);
    this.scene.add(this.cursorLight);
    const vesselFill = new THREE.PointLight(0xff5a48, 2.4, 3.4, 2);
    vesselFill.position.set(0.4, ARTERY.y + 0.05, FACE_Z + 0.7);
    this.scene.add(vesselFill);
    this.tumorLight = new THREE.PointLight(0xff8a3c, 0, 3.2, 2);
    this.tumorLight.position.set(TUMOR.x, TUMOR.y + 0.1, FACE_Z + 0.45);
    this.scene.add(this.tumorLight);

    await yieldToMain();
    this.stage = createStage({ lowPower: opts.lowPower });
    this.scene.add(this.stage.group);
    await yieldToMain();
    this.tissue = createTissue();
    this.scene.add(this.tissue.group);
    await yieldToMain();
    this.flow = createFlow({ lowPower: opts.lowPower });
    this.scene.add(this.flow.group);
    await yieldToMain();
    this.probe = createProbe();
    this.scene.add(this.probe.group);
    await yieldToMain();
    this.particle = createNanoparticle({ lowPower: opts.lowPower });
    this.particle.root.position.copy(LOUPE);
    this.scene.add(this.particle.root);
    await yieldToMain();
    this.plane = createImagingPlane();
    this.screen = createEchoScreen();
    this.scene.add(this.plane.mesh, this.screen.group);

    const target = new THREE.WebGLRenderTarget(2, 2, { type: THREE.HalfFloatType, samples: opts.lowPower ? 0 : 4 });
    this.composer = new EffectComposer(renderer, target);
    this.composer.addPass(new RenderPass(this.scene, this.camera));
    this.bloom = new UnrealBloomPass(new THREE.Vector2(256, 256), 0.5, 0.5, 1.08);
    this.composer.addPass(this.bloom);
    this.output = new OutputPass();
    this.composer.addPass(this.output);
    this.finish = new ShaderPass(finishShader);
    this.composer.addPass(this.finish);

    if (opts.reducedMotion) {
      // A composed still: rings frozen mid-flight around the tumor.
      this.playing = false;
      this.laserT = -0.7;
      this.paT = this.laserT + 0.05;
      this.nextPulse = Infinity;
    }
    if (opts.framing) this.framing = opts.framing;
    if (opts.size) this.size = { w: Math.max(1, opts.size.w), h: Math.max(1, opts.size.h), dpr: opts.size.dpr };
    this.applySize();
    this.applyState(true);

    // Shaders compile in parallel (KHR_parallel_shader_compile) while the page stays responsive: the
    // scene's, then the post passes'. Then every part of the lab, and every pass, is drawn once.
    await yieldToMain();
    await this.compileOffscreen(this.scene);
    await this.settleGpu();
    await this.compilePasses();
    await this.settleGpu();
    await this.warm();
    if (this.disposed) return;
    this.composer.render(0);
    await this.settleGpu();
    if (this.disposed) return;
    this.lastWall = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  /**
   * Draws everything the lab can show once, offscreen, one part per task, so each program's first use
   * (uniform lookups, buffer uploads, the key light's depth map) happens here rather than in a frame
   * after a click. Parts hidden until a chapter needs them are drawn too, from the overview camera
   * with culling off, and so is the probe's see-through variant (it fades out while designing).
   */
  private async warm() {
    const r = this.renderer;
    this.updateCamera();
    const hidden: THREE.Object3D[] = [];
    const culled: THREE.Object3D[] = [];
    this.scene.traverse((o) => {
      if (!o.visible && !(o as THREE.Light).isLight) {
        hidden.push(o);
        o.visible = true;
      }
      if (o.frustumCulled) {
        culled.push(o);
        o.frustumCulled = false;
      }
    });
    const parts = [this.stage.group, this.tissue.group, this.flow.group, this.probe.group, this.particle.root, this.plane.mesh, this.screen.group];
    const draw = async (only: THREE.Object3D) => {
      for (const part of parts) part.visible = part === only;
      r.setRenderTarget(this.composer.readBuffer);
      r.render(this.scene, this.camera);
      r.setRenderTarget(null);
      await this.settleGpu();
    };
    for (const part of parts) {
      if (this.disposed) return;
      await draw(part);
    }
    this.probe.setPresence(0.5);
    await this.compileOffscreen(this.probe.group);
    await draw(this.probe.group);
    this.probe.setPresence(1);
    for (const part of parts) part.visible = true;
    for (const o of hidden) o.visible = false;
    for (const o of culled) o.frustumCulled = true;

    // Each pass's material, into the kind of target it draws into (the GPU builds a pipeline per
    // shader, target format and blend state).
    const quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2));
    const passes = new THREE.Scene().add(quad);
    const flat = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    const bloom = this.bloom;
    const blurTarget = bloom.renderTargetsHorizontal[0];
    const steps: Array<[THREE.Material, THREE.WebGLRenderTarget | null]> = [
      [bloom.materialHighPassFilter, blurTarget],
      ...bloom.separableBlurMaterials.map((m): [THREE.Material, THREE.WebGLRenderTarget] => [m, blurTarget]),
      [bloom.compositeMaterial, blurTarget],
      [bloom.blendMaterial, this.composer.readBuffer],
      [this.finish.material, null],
    ];
    for (const [material, target] of steps) {
      if (this.disposed) return;
      quad.material = material;
      r.setRenderTarget(target);
      r.render(passes, flat);
      r.setRenderTarget(null);
      await this.settleGpu();
    }
    quad.geometry.dispose();
    // The output pass sets its defines on first use, so it compiles here.
    this.output.render(r, this.composer.writeBuffer, this.composer.readBuffer, 0, false);
    await this.settleGpu();
  }

  /**
   * Resolves once the GPU has worked through everything submitted so far (a fence), without blocking:
   * the page stays free while shaders and pipelines build, and the next step doesn't stall on them.
   */
  private settleGpu() {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    if (!sync) return yieldToMain();
    gl.flush();
    const start = performance.now();
    return new Promise<void>((resolve) => {
      const poll = () => {
        // The status only updates between tasks, so polling from timers never blocks.
        const done = gl.isContextLost() || gl.getSyncParameter(sync, gl.SYNC_STATUS) === gl.SIGNALED || performance.now() - start > 1000;
        if (!done) return void setTimeout(poll, 4);
        if (!gl.isContextLost()) gl.deleteSync(sync);
        resolve();
      };
      setTimeout(poll, 0);
    });
  }

  /**
   * The scene draws into the composer's offscreen target, not the screen, and three builds different
   * programs for the two (tone mapping and color space are applied later, by the output pass), so the
   * programs are compiled with that target bound.
   */
  private compileOffscreen(object: THREE.Object3D) {
    this.renderer.setRenderTarget(this.composer.readBuffer);
    const compiled = this.renderer.compileAsync(object, this.camera, this.scene);
    this.renderer.setRenderTarget(null);
    return compiled;
  }

  /**
   * The post passes draw full-screen quads with their own materials: compile them the way they'll be
   * used, into an offscreen target (bloom) or to the screen (the finish), so the first frame doesn't.
   * The output pass sets its defines on first use and compiles then; it's one small program.
   */
  private async compilePasses() {
    const quad = new THREE.PlaneGeometry(2, 2);
    const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    const scene = (materials: THREE.Material[]) => new THREE.Scene().add(...materials.map((m) => new THREE.Mesh(quad, m)));
    const bloom = this.bloom;
    const offscreen = scene([bloom.materialHighPassFilter, ...bloom.separableBlurMaterials, bloom.compositeMaterial, bloom.blendMaterial]);
    this.renderer.setRenderTarget(this.composer.readBuffer);
    const drawn = this.renderer.compileAsync(offscreen, camera);
    this.renderer.setRenderTarget(null);
    await Promise.all([drawn, this.renderer.compileAsync(scene([this.finish.material]), camera)]);
    quad.dispose();
  }

  /* ---------- public API ---------- */

  setSize(w: number, h: number, dpr: number) {
    w = Math.max(1, w);
    h = Math.max(1, h);
    // Resizing a canvas clears it and reallocates its buffers, even to the same size.
    if (w === this.size.w && h === this.size.h && dpr === this.size.dpr) return;
    this.size = { w, h, dpr };
    this.applySize();
    this.pendingFrames = 2;
  }

  setFraming(framing: Framing) {
    this.framing = framing;
    this.applySize();
    this.pendingFrames = 2;
  }

  setPointer(nx: number, ny: number) {
    if (this.opts.reducedMotion) return;
    this.pointerTarget.set(THREE.MathUtils.clamp(nx, -1, 1), THREE.MathUtils.clamp(ny, -1, 1));
  }

  setScroll(p: number) {
    this.scrollTarget = this.opts.reducedMotion ? 0 : THREE.MathUtils.clamp(p, 0, 1);
  }

  setActive(active: boolean) {
    if (active === this.active) return;
    this.active = active;
    if (active && !this.disposed) {
      this.lastWall = performance.now();
      cancelAnimationFrame(this.raf);
      this.raf = requestAnimationFrame(this.loop);
    }
  }

  setPlaying(playing: boolean) {
    this.playing = playing;
    this.pendingFrames = 1;
    labBus.emit("playing", { playing });
  }

  isPlaying() {
    return this.playing;
  }

  setState(state: LabState) {
    const prev = this.state;
    this.state = state;
    this.applyState(false, prev);
    this.pendingFrames = 3;
  }

  /** Answer a click: a light pulse turning into sound, or in the ultrasound chapter, a transmit. */
  pulse() {
    if (this.state.chapter === "ultrasound") this.nextUs = this.time;
    else {
      this.nextPulse = this.time + FIBER_TRAVEL;
      this.userPulse = true;
    }
    this.pendingFrames = 3;
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.scene.traverse((o) => {
      const mesh = o as THREE.Mesh;
      if (mesh.geometry) mesh.geometry.dispose();
      const mat = mesh.material as THREE.Material | THREE.Material[] | undefined;
      if (Array.isArray(mat)) mat.forEach((m) => m.dispose());
      else mat?.dispose();
    });
    this.scene.environment?.dispose();
    // Disposed mid-build (the visitor left, or the context was lost), the composer may not exist yet.
    this.composer?.dispose();
    this.renderer.dispose();
  }

  /* ---------- state → goals ---------- */

  private applyState(initial: boolean, prev?: LabState) {
    const s = this.state;
    const chapterChanged = !prev || prev.chapter !== s.chapter;

    // Schedule what each chapter does on its own
    if (s.chapter === "photoacoustic" && (chapterChanged || prev?.photoacoustic !== s.photoacoustic)) {
      this.nextPulse = this.time + 0.7 + FIBER_TRAVEL;
    }
    if (s.chapter === "ultrasound" && (chapterChanged || prev?.ultrasound.lesion !== s.ultrasound.lesion)) {
      this.nextUs = this.time + 0.9;
    } else if (s.chapter !== "ultrasound") this.nextUs = Infinity;
    if (s.chapter === "deliver" && s.deliver.light === "pulsed" && prev?.deliver.light !== "pulsed") this.nextPulse = this.time + FIBER_TRAVEL;
    if (s.chapter === "design" && s.design.step === "core" && prev?.design.step !== "core") this.nextPulse = this.time + 1.4;
    if (this.opts.reducedMotion && !initial) this.nextPulse = Infinity;

    this.goalShot(s, this.goal);
    if (initial) {
      this.cam.target.copy(this.goal.target);
      this.cam.az = this.goal.az;
      this.cam.el = this.goal.el;
      this.cam.dist = this.goal.dist;
    }
    this.refreshImages();
  }

  private goalShot(s: LabState, out: Shot) {
    const probeX = this.probeGoalX(s);
    switch (s.chapter) {
      case "overview":
        out.target.set(0.95, -0.35, 0.4);
        out.az = 0.2;
        out.el = 0.2;
        out.dist = 1;
        return;
      case "design": {
        const exploded = s.design.view === "exploded";
        out.target.copy(LOUPE);
        if (exploded) {
          out.az = 0.16;
          out.el = 0.08;
          out.dist = 0.6;
          this.fitExploded(out);
        } else if (s.design.step === "core") {
          out.az = 0.12;
          out.el = 0.08;
          out.dist = 0.3;
        } else if (s.design.step === "gel") {
          out.az = 0.3;
          out.el = 0.16;
          out.dist = 0.34;
        } else {
          out.az = -0.32;
          out.el = 0.3;
          out.dist = 0.38;
        }
        return;
      }
      case "deliver": {
        const lit = s.deliver.light !== "off";
        out.target.set(1.45, lit ? -1.02 : -1.36, FACE_Z);
        out.az = lit ? 0.22 : 0.1;
        out.el = lit ? 0.16 : 0.05;
        out.dist = s.deliver.elapsed === "day" ? 0.56 : lit ? 0.6 : 0.5;
        return;
      }
      case "photoacoustic": {
        const dark = s.photoacoustic.skin === "darker";
        out.target.set(TUMOR.x - 0.35, dark ? -0.62 : -1.02, FACE_Z - 0.2);
        out.az = 0.34;
        out.el = dark ? 0.27 : 0.2;
        out.dist = dark ? 0.56 : 0.64;
        return;
      }
      case "ultrasound": {
        if (s.ultrasound.view === "echoes") {
          out.target.set(probeX + 1.15, 0.5, FACE_Z - 0.4);
          out.az = 0.2;
          out.el = 0.12;
          out.dist = 0.68;
        } else {
          out.target.set(probeX, -1.25, FACE_Z - 0.2);
          out.az = s.ultrasound.lesion === "cyst" ? -0.22 : 0.24;
          out.el = 0.14;
          out.dist = 0.58;
        }
        return;
      }
    }
  }

  /**
   * Taken apart, the three layers sit side by side, wider than the particle and centred right of it.
   * The shot aims at the middle of the row and backs off until all three fit the frame's usable width
   * with a margin (on phones the membrane coat used to be cut off at the right edge).
   */
  private fitExploded(out: Shot) {
    const mid = (EXPLODED.left + EXPLODED.right) / 2;
    const half = ((EXPLODED.right - EXPLODED.left) / 2) * 1.16;
    // Along the camera's right: the particle turns to face the camera, so this is its own x axis.
    out.target.x += Math.cos(out.az) * mid;
    out.target.z -= Math.sin(out.az) * mid;
    const tanV = Math.tan(THREE.MathUtils.degToRad(this.camera.fov / 2));
    const aspect = this.size.w / this.size.h;
    const fit = half / (tanV * aspect * Math.min(1, this.framing.usableW)) / (this.baseDist * 0.985);
    out.dist = Math.max(out.dist, fit);
  }

  private probeGoalX(s: LabState) {
    return s.chapter === "ultrasound" && s.ultrasound.lesion === "cyst" ? CYST.x : TUMOR.x;
  }

  private imageKey = "";
  private refreshImages() {
    const s = this.state;
    const key =
      s.chapter === "photoacoustic"
        ? `pa:${s.photoacoustic.map}:${s.photoacoustic.skin}:${s.photoacoustic.beamformer}`
        : s.chapter === "ultrasound"
          ? `us:${s.ultrasound.lesion}:${s.ultrasound.beamformer}:${s.ultrasound.view}`
          : s.chapter === "overview"
            ? "overview"
            : "";
    if (key === this.imageKey) return;
    this.imageKey = key;
    if (!key) return;
    const stale = () => this.disposed || key !== this.imageKey;
    const canvas = () => {
      const c = document.createElement("canvas");
      c.width = IMG_W;
      c.height = IMG_H;
      return c;
    };
    // The pictures come from the instrument worker; they're put up off the current frame, so a
    // click never stutters the camera move.
    const later = (put: () => void) =>
      setTimeout(() => {
        if (stale()) return;
        put();
        this.pendingFrames = 2;
      }, 30);
    if (key.startsWith("pa") || key === "overview") {
      const pa =
        key === "overview"
          ? photoacoustic("both", 0, "standard")
          : photoacoustic(s.photoacoustic.map, MELANIN[s.photoacoustic.skin], s.photoacoustic.beamformer);
      pa.then((img) =>
        later(() => {
          const c = canvas();
          drawHologram(c.getContext("2d")!, img);
          this.plane.setImage(c, "pa", key);
        }),
      ).catch(() => {});
    } else {
      const { lesion, beamformer } = s.ultrasound;
      Promise.all([ultrasound(lesion, beamformer), channels(lesion)])
        .then(([us, echoes]) =>
          later(() => {
            const c = canvas();
            drawUltrasound(c.getContext("2d")!, us, false);
            this.plane.setImage(c, "us", key);
            this.screen.draw(`${lesion}:${beamformer}`, (sctx, w, h) => drawChannelData(sctx, echoes, lesion, beamformer, w, h));
          }),
        )
        .catch(() => {});
    }
  }

  /* ---------- sizing ---------- */

  private applySize() {
    const { w, h, dpr } = this.size;
    const ratio = Math.max(0.75, dpr - this.qualityStep * 0.25);
    this.renderer.setPixelRatio(ratio);
    this.renderer.setSize(w, h, false);
    this.composer.setPixelRatio(ratio);
    this.composer.setSize(w, h);
    this.bloom.resolution.set(w * ratio * 0.5, h * ratio * 0.5);
    (this.finish.uniforms.uRes.value as THREE.Vector2).set(w * ratio, h * ratio);
    this.flow.dropMaterial.uniforms.uScale.value = ratio;
    this.stage.dustUniforms.uScale.value = ratio;

    const aspect = w / h;
    const f = this.framing;
    const tanV = Math.tan(THREE.MathUtils.degToRad(this.camera.fov / 2));
    this.baseDist = Math.max(EXTENT.h / 2 / (tanV * f.usableH), EXTENT.w / 2 / (tanV * aspect * f.usableW));
    const fog = this.scene.fog as THREE.Fog;
    fog.near = this.baseDist + 5;
    fog.far = this.baseDist + 30;
    this.camera.aspect = aspect;
    this.camera.setViewOffset(w, h, -(f.focusX - 0.5) * w, -(f.focusY - 0.5) * h, w, h);
    this.camera.updateProjectionMatrix();
    // Some shots fit themselves to the frame's shape.
    this.goalShot(this.state, this.goal);
  }

  /* ---------- frame ---------- */

  private loop = (now: number) => {
    if (this.disposed || !this.active) return;
    this.raf = requestAnimationFrame(this.loop);

    const wallDt = Math.min(0.05, (now - this.lastWall) / 1000);
    this.lastWall = now;
    this.trackQuality(wallDt);
    const dt = this.playing ? wallDt : 0;
    this.time += dt;
    const s = this.state;

    // Light pulses (with the fibre run-up) and ultrasound transmits
    if (this.time >= this.nextPulse) {
      this.laserT = this.time;
      this.paT = this.time + 0.05;
      this.waveEmitted = !this.userPulse;
      this.userPulse = false;
      this.arrival = this.computeArrival();
      labBus.emit("laser", { startedAt: now });
      this.nextPulse = this.pulseInterval();
    }
    if (this.time >= this.nextUs) {
      this.usT = this.time;
      labBus.emit("ultrasound", { startedAt: now });
      this.nextUs = this.time + 2.6;
    }
    if (this.time >= this.paT + this.arrival && this.paT > 0) {
      if (!this.waveEmitted) {
        this.waveEmitted = true;
        this.emitWave(now);
      }
    }

    // Ease every driver toward what the state asks for
    const k = (rate: number) => 1 - Math.exp(-wallDt * rate);
    const pa = s.chapter === "photoacoustic";
    const d = this.drive;
    d.melanin = approach(d.melanin, pa ? MELANIN[s.photoacoustic.skin] : 0, wallDt, 3);
    const heating = s.chapter === "deliver" && s.deliver.light === "continuous";
    d.heat = approach(d.heat, heating ? 1 : 0, wallDt, heating ? 0.9 : 2);
    d.damage = approach(d.damage, heating && s.deliver.particle === "gel" ? 1 : heating ? 0.45 : 0, wallDt, heating ? 0.35 : 1.5);
    // Designing happens at the nanoscale: the lab (tissue, blood, probe) recedes into the dark
    d.lab = approach(d.lab, s.chapter === "design" ? 0 : 1, wallDt, this.opts.reducedMotion ? 60 : 3.2);
    d.dim = 0.1 + 0.9 * d.lab;
    const planeGoal = pa ? 1 : s.chapter === "ultrasound" && s.ultrasound.view === "image" ? 0.55 : 0;
    d.plane = approach(d.plane, planeGoal, wallDt, 2.5);
    d.screen = approach(d.screen, s.chapter === "ultrasound" && s.ultrasound.view === "echoes" ? 1 : 0, wallDt, 3);
    d.probeX = approach(d.probeX, this.probeGoalX(s), wallDt, 2.2);

    this.pointer.lerp(this.pointerTarget, k(3.2));
    this.scroll += (this.scrollTarget - this.scroll) * k(8);
    const camRate = this.opts.reducedMotion ? 60 : 2.1;
    this.cam.target.lerp(this.goal.target, k(camRate));
    this.cam.az = approach(this.cam.az, this.goal.az, wallDt, camRate);
    this.cam.el = approach(this.cam.el, this.goal.el, wallDt, camRate);
    this.cam.dist = approach(this.cam.dist, this.goal.dist, wallDt, camRate);

    // Paused and nothing moving: skip the frame (saves the GPU and the battery)
    const settling =
      this.pointer.distanceToSquared(this.pointerTarget) > 1e-7 ||
      Math.abs(this.scrollTarget - this.scroll) > 1e-4 ||
      this.cam.target.distanceToSquared(this.goal.target) > 1e-6 ||
      Math.abs(this.cam.dist - this.goal.dist) > 1e-4 ||
      Math.abs(this.cam.az - this.goal.az) > 1e-4 ||
      Math.abs(d.probeX - this.probeGoalX(s)) > 1e-3;
    const rippling = !this.opts.reducedMotion && now - this.waveWall < 2600;
    if (!this.playing && !settling && !rippling && this.pendingFrames <= 0) return;
    this.pendingFrames = Math.max(0, this.pendingFrames - 1);

    this.updateCamera();

    // Scene state
    const lt = this.time - this.laserT;
    d.flash = lt > 0 ? Math.exp(-lt * 3.2) : 0;
    const deliverChapter = s.chapter === "deliver";
    const flowOut = this.flow.update(this.time, dt, {
      particle: deliverChapter ? s.deliver.particle : "imaging",
      elapsed: deliverChapter ? s.deliver.elapsed : "hours",
      light: deliverChapter ? s.deliver.light : "off",
      flash: d.flash,
    });
    this.flowSources = flowOut.sources;

    const u = this.tissue.uniforms;
    u.uTime.value = this.time;
    u.uAccum.value = flowOut.accumulation;
    u.uLaserT.value = this.laserT;
    u.uUsT.value = this.usT;
    u.uPAT.value = this.paT;
    u.uMelanin.value = d.melanin;
    u.uHeat.value = d.heat;
    u.uDamage.value = d.damage;
    u.uDim.value = d.dim;
    u.uSkinPA.value = s.chapter === "design" ? 0 : 0.18 + d.melanin * 0.95;
    u.uProbe.value.x = d.probeX;
    this.writeSources(u.uSrc.value);

    this.probe.group.position.x = d.probeX;
    this.probe.setPresence(d.lab < 0.02 ? 0 : d.lab > 0.98 ? 1 : d.lab);
    this.flow.group.visible = d.lab > 0.25;
    this.tissue.group.visible = d.lab > 0.04;
    const toLaser = this.nextPulse - this.time;
    const fiberU = toLaser >= 0 && toLaser < FIBER_TRAVEL && s.chapter !== "design" ? Math.pow(toLaser / FIBER_TRAVEL, 1.8) : -1;
    const [sx, sy] = this.strongestSource();
    const flash = this.probe.update(this.time, s.chapter === "design" ? -100 : this.laserT, this.usT, this.paT, fiberU, sx, sy);

    this.particle.update(
      this.time,
      wallDt,
      {
        visible: s.chapter === "overview" || s.chapter === "design",
        step: s.chapter === "design" ? s.design.step : "coat",
        view: s.chapter === "design" ? s.design.view : "cut",
        heat: s.chapter === "design" && s.design.step === "core" ? d.flash : s.chapter === "overview" ? d.flash * 0.6 : 0,
        waveT: this.paT,
        ring: true,
        backdrop: s.chapter === "design",
        snap: this.opts.reducedMotion,
      },
      this.camera,
    );
    this.stage.update(this.time, flash * 0.6);
    this.tumorLight.intensity = d.flash * flowOut.accumulation * 5 + d.heat * 3.5;
    this.cursorLight.position.set(this.cam.target.x + this.pointer.x * 4.2, this.cam.target.y - 0.4 + this.pointer.y * 1.8, FACE_Z + 1.25);
    // A fill for the tissue face; at the nanoscale it would sit a hand's width from the particle
    this.cursorLight.intensity = 6 * d.lab;

    const sweepT = s.chapter === "ultrasound" ? this.usT + 0.2 : this.paT + this.arrival;
    this.plane.update(this.time, s.chapter === "ultrasound" ? d.probeX : TUMOR.x, d.plane, sweepT);
    this.v3.set(d.probeX + 1.6, 1.6, FACE_Z - 0.35);
    this.screen.update(this.time, this.v3, d.screen, this.camera);

    this.updateFinish(now);
    this.composer.render(wallDt);

    labBus.emit("frame", { accumulation: flowOut.accumulation, released: flowOut.released, signal: d.flash, time: this.time });
    this.emitAnchors();
  };

  private pulseInterval() {
    const s = this.state;
    if (this.opts.reducedMotion) return Infinity;
    switch (s.chapter) {
      case "photoacoustic":
        return this.time + 3.1;
      case "deliver":
        return s.deliver.light === "pulsed" ? this.time + 1.7 : Infinity;
      case "design":
        return s.design.step === "core" && s.design.view === "cut" ? this.time + 3.2 : Infinity;
      case "overview":
        return this.time + 7;
      default:
        return Infinity;
    }
  }

  /** Photoacoustic point sources for the tissue shader: particles, artery, vein. */
  private writeSources(out: THREE.Vector4[]) {
    const s = this.state;
    for (const v of out) v.set(0, 0, 0, 0);
    if (s.chapter === "ultrasound" || s.chapter === "design") return;
    let i = 0;
    const npWeight = s.chapter === "photoacoustic" ? (s.photoacoustic.map === "particles" ? 1 : 0.45) : 0.9;
    const bloodWeight = s.chapter === "photoacoustic" ? (s.photoacoustic.map === "oxygenation" ? 0.95 : 0.45) : 0.35;
    const particleSources = s.chapter === "deliver" ? this.flowSources : NP_SITES.slice(0, 4).map(([x, y, w]) => [x, y, w] as [number, number, number]);
    for (const [x, y, w] of particleSources) if (i < 5) out[i++].set(x, y, w * npWeight, 0);
    if (s.chapter !== "deliver") {
      out[i++].set(TUMOR.x - 0.6, ARTERY.y, bloodWeight, 0);
      out[i++].set(TUMOR.x + 0.55, ARTERY.y, bloodWeight, 0);
      if (i < 8) out[i++].set(VEIN.x, VEIN.y, bloodWeight * 0.9, 0);
    }
  }

  private strongestSource(): [number, number] {
    const s = this.state;
    if (s.chapter === "deliver" && this.flowSources.length) return [this.flowSources[0][0], this.flowSources[0][1]];
    return [NP_SITES[0][0], NP_SITES[0][1]];
  }

  private computeArrival() {
    const [, y] = this.strongestSource();
    return Math.max(0.3, -y / WAVE_SPEED - 0.05);
  }

  private updateCamera() {
    const drift = this.opts.reducedMotion ? 0 : Math.sin(this.time * 0.12) * 0.025;
    const az = this.cam.az + this.pointer.x * 0.06 + drift;
    const el = this.cam.el + this.pointer.y * -0.035 + this.scroll * 0.12;
    const dist = this.baseDist * this.cam.dist * (1 + this.scroll * 0.14) * 0.985;
    const t = this.cam.target;
    this.camera.position.set(t.x + Math.sin(az) * Math.cos(el) * dist, t.y + Math.sin(el) * dist, t.z + Math.cos(az) * Math.cos(el) * dist);
    this.camera.lookAt(t);
  }

  private emitWave(now: number) {
    const origin = this.project(this.probe.group.localToWorld(this.v3b.copy(this.probe.anchors.array).setX(0)));
    const pxPerUnit = this.size.h / (2 * this.baseDist * this.cam.dist * Math.tan(THREE.MathUtils.degToRad(this.camera.fov / 2)));
    this.waveSpeed = Math.max(520, Math.min(1400, pxPerUnit * WAVE_SPEED * 4.2));
    labBus.emit("wave", { x: origin.x, y: origin.y, startedAt: now, speed: this.waveSpeed });
    this.waveWall = now;
    this.waveOrigin.set(origin.x, origin.y);
  }

  private updateFinish(now: number) {
    const u = this.finish.uniforms;
    u.uTime.value = now / 1000;
    const ratio = this.renderer.getPixelRatio();
    const t = (now - this.waveWall) / 1000;
    if (t >= 0 && t < 2.4 && !this.opts.reducedMotion) {
      (u.uCenter.value as THREE.Vector2).set(this.waveOrigin.x * ratio, (this.size.h - this.waveOrigin.y) * ratio);
      u.uRadius.value = t * this.waveSpeed * ratio;
      u.uAmp.value = (1 - t / 2.4) ** 1.5;
    } else u.uAmp.value = 0;
  }

  private project(world: THREE.Vector3): Anchor {
    const p = this.v3.copy(world).project(this.camera);
    return {
      x: (p.x * 0.5 + 0.5) * this.size.w,
      y: (-p.y * 0.5 + 0.5) * this.size.h,
      visible: p.z < 1 && p.x > -1.1 && p.x < 1.1 && p.y > -1.1 && p.y < 1.1,
    };
  }

  private emitAnchors() {
    const w = this.anchorWorld;
    const set = (name: string, x: number, y: number, z: number) => (w[name] ??= new THREE.Vector3()).set(x, y, z);
    const probe = this.probe.group;
    const local = (name: string, v: THREE.Vector3) => probe.localToWorld((w[name] ??= new THREE.Vector3()).copy(v));
    local("array", this.probe.anchors.array);
    local("light", this.probe.anchors.light);
    local("probe", this.probe.anchors.handle);
    for (const name of this.particle.anchorNames) this.particle.anchorWorld(name, (w[name] ??= new THREE.Vector3()));
    set("loupe", LOUPE.x, LOUPE.y, LOUPE.z);
    const right = this.v3b.setFromMatrixColumn(this.camera.matrixWorld, 0).multiplyScalar(this.particle.radius);
    (w.loupeEdge ??= new THREE.Vector3()).copy(LOUPE).add(right);
    set("zoom", 2.6, ARTERY.y, FACE_Z - 0.08);
    set("tumor", TUMOR.x - 0.55, TUMOR.y - 0.45, FACE_Z);
    set("artery", -0.4, ARTERY.y + ARTERY.r + 0.02, FACE_Z);
    set("vein", VEIN.x - VEIN.r, VEIN.y, FACE_Z);
    set("skin", TUMOR.x + 1.25, -0.03, FACE_Z);
    set("lesion", (this.state.ultrasound.lesion === "cyst" ? CYST.x - CYST.r : TUMOR.x - TUMOR.r) + 0.05, this.state.ultrasound.lesion === "cyst" ? CYST.y : TUMOR.y, FACE_Z);
    set("screen", this.drive.probeX + 1.6 + 1.0, 1.6 + 0.6, FACE_Z - 0.35);
    set("leak", LEAK.x1 - 0.2, ARTERY.y + ARTERY.r + 0.04, FACE_Z);
    w.rim ??= new THREE.Vector3();
    w.rim.copy(this.flow.anchors.rim);
    w.tumorCore ??= new THREE.Vector3();
    w.tumorCore.copy(this.flow.anchors.tumorCore);
    for (const name in w) {
      const a = this.project(w[name]);
      const slot = (this.anchors[name] ??= { x: 0, y: 0, visible: false });
      slot.x = a.x;
      slot.y = a.y;
      slot.visible = a.visible;
    }
    labBus.emit("anchors", this.anchors);
  }

  private trackQuality(dt: number) {
    if (dt <= 0) return;
    this.frameTimes.push(dt);
    if (this.frameTimes.length < 90) return;
    const avg = this.frameTimes.reduce((a, b) => a + b, 0) / this.frameTimes.length;
    this.frameTimes.length = 0;
    if (avg > 1 / 52 && this.qualityStep < 3 && this.size.dpr - this.qualityStep * 0.25 > 1) {
      this.qualityStep++;
      this.applySize();
    }
  }
}

