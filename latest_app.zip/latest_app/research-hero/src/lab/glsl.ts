/* Shared GLSL. All colours are linear-space; three.js converts on output. */

export const noiseGLSL = /* glsl */ `
float labHash12(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}
vec2 labHash22(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973));
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.xx + p3.yz) * p3.zy);
}
float labNoise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  float a = labHash12(i);
  float b = labHash12(i + vec2(1.0, 0.0));
  float c = labHash12(i + vec2(0.0, 1.0));
  float d = labHash12(i + vec2(1.0, 1.0));
  return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}
float labFbm(vec2 p) {
  float s = 0.0;
  float a = 0.5;
  for (int i = 0; i < 4; i++) {
    s += a * labNoise(p);
    p = p * 2.07 + vec2(17.3, 9.1);
    a *= 0.5;
  }
  return s;
}
/* Cellular pattern. x: distance to the cell wall, y: distance to the cell centre, z: cell hash. */
vec3 labCells(vec2 x) {
  vec2 n = floor(x);
  vec2 f = fract(x);
  float d1 = 8.0;
  float d2 = 8.0;
  float id = 0.0;
  for (int j = -1; j <= 1; j++) {
    for (int i = -1; i <= 1; i++) {
      vec2 g = vec2(float(i), float(j));
      vec2 o = 0.15 + 0.7 * labHash22(n + g);
      vec2 r = g + o - f;
      float d = dot(r, r);
      if (d < d1) {
        d2 = d1;
        d1 = d;
        id = labHash12(n + g + 3.7);
      } else if (d < d2) {
        d2 = d;
      }
    }
  }
  d1 = sqrt(d1);
  d2 = sqrt(d2);
  return vec3(0.5 * (d2 - d1), d1, id);
}
vec3 labPerturbNormal(vec3 surfPos, vec3 surfNorm, vec2 dHdxy, float faceDirection) {
  vec3 sigmaX = dFdx(surfPos);
  vec3 sigmaY = dFdy(surfPos);
  vec3 r1 = cross(sigmaY, surfNorm);
  vec3 r2 = cross(surfNorm, sigmaX);
  float det = dot(sigmaX, r1) * faceDirection;
  vec3 grad = sign(det) * (dHdxy.x * r1 + dHdxy.y * r2);
  return normalize(abs(det) * surfNorm - grad);
}
`;

/*
  The tissue block. One material shades every face by its normal:
  front = the cut cross-section (skin, dermis, cells, artery, vein, cyst, tumor, live wave field),
  top = skin with a patch of ultrasound gel under the probe, sides = cut tissue.
*/
export const tissueParsGLSL = /* glsl */ `
uniform float uTime;
uniform vec3 uBlock;
uniform vec2 uArtery;
uniform vec3 uVein;
uniform vec3 uCyst;
uniform vec3 uTumor;
uniform vec2 uLeak;
uniform vec3 uProbe;
uniform float uAccum;
uniform float uLaserT;
uniform float uUsT;
uniform float uPAT;
uniform float uWaveSpeed;
uniform vec4 uSrc[8];
uniform float uSkinPA;
uniform float uMelanin;
uniform float uHeat;
uniform float uDamage;
uniform float uDim;
uniform vec3 uPulseColor;
uniform vec3 uEchoColor;
uniform vec3 uHeatColor;

varying vec3 vLabPos;
varying vec3 vLabNormal;

${noiseGLSL}

struct LabTissue {
  vec3 albedo;
  float rough;
  float height;
  vec3 emissive;
};

float labTumorField(vec2 p) {
  vec2 d = p - uTumor.xy;
  float a = atan(d.y, d.x);
  float r = length(d * vec2(0.84, 1.0));
  float edge = uTumor.z * (1.0 + 0.09 * sin(a * 3.0 + 1.7) + 0.06 * sin(a * 5.0 - 0.4) + 0.24 * (labFbm(p * 2.4 + 3.1) - 0.5));
  return edge - r;
}

vec3 labSkinColor(float variation) {
  vec3 light = mix(vec3(0.5, 0.3, 0.22), vec3(0.6, 0.39, 0.3), variation);
  vec3 dark = mix(vec3(0.11, 0.055, 0.035), vec3(0.16, 0.085, 0.055), variation);
  return mix(light, dark, uMelanin);
}

/* Pressure field on the cut face. Positive = compression, negative = rarefaction. */
float labAcoustic(vec2 p) {
  float field = 0.0;
  float depth = -p.y;

  float pt = uTime - uPAT;
  if (pt > 0.0 && pt < 3.2) {
    for (int i = 0; i < 8; i++) {
      vec4 src = uSrc[i];
      if (src.z <= 0.001) continue;
      float r = length(p - src.xy);
      float ph = (r - uWaveSpeed * pt) / 0.06;
      field += src.z * (-ph * exp(-0.5 * ph * ph)) * 0.62 / sqrt(r + 0.22);
    }
    // The skin itself absorbs light and rings: a plane wave down, then a weaker reverberation.
    float ap = exp(-pow(abs(p.x - uProbe.x) / (uProbe.y * 1.35), 4.0));
    float phs = (depth - uWaveSpeed * pt) / 0.05;
    field += uSkinPA * ap * (-phs * exp(-0.5 * phs * phs)) * 0.95;
    float phr = (depth - uWaveSpeed * (pt - 0.32)) / 0.05;
    field += uSkinPA * ap * 0.5 * (-phr * exp(-0.5 * phr * phr)) * step(0.32, pt);
    field *= smoothstep(3.2, 1.7, pt) * step(p.y, -0.02);
  }

  float ut = uTime - uUsT;
  if (ut > 0.0 && ut < 2.8) {
    float spread = uProbe.y * (1.0 + depth * 0.22);
    float aperture = exp(-pow(abs(p.x - uProbe.x) / spread, 6.0));
    float front = -uWaveSpeed * ut;
    float ph = (p.y - front) / 0.03;
    // A real transmit pulse: a few carrier cycles under a Gaussian envelope
    field += 1.05 * aperture * exp(-0.5 * pow(ph / 2.2, 2.0)) * cos(ph * 1.9) * smoothstep(3.1, 1.6, depth);

    bool cystUnder = abs(uProbe.x - uCyst.x) < abs(uProbe.x - uTumor.x);
    vec3 L = cystUnder ? uCyst : uTumor;
    for (int k = 0; k < 6; k++) {
      vec2 e = vec2(0.0);
      float amp = 0.0;
      if (k == 0) { e = vec2(uProbe.x, uArtery.x + uArtery.y); amp = 0.45; }
      else if (k == 1) { e = vec2(uProbe.x, uArtery.x - uArtery.y); amp = 0.4; }
      else if (k == 2) { e = vec2(L.x, L.y + L.z * 0.95); amp = 0.6; }
      else if (k == 3) { e = vec2(L.x, L.y - L.z * 0.95); amp = cystUnder ? 0.75 : 0.32; }
      else if (!cystUnder) { e = L.xy + (k == 4 ? vec2(-0.22, 0.16) : vec2(0.26, -0.18)); amp = 0.42; }
      if (amp <= 0.0) continue;
      float et = ut + e.y / uWaveSpeed;
      if (et > 0.0) {
        float r = length(vec2((p.x - e.x) * 0.55, p.y - e.y));
        float ph2 = (r - uWaveSpeed * et) / 0.03;
        field += amp * step(e.y, p.y) * aperture * exp(-0.5 * pow(ph2 / 1.8, 2.0)) * cos(ph2 * 1.9) / sqrt(r + 0.3);
      }
    }
  }
  return field;
}

/* px = pixel footprint in cell units, taken outside any branch so derivatives stay defined. */
vec3 labCellColor(vec2 cq, float px, float isTumor, out float nucleus, out float height) {
  vec3 c = labCells(cq);
  float damage = uDamage * isTumor;
  float wallLine = 1.0 - smoothstep(0.0, 0.07 + px + damage * 0.08, c.x + (labNoise(cq * 6.0) - 0.5) * damage * 0.12);
  float nucR = mix(0.19, 0.33, isTumor) * mix(0.82 + 0.36 * c.z, 0.62 + 0.8 * c.z, isTumor) * (1.0 - damage * 0.45);
  nucleus = 1.0 - smoothstep(nucR - px, nucR + px, c.y);
  float nucleolus = (1.0 - smoothstep(0.045 - px, 0.045 + px, c.y)) * isTumor * (1.0 - damage);
  float chromatin = labNoise(cq * 7.0 + c.z * 19.0);
  float grain = labNoise(cq * 3.3 + 7.0);
  float dome = 1.0 - smoothstep(0.05, 0.62, c.y);
  vec3 cyto = isTumor > 0.5
    ? mix(vec3(0.3, 0.085, 0.24), vec3(0.42, 0.13, 0.33), c.z * 0.7 + grain * 0.3)
    : mix(vec3(0.66, 0.26, 0.3), vec3(0.78, 0.36, 0.38), c.z * 0.7 + grain * 0.3);
  vec3 nuc = isTumor > 0.5
    ? mix(vec3(0.07, 0.015, 0.13), vec3(0.16, 0.04, 0.26), chromatin)
    : mix(vec3(0.12, 0.035, 0.2), vec3(0.24, 0.08, 0.34), chromatin);
  // Therapy damage: cytoplasm browns and fragments, nuclei shrink and darken (pyknosis).
  cyto = mix(cyto, vec3(0.2, 0.07, 0.06) * (0.7 + grain * 0.6), damage * 0.75);
  nuc = mix(nuc, vec3(0.03, 0.01, 0.02), damage);
  vec3 col = cyto * (0.82 + 0.26 * dome);
  col = mix(col, col * 0.62, wallLine * 0.8);
  col = mix(col, nuc, nucleus * 0.92);
  col = mix(col, vec3(0.05, 0.01, 0.08), nucleolus * 0.8);
  height = dome * 0.8 * (1.0 - damage * 0.5) + nucleus * 0.25 - wallLine * 0.3;
  return col;
}

LabTissue labFront(vec2 p) {
  LabTissue t;
  float depth = -p.y;
  vec2 warp = vec2(labFbm(p * 1.1), labFbm(p * 1.1 + 5.2)) - 0.5;
  vec2 q = p + warp * 0.24;

  float tf = labTumorField(p);
  float tumor = smoothstep(-0.05, 0.08, tf);
  float margin = exp(-tf * tf / 0.0018);

  vec2 cqN = q * 2.9;
  vec2 cqT = q * 5.1 + 17.0;
  float pxN = length(fwidth(cqN)) * 0.9 + 0.015;
  float pxT = length(fwidth(cqT)) * 0.9 + 0.015;
  float pxW = length(fwidth(p)) * 1.2 + 0.004;
  float nucN, hN;
  vec3 colN = labCellColor(cqN, pxN, 0.0, nucN, hN);
  float nucT = nucN;
  float hT = hN;
  vec3 colT = colN;
  if (tumor > 0.001) {
    colT = labCellColor(cqT, pxT, 1.0, nucT, hT);
    hT += 0.35;
  }
  vec3 col = mix(colN, colT, tumor);
  float nucleus = mix(nucN, nucT, tumor);
  col = mix(col, col * vec3(0.55, 0.42, 0.62), margin * 0.7);

  float epi = 1.0 - smoothstep(0.05, 0.085, depth);
  float derm = (1.0 - smoothstep(0.28, 0.4, depth + warp.x * 0.1)) * (1.0 - epi);
  float fib = labNoise(vec2(q.x * 1.6, q.y * 11.0 + labFbm(q * 2.0) * 3.0));
  vec3 dermCol = mix(vec3(0.7, 0.34, 0.32), vec3(0.86, 0.5, 0.44), smoothstep(0.3, 0.8, fib));
  col = mix(col, dermCol, derm);
  col = mix(col, labSkinColor(labNoise(q * 24.0)), epi);

  float h = mix(hN, hT, tumor) * (1.0 - derm - epi) + derm * fib * 0.25;
  float rough = mix(0.46, 0.38, tumor) + nucleus * 0.06;

  vec3 cap = labCells(q * 1.5 + 11.0);
  float capillary = step(0.86, cap.z) * (1.0 - smoothstep(0.05, 0.075, cap.y)) * (1.0 - tumor) * step(0.5, depth);

  // Cyst: a smooth, fluid-filled cavity with a thin capsule
  float cd = length(p - uCyst.xy);
  float cr = clamp(cd / uCyst.z, 0.0, 1.0);
  float cystIn = 1.0 - smoothstep(uCyst.z - pxW * 2.0, uCyst.z + pxW, cd);
  float capsule = exp(-pow((cd - uCyst.z) / 0.03, 2.0));
  // Clear, straw-tinted fluid: darker at the centre, a lighter meniscus toward the top
  vec3 fluid = mix(vec3(0.05, 0.055, 0.06), vec3(0.16, 0.15, 0.12), smoothstep(-0.2, 1.0, (p.y - uCyst.y) / uCyst.z) * 0.6 + cr * cr * 0.4);
  capillary *= 1.0 - cystIn;
  col = mix(col, vec3(0.34, 0.02, 0.03), capillary);
  col = mix(col, fluid, cystIn);
  col = mix(col, vec3(0.62, 0.36, 0.38), capsule * 0.7);
  h = mix(h, -0.18 * (1.0 - cr * cr), cystIn) + capsule * 0.3;
  rough = mix(rough, 0.08, cystIn);

  // Vein, cut across: dark oxygen-poor blood with a muscular wall
  float vd = length(p - uVein.xy);
  float veinIn = 1.0 - smoothstep(uVein.z - pxW * 2.0, uVein.z + pxW, vd);
  float veinWall = smoothstep(uVein.z + 0.065, uVein.z + 0.035, vd) * (1.0 - veinIn);
  float cellsInVein = smoothstep(0.35, 0.75, labNoise((p - uVein.xy) * 34.0));
  col = mix(col, mix(vec3(0.12, 0.008, 0.025), vec3(0.22, 0.02, 0.05), cellsInVein), veinIn);
  col = mix(col, vec3(0.38, 0.04, 0.07), veinWall);
  h += veinWall * 0.3 - veinIn * 0.12 * (1.0 - pow(clamp(vd / uVein.z, 0.0, 1.0), 2.0));
  rough = mix(rough, 0.22, veinIn);

  // Artery wall, with gaps in the leaky stretch over the tumor
  float dy = p.y - uArtery.x;
  float ad = abs(dy);
  float wall = smoothstep(uArtery.y + 0.1, uArtery.y + 0.07, ad);
  float leakZone = step(uLeak.x, p.x) * step(p.x, uLeak.y) * step(dy, 0.0);
  float gap = leakZone * smoothstep(0.62, 0.8, abs(fract(p.x * 2.4 + 0.3) - 0.5) * 2.0);
  float innerEdge = exp(-pow((ad - uArtery.y - 0.012) / 0.012, 2.0));
  col = mix(col, vec3(0.42, 0.03, 0.05), wall * (1.0 - gap));
  col += vec3(0.5, 0.12, 0.12) * innerEdge * (1.0 - gap);
  col = mix(col, vec3(0.16, 0.01, 0.02), gap * smoothstep(uArtery.y + 0.11, uArtery.y, ad));
  h += wall * (1.0 - gap) * 0.4;
  rough -= wall * 0.14;

  vec3 em = col * 0.07;
  float lt = uTime - uLaserT;
  float laserEnv = lt > 0.0 ? exp(-lt * 5.0) : 0.0;
  float beamHalf = uProbe.y * 1.05 + depth * 0.65;
  float fluence = exp(-depth * (0.85 + 0.9 * uMelanin)) * exp(-pow((p.x - uProbe.x) / beamHalf, 2.0));
  em += uPulseColor * fluence * laserEnv * 0.55;
  // Melanin soaks up light right at the surface
  em += uHeatColor * laserEnv * uMelanin * epi * exp(-pow((p.x - uProbe.x) / (uProbe.y * 1.3), 2.0)) * 1.1;

  // Sustained light: the tumor warms from the particles outward
  float heatField = exp(-length((p - uTumor.xy) * vec2(0.85, 1.0)) / 0.62);
  float shimmer = 0.85 + 0.15 * sin(uTime * 3.0 + labNoise(p * 6.0) * 6.0);
  em += uHeatColor * uHeat * (heatField * 0.32 + tumor * uAccum * 0.3) * shimmer * (1.0 - cystIn);

  float field = labAcoustic(p);
  em += uEchoColor * max(field, 0.0) * 1.1;
  col *= 1.0 - 0.45 * clamp(-field, 0.0, 1.0);

  t.albedo = col * uDim;
  t.rough = rough;
  t.height = h;
  t.emissive = em * uDim;
  return t;
}

LabTissue labSide(vec2 p, float withVessel) {
  LabTissue t;
  vec2 warp = vec2(labFbm(p * 1.2 + 2.0), labFbm(p * 1.2 + 7.3)) - 0.5;
  vec2 q = p + warp * 0.25;
  float depth = -p.y;
  vec2 cq = q * 2.6 + 13.0;
  float px = length(fwidth(cq)) + 0.02;
  vec3 c = labCells(cq);
  float wallLine = 1.0 - smoothstep(0.0, 0.1 + px, c.x);
  float nucleus = 1.0 - smoothstep(0.2 - px, 0.2 + px, c.y);
  float epi = 1.0 - smoothstep(0.05, 0.085, depth);
  float derm = (1.0 - smoothstep(0.28, 0.4, depth)) * (1.0 - epi);
  vec3 col = mix(vec3(0.46, 0.15, 0.18), vec3(0.54, 0.2, 0.22), labFbm(q * 2.0));
  col = mix(col, col * 0.8, wallLine * 0.5);
  col = mix(col, vec3(0.22, 0.07, 0.2), nucleus * 0.35);
  col = mix(col, vec3(0.6, 0.3, 0.28), derm);
  col = mix(col, labSkinColor(0.5) * 0.9, epi);

  float dv = length(p - vec2(uBlock.z * 0.5, uArtery.x));
  float lumen = (1.0 - smoothstep(uArtery.y - 0.01, uArtery.y + 0.01, dv)) * withVessel;
  float wall = smoothstep(uArtery.y + 0.1, uArtery.y + 0.07, dv) * (1.0 - lumen) * withVessel;
  col = mix(col, vec3(0.14, 0.006, 0.012), lumen);
  col = mix(col, vec3(0.4, 0.03, 0.05), wall);

  t.albedo = col * uDim * 0.8;
  t.rough = 0.55 - lumen * 0.3;
  t.height = (1.0 - smoothstep(0.05, 0.6, c.y)) * 0.4 * (1.0 - derm - epi);
  t.emissive = col * 0.035 * uDim;
  return t;
}

LabTissue labTop(vec2 p) {
  LabTissue t;
  float n = labFbm(p * 4.0);
  vec2 pc = p * 19.0;
  float px = length(fwidth(pc)) + 0.02;
  vec3 pores = labCells(pc);
  float pore = 1.0 - smoothstep(0.05 - px, 0.05 + px, pores.y);
  float crease = smoothstep(0.03, 0.0, abs(labNoise(vec2(p.x * 1.3 + p.y * 0.7, p.y * 2.4)) - 0.5)) * 0.5;
  vec3 col = labSkinColor(n);
  col *= 1.0 - pore * 0.045 - crease * 0.05;

  vec2 gd = (p - uProbe.xz) / vec2(uProbe.y + 0.45, 0.66);
  float gel = 1.0 - smoothstep(0.75, 1.0, length(gd) + (labFbm(p * 3.0) - 0.5) * 0.35);
  col = mix(col, col * vec3(0.84, 0.88, 0.92), gel);

  float lt = uTime - uLaserT;
  float laserEnv = lt > 0.0 ? exp(-lt * 5.0) : 0.0;
  vec3 em = col * 0.04;
  em += uPulseColor * laserEnv * 0.2 * exp(-dot(gd, gd) * 1.2) + uHeatColor * laserEnv * uMelanin * 0.55 * exp(-dot(gd, gd) * 1.2);

  t.albedo = col * uDim;
  t.rough = mix(0.5, 0.08, gel);
  t.height = n * 0.18 - pore * 0.12 - crease * 0.12 + gel * 0.15;
  t.emissive = em * uDim;
  return t;
}
`;

export const tissueMainGLSL = /* glsl */ `
  vec3 labN = normalize(vLabNormal);
  LabTissue labT;
  if (labN.z > 0.6) {
    if (abs(vLabPos.y - uArtery.x) < uArtery.y && abs(vLabPos.x) < uBlock.x * 0.5 - 0.035) discard;
    labT = labFront(vLabPos.xy);
  } else if (labN.y > 0.6) {
    labT = labTop(vLabPos.xz);
  } else if (abs(labN.x) > 0.6) {
    labT = labSide(vec2(vLabPos.z, vLabPos.y), 1.0);
  } else {
    labT = labSide(vec2(vLabPos.x, vLabPos.y), 0.0);
  }
  diffuseColor.rgb = labT.albedo;
`;
