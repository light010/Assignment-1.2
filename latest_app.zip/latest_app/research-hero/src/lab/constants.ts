/*
  World layout, in scene units. The tissue block's top (the skin) sits at y = 0 and its
  front face (the cut we look into) is the plane z = FACE_Z. The instrument images and the
  tissue shader both read these numbers, so what the probe "sees" matches the anatomy.
*/
export const BLOCK = { w: 6.4, h: 3.0, d: 2.6, r: 0.05 } as const;
export const FACE_Z = BLOCK.d / 2;

/** Oxygen-rich artery running across the cut: the delivery route. */
export const ARTERY = { y: -0.78, r: 0.26 } as const;
/** Oxygen-poor vein, cut across so it shows as a round lumen. */
export const VEIN = { x: 0.42, y: -1.62, r: 0.16 } as const;
/** Solid mass (tumor). */
export const TUMOR = { x: 1.55, y: -1.92, r: 0.7 } as const;
/** Fluid-filled cyst, for the ultrasound comparison. */
export const CYST = { x: -1.55, y: -1.9, r: 0.52 } as const;
/** Leaky stretch of artery wall above the tumor. */
export const LEAK = { x0: 1.0, x1: 2.2 } as const;

/** Probe acoustic aperture (half width) and the imaging plane it sees below it. */
export const PROBE_APERTURE = 1.0;
export const FOV = { halfWidth: 1.5, depth: 2.9 } as const;

/** Particle clusters inside the tumor (x, y, weight): photoacoustic sources and release sites. */
export const NP_SITES: ReadonlyArray<readonly [number, number, number]> = [
  [1.3, -1.6, 1.0],
  [1.85, -1.72, 0.85],
  [1.5, -2.22, 0.9],
  [1.98, -2.25, 0.6],
  [1.08, -2.04, 0.7],
  [1.6, -1.38, 0.55],
];

/** Speed of sound in the scene, units per second. */
export const WAVE_SPEED = 1.85;

/** Where the magnified particle floats in the overview. */
export const LOUPE_POS = [4.05, 1.72, 1.5] as const;

export const COLORS = {
  void: 0x060a0c,
  bone: 0xece7df,
  pulse: 0xffad62,
  echo: 0x8fe1f0,
  core: 0xd8b67c,
  /** Photoacoustic map: oxygen-rich blood green, oxygen-poor blood red (lab convention). */
  oxy: 0x4fdc8a,
  deoxy: 0xff4a4a,
} as const;
