import { CYST, TUMOR } from "./constants";
import {
  CH_APERTURE,
  CH_H,
  CH_T0,
  CH_T1,
  CH_W,
  IMG_H,
  IMG_W,
  MICROGRAPH_SEED,
  mulberry32After,
  type ChannelPicture,
  type MicrographFilm,
  type PaPicture,
  type UsPicture,
} from "./instrument-shared";
import type { Beamformer, DesignStep, Lesion } from "./state";

/*
  Canvas output for the instrument pictures. The per-pixel work arrives done (instrument-client.ts);
  what's left here is cheap: putting the pixels down and drawing the vector marks on top (regions of
  interest, the delay curve, coherence bars, the particles of a micrograph, scale bars).
*/

export { IMG_H, IMG_W };

/* ---------- electron micrographs ---------- */

export function drawMicrograph(ctx: CanvasRenderingContext2D, step: DesignStep, { film }: MicrographFilm, w: number, h: number) {
  // The film drew w * h numbers from this seed; the particles continue the same sequence.
  const rand = mulberry32After(MICROGRAPH_SEED[step], w * h);
  // Carbon support film
  ctx.putImageData(new ImageData(film, w, h), 0, 0);

  const dot = (x: number, y: number, r: number, dark: number, soft = 0.35) => {
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, `rgba(10,10,12,${dark})`);
    g.addColorStop(1 - soft, `rgba(20,20,24,${dark * 0.85})`);
    g.addColorStop(1, "rgba(20,20,24,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  };

  let scaleLabel = "20 nm";
  let scalePx = 60;
  if (step === "core") {
    // Ultrasmall, uniform crystals with a faint capping halo; a few loose clusters
    for (let n = 0; n < 95; n++) {
      const cx = rand() * w;
      const cy = rand() * h;
      const r = 6 + rand() * 3.2;
      ctx.fillStyle = "rgba(255,255,255,0.08)";
      ctx.beginPath();
      ctx.arc(cx, cy, r * 1.7, 0, Math.PI * 2);
      ctx.fill();
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(rand() * Math.PI);
      ctx.fillStyle = `rgba(18,16,18,${0.75 + rand() * 0.2})`;
      ctx.beginPath();
      for (let s = 0; s < 6; s++) {
        const a = (s / 6) * Math.PI * 2;
        const rr = r * (0.85 + rand() * 0.3);
        ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr);
      }
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }
  } else {
    scaleLabel = "100 nm";
    scalePx = 70;
    const spheres = step === "gel" ? 7 : 6;
    for (let n = 0; n < spheres; n++) {
      const cx = 60 + rand() * (w - 120);
      const cy = 60 + rand() * (h - 140);
      const r = 44 + rand() * 18;
      // Gel: soft, low-contrast body
      const g = ctx.createRadialGradient(cx, cy, r * 0.2, cx, cy, r);
      g.addColorStop(0, "rgba(95,95,100,0.55)");
      g.addColorStop(0.85, "rgba(110,110,115,0.45)");
      g.addColorStop(1, "rgba(110,110,115,0)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fill();
      // Embedded cores
      for (let c = 0; c < 9; c++) {
        const a = rand() * Math.PI * 2;
        const d = Math.sqrt(rand()) * r * 0.72;
        dot(cx + Math.cos(a) * d, cy + Math.sin(a) * d, 3.2 + rand() * 1.6, 0.9, 0.2);
      }
      if (step === "coat") {
        // Membrane: a thin dark rim with a faint corona
        ctx.strokeStyle = "rgba(25,25,30,0.8)";
        ctx.lineWidth = 3.2;
        ctx.beginPath();
        ctx.arc(cx, cy, r * 0.97, 0, Math.PI * 2);
        ctx.stroke();
        ctx.strokeStyle = "rgba(255,255,255,0.22)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(cx, cy, r * 0.97 + 3, 0, Math.PI * 2);
        ctx.stroke();
      }
    }
  }
  // Scale bar
  ctx.fillStyle = "rgba(255,255,255,0.92)";
  ctx.fillRect(18, h - 28, scalePx, 5);
  ctx.font = "600 15px ui-sans-serif, system-ui, sans-serif";
  ctx.fillText(scaleLabel, 18, h - 36);
}

/* ---------- imaging ---------- */

export function drawUltrasound(ctx: CanvasRenderingContext2D, img: UsPicture, showRois = true) {
  ctx.putImageData(new ImageData(img.pixels, IMG_W, IMG_H), 0, 0);
  if (!showRois) return;
  ctx.setLineDash([6, 5]);
  ctx.lineWidth = 2;
  ctx.strokeStyle = "rgba(143,225,240,0.95)";
  ctx.beginPath();
  ctx.arc(img.lesionRoi.x, img.lesionRoi.y, img.lesionRoi.r, 0, Math.PI * 2);
  ctx.stroke();
  ctx.strokeStyle = "rgba(236,231,223,0.8)";
  ctx.beginPath();
  ctx.arc(img.backgroundRoi.x, img.backgroundRoi.y, img.backgroundRoi.r, 0, Math.PI * 2);
  ctx.stroke();
  ctx.setLineDash([]);
}

/** The panel's photoacoustic image: the overlay over its dimmed ultrasound underlay. */
export function drawPhotoacoustic(ctx: CanvasRenderingContext2D, img: PaPicture) {
  ctx.putImageData(new ImageData(img.pixels, IMG_W, IMG_H), 0, 0);
}

/** The scene's hologram: the overlay alone, with clutter toned down. */
export function drawHologram(ctx: CanvasRenderingContext2D, img: PaPicture) {
  ctx.putImageData(new ImageData(img.holo, IMG_W, IMG_H), 0, 0);
}

export function drawChannelData(ctx: CanvasRenderingContext2D, channels: ChannelPicture, lesion: Lesion, beamformer: Beamformer, w: number, h: number) {
  const data = channels.data;
  const img = ctx.createImageData(CH_W, CH_H);
  for (let k = 0; k < CH_W * CH_H; k++) {
    const v = data[k];
    const lum = 128 + v * 118;
    img.data[k * 4] = lum * 0.93;
    img.data[k * 4 + 1] = lum * 0.97;
    img.data[k * 4 + 2] = lum;
    img.data[k * 4 + 3] = 255;
  }
  const tmp = document.createElement("canvas");
  tmp.width = CH_W;
  tmp.height = CH_H;
  tmp.getContext("2d")!.putImageData(img, 0, 0);
  ctx.imageSmoothingEnabled = true;
  ctx.drawImage(tmp, 0, 0, w, h);

  const L = lesion === "cyst" ? CYST : TUMOR;
  const zc = -L.y;
  const rowC = ((zc - CH_T0) / (CH_T1 - CH_T0)) * CH_H;
  if (beamformer === "standard") {
    // Delay-and-sum: the arrival curve for the lesion centre, along which echoes are summed
    ctx.strokeStyle = "rgba(255,173,98,0.95)";
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    for (let e = 0; e < CH_W; e++) {
      const dx = ((e / (CH_W - 1)) * 2 - 1) * CH_APERTURE;
      const t = (zc + Math.hypot(zc, dx)) / 2;
      const x = ((e + 0.5) / CH_W) * w;
      const y = ((t - CH_T0) / (CH_T1 - CH_T0)) * h;
      if (e === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
  } else {
    // Short-lag coherence: how well each element agrees with its neighbour at the lesion depth
    const coh = channels.coherence;
    const y = (rowC / CH_H) * h;
    ctx.fillStyle = "rgba(6,10,12,0.55)";
    ctx.fillRect(0, y - 26, w, 52);
    for (let e = 0; e < CH_W - 1; e++) {
      const c = Math.max(0, coh[e]);
      ctx.fillStyle = `rgba(143,225,240,${0.25 + c * 0.75})`;
      const x = ((e + 1) / CH_W) * w;
      const bar = 4 + c * 40;
      ctx.fillRect(x - 2, y - bar / 2, 4, bar);
    }
  }
}
