import * as THREE from "three";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";
import { COLORS } from "../constants";
import { noiseGLSL } from "../glsl";
import type { DesignStep, DesignView } from "../state";

/*
  One nanoparticle, magnified and cut open, built in the same order as the lab makes it:
  1. light-absorbing crystal cores with a soft capping layer,
  2. loaded into a heat-responsive gel together with drug molecules,
  3. wrapped in a cell-membrane coat studded with proteins.
  "Exploded" lays the three layers out side by side, like a lens taken apart.
*/

const R_GEL = 0.86;
const R_TAIL = 0.95;
const R_HEAD = 0.985;

const clamp01 = (t: number) => Math.min(1, Math.max(0, t));
const easeOut = (t: number) => 1 - Math.pow(1 - t, 3);
/** Eased approach that lands exactly, so no half-finished stragglers linger after a transition. */
const approach = (v: number, goal: number, dt: number, rate = 1.8) => {
  const next = v + (goal - v) * (1 - Math.exp(-dt * rate));
  return Math.abs(goal - next) < 0.012 ? goal : next;
};

/** Octant orientation shared by every layer: the cut faces the viewer, tilted slightly. */
const OCTANT_Q = new THREE.Quaternion().setFromUnitVectors(
  new THREE.Vector3(1, 1, 1).normalize(),
  new THREE.Vector3(0.2, 0.14, 1).normalize(),
);

/** Where cores and drug sit inside the gel: straddling the cut planes so they read as embedded. */
const CORE_IN_GEL: Array<[number, number, number]> = [
  [0.28, 0.32, 0.05],
  [0.58, 0.14, 0.05],
  [0.06, 0.46, 0.36],
  [0.05, 0.2, 0.63],
  [0.4, 0.05, 0.42],
  [0.64, 0.06, 0.24],
  [0.2, 0.2, 0.2],
];
const DRUG_IN_GEL: Array<[number, number, number]> = [
  [0.44, 0.44, 0.04],
  [0.14, 0.62, 0.04],
  [0.7, 0.3, 0.04],
  [0.04, 0.66, 0.2],
  [0.04, 0.4, 0.55],
  [0.04, 0.12, 0.42],
  [0.2, 0.04, 0.64],
  [0.56, 0.04, 0.5],
  [0.74, 0.04, 0.1],
  [0.34, 0.14, 0.3],
];

interface Layer {
  group: THREE.Group;
  body: THREE.Group;
  planes: THREE.Plane[];
}

function createLayer(): Layer {
  const group = new THREE.Group();
  const body = new THREE.Group();
  body.quaternion.copy(OCTANT_Q);
  group.add(body);
  return { group, body, planes: [new THREE.Plane(), new THREE.Plane(), new THREE.Plane()] };
}

const LOCAL_PLANES = [
  new THREE.Plane(new THREE.Vector3(-1, 0, 0), 0),
  new THREE.Plane(new THREE.Vector3(0, -1, 0), 0),
  new THREE.Plane(new THREE.Vector3(0, 0, -1), 0),
];

/** A small drug molecule: a few red atoms on thin bonds. */
function createMoleculeGeometry() {
  const parts: THREE.BufferGeometry[] = [];
  const atoms: Array<[number, number, number, number]> = [
    [0, 0, 0, 0.034],
    [0.07, 0.03, 0.01, 0.028],
    [-0.05, 0.055, -0.02, 0.026],
    [-0.02, -0.07, 0.03, 0.028],
    [0.12, -0.02, -0.03, 0.022],
  ];
  for (const [x, y, z, r] of atoms) parts.push(new THREE.IcosahedronGeometry(r, 1).translate(x, y, z));
  const bonds: Array<[number, number]> = [
    [0, 1],
    [0, 2],
    [0, 3],
    [1, 4],
  ];
  for (const [ia, ib] of bonds) {
    const a = new THREE.Vector3(atoms[ia][0], atoms[ia][1], atoms[ia][2]);
    const b = new THREE.Vector3(atoms[ib][0], atoms[ib][1], atoms[ib][2]);
    const bond = new THREE.CylinderGeometry(0.008, 0.008, a.distanceTo(b), 6);
    bond.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), b.clone().sub(a).normalize()));
    bond.translate((a.x + b.x) / 2, (a.y + b.y) / 2, (a.z + b.z) / 2);
    parts.push(bond);
  }
  const merged = mergeGeometries(parts.map((g) => (g.index ? g.toNonIndexed() : g)));
  merged.computeVertexNormals();
  return merged;
}

export interface ParticleParams {
  /** Show the particle at all (overview and design only). */
  visible: boolean;
  step: DesignStep;
  view: DesignView;
  /** 0..1 light flash: cores glow and the gel warms. */
  heat: number;
  /** Timeline time of the last photoacoustic emission (loupe ring). */
  waveT: number;
  /** Frame the particle in the loupe ring. */
  ring: boolean;
  /** Grow the loupe into a dark stage that hides the lab (designing at the nanoscale). */
  backdrop: boolean;
  /** Jump straight to the target state (reduced motion). */
  snap?: boolean;
}

export function createNanoparticle({ lowPower }: { lowPower: boolean }) {
  const root = new THREE.Group();
  root.name = "nanoparticle";
  const spin = new THREE.Group();
  root.add(spin);

  const core = createLayer();
  const gel = createLayer();
  const coat = createLayer();
  spin.add(core.group, gel.group, coat.group);

  // 1. Cores: faceted near-black absorbers with a warm metallic glint and a capping halo
  // Near-black facets that catch warm, golden highlights
  const coreMat = new THREE.MeshPhysicalMaterial({
    color: 0x0b0a08,
    metalness: 0.35,
    roughness: 0.2,
    specularColor: new THREE.Color(0xffc46b),
    specularIntensity: 1,
    clearcoat: 1,
    clearcoatRoughness: 0.06,
    iridescence: 0.35,
    iridescenceIOR: 1.8,
    flatShading: true,
    emissive: new THREE.Color(COLORS.pulse),
    emissiveIntensity: 0,
  });
  const cappingUniforms = { uOpacity: { value: 1 }, uColor: { value: new THREE.Color(0xd9c9ff) } };
  const cappingMat = new THREE.ShaderMaterial({
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    uniforms: cappingUniforms,
    vertexShader: /* glsl */ `
      varying vec3 vN;
      varying vec3 vV;
      void main() {
        vec4 mv = modelViewMatrix * vec4(position, 1.0);
        vN = normalize(normalMatrix * normal);
        vV = normalize(-mv.xyz);
        gl_Position = projectionMatrix * mv;
      }
    `,
    fragmentShader: /* glsl */ `
      uniform float uOpacity;
      uniform vec3 uColor;
      varying vec3 vN;
      varying vec3 vV;
      void main() {
        float f = pow(1.0 - abs(dot(normalize(vN), normalize(vV))), 2.2);
        gl_FragColor = vec4(uColor * f * 0.55 * uOpacity, 1.0);
      }
    `,
  });
  const crystalGeo = new THREE.DodecahedronGeometry(0.1, 0);
  const haloGeo = new THREE.SphereGeometry(0.15, 24, 16);
  const invOctant = OCTANT_Q.clone().invert();
  const cores = CORE_IN_GEL.map(([x, y, z], i) => {
    const mesh = new THREE.Mesh(crystalGeo, coreMat);
    mesh.scale.setScalar(0.85 + ((i * 37) % 10) / 30);
    mesh.rotation.set(i * 1.3, i * 0.7, i * 2.1);
    mesh.add(new THREE.Mesh(haloGeo, cappingMat));
    core.body.add(mesh);
    const a = (i / CORE_IN_GEL.length) * Math.PI * 2;
    return {
      mesh,
      loose: new THREE.Vector3(Math.cos(a) * 0.46, Math.sin(a * 1.7) * 0.28, Math.sin(a) * 0.46).applyQuaternion(invOctant),
      inGel: new THREE.Vector3(x, y, z),
      spinAxis: new THREE.Vector3(Math.sin(i), Math.cos(i * 2), 0.5).normalize(),
    };
  });

  // 2. Gel: blue heat-responsive network, clipped to show its inside, with drug molecules
  const gelUniforms = { uWarm: { value: 0 } };
  const gelMat = new THREE.MeshPhysicalMaterial({
    color: 0x2a64c8,
    roughness: 0.2,
    clearcoat: 1,
    clearcoatRoughness: 0.15,
    emissive: new THREE.Color(0x0c2a66),
    emissiveIntensity: 0.9,
    clippingPlanes: gel.planes,
    clipIntersection: true,
    side: THREE.DoubleSide,
  });
  gelMat.onBeforeCompile = (shader) => {
    Object.assign(shader.uniforms, gelUniforms);
    shader.vertexShader = shader.vertexShader
      .replace("#include <common>", "#include <common>\nvarying vec3 vGelPos;")
      .replace("#include <project_vertex>", "#include <project_vertex>\nvGelPos = position;");
    shader.fragmentShader = shader.fragmentShader
      .replace("#include <common>", `#include <common>\nvarying vec3 vGelPos;\nuniform float uWarm;\n${noiseGLSL}`)
      .replace(
        "#include <emissivemap_fragment>",
        `#include <emissivemap_fragment>
        {
          vec3 n = normalize(vGelPos);
          vec2 uvn = vec2(atan(n.z, n.x) * 2.2, asin(n.y) * 3.0);
          float fib = 1.0 - smoothstep(0.02, 0.06, labCells(uvn * 2.6).x);
          totalEmissiveRadiance += vec3(0.35, 0.6, 1.0) * fib * 0.35 + vec3(1.0, 0.45, 0.1) * uWarm * 0.6;
        }`,
      );
  };
  gelMat.customProgramCacheKey = () => "lab-np-gel";
  const gelSphere = new THREE.Mesh(new THREE.SphereGeometry(R_GEL, 72, 54), gelMat);
  gel.body.add(gelSphere);

  const moleculeMat = new THREE.MeshPhysicalMaterial({
    color: 0xe0343a,
    roughness: 0.3,
    clearcoat: 1,
    emissive: new THREE.Color(0x6a0a0e),
    emissiveIntensity: 0.6,
  });
  const molecules = new THREE.InstancedMesh(createMoleculeGeometry(), moleculeMat, DRUG_IN_GEL.length);
  molecules.frustumCulled = false;
  gel.body.add(molecules);

  // Cross-section caps: one set for the gel, one for the membrane band
  const capGeo = new THREE.CircleGeometry(1, 96, 0, Math.PI / 2);
  const makeCaps = (band: "gel" | "coat") => {
    const uniforms = { uR: { value: new THREE.Vector2(0, R_GEL) }, uLoad: { value: 1 }, uWarm: { value: 0 } };
    const mat = new THREE.MeshStandardMaterial({ roughness: 0.42, side: THREE.DoubleSide });
    mat.onBeforeCompile = (shader) => {
      Object.assign(shader.uniforms, uniforms);
      shader.vertexShader = shader.vertexShader
        .replace("#include <common>", "#include <common>\nvarying vec2 vCap;")
        .replace("#include <uv_vertex>", "#include <uv_vertex>\nvCap = position.xy;");
      shader.fragmentShader = shader.fragmentShader
        .replace(
          "#include <common>",
          `#include <common>\nuniform vec2 uR;\nuniform float uLoad, uWarm;\nvarying vec2 vCap;\n${noiseGLSL}\nvec3 capEmissive = vec3(0.0);`,
        )
        .replace(
          "#include <map_fragment>",
          band === "gel"
            ? `
            float r = length(vCap);
            if (r > uR.y) discard;
            vec3 net = labCells(vCap * 9.0);
            float fiber = 1.0 - smoothstep(0.015, 0.05, net.x);
            vec3 drug = labCells(vCap * 12.0 + 4.0);
            float dotD = step(0.62, drug.z) * (1.0 - smoothstep(0.09, 0.14, drug.y)) * uLoad;
            float depthK = smoothstep(0.0, uR.y, r);
            vec3 col = mix(vec3(0.03, 0.09, 0.26), vec3(0.07, 0.2, 0.46), depthK);
            col = mix(col, vec3(0.55, 0.75, 1.0), fiber * 0.55);
            col = mix(col, vec3(0.9, 0.12, 0.14), dotD);
            col = mix(col, vec3(0.6, 0.25, 0.06), uWarm * (1.0 - depthK) * 0.7);
            capEmissive = vec3(0.03, 0.09, 0.24) * (0.7 + fiber * 1.4) + vec3(0.9, 0.12, 0.1) * dotD * 0.8 + vec3(1.0, 0.45, 0.12) * uWarm * 0.9;
            diffuseColor.rgb = col;`
            : `
            float r = length(vCap);
            if (r < uR.x || r > uR.y) discard;
            float ang = atan(vCap.y, vCap.x);
            float spacing = 0.064;
            float along = fract(ang * r / spacing) - 0.5;
            float inner = length(vec2((r - (uR.x + 0.02)) / spacing, along));
            float outer = length(vec2((r - (uR.y - 0.02)) / spacing, along));
            float headsIn = 1.0 - smoothstep(0.3, 0.42, inner);
            float headsOut = 1.0 - smoothstep(0.3, 0.42, outer);
            float band = (r - uR.x) / (uR.y - uR.x);
            float tails = smoothstep(0.35, 0.0, abs(fract(ang * r / (spacing * 0.5)) - 0.5)) * step(0.28, band) * step(band, 0.72);
            vec3 col = mix(vec3(0.62, 0.72, 0.86), vec3(0.8, 0.86, 0.95), tails);
            col = mix(col, vec3(0.7, 0.82, 1.0), headsIn);
            col = mix(col, vec3(0.96, 0.46, 0.46), headsOut);
            capEmissive = vec3(0.12, 0.03, 0.03) * headsOut + vec3(0.03, 0.05, 0.08) * headsIn;
            diffuseColor.rgb = col;`,
        )
        .replace("#include <emissivemap_fragment>", "#include <emissivemap_fragment>\ntotalEmissiveRadiance += capEmissive;");
    };
    mat.customProgramCacheKey = () => `lab-np-cap-${band}`;
    const caps = [new THREE.Mesh(capGeo, mat), new THREE.Mesh(capGeo, mat), new THREE.Mesh(capGeo, mat)];
    caps[1].rotation.y = -Math.PI / 2;
    caps[2].rotation.x = Math.PI / 2;
    return { caps, uniforms };
  };
  const gelCaps = makeCaps("gel");
  gel.body.add(...gelCaps.caps);

  // 3. Coat: bilayer (pale inner leaflet, pink heads outside) with purple membrane proteins
  const tailMat = new THREE.MeshPhysicalMaterial({
    color: 0xb7c6de,
    roughness: 0.5,
    sheen: 0.5,
    sheenColor: new THREE.Color(0xd8e6ff),
    clippingPlanes: coat.planes,
    clipIntersection: true,
    side: THREE.DoubleSide,
  });
  const tails = new THREE.Mesh(new THREE.SphereGeometry(R_TAIL, 64, 48), tailMat);
  coat.body.add(tails);
  const coatCaps = makeCaps("coat");
  coatCaps.uniforms.uR.value.set(R_GEL, R_HEAD);
  coat.body.add(...coatCaps.caps);

  const target = lowPower ? 1300 : 2600;
  const dirs: THREE.Vector3[] = [];
  const golden = Math.PI * (3 - Math.sqrt(5));
  for (let i = 0; i < target; i++) {
    const y = 1 - (i / (target - 1)) * 2;
    const rad = Math.sqrt(1 - y * y);
    const th = golden * i;
    const d = new THREE.Vector3(Math.cos(th) * rad, y, Math.sin(th) * rad);
    if (d.x > 0.012 && d.y > 0.012 && d.z > 0.012) continue;
    dirs.push(d);
  }
  const headMat = new THREE.MeshPhysicalMaterial({
    color: 0xffffff,
    roughness: 0.34,
    clearcoat: 0.6,
    clearcoatRoughness: 0.3,
    sheen: 0.7,
    sheenColor: new THREE.Color(0xffc2c2),
  });
  const heads = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(lowPower ? 0.05 : 0.043, 1), headMat, dirs.length);
  heads.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  heads.frustumCulled = false;
  const headColor = new THREE.Color();
  const headDelay = new Float32Array(dirs.length);
  for (let i = 0; i < dirs.length; i++) {
    const d = dirs[i];
    headColor.setHSL(0.985 + Math.random() * 0.02, 0.62, 0.66 + Math.random() * 0.08);
    heads.setColorAt(i, headColor);
    headDelay[i] = (Math.atan2(d.z, d.x) / (Math.PI * 2) + 0.5) * 0.55 + (1 - d.y) * 0.12;
  }
  const maxDelay = headDelay.reduce((a, b) => Math.max(a, b), 0) + 0.42;
  coat.body.add(heads);

  const proteinDirs = dirs.filter((_, i) => i % 61 === 7);
  const proteins = new THREE.InstancedMesh(
    new THREE.CapsuleGeometry(0.05, 0.07, 4, 10),
    new THREE.MeshPhysicalMaterial({
      color: 0x7c4dff,
      roughness: 0.3,
      clearcoat: 0.8,
      emissive: new THREE.Color(0x2a1066),
      emissiveIntensity: 0.8,
    }),
    proteinDirs.length,
  );
  proteins.frustumCulled = false;
  coat.body.add(proteins);

  // Loupe: backing disc, rim and dial ticks; the particle "sings" into its ring on a pulse
  const loupeUniforms = {
    uTime: { value: 0 },
    uWave: { value: -100 },
    uRim: { value: new THREE.Color(COLORS.bone) },
    uEcho: { value: new THREE.Color(COLORS.echo) },
    uOpacity: { value: 1 },
    uBackdrop: { value: 0 },
  };
  const LOUPE_SIZE = 11;
  const loupe = new THREE.Mesh(
    new THREE.PlaneGeometry(LOUPE_SIZE, LOUPE_SIZE),
    new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      uniforms: loupeUniforms,
      vertexShader: /* glsl */ `
        varying vec2 vUv;
        void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
      `,
      fragmentShader: /* glsl */ `
        uniform float uTime, uWave, uOpacity, uBackdrop;
        uniform vec3 uRim, uEcho;
        varying vec2 vUv;
        void main() {
          vec2 p = (vUv - 0.5) * ${LOUPE_SIZE.toFixed(1)};
          float r = length(p);
          float a = atan(p.y, p.x);
          float R = 1.2;
          // Backdrop: the loupe's disc, which grows into a dark "nanoscale stage" while designing
          float stageR = mix(R, 5.2, uBackdrop);
          float disc = 1.0 - smoothstep(stageR - mix(0.01, 1.5, uBackdrop), stageR + 0.01, r);
          vec3 col = mix(vec3(0.02, 0.05, 0.06), vec3(0.0, 0.012, 0.016), smoothstep(0.0, stageR, r));
          col += vec3(0.02, 0.045, 0.055) * exp(-r * r / 3.0) * uBackdrop;
          float alpha = disc * mix(0.72, 0.97, uBackdrop);
          float rim = smoothstep(0.012, 0.0, abs(r - R)) * uOpacity;
          col += uRim * rim * 1.1;
          alpha = max(alpha, rim);
          float tickA = fract((a + uTime * 0.03) / 6.28318 * 72.0);
          float tickLen = mix(0.045, 0.1, step(fract((a + uTime * 0.03) / 6.28318 * 12.0), 0.08));
          float tick = step(abs(tickA - 0.5), 0.07) * step(R + 0.03, r) * step(r, R + 0.03 + tickLen) * uOpacity;
          col += uRim * tick * 0.55;
          alpha = max(alpha, tick * 0.55);
          float glare = smoothstep(0.03, 0.0, abs(r - (R - 0.06))) * smoothstep(0.3, 1.0, sin(a - 2.2)) * 0.35 * uOpacity;
          col += vec3(1.0) * glare;
          float wt = uTime - uWave;
          if (wt > 0.0 && wt < 1.6) {
            float wr = R + wt * 0.8;
            float ring = exp(-pow((r - wr) / 0.03, 2.0)) * (1.0 - wt / 1.6);
            col += uEcho * ring * 2.0;
            alpha = max(alpha, ring);
          }
          gl_FragColor = vec4(col, alpha * max(uOpacity, uBackdrop));
        }
      `,
    }),
  );
  loupe.position.z = -1.25;
  loupe.renderOrder = -1;
  root.add(loupe);

  // Build parameters, eased toward the chosen step and view
  const anim = { spread: 0, gel: 1, load: 1, coat: 1, explode: 0, show: 1, ring: 1, backdrop: 0 };
  const m = new THREE.Matrix4();
  const up = new THREE.Vector3(0, 1, 0);
  const q = new THREE.Quaternion();
  const p = new THREE.Vector3();
  const s = new THREE.Vector3();
  const euler = new THREE.Euler();
  let lastCoat = -1;

  function layoutHeads(coatK: number) {
    if (Math.abs(coatK - lastCoat) < 1e-4) return;
    lastCoat = coatK;
    for (let i = 0; i < dirs.length; i++) {
      const k = easeOut(clamp01((coatK * (1 + maxDelay) - headDelay[i]) / 0.42));
      p.copy(dirs[i]).multiplyScalar(R_HEAD + (1 - k) * 0.75);
      s.setScalar((0.2 + 0.8 * k) * (k > 0.001 ? 1 : 0));
      q.setFromUnitVectors(up, dirs[i]);
      heads.setMatrixAt(i, m.compose(p, q, s));
    }
    heads.instanceMatrix.needsUpdate = true;
    const pk = clamp01((coatK - 0.75) / 0.25);
    for (let i = 0; i < proteinDirs.length; i++) {
      p.copy(proteinDirs[i]).multiplyScalar(R_HEAD + 0.03);
      q.setFromUnitVectors(up, proteinDirs[i]);
      s.setScalar(pk);
      proteins.setMatrixAt(i, m.compose(p, q, s));
    }
    proteins.instanceMatrix.needsUpdate = true;
  }

  function layoutMolecules(load: number, time: number) {
    for (let i = 0; i < DRUG_IN_GEL.length; i++) {
      const [x, y, z] = DRUG_IN_GEL[i];
      const k = easeOut(clamp01(load * 1.6 - i * 0.06));
      p.set(x, y, z).multiplyScalar(0.3 + 0.7 * k);
      q.setFromEuler(euler.set(i * 1.7 + time * 0.3, i * 0.9, i * 2.3));
      s.setScalar(k * 1.15);
      molecules.setMatrixAt(i, m.compose(p, q, s));
    }
    molecules.instanceMatrix.needsUpdate = true;
  }

  function update(time: number, frameDt: number, params: ParticleParams, camera: THREE.Camera) {
    const exploded = params.view === "exploded";
    const dt = params.snap ? 10 : frameDt;
    const spinDt = params.snap ? 0 : frameDt;
    anim.show = approach(anim.show, params.visible ? 1 : 0, dt, 3);
    anim.spread = approach(anim.spread, !exploded && params.step === "core" ? 1 : 0, dt, 2.2);
    anim.gel = approach(anim.gel, exploded || params.step !== "core" ? 1 : 0, dt, 1.8);
    anim.load = approach(anim.load, exploded || params.step !== "core" ? 1 : 0, dt, 1.3);
    anim.coat = approach(anim.coat, exploded || params.step === "coat" ? 1 : 0, dt, 1.2);
    anim.explode = approach(anim.explode, exploded ? 1 : 0, dt, 2);
    anim.ring = approach(anim.ring, params.ring && !exploded ? 1 : 0, dt, 3);
    anim.backdrop = approach(anim.backdrop, params.backdrop ? 1 : 0, dt, 2.4);

    root.visible = anim.show > 0.01;
    root.scale.setScalar(0.001 + anim.show * 0.999);
    root.lookAt(camera.position);
    spin.rotation.z = (Math.sin(time * 0.12) * 0.22 + time * 0.02) * (1 - anim.explode);

    // Exploded: core, gel and coat side by side, in build order
    const e = easeOut(anim.explode);
    core.group.position.set(-1.9 * e, 0.05 * e, 0.25 * e);
    gel.group.position.set(0.05 * e, 0, 0);
    coat.group.position.set(2.0 * e, -0.05 * e, -0.3 * e);
    coat.group.rotation.y = -0.35 * e;
    core.group.rotation.y = 0.3 * e;

    // Cores: a loose cluster while being made, then seated in the gel
    const loose = easeOut(anim.spread);
    for (const c of cores) {
      c.mesh.position.lerpVectors(c.inGel, c.loose, loose);
      c.mesh.rotateOnAxis(c.spinAxis, spinDt * (0.25 + loose * 0.35));
    }
    cappingUniforms.uOpacity.value = 0.06 + 0.94 * Math.max(loose, anim.explode * 0.5);
    core.body.scale.setScalar(1 + loose * 0.55 + anim.explode * 0.25);
    coreMat.emissiveIntensity = params.heat * 4.5;

    // Gel forms around the cores, then loads with drug
    const g = easeOut(anim.gel);
    gelSphere.scale.setScalar(Math.max(0.001, g));
    gelSphere.visible = g > 0.01;
    for (const c of gelCaps.caps) c.visible = g > 0.01;
    gelCaps.uniforms.uR.value.set(0, R_GEL * g);
    gelCaps.uniforms.uLoad.value = anim.load;
    gelCaps.uniforms.uWarm.value = params.heat;
    gelUniforms.uWarm.value = params.heat;
    layoutMolecules(anim.load * g, time);
    molecules.visible = anim.load > 0.01;

    // Coat wraps last
    tails.visible = anim.coat > 0.35;
    tails.scale.setScalar(THREE.MathUtils.lerp(R_GEL, R_TAIL, clamp01((anim.coat - 0.35) / 0.4)) / R_TAIL);
    for (const c of coatCaps.caps) c.visible = anim.coat > 0.6;
    layoutHeads(anim.coat);

    loupeUniforms.uTime.value = time;
    loupeUniforms.uWave.value = params.waveT;
    loupeUniforms.uOpacity.value = anim.ring;
    loupeUniforms.uBackdrop.value = anim.backdrop;
    loupe.visible = anim.ring > 0.01 || anim.backdrop > 0.01;

    root.updateMatrixWorld(true);
    for (const layer of [gel, coat]) {
      for (let i = 0; i < 3; i++) layer.planes[i].copy(LOCAL_PLANES[i]).applyMatrix4(layer.body.matrixWorld);
    }
  }

  const localAnchors: Record<string, [Layer, THREE.Vector3]> = {
    core: [core, new THREE.Vector3(0.58, 0.14, 0.12)],
    capping: [core, new THREE.Vector3(0.2, 0.32, 0.32)],
    gel: [gel, new THREE.Vector3(0.66, 0.02, 0.42)],
    drug: [gel, new THREE.Vector3(0.04, 0.4, 0.55)],
    coat: [coat, new THREE.Vector3(-0.3, 0.92, 0.25)],
    protein: [coat, (proteinDirs[3] ?? new THREE.Vector3(0.9, -0.3, 0.3)).clone().multiplyScalar(1.03)],
    xCore: [core, new THREE.Vector3(0.2, 0.2, 0.2)],
    xGel: [gel, new THREE.Vector3(0.1, 0.84, 0.1)],
    xCoat: [coat, new THREE.Vector3(0.1, 0.98, 0.1)],
  };

  const rootRight = new THREE.Vector3();
  function anchorWorld(name: string, out: THREE.Vector3) {
    if (name === "core" && anim.spread > 0.5) return cores[5].mesh.getWorldPosition(out);
    if (name === "capping" && anim.spread > 0.5) {
      cores[2].mesh.getWorldPosition(out);
      rootRight.setFromMatrixColumn(root.matrixWorld, 0).normalize().multiplyScalar(0.24 * core.body.scale.x);
      return out.add(rootRight);
    }
    const entry = localAnchors[name];
    if (!entry) return out.set(0, 0, 0);
    return entry[0].body.localToWorld(out.copy(entry[1]));
  }

  return { root, update, anchorWorld, anchorNames: Object.keys(localAnchors), radius: 1.2 };
}
