import * as THREE from "three";
import { RoundedBoxGeometry } from "three/addons/geometries/RoundedBoxGeometry.js";
import { ARTERY, COLORS, TUMOR, WAVE_SPEED } from "../constants";
import { PROBE_Z } from "./tissue";

/*
  A linear-array photoacoustic probe: bone handle, graphite transducer head, soft acoustic
  lens, and fibre-optic light bars flush on both elevation faces. Two indicator lines on the
  head tell the physics: amber where light leaves, cyan array elements where sound returns.
*/
export function createProbe() {
  const group = new THREE.Group();
  group.name = "probe";
  group.position.set(TUMOR.x, 0, PROBE_Z);

  const shellMat = new THREE.MeshPhysicalMaterial({
    color: 0xc9c3b9,
    roughness: 0.46,
    clearcoat: 0.35,
    clearcoatRoughness: 0.32,
    sheen: 0.25,
    sheenRoughness: 0.5,
    sheenColor: new THREE.Color(0xfff4e6),
  });
  const graphite = new THREE.MeshPhysicalMaterial({
    color: 0x1f2326,
    metalness: 0.25,
    roughness: 0.42,
    clearcoat: 0.7,
    clearcoatRoughness: 0.25,
  });

  // Handle silhouette, extruded and bevelled
  const s = new THREE.Shape();
  s.moveTo(-0.9, 0.5);
  s.lineTo(0.9, 0.5);
  s.quadraticCurveTo(0.98, 0.5, 0.97, 0.6);
  s.bezierCurveTo(0.95, 0.86, 0.46, 0.9, 0.44, 1.26);
  s.bezierCurveTo(0.43, 1.6, 0.49, 1.9, 0.47, 2.3);
  s.bezierCurveTo(0.46, 2.62, 0.4, 2.86, 0.18, 2.94);
  s.quadraticCurveTo(0, 2.98, -0.18, 2.94);
  s.bezierCurveTo(-0.4, 2.86, -0.46, 2.62, -0.47, 2.3);
  s.bezierCurveTo(-0.49, 1.9, -0.43, 1.6, -0.44, 1.26);
  s.bezierCurveTo(-0.46, 0.9, -0.95, 0.86, -0.97, 0.6);
  s.quadraticCurveTo(-0.98, 0.5, -0.9, 0.5);
  const depth = 0.34;
  const shellGeo = new THREE.ExtrudeGeometry(s, {
    depth,
    bevelEnabled: true,
    bevelThickness: 0.13,
    bevelSize: 0.08,
    bevelSegments: 12,
    curveSegments: 72,
  });
  shellGeo.translate(0, 0.02, -depth / 2);
  shellGeo.computeVertexNormals();
  const shell = new THREE.Mesh(shellGeo, shellMat);
  shell.castShadow = true;
  shell.receiveShadow = true;
  group.add(shell);

  // Transducer head and acoustic lens
  const head = new THREE.Mesh(new RoundedBoxGeometry(2.22, 0.46, 0.7, 6, 0.1), graphite);
  head.position.set(0, 0.34, 0);
  head.castShadow = true;
  head.receiveShadow = true;
  group.add(head);
  const lens = new THREE.Mesh(
    new RoundedBoxGeometry(2.06, 0.14, 0.52, 4, 0.06),
    new THREE.MeshPhysicalMaterial({ color: 0x2a343b, roughness: 0.55, clearcoat: 0.5, clearcoatRoughness: 0.4 }),
  );
  lens.position.set(0, 0.07, 0);
  group.add(lens);
  const seam = new THREE.Mesh(
    new RoundedBoxGeometry(2.0, 0.035, 0.62, 2, 0.015),
    new THREE.MeshStandardMaterial({ color: 0x8b8f92, metalness: 0.9, roughness: 0.25 }),
  );
  seam.position.set(0, 0.575, 0);
  group.add(seam);

  // Array elements: light up in the order the returning wavefront reaches them
  const arrayUniforms = {
    uTime: { value: 0 },
    uPAT: { value: -100 },
    uUsT: { value: -100 },
    uColor: { value: new THREE.Color(COLORS.echo) },
    uSpeed: { value: WAVE_SPEED },
    uSrc: { value: new THREE.Vector2(0, TUMOR.y + 0.35) },
    uVessel: { value: ARTERY.y },
  };
  const arrayMat = new THREE.ShaderMaterial({
    uniforms: arrayUniforms,
    vertexShader: /* glsl */ `
      varying vec2 vUv;
      void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
    `,
    fragmentShader: /* glsl */ `
      uniform float uTime, uPAT, uUsT, uSpeed, uVessel;
      uniform vec2 uSrc;
      uniform vec3 uColor;
      varying vec2 vUv;
      void main() {
        float cell = fract(vUv.x * 48.0);
        float seg = smoothstep(0.1, 0.2, cell) * smoothstep(0.9, 0.8, cell);
        float x = (vUv.x - 0.5) * 1.9;
        float arrive = uPAT + length(vec2(x - uSrc.x, uSrc.y)) / uSpeed;
        float e = uTime - arrive;
        float pa = e > 0.0 ? exp(-e * 2.4) : 0.0;
        float echoT = uUsT + 2.0 * abs(uVessel + 0.3) / uSpeed + abs(x) * 0.04;
        float e2 = uTime - echoT;
        float us = e2 > 0.0 ? exp(-e2 * 4.0) * 0.7 : 0.0;
        float lit = 0.22 + (pa + us) * 3.2;
        gl_FragColor = vec4(uColor * lit * seg, 1.0);
      }
    `,
  });
  const strip = new THREE.Mesh(new THREE.PlaneGeometry(1.9, 0.045), arrayMat);
  strip.position.set(0, 0.43, 0.352);
  group.add(strip);

  // Fibre-optic light bars (front and back), amber emitting edge at the skin
  const fiberMat = new THREE.MeshStandardMaterial({
    color: 0x000000,
    emissive: new THREE.Color(COLORS.pulse),
    emissiveIntensity: 0.5,
  });
  const barMat = new THREE.MeshPhysicalMaterial({ color: 0x121517, metalness: 0.6, roughness: 0.28, clearcoat: 0.8 });
  for (const side of [1, -1]) {
    const bar = new THREE.Mesh(new RoundedBoxGeometry(2.02, 0.2, 0.07, 3, 0.03), barMat);
    bar.position.set(0, 0.16, side * 0.38);
    bar.rotation.x = side * 0.16;
    bar.castShadow = true;
    group.add(bar);
    const fiber = new THREE.Mesh(new RoundedBoxGeometry(1.86, 0.03, 0.05, 2, 0.012), fiberMat);
    fiber.position.set(0, 0.055, side * 0.4);
    group.add(fiber);
  }

  // Cable leaving up and back
  const cableMat = new THREE.MeshPhysicalMaterial({ color: 0x1b1f22, roughness: 0.5, clearcoat: 0.5, clearcoatRoughness: 0.3 });
  const cablePath = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, 3.0, 0),
    new THREE.Vector3(0, 3.35, -0.08),
    new THREE.Vector3(-0.2, 3.85, -0.5),
    new THREE.Vector3(-0.8, 4.5, -1.4),
    new THREE.Vector3(-1.9, 5.2, -2.7),
    new THREE.Vector3(-3.4, 5.9, -4.1),
  ]);
  const cable = new THREE.Mesh(new THREE.TubeGeometry(cablePath, 120, 0.1, 20, false), cableMat);
  cable.castShadow = true;
  group.add(cable);
  const relief = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.19, 0.34, 32), cableMat);
  relief.position.set(0, 3.1, 0);
  group.add(relief);

  // Fibre bundle: the light pulse is visible travelling down it just before the flash
  const fiberUniforms = { uPulseU: { value: -1 }, uGlow: { value: new THREE.Color(COLORS.pulse) } };
  const fiberCableMat = new THREE.MeshPhysicalMaterial({ color: 0x191b1d, roughness: 0.42, clearcoat: 0.6 });
  fiberCableMat.onBeforeCompile = (shader) => {
    Object.assign(shader.uniforms, fiberUniforms);
    shader.vertexShader = shader.vertexShader
      .replace("#include <common>", "#include <common>\nvarying float vAlong;")
      .replace("#include <uv_vertex>", "#include <uv_vertex>\nvAlong = uv.x;");
    shader.fragmentShader = shader.fragmentShader
      .replace("#include <common>", "#include <common>\nvarying float vAlong;\nuniform float uPulseU;\nuniform vec3 uGlow;")
      .replace(
        "#include <emissivemap_fragment>",
        `#include <emissivemap_fragment>
        if (uPulseU >= 0.0) {
          float head = exp(-pow((vAlong - uPulseU) / 0.03, 2.0));
          float tail = smoothstep(uPulseU + 0.16, uPulseU, vAlong) * step(uPulseU, vAlong) * 0.35;
          totalEmissiveRadiance += uGlow * (head * 7.0 + tail);
        }`,
      );
  };
  fiberCableMat.customProgramCacheKey = () => "lab-fiber";
  const fiberPath = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0.99, 0.26, 0.45),
    new THREE.Vector3(0.93, 0.6, 0.52),
    new THREE.Vector3(0.66, 1.08, 0.5),
    new THREE.Vector3(0.6, 1.9, 0.44),
    new THREE.Vector3(0.44, 2.62, 0.3),
    new THREE.Vector3(0.2, 3.22, 0.08),
    new THREE.Vector3(0.06, 3.72, -0.3),
    new THREE.Vector3(-0.58, 4.45, -1.28),
    new THREE.Vector3(-1.72, 5.2, -2.6),
    new THREE.Vector3(-3.25, 5.95, -3.98),
  ]);
  const fiberCable = new THREE.Mesh(new THREE.TubeGeometry(fiberPath, 200, 0.045, 12, false), fiberCableMat);
  fiberCable.castShadow = true;
  group.add(fiberCable);
  const ferrule = new THREE.Mesh(
    new THREE.CylinderGeometry(0.065, 0.065, 0.16, 20),
    new THREE.MeshStandardMaterial({ color: 0x9a9fa3, metalness: 1, roughness: 0.3 }),
  );
  ferrule.position.set(0.99, 0.24, 0.45);
  group.add(ferrule);

  // Contact darkening where the lens meets the skin
  const contact = new THREE.Mesh(
    new THREE.PlaneGeometry(2.9, 1.3),
    new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      vertexShader: /* glsl */ `
        varying vec2 vUv;
        void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
      `,
      fragmentShader: /* glsl */ `
        varying vec2 vUv;
        void main() {
          vec2 p = (vUv - 0.5) * vec2(2.9, 1.3);
          vec2 d = abs(p) - vec2(1.0, 0.24);
          float dist = length(max(d, 0.0)) + min(max(d.x, d.y), 0.0);
          float a = (1.0 - smoothstep(0.0, 0.34, dist)) * 0.55;
          gl_FragColor = vec4(0.0, 0.0, 0.0, a);
        }
      `,
    }),
  );
  contact.rotation.x = -Math.PI / 2;
  contact.position.set(0, 0.004, 0);
  contact.renderOrder = 1;
  group.add(contact);

  const flash = new THREE.PointLight(COLORS.pulse, 0, 4, 2);
  flash.position.set(0, 0.12, 0.75);
  group.add(flash);

  /**
   * fiberU: position of the light pulse along the fibre (1 = far end, 0 = probe), or -1 when idle.
   * sourceX/sourceY: the strongest photoacoustic source, so the array lights in arrival order.
   */
  function update(time: number, laserT: number, usT: number, paT: number, fiberU: number, sourceX: number, sourceY: number) {
    fiberUniforms.uPulseU.value = fiberU;
    arrayUniforms.uSrc.value.set(sourceX - group.position.x, sourceY);
    const lt = time - laserT;
    const env = lt > 0 ? Math.exp(-lt * 5) : 0;
    fiberMat.emissiveIntensity = 0.5 + env * 6;
    flash.intensity = env * 7;
    arrayUniforms.uTime.value = time;
    arrayUniforms.uPAT.value = paT;
    arrayUniforms.uUsT.value = usT;
    return env;
  }

  /** Label points in the probe's own space (the group moves along the skin). */
  // Fade the whole instrument in and out (hidden while designing at the nanoscale)
  const materials = new Set<THREE.Material>();
  group.traverse((o) => {
    const mat = (o as THREE.Mesh).material as THREE.Material | undefined;
    if (mat) materials.add(mat);
  });
  let presence = 1;
  function setPresence(p: number) {
    if (Math.abs(p - presence) < 1e-3) return;
    const wasOpaque = presence >= 0.999;
    presence = p;
    const opaque = p >= 0.999;
    for (const mat of materials) {
      if (mat.userData.baseOpacity === undefined) mat.userData.baseOpacity = mat.opacity;
      mat.opacity = (mat.userData.baseOpacity as number) * p;
      if (opaque !== wasOpaque && !(mat as THREE.ShaderMaterial).isShaderMaterial) {
        mat.transparent = !opaque || mat.userData.baseTransparent === true;
        mat.needsUpdate = true;
      }
    }
    group.visible = p > 0.01;
  }
  for (const mat of materials) mat.userData.baseTransparent = mat.transparent;

  const anchors = {
    // The cyan array on the head is what actually receives the sound.
    array: new THREE.Vector3(-1.02, 0.43, 0.37),
    light: new THREE.Vector3(0.93, 0.07, 0.42),
    handle: new THREE.Vector3(-0.46, 2.1, 0.3),
  };

  return { group, update, anchors, setPresence };
}
