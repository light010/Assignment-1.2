import * as THREE from "three";
import { ARTERY, BLOCK, FACE_Z, LEAK, NP_SITES, TUMOR } from "../constants";
import type { Elapsed, Light, Particle } from "../state";

/*
  Blood flow through the cut artery (red cells and circulating particles), and the particles
  that leave through the leaky wall. Where they end up depends on what they are, following
  the delivery trade-off: large particles stall at the vessel rim, ultrasmall ones diffuse
  deep but wash out, and gel carriers hold at the rim until heat shrinks the gel and squeezes out
  the drug (the cores stay inside: a shrinking gel holds them tighter, not looser).
*/

const PIPE_HALF = (BLOCK.w - 0.07) / 2;

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const easeOut = (t: number) => 1 - Math.pow(1 - t, 3);
const easeInOut = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
const clamp01 = (t: number) => Math.min(1, Math.max(0, t));

/** Biconcave disc (Evans–Fung profile), diameter 2 * radius. */
function createRBCGeometry(radius: number) {
  const pts: THREE.Vector2[] = [];
  const thickness = (u: number) => {
    const s = Math.sqrt(Math.max(0, 1 - u * u));
    return 2 * s * (0.0518 + 0.50065 * u * u - 0.2807 * u ** 4);
  };
  const steps = 12;
  for (let i = 0; i <= steps; i++) {
    const u = Math.sin((i / steps) * (Math.PI / 2));
    pts.push(new THREE.Vector2(u * radius, (thickness(u) * radius) / 2 + 0.0005));
  }
  for (let i = steps; i >= 0; i--) {
    const u = Math.sin((i / steps) * (Math.PI / 2));
    pts.push(new THREE.Vector2(u * radius, -(thickness(u) * radius) / 2 - 0.0005));
  }
  const geo = new THREE.LatheGeometry(pts, 28);
  geo.computeVertexNormals();
  return geo;
}

/** Look of each particle kind, echoing the delivery figure: silver large, amber ultrasmall, blue gel. */
const KIND = {
  large: { radius: 0.052, color: new THREE.Color(0xb9c2c8), glow: 0.05 },
  ultrasmall: { radius: 0.02, color: new THREE.Color(0xffb04a), glow: 0.9 },
  gel: { radius: 0.043, color: new THREE.Color(0x6aa8ff), glow: 0.35 },
} as const;

export interface FlowInput {
  /** "imaging" = the settled platform used by the imaging chapters. */
  particle: Particle | "imaging";
  elapsed: Elapsed;
  light: Light;
  /** 0..1 flash from the most recent light pulse. */
  flash: number;
}

export interface FlowOutput {
  /** Share of carriers that sit in the tissue, 0..1. */
  accumulation: number;
  /** Up to four cluster centres (x, y, weight) where particles currently sit. */
  sources: Array<[number, number, number]>;
  /** 0..1 progress of heat-triggered release. */
  released: number;
}

interface Carrier {
  exitX: number;
  theta: number;
  rho: number;
  rim: THREE.Vector3;
  deep: THREE.Vector3;
  delay: number;
  jitter: number;
  fade: number;
  p: number;
  since: number;
  pos: THREE.Vector3;
  key: string;
}

export function createFlow({ lowPower }: { lowPower: boolean }) {
  const rand = mulberry32(7);
  const group = new THREE.Group();
  group.name = "flow";

  // Red blood cells
  const rbcCount = lowPower ? 22 : 36;
  const rbcMat = new THREE.MeshPhysicalMaterial({
    color: 0xa8141c,
    roughness: 0.38,
    clearcoat: 0.8,
    clearcoatRoughness: 0.22,
    sheen: 1,
    sheenColor: new THREE.Color(0xff5a48),
    sheenRoughness: 0.35,
    emissive: new THREE.Color(0x4a0508),
  });
  const rbcs = new THREE.InstancedMesh(createRBCGeometry(0.12), rbcMat, rbcCount);
  rbcs.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  rbcs.frustumCulled = false;
  const cells = Array.from({ length: rbcCount }, () => {
    const axis = new THREE.Vector3(rand() - 0.5, rand() - 0.5, rand() - 0.5).normalize();
    return {
      x: -PIPE_HALF + rand() * PIPE_HALF * 2,
      theta: Math.PI / 2 + 0.25 + rand() * (Math.PI - 0.5),
      rho: 0.02 + rand() * 0.11,
      spin: new THREE.Quaternion().setFromAxisAngle(axis, 0.5 + rand() * 0.8),
      q: new THREE.Quaternion().setFromEuler(new THREE.Euler(rand() * 6, rand() * 6, rand() * 6)),
    };
  });
  group.add(rbcs);

  // Particles share one mesh: circulating ones and carriers in tissue
  const circCount = lowPower ? 20 : 30;
  const carrierCount = lowPower ? 24 : 36;
  const total = circCount + carrierCount;
  const npMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.25, metalness: 0.2 });
  const glow = { value: 0.3 };
  npMat.onBeforeCompile = (shader) => {
    shader.uniforms.uGlow = glow;
    shader.fragmentShader = shader.fragmentShader
      .replace("#include <common>", "#include <common>\nuniform float uGlow;")
      .replace(
        "#include <emissivemap_fragment>",
        "#include <emissivemap_fragment>\n#ifdef USE_INSTANCING_COLOR\ntotalEmissiveRadiance += vColor * uGlow;\n#endif",
      );
  };
  npMat.customProgramCacheKey = () => "lab-particles";
  const nps = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1, 2), npMat, total);
  nps.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  nps.frustumCulled = false;
  const white = new THREE.Color(0xffffff);
  for (let i = 0; i < total; i++) nps.setColorAt(i, white);
  group.add(nps);

  const circulating = Array.from({ length: circCount }, () => ({
    x: -PIPE_HALF + rand() * PIPE_HALF * 2,
    theta: Math.PI / 2 + 0.1 + rand() * (Math.PI - 0.2),
    rho: rand() * (ARTERY.r - 0.06),
    phase: rand() * 10,
  }));

  const floorOfRim = ARTERY.y - ARTERY.r - 0.1;
  const carriers: Carrier[] = [];
  for (let i = 0; i < carrierCount; i++) {
    const exitX = LEAK.x0 + 0.08 + rand() * (LEAK.x1 - LEAK.x0 - 0.16);
    const rim = new THREE.Vector3(exitX + (rand() - 0.5) * 0.3, floorOfRim - rand() * 0.28, FACE_Z + 0.02);
    const [sx, sy] = NP_SITES[i % NP_SITES.length];
    let dx = sx + (rand() - 0.5) * 0.42;
    let dy = sy + (rand() - 0.5) * 0.36;
    const d = Math.hypot(dx - TUMOR.x, (dy - TUMOR.y) * 1.1);
    if (d > TUMOR.r * 0.88) {
      const k = (TUMOR.r * 0.88) / d;
      dx = TUMOR.x + (dx - TUMOR.x) * k;
      dy = TUMOR.y + (dy - TUMOR.y) * k;
    }
    carriers.push({
      exitX,
      theta: Math.PI + (rand() - 0.5) * 1.6,
      rho: 0.04 + rand() * 0.12,
      rim,
      deep: new THREE.Vector3(dx, dy, FACE_Z + 0.02),
      delay: rand() * 1.6,
      jitter: rand() * 100,
      fade: rand(),
      p: 1,
      since: 0,
      pos: new THREE.Vector3(dx, dy, FACE_Z + 0.02),
      key: "imaging:h",
    });
  }
  // Drug molecules pushed out of gel carriers by heat
  const perCarrier = lowPower ? 4 : 7;
  const dropCount = carrierCount * perCarrier;
  const dropPos = new Float32Array(dropCount * 3);
  const dropAlpha = new Float32Array(dropCount);
  const dropSeeds = Array.from({ length: dropCount }, () => ({
    dir: new THREE.Vector2(rand() - 0.5, rand() - 0.5 - 0.35).normalize(),
    delay: rand() * 2.2,
    speed: 0.25 + rand() * 0.35,
  }));
  const dropGeo = new THREE.BufferGeometry();
  dropGeo.setAttribute("position", new THREE.BufferAttribute(dropPos, 3).setUsage(THREE.DynamicDrawUsage));
  dropGeo.setAttribute("alpha", new THREE.BufferAttribute(dropAlpha, 1).setUsage(THREE.DynamicDrawUsage));
  const dropMat = new THREE.ShaderMaterial({
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    uniforms: { uColor: { value: new THREE.Color(0xff5c4a).multiplyScalar(2.2) }, uScale: { value: 1 } },
    vertexShader: /* glsl */ `
      attribute float alpha;
      uniform float uScale;
      varying float vAlpha;
      void main() {
        vAlpha = alpha;
        vec4 mv = modelViewMatrix * vec4(position, 1.0);
        gl_PointSize = uScale * 80.0 / -mv.z;
        gl_Position = projectionMatrix * mv;
      }
    `,
    fragmentShader: /* glsl */ `
      uniform vec3 uColor;
      varying float vAlpha;
      void main() {
        float d = length(gl_PointCoord - 0.5);
        float a = smoothstep(0.5, 0.1, d) * vAlpha;
        if (a < 0.01) discard;
        gl_FragColor = vec4(uColor * a, a);
      }
    `,
  });
  const drops = new THREE.Points(dropGeo, dropMat);
  drops.frustumCulled = false;
  group.add(drops);

  const m = new THREE.Matrix4();
  const pos = new THREE.Vector3();
  const tmp = new THREE.Vector3();
  const scl = new THREE.Vector3();
  const tmpQ = new THREE.Quaternion();
  const identity = new THREE.Quaternion();
  const ctrl = new THREE.Vector3();
  const clusters = [new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3()];
  const clusterW = [0, 0, 0, 0];
  let releaseProgress = 0;
  let clock = 0;

  function lumenPoint(x: number, theta: number, rho: number, out: THREE.Vector3) {
    return out.set(x, ARTERY.y + rho * Math.sin(theta), FACE_Z + rho * Math.cos(theta));
  }

  /** Carrier position along its journey: vessel (0..0.4), out through the wall (0.4..0.55), into tissue (0.55..1). */
  function journey(c: Carrier, target: THREE.Vector3, p: number, out: THREE.Vector3) {
    if (p < 0.4) {
      const k = easeInOut(p / 0.4);
      return lumenPoint(THREE.MathUtils.lerp(-PIPE_HALF, c.exitX, k), c.theta, c.rho, out);
    }
    if (p < 0.55) {
      const k = easeInOut((p - 0.4) / 0.15);
      const a = lumenPoint(c.exitX, c.theta, c.rho, tmp);
      return out.set(c.exitX, THREE.MathUtils.lerp(a.y, floorOfRim, k), THREE.MathUtils.lerp(a.z, FACE_Z + 0.02, k));
    }
    const k = easeOut((p - 0.55) / 0.45);
    ctrl.set((c.exitX + target.x) / 2 + 0.1, Math.min(floorOfRim, target.y) + 0.12, FACE_Z + 0.02);
    const u = 1 - k;
    return out.set(
      u * u * c.exitX + 2 * u * k * ctrl.x + k * k * target.x,
      u * u * floorOfRim + 2 * u * k * ctrl.y + k * k * target.y,
      FACE_Z + 0.02,
    );
  }

  function update(time: number, dt: number, input: FlowInput): FlowOutput {
    clock += dt;
    const kindKey = input.particle === "imaging" ? "gel" : input.particle;
    const kind = KIND[kindKey];
    const rate = input.particle === "imaging" ? 0.85 : 1.1;

    // Red cells: parabolic (Poiseuille) velocity profile
    for (let i = 0; i < cells.length; i++) {
      const c = cells[i];
      c.x += (0.95 * (1 - (c.rho / ARTERY.r) ** 2) + 0.2) * rate * dt;
      if (c.x > PIPE_HALF + 0.2) c.x -= PIPE_HALF * 2 + 0.4;
      tmpQ.copy(identity).slerp(c.spin, Math.min(1, dt * 1.2 * rate));
      c.q.multiply(tmpQ);
      lumenPoint(c.x, c.theta, c.rho, pos);
      scl.setScalar(clamp01((PIPE_HALF + 0.02 - Math.abs(c.x)) / 0.25));
      rbcs.setMatrixAt(i, m.compose(pos, c.q, scl));
    }
    rbcs.instanceMatrix.needsUpdate = true;

    let slot = 0;
    for (const p of circulating) {
      p.x += (1.1 * (1 - (p.rho / ARTERY.r) ** 2) + 0.25) * rate * dt;
      if (p.x > PIPE_HALF + 0.1) p.x -= PIPE_HALF * 2 + 0.2;
      lumenPoint(p.x, p.theta + Math.sin(time * 1.3 + p.phase) * 0.05, p.rho, pos);
      scl.setScalar(kind.radius * clamp01((PIPE_HALF - Math.abs(p.x)) / 0.2));
      nps.setMatrixAt(slot, m.compose(pos, identity, scl));
      nps.setColorAt(slot++, kind.color);
    }

    // Where each carrier should be, given the particle kind, time since injection, and light
    const imaging = input.particle === "imaging";
    const minutes = input.elapsed === "minutes" && !imaging;
    const washed = input.particle === "ultrasmall" && input.elapsed === "day";
    const heating = input.light === "continuous";
    const releasing = input.particle === "gel" && heating;
    releaseProgress = THREE.MathUtils.clamp(releaseProgress + (releasing ? dt / 2.6 : -dt / 1.2), 0, 1);
    const key = `${input.particle}:${minutes ? "m" : "h"}`;

    let inTissue = 0;
    for (let k = 0; k < 4; k++) {
      clusters[k].set(0, 0, 0);
      clusterW[k] = 0;
    }
    for (let i = 0; i < carriers.length; i++) {
      const c = carriers[i];
      if (c.key !== key) {
        // A new choice re-delivers: fresh particles enter from the vessel and travel again
        c.key = key;
        c.p = 0;
        c.since = 0;
      }
      c.since += dt;
      const deep = imaging || input.particle === "ultrasmall";
      const target = deep ? c.deep : c.rim;
      const goal = minutes ? (i % 4 === 0 ? 1 : 0.38) : 1;
      if (c.since > c.delay) c.p = Math.min(goal, c.p + dt / 2.2);
      journey(c, target, c.p, c.pos);
      c.pos.x += Math.sin(time * 0.9 + c.jitter) * 0.01 * c.p;
      c.pos.y += Math.cos(time * 0.8 + c.jitter) * 0.01 * c.p;

      let vis = c.p > 0.001 ? 1 : 0;
      if (washed) vis *= c.fade < 0.22 ? 1 : 0;
      scl.setScalar(kind.radius * vis * (kindKey === "gel" ? 1 - releaseProgress * 0.35 : 1));
      nps.setMatrixAt(slot, m.compose(c.pos, identity, scl));
      nps.setColorAt(slot++, kind.color);

      if (c.p > 0.55 && vis > 0) {
        inTissue++;
        const ci = i % 4;
        clusters[ci].add(c.pos);
        clusterW[ci]++;
      }
    }

    nps.instanceMatrix.needsUpdate = true;
    if (nps.instanceColor) nps.instanceColor.needsUpdate = true;
    glow.value = kind.glow + input.flash * 3.2 + (heating ? 0.9 + Math.sin(time * 3) * 0.15 : 0);

    // Drug released from gel carriers while heated
    for (let i = 0; i < dropCount; i++) {
      const c = carriers[Math.floor(i / perCarrier)];
      const sd = dropSeeds[i];
      const life = ((((clock - sd.delay) % 2.4) + 2.4) % 2.4) / 2.4;
      const on = releaseProgress > 0.05 && c.p > 0.55 ? releaseProgress : 0;
      const r = sd.speed * easeOut(life);
      const o = i * 3;
      dropPos[o] = c.pos.x + sd.dir.x * r;
      dropPos[o + 1] = c.pos.y + sd.dir.y * r;
      dropPos[o + 2] = FACE_Z + 0.03;
      dropAlpha[i] = on * Math.sin(Math.PI * life) * 0.9;
    }
    dropGeo.attributes.position.needsUpdate = true;
    dropGeo.attributes.alpha.needsUpdate = true;

    const sources: Array<[number, number, number]> = [];
    for (let k = 0; k < 4; k++) {
      if (clusterW[k] === 0) continue;
      clusters[k].divideScalar(clusterW[k]);
      sources.push([clusters[k].x, clusters[k].y, Math.min(1, clusterW[k] / (carrierCount / 4))]);
    }
    return { accumulation: inTissue / carriers.length, sources, released: releaseProgress };
  }

  /** Representative points for labels. */
  const anchors = {
    rim: new THREE.Vector3((LEAK.x0 + LEAK.x1) / 2 - 0.35, floorOfRim - 0.12, FACE_Z),
    tumorCore: new THREE.Vector3(TUMOR.x + 0.2, TUMOR.y - 0.25, FACE_Z),
    leak: new THREE.Vector3(LEAK.x1 - 0.2, ARTERY.y + ARTERY.r + 0.04, FACE_Z),
  };

  return { group, update, dropMaterial: dropMat, anchors };
}
