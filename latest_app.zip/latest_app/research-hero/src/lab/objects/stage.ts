import * as THREE from "three";
import { BLOCK } from "../constants";

/* The room: an optical breadboard to stand on, a soft backdrop, and dust in the key light. */
export function createStage({ lowPower }: { lowPower: boolean }) {
  const group = new THREE.Group();
  group.name = "stage";

  const floorY = -BLOCK.h;
  const boardMat = new THREE.MeshPhysicalMaterial({
    color: 0xffffff,
    metalness: 0.6,
    roughness: 0.36,
    clearcoat: 0.35,
    clearcoatRoughness: 0.4,
  });
  boardMat.onBeforeCompile = (shader) => {
    shader.vertexShader = shader.vertexShader
      .replace("#include <common>", "#include <common>\nvarying vec3 vBoardPos;")
      .replace("#include <project_vertex>", "#include <project_vertex>\nvBoardPos = (modelMatrix * vec4(transformed, 1.0)).xyz;");
    shader.fragmentShader = shader.fragmentShader
      .replace("#include <common>", "#include <common>\nvarying vec3 vBoardPos;\nfloat boardHole;")
      .replace(
        "#include <map_fragment>",
        `
        vec2 grid = vBoardPos.xz / 0.5;
        vec2 cell = fract(grid) - 0.5;
        float d = length(cell) * 0.5;
        // Antialias by pixel footprint, and let the grid dissolve before it can moire.
        float fw = length(fwidth(grid));
        float aa = fw * 0.25 + 0.002;
        float keep = 1.0 - smoothstep(0.18, 0.42, fw);
        boardHole = (1.0 - smoothstep(0.055 - aa, 0.055 + aa, d)) * keep;
        float chamfer = (smoothstep(0.075 + aa, 0.058, d) * (1.0 - boardHole)) * keep;
        float fall = exp(-dot(vBoardPos.xz - vec2(0.6, 0.0), vBoardPos.xz - vec2(0.6, 0.0)) / 90.0);
        vec3 base = vec3(0.028, 0.032, 0.036);
        base *= 1.0 - boardHole * 0.92;
        base += chamfer * 0.03;
        diffuseColor.rgb = base * (0.35 + 0.65 * fall);
        `,
      )
      .replace(
        "#include <roughnessmap_fragment>",
        "#include <roughnessmap_fragment>\nroughnessFactor = mix(roughnessFactor, 0.9, boardHole);",
      );
  };
  boardMat.customProgramCacheKey = () => "lab-board";
  const board = new THREE.Mesh(new THREE.PlaneGeometry(60, 40), boardMat);
  const contact = new THREE.Mesh(
    new THREE.PlaneGeometry(BLOCK.w + 2.4, BLOCK.d + 2.4),
    new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      uniforms: { uSize: { value: new THREE.Vector2(BLOCK.w + 2.4, BLOCK.d + 2.4) }, uBox: { value: new THREE.Vector2(BLOCK.w / 2, BLOCK.d / 2) } },
      vertexShader: /* glsl */ `
        varying vec2 vUv;
        void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
      `,
      fragmentShader: /* glsl */ `
        uniform vec2 uSize, uBox;
        varying vec2 vUv;
        void main() {
          vec2 p = (vUv - 0.5) * uSize;
          vec2 d = abs(p) - uBox;
          float dist = length(max(d, 0.0)) + min(max(d.x, d.y), 0.0);
          float a = (1.0 - smoothstep(-0.2, 1.1, dist)) * 0.78;
          gl_FragColor = vec4(0.0, 0.0, 0.0, a);
        }
      `,
    }),
  );
  contact.rotation.x = -Math.PI / 2;
  contact.position.set(0, floorY + 0.003, 0);
  contact.renderOrder = 1;
  group.add(contact);
  board.rotation.x = -Math.PI / 2;
  board.position.y = floorY;
  board.receiveShadow = true;
  group.add(board);

  const backdrop = new THREE.Mesh(
    new THREE.PlaneGeometry(90, 44),
    new THREE.ShaderMaterial({
      depthWrite: false,
      uniforms: { uTime: { value: 0 } },
      vertexShader: /* glsl */ `
        varying vec2 vUv;
        void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
      `,
      fragmentShader: /* glsl */ `
        varying vec2 vUv;
        float h(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
        void main() {
          vec2 p = (vUv - vec2(0.56, 0.42)) * vec2(2.2, 1.0);
          float glow = exp(-dot(p, p) * 5.0);
          vec2 p2 = (vUv - vec2(0.7, 0.66)) * vec2(2.6, 1.3);
          float glow2 = exp(-dot(p2, p2) * 9.0);
          vec3 col = vec3(0.004, 0.007, 0.009);
          col += vec3(0.012, 0.032, 0.04) * glow;
          col += vec3(0.02, 0.028, 0.03) * glow2 * 0.6;
          // Out-of-focus lab lights: soft discs with a brighter rim, like lens bokeh
          vec2 asp = vec2(90.0 / 44.0, 1.0);
          vec4 bk[5];
          bk[0] = vec4(0.18, 0.62, 0.055, 0.0);
          bk[1] = vec4(0.83, 0.74, 0.07, 1.0);
          bk[2] = vec4(0.9, 0.45, 0.035, 0.0);
          bk[3] = vec4(0.36, 0.8, 0.03, 1.0);
          bk[4] = vec4(0.66, 0.86, 0.045, 0.0);
          for (int i = 0; i < 5; i++) {
            float d = length((vUv - bk[i].xy) * asp);
            float disc = smoothstep(bk[i].z, bk[i].z * 0.93, d);
            float rim = exp(-pow((d - bk[i].z * 0.95) / (bk[i].z * 0.05), 2.0));
            vec3 tint = mix(vec3(0.05, 0.14, 0.16), vec3(0.16, 0.1, 0.05), bk[i].w);
            col += tint * (disc * 0.12 + rim * 0.1);
          }
          col += (h(gl_FragCoord.xy) - 0.5) * 0.0025;
          gl_FragColor = vec4(col, 1.0);
        }
      `,
    }),
  );
  backdrop.position.set(2, 3, -18);
  backdrop.renderOrder = -10;
  group.add(backdrop);

  const count = lowPower ? 140 : 320;
  const pos = new Float32Array(count * 3);
  const seed = new Float32Array(count);
  for (let i = 0; i < count; i++) {
    pos[i * 3] = -9 + Math.random() * 20;
    pos[i * 3 + 1] = -3 + Math.random() * 10;
    pos[i * 3 + 2] = -6 + Math.random() * 12;
    seed[i] = Math.random();
  }
  const dustGeo = new THREE.BufferGeometry();
  dustGeo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  dustGeo.setAttribute("seed", new THREE.BufferAttribute(seed, 1));
  const dustUniforms = { uTime: { value: 0 }, uScale: { value: 1 }, uFlash: { value: 0 } };
  const dust = new THREE.Points(
    dustGeo,
    new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      uniforms: dustUniforms,
      vertexShader: /* glsl */ `
        attribute float seed;
        uniform float uTime, uScale;
        varying float vA;
        void main() {
          vec3 p = position;
          p.y = mod(p.y + uTime * (0.05 + seed * 0.08) + 3.0, 10.0) - 3.0;
          p.x += sin(uTime * 0.21 + seed * 40.0) * 0.35;
          p.z += cos(uTime * 0.17 + seed * 23.0) * 0.3;
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          float beam = exp(-pow((p.x - 0.4) / 4.5, 2.0)) * smoothstep(-3.5, 1.0, p.y);
          vA = (0.12 + 0.5 * beam) * (0.4 + 0.6 * seed) * smoothstep(10.0, 7.0, p.y + 3.0);
          gl_PointSize = uScale * (0.9 + seed * 1.8) * 26.0 / -mv.z;
          gl_Position = projectionMatrix * mv;
        }
      `,
      fragmentShader: /* glsl */ `
        uniform float uFlash;
        varying float vA;
        void main() {
          float d = length(gl_PointCoord - 0.5);
          float a = smoothstep(0.5, 0.0, d) * vA;
          vec3 col = mix(vec3(0.9, 0.86, 0.8), vec3(1.0, 0.7, 0.4), uFlash);
          gl_FragColor = vec4(col * a * (1.0 + uFlash * 2.0), a);
        }
      `,
    }),
  );
  dust.frustumCulled = false;
  group.add(dust);

  function update(time: number, flash: number) {
    dustUniforms.uTime.value = time;
    dustUniforms.uFlash.value = flash;
  }

  return { group, update, dustUniforms };
}
