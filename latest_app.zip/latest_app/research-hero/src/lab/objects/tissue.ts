import * as THREE from "three";
import { RoundedBoxGeometry } from "three/addons/geometries/RoundedBoxGeometry.js";
import { ARTERY, BLOCK, COLORS, CYST, FACE_Z, LEAK, PROBE_APERTURE, TUMOR, VEIN, WAVE_SPEED } from "../constants";
import { tissueMainGLSL, tissueParsGLSL } from "../glsl";

/** Probe footprint on the skin (z) — shared with the probe placement. */
export const PROBE_Z = FACE_Z - 0.46;

export function createTissue() {
  const group = new THREE.Group();
  group.name = "tissue";

  const uniforms = {
    uTime: { value: 0 },
    uBlock: { value: new THREE.Vector3(BLOCK.w, BLOCK.h, BLOCK.d) },
    uArtery: { value: new THREE.Vector2(ARTERY.y, ARTERY.r) },
    uVein: { value: new THREE.Vector3(VEIN.x, VEIN.y, VEIN.r) },
    uCyst: { value: new THREE.Vector3(CYST.x, CYST.y, CYST.r) },
    uLeak: { value: new THREE.Vector2(LEAK.x0, LEAK.x1) },
    uTumor: { value: new THREE.Vector3(TUMOR.x, TUMOR.y, TUMOR.r) },
    uProbe: { value: new THREE.Vector3(TUMOR.x, PROBE_APERTURE, PROBE_Z) },
    uAccum: { value: 1 },
    uLaserT: { value: -100 },
    uUsT: { value: -100 },
    uPAT: { value: -100 },
    uWaveSpeed: { value: WAVE_SPEED },
    uSrc: { value: Array.from({ length: 8 }, () => new THREE.Vector4()) },
    uSkinPA: { value: 0 },
    uMelanin: { value: 0 },
    uHeat: { value: 0 },
    uDamage: { value: 0 },
    uPulseColor: { value: new THREE.Color(COLORS.pulse).multiplyScalar(1.2) },
    uEchoColor: { value: new THREE.Color(COLORS.echo).multiplyScalar(1.25) },
    uHeatColor: { value: new THREE.Color(0xff6a2a).multiplyScalar(1.0) },
    uDim: { value: 1 },
  };

  const material = new THREE.MeshPhysicalMaterial({
    color: 0xffffff,
    roughness: 0.45,
    metalness: 0,
    clearcoat: 0.35,
    clearcoatRoughness: 0.42,
    sheen: 0.35,
    sheenRoughness: 0.6,
    sheenColor: new THREE.Color(0xff9d8a),
  });

  material.onBeforeCompile = (shader) => {
    Object.assign(shader.uniforms, uniforms);
    shader.vertexShader = shader.vertexShader
      .replace(
        "#include <common>",
        "#include <common>\nvarying vec3 vLabPos;\nvarying vec3 vLabNormal;",
      )
      .replace(
        "#include <project_vertex>",
        "#include <project_vertex>\nvLabPos = (modelMatrix * vec4(transformed, 1.0)).xyz;\nvLabNormal = normalize(mat3(modelMatrix) * objectNormal);",
      );
    shader.fragmentShader = shader.fragmentShader
      .replace("#include <common>", `#include <common>\n${tissueParsGLSL}`)
      .replace("#include <map_fragment>", tissueMainGLSL)
      .replace(
        "#include <roughnessmap_fragment>",
        "#include <roughnessmap_fragment>\nroughnessFactor = labT.rough;",
      )
      .replace(
        "#include <normal_fragment_maps>",
        `#include <normal_fragment_maps>
        {
          vec2 labDh = vec2(dFdx(labT.height), dFdy(labT.height)) * 0.32;
          normal = labPerturbNormal(-vViewPosition, normal, labDh, faceDirection);
        }`,
      )
      .replace(
        "#include <emissivemap_fragment>",
        "#include <emissivemap_fragment>\ntotalEmissiveRadiance += labT.emissive;",
      );
  };
  material.customProgramCacheKey = () => "lab-tissue";

  const block = new THREE.Mesh(new RoundedBoxGeometry(BLOCK.w, BLOCK.h, BLOCK.d, 5, BLOCK.r), material);
  block.position.set(0, -BLOCK.h / 2, 0);
  block.castShadow = true;
  block.receiveShadow = true;
  group.add(block);

  // The vessel's far half, seen through the cut. The shader opens a window in the face.
  const pipeLength = BLOCK.w - 0.07;
  const pipeGeo = new THREE.CylinderGeometry(ARTERY.r, ARTERY.r, pipeLength, 64, 24, true, Math.PI / 2, Math.PI);
  pipeGeo.rotateZ(Math.PI / 2);
  const pipeMat = createVesselWallMaterial();
  const pipe = new THREE.Mesh(pipeGeo, pipeMat);
  pipe.position.set(0, ARTERY.y, FACE_Z);
  pipe.receiveShadow = false;
  group.add(pipe);

  const capGeo = new THREE.CircleGeometry(ARTERY.r, 32, -Math.PI / 2, Math.PI);
  capGeo.rotateY(Math.PI / 2);
  const capMat = new THREE.MeshStandardMaterial({ color: 0x1a0204, roughness: 0.5, side: THREE.DoubleSide });
  for (const side of [-1, 1]) {
    const cap = new THREE.Mesh(capGeo, capMat);
    cap.position.set((side * pipeLength) / 2, ARTERY.y, FACE_Z);
    group.add(cap);
  }

  // Plasma haze: gives the lumen depth so cells read as suspended, not pasted on.
  const hazeGeo = new THREE.PlaneGeometry(pipeLength, ARTERY.r * 2);
  const hazeMat = new THREE.ShaderMaterial({
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    uniforms: { uTime: uniforms.uTime, uColor: { value: new THREE.Color(0xff5a4a) } },
    vertexShader: /* glsl */ `
      varying vec2 vUv;
      void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
    `,
    fragmentShader: /* glsl */ `
      uniform vec3 uColor;
      uniform float uTime;
      varying vec2 vUv;
      void main() {
        float y = abs(vUv.y - 0.5) * 2.0;
        float core = (1.0 - y * y) * 0.022;
        float edgeFade = smoothstep(0.0, 0.03, vUv.x) * smoothstep(1.0, 0.97, vUv.x);
        gl_FragColor = vec4(uColor * core * edgeFade, 1.0);
      }
    `,
  });
  const haze = new THREE.Mesh(hazeGeo, hazeMat);
  haze.position.set(0, ARTERY.y, FACE_Z - 0.02);
  haze.renderOrder = 2;
  group.add(haze);

  return { group, block, uniforms };
}

function createVesselWallMaterial() {
  const mat = new THREE.MeshPhysicalMaterial({
    color: 0xffffff,
    roughness: 0.44,
    clearcoat: 0.45,
    clearcoatRoughness: 0.38,
    side: THREE.BackSide,
  });
  mat.onBeforeCompile = (shader) => {
    shader.vertexShader = shader.vertexShader
      .replace("#include <common>", "#include <common>\nvarying vec3 vWallPos;")
      .replace("#include <project_vertex>", "#include <project_vertex>\nvWallPos = position;");
    shader.fragmentShader = shader.fragmentShader
      .replace(
        "#include <common>",
        `#include <common>
        varying vec3 vWallPos;
        float wHash(vec2 p) { vec3 p3 = fract(vec3(p.xyx) * 0.1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
        float wNoise(vec2 p) { vec2 i = floor(p); vec2 f = fract(p); vec2 u = f * f * (3.0 - 2.0 * f);
          return mix(mix(wHash(i), wHash(i + vec2(1.0, 0.0)), u.x), mix(wHash(i + vec2(0.0, 1.0)), wHash(i + vec2(1.0, 1.0)), u.x), u.y); }`,
      )
      .replace(
        "#include <map_fragment>",
        `float wAng = atan(vWallPos.y, vWallPos.z);
        vec2 wUv = vec2(vWallPos.x * 7.0, wAng * 3.2);
        float cellsW = wNoise(wUv * vec2(1.0, 2.2)) * 0.6 + wNoise(wUv * 3.1) * 0.4;
        float depthShade = smoothstep(-0.3, 0.3, vWallPos.y) * 0.5 + 0.5;
        diffuseColor.rgb = mix(vec3(0.16, 0.01, 0.02), vec3(0.36, 0.03, 0.05), cellsW) * depthShade;`,
      );
  };
  mat.customProgramCacheKey = () => "lab-vessel-wall";
  return mat;
}
