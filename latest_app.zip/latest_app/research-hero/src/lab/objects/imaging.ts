import * as THREE from "three";
import { COLORS, FACE_Z, FOV } from "../constants";

/*
  The probe's imaging plane, drawn as an augmented-reality overlay on the cut face: the slice
  the probe actually sees, framed, with the live image (photoacoustic colours or ultrasound
  grey) laid over the tissue it came from. And a floating screen for the raw channel data.
*/

export function createImagingPlane() {
  const canvas = document.createElement("canvas");
  canvas.width = 4;
  canvas.height = 4;
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.minFilter = THREE.LinearFilter;
  texture.generateMipmaps = false;

  const uniforms = {
    uMap: { value: texture as THREE.Texture },
    uOpacity: { value: 0 },
    uTime: { value: 0 },
    uMode: { value: 0 },
    uSweep: { value: -100 },
    uFrame: { value: new THREE.Color(COLORS.echo) },
  };
  const mesh = new THREE.Mesh(
    new THREE.PlaneGeometry(FOV.halfWidth * 2, FOV.depth),
    new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      uniforms,
      vertexShader: /* glsl */ `
        varying vec2 vUv;
        void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
      `,
      fragmentShader: /* glsl */ `
        uniform sampler2D uMap;
        uniform float uOpacity, uTime, uMode, uSweep;
        uniform vec3 uFrame;
        varying vec2 vUv;
        void main() {
          vec4 tex = texture2D(uMap, vUv);
          vec2 d = min(vUv, 1.0 - vUv);
          float border = 1.0 - smoothstep(0.0, 0.0035, min(d.x, d.y));
          float corner = max(step(d.x, 0.07) * step(d.y, 0.01), step(d.y, 0.07) * step(d.x, 0.01));
          float scan = 0.86 + 0.14 * sin(vUv.y * 420.0 + uTime * 2.4);
          // A sweep refreshes the image from left to right after each acquisition
          float st = uTime - uSweep;
          float swept = st > 0.0 && st < 1.3 ? step(vUv.x, st / 1.3) : 1.0;
          float line = st > 0.0 && st < 1.3 ? exp(-pow((vUv.x - st / 1.3) / 0.012, 2.0)) : 0.0;
          vec3 col;
          if (uMode < 0.5) {
            col = tex.rgb * tex.a * 1.35 * scan;
          } else {
            float v = dot(tex.rgb, vec3(0.333));
            col = vec3(0.55, 0.85, 0.95) * pow(v, 1.3) * 0.85 * scan;
          }
          col *= mix(0.25, 1.0, swept);
          col += uFrame * (border * 0.4 + corner * 1.1 + line * 0.8);
          gl_FragColor = vec4(col * uOpacity, 1.0);
        }
      `,
    }),
  );
  mesh.position.set(0, -FOV.depth / 2, FACE_Z + 0.006);
  mesh.renderOrder = 3;
  mesh.visible = false;

  let key = "";
  function setImage(source: HTMLCanvasElement, mode: "pa" | "us", sourceKey: string) {
    if (sourceKey === key) return;
    key = sourceKey;
    canvas.width = source.width;
    canvas.height = source.height;
    canvas.getContext("2d")!.drawImage(source, 0, 0);
    texture.needsUpdate = true;
    uniforms.uMode.value = mode === "pa" ? 0 : 1;
  }

  function update(time: number, centerX: number, opacity: number, sweepT: number) {
    mesh.position.x = centerX;
    uniforms.uTime.value = time;
    uniforms.uOpacity.value = opacity;
    uniforms.uSweep.value = sweepT;
    mesh.visible = opacity > 0.01 && key !== "";
  }

  return { mesh, setImage, update };
}

export function createEchoScreen() {
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 420;
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  const group = new THREE.Group();
  const uniforms = {
    uMap: { value: texture as THREE.Texture },
    uOpacity: { value: 0 },
    uTime: { value: 0 },
    uFrame: { value: new THREE.Color(COLORS.echo) },
  };
  const screen = new THREE.Mesh(
    new THREE.PlaneGeometry(2.3, 1.9),
    new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      uniforms,
      vertexShader: /* glsl */ `
        varying vec2 vUv;
        void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
      `,
      fragmentShader: /* glsl */ `
        uniform sampler2D uMap;
        uniform float uOpacity, uTime;
        uniform vec3 uFrame;
        varying vec2 vUv;
        void main() {
          vec2 inner = (vUv - 0.5) * vec2(1.06, 1.08) + 0.5;
          vec3 col = vec3(0.01, 0.025, 0.03);
          float a = 0.82;
          if (inner.x > 0.0 && inner.x < 1.0 && inner.y > 0.0 && inner.y < 1.0) {
            col = texture2D(uMap, inner).rgb;
          }
          vec2 d = min(vUv, 1.0 - vUv);
          float border = 1.0 - smoothstep(0.0, 0.006, min(d.x, d.y));
          col += uFrame * border * 0.9;
          col *= 0.92 + 0.08 * sin(vUv.y * 300.0 + uTime * 2.0);
          gl_FragColor = vec4(col, a * uOpacity);
        }
      `,
    }),
  );
  screen.renderOrder = 4;
  group.add(screen);
  group.visible = false;

  let key = "";
  function draw(sourceKey: string, painter: (ctx: CanvasRenderingContext2D, w: number, h: number) => void) {
    if (sourceKey === key) return;
    key = sourceKey;
    const ctx = canvas.getContext("2d")!;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    painter(ctx, canvas.width, canvas.height);
    texture.needsUpdate = true;
  }

  function update(time: number, position: THREE.Vector3, opacity: number, camera: THREE.Camera) {
    group.position.copy(position);
    group.lookAt(camera.position);
    group.scale.setScalar(0.85 + 0.15 * opacity);
    uniforms.uTime.value = time;
    uniforms.uOpacity.value = opacity;
    group.visible = opacity > 0.01;
  }

  return { group, draw, update };
}
