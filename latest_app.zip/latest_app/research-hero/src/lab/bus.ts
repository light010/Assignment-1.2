/** Per-frame readout the HUD mirrors straight into the DOM (no React renders). */
export interface LabFrame {
  /** 0..1 share of particles that sit in the tissue. */
  accumulation: number;
  /** 0..1 progress of heat-triggered drug release. */
  released: number;
  /** 0..1 light flash envelope. */
  signal: number;
  /** Timeline seconds. */
  time: number;
}

export interface WaveEvent {
  /** Source position in CSS pixels, relative to the canvas. */
  x: number;
  y: number;
  /** performance.now() when the wavefront leaves the source. */
  startedAt: number;
  /** Wavefront speed in CSS pixels per second. */
  speed: number;
}

export interface Anchor {
  x: number;
  y: number;
  /** false when behind the camera or off-canvas. */
  visible: boolean;
}

type Events = {
  frame: LabFrame;
  ultrasound: { startedAt: number };
  laser: { startedAt: number };
  wave: WaveEvent;
  anchors: Record<string, Anchor>;
  ready: { at: number };
  playing: { playing: boolean };
};

type Handler<T> = (payload: T) => void;

class Bus {
  private handlers = new Map<keyof Events, Set<Handler<never>>>();

  on<K extends keyof Events>(event: K, handler: Handler<Events[K]>) {
    let set = this.handlers.get(event);
    if (!set) {
      set = new Set();
      this.handlers.set(event, set);
    }
    set.add(handler as Handler<never>);
    return () => {
      set.delete(handler as Handler<never>);
    };
  }

  emit<K extends keyof Events>(event: K, payload: Events[K]) {
    const set = this.handlers.get(event);
    if (!set) return;
    for (const handler of set) (handler as Handler<Events[K]>)(payload);
  }
}

export const labBus = new Bus();
