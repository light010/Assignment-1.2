import { computeInstrument } from "./instruments";
import type { WorkerRequest, WorkerResponse } from "./instrument-shared";

/*
  The instrument math, off the main thread. Requests queue up and the newest is answered first: when
  a visitor clicks through several settings, the one on screen is ready soonest, and the ones passed
  over still land in the page's cache for later. The pixels move back without a copy.
*/

const scope = self as unknown as {
  onmessage: ((e: MessageEvent<WorkerRequest>) => void) | null;
  postMessage(message: WorkerResponse, transfer: Transferable[]): void;
};

const queue: WorkerRequest[] = [];
let scheduled = false;

function drain() {
  scheduled = false;
  const next = queue.pop();
  if (!next) return;
  try {
    const { result, transfer } = computeInstrument(next.request);
    scope.postMessage({ id: next.id, result }, transfer);
  } catch (err) {
    scope.postMessage({ id: next.id, error: err instanceof Error ? err.message : String(err) }, []);
  }
  schedule();
}

// A macrotask between jobs lets requests that arrived during the last one join the queue first.
function schedule() {
  if (scheduled || !queue.length) return;
  scheduled = true;
  setTimeout(drain, 0);
}

scope.onmessage = (e) => {
  queue.push(e.data);
  schedule();
};
