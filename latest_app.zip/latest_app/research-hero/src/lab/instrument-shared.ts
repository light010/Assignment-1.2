import type { Beamformer, DesignStep, Lesion, PAMap } from "./state";

/*
  What the page and the instrument worker agree on: image sizes, the channel-data geometry, the
  requests the worker answers, and the pictures it sends back. The math lives in instruments.ts
  (the worker's side); the canvases are drawn in instrument-draw.ts (the page's side). Everything
  here is small, so the page can import it without pulling in the math.
*/

export const IMG_W = 400;
export const IMG_H = 386;

/** Raw channel data: one column per array element, time (depth) down. */
export const CH_W = 64;
export const CH_H = 256;
/** Channel-data geometry: a wide receive aperture and a time window around the lesions. */
export const CH_APERTURE = 1.7;
export const CH_T0 = 0.75;
export const CH_T1 = 3.0;

/** Seeded generator: the same seed always gives the same speckle, clutter and particles. */
export function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** The generator's state only ever steps by a constant, so skipping n draws costs nothing. */
export function mulberry32After(seed: number, draws: number) {
  return mulberry32((seed + Math.imul(draws, 0x6d2b79f5)) | 0);
}

/** Seed of the micrograph for each build step (the film uses it first, then the particles). */
export const MICROGRAPH_SEED: Record<DesignStep, number> = { core: 11, gel: 12, coat: 13 };

export interface Roi {
  x: number;
  y: number;
  r: number;
}

export type InstrumentRequest =
  | { kind: "us"; lesion: Lesion; beamformer: Beamformer }
  | { kind: "pa"; map: PAMap | "both"; melanin: number; beamformer: Beamformer }
  | { kind: "ch"; lesion: Lesion }
  | { kind: "tem"; step: DesignStep };

/** An ultrasound image as shown: grey pixels, the regions gCNR was measured in, and gCNR. */
export interface UsPicture {
  pixels: Uint8ClampedArray<ArrayBuffer>;
  lesionRoi: Roi;
  backgroundRoi: Roi;
  gcnr: number;
  centerX: number;
}

/** A photoacoustic image: the panel's picture (over its ultrasound underlay), the scene's hologram, and what was measured. */
export interface PaPicture {
  pixels: Uint8ClampedArray<ArrayBuffer>;
  /** The overlay with clutter toned down, for the in-scene hologram. */
  holo: Uint8ClampedArray<ArrayBuffer>;
  visibility: number;
  clutter: number;
  /** Share of the light that gets through the skin's melanin (1 for lighter skin), 0..1. */
  light: number;
  centerX: number;
}

/** Per-element echoes (signed, -1..1), and how well neighbours agree at the lesion's depth. */
export interface ChannelPicture {
  data: Float32Array<ArrayBuffer>;
  coherence: Float32Array<ArrayBuffer>;
}

/** The carbon support film behind the particles of an electron micrograph (RGBA). */
export interface MicrographFilm {
  film: Uint8ClampedArray<ArrayBuffer>;
}

export type InstrumentResult<R extends InstrumentRequest> = R extends { kind: "us" }
  ? UsPicture
  : R extends { kind: "pa" }
    ? PaPicture
    : R extends { kind: "ch" }
      ? ChannelPicture
      : MicrographFilm;

export function requestKey(r: InstrumentRequest) {
  switch (r.kind) {
    case "us":
      return `us:${r.lesion}:${r.beamformer}`;
    case "pa":
      return `pa:${r.map}:${r.melanin}:${r.beamformer}`;
    case "ch":
      return `ch:${r.lesion}`;
    case "tem":
      return `tem:${r.step}`;
  }
}

/** Worker protocol: every request carries an id, and its answer (or the error) comes back with it. */
export type WorkerRequest = { id: number; request: InstrumentRequest };
export type WorkerResponse = { id: number; result: InstrumentResult<InstrumentRequest> } | { id: number; error: string };
