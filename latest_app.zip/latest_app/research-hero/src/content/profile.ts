// Everything a visitor reads in the hero outside the lab chapters, so copy edits never touch components.
import { SECTIONS } from "./site.ts";

export const profile = {
  name: "Madhavi Tripathi",
  /** The researcher's own descriptor (from their current site); employers change, this doesn't. */
  role: "Translational scientist",
  /** One sentence per line: what I build, then how I see. */
  headline: ["Nanomaterials for delivery.", "Light and sound for imaging."],
  lede: "I engineer nanoparticles that carry drugs into tumors, and I make photoacoustic and ultrasound images clearer — connecting how we deliver with how we see.",
  nav: SECTIONS.map((s) => ({ label: s.label, href: `#${s.id}` })),
} as const;
