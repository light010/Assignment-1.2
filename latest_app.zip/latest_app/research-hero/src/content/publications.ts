import type { Publication } from "./types";

/*
  The complete, hand-curated record: 15 items (14 with DOIs, plus the thesis record).
  Bibliographic fields were checked against Crossref on 27 September 2026; summaries are the
  owner's own, from their current site. Never import by name: other researchers publish as
  "Madhavi Tripathi", and indexes have already mixed their records with these.
*/

const me = { name: "Madhavi Tripathi", me: true } as const;
const doi = (d: string) => ({ kind: "doi" as const, href: `https://doi.org/${d}`, label: "Paper" });

export const publications: Publication[] = [
  // New records go directly below this line; scripts/add-paper.mts inserts here, newest first.
  {
    id: "enslein-2026-npj-imaging",
    title:
      "In vivo photoacoustic breast imaging and the interactive effects of skin tone, wavelength, beamformer, and depth on target detectability",
    authors: [
      { name: "Jamie Enslein" },
      me,
      { name: "Babita Panigrahi" },
      { name: "Kelly Myers" },
      { name: "Joselyn Wei Chen", family: "Wei Chen" },
      { name: "José Timaná" },
      { name: "Emily Ambinder" },
      { name: "Muyinatu A. Lediju Bell", family: "Lediju Bell" },
    ],
    type: "journal-article",
    venue: "npj Imaging",
    year: 2026,
    doi: "10.1038/s44303-026-00193-4",
    links: [doi("10.1038/s44303-026-00193-4")],
    access: "open-access",
    license: "CC BY 4.0",
    themes: ["imaging"],
    chapters: ["photoacoustic"],
    summary:
      "We imaged breast masses with photoacoustics in patients of many skin tones. Under darker skin, coherence beamforming (SLSC) made deep targets easier to detect; for targets near the skin, delay-and-sum did better.",
    role: {
      credit: ["Patient data acquisition", "Image reconstruction", "Manuscript review"],
      source: "https://doi.org/10.1038/s44303-026-00193-4",
    },
    selected: true,
  },
  {
    id: "arroyo-2026-jbo",
    title: "Pigmentation-dependent skin injury thresholds with nanosecond single-pulse laser exposure",
    authors: [
      { name: "Junior Arroyo" },
      { name: "Jiaxin Zhang" },
      me,
      { name: "Junhao Zhang" },
      { name: "Nethra Venkatayogi" },
      { name: "Jamie Enslein" },
      { name: "Muyinatu A. Lediju Bell", family: "Lediju Bell" },
    ],
    type: "journal-article",
    venue: "Journal of Biomedical Optics",
    details: "31(8), 085001",
    year: 2026,
    doi: "10.1117/1.JBO.31.8.085001",
    links: [
      doi("10.1117/1.JBO.31.8.085001"),
      { kind: "pmc", href: "https://pmc.ncbi.nlm.nih.gov/articles/PMC13452404/", label: "PubMed Central" },
    ],
    access: "open-access",
    license: "CC BY 4.0",
    themes: ["imaging"],
    chapters: ["photoacoustic"],
    summary:
      "We measured the pulsed-laser dose that visibly injures pig skin of different pigmentation. Darker skin was injured at a lower dose than lighter skin, which matters for photoacoustic systems run close to safety limits.",
  },
  {
    id: "enslein-2026-spie",
    title:
      "Comparison of skin tone and target detectability in simulated, tissue-mimicking phantom, and clinical photoacoustic breast images",
    authors: [
      { name: "Jamie Enslein" },
      me,
      { name: "Babita Panigrahi" },
      { name: "Kelly Myers" },
      { name: "Muyinatu A. Lediju Bell", family: "Lediju Bell" },
    ],
    type: "conference-paper",
    venue: "Proceedings of SPIE 13851, Photons Plus Ultrasound: Imaging and Sensing 2026",
    venueShort: "SPIE Photons Plus Ultrasound 2026",
    details: "1385103",
    year: 2026,
    doi: "10.1117/12.3081139",
    links: [
      doi("10.1117/12.3081139"),
      { kind: "pdf", href: "https://pulselab.jhu.edu/wp-content/uploads/2026/03/Enslein_SPIE_2026.pdf", label: "PDF", note: "PULSE Lab" },
    ],
    access: "lab-pdf",
    themes: ["imaging"],
    chapters: ["photoacoustic"],
    summary:
      "We compared target visibility under different skin tones in simulated, phantom, and patient photoacoustic breast images. Under darker skin, coherence beamforming (SLSC) gave deep targets a clearer signal than delay-and-sum.",
  },
  {
    id: "drabek-2026-spie",
    title: "Learning from skinless datasets to improve target detectability in photoacoustic breast imaging across skin tones",
    authors: [
      { name: "Julia Urszula Drabek" },
      me,
      { name: "Jamie Enslein" },
      { name: "Kelly Myers" },
      { name: "Babita Panigrahi" },
      { name: "Muyinatu A. Lediju Bell", family: "Lediju Bell" },
    ],
    type: "conference-paper",
    venue: "Proceedings of SPIE 13851, Photons Plus Ultrasound: Imaging and Sensing 2026",
    venueShort: "SPIE Photons Plus Ultrasound 2026",
    details: "138510N",
    year: 2026,
    doi: "10.1117/12.3083562",
    links: [
      doi("10.1117/12.3083562"),
      { kind: "pdf", href: "https://pulselab.jhu.edu/wp-content/uploads/2026/03/Drabek_SPIE_2026.pdf", label: "PDF", note: "PULSE Lab" },
    ],
    access: "lab-pdf",
    themes: ["imaging"],
    chapters: ["photoacoustic"],
    summary:
      "We trained a generative neural network, on paired simulations with and without skin, to reduce skin clutter in raw photoacoustic data. Targets became easier to detect in simulations, and an early patient test showed it can work.",
  },
  {
    id: "sharma-2025-gcnr-slsc",
    title:
      "Generalized contrast-to-noise ratio applied to short-lag spatial coherence ultrasound differentiates breast cysts from solid masses",
    authors: [
      { name: "Arunima Sharma" },
      { name: "Eniola T. Oluyemi" },
      me,
      { name: "Emily B. Ambinder" },
      { name: "Lisa A. Mullen" },
      { name: "Babita Panigrahi" },
      { name: "Joanna Rossi" },
      { name: "Nethra Venkatayogi" },
      { name: "Kelly S. Myers" },
      { name: "Muyinatu A. Lediju Bell", family: "Lediju Bell" },
    ],
    type: "journal-article",
    venue: "Radiology Advances",
    details: "2(6), umaf037",
    year: 2025,
    doi: "10.1093/radadv/umaf037",
    links: [doi("10.1093/radadv/umaf037")],
    access: "open-access",
    license: "CC BY 4.0",
    themes: ["imaging"],
    chapters: ["ultrasound"],
    summary:
      "We applied an objective contrast measure (gCNR) to coherence-beamformed (SLSC) breast ultrasound. The measure told complicated cysts from solid masses more accurately, and with more radiologist agreement, than reading B-mode images by eye.",
    role: {
      credit: ["Data curation", "Formal analysis", "Investigation", "Software", "Validation", "Writing—review & editing"],
      source: "https://academic.oup.com/radadv/article/2/6/umaf037/8300868",
    },
    selected: true,
    note: "The interactive lab uses this study’s 0.76 threshold.",
  },
  {
    id: "tripathi-2025-mucin",
    title: "Mucin-capped CuS nanoparticles for mitochondrial targeted NIR-II photothermal therapy and photoacoustic imaging",
    authors: [me, { name: "Ananya Sharma" }, { name: "Victor A. Ajisafe" }, { name: "Sanhita Sinharay" }, { name: "Ashok M. Raichur" }],
    type: "journal-article",
    venue: "Journal of Drug Delivery Science and Technology",
    details: "105, 106668",
    year: 2025,
    doi: "10.1016/j.jddst.2025.106668",
    links: [
      doi("10.1016/j.jddst.2025.106668"),
      { kind: "preprint", href: "https://doi.org/10.2139/ssrn.4972313", label: "Preprint", note: "SSRN, 2024" },
    ],
    access: "subscription",
    themes: ["delivery"],
    chapters: ["design", "deliver", "photoacoustic"],
    summary:
      "We capped ultrasmall light-absorbing particles with a natural biomolecule and tagged them for mitochondria. With light they killed cancer cells and gave photoacoustic contrast, and they penetrated 3D tumor models.",
    selected: true,
  },
  {
    id: "tripathi-2024-nanoflakes",
    title:
      "Effect of PVP molecular weights on the synthesis of ultrasmall CuS nanoflakes: synthesis, properties, and potential application for phototheranostics",
    authors: [me, { name: "Ananya Sharma" }, { name: "Sanhita Sinharay" }, { name: "Ashok M. Raichur" }],
    type: "journal-article",
    venue: "ACS Applied Bio Materials",
    details: "7(3), 1671–1681",
    year: 2024,
    doi: "10.1021/acsabm.3c01123",
    links: [doi("10.1021/acsabm.3c01123")],
    access: "subscription",
    themes: ["delivery"],
    chapters: ["design"],
    summary:
      "We tested how the length of the capping polymer changes ultrasmall light-absorbing particles. All stayed ultrasmall, crystalline, and gentle on cells, and heated under light; the shortest polymer gave the strongest photoacoustic signal.",
    selected: true,
  },
  {
    id: "tripathi-phd-thesis",
    title:
      "Thermoresponsive CuS based nanocomposites mimicking red blood cells for combinatorial therapy and photoacoustic imaging",
    authors: [me],
    type: "thesis",
    venue: "PhD thesis, Indian Institute of Science, Bengaluru",
    venueShort: "PhD thesis, Indian Institute of Science",
    year: 2024,
    links: [
      { kind: "record", href: "https://etd.iisc.ac.in/handle/2005/6575", label: "Thesis record", note: "IISc network only" },
    ],
    access: "restricted",
    themes: ["delivery"],
    chapters: ["design", "deliver", "photoacoustic"],
    summary:
      "I built heat-responsive gel carriers that hold light-absorbing cores and mimic red blood cells, to combine drug delivery, heating tumors with light, and photoacoustic imaging.",
  },
  {
    id: "tripathi-2023-nanohybrids",
    title: "Seed-mediated galvanic synthesis of CuS–Au nanohybrids for photo-theranostic applications",
    authors: [me, { name: "Swathi Padmanabhan" }, { name: "Jaya Prakash" }, { name: "Ashok M. Raichur" }],
    type: "journal-article",
    venue: "ACS Applied Nano Materials",
    details: "6(16), 14861–14875",
    year: 2023,
    doi: "10.1021/acsanm.3c02405",
    links: [doi("10.1021/acsanm.3c02405")],
    access: "subscription",
    themes: ["delivery"],
    chapters: ["design", "deliver", "photoacoustic"],
    summary:
      "We grew metal from seeds bound to ultrasmall light-absorbing particles, keeping the hybrids ultrasmall. They heated under light, gave a photoacoustic signal through tissue, and were more toxic to lung cancer cells than either part alone.",
    selected: true,
  },
  {
    id: "tripathi-2023-hydrogels",
    title: "Thermoresponsive nanocomposite hydrogels: tunable systems for localized cancer theranostics",
    authors: [me, { name: "Zahra Mafibaniasadi" }, { name: "Ashok M. Raichur" }],
    type: "book-chapter",
    venue: "Functional Nanocomposite Hydrogels (Elsevier)",
    details: "pp. 453–477",
    year: 2023,
    doi: "10.1016/B978-0-323-99638-9.00019-8",
    links: [doi("10.1016/B978-0-323-99638-9.00019-8")],
    access: "subscription",
    themes: ["delivery"],
    chapters: ["design", "deliver"],
    summary:
      "We reviewed temperature-responsive gels that hold nanoparticles, and how they can be tuned to treat and image tumors locally.",
  },
  {
    id: "wazalwar-2022-mxene-epoxy",
    title:
      "Curing behavior and mechanical properties of tetra-functional epoxy reinforced with polyethyleneimine-functionalized MXene",
    authors: [{ name: "Radhika Wazalwar" }, me, { name: "Ashok M. Raichur" }],
    type: "journal-article",
    venue: "ACS Applied Polymer Materials",
    details: "4(4), 2573–2584",
    year: 2022,
    doi: "10.1021/acsapm.1c01876",
    links: [doi("10.1021/acsapm.1c01876")],
    access: "subscription",
    themes: [],
    chapters: [],
    summary:
      "We added surface-treated two-dimensional nanosheets to an aerospace-grade resin. A small amount helped it cure and made it stronger and tougher; with more, the sheets clumped and the gains fell. Untreated sheets did little.",
  },
  {
    id: "jain-2021-biopolymer",
    title: "Biopolymer matrix composite for drug delivery applications in cancer",
    authors: [{ name: "Ankit Jain" }, me, { name: "Shiv K. Prajapati" }, { name: "Ashok M. Raichur" }],
    type: "book-chapter",
    venue: "Encyclopedia of Materials: Composites (Elsevier)",
    details: "pp. 804–817",
    year: 2021,
    doi: "10.1016/B978-0-12-819724-0.00028-8",
    links: [doi("10.1016/B978-0-12-819724-0.00028-8")],
    access: "subscription",
    themes: ["delivery"],
    chapters: ["deliver"],
    summary:
      "We reviewed how natural and synthetic biopolymer composites can carry cancer drugs: their properties, targeting, stimulus-triggered release, preparation, and uses in treatment and diagnosis.",
  },
  {
    id: "jain-2021-hydroxychloroquine",
    title:
      "Exploring the room for repurposed hydroxychloroquine to impede COVID-19: toxicities and multipronged combination approaches with pharmaceutical insights",
    authors: [
      { name: "Ankit Jain" },
      { name: "Shiv Kumar Prajapati" },
      me,
      { name: "Ashok M. Raichur" },
      { name: "Jagat R. Kanwar" },
    ],
    type: "review",
    venue: "Expert Review of Clinical Pharmacology",
    details: "14(6), 715–734",
    year: 2021,
    doi: "10.1080/17512433.2021.1909473",
    links: [doi("10.1080/17512433.2021.1909473")],
    access: "subscription",
    themes: [],
    chapters: [],
    summary:
      "We reviewed the toxicity of a repurposed antimalarial drug proposed for COVID-19, along with new delivery approaches, computer modeling, and drug combinations that might make it safer and more effective.",
  },
  {
    id: "tripathi-2015-malaria",
    title: "Genotyping malaria parasites with DNA barcodes",
    authors: [me, { name: "Aparup Das" }],
    type: "journal-article",
    venue: "Tropical Medicine & International Health",
    details: "20(12), 1636–1638",
    year: 2015,
    doi: "10.1111/tmi.12594",
    links: [doi("10.1111/tmi.12594")],
    access: "free-to-read",
    themes: [],
    chapters: [],
    summary:
      "We discussed genotyping malaria parasites with DNA barcodes (panels of genetic markers). We argued that current panels leave out parasites from India and other regions, so they can’t yet reliably tell parasite strains apart worldwide.",
  },
  {
    id: "tripathi-2015-stem-cells",
    title: "Stem cell technologies in human health: boon or bane?",
    authors: [me, { name: "Sangeeta Singh" }],
    type: "review",
    venue: "Journal of Biosciences and Medicines",
    details: "3(11), 16–24",
    year: 2015,
    doi: "10.4236/jbm.2015.311002",
    links: [doi("10.4236/jbm.2015.311002")],
    access: "open-access",
    license: "CC BY 4.0",
    themes: [],
    chapters: [],
    summary:
      "We reviewed stem cell technologies, from embryonic and induced pluripotent stem cells to cord blood banking, weighing their promise for human health against ethical questions and the need for closer evaluation.",
  },
];

export const byId = new Map(publications.map((p) => [p.id, p]));

export const isFirstAuthor = (p: Publication) => p.authors[0]?.me === true;
