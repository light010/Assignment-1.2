import { OWN_SITE } from "./person.ts";
import type { Recognition, Update } from "./types";

/* Recognition, service, and recent updates, from the owner's current site. */

export const recognition: Recognition[] = [
  {
    id: "iisc-best-thesis-2025",
    when: "2025",
    title: { value: "Best Thesis Award and Gold Medal", source: OWN_SITE, confirmed: true },
    context: "Indian Institute of Science, for doctoral research on nanoparticles designed to treat and image cancer",
    kind: "award",
    // The Design chapter's particle is modeled on the thesis platform. Once the owner confirms its red blood cell
    // membrane coat, the caption can read "The particle this thesis built, taken apart".
    still: { render: "design", caption: "A particle built in layers, as in this thesis" },
  },
  {
    id: "wimin-committee",
    when: "2024–present",
    title: { value: "Leadership committee, Women in Molecular Imaging Network", source: OWN_SITE, confirmed: true },
    kind: "service",
  },
  {
    id: "iisc-symposium-2023",
    when: "2023",
    title: { value: "Convener, 36th Annual Symposium of Materials Engineering", source: OWN_SITE, confirmed: true },
    context: "Indian Institute of Science",
    kind: "service",
  },
];

export const updates: Update[] = [
  {
    id: "2026-09-npj-imaging",
    date: "2026-09-04",
    kind: "Paper",
    title: "A closer look at photoacoustic breast imaging",
    text: "Our paper in npj Imaging examines how skin tone and imaging choices interact.",
    link: { label: "Read the paper", href: "https://doi.org/10.1038/s44303-026-00193-4" },
    confirmed: true,
  },
  {
    id: "2023-09-iisc-feature",
    date: "2023-09-11",
    kind: "Feature",
    title: "Hybrid nanoparticles in the spotlight",
    text: "The Indian Institute of Science featured our ultrasmall hybrid nanoparticles, which turn light into heat and sound.",
    link: {
      label: "Read the feature",
      href: "https://www.iisc.ac.in/events/hybrid-nanoparticles-shine-new-light-on-targeting-cancer-cells/",
    },
    confirmed: true,
  },
];
