import { OWN_SITE } from "./person.ts";
import type { ResearchDirection, ResearchTheme } from "./types";

/*
  The two halves of the work, titled with the headline's two lines: they name the publication groups and the
  Show filter. Research presents the same work as three directions (below).
*/

export const RESEARCH_DECK =
  "Two halves of one practice: building particles that carry treatment, and imaging what’s inside with light and sound, or sound alone.";

export const themes: ResearchTheme[] = [
  { id: "delivery", title: "Nanomaterials for delivery" },
  { id: "imaging", title: "Light and sound for imaging" },
];

/*
  Research, as three directions in the lab's own order: the particles, then photoacoustics (the bridge, where
  absorbed pulsed light turns into sound), then ultrasound. The sentences reuse the reviewed wording above and
  the owner's own questions and skill words from their current site.
*/
export const directions: ResearchDirection[] = [
  {
    id: "delivery",
    theme: "delivery",
    title: "Nanomaterials for delivery",
    where: { value: "PhD research, Indian Institute of Science", source: OWN_SITE, confirmed: true },
    question: "How can a carrier respond when it matters?",
    body: "I design nanoparticles in layers, each with one job: light-absorbing cores turn light into heat and sound, a heat-responsive gel holds a drug until it’s heated, and a red blood cell membrane coat helps the particle circulate longer.",
    skills: [
      "Ultrasmall light-absorbing nanoparticles",
      "Capping layers for stability and targeting",
      "3D tumor models and preclinical testing",
    ],
    chapters: ["design", "deliver"],
  },
  {
    id: "photoacoustic",
    theme: "imaging",
    title: "Photoacoustic imaging",
    where: { value: "Indian Institute of Science and Johns Hopkins University", source: OWN_SITE, confirmed: true },
    question: "How can light and sound reveal more?",
    body: "Pulsed light absorbed in tissue, or by my particles, turns into sound we can image. At Johns Hopkins, we studied how skin tone changes what photoacoustic imaging can detect, and how much pulsed light it takes to injure pig skin of different tones.",
    skills: [
      "Nanoparticles as photoacoustic contrast agents",
      "Sound-speed selection in image reconstruction",
      "Oxygenation mapping and target detectability",
      "Simulation, phantom, and clinical studies",
    ],
    chapters: ["photoacoustic"],
  },
  {
    id: "ultrasound",
    theme: "imaging",
    title: "Ultrasound imaging",
    where: { value: "Postdoctoral research, Johns Hopkins University", source: OWN_SITE, confirmed: true },
    question: "What can the echoes tell us more clearly?",
    body: "In Muyinatu Bell’s PULSE Lab, we measured contrast objectively (gCNR) on coherence-beamformed ultrasound to tell breast cysts from solid masses, which B-mode images can confuse.",
    skills: [
      "Delay-and-sum and coherence (SLSC) beamforming",
      "Objective image-quality measures such as gCNR",
      "Raw channel data analysis",
    ],
    chapters: ["ultrasound"],
  },
];

