import type { Person, Source } from "./types";

/*
  Facts about the owner. The primary source is the owner's own current site, whose role and
  education details come from their 2026 résumé (see the old site's docs/CONTENT-SOURCES.md).
  Where ORCID disagrees, the résumé wins and the difference is noted beside the fact.
*/

export const OWN_SITE: Source = {
  label: "The owner's current site, from their 2026 résumé",
  checked: "2026-09-27",
};

const SCHOLAR = "https://scholar.google.com/citations?user=zZx1Td0AAAAJ&hl=en";

export const person: Person = {
  name: "Madhavi Tripathi",
  role: { value: "Translational scientist", source: OWN_SITE, confirmed: true },
  now: {
    value: { title: "Lead Scientist", org: "SynapSeek", place: "remote", since: "2026-02" },
    source: OWN_SITE,
    confirmed: true,
  },
  bio: {
    value:
      "I am a translational scientist working across biomaterials, drug delivery, and photoacoustic and ultrasound imaging. I earned my PhD in Materials Engineering at the Indian Institute of Science and completed postdoctoral training in the PULSE Lab at Johns Hopkins University.\n\nMy work connects material synthesis and biological evaluation with image reconstruction, quantitative analysis, and clinical imaging studies. I now lead scientific and AI/ML strategy at SynapSeek, developing reproducible workflows for a neurodiagnostic mapping platform. Alongside research, I mentor junior scientists and serve on the Women in Molecular Imaging Network leadership committee.",
    source: OWN_SITE,
    confirmed: true,
  },
  shortBio: {
    value:
      "Madhavi Tripathi is a translational scientist working across biomaterials, drug delivery, and photoacoustic and ultrasound imaging. Trained at the Indian Institute of Science (PhD, Materials Engineering) and in the PULSE Lab at Johns Hopkins University (postdoctoral fellowship), Tripathi now leads scientific and AI/ML strategy at SynapSeek.",
    source: OWN_SITE,
    confirmed: true,
  },
  email: { value: "madhavi.tri16@gmail.com", source: OWN_SITE, confirmed: true },
  links: {
    scholar: SCHOLAR,
    orcid: { value: "0000-0002-4736-9134", source: OWN_SITE, confirmed: true },
    linkedin: { value: "https://www.linkedin.com/in/mtri16", source: OWN_SITE, confirmed: true },
  },
  positions: [
    {
      title: { value: "Lead Scientist", source: OWN_SITE, confirmed: true },
      org: "SynapSeek",
      place: "remote",
      start: { value: "2026-02", source: OWN_SITE, confirmed: true },
      description:
        "Leading scientific and AI/ML strategy, data pipelines, model evaluation, and validation for a neurodiagnostic mapping platform.",
    },
    {
      title: { value: "Postdoctoral Research Fellow", source: OWN_SITE, confirmed: true },
      org: "Johns Hopkins University",
      unit: "PULSE Lab",
      // ORCID and the lab's welcome post give February 2025; the résumé gives December 2024.
      start: { value: "2024-12", source: OWN_SITE, confirmed: true },
      end: { value: "2026-01", source: OWN_SITE, confirmed: true },
      description:
        "Ultrasound and photoacoustic image reconstruction, quantitative analysis, and breast-imaging studies with Prof. Muyinatu A. Lediju Bell.",
      link: { label: "PULSE Lab people page", href: "https://pulselab.jhu.edu/people/" },
    },
  ],
  education: [
    {
      degree: { value: "PhD in Materials Engineering", source: OWN_SITE, confirmed: true },
      org: "Indian Institute of Science",
      place: "Bengaluru",
      // Thesis defended 13 December 2024 (the date ORCID shows); degree dated March 2025 on the résumé.
      end: { value: "2025-03", source: OWN_SITE, confirmed: true },
      description:
        "Doctoral research on nanoparticles for photoacoustic imaging and image-guided therapy, advised by Prof. Ashok M. Raichur.",
      link: { label: "Thesis record (IISc network only)", href: "https://etd.iisc.ac.in/handle/2005/6575" },
    },
    {
      degree: { value: "Integrated M.Tech. in Biomedical Engineering", source: OWN_SITE, confirmed: true },
      org: "Indian Institute of Information Technology",
      place: "Allahabad",
      end: { value: "2018-07", source: OWN_SITE, confirmed: true },
      description: "A five-year foundation in biomedical engineering, bringing together engineering methods and biological questions.",
    },
  ],
};
