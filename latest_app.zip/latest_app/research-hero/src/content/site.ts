/*
  Site-wide settings. SITE_URL is the production address; set NEXT_PUBLIC_SITE_URL when the
  domain is chosen. Canonical links, the sitemap, share images, and structured data all use it.
*/

export const SITE_URL = (process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3217").replace(/\/$/, "");

/** The content date shown in the footer and on the publication list. */
export const UPDATED = { iso: "2026-09-27", label: "September 2026" } as const;

/** Same labels and order everywhere: header, phone row, and the section bar. */
export const SECTIONS = [
  { id: "research", label: "Research" },
  { id: "publications", label: "Publications" },
  { id: "about", label: "About" },
  { id: "contact", label: "Contact" },
] as const;

/** One sentence under a section heading, at most 140 characters (design-system/MASTER.md). */
export const DECKS = {
  publications: "Papers, book chapters, and my thesis, each with a sentence on what the work found.",
  contact: "Email is the best way to reach me about a collaboration or any of the papers above.",
} as const;

/** The footer's statement about the lab's pictures. */
export const SIMULATION_NOTE = "The lab images are simulations for explanation, not measurements.";

export const DESCRIPTION =
  "Madhavi Tripathi builds nanoparticles for drug delivery and works on photoacoustic and ultrasound imaging. Research, publications, and contact.";
