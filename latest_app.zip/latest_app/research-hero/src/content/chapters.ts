import type { LabState, SkillChapter } from "@/lab/state";

/*
  Everything the lab says, per chapter and per control value. Voice rules, the glossary and
  length budgets live in design-system/MASTER.md: plain words first, then the term; one name
  per thing; American spelling; captions describe what is on screen, why, and what it measures.
*/

export interface ControlDef {
  /** Key inside the chapter’s state slice. */
  key: string;
  label: string;
  options: ReadonlyArray<{ value: string; label: string }>;
}

export interface ChapterDef {
  label: string;
  /** What the chapter shows, in the visitor’s words (20 characters at most). */
  hint: string;
  controls: ReadonlyArray<ControlDef>;
}

export const CHAPTER_ORDER: SkillChapter[] = ["design", "deliver", "photoacoustic", "ultrasound"];

const BEAMFORMER: ControlDef = {
  key: "beamformer",
  label: "Beamformer",
  options: [
    { value: "standard", label: "Delay-and-sum" },
    { value: "coherence", label: "Coherence" },
  ],
};

export const CHAPTERS: Record<SkillChapter, ChapterDef> = {
  design: {
    label: "Design",
    hint: "Building in layers",
    controls: [
      {
        key: "step",
        label: "Build",
        options: [
          { value: "core", label: "Core" },
          { value: "gel", label: "Gel and drug" },
          { value: "coat", label: "Membrane coat" },
        ],
      },
      {
        key: "view",
        label: "View",
        options: [
          { value: "cut", label: "Cut open" },
          { value: "exploded", label: "Taken apart" },
        ],
      },
    ],
  },
  deliver: {
    label: "Delivery",
    hint: "Reaching the tumor",
    controls: [
      {
        key: "particle",
        label: "Particle",
        options: [
          { value: "large", label: "Large" },
          { value: "ultrasmall", label: "Ultrasmall" },
          { value: "gel", label: "Gel carrier" },
        ],
      },
      {
        key: "elapsed",
        label: "After",
        options: [
          { value: "minutes", label: "Minutes" },
          { value: "hours", label: "Hours" },
          { value: "day", label: "A day" },
        ],
      },
      {
        key: "light",
        label: "Light",
        options: [
          { value: "off", label: "Off" },
          { value: "pulsed", label: "Pulsed" },
          { value: "continuous", label: "Continuous" },
        ],
      },
    ],
  },
  photoacoustic: {
    label: "Photoacoustics",
    hint: "Listening to light",
    controls: [
      {
        key: "map",
        label: "Show",
        options: [
          { value: "oxygenation", label: "Blood oxygen" },
          { value: "particles", label: "Nanoparticles" },
        ],
      },
      {
        key: "skin",
        label: "Skin tone",
        options: [
          { value: "lighter", label: "Lighter" },
          { value: "medium", label: "Medium" },
          { value: "darker", label: "Darker" },
        ],
      },
      BEAMFORMER,
    ],
  },
  ultrasound: {
    label: "Ultrasound",
    hint: "Listening to echoes",
    controls: [
      {
        key: "lesion",
        label: "Lesion",
        options: [
          { value: "cyst", label: "Cyst" },
          { value: "solid", label: "Solid mass" },
        ],
      },
      BEAMFORMER,
      {
        key: "view",
        label: "View",
        options: [
          { value: "image", label: "Image" },
          { value: "echoes", label: "Raw echoes" },
        ],
      },
    ],
  },
};

/** Numbers the instruments measure from the images they render. */
export interface Metrics {
  /** Generalized contrast-to-noise ratio of the lesion vs. background, 0..1. */
  gcnr?: number;
  /** Photoacoustic target visibility, 0..1. */
  visibility?: number;
  /** Photoacoustic skin clutter, 0..1. */
  clutter?: number;
  /** Light reaching the photoacoustic target, relative to lighter skin, 0..1. */
  light?: number;
}

export const GCNR_THRESHOLD = 0.76;

/** Word joiners keep hyphenated terms from breaking across lines ("B-" / "mode"). */
const B_MODE = "B-⁠mode";
const DAS = "delay-⁠and-⁠sum";

export function caption(s: LabState, m: Metrics = {}): string {
  switch (s.chapter) {
    case "overview":
      return "Tissue with a tumor, my nanoparticles in the bloodstream, and a probe that images with light and sound. Pick a skill to look closer.";
    case "design": {
      if (s.design.view === "exploded")
        return "Taken apart, the particle shows each layer’s job: the cores absorb light, the gel holds and releases the drug, and the coat keeps it circulating longer.";
      if (s.design.step === "core")
        return "Each particle starts with ultrasmall crystal cores that turn light into heat and sound. A soft capping layer keeps them small, stable, and gentle on cells.";
      if (s.design.step === "gel")
        return "Many cores go into a soft, heat-responsive gel along with the drug. Heated, the gel shrinks and squeezes the drug out.";
      return "A coat of red blood cell membrane makes the particle look like one of the body’s own cells to the immune system, so it circulates long enough to reach the tumor.";
    }
    case "deliver": {
      const { particle, elapsed, light } = s.deliver;
      const heated = light === "continuous";
      if (particle === "gel" && heated && elapsed === "minutes")
        return "Minutes after injection, most gel carriers are still in the bloodstream, so heating now would release the drug before it reaches the tumor.";
      const base =
        particle === "large"
          ? "Large particles stall at the tumor’s rim: they stay, but barely reach the center."
          : particle === "ultrasmall"
            ? elapsed === "day"
              ? "Ultrasmall particles reach deep, but without a carrier most wash out within a day."
              : "Ultrasmall particles slip deep into the tumor, but without a carrier they soon leave."
            : heated
              ? "The gel carrier waits at the rim like a large particle."
              : "Like a large particle, the gel carrier stays at the rim, holding its cores and drug.";
      const lit =
        light === "pulsed"
          ? " Short light pulses make the particles emit sound, so they show up in a photoacoustic image."
          : heated
            ? particle === "gel"
              ? " Continuous light heats its cores: the gel shrinks, the freed drug spreads deep, and heat damages tumor cells."
              : " Continuous light heats the particles and nearby tissue, but there’s no drug to release."
            : elapsed === "minutes"
              ? " Minutes after injection, most particles are still in the bloodstream."
              : "";
      return base + lit;
    }
    case "photoacoustic": {
      const { map, skin, beamformer } = s.photoacoustic;
      const coherent = beamformer === "coherence";
      const oxygen = map === "oxygenation";
      const first = oxygen
        ? "Oxygen shifts which colors blood absorbs, so imaging with a few colors maps blood oxygen."
        : "The nanoparticles absorb far more light than tissue, so they stand out where they gathered.";
      const second =
        skin === "lighter"
          ? coherent
            ? oxygen
              ? " Lighter skin adds little clutter, but coherence still brings out faint vessels."
              : " Lighter skin adds little clutter, but coherence still brings out faint targets."
            : " Lighter skin absorbs little light at the surface, leaving more for deep targets."
          : coherent
            ? oxygen
              ? ` Coherence cuts most skin clutter, but oxygen still comes from the ${DAS} signal.`
              : " Coherence keeps faint signals that agree and cuts most clutter; lost light stays lost."
            : skin === "darker"
              ? " Melanin in darker skin absorbs light at the surface, and clutter buries deep targets."
              : " Some light is lost in the skin, and clutter below it starts to hide deep targets.";
      return first + second;
    }
    case "ultrasound": {
      const { lesion, beamformer, view } = s.ultrasound;
      const coherent = beamformer === "coherence";
      // The 0.76 cutoff was set for gCNR on coherence (SLSC) images, so only they get a verdict.
      const measured =
        m.gcnr === undefined
          ? ""
          : coherent
            ? ` gCNR ${m.gcnr.toFixed(2)}: reads as ${m.gcnr >= GCNR_THRESHOLD ? "a cyst" : "a solid mass"}.`
            : ` gCNR ${m.gcnr.toFixed(2)}.`;
      if (view === "echoes")
        return (
          (coherent
            ? "Short-lag spatial coherence (SLSC) measures how well echoes at neighboring elements agree: tissue echoes do; clutter and noise in fluid don’t."
            : `Each element of the array records its own echo. Delay-⁠and-⁠sum lines them up along this curve and adds them to form the ${B_MODE} image.`) +
          measured
        );
      if (lesion === "cyst")
        return (
          (coherent
            ? "Coherence beamforming (SLSC) asks whether echoes agree between neighboring array elements. Fluid returns nothing coherent, so the cyst goes dark."
            : `A cyst is fluid and should look black, but in the standard ${B_MODE} image, clutter fills it with haze, so it can pass for a solid mass.`) +
          measured
        );
      return (
        (coherent
          ? "Tissue inside a solid mass still echoes coherently, so in the coherence image it blends in with its surroundings."
          : `Many solid masses also look dark in ${B_MODE}, which is why cysts and solid masses get confused.`) + measured
      );
    }
  }
}

export interface Readout {
  label: string;
  value: string;
  /** Optional 0..1 meter drawn under the value, with an optional threshold tick. */
  meter?: number;
  threshold?: number;
  tone?: "good" | "warn";
}

export function readouts(s: LabState, m: Metrics = {}): Readout[] {
  switch (s.chapter) {
    case "overview":
      return [];
    case "design":
      if (s.design.view === "exploded")
        return [
          { label: "Layers", value: "Core, gel, coat" },
          { label: "Carries", value: "Drug and cores" },
          { label: "Releases when", value: "Heated" },
        ];
      // Built in order, and each layer has one job (the same jobs the taken-apart view names).
      if (s.design.step === "core")
        return [
          { label: "Step", value: "1 of 3" },
          { label: "Job", value: "Absorb light" },
          { label: "Turns light into", value: "Heat and sound" },
        ];
      if (s.design.step === "gel")
        return [
          { label: "Step", value: "2 of 3" },
          { label: "Job", value: "Hold the drug" },
          { label: "Releases when", value: "Heated" },
        ];
      return [
        { label: "Step", value: "3 of 3" },
        { label: "Job", value: "Circulate longer" },
        { label: "Immune cells see", value: "A red blood cell" },
      ];
    case "deliver": {
      const { particle, elapsed, light } = s.deliver;
      const early = elapsed === "minutes";
      const heated = light === "continuous";
      const released = particle === "gel" && heated && !early;
      // Tones follow the delivery goal: reaching deep and staying there are good.
      const reach: Readout = early
        ? { label: "Reach", value: "Not there yet" }
        : particle === "large"
          ? { label: "Reach", value: "Rim only", tone: "warn" }
          : particle === "ultrasmall"
            ? { label: "Reach", value: "Deep", tone: "good" }
            : released
              ? { label: "Reach", value: "Drug goes deep", tone: "good" }
              : { label: "Reach", value: "Rim, for now" };
      const retention: Readout = early
        ? { label: "Retention", value: "Too soon to tell" }
        : particle === "ultrasmall"
          ? { label: "Retention", value: elapsed === "day" ? "Washed out" : "Low", tone: "warn" }
          : { label: "Retention", value: "High", tone: "good" };
      const effect: Readout =
        light === "off"
          ? { label: "Light’s effect", value: "None yet" }
          : light === "pulsed"
            ? { label: "Light’s effect", value: "Imaging signal" }
            : particle !== "gel"
              ? { label: "Light’s effect", value: "Heat only" }
              : early
                ? { label: "Light’s effect", value: "Early release", tone: "warn" }
                : { label: "Light’s effect", value: "Heat, drug release" };
      return [reach, retention, effect];
    }
    case "photoacoustic": {
      // Tones follow the word shown, so the same level never changes color between maps.
      const light = level(m.light, 0.2);
      const clutter = level(m.clutter);
      const visibility = level(m.visibility);
      return [
        { label: "Light through skin", value: light, meter: m.light, tone: light === "Low" ? "warn" : undefined },
        { label: "Skin clutter", value: clutter, meter: m.clutter, tone: clutter === "Medium" || clutter === "High" ? "warn" : undefined },
        {
          label: "Target visibility",
          value: visibility,
          meter: m.visibility,
          tone: visibility === "High" ? "good" : visibility === "Low" ? "warn" : undefined,
        },
      ];
    }
    case "ultrasound": {
      const g = m.gcnr ?? 0;
      const coherent = s.ultrasound.beamformer === "coherence";
      const readsCyst = g >= GCNR_THRESHOLD;
      const correct = readsCyst === (s.ultrasound.lesion === "cyst");
      return [
        {
          label: "Contrast (gCNR)",
          value: m.gcnr === undefined ? "…" : g.toFixed(2),
          meter: g,
          // The cutoff belongs to coherence images; B-mode was read by eye in the study.
          threshold: coherent ? GCNR_THRESHOLD : undefined,
        },
        coherent
          ? { label: "Reads as", value: readsCyst ? "Cyst" : "Solid mass", tone: correct ? "good" : "warn" }
          : { label: "Reads as", value: "Cyst or solid?", tone: "warn" },
        { label: "Truth", value: s.ultrasound.lesion === "cyst" ? "Cyst" : "Solid mass" },
      ];
    }
  }
}

function level(v: number | undefined, low = 0.33) {
  return v === undefined ? "…" : v > 0.66 ? "High" : v > low ? "Medium" : "Low";
}

export interface CalloutDef {
  anchor: string;
  text: string;
  side: "left" | "right";
}

export function callouts(s: LabState): CalloutDef[] {
  switch (s.chapter) {
    case "overview":
      return [
        { anchor: "loupe", text: "A nanoparticle, cut open", side: "left" },
        { anchor: "tumor", text: "Tumor", side: "left" },
        { anchor: "probe", text: "Light and sound probe", side: "left" },
      ];
    case "design":
      if (s.design.view === "exploded")
        return [
          { anchor: "xCore", text: "Light-absorbing cores", side: "left" },
          { anchor: "xGel", text: "Gel and drug", side: "left" },
          { anchor: "xCoat", text: "Membrane coat", side: "right" },
        ];
      if (s.design.step === "core")
        return [
          { anchor: "core", text: "Light-absorbing core", side: "left" },
          { anchor: "capping", text: "Capping layer", side: "right" },
        ];
      if (s.design.step === "gel")
        return [
          { anchor: "gel", text: "Heat-responsive gel", side: "right" },
          { anchor: "drug", text: "Drug molecules", side: "left" },
          { anchor: "core", text: "Light-absorbing cores", side: "left" },
        ];
      return [
        { anchor: "coat", text: "Membrane coat", side: "left" },
        { anchor: "protein", text: "Membrane proteins", side: "right" },
      ];
    case "deliver":
      return [
        { anchor: "leak", text: "Leaky tumor vessel", side: "right" },
        { anchor: "rim", text: "Tumor rim", side: "left" },
        { anchor: "tumorCore", text: "Tumor center", side: "right" },
      ];
    case "photoacoustic":
      return s.photoacoustic.map === "oxygenation"
        ? [
            { anchor: "artery", text: "Artery, oxygenated", side: "left" },
            { anchor: "vein", text: "Vein, deoxygenated", side: "left" },
            { anchor: "skin", text: "Skin", side: "right" },
            { anchor: "tumor", text: "Tumor", side: "right" },
          ]
        : [
            { anchor: "tumor", text: "Nanoparticles in tumor", side: "left" },
            { anchor: "skin", text: "Skin", side: "right" },
            { anchor: "artery", text: "Artery", side: "left" },
          ];
    case "ultrasound":
      if (s.ultrasound.view === "echoes")
        return [
          { anchor: "array", text: "Array elements", side: "left" },
          { anchor: "screen", text: "Echo at each element", side: "right" },
        ];
      return [
        { anchor: "lesion", text: s.ultrasound.lesion === "cyst" ? "Fluid-filled cyst" : "Solid mass", side: "left" },
        { anchor: "array", text: "Transducer array", side: "left" },
      ];
  }
}

export interface PanelInfo {
  title: string;
  legend: ReadonlyArray<{ label: string; swatch: string }>;
}

const OXYGEN_LEGEND = [
  { label: "Oxygenated", swatch: "bg-[#4fdc8a]" },
  { label: "Deoxygenated", swatch: "bg-[#ff4a4a]" },
];
const PARTICLE_LEGEND = { label: "Nanoparticles", swatch: "bg-gradient-to-r from-[#8a1a06] via-pulse to-[#fff3c4]" };

export function panelInfo(s: LabState): PanelInfo {
  switch (s.chapter) {
    case "design":
      return { title: "Electron micrograph", legend: [] };
    case "deliver":
      return {
        title: "Where the particles end up",
        legend: [
          { label: "Large", swatch: "bg-[#b9c2c8]" },
          { label: "Ultrasmall", swatch: "bg-pulse" },
          { label: "Gel carrier", swatch: "bg-[#6aa8ff]" },
        ],
      };
    case "photoacoustic":
      return {
        title: "Photoacoustic image",
        legend: s.photoacoustic.map === "oxygenation" ? OXYGEN_LEGEND : [PARTICLE_LEGEND],
      };
    case "ultrasound":
      if (s.ultrasound.view === "echoes")
        return {
          title: "Raw echoes",
          legend:
            s.ultrasound.beamformer === "coherence"
              ? [{ label: "Agreement with neighbors", swatch: "bg-echo" }]
              : [{ label: "Delay curve", swatch: "bg-pulse" }],
        };
      return {
        title: s.ultrasound.beamformer === "coherence" ? "Coherence image" : "B-mode image",
        legend: [
          { label: "Lesion", swatch: "border border-dashed border-echo bg-transparent" },
          { label: "Background", swatch: "border border-dashed border-bone/70 bg-transparent" },
        ],
      };
    default:
      return { title: "Photoacoustic image", legend: [...OXYGEN_LEGEND, PARTICLE_LEGEND] };
  }
}

export interface Evidence {
  label: string;
  href: string;
  /** Leaves the site ("Read …") rather than moving within it ("See …"). */
  external: boolean;
}

/**
 * The paper behind what the lab is showing, labeled by what that paper covers. The skin-tone study is
 * named as such, so it never reads as a paper about oxygen mapping.
 */
export function evidence(s: LabState): Evidence | null {
  const papers = { label: "See the papers behind this", href: "/?show=delivery#publications", external: false };
  switch (s.chapter) {
    case "design":
    case "deliver":
      return papers;
    case "photoacoustic":
      return s.photoacoustic.map === "particles"
        ? papers
        : { label: "Read the skin-tone paper in npj Imaging", href: "https://doi.org/10.1038/s44303-026-00193-4", external: true };
    case "ultrasound":
      return { label: "Read the paper in Radiology Advances", href: "https://doi.org/10.1093/radadv/umaf037", external: true };
    default:
      return null;
  }
}
