import data from "./scholar.json" with { type: "json" };

/*
  Google Scholar's figures for the owner's profile, as a committed snapshot (scholar.json beside this file).
  scripts/scholar-sync.mts writes it: one read of the public profile page every 4 hours in CI, and `npm run
  scholar` by hand (docs/scholar-sync.md). The numbers are Scholar's own as of `checkedAt`; the page never
  calls Google. This module ships in the page build, so it holds types and a lookup only, no parsing.
*/

export interface ScholarArticle {
  /** Scholar's citation id ("zZx1Td0AAAAJ:Tyk-4Ss8FVUC"): stable when a title is edited. */
  id: string;
  /** As Scholar shows it, entities decoded. */
  title: string;
  /** As Scholar prints them ("A Sharma, ET Oluyemi, M Tripathi, ..."). */
  authors: string;
  /** As Scholar prints it, without the trailing year; may be "". */
  venue: string;
  year: number | null;
  /** 0 when Scholar shows none. */
  citedBy: number;
  /** Scholar's list of citing works, https://scholar.google.com/scholar?cites=<id>&hl=en; absent when citedBy is 0. */
  citedByUrl?: string;
  /** The site's publication id (src/content/publications.ts) this entry is, or null when the site doesn't list it. */
  pub: string | null;
}

export interface ScholarSnapshot {
  schema: 1;
  profile: { id: string; url: string; name: string };
  source: "profile-page" | "serpapi";
  /** ISO 8601 UTC, when Scholar was last read successfully. */
  checkedAt: string;
  totals: { citations: number; hIndex: number; i10Index: number };
  /** Scholar's "Since <year>" column: the last five full years and this one. */
  recent: { since: number; citations: number; hIndex: number; i10Index: number };
  /** Oldest first, zero-filled between the first and last year shown; the last year is partial. */
  byYear: Array<{ year: number; citations: number }>;
  articles: ScholarArticle[];
}

export const scholar: ScholarSnapshot = data as ScholarSnapshot;

const byPub = new Map(scholar.articles.flatMap((article) => (article.pub ? [[article.pub, article] as const] : [])));

/** Scholar's entry for one of the site's publications, by its id in publications.ts; undefined when Scholar doesn't list it. */
export function scholarFor(pubId: string): ScholarArticle | undefined {
  return byPub.get(pubId);
}
