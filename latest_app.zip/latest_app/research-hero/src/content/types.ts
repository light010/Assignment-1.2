import type { SkillChapter } from "@/lab/state";

/*
  The content model. Every statement about the person is a Fact with the place it came from;
  a production build refuses to render an unconfirmed Fact, and scripts/check-content.mts fails
  the build when a required one is missing. Editorial copy (summaries, bodies) is plain text:
  it paraphrases confirmed facts and never adds new ones.
*/

/** Where a fact was read, and when. */
export interface Source {
  label: string;
  url?: string;
  /** ISO date the source was last checked. */
  checked: string;
}

/** A statement about the person: rendered only once confirmed. */
export interface Fact<T = string> {
  value: T;
  source: Source;
  confirmed: boolean;
}

export type ThemeId = "delivery" | "imaging";

export type PubType = "journal-article" | "review" | "conference-paper" | "book-chapter" | "thesis";

/** How a visitor can read it. */
export type Access = "open-access" | "free-to-read" | "lab-pdf" | "subscription" | "restricted";

export interface Author {
  /** Display name, given names first ("Ananya Sharma"). */
  name: string;
  /** Family name when it is more than the last word ("Wei Chen"), for citations. */
  family?: string;
  /** The site owner. */
  me?: true;
}

export interface PubLink {
  kind: "doi" | "pdf" | "preprint" | "pmc" | "record";
  href: string;
  /** Visible text: "Paper", "PDF", "Preprint", "PubMed Central", "Thesis record". */
  label: string;
  /** Short note shown after the link, such as "IISc network only". */
  note?: string;
}

export interface Publication {
  /** Stable anchor: #pub-{id}. Never renamed without an alias. */
  id: string;
  aliases?: string[];
  /** Wording verbatim from the publisher; sentence case with acronyms and formulas kept. */
  title: string;
  authors: Author[];
  type: PubType;
  /** Journal, proceedings, book, or institution. */
  venue: string;
  /** A shorter name for the list row when the venue runs long ("SPIE Photons Plus Ultrasound 2026"); citations keep `venue`. */
  venueShort?: string;
  /** Volume, issue, pages, or article number. */
  details?: string;
  year: number;
  doi?: string;
  links: PubLink[];
  access: Access;
  license?: "CC BY 4.0";
  /** Which half of the work it belongs to; empty means "Other and earlier work". */
  themes: ThemeId[];
  /** Lab chapters that show this work. */
  chapters: SkillChapter[];
  /** One sentence on what the paper does, in the owner's words. */
  summary: string;
  /** The owner's contribution, from the journal's published CRediT roles. */
  role?: { credit: string[]; source: string };
  /** Featured in Research, and marked "Selected work" on the owner's current site. */
  selected?: boolean;
  /** One line of context, such as where the lab's threshold comes from. */
  note?: string;
}

export interface Position {
  title: Fact;
  org: string;
  unit?: string;
  place?: string;
  /** "2026-02". */
  start: Fact;
  /** Omitted while current. */
  end?: Fact;
  description: string;
  link?: { label: string; href: string };
}

export interface Education {
  degree: Fact;
  org: string;
  place?: string;
  /** Month the degree was completed, "2025-03". */
  end: Fact;
  description: string;
  link?: { label: string; href: string };
}

export interface Recognition {
  id: string;
  /** "2025" or "2024–present". */
  when: string;
  title: Fact;
  /** What it was for or where, when the title doesn't already say it. */
  context?: string;
  kind: "award" | "service";
  /**
   * The owner's photo of the moment: its file comes from assets/originals/recognition/{id}.* through
   * `npm run photos`. Shown with its credit; it replaces the still.
   */
  photo?: { alt: string; credit: string };
  /**
   * Until there is a photo: a lab still (src/content/renders.ts) that shows the work the item recognizes,
   * labeled "Simulated", with a line saying how it relates. Never a stand-in for the event itself.
   */
  still?: { render: "overview" | "design" | "delivery" | "photoacoustics" | "ultrasound"; caption: string };
}

export interface Update {
  id: string;
  /** ISO date, or "YYYY-MM" when the day is not known. */
  date: string;
  kind: "Paper" | "Role" | "Feature" | "Award";
  title: string;
  text: string;
  link?: { label: string; href: string };
  confirmed: boolean;
}

export interface ResearchTheme {
  id: ThemeId;
  /** Mirrors a headline line; names a publication group. */
  title: string;
}

/** One of the three research directions shown as cards: the delivery half, and the imaging half split in two. */
export interface ResearchDirection {
  id: "delivery" | "photoacoustic" | "ultrasound";
  /** The publication group its papers sit in (the Show filter's value). */
  theme: ThemeId;
  title: string;
  /** Where the work was done. */
  where: Fact;
  /** The question the work answers, in the owner's words. */
  question: string;
  /** At most 45 words: what was done, in the voice rules' plain words. */
  body: string;
  /** 3–5 items of at most 48 characters, the owner's skill vocabulary. */
  skills: string[];
  /** Lab chapters that show it. */
  chapters: SkillChapter[];
}

export interface Person {
  name: string;
  role: Fact;
  now: Fact<{ title: string; org: string; place: string; since: string }>;
  /** First person, at most 160 words. */
  bio: Fact;
  /** Third person, at most 60 words, for talk organizers. */
  shortBio: Fact;
  email: Fact;
  links: {
    scholar: string;
    orcid: Fact;
    linkedin: Fact;
  };
  positions: Position[];
  education: Education[];
}
