/*
  Interface words: every label, button, status, and message the site's components print. The other files
  here hold what the site says (facts, papers, research); these are the words that operate it. The copy check
  (scripts/copy-deck.mts) lints them with the rest, so a stray straight quote or a changed name fails the build.
  One name per action: a button and its confirmation use the same verb.
*/

export const UI = {
  skipLink: "Skip the lab",

  recognition: {
    title: "Recognition and service",
    previous: "Previous",
    next: "Next",
    /** "2 of 3: Best Thesis Award and Gold Medal", announced when the buttons change the item. */
    position: (index: number, count: number, title: string) => `${index} of ${count}: ${title}`,
    award: "Award",
    service: "Service",
    simulated: "Simulated",
  },

  research: {
    title: "Research",
    skills: "Skills",
    inLab: "In the lab",
    /** Goes down to the publication list, filtered to this direction's half of the work. */
    papers: { delivery: "See the delivery papers", imaging: "See the imaging papers" },
  },

  publications: {
    title: "Publications",
    show: "Show",
    options: { all: "All", delivery: "Delivery", imaging: "Imaging", "first-author": "First author" },
    sort: "Sort",
    sortOptions: { newest: "Newest", cited: "Most cited" },
    /** Announced when the order changes. */
    sorted: { newest: "Newest first.", cited: "Most cited first." },
    /** The scrolling list's name, for the keyboard stop that scrolls it. */
    list: "Publication list",
    /** Above the list: how many the filter shows (also announced, with a period, when the filter changes). */
    count: (count: number, total: number) => (count === total ? `${total} publications` : `${count} of ${total} publications`),
    /** Opens a row: the summary, then authors, role, links, and Cite. */
    summary: "Summary",
    /** Phones: shows every row the filter keeps, then back to five. */
    showAll: (count: number) => `Show all ${count}`,
    showFewer: "Show fewer",
    /** Wide screens: lets the list run with the page instead of scrolling in its panel, then back. */
    expandList: "Show the whole list",
    collapseList: "Collapse the list",
    /** "Cited by 34", Google Scholar's own wording; the number links to the citing papers there. */
    citedBy: "Cited by",
    firstAuthor: "First author",
    myRole: "My role:",
    inLab: "In the lab:",
    paper: "Paper",
    readPaper: "Read the paper",
    cite: "Cite",
    copyCitation: "Copy citation",
    copyBibtex: "Copy BibTeX",
    copyLink: "Copy link",
    /** The whole list as one BibTeX file, /publications.bib. */
    allBibtex: "All citations as BibTeX",
  },

  /** The Google Scholar readout beside the publication list; the numbers come from src/content/scholar.json. */
  scholar: {
    label: "Google Scholar",
    citations: "Citations",
    /** Under the citation count, Scholar's "Since 2021" column: "98 since 2021". No-break spaces keep it whole. */
    since: (count: number, year: number) => `${count}\u00a0since\u00a0${year}`,
    hIndex: "h-index",
    /** Under each index, what it counts, with its own value. */
    hMeaning: (h: number) =>
      h === 0 ? "No paper cited yet" : h === 1 ? "1\u00a0paper cited at least once" : `${h}\u00a0papers each cited at least ${h}\u00a0times`,
    i10Index: "i10-index",
    i10Meaning: (count: number) =>
      count === 0
        ? "No paper cited 10\u00a0times yet"
        : count === 1
          ? "1\u00a0paper cited at least 10\u00a0times"
          : `${count}\u00a0papers each cited at least 10\u00a0times`,
    perYear: "Citations per year",
    /** For screen readers, after each year's count in the chart: "2018, 1 citation". */
    citationWord: (count: number) => (count === 1 ? "citation" : "citations"),
    /** After a year that hasn't ended: "2026 so far". */
    soFar: "so far",
    checked: (date: string) => `Checked ${date}`,
    profile: "Google Scholar profile",
  },

  copy: {
    done: "Copied",
    /** When the text is on the page: the button selects it instead. */
    failedSelected: "Couldn’t copy. The text is selected: copy it with your keyboard or menu.",
    /** When it isn't (a link): the message shows it, ready to select. */
    failedShown: "Couldn’t copy. Select it here and copy it with your keyboard or menu:",
    /** When the text had to be loaded and couldn't be. */
    failedLoad: "Couldn’t load the BibTeX. Every citation is in one file:",
  },

  about: {
    title: "About",
    shortBio: "Short bio, for talks and programs",
    copyShortBio: "Copy short bio",
    positions: "Positions and education",
    recent: "Recent",
  },

  contact: {
    title: "Contact",
    copyEmail: "Copy email",
    profiles: "Profiles",
  },

  footer: {
    backToTop: "Back to top",
    scholar: "Google Scholar",
    email: "Email",
    updated: "Updated",
  },

  notFound: {
    title: "Page not found",
    message: "Nothing echoes back from this address. The page may have moved when this site was rebuilt.",
    home: "Home",
  },

  staticHero: {
    caption: "Simulated. The interactive lab couldn’t start in this browser.",
  },

  theme: {
    /** The toggle's accessible name; aria-pressed carries whether the light theme is on. */
    light: "Light theme",
  },
} as const;
