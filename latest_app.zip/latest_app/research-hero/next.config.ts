import type { NextConfig } from "next";

/*
  A static site: `next build` writes every page and file to out/, served by any static host
  (see wrangler.jsonc). Security headers and the /cv redirect live in public/_headers and
  public/_redirects, because next.config headers() and redirects() don't apply to an export.
*/
const nextConfig: NextConfig = {
  output: "export",
  devIndicators: false,
  poweredByHeader: false,
  // The export has no image server; images ship pre-sized as AVIF and WebP (scripts/render-stills.mts).
  images: { unoptimized: true },
};

export default nextConfig;
