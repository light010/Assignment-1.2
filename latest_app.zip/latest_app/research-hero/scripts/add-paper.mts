/*
  Add a paper by its DOI, without editing code by hand.

    node scripts/add-paper.mts --doi 10.1093/radadv/umaf037 --summary "One sentence, in your words." \
      [--role "Data curation, Formal analysis"] [--themes delivery,imaging] \
      [--chapters design,deliver,photoacoustic,ultrasound] [--selected]

  It reads Crossref, drafts a record in the style of the others (id <first author's family name>-<year>-<slug>,
  display names, Crossref's title with markup stripped, links: [doi(...)], "subscription" unless Crossref lists a
  CC BY 4.0 license), and inserts it directly below the marker comment in src/content/publications.ts. The list
  is newest first and check-content enforces that, so an older paper (one the ORCID watch finds later, say) goes
  above the first record that is older still. It also adds the Crossref entry to publications.crossref.json
  beside that file, so `node scripts/enrich-publications.mts --offline` passes.

  It refuses a DOI or id that is already in the file, a DOI Crossref does not know, and a paper with no
  Madhavi Tripathi among the authors (or whose Tripathi carries someone else's ORCID).

  More options:
    --slug <words>      the end of the id, when the automatic one reads badly
    --type <type>       journal-article | review | conference-paper | book-chapter | thesis (Crossref cannot
                        tell a review from an article)
    --file <path>       publications.ts to edit (default src/content/publications.ts); use a copy to try it out
    --snapshot <path>   Crossref snapshot to update (default: publications.crossref.json beside --file)
    --dry-run           print the record and change nothing
*/

import { appendFileSync, existsSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { parseArgs } from "node:util";
import type { Access, Publication, PubType, ThemeId } from "../src/content/types.ts";
import type { SkillChapter } from "../src/lab/state.ts";
import {
  bareDoi,
  DEFAULT_PUBLICATIONS,
  displayName,
  fetchCrossref,
  fold,
  hasCcBy4,
  hasCreativeCommons,
  isTripathi,
  loadPublications,
  normalizeDoi,
  ownerIndex,
  ownerOrcid,
  readSnapshot,
  serializeSnapshot,
  snapshotEntry,
  toSnapshotRecord,
  type SnapshotAuthor,
  type SnapshotRecord,
} from "./enrich-publications.mts";

const MARKER = "// New records go directly below this line; scripts/add-paper.mts inserts here, newest first.";
const THEMES = ["delivery", "imaging"] as const satisfies readonly ThemeId[];
const CHAPTERS = ["design", "deliver", "photoacoustic", "ultrasound"] as const satisfies readonly SkillChapter[];
const TYPES = ["journal-article", "review", "conference-paper", "book-chapter", "thesis"] as const satisfies readonly PubType[];
const CREDIT_ROLES = [
  "Conceptualization", "Data curation", "Formal analysis", "Funding acquisition", "Investigation", "Methodology",
  "Project administration", "Resources", "Software", "Supervision", "Validation", "Visualization",
  "Writing – original draft", "Writing – review & editing",
];
/** Crossref type → the site's type. Anything else needs --type. */
const FROM_CROSSREF: Record<string, PubType> = {
  "journal-article": "journal-article",
  "proceedings-article": "conference-paper",
  "book-chapter": "book-chapter",
  "book-part": "book-chapter",
  "book-section": "book-chapter",
  "reference-entry": "book-chapter",
  dissertation: "thesis",
};
/** Words skipped when the id's slug is taken from the title. */
const SLUG_STOPWORDS = new Set(
  (
    "a an and are as at based by for from in into is its of on or the their this to toward towards under using via " +
    "with within without vs versus new novel study studies effect effects role impact analysis approach " +
    "investigation evaluation comparison assessment"
  ).split(" "),
);
/** Lines longer than this put the value on its own line (the file is hand-wrapped at about this width). */
const WIDTH = 140;

type AuthorItem = "me" | { name: string; family?: string };

interface Draft {
  id: string;
  title: string;
  authors: AuthorItem[];
  type: PubType;
  venue: string;
  details?: string;
  year: number;
  doi: string;
  access: Access;
  license?: "CC BY 4.0";
  themes: ThemeId[];
  chapters: SkillChapter[];
  summary: string;
  role?: { credit: string[]; source: string };
  selected?: boolean;
}

class Refusal extends Error {}
function refuse(message: string): never {
  throw new Refusal(message);
}

/* ------------------------------------------------------------------------------------------------
   Input
   ------------------------------------------------------------------------------------------------ */

function list<T extends string>(raw: string | undefined, allowed: readonly T[], what: string): T[] {
  const items = [...new Set((raw ?? "").split(/[\s,;]+/).map((s) => s.trim().toLowerCase()).filter(Boolean))];
  const unknown = items.filter((item) => !(allowed as readonly string[]).includes(item));
  if (unknown.length) {
    const hint = what === "chapters" && unknown.includes("delivery") ? ' (the chapter is "deliver"; "delivery" is a theme)' : "";
    refuse(`Unknown ${what}: ${unknown.join(", ")}${hint}. Use any of: ${allowed.join(", ")}.`);
  }
  return items as T[];
}

function cleanSummary(raw: string, warnings: string[]): string {
  let summary = raw.replace(/\s+/g, " ").trim();
  if (!summary) refuse("--summary is empty: write one sentence on what the paper does.");
  if (!/[.!?]$/.test(summary)) summary += ".";
  if (/[.!?]\s+[A-Z]/.test(summary)) warnings.push("The summary looks like more than one sentence; the site uses one.");
  if (summary.length > 170) warnings.push(`The summary is ${summary.length} characters; the others are 87 to 150.`);
  return summary;
}

function parseRole(raw: string | undefined, doi: string, warnings: string[]): Draft["role"] {
  const credit = [...new Set((raw ?? "").split(/[,;]/).map((s) => s.replace(/\s+/g, " ").trim()).filter(Boolean))];
  if (!credit.length) return undefined;
  const key = (role: string) => fold(role).replace(/&/g, "and").replace(/[^a-z]/g, "");
  const known = new Set(CREDIT_ROLES.map(key));
  const unknown = credit.filter((role) => !known.has(key(role)));
  if (unknown.length) warnings.push(`Not CRediT role names: ${unknown.join(", ")}. The roles are: ${CREDIT_ROLES.join(", ")}.`);
  return { credit, source: `https://doi.org/${doi}` };
}

/* ------------------------------------------------------------------------------------------------
   Building the record
   ------------------------------------------------------------------------------------------------ */

const capitalized = (word: string) => word.charAt(0) + word.slice(1).toLowerCase();

/** "T" → "T.", "AM" → "A. M.", "MADHAVI" → "Madhavi"; anything else as Crossref gives it. */
function givenDisplay(given: string): string {
  return given
    .split(/\s+/)
    .filter(Boolean)
    .map((token) => {
      if (/^[A-Z]$/.test(token)) return `${token}.`;
      if (/^[A-Z]{2,3}$/.test(token)) return token.split("").map((c) => `${c}.`).join(" ");
      if (/^[A-Z][A-Z'-]{3,}$/.test(token)) return token.split("-").map(capitalized).join("-");
      return token;
    })
    .join(" ");
}

function familyDisplay(family: string): string {
  return family
    .split(/\s+/)
    .filter(Boolean)
    .map((word) => (/^[A-Z][A-Z'-]{3,}$/.test(word) ? word.split("-").map(capitalized).join("-") : word))
    .join(" ");
}

function authorItem(author: SnapshotAuthor): AuthorItem {
  if (author.name !== undefined) return { name: author.name };
  const family = familyDisplay(author.family ?? "");
  const name = [givenDisplay(author.given ?? ""), family].filter(Boolean).join(" ");
  // `family` is recorded only when it is more than the last word ("Wei Chen"), as in the curated records.
  return family.includes(" ") ? { name, family } : { name };
}

const slugify = (value: string) =>
  fold(value)
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");

function titleSlug(title: string): string {
  const words = fold(title)
    .split(/[^a-z0-9]+/)
    .filter((word) => word && !SLUG_STOPWORDS.has(word) && !/^\d+$/.test(word));
  return words.slice(0, 2).join("-");
}

function looksLikeTitleCase(title: string): boolean {
  const words = title.split(/\s+/).slice(1).filter((word) => /^[A-Za-z][a-z]{3,}/.test(word));
  return words.length >= 4 && words.filter((word) => /^[A-Z]/.test(word)).length / words.length > 0.6;
}

const noZeros = (value: string | null) => (value ?? "").replace(/^0+(?=\d)/, "");
const pageRange = (value: string) => value.replace(/\s*[-\u2010-\u2015\u2212]\s*/g, "–");

function venueFor(type: PubType, cr: SnapshotRecord, publisher: string | undefined, resourceUrl: string | undefined): string {
  const container = cr.container ?? "";
  if (!container) refuse("Crossref gives no journal, proceedings, or book title for this DOI; add it by hand.");
  const spieVolume = /conference-proceedings-of-spie\/(\d+)\//.exec(resourceUrl ?? "")?.[1];
  if (type === "conference-paper" && spieVolume) return `Proceedings of SPIE ${spieVolume}, ${container}`;
  if (type === "book-chapter" && publisher) {
    const short = publisher
      .replace(/\s*\([^)]*\)/g, "")
      .replace(/[\s,]+(B\.?V\.?|Ltd\.?|Limited|LLC|Inc\.?|GmbH|AG|plc|S\.A\.)$/i, "")
      .trim();
    return `${container} (${short})`;
  }
  return container;
}

function detailsFor(type: PubType, cr: SnapshotRecord, doi: string, warnings: string[]): string | undefined {
  const volume = noZeros(cr.volume);
  const issue = noZeros(cr.issue);
  const page = cr.page ?? "";
  const isRange = /^\w+\s*[-\u2010-\u2015\u2212]\s*\w+$/.test(page);
  // SPIE journals number articles by the end of the DOI (10.1117/1.JBO.31.8.085001 → 085001).
  const spieArticle = /^10\.1117\/1\.[a-z]+\.\d+\.\d+\.(\w+)$/i.exec(doi)?.[1];
  if (type === "book-chapter") return isRange ? `pp. ${pageRange(page)}` : undefined;
  if (type === "conference-paper") {
    if (cr.articleNumber) return cr.articleNumber;
    if (isRange) return `pp. ${pageRange(page)}`;
    warnings.push("Crossref has no paper number for this proceedings paper (SPIE's look like 1385103): add `details` by hand from the paper.");
    return undefined;
  }
  if (type === "thesis") return undefined;
  const locator = spieArticle ?? cr.articleNumber ?? (page ? pageRange(page) : "");
  if (!volume && !locator) {
    warnings.push("Crossref has no volume, issue, or pages yet (usual for a new paper): add `details` when they appear.");
    return undefined;
  }
  const head = volume ? `${volume}${issue ? `(${issue})` : ""}` : "";
  return [head, locator].filter(Boolean).join(", ");
}

function accessFor(licenses: string[], warnings: string[]): Pick<Draft, "access" | "license"> {
  if (hasCcBy4(licenses)) return { access: "open-access", license: "CC BY 4.0" };
  if (hasCreativeCommons(licenses)) {
    const cc = licenses.filter((url) => /creativecommons\.org/i.test(url)).join(", ");
    warnings.push(`Crossref lists ${cc}, not CC BY 4.0: marked "open-access" without a license label. Check it.`);
    return { access: "open-access" };
  }
  return { access: "subscription" };
}

/* ------------------------------------------------------------------------------------------------
   Writing the record in the file's style
   ------------------------------------------------------------------------------------------------ */

const q = (value: string) => JSON.stringify(value);

function property(key: string, value: string, indent = "    "): string[] {
  const oneLine = `${indent}${key}: ${value},`;
  return oneLine.length <= WIDTH ? [oneLine] : [`${indent}${key}:`, `${indent}  ${value},`];
}

function array(key: string, items: string[], indent = "    "): string[] {
  const oneLine = `${indent}${key}: [${items.join(", ")}],`;
  return oneLine.length <= WIDTH ? [oneLine] : [`${indent}${key}: [`, ...items.map((item) => `${indent}  ${item},`), `${indent}],`];
}

function renderRecord(draft: Draft): string {
  const authorItems = draft.authors.map((a) =>
    a === "me" ? "me" : a.family ? `{ name: ${q(a.name)}, family: ${q(a.family)} }` : `{ name: ${q(a.name)} }`,
  );
  const lines = [
    "  {",
    `    id: ${q(draft.id)},`,
    ...property("title", q(draft.title)),
    ...array("authors", authorItems),
    `    type: ${q(draft.type)},`,
    ...property("venue", q(draft.venue)),
    ...(draft.details ? [`    details: ${q(draft.details)},`] : []),
    `    year: ${draft.year},`,
    `    doi: ${q(draft.doi)},`,
    `    links: [doi(${q(draft.doi)})],`,
    `    access: ${q(draft.access)},`,
    ...(draft.license ? [`    license: ${q(draft.license)},`] : []),
    `    themes: [${draft.themes.map(q).join(", ")}],`,
    `    chapters: [${draft.chapters.map(q).join(", ")}],`,
    ...property("summary", q(draft.summary)),
    ...(draft.role
      ? ["    role: {", ...array("credit", draft.role.credit.map(q), "      "), `      source: ${q(draft.role.source)},`, "    },"]
      : []),
    ...(draft.selected ? ["    selected: true,"] : []),
    "  },",
  ];
  return lines.join("\n");
}

/* ------------------------------------------------------------------------------------------------
   Main
   ------------------------------------------------------------------------------------------------ */

async function main(): Promise<number> {
  const { values } = parseArgs({
    options: {
      doi: { type: "string" },
      summary: { type: "string" },
      role: { type: "string" },
      themes: { type: "string" },
      chapters: { type: "string" },
      selected: { type: "boolean" },
      slug: { type: "string" },
      type: { type: "string" },
      file: { type: "string" },
      snapshot: { type: "string" },
      "dry-run": { type: "boolean" },
      help: { type: "boolean", short: "h" },
    },
  });
  if (values.help) {
    console.log('Usage: node scripts/add-paper.mts --doi <doi> --summary "<one sentence>" [--role "<roles>"]' +
      " [--themes delivery,imaging] [--chapters design,deliver,photoacoustic,ultrasound] [--selected]\n" +
      "       [--slug <words>] [--type <type>] [--file <publications.ts>] [--snapshot <json>] [--dry-run]");
    return 0;
  }

  const warnings: string[] = [];
  const doi = bareDoi(values.doi ?? "");
  if (!/^10\.\d{4,9}\/\S+$/.test(doi)) refuse(`--doi must look like 10.1093/radadv/umaf037 (got ${q(values.doi ?? "")}).`);
  const summary = cleanSummary(values.summary ?? "", warnings);
  const themes = list(values.themes, THEMES, "themes");
  const chapters = list(values.chapters, CHAPTERS, "chapters");
  const role = parseRole(values.role, doi, warnings);
  const typeOverride = values.type ? list(values.type, TYPES, "type")[0] : undefined;

  const file = resolve(values.file ?? DEFAULT_PUBLICATIONS);
  const snapshotPath = resolve(values.snapshot ?? join(dirname(file), "publications.crossref.json"));
  const source = readFileSync(file, "utf8");
  const eol = source.includes("\r\n") ? "\r\n" : "\n";
  const lines = source.split(eol);
  const markerAt = lines.findIndex((line) => line.trim() === MARKER);
  if (markerAt < 0) refuse(`The marker comment is missing from ${file}:\n  ${MARKER}`);

  // Duplicates: the record DOIs, every DOI in a link (preprints too), ids, and aliases.
  const existing = await loadPublications(file);
  const key = normalizeDoi(doi);
  const clash = existing.find(
    (p) => (p.doi && normalizeDoi(p.doi) === key) || p.links.some((l) => /doi\.org\//i.test(l.href) && normalizeDoi(l.href) === key),
  );
  if (clash) refuse(`${doi} is already in the file, in ${clash.id}.`);

  const work = await fetchCrossref(doi);
  if (!work) refuse(`Crossref does not know ${doi}. Check the DOI; papers registered elsewhere (DataCite, for example) need adding by hand.`);
  const record = toSnapshotRecord(work);

  // Namesake protection: the paper must list Madhavi Tripathi, and not someone else's ORCID for her.
  const orcid = await ownerOrcid();
  const owner = ownerIndex(record.authors, orcid);
  if (!record.authors.some(isTripathi)) {
    refuse(`Crossref lists no author named Tripathi for ${doi} (authors: ${record.authors.map(displayName).join(", ")}).`);
  }
  if (owner < 0) {
    const tripathis = record.authors.filter(isTripathi).map((a) => `${displayName(a)}${a.orcid ? ` (ORCID ${a.orcid})` : ""}`);
    refuse(`${doi} lists ${tripathis.join(" and ")}, but not Madhavi Tripathi (ORCID ${orcid}): probably a namesake.`);
  }
  if (record.authors[owner].orcid !== orcid) {
    warnings.push(`Crossref has no ORCID for Tripathi on this paper, so it cannot confirm the author is Madhavi Tripathi (${orcid}). Check before merging.`);
  }

  const type = typeOverride ?? FROM_CROSSREF[record.type] ?? refuse(`Crossref calls this a ${q(record.type)}; pass --type with one of: ${TYPES.join(", ")}.`);
  const year = Number(record.published?.slice(0, 4));
  if (!Number.isInteger(year)) refuse(`Crossref gives no publication date for ${doi}.`);
  if (!record.title) refuse(`Crossref gives no title for ${doi}.`);
  if (looksLikeTitleCase(record.title)) {
    warnings.push("Crossref gives the title in Title Case. The site uses sentence case, keeping acronyms and formulas (CuS, SLSC): edit it in the pull request.");
  }

  const first = record.authors[0];
  const family = slugify(first ? (first.family ?? first.name ?? "") : "") || "anon";
  const slug = values.slug !== undefined ? slugify(values.slug) : titleSlug(record.title);
  if (!slug) refuse("Could not make a slug from the title; pass --slug with a word or two.");
  const id = `${family}-${year}-${slug}`;
  const taken = existing.find((p) => p.id === id || (p.aliases ?? []).includes(id));
  if (taken) refuse(`The id ${id} is already used by ${taken.doi ?? taken.id}. Pass --slug with other words.`);

  const draft: Draft = {
    id,
    // The content check rejects a title that ends with a period.
    title: record.title.replace(/\.$/, ""),
    authors: record.authors.map((author, i) => (i === owner ? "me" : authorItem(author))),
    type,
    venue: venueFor(type, record, work.publisher, work.resource?.primary?.URL),
    details: detailsFor(type, record, doi, warnings),
    year,
    doi,
    ...accessFor(record.license, warnings),
    themes,
    chapters,
    summary,
    role,
    selected: values.selected ? true : undefined,
  };
  const names = draft.authors.map((a) => (a === "me" ? "Madhavi Tripathi" : a.name));
  if (new Set(names).size !== names.length) warnings.push("Crossref lists an author twice; the content check rejects that. Fix the list.");
  const rendered = renderRecord(draft);

  // Newest first, which the content check enforces: a new paper goes directly below the marker; an older one
  // (found later, say through the ORCID watch) goes above the first record that is older still.
  const dates = existsSync(snapshotPath) ? readSnapshot(snapshotPath) : {};
  const dateOf = (p: Publication) => (p.doi ? snapshotEntry(dates, p.doi)?.published : undefined) ?? String(p.year);
  const newDate = record.published ?? String(year);
  const olderAt = existing.findIndex((p) => dateOf(p) < newDate);
  const position = olderAt < 0 ? existing.length : olderAt;
  let insertAt = markerAt + 1;
  if (position > 0 && position < existing.length) {
    const idLine = lines.findIndex((l) => l === `    id: ${q(existing[position].id)},`);
    insertAt = idLine > 0 && lines[idLine - 1] === "  {" ? idLine - 1 : -1;
  } else if (position > 0) {
    insertAt = lines.findIndex((l, i) => i > markerAt && /^\];/.test(l));
  }
  if (insertAt < 0) refuse(`Could not find where a ${year} paper goes in ${file}; add the record by hand.`);
  const where = position === 0 ? "directly below the marker" : position < existing.length ? `above ${existing[position].id}, to keep the list newest first` : "at the end, as the oldest";

  console.log(`${values["dry-run"] ? "Would add" : "Adding"} ${id} to ${file}, ${where}:\n`);
  console.log(rendered);
  for (const warning of warnings) console.log(`\nCheck: ${warning}`);

  if (!values["dry-run"]) {
    const updated = [...lines.slice(0, insertAt), ...rendered.split("\n"), ...lines.slice(insertAt)].join(eol);
    writeFileSync(file, updated);
    let after: Publication[] | undefined;
    try {
      after = await loadPublications(file);
    } catch (error) {
      console.error(`The edited file does not load: ${error instanceof Error ? error.message : String(error)}`);
    }
    if (!after || after.length !== existing.length + 1 || after[position]?.id !== id || after[position]?.doi !== doi) {
      writeFileSync(file, source);
      refuse(`The new record did not read back where it was put, so ${file} was restored unchanged.`);
    }
    if (existsSync(snapshotPath)) {
      const snapshot = readSnapshot(snapshotPath);
      snapshot[doi] = record;
      writeFileSync(snapshotPath, serializeSnapshot(snapshot));
      console.log(`\nAdded the Crossref entry to ${snapshotPath}.`);
    } else {
      warnings.push(`No snapshot at ${snapshotPath}: run \`npm run enrich\` so the offline check knows this DOI.`);
      console.log(`\nCheck: ${warnings[warnings.length - 1]}`);
    }
    console.log(`\nAdded ${id}. Next: review the title's case, the summary, role, themes, and chapters; then run`);
    console.log("`node scripts/enrich-publications.mts --offline`, `npm run typecheck`, and `npm run check:content`.");
  }

  if (process.env.GITHUB_OUTPUT) {
    appendFileSync(process.env.GITHUB_OUTPUT, `id=${id}\ndoi=${doi}\ntitle=${draft.title.replace(/[\r\n]+/g, " ")}\n`);
  }
  return 0;
}

try {
  process.exitCode = await main();
} catch (error) {
  // A Refusal is expected (bad input, a duplicate, a namesake); anything else is a bug or a network failure.
  console.error(`add-paper: ${error instanceof Error ? error.message : String(error)}`);
  if (!(error instanceof Refusal) && error instanceof Error && error.stack) console.error(error.stack);
  process.exitCode = 1;
}
