/*
  The copy deck: every sentence and label the content files put on the page, with its length against
  the budgets in design-system/MASTER.md, so reviewers can read the words without the design around them.
  The same pass lints the words against the style guide: budgets, the glossary, banned words, American
  spelling, curly quotes, and characters the fonts don't have.

  npm run copy-deck    writes docs/copy-deck.md
  npm run check:copy   lints only, and fails on a broken rule (it runs before every build)

  Paper titles, venues, and names are quoted verbatim and never linted. The owner's own words (paper
  summaries, bios, the research questions) get warnings for glossary terms, not failures: the glossary
  governs the lab's voice, and changing the owner's wording is the owner's call.
*/
import fs from "node:fs";
import path from "node:path";
import { recognition, updates } from "../src/content/about.ts";
import { CHAPTER_ORDER, CHAPTERS, callouts, caption, evidence, panelInfo, readouts } from "../src/content/chapters.ts";
import { person } from "../src/content/person.ts";
import { profile } from "../src/content/profile.ts";
import { publications } from "../src/content/publications.ts";
import { DECKS, DESCRIPTION, SECTIONS, SIMULATION_NOTE } from "../src/content/site.ts";
import { RESEARCH_DECK, directions, themes } from "../src/content/themes.ts";
import { UI } from "../src/content/ui.ts";
import { allStates, describe, metricSamples } from "./lib/lab-states.mts";

type Voice = "site" | "owner" | "label";
interface Item {
  section: string;
  where: string;
  text: string;
  voice: Voice;
  /** Characters, or words when `words` is set. */
  budget?: number;
  words?: boolean;
  /** Numbers are expected here (readouts, measured captions, notes that quote a threshold). */
  numbers?: boolean;
}

const items: Item[] = [];
const add = (item: Item) => items.push(item);

// ── Hero ─────────────────────────────────────────────────────────────────────────────────────────
profile.headline.forEach((line, i) => add({ section: "Hero", where: `headline line ${i + 1}`, text: line, voice: "site", budget: 28 }));
add({ section: "Hero", where: "lede", text: profile.lede, voice: "site", budget: 160 });
add({ section: "Hero", where: "role", text: person.role.value, voice: "label" });
for (const n of profile.nav) add({ section: "Hero", where: "nav", text: n.label, voice: "label" });

// ── Lab: chapter labels and controls, then every state ───────────────────────────────────────────
for (const id of CHAPTER_ORDER) {
  const c = CHAPTERS[id];
  add({ section: "Lab", where: `${id} tab`, text: c.label, voice: "label" });
  add({ section: "Lab", where: `${id} tab hint`, text: c.hint, voice: "label", budget: 20 });
  for (const control of c.controls) {
    add({ section: "Lab", where: `${id} control`, text: control.label, voice: "label" });
    for (const o of control.options) add({ section: "Lab", where: `${id} ${control.key} option`, text: o.label, voice: "label", budget: 14 });
  }
}
const seen = new Set<string>();
const once = (item: Item) => {
  const key = `${item.where}|${item.text}`;
  if (seen.has(key)) return;
  seen.add(key);
  add(item);
};
for (const s of allStates()) {
  const state = describe(s);
  for (const m of metricSamples(s)) {
    once({ section: "Lab states", where: `${state} caption`, text: caption(s, m), voice: "site", budget: 180, numbers: true });
    for (const r of readouts(s, m)) {
      once({ section: "Lab states", where: `${s.chapter} readout label`, text: r.label, voice: "label" });
      once({ section: "Lab states", where: `${s.chapter} readout "${r.label}"`, text: r.value, voice: "label", budget: 18, numbers: true });
    }
  }
  for (const c of callouts(s)) once({ section: "Lab states", where: `${s.chapter} 3D label`, text: c.text, voice: "label", budget: 24 });
  const panel = panelInfo(s);
  once({ section: "Lab states", where: `${s.chapter} image title`, text: panel.title, voice: "label" });
  for (const l of panel.legend) once({ section: "Lab states", where: `${s.chapter} legend`, text: l.label, voice: "label" });
  const e = evidence(s);
  if (e) once({ section: "Lab states", where: `${s.chapter} evidence link`, text: e.label, voice: "label" });
}

// ── Sections ─────────────────────────────────────────────────────────────────────────────────────
add({ section: "Research", where: "deck", text: RESEARCH_DECK, voice: "site", budget: 140 });
for (const t of themes) add({ section: "Publications", where: `${t.id} group title`, text: t.title, voice: "site" });
for (const d of directions) {
  add({ section: "Research", where: `${d.id} title`, text: d.title, voice: "site" });
  add({ section: "Research", where: `${d.id} where`, text: d.where.value, voice: "label" });
  add({ section: "Research", where: `${d.id} question`, text: d.question, voice: "owner" });
  add({ section: "Research", where: `${d.id} body`, text: d.body, voice: "site", budget: 45, words: true });
  // Skills keep the owner's vocabulary for specialists ("channel data"), so glossary hits are warnings.
  d.skills.forEach((s, i) => add({ section: "Research", where: `${d.id} skill ${i + 1}`, text: s, voice: "owner", budget: 48 }));
}
add({ section: "Publications", where: "deck", text: DECKS.publications, voice: "site", budget: 140 });
for (const p of publications) {
  add({ section: "Publications", where: `${p.id} summary`, text: p.summary, voice: "owner", budget: 240 });
  // Roles quote the journal's CRediT record verbatim, so they may run past the 90-character line budget.
  if (p.role) add({ section: "Publications", where: `${p.id} role`, text: `My role: ${p.role.credit.join(", ")}`, voice: "owner", budget: 140 });
  if (p.note) add({ section: "Publications", where: `${p.id} note`, text: p.note, voice: "site", numbers: true });
  for (const l of p.links) add({ section: "Publications", where: `${p.id} link`, text: l.note ? `${l.label} (${l.note})` : l.label, voice: "label" });
}
person.bio.value.split("\n\n").forEach((para, i) => add({ section: "About", where: `bio paragraph ${i + 1}`, text: para, voice: "owner" }));
add({ section: "About", where: "bio, whole", text: person.bio.value.replace(/\n\n/g, " "), voice: "owner", budget: 160, words: true });
add({ section: "About", where: "short bio", text: person.shortBio.value, voice: "owner", budget: 60, words: true });
person.positions.forEach((p, i) => {
  add({ section: "About", where: `position ${i + 1} title`, text: p.title.value, voice: "label" });
  add({ section: "About", where: `position ${i + 1}`, text: p.description, voice: "owner" });
});
person.education.forEach((e, i) => {
  add({ section: "About", where: `degree ${i + 1}`, text: e.degree.value, voice: "label" });
  add({ section: "About", where: `degree ${i + 1} description`, text: e.description, voice: "owner" });
});
for (const r of recognition) {
  add({ section: "About", where: `recognition ${r.id}`, text: r.title.value, voice: "label", numbers: true });
  if (r.context) add({ section: "About", where: `recognition ${r.id} context`, text: r.context, voice: "owner", numbers: true });
  // Captions sit on one line under the picture; credits too (copy review, image-led carousel notes).
  if (r.still) add({ section: "About", where: `recognition ${r.id} still caption`, text: r.still.caption, voice: "site", budget: 50 });
  if (r.photo) {
    add({ section: "About", where: `recognition ${r.id} photo credit`, text: `Photo: ${r.photo.credit}`, voice: "label", budget: 40 });
    add({ section: "About", where: `recognition ${r.id} photo alt`, text: r.photo.alt, voice: "site", budget: 160 });
  }
}
for (const u of updates) {
  add({ section: "About", where: `update ${u.id} title`, text: u.title, voice: "site", numbers: true });
  add({ section: "About", where: `update ${u.id}`, text: u.text, voice: "site", numbers: true });
}
add({ section: "Contact", where: "deck", text: DECKS.contact, voice: "site", budget: 140 });
add({ section: "Footer", where: "simulation note", text: SIMULATION_NOTE, voice: "site" });
add({ section: "Metadata", where: "title", text: `${person.name}, ${person.role.value.toLowerCase()}`, voice: "site", budget: 60 });
add({ section: "Metadata", where: "description", text: DESCRIPTION, voice: "site", budget: 155 });
for (const s of SECTIONS) add({ section: "Metadata", where: `section ${s.id}`, text: s.label, voice: "label" });

// ── Interface words (src/content/ui.ts), with sample values where a string takes them ───────────────
const SAMPLES: Record<string, unknown[]> = {
  position: [2, 3, "Best Thesis Award and Gold Medal"],
  showAll: [15],
  count: [6, 15],
  citationWord: [2],
  since: [98, 2021],
  hMeaning: [7],
  i10Meaning: [3],
  checked: ["28 Sep 2026"],
};
function addUi(value: unknown, where: string) {
  if (typeof value === "string") add({ section: "Interface", where, text: value, voice: "label", numbers: true });
  else if (typeof value === "function") {
    const key = where.split(".").at(-1) ?? "";
    const out = (value as (...args: unknown[]) => unknown)(...(SAMPLES[key] ?? []));
    addUi(typeof out === "object" && out !== null ? Object.values(out).join("") : out, where);
  } else if (value && typeof value === "object") for (const [k, v] of Object.entries(value)) addUi(v, `${where}.${k}`);
}
addUi(UI, "ui");

// ── Rules ────────────────────────────────────────────────────────────────────────────────────────
interface Rule {
  pattern: RegExp;
  message: string;
  /** Where the rule applies; a glossary rule is a warning in the owner's own words. */
  voices?: Voice[];
  glossary?: boolean;
}
const RULES: Rule[] = [
  // Banned (PLAN 4.3, appendix B 5.1)
  { pattern: /\b(passionate|cutting-edge|novel|breakthrough|state-of-the-art|revolutionary|world-class|game-chang\w*)\b/i, message: "banned word" },
  // Glossary: one name per thing (MASTER.md)
  { pattern: /\bnanocarriers?\b|\bNPs?\b/, message: 'use "nanoparticle"', glossary: true },
  { pattern: /\babsorbers?\b/i, message: 'use "light-absorbing core"', glossary: true },
  { pattern: /\bthermo-?responsive\b/i, message: 'use "heat-responsive"', glossary: true },
  { pattern: /\bhydrogels?\b/i, message: 'use "gel" or "gel carrier"', glossary: true },
  { pattern: /\bcloak(ed|ing|s)?\b/i, message: 'use "membrane coat"', glossary: true },
  { pattern: /\btumou?r core\b/i, message: 'use "tumor center"; "core" belongs to the particle', glossary: true },
  { pattern: /\blasers?\b/i, message: 'use "light" ("pulsed" or "continuous")', glossary: true },
  { pattern: /\bexploded\b/i, message: 'use "taken apart"', glossary: true },
  { pattern: /\boxygen-(rich|poor)\b/i, message: 'use "oxygenated" or "deoxygenated"', glossary: true },
  { pattern: /\bwarm(ed|ing|s)?\b/i, message: 'use "heat" or "heated"', glossary: true },
  { pattern: /\bstandard beamformer\b/i, message: 'use "delay-and-sum"', glossary: true },
  { pattern: /(?<![g\w])CNR\b|\bcontrast ratio\b/i, message: 'use "gCNR"', glossary: true },
  { pattern: /\bchannel data\b|\bRF (data|signals?)\b/i, message: 'use "raw echoes"', glossary: true },
  { pattern: /\boptoacoustic\b/i, message: 'use "photoacoustic"', glossary: true },
  { pattern: /\bPTT\b/, message: 'use "heating tumors with light"', glossary: true },
  { pattern: /\bJHU\b/, message: 'use "Johns Hopkins"', glossary: true },
  // The owner's rule: describe skills, not materials. Material, drug, and wavelength names stay in paper titles.
  {
    pattern: /\b(copper sulfide|CuS|mucin(-capped)?|PVP|MXenes?|epoxy|hydroxychloroquine|chloroquine|NIR(-II)?|near-infrared)\b|\bgold\b(?! medal)|\b\d+\s?nm\b/i,
    message: "names a material, drug, or wavelength: describe the skill instead",
    glossary: true,
  },
  // American spelling
  {
    pattern:
      /\b(colou?rs?\b(?<=colours?)|colour\w+|behaviour\w*|tumours?|centre[sd]?|favour\w*|analys(e|ed|es|ing)|optimis\w+|organis(e|ed|es|ing|ation)|realis(e|ed|es|ing)|recognis(e|ed|es|ing)|characteris(e|ed|es|ing|ation)|synthesis(e|ed|es|ing)|modelling|modelled|labelled|labelling|travelled|programme|fibres?|litres?|grey|aluminium|sulphur|haem\w*|oesophag\w*|anaesthe\w*|paediatric\w*|foetal|oestrogen)\b/i,
    message: "use American spelling",
  },
  // Typography
  { pattern: /['"]/, message: "use curly quotes and apostrophes (’ “ ”)" },
  { pattern: /!/, message: "no exclamation marks" },
  { pattern: / \+ /, message: 'write "and", not "+"' },
  { pattern: / - /, message: "a spaced hyphen: use an em dash or an en dash" },
  { pattern: /\.\.\./, message: "use the ellipsis character …" },
  { pattern: /\s{2,}(?!$)|^\s|\s$/, message: "stray whitespace" },
  { pattern: /[→↗  µ′]/, message: "a character the fonts don't have (→ ↗ thin spaces µ ′)" },
  { pattern: /(?![\u00a9\u00ae\u2122])\p{Extended_Pictographic}/u, message: "no emoji" },
];

/*
  Warnings the owner or the reviews have settled, with the reason. They stay listed in the deck but no
  longer print on every build. A new hit in the same string still prints.
*/
const ACCEPTED: ReadonlyArray<{ where: string; message: string; reason: string }> = [
  {
    where: "arroyo-2026-jbo summary",
    message: 'use "light" ("pulsed" or "continuous")',
    reason: "The study measures laser injury thresholds; \"light\" would be less accurate.",
  },
  {
    where: "ultrasound skill 3",
    message: 'use "raw echoes"',
    reason: "A skills list for specialists uses the term of art; the lab says \"raw echoes\" for everyone else.",
  },
];

interface Finding {
  item: Item;
  message: string;
  level: "error" | "warning";
}
const findings: Finding[] = [];
const wordCount = (s: string) => s.trim().split(/\s+/).filter(Boolean).length;

for (const item of items) {
  // A single word label (a tab, an option) is exempt from sentence rules but not from spelling or glyphs.
  for (const rule of RULES) {
    if (!rule.pattern.test(item.text)) continue;
    const level = rule.glossary && item.voice === "owner" ? "warning" : "error";
    findings.push({ item, message: rule.message, level });
  }
  const dashes = item.text.split("\n").map((para) => (para.match(/—/g) ?? []).length);
  if (dashes.some((n) => n > 1)) findings.push({ item, message: "more than one em dash in a paragraph", level: "error" });
  if (item.budget !== undefined) {
    const size = item.words ? wordCount(item.text) : [...item.text.replace(/⁠/g, "")].length;
    if (size > item.budget) findings.push({ item, message: `${size} ${item.words ? "words" : "characters"}, over the ${item.budget} budget`, level: "error" });
  }
  // Names that contain digits aren't numbers in prose.
  const prose = item.text.replace(/\b(3D|2D|COVID-19|M\.Tech\.)\b/g, "");
  if (!item.numbers && item.voice !== "label" && /\d/.test(prose))
    findings.push({ item, message: "a number in prose: keep numbers to citations, readouts, and the threshold note", level: "warning" });
}

const isAccepted = (f: Finding) => ACCEPTED.some((a) => f.item.where === a.where && f.message === a.message);
const errors = findings.filter((f) => f.level === "error");
const warnings = findings.filter((f) => f.level === "warning" && !isAccepted(f));
const accepted = findings.filter((f) => f.level === "warning" && isAccepted(f));
const line = (f: Finding) => `  - [${f.item.section}] ${f.item.where}: ${f.message}\n      “${f.item.text.length > 140 ? f.item.text.slice(0, 137) + "…" : f.item.text}”`;

// ── The deck ─────────────────────────────────────────────────────────────────────────────────────
const DECK = path.join(import.meta.dirname, "..", "docs", "copy-deck.md");
function deck(): string {
  const out: string[] = [
    "# Copy deck",
    "",
    "Generated by `npm run copy-deck` from `src/content`. Don't edit it here: change the content files and regenerate.",
    "Lengths are characters (or words, where marked) against the budgets in `design-system/MASTER.md`; ✗ marks one over budget.",
    "",
  ];
  let section = "";
  for (const item of items) {
    if (item.section !== section) {
      section = item.section;
      out.push(`## ${section}`, "", "| Where | Text | Length |", "| --- | --- | --- |");
    }
    const size = item.words ? `${wordCount(item.text)} words` : `${[...item.text.replace(/⁠/g, "")].length}`;
    const over = item.budget !== undefined && (item.words ? wordCount(item.text) : [...item.text.replace(/⁠/g, "")].length) > item.budget;
    const budget = item.budget === undefined ? size : `${size} / ${item.budget}${over ? " ✗" : ""}`;
    const text = item.text.replace(/⁠/g, "").replace(/\|/g, "\\|").replace(/\n+/g, " ¶ ");
    const where = item.where.replace(/\|/g, "\\|");
    // A new table after every state heading would be noise; one table per section is enough.
    if (out[out.length - 1] === "" && item.section === section && out[out.length - 2]?.startsWith("|")) out.pop();
    out.push(`| ${where} | ${text} | ${budget} |`);
    if (items[items.indexOf(item) + 1]?.section !== section) out.push("");
  }
  if (warnings.length) out.push("## Warnings", "", ...warnings.map((f) => `- **${f.item.where}**: ${f.message}`), "");
  if (accepted.length)
    out.push(
      "## Accepted exceptions",
      "",
      ...accepted.map((f) => `- **${f.item.where}**: ${f.message}. ${ACCEPTED.find((a) => a.where === f.item.where && a.message === f.message)?.reason}`),
      "",
    );
  return out.join("\n");
}

const check = process.argv.includes("--check");
if (!check) {
  fs.writeFileSync(DECK, deck());
  console.log(`Wrote ${path.relative(process.cwd(), DECK)}: ${items.length} strings.`);
}
console.log(`Copy check: ${items.length} strings, ${errors.length} errors, ${warnings.length} warnings.`);
if (warnings.length) console.log(`Warnings (the owner's call, or worth a second look):\n${warnings.map(line).join("\n")}`);
if (check && fs.existsSync(DECK) && fs.readFileSync(DECK, "utf8") !== deck())
  console.log("Note: docs/copy-deck.md is out of date; run npm run copy-deck before review.");
if (errors.length) {
  console.error(`\n✗ ${errors.length} copy error${errors.length === 1 ? "" : "s"}:\n${errors.map(line).join("\n")}`);
  process.exit(1);
}
console.log("✓ Copy follows the style guide.");
