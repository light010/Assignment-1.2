/*
  Google Scholar snapshot: the owner's citation figures, read politely and committed as a file the site builds from.

    npm run scholar
        One GET of the public profile page (the Scholar link in src/content/person.ts, ...?user=<id>&hl=en),
        parsed, matched to src/content/publications.ts, checked against the committed snapshot, and written to
        src/content/scholar.json when anything Scholar shows changed, or when the committed checkedAt is more than
        20 hours old (so the site's "checked" date stays within a day without a commit every 4 hours).
    npm run check:scholar          (node scripts/scholar-sync.mts --check)
        Checks the committed snapshot without the network. Every build runs it (prebuild).
    node scripts/scholar-sync.mts --from <page.html> [--checked-at <ISO time>]
        Parses a saved profile page instead of fetching one; --checked-at defaults to the file's modified time.
    npm run scholar -- --rematch
        Pairs the committed snapshot with publications.ts again, without the network: after a paper is removed,
        renamed, or added, or OVERRIDES changes. Scholar's figures and checkedAt stay as they are.

  Options:
    --report <file.md>   also writes the Scholar entries the site does not show as Markdown (the workflow's
                         issue), or removes the file when there are none
    --force              accepts a drop of more than 10% in total citations or in the article count (usually a
                         parse fault, or a namesake's papers leaving the profile), or a page older than the snapshot
    --snapshot <path>    the snapshot to check and write (default src/content/scholar.json)
  Through npm, options go after "--": npm run scholar -- --force.

  SerpApi fallback: when SERPAPI_API_KEY is set in the environment, one request goes to SerpApi's Google Scholar
  Author API if the page is refused, unparseable, or lists only part of the profile (the page shows 20
  articles; SerpApi, 100). The key is read from the environment only; neither it nor the request URL is printed.

  Politeness, as hard rules: one request to Google per run and no retries; an honest User-Agent, no proxies,
  no browser impersonation; never a CAPTCHA, and only the profile address itself (robots.txt allows
  /citations?user= and disallows /citations?*cstart=). When Google refuses, the run stops and the last snapshot stays.

  Exit status: 0 written or unchanged; 1 validation or parse failure (nothing written); 2 usage error;
  3 Scholar unavailable or blocked and no fallback succeeded (the last snapshot is kept).
*/

import { appendFileSync, existsSync, readFileSync, realpathSync, rmSync, statSync, writeFileSync } from "node:fs";
import { dirname, join, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { parseArgs } from "node:util";
import type { Person } from "../src/content/types.ts";
import { importTs, loadPublications } from "./enrich-publications.mts";
import {
  checkSnapshot,
  dayLabel,
  decodeHtml,
  detectBlock,
  fromSerpApi,
  IGNORED,
  isIsoSeconds,
  isoSeconds,
  matchArticles,
  needsWrite,
  oneLine,
  parseProfile,
  PROFILE_ID,
  profileUrl,
  REFRESH_HOURS,
  rematch,
  ScholarParseError,
  serializeSnapshot,
  shapeErrors,
  unlistedOf,
  unlistedReport,
  validate,
  type ParsedProfile,
  type PubRef,
  type ScholarSnapshot,
} from "./lib/scholar.mts";

const APP_DIR = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const DEFAULT_SNAPSHOT = join(APP_DIR, "src", "content", "scholar.json");
const PERSON_FILE = join(APP_DIR, "src", "content", "person.ts");

/** Names the site and what it is doing; no browser string. */
export const USER_AGENT = "madhavi-tripathi-site/0.2 (research website citation snapshot)";
const PROFILE_PAGE = "https://scholar.google.com/citations?user=";
const PAGE_TIMEOUT_MS = 20_000;
const SERPAPI_TIMEOUT_MS = 30_000;

const USAGE = `Usage:
  node scripts/scholar-sync.mts [--report <file.md>] [--force]     read Scholar, write the snapshot when it changed
  node scripts/scholar-sync.mts --check                            check the committed snapshot (no network)
  node scripts/scholar-sync.mts --rematch                          pair the snapshot with publications.ts again
  node scripts/scholar-sync.mts --from <page.html> [--checked-at <ISO time>] [--report <file.md>] [--force]
Options: --snapshot <scholar.json>. Through npm: npm run scholar -- <options>.
Exit status: 0 written or unchanged, 1 failed checks (nothing written), 2 usage, 3 Scholar blocked or
unavailable (the last snapshot is kept).`;

/* ------------------------------------------------------------------------------------------------
   Inputs
   ------------------------------------------------------------------------------------------------ */

export interface Owner {
  name: string;
  profileId: string;
}

async function loadOwner(): Promise<Owner> {
  const { person } = await importTs<{ person: Person }>(PERSON_FILE);
  const link = person?.links?.scholar ?? "";
  let profileId: string | null = null;
  try {
    profileId = new URL(link).searchParams.get("user");
  } catch {
    // reported below
  }
  if (!profileId || !PROFILE_ID.test(profileId)) throw new Error(`person.links.scholar ("${link}") has no Scholar user id`);
  return { name: person.name, profileId };
}

/** The snapshot on disk: its text, and the snapshot itself when it has the promised shape. */
interface Committed {
  raw?: string;
  snapshot?: ScholarSnapshot;
  problems: string[];
}

function readCommitted(path: string): Committed {
  if (!existsSync(path)) return { problems: ["missing: run `npm run scholar`"] };
  const raw = readFileSync(path, "utf8");
  let value: unknown;
  try {
    value = JSON.parse(raw);
  } catch (error) {
    return { raw, problems: [`not JSON (${messageOf(error)})`] };
  }
  const problems = shapeErrors(value);
  return problems.length ? { raw, problems } : { raw, snapshot: value as ScholarSnapshot, problems };
}

const messageOf = (error: unknown) => oneLine(error instanceof Error ? error.message : String(error));

const shown = (path: string) => {
  const rel = relative(process.cwd(), path);
  return rel && !rel.startsWith("..") ? rel : path;
};

/** A warning in the GitHub Actions run summary (a plain log line elsewhere is enough). */
function annotate(title: string, message: string): void {
  if (process.env.GITHUB_ACTIONS === "true") console.log(`::warning title=${title}::${oneLine(message).replace(/%/g, "%25")}`);
}

/* ------------------------------------------------------------------------------------------------
   Reading Scholar: one request, no retries
   ------------------------------------------------------------------------------------------------ */

export type Read =
  | { ok: true; parsed: ParsedProfile; source: ScholarSnapshot["source"] }
  | { ok: false; kind: "blocked" | "parse" | "fallback"; message: string };

export async function readProfilePage(url: string): Promise<Read> {
  if (!url.startsWith(PROFILE_PAGE) || /[?&]cstart=/i.test(url)) {
    throw new Error(`refusing ${url}: only the profile page itself may be read (robots.txt disallows the rest, and cstart= paging)`);
  }
  let response: Response;
  try {
    response = await fetch(url, {
      headers: { "User-Agent": USER_AGENT, "Accept-Language": "en", Accept: "text/html" },
      // A redirect is Google's answer (usually to /sorry/): report it rather than make a second request.
      redirect: "manual",
      signal: AbortSignal.timeout(PAGE_TIMEOUT_MS),
    });
  } catch (error) {
    return { ok: false, kind: "blocked", message: `no response from Google Scholar: ${messageOf(error)}` };
  }
  let html: string;
  try {
    html = decodeHtml(new Uint8Array(await response.arrayBuffer()), response.headers.get("content-type"));
  } catch (error) {
    return { ok: false, kind: "blocked", message: `the response could not be read: ${messageOf(error)}` };
  }
  const block = detectBlock(response.status, html, response.headers.get("location"));
  if (block) return { ok: false, kind: "blocked", message: block };
  return parsePage(html);
}

function parsePage(html: string): Read {
  try {
    return { ok: true, parsed: parseProfile(html), source: "profile-page" };
  } catch (error) {
    if (error instanceof ScholarParseError) return { ok: false, kind: "parse", message: messageOf(error) };
    throw error;
  }
}

export async function readSerpApi(authorId: string, key: string): Promise<Read> {
  const redact = (text: string) => text.split(key).join("[key]");
  const fail = (message: string): Read => ({ ok: false, kind: "fallback", message: redact(message) });
  const url = new URL("https://serpapi.com/search.json");
  url.search = new URLSearchParams({ engine: "google_scholar_author", author_id: authorId, hl: "en", num: "100", api_key: key }).toString();
  let response: Response;
  try {
    response = await fetch(url, {
      headers: { "User-Agent": USER_AGENT, Accept: "application/json" },
      signal: AbortSignal.timeout(SERPAPI_TIMEOUT_MS),
    });
  } catch (error) {
    return fail(`no response from SerpApi: ${messageOf(error)}`);
  }
  let body: unknown;
  try {
    body = await response.json();
  } catch {
    return fail(`SerpApi answered HTTP ${response.status} without JSON`);
  }
  if (!response.ok) {
    const detail = typeof body === "object" && body !== null && "error" in body ? `: ${oneLine(String(body.error))}` : "";
    return fail(`SerpApi answered HTTP ${response.status}${detail}`);
  }
  try {
    return { ok: true, parsed: fromSerpApi(body), source: "serpapi" };
  } catch (error) {
    return fail(messageOf(error));
  }
}

/* ------------------------------------------------------------------------------------------------
   Output
   ------------------------------------------------------------------------------------------------ */

function printSnapshot(s: ScholarSnapshot, label: string): void {
  const { totals, recent } = s;
  const lastYear = s.byYear[s.byYear.length - 1]?.year;
  console.log(`${label}: ${s.profile.name} (${s.profile.id}), from the ${s.source === "serpapi" ? "SerpApi fallback" : "profile page"}, ${s.checkedAt}`);
  console.log(
    `  Citations ${totals.citations}, h-index ${totals.hIndex}, i10-index ${totals.i10Index};` +
      ` since ${recent.since}: ${recent.citations}, ${recent.hIndex}, ${recent.i10Index}`,
  );
  if (s.byYear.length) {
    console.log(`  Per year: ${s.byYear.map((y) => `${y.year} ${y.citations}`).join(", ")} (${lastYear} so far)`);
  }
  const onSite = s.articles.filter((a) => a.pub).length;
  console.log(`  ${s.articles.length} articles on Scholar, ${onSite} of them on the site`);
}

function printChanges(previous: ScholarSnapshot | undefined, next: ScholarSnapshot): void {
  if (!previous) return;
  const lines: string[] = [];
  const delta = (label: string, a: number, b: number) => a !== b && lines.push(`${label} ${a} → ${b}`);
  delta("citations", previous.totals.citations, next.totals.citations);
  delta("h-index", previous.totals.hIndex, next.totals.hIndex);
  delta("i10-index", previous.totals.i10Index, next.totals.i10Index);
  const before = new Map(previous.articles.map((a) => [a.id, a]));
  const after = new Map(next.articles.map((a) => [a.id, a]));
  for (const article of next.articles) {
    const name = article.pub ?? `"${article.title}"`;
    const old = before.get(article.id);
    if (!old) {
      lines.push(`new on Scholar: ${name} (${article.year ?? "no year"}, cited by ${article.citedBy})`);
      continue;
    }
    if (old.citedBy !== article.citedBy) lines.push(`${name}: cited by ${old.citedBy} → ${article.citedBy}`);
    for (const field of ["title", "authors", "venue", "year", "pub"] as const) {
      if (old[field] !== article[field]) lines.push(`${name}: ${field} ${JSON.stringify(old[field])} → ${JSON.stringify(article[field])}`);
    }
  }
  for (const article of previous.articles) if (!after.has(article.id)) lines.push(`gone from Scholar: ${article.pub ?? `"${article.title}"`}`);
  console.log(lines.length ? `Changes since ${previous.checkedAt}:\n  ${lines.join("\n  ")}` : `No changes since ${previous.checkedAt}.`);
}

function printList(title: string, lines: string[], print: (text: string) => void = console.log): void {
  if (!lines.length) return;
  print(`${title}\n  ${lines.join("\n  ")}`);
}

function writeReport(path: string | undefined, snapshot: ScholarSnapshot | undefined): void {
  if (!path) return;
  const report = snapshot ? unlistedReport(snapshot) : null;
  if (report) {
    writeFileSync(path, report);
    console.log(`Wrote ${shown(path)}`);
  } else if (existsSync(path)) rmSync(path);
}

/** Step outputs for the workflow (GitHub Actions only), about the snapshot on disk after the run. */
function writeOutputs(result: string, snapshot: ScholarSnapshot | undefined, now: Date): void {
  if (!process.env.GITHUB_OUTPUT) return;
  const lines = [`result=${result}`];
  if (snapshot) {
    lines.push(
      `source=${snapshot.source}`,
      `citations=${snapshot.totals.citations}`,
      `checked_at=${snapshot.checkedAt}`,
      `checked_day=${dayLabel(snapshot.checkedAt)}`,
      `age_hours=${Math.max(0, Math.floor((now.getTime() - Date.parse(snapshot.checkedAt)) / 3_600_000))}`,
      `unlisted=${unlistedOf(snapshot).length}`,
    );
  }
  appendFileSync(process.env.GITHUB_OUTPUT, `${lines.join("\n")}\n`);
}

/* ------------------------------------------------------------------------------------------------
   Modes
   ------------------------------------------------------------------------------------------------ */

export function runCheck(snapshotPath: string, owner: Owner, publications: PubRef[]): number {
  const committed = readCommitted(snapshotPath);
  const snapshot = committed.snapshot;
  if (!snapshot) {
    console.error(`Google Scholar snapshot ${shown(snapshotPath)} fails its check:`);
    printList("Problems:", committed.problems, console.error);
    return 1;
  }
  const now = new Date();
  const { errors, warnings } = checkSnapshot(snapshot, { ...owner, publications, now });
  if (committed.raw !== serializeSnapshot(snapshot)) {
    warnings.push("the file is not laid out the way scholar-sync writes it (edited by hand?); the next sync rewrites it");
  }
  const days = Math.floor((now.getTime() - Date.parse(snapshot.checkedAt)) / 86_400_000);
  const onSite = snapshot.articles.filter((a) => a.pub).length;
  console.log(
    `Google Scholar snapshot ${shown(snapshotPath)}: ${snapshot.totals.citations} citations, h-index ${snapshot.totals.hIndex}; ` +
      `${snapshot.articles.length} articles, ${onSite} on the site; read ${dayLabel(snapshot.checkedAt)}` +
      ` (${days <= 0 ? "today" : `${days} day${days === 1 ? "" : "s"} ago`}) ${snapshot.source === "serpapi" ? "through SerpApi" : "from the profile page"}.`,
  );
  printList("Warnings:", warnings);
  if (errors.length) {
    printList("Problems:", errors, console.error);
    console.error(`${errors.length} problem(s) in ${shown(snapshotPath)}.`);
    return 1;
  }
  return 0;
}

/** `--rematch`: the committed snapshot paired with publications.ts again; Scholar's figures and checkedAt unchanged. */
export function runRematch(snapshotPath: string, publications: PubRef[]): number {
  const committed = readCommitted(snapshotPath);
  const snapshot = committed.snapshot;
  if (!snapshot) {
    console.error(`Google Scholar snapshot ${shown(snapshotPath)} can't be read:`);
    printList("Problems:", committed.problems, console.error);
    return 1;
  }
  const next = rematch(snapshot, publications);
  const text = serializeSnapshot(next);
  if (text === committed.raw) {
    console.log(`${shown(snapshotPath)}: every entry is already paired as publications.ts and OVERRIDES say; nothing to write.`);
    return 0;
  }
  writeFileSync(snapshotPath, text);
  const moves = snapshot.articles
    .map((a, i) => ({ a, pub: next.articles[i].pub }))
    .filter(({ a, pub }) => a.pub !== pub)
    .map(({ a, pub }) => `"${a.title}": ${a.pub ?? "not on the site"} → ${pub ?? "not on the site"}`);
  console.log(`Paired again and written: ${shown(snapshotPath)} (Scholar's figures and checkedAt ${snapshot.checkedAt} unchanged).`);
  printList(`Changed pairings (${moves.length}):`, moves);
  return 0;
}

export interface SyncOptions {
  snapshotPath: string;
  from?: string;
  checkedAt?: string;
  report?: string;
  force: boolean;
}

export async function runSync(options: SyncOptions, owner: Owner, publications: PubRef[]): Promise<number> {
  const now = new Date();
  const committed = readCommitted(options.snapshotPath);
  const previous = committed.snapshot;
  if (!previous && committed.raw !== undefined) {
    console.log(`Note: the committed snapshot is unusable (${committed.problems.join("; ")}); a successful read replaces it.`);
  }

  let read: Read;
  let checkedAt = isoSeconds(now);
  if (options.from) {
    checkedAt = options.checkedAt ?? isoSeconds(statSync(options.from).mtime);
    console.log(`Parsing ${shown(options.from)} (a saved page, read at ${checkedAt}).`);
    const html = decodeHtml(new Uint8Array(readFileSync(options.from)));
    const block = detectBlock(200, html);
    read = block ? { ok: false, kind: "parse", message: block } : parsePage(html);
    if (!read.ok) console.log(`The page could not be used: ${read.message}`);
  } else {
    const url = profileUrl(owner.profileId);
    console.log(`Reading ${url} (one request; User-Agent "${USER_AGENT}").`);
    read = await readProfilePage(url);
    if (!read.ok) {
      console.log(`${read.kind === "parse" ? "The page could not be parsed" : "Google Scholar refused or failed"}: ${read.message}`);
    } else if (!read.parsed.complete) {
      console.log(`The page lists ${read.parsed.articles.length} articles, and Scholar has more.`);
    }
    const key = process.env.SERPAPI_API_KEY?.trim();
    const wanted = !read.ok || !read.parsed.complete;
    if (wanted && key) {
      console.log("Trying SerpApi's Google Scholar Author API (SERPAPI_API_KEY is set).");
      const fallback = await readSerpApi(owner.profileId, key);
      if (fallback.ok) {
        if (!read.ok && read.kind === "parse") {
          console.log(`Used SerpApi; the page parser needs attention (${read.message}).`);
          annotate("Scholar page parser needs attention", `The profile page could not be parsed (${read.message}); SerpApi covered this run.`);
        }
        read = fallback;
      } else console.log(`SerpApi failed too: ${fallback.message}`);
    } else if (!read.ok) console.log("No SERPAPI_API_KEY in the environment, so no fallback (docs/scholar-sync.md).");
  }

  if (!read.ok) {
    writeReport(options.report, previous);
    // A page that was the profile but didn't parse needs a code fix (1); a refusal just needs time or SerpApi (3).
    const parseFault = read.kind === "parse";
    writeOutputs(parseFault ? "failed" : "blocked", previous, now);
    console.log(`Nothing written; ${previous ? `the snapshot from ${previous.checkedAt} stays` : "there is no snapshot yet"}.`);
    return parseFault ? 1 : 3;
  }

  const matched = matchArticles(read.parsed.articles, publications);
  const next: ScholarSnapshot = {
    schema: 1,
    profile: read.parsed.profile,
    source: read.source,
    checkedAt,
    totals: read.parsed.totals,
    recent: read.parsed.recent,
    byYear: read.parsed.byYear,
    articles: matched.articles,
  };
  printSnapshot(next, "Google Scholar");
  printChanges(previous, next);
  const unlisted = unlistedOf(next);
  printList(`Scholar entries the site does not show (${unlisted.length}):`, unlisted.map((a) => `${a.id}  ${a.year ?? "----"}  ${a.title}`));
  printList(
    "Left off the site on purpose (IGNORED):",
    next.articles.filter((a) => a.pub === null && Object.hasOwn(IGNORED, a.id)).map((a) => `${a.id}  ${a.title}: ${IGNORED[a.id]}`),
  );
  printList(`Site papers not found on Scholar (${matched.missing.length}):`, matched.missing);
  printList("Matching notes:", matched.notes);

  const incomplete = !read.parsed.complete;
  const { errors, warnings } = validate(next, previous, {
    profileId: owner.profileId,
    name: owner.name,
    force: options.force,
    incomplete,
    now,
  });
  if (incomplete) {
    const message =
      `Scholar has more articles than this read lists (${next.articles.length}); the others are missing from the snapshot. ` +
      "A SERPAPI_API_KEY lists up to 100 (docs/scholar-sync.md).";
    warnings.push(message);
    annotate("Scholar profile read in part", message);
  }
  printList("Warnings:", warnings);
  if (errors.length) {
    printList("Refused (nothing written):", errors);
    writeReport(options.report, previous);
    writeOutputs("failed", previous, now);
    return 1;
  }

  const reason = needsWrite(previous, next);
  const current = reason ? next : previous;
  if (reason) {
    writeFileSync(options.snapshotPath, serializeSnapshot(next));
    const why = { new: "first snapshot", changed: "Scholar's data changed", refresh: `unchanged, but the last write was over ${REFRESH_HOURS} hours ago` }[reason];
    console.log(`Snapshot written: ${shown(options.snapshotPath)} (${why}).`);
  } else {
    console.log(
      `Snapshot unchanged: ${shown(options.snapshotPath)} keeps checkedAt ${previous?.checkedAt}; ` +
        `it is rewritten once that is over ${REFRESH_HOURS} hours old.`,
    );
  }
  writeReport(options.report, current);
  writeOutputs(reason ? "written" : "unchanged", current, now);
  return 0;
}

/* ------------------------------------------------------------------------------------------------
   Main
   ------------------------------------------------------------------------------------------------ */

async function main(): Promise<number> {
  let values: {
    check?: boolean;
    rematch?: boolean;
    from?: string;
    "checked-at"?: string;
    report?: string;
    force?: boolean;
    snapshot?: string;
    help?: boolean;
  };
  try {
    ({ values } = parseArgs({
      options: {
        check: { type: "boolean" },
        rematch: { type: "boolean" },
        from: { type: "string" },
        "checked-at": { type: "string" },
        report: { type: "string" },
        force: { type: "boolean" },
        snapshot: { type: "string" },
        help: { type: "boolean", short: "h" },
      },
    }));
  } catch (error) {
    console.error(`${messageOf(error)}\n\n${USAGE}`);
    return 2;
  }
  if (values.help) {
    console.log(USAGE);
    return 0;
  }
  const usage = (message: string) => {
    console.error(`${message}\n\n${USAGE}`);
    return 2;
  };
  const offline = values.check ? "--check" : values.rematch ? "--rematch" : null;
  if (values.check && values.rematch) return usage("--check and --rematch are separate runs.");
  if (offline && (values.from || values.report || values.force || values["checked-at"])) {
    return usage(`${offline} takes no other option but --snapshot.`);
  }
  if (values["checked-at"] && !values.from) return usage("--checked-at goes with --from.");
  if (values["checked-at"] && !isIsoSeconds(values["checked-at"])) {
    return usage(`--checked-at must be an ISO 8601 UTC time such as 2026-09-28T10:14:54Z, not "${values["checked-at"]}".`);
  }
  if (values.from && !(existsSync(values.from) && statSync(values.from).isFile())) return usage(`Not a file: ${values.from}`);

  const publications: PubRef[] = (await loadPublications()).map(({ id, title, year }) => ({ id, title, year }));
  const snapshotPath = resolve(values.snapshot ?? DEFAULT_SNAPSHOT);
  if (values.rematch) return runRematch(snapshotPath, publications);
  const owner = await loadOwner();
  if (values.check) return runCheck(snapshotPath, owner, publications);
  return runSync(
    {
      snapshotPath,
      from: values.from ? resolve(values.from) : undefined,
      checkedAt: values["checked-at"],
      report: values.report ? resolve(values.report) : undefined,
      force: values.force ?? false,
    },
    owner,
    publications,
  );
}

const invokedDirectly = (() => {
  try {
    return !!process.argv[1] && realpathSync(process.argv[1]) === realpathSync(fileURLToPath(import.meta.url));
  } catch {
    return false;
  }
})();

if (invokedDirectly) {
  try {
    process.exitCode = await main();
  } catch (error) {
    console.error(`scholar-sync: ${messageOf(error)}`);
    process.exitCode = 1;
  }
}
