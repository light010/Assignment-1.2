/*
  The built-site gate. Runs after every build (npm run build → postbuild) and reads out/ the way a host,
  a crawler, and a link preview would:
  - every file the site promises exists: the page, the 404, sitemap, robots, manifest, icons, BibTeX,
    share image, and the host's _headers and _redirects
  - no builder leftovers or placeholders in any page or text file
  - the page's metadata: one title and description within budget, an absolute canonical that matches
    og:url, a share image that exists, and structured data that parses with every @id resolving
  - every in-page link lands on an id, ids are unique, images have alt text, new tabs are safe
  - every character on the page is in the site's own fonts, so none falls back to a system font
  - canonical URLs don't point at localhost in a deploy build (CI, Cloudflare)
  Usage: node scripts/check-built.mts [out]
*/
import fs from "node:fs";
import path from "node:path";
import { publications } from "../src/content/publications.ts";
import { SITE_URL } from "../src/content/site.ts";
import { forbiddenIn } from "./lib/forbidden.mts";
import { readWoff2, type FontInfo } from "./lib/fonts.mts";

const OUT = path.resolve(process.argv[2] ?? "out");
const problems: string[] = [];
const notes: string[] = [];
const fail = (where: string, message: string) => problems.push(`${where}: ${message}`);
const read = (rel: string) => fs.readFileSync(path.join(OUT, rel), "utf8");
const exists = (rel: string) => fs.existsSync(path.join(OUT, rel));

if (!fs.existsSync(OUT)) {
  console.error(`✗ ${OUT} doesn't exist; run npm run build first.`);
  process.exit(1);
}

// ── Files ────────────────────────────────────────────────────────────────────────────────────────
const REQUIRED = [
  "index.html",
  "404.html",
  "sitemap.xml",
  "robots.txt",
  "manifest.webmanifest",
  "publications.bib",
  "icon.svg",
  "_headers",
  "_redirects",
];
const PENDING = ["apple-icon.png", "opengraph-image.jpg"]; // made by the stills pipeline
for (const f of REQUIRED) if (!exists(f)) fail(f, "missing from the build");
for (const f of PENDING) if (!exists(f)) notes.push(`${f} isn't in the build yet (scripts/build-og.mts and the stills pipeline make it).`);

function walk(dir: string): string[] {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
    const p = path.join(dir, e.name);
    return e.isDirectory() ? walk(p) : [p];
  });
}
const files = walk(OUT).map((f) => path.relative(OUT, f).split(path.sep).join("/"));
const textFiles = files.filter((f) => /\.(html|txt|xml|bib|webmanifest|json)$/.test(f) || f === "_headers" || f === "_redirects");

// ── Forbidden text, everywhere a visitor or crawler can read ─────────────────────────────────────
for (const f of textFiles) {
  const text = read(f);
  for (const hit of forbiddenIn(text)) fail(f, `forbidden text ${hit}`);
}
const deploying = Boolean(process.env.CI || process.env.WORKERS_CI || process.env.CF_PAGES);
if (/localhost|127\.0\.0\.1/.test(SITE_URL)) {
  if (deploying) fail("NEXT_PUBLIC_SITE_URL", `canonical URLs point at ${SITE_URL}; set the production address`);
  else notes.push(`Canonical and share URLs point at ${SITE_URL}. Set NEXT_PUBLIC_SITE_URL before a deploy build.`);
}

// ── HTML helpers (the export is our own markup, so attribute-level parsing is enough) ────────────
const decode = (s: string) =>
  s
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#x27;|&#39;/g, "'")
    .replace(/&nbsp;/g, " ")
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(Number(d)))
    .replace(/&amp;/g, "&");
const attrs = (tag: string) =>
  Object.fromEntries([...tag.matchAll(/([\w:-]+)(?:="([^"]*)")?/g)].slice(1).map((m) => [m[1].toLowerCase(), decode(m[2] ?? "")]));
const tags = (html: string, name: string) => [...html.matchAll(new RegExp(`<${name}\\b[^>]*>`, "gi"))].map((m) => attrs(m[0]));
const meta = (html: string, key: string) => tags(html, "meta").filter((m) => m.name === key || m.property === key).map((m) => m.content);
const withoutScripts = (html: string) => html.replace(/<script\b[\s\S]*?<\/script>/gi, "").replace(/<style\b[\s\S]*?<\/style>/gi, "");
const visibleText = (html: string) =>
  decode(
    withoutScripts(html)
      .replace(/<(title|template|noscript)\b[\s\S]*?<\/\1>/gi, " ")
      .replace(/<[^>]+>/g, " "),
  );

function checkPage(file: string, opts: { indexable: boolean }) {
  const html = read(file);
  const body = withoutScripts(html);
  const titles = [...html.matchAll(/<title>([\s\S]*?)<\/title>/g)].map((m) => decode(m[1]));
  if (titles.length !== 1) fail(file, `${titles.length} <title> elements`);
  else if (titles[0].length > 60) fail(file, `title is ${titles[0].length} characters (budget 60): "${titles[0]}"`);
  const descriptions = meta(html, "description");
  if (descriptions.length !== 1) fail(file, `${descriptions.length} meta descriptions`);
  else if (descriptions[0].length > 155) fail(file, `description is ${descriptions[0].length} characters (budget 155)`);
  if (!/<html[^>]*\slang="en"/.test(html)) fail(file, 'the <html> element needs lang="en"');
  const h1 = (body.match(/<h1\b/g) ?? []).length;
  if (h1 !== 1) fail(file, `${h1} <h1> elements; expected 1`);
  const robots = meta(html, "robots").join(",");
  if (opts.indexable && /noindex/.test(robots)) fail(file, "is marked noindex");
  if (!opts.indexable && !/noindex/.test(robots)) fail(file, "should be noindex");

  // ids and links
  const ids = [...body.matchAll(/\sid="([^"]+)"/g)].map((m) => decode(m[1]));
  const idSet = new Set(ids);
  for (const id of ids.filter((id, i) => ids.indexOf(id) !== i)) fail(file, `id "${id}" is used more than once`);
  for (const a of tags(body, "a")) {
    const href = a.href;
    if (href === undefined) continue;
    if (href.startsWith("#")) {
      if (href.length > 1 && !idSet.has(href.slice(1))) fail(file, `link ${href} has no target on the page`);
    } else if (href.startsWith("/")) {
      const url = new URL(href, "https://example.org");
      const target = url.pathname === "/" ? "index.html" : url.pathname.replace(/^\//, "");
      const found = [target, `${target}.html`, `${target}/index.html`].some(exists);
      if (!found) fail(file, `link ${href} points at a page that isn't in the build`);
      else if (url.hash && url.pathname === "/" && !idsOfIndex().has(url.hash.slice(1))) fail(file, `link ${href} has no target`);
    } else if (href.startsWith("http://")) fail(file, `link ${href} must use https`);
    if (a.target === "_blank" && !/noopener|noreferrer/.test(a.rel ?? "")) fail(file, `link ${href} opens a new tab without rel="noopener"`);
  }
  for (const img of tags(body, "img")) if (img.alt === undefined) fail(file, `image ${img.src} has no alt attribute`);
  for (const text of [visibleText(html)]) {
    if (/[→↗]/.test(text)) fail(file, "an arrow character on the page (the fonts don't have it, and the style guide bans it)");
    if (/(?![\u00a9\u00ae\u2122])\p{Extended_Pictographic}/u.test(text)) fail(file, "an emoji on the page");
  }
  return { html, ids: idSet };
}

let indexIds: Set<string> | undefined;
function idsOfIndex() {
  indexIds ??= new Set([...withoutScripts(read("index.html")).matchAll(/\sid="([^"]+)"/g)].map((m) => decode(m[1])));
  return indexIds;
}

// ── The page ─────────────────────────────────────────────────────────────────────────────────────
if (exists("index.html")) {
  const { html, ids } = checkPage("index.html", { indexable: true });
  const canonical = tags(html, "link").find((l) => l.rel === "canonical")?.href;
  if (!canonical) fail("index.html", "no canonical link");
  else {
    if (canonical !== `${SITE_URL}/` && canonical !== SITE_URL) fail("index.html", `canonical is ${canonical}, expected ${SITE_URL}/`);
    const ogUrl = meta(html, "og:url")[0];
    if (ogUrl !== canonical) fail("index.html", `og:url (${ogUrl}) differs from the canonical (${canonical})`);
  }
  for (const key of ["og:title", "og:description", "og:type", "og:site_name", "twitter:card"])
    if (meta(html, key).length === 0) fail("index.html", `no ${key}`);
  if (meta(html, "og:type")[0] !== "profile") fail("index.html", "og:type should be profile");
  const ogImage = meta(html, "og:image")[0];
  if (ogImage) {
    const rel = ogImage.replace(SITE_URL, "").replace(/^\//, "").split("?")[0];
    if (!exists(rel)) fail("index.html", `og:image ${ogImage} isn't in the build`);
    for (const key of ["og:image:width", "og:image:height", "og:image:alt", "og:image:type"])
      if (meta(html, key).length === 0) fail("index.html", `the share image has no ${key}`);
  } else notes.push("No og:image yet: link previews will show no picture until opengraph-image.jpg lands.");

  // Every paper and lab chapter has its stable anchor.
  for (const p of publications) if (!ids.has(`pub-${p.id}`)) fail("index.html", `no #pub-${p.id} anchor`);
  for (const id of ["top", "main", "recognition", "research", "publications", "about", "contact", "lab-design", "lab-delivery", "lab-photoacoustics", "lab-ultrasound"])
    if (!ids.has(id)) fail("index.html", `no #${id}`);
  const skip = withoutScripts(html).match(/<body[^>]*>\s*(?:<[^a][^>]*>\s*)*<a\b[^>]*>/);
  if (!skip || !/href="#recognition"/.test(skip[0])) fail("index.html", '"Skip the lab" must be the first link in the body and land after the lab');

  // Structured data: parses, and every reference resolves inside the graph.
  const ld = [...html.matchAll(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/g)];
  if (ld.length !== 1) fail("index.html", `${ld.length} JSON-LD blocks; expected 1`);
  else {
    try {
      const data = JSON.parse(ld[0][1]);
      const graph: Record<string, unknown>[] = data["@graph"] ?? [];
      if (data["@context"] !== "https://schema.org" || graph.length === 0) fail("index.html", "JSON-LD needs a schema.org @context and an @graph");
      const nodeIds = new Set(graph.map((n) => n["@id"] as string));
      const refs: string[] = [];
      const collect = (v: unknown, top: boolean) => {
        if (Array.isArray(v)) v.forEach((x) => collect(x, false));
        else if (v && typeof v === "object") {
          const o = v as Record<string, unknown>;
          if (!top && Object.keys(o).length === 1 && typeof o["@id"] === "string") refs.push(o["@id"]);
          for (const [k, x] of Object.entries(o)) if (k !== "@id") collect(x, false);
        }
      };
      graph.forEach((n) => collect(n, true));
      for (const r of refs) if (!nodeIds.has(r)) fail("index.html", `JSON-LD reference ${r} doesn't resolve`);
      for (const n of graph) if (!n["@type"]) fail("index.html", `JSON-LD node ${n["@id"]} has no @type`);
      if (/@[a-z0-9-]+\.[a-z]{2,}/i.test(JSON.stringify(data).replace(/"https?:[^"]*"/g, ""))) fail("index.html", "JSON-LD contains an email address");
      const scholarly = graph.filter((n) => ["ScholarlyArticle", "Chapter", "Thesis"].includes(n["@type"] as string)).length;
      if (scholarly !== publications.length) fail("index.html", `JSON-LD lists ${scholarly} works; the page has ${publications.length}`);
    } catch (e) {
      fail("index.html", `JSON-LD doesn't parse: ${(e as Error).message}`);
    }
  }
}
if (exists("404.html")) {
  const { html } = checkPage("404.html", { indexable: false });
  if (!/<title>Page not found · /.test(html)) fail("404.html", 'title should start "Page not found · "');
}

// ── Machine-readable files ───────────────────────────────────────────────────────────────────────
if (exists("sitemap.xml")) {
  const xml = read("sitemap.xml");
  if (!xml.includes(`<loc>${SITE_URL}/</loc>`)) fail("sitemap.xml", `doesn't list ${SITE_URL}/`);
  if (!/<lastmod>/.test(xml)) fail("sitemap.xml", "has no lastmod");
}
if (exists("robots.txt")) {
  const txt = read("robots.txt");
  if (!txt.includes(`Sitemap: ${SITE_URL}/sitemap.xml`)) fail("robots.txt", "doesn't name the sitemap");
  if (/^Host:/im.test(txt)) fail("robots.txt", "has a non-standard Host line");
  if (/Disallow: \/\s*$/m.test(txt)) fail("robots.txt", "blocks the whole site");
}
if (exists("manifest.webmanifest")) {
  try {
    const m = JSON.parse(read("manifest.webmanifest"));
    for (const icon of m.icons ?? []) if (!exists(icon.src.replace(/^\//, ""))) notes.push(`manifest icon ${icon.src} isn't in the build yet.`);
  } catch {
    fail("manifest.webmanifest", "isn't valid JSON");
  }
}
if (exists("publications.bib")) {
  const bib = read("publications.bib");
  const keys = [...bib.matchAll(/^@\w+\{([^,]+),/gm)].map((m) => m[1]);
  if (keys.length !== publications.length) fail("publications.bib", `${keys.length} entries; expected ${publications.length}`);
  if (new Set(keys).size !== keys.length) fail("publications.bib", "duplicate citation keys");
  let depth = 0;
  for (const ch of bib.replace(/\\[{}]/g, "")) {
    depth += ch === "{" ? 1 : ch === "}" ? -1 : 0;
    if (depth < 0) break;
  }
  if (depth !== 0) fail("publications.bib", "unbalanced braces");
}
if (exists("_headers")) {
  const h = read("_headers");
  for (const header of ["Content-Security-Policy", "Strict-Transport-Security", "X-Content-Type-Options", "Referrer-Policy"])
    if (!h.includes(`${header}:`)) fail("_headers", `no ${header}`);
  if (!/\/_next\/static\/\*\s*\n\s+Cache-Control: public, max-age=31536000, immutable/.test(h)) fail("_headers", "static assets aren't cached as immutable");
}
if (exists("_redirects")) {
  for (const line of read("_redirects").split("\n")) {
    const rule = line.trim();
    if (!rule || rule.startsWith("#")) continue;
    const [from, to, status] = rule.split(/\s+/);
    if (!from?.startsWith("/") || !to) fail("_redirects", `malformed rule "${rule}"`);
    else if (to.startsWith("/") && !exists(to.slice(1).split(/[?#]/)[0])) fail("_redirects", `${from} redirects to ${to}, which isn't in the build`);
    if (status && !["301", "302", "303", "307", "308"].includes(status)) fail("_redirects", `status ${status} isn't a redirect`);
  }
}

// ── Every character on the pages is in the site's fonts ──────────────────────────────────────────
const fontFiles = files.filter((f) => f.endsWith(".woff2"));
const fonts: FontInfo[] = fontFiles.map((f) => readWoff2(fs.readFileSync(path.join(OUT, f))));
const families = {
  "Newsreader": fonts.filter((f) => f.family.startsWith("Newsreader") && !f.italic),
  "Newsreader italic": fonts.filter((f) => f.family.startsWith("Newsreader") && f.italic),
  "Mona Sans": fonts.filter((f) => f.family.startsWith("Mona Sans")),
};
for (const [name, list] of Object.entries(families)) if (list.length === 0) fail("fonts", `no ${name} files in the build`);
// Default-ignorable characters (word joiners, soft hyphens) never render, so they need no glyph.
const IGNORABLE = /[\s­͏؜ᅟᅠ឴឵᠋-᠏​-‏‪-‮⁠-⁯︀-️﻿]/u;
const pageText = ["index.html", "404.html"].filter(exists).map((f) => visibleText(read(f))).join(" ");
const chars = [...new Set(pageText)].filter((c) => !IGNORABLE.test(c));
const missing: string[] = [];
for (const c of chars) {
  const cp = c.codePointAt(0)!;
  const lacking = (["Newsreader", "Mona Sans"] as const).filter((name) => !families[name].some((f) => f.has(cp)));
  if (lacking.length) missing.push(`"${c}" U+${cp.toString(16).toUpperCase().padStart(4, "0")} (${lacking.join(", ")})`);
}
if (missing.length) fail("fonts", `characters on the page that the fonts don't have: ${missing.join("; ")}`);
const nameChars = [...new Set("Madhavi Tripathi")].filter((c) => c !== " ");
for (const c of nameChars) if (!families["Newsreader italic"].some((f) => f.has(c.codePointAt(0)!))) fail("fonts", `the italic lacks "${c}"`);

// ── Report ───────────────────────────────────────────────────────────────────────────────────────
console.log("Build check");
console.log(`  ${files.length} files in ${path.relative(process.cwd(), OUT) || "."}; ${chars.length} distinct characters checked against ${fontFiles.length} font files`);
for (const n of notes) console.log(`  Note: ${n}`);
if (problems.length) {
  console.error(`\n✗ ${problems.length} problem${problems.length === 1 ? "" : "s"}:\n${problems.map((p) => `  - ${p}`).join("\n")}`);
  process.exit(1);
}
console.log("✓ The build is complete and consistent.");
