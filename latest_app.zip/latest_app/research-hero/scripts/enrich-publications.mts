/*
  Publications: Crossref enrichment and verification, and the ORCID watch.

    npm run enrich
        Fetches every DOI in src/content/publications.ts from Crossref, writes the committed snapshot
        src/content/publications.crossref.json (sorted and stable, so diffs are reviewable), then checks
        every curated record against it.
    node scripts/enrich-publications.mts --offline
        The same checks against the committed snapshot, without the network (CI).
    node scripts/enrich-publications.mts --orcid [--orcid-id 0000-0002-4736-9134] [--report missing.md]
        Lists DOIs on the ORCID record that the site does not show (the weekly workflow opens an issue).

  Checks per record (a failure exits 1):
    title    equal after ignoring case, punctuation, dashes, markup, and diacritics
             (curated titles use sentence case on purpose; Crossref often uses Title Case)
    year     equal to the year Crossref gives as first published (print or online, whichever is earlier)
    authors  same count, and the same names in the same order after folding diacritics and initials
    Tripathi the curated `me` author is a Tripathi in Crossref at the same position, and, where Crossref
             carries an ORCID for her, it is the owner's (other researchers publish as "Madhavi Tripathi")
    license  a "CC BY 4.0" claim is backed by a Creative Commons BY 4.0 license in Crossref
  Venue, volume, issue, pages, and type are compared for information only.

  Options: --file <publications.ts> and --snapshot <json> point at copies (for tests).
  Exit status: 0 when every check passes, 1 on a mismatch or a fetch failure, 2 on a usage error.
  Builds never run this: they read the committed snapshot, so they stay reproducible and offline.
*/

import { appendFileSync, existsSync, readFileSync, realpathSync, rmSync, writeFileSync } from "node:fs";
import * as nodeModule from "node:module";
import { dirname, join, relative, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { parseArgs } from "node:util";
import type { Publication } from "../src/content/types.ts";

export const APP_DIR = resolve(dirname(fileURLToPath(import.meta.url)), "..");
export const DEFAULT_PUBLICATIONS = join(APP_DIR, "src", "content", "publications.ts");
export const DEFAULT_SNAPSHOT = join(APP_DIR, "src", "content", "publications.crossref.json");
const PERSON_FILE = join(APP_DIR, "src", "content", "person.ts");

/** Names the site and never a person: no email (Crossref's public pool does not need one). */
export const USER_AGENT = "madhavi-tripathi-site/1.0 (+https://github.com/)";
/** Used only if src/content/person.ts cannot be read. */
const OWNER_ORCID_FALLBACK = "0000-0002-4736-9134";

/**
  Reviewed differences that should not fail the check, by DOI and field, with the reason.
  Empty today: every curated record matches Crossref. Prefer fixing the record to adding a line here.
*/
const ACCEPTED: Record<string, Partial<Record<"title" | "year" | "authors", string>>> = {};

/* ------------------------------------------------------------------------------------------------
   Loading the TypeScript content modules with Node's type stripping
   ------------------------------------------------------------------------------------------------ */

type NextResolve = (specifier: string, context: unknown) => unknown;
type ResolveHook = (specifier: string, context: unknown, nextResolve: NextResolve) => unknown;

let hooksInstalled = false;

/**
  Lets Node load the content modules the way the bundler does: the "@/" alias maps to src/, and
  extensionless relative imports find their .ts file. publications.ts only has type imports today
  (erased by type stripping), so this is a safety net for value imports added later.
*/
function installResolveHooks(): void {
  if (hooksInstalled) return;
  hooksInstalled = true;
  const registerHooks = (nodeModule as unknown as { registerHooks?: (hooks: { resolve: ResolveHook }) => unknown })
    .registerHooks;
  registerHooks?.({
    resolve(specifier, context, nextResolve) {
      const target = specifier.startsWith("@/") ? pathToFileURL(join(APP_DIR, "src", specifier.slice(2))).href : specifier;
      try {
        return nextResolve(target, context);
      } catch (error) {
        if (/^(\.{1,2}\/|\/|file:)/.test(target) && !/\.[cm]?[jt]sx?$/.test(target)) {
          for (const suffix of [".ts", "/index.ts"]) {
            try {
              return nextResolve(target + suffix, context);
            } catch {
              // try the next suffix
            }
          }
        }
        throw error;
      }
    },
  });
}

/** Imports a .ts module by path; `fresh` bypasses the module cache (add-paper re-reads the file it edited). */
export async function importTs<T>(file: string, fresh = false): Promise<T> {
  installResolveHooks();
  return (await import(pathToFileURL(file).href + (fresh ? `?v=${Date.now()}` : ""))) as T;
}

export async function loadPublications(file = DEFAULT_PUBLICATIONS): Promise<Publication[]> {
  const mod = await importTs<{ publications?: unknown }>(file, true);
  if (!Array.isArray(mod.publications)) throw new Error(`${file} does not export a "publications" array.`);
  return mod.publications as Publication[];
}

/** The owner's ORCID iD, from src/content/person.ts. */
export async function ownerOrcid(): Promise<string> {
  try {
    const mod = await importTs<{ person?: { links?: { orcid?: { value?: unknown } } } }>(PERSON_FILE);
    const value = mod.person?.links?.orcid?.value;
    if (typeof value === "string" && ORCID_ID.test(value)) return value;
  } catch {
    // fall through to the constant
  }
  console.warn(`Note: could not read the ORCID iD from ${relative(process.cwd(), PERSON_FILE)}; using ${OWNER_ORCID_FALLBACK}.`);
  return OWNER_ORCID_FALLBACK;
}

/* ------------------------------------------------------------------------------------------------
   Text: markup, entities, and the normalized forms used for comparison
   ------------------------------------------------------------------------------------------------ */

const ENTITIES: Record<string, string> = {
  amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: "\u00a0", thinsp: "\u2009", ensp: "\u2002", emsp: "\u2003",
  ndash: "–", mdash: "—", minus: "−", hyphen: "‐", hellip: "…", middot: "·", bull: "•",
  lsquo: "‘", rsquo: "’", sbquo: "‚", ldquo: "“", rdquo: "”", bdquo: "„", laquo: "«", raquo: "»", prime: "′", Prime: "″",
  times: "×", divide: "÷", plusmn: "±", deg: "°", micro: "µ", le: "≤", ge: "≥", ne: "≠", asymp: "≈", infin: "∞",
  rarr: "→", larr: "←", harr: "↔", trade: "™", reg: "®", copy: "©", sect: "§", para: "¶",
  alpha: "α", beta: "β", gamma: "γ", delta: "δ", epsilon: "ε", zeta: "ζ", eta: "η", theta: "θ", iota: "ι", kappa: "κ",
  lambda: "λ", mu: "μ", nu: "ν", xi: "ξ", pi: "π", rho: "ρ", sigma: "σ", tau: "τ", phi: "φ", chi: "χ", psi: "ψ", omega: "ω",
  Gamma: "Γ", Delta: "Δ", Theta: "Θ", Lambda: "Λ", Pi: "Π", Sigma: "Σ", Phi: "Φ", Psi: "Ψ", Omega: "Ω",
  aacute: "á", agrave: "à", acirc: "â", atilde: "ã", auml: "ä", aring: "å", ccedil: "ç", eacute: "é", egrave: "è",
  ecirc: "ê", euml: "ë", iacute: "í", igrave: "ì", icirc: "î", iuml: "ï", ntilde: "ñ", oacute: "ó", ograve: "ò",
  ocirc: "ô", otilde: "õ", ouml: "ö", oslash: "ø", uacute: "ú", ugrave: "ù", ucirc: "û", uuml: "ü", yacute: "ý",
  szlig: "ß", Aacute: "Á", Agrave: "À", Auml: "Ä", Ccedil: "Ç", Eacute: "É", Iacute: "Í", Ntilde: "Ñ", Oacute: "Ó",
  Ouml: "Ö", Oslash: "Ø", Uacute: "Ú", Uuml: "Ü",
};

/** An HTML, JATS, or MathML tag: "<" must be followed by a letter, so "<5 mm" survives. */
const TAG = /<\/?[A-Za-z][\w.:-]*(?:\s[^<>]*)?\/?>/g;
const ENTITY = /&(#[xX][0-9a-fA-F]+|#[0-9]+|[A-Za-z][A-Za-z0-9]*);/g;
const COMBINING_MARKS = new RegExp("\\p{M}+", "gu");
const NOT_LETTER_OR_DIGIT = new RegExp("[^\\p{L}\\p{N}]+", "gu");

function decodeEntities(value: string): string {
  return value.replace(ENTITY, (whole, body: string) => {
    if (body.startsWith("#")) {
      const hex = body[1] === "x" || body[1] === "X";
      const codePoint = Number.parseInt(body.slice(hex ? 2 : 1), hex ? 16 : 10);
      return codePoint > 0 && codePoint <= 0x10ffff ? String.fromCodePoint(codePoint) : whole;
    }
    return ENTITIES[body] ?? whole;
  });
}

/** Crossref text as a reader sees it: tags stripped (<scp>DNA</scp> → DNA), entities decoded (&amp; → &). */
export function cleanText(raw: string): string {
  let value = raw.replace(TAG, "");
  // Some deposits double-encode (&amp;lt;scp&amp;gt;): decode, strip what that reveals, and repeat.
  for (let pass = 0; pass < 3; pass++) {
    const next = decodeEntities(value).replace(TAG, "");
    if (next === value) break;
    value = next;
  }
  return value.replace(/\s+/g, " ").trim();
}

/** Lower case, diacritics removed ("José Timaná" → "jose timana"). */
export function fold(value: string): string {
  return value.normalize("NFKD").replace(COMBINING_MARKS, "").toLowerCase();
}

/** Comparison key for titles and venues: letters and digits only. */
export function titleKey(value: string): string {
  return fold(cleanText(value)).replace(NOT_LETTER_OR_DIGIT, "");
}

/** Name tokens: periods, spaces, hyphens, and dashes separate; apostrophes and diacritics fold away. */
function nameTokens(value: string, splitCapitalInitials = false): string[] {
  return cleanText(value)
    .split(/[\s.\u2010-\u2015-]+/)
    .flatMap((token) => (splitCapitalInitials && /^[A-Z]{2,3}$/.test(token) ? token.split("") : [token]))
    .map((token) => fold(token).replace(NOT_LETTER_OR_DIGIT, ""))
    .filter(Boolean);
}

const ORCID_ID = /^\d{4}-\d{4}-\d{4}-\d{3}[\dX]$/;

export function normalizeOrcid(value: string | undefined | null): string | undefined {
  return value?.match(/\d{4}-\d{4}-\d{4}-\d{3}[\dXx]/)?.[0].toUpperCase();
}

/** "https://doi.org/10.1117/12.3081139" or "doi:10.1117/..." → "10.1117/12.3081139", case kept. */
export function bareDoi(value: string): string {
  let doi = value.trim();
  try {
    doi = decodeURIComponent(doi);
  } catch {
    // keep it as written
  }
  return doi
    .replace(/^(https?:\/\/)?(dx\.)?doi\.org\//i, "")
    .replace(/^doi:\s*/i, "")
    .trim();
}

/** DOIs are case-insensitive: the form used to compare them. */
export const normalizeDoi = (value: string) => bareDoi(value).toLowerCase();

/* ------------------------------------------------------------------------------------------------
   HTTP: polite pacing, a timeout, and retries on 429, 5xx, and network errors
   ------------------------------------------------------------------------------------------------ */

const sleep = (ms: number) => new Promise<void>((done) => setTimeout(done, ms));
const backoff = (attempt: number) => Math.min(16_000, 1000 * 2 ** (attempt - 1)) + Math.floor(Math.random() * 250);
/** Crossref's public pool allows 5 requests a second for single works; stay under it. */
const MIN_GAP_MS = 250;
let lastRequestAt = 0;

export async function getJson(url: string): Promise<{ status: number; body: unknown }> {
  const attempts = 5;
  let lastError = "no response";
  for (let attempt = 1; attempt <= attempts; attempt++) {
    const wait = lastRequestAt + MIN_GAP_MS - Date.now();
    if (wait > 0) await sleep(wait);
    lastRequestAt = Date.now();
    let response: Response;
    try {
      response = await fetch(url, {
        headers: { "User-Agent": USER_AGENT, Accept: "application/json" },
        signal: AbortSignal.timeout(20_000),
      });
    } catch (error) {
      lastError = error instanceof Error ? error.message : String(error);
      await sleep(backoff(attempt));
      continue;
    }
    if (response.ok) return { status: response.status, body: await response.json() };
    await response.body?.cancel();
    if (response.status === 404) return { status: 404, body: null };
    if (response.status !== 429 && response.status < 500) throw new Error(`HTTP ${response.status} from ${url}`);
    lastError = `HTTP ${response.status}`;
    const retryAfter = Number(response.headers.get("retry-after"));
    await sleep(retryAfter > 0 ? Math.min(retryAfter, 60) * 1000 : backoff(attempt));
  }
  throw new Error(`${lastError} from ${url} after ${attempts} attempts`);
}

/* ------------------------------------------------------------------------------------------------
   Crossref and the snapshot
   ------------------------------------------------------------------------------------------------ */

type DateParts = { "date-parts"?: (number | null)[][] };

export interface CrossrefAuthor {
  given?: string;
  family?: string;
  name?: string;
  ORCID?: string;
}

export interface CrossrefWork {
  DOI: string;
  type?: string;
  title?: string[];
  subtitle?: string[];
  "container-title"?: string[];
  volume?: string;
  issue?: string;
  page?: string;
  "article-number"?: string;
  published?: DateParts;
  issued?: DateParts;
  "published-print"?: DateParts;
  "published-online"?: DateParts;
  license?: { URL?: string; "content-version"?: string }[];
  author?: CrossrefAuthor[];
  publisher?: string;
  resource?: { primary?: { URL?: string } };
}

/** Returns null when Crossref does not know the DOI (HTTP 404). */
export async function fetchCrossref(doi: string): Promise<CrossrefWork | null> {
  const { body } = await getJson(`https://api.crossref.org/works/${encodeURIComponent(doi)}`);
  if (body === null) return null;
  const work = (body as { message?: CrossrefWork }).message;
  if (!work || typeof work.DOI !== "string") throw new Error(`Unexpected Crossref response for ${doi}`);
  return work;
}

export interface SnapshotAuthor {
  given?: string;
  family?: string;
  /** Organizations and consortia. */
  name?: string;
  /** Publisher-deposited ORCID iD, when Crossref has one. */
  orcid?: string;
}

export interface SnapshotRecord {
  title: string;
  container: string | null;
  volume: string | null;
  issue: string | null;
  page: string | null;
  articleNumber: string | null;
  /** ISO 8601 at the precision Crossref gives: "2025", "2025-03", or "2025-10-24". */
  published: string | null;
  /** Crossref's type: journal-article, proceedings-article, book-chapter, ... */
  type: string;
  license: string[];
  authors: SnapshotAuthor[];
}

/** DOI (as written in publications.ts) → the Crossref record. */
export type Snapshot = Record<string, SnapshotRecord>;

const textOrNull = (value: string | undefined | null): string | null => {
  if (value === undefined || value === null) return null;
  return cleanText(String(value)) || null;
};

function isoDate(date: DateParts | undefined): string | null {
  const parts = date?.["date-parts"]?.[0];
  if (!parts || typeof parts[0] !== "number") return null;
  const [year, month, day] = parts;
  let iso = String(year).padStart(4, "0");
  if (typeof month === "number") {
    iso += `-${String(month).padStart(2, "0")}`;
    if (typeof day === "number") iso += `-${String(day).padStart(2, "0")}`;
  }
  return iso;
}

/** Title plus subtitle, unless the title already ends with it. */
export function fullTitle(work: CrossrefWork): string {
  const title = textOrNull(work.title?.[0]) ?? "";
  const subtitle = textOrNull(work.subtitle?.[0]);
  if (!subtitle || titleKey(title).endsWith(titleKey(subtitle))) return title;
  return `${title}: ${subtitle}`;
}

export function toSnapshotRecord(work: CrossrefWork): SnapshotRecord {
  return {
    title: fullTitle(work),
    container: textOrNull(work["container-title"]?.[0]),
    volume: textOrNull(work.volume),
    issue: textOrNull(work.issue),
    page: textOrNull(work.page),
    articleNumber: textOrNull(work["article-number"]),
    published:
      isoDate(work.published) ?? isoDate(work.issued) ?? isoDate(work["published-print"]) ?? isoDate(work["published-online"]),
    type: work.type ?? "unknown",
    license: [...new Set((work.license ?? []).map((l) => l.URL?.trim()).filter((url): url is string => !!url))].sort(),
    authors: (work.author ?? []).map((author) => {
      const orcid = normalizeOrcid(author.ORCID);
      const who: SnapshotAuthor =
        author.family || author.given
          ? { given: textOrNull(author.given) ?? "", family: textOrNull(author.family) ?? "" }
          : { name: textOrNull(author.name) ?? "" };
      return orcid ? { ...who, orcid } : who;
    }),
  };
}

export function readSnapshot(path: string): Snapshot {
  const parsed: unknown = JSON.parse(readFileSync(path, "utf8"));
  if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) throw new Error(`${path} is not a DOI map.`);
  return parsed as Snapshot;
}

/** Sorted by DOI (case-insensitive), two-space indent, trailing newline: stable across runs. */
export function serializeSnapshot(snapshot: Snapshot): string {
  const key = (doi: string) => doi.toLowerCase();
  const ordered: Snapshot = {};
  for (const doi of Object.keys(snapshot).sort((a, b) => (key(a) < key(b) ? -1 : key(a) > key(b) ? 1 : 0))) {
    ordered[doi] = snapshot[doi];
  }
  return `${JSON.stringify(ordered, null, 2)}\n`;
}

export function snapshotEntry(snapshot: Snapshot, doi: string): SnapshotRecord | undefined {
  if (snapshot[doi]) return snapshot[doi];
  const match = Object.keys(snapshot).find((key) => key.toLowerCase() === doi.toLowerCase());
  return match ? snapshot[match] : undefined;
}

export const hasCcBy4 = (licenses: string[]) => licenses.some((url) => /creativecommons\.org\/licenses\/by\/4\.0/i.test(url));
export const hasCreativeCommons = (licenses: string[]) => licenses.some((url) => /creativecommons\.org\/licenses\//i.test(url));

export const isTripathi = (author: SnapshotAuthor) => nameTokens(author.family ?? author.name ?? "").join(" ") === "tripathi";

/** Given name "Madhavi", or the bare initial "M." ("Manjari Tripathi" is a frequent co-author of a namesake). */
const isMadhavi = (author: SnapshotAuthor) => {
  const given = nameTokens(author.given ?? "");
  return given[0] === "madhavi" || (given.length === 1 && given[0] === "m");
};

/**
  Index of the site owner among Crossref's authors: the author with her ORCID, or else a Madhavi (or M.) Tripathi
  with no ORCID. A Madhavi Tripathi carrying another ORCID is a namesake and never matches. -1 when none.
*/
export function ownerIndex(authors: SnapshotAuthor[], orcid: string): number {
  const byOrcid = authors.findIndex((a) => a.orcid === orcid);
  if (byOrcid >= 0) return byOrcid;
  return authors.findIndex((a) => isTripathi(a) && isMadhavi(a) && !a.orcid);
}

export const displayName = (author: SnapshotAuthor) =>
  author.name ?? [author.given, author.family].filter(Boolean).join(" ");

/* ------------------------------------------------------------------------------------------------
   Validation
   ------------------------------------------------------------------------------------------------ */

type NameMatch = "exact" | "initials" | "different";

/** Compares a curated display name ("Given Family") with Crossref's given and family names. */
function compareName(display: string, author: SnapshotAuthor): NameMatch {
  const shown = nameTokens(display);
  const family = nameTokens(author.family ?? author.name ?? "");
  const given = nameTokens(author.given ?? "");
  if (shown.join(" ") === [...given, ...family].join(" ")) return "exact";
  if (!family.length || shown.length <= family.length) return "different";
  if (shown.slice(-family.length).join(" ") !== family.join(" ")) return "different";
  // Same family name: accept given names that agree once initials are compared as initials ("E. T." = "Eniola T").
  const shownGiven = shown.slice(0, -family.length);
  const crossrefGiven = nameTokens(author.given ?? "", true);
  if (shownGiven.length !== crossrefGiven.length) return "different";
  const agree = shownGiven.every((token, i) => {
    const other = crossrefGiven[i];
    return token === other || ((token.length === 1 || other.length === 1) && token[0] === other[0]);
  });
  return agree ? "initials" : "different";
}

const EXPECTED_TYPES: Record<string, string[]> = {
  "journal-article": ["journal-article"],
  review: ["journal-article"],
  "conference-paper": ["proceedings-article"],
  "book-chapter": ["book-chapter", "book-part", "book-section", "reference-entry"],
  thesis: ["dissertation"],
};

type Level = "ok" | "note" | "fail";
interface Cell {
  text: string;
  level: Level;
}
interface Result {
  pub: Publication;
  cells: { title: Cell; year: Cell; authors: Cell; tripathi: Cell; license: Cell };
  failures: string[];
  notes: string[];
  venue: string;
  details: string;
}

const quote = (value: string) => `"${value}"`;

function validate(pub: Publication, cr: SnapshotRecord | undefined, orcid: string, source: string): Result {
  const failures: string[] = [];
  const notes: string[] = [];
  const doi = pub.doi ?? "";
  const accepted = ACCEPTED[doi] ?? {};
  const missing: Cell = { text: "-", level: "fail" };
  if (!cr) {
    failures.push(`not in the Crossref data (${source}); run \`npm run enrich\``);
    return { pub, cells: { title: missing, year: missing, authors: missing, tripathi: missing, license: missing }, failures, notes, venue: "-", details: "-" };
  }
  const where = `https://api.crossref.org/works/${doi}`;
  const fail = (field: "title" | "year" | "authors", message: string): Cell => {
    if (accepted[field]) {
      notes.push(`${field}: accepted difference (${accepted[field]}): ${message}`);
      return { text: "accepted", level: "note" };
    }
    failures.push(`${message} (${where})`);
    return { text: "DIFFERS", level: "fail" };
  };

  // Title
  const title: Cell =
    titleKey(pub.title) === titleKey(cr.title)
      ? { text: "ok", level: "ok" }
      : fail("title", `title: current ${quote(pub.title)}; Crossref ${quote(cr.title)}`);

  // Year
  const crYear = cr.published ? Number(cr.published.slice(0, 4)) : Number.NaN;
  const year: Cell =
    crYear === pub.year
      ? { text: String(pub.year), level: "ok" }
      : fail("year", `year: current ${pub.year}; Crossref ${Number.isNaN(crYear) ? "none" : crYear} (published ${cr.published ?? "?"})`);
  if (year.level === "fail") year.text = `${pub.year}≠${Number.isNaN(crYear) ? "?" : crYear}`;

  // Authors
  const crAuthors = cr.authors ?? [];
  const differences: string[] = [];
  let initialsOnly = 0;
  const count = Math.max(pub.authors.length, crAuthors.length);
  for (let i = 0; i < count; i++) {
    const mine = pub.authors[i];
    const theirs = crAuthors[i];
    if (!mine || !theirs) {
      differences.push(`#${i + 1}: current ${mine ? quote(mine.name) : "none"}; Crossref ${theirs ? quote(displayName(theirs)) : "none"}`);
      continue;
    }
    const match = compareName(mine.name, theirs);
    if (match === "different") differences.push(`#${i + 1}: current ${quote(mine.name)}; Crossref ${quote(displayName(theirs))}`);
    if (match === "initials") initialsOnly++;
    // `family` is the citation form of a multi-word family name; Crossref splits some names differently per paper.
    if (mine.family && nameTokens(mine.family).join(" ") !== nameTokens(theirs.family ?? theirs.name ?? "").join(" ")) {
      notes.push(`author #${i + 1} family: current ${quote(mine.family)}; Crossref ${quote(theirs.family ?? theirs.name ?? "")}`);
    }
  }
  let authors: Cell;
  if (differences.length) {
    authors = fail("authors", `authors: ${differences.join("; ")}`);
    if (authors.level === "fail") {
      authors.text = pub.authors.length === crAuthors.length ? `${differences.length} differ` : `${pub.authors.length}≠${crAuthors.length}`;
    }
  } else {
    authors = { text: `${pub.authors.length}/${crAuthors.length}`, level: "ok" };
    if (initialsOnly) {
      authors.text += " (initials)";
      notes.push(`authors: ${initialsOnly} name(s) match only as initials in Crossref`);
    }
  }

  // Tripathi: the curated `me` author must be the owner in Crossref, at the same position
  const meIndex = pub.authors.findIndex((a) => a.me === true);
  const crOwner = crAuthors[meIndex];
  let tripathi: Cell;
  if (meIndex < 0) {
    failures.push("Tripathi: no author is marked `me` in publications.ts");
    tripathi = { text: "no me", level: "fail" };
  } else if (!crAuthors.some(isTripathi)) {
    failures.push(`Tripathi: Crossref lists no author named Tripathi (${where})`);
    tripathi = { text: "MISSING", level: "fail" };
  } else if (!crOwner || !isTripathi(crOwner) || !isMadhavi(crOwner)) {
    const at = crAuthors.findIndex(isTripathi);
    failures.push(
      `Tripathi: \`me\` is author #${meIndex + 1}, but Crossref's #${meIndex + 1} is ${crOwner ? quote(displayName(crOwner)) : "missing"} and its Tripathi is #${at + 1} (${where})`,
    );
    tripathi = { text: "MOVED", level: "fail" };
  } else if (crOwner.orcid && crOwner.orcid !== orcid) {
    failures.push(`Tripathi: Crossref's author #${meIndex + 1} carries ORCID ${crOwner.orcid}, not ${orcid}: a namesake? (${where})`);
    tripathi = { text: "ORCID≠", level: "fail" };
  } else {
    tripathi = { text: `#${meIndex + 1} ${crOwner.orcid ? "ORCID" : "name"}`, level: "ok" };
  }

  // License and access
  const licenses = cr.license ?? [];
  let license: Cell;
  if (pub.license === "CC BY 4.0" && !hasCcBy4(licenses)) {
    failures.push(
      `license: current "CC BY 4.0"; Crossref ${hasCreativeCommons(licenses) ? `lists ${licenses.join(", ")}` : "lists no Creative Commons license"} (${where})`,
    );
    license = { text: "DIFFERS", level: "fail" };
  } else if (pub.license === "CC BY 4.0") {
    license = { text: "CC BY 4.0", level: "ok" };
  } else if (hasCcBy4(licenses) && pub.access !== "open-access") {
    notes.push(`access: current ${quote(pub.access)}, but Crossref lists CC BY 4.0: "open-access" with license "CC BY 4.0"?`);
    license = { text: "check", level: "note" };
  } else if (pub.access === "open-access" && !hasCreativeCommons(licenses)) {
    notes.push('access: "open-access" without a Creative Commons license in Crossref');
    license = { text: "check", level: "note" };
  } else {
    license = { text: pub.access === "free-to-read" ? "free (n/a)" : "none", level: "ok" };
  }

  // Type (information)
  const expected = EXPECTED_TYPES[pub.type] ?? [];
  if (!expected.includes(cr.type)) notes.push(`type: current ${quote(pub.type)}; Crossref ${quote(cr.type)}`);

  return {
    pub,
    cells: { title, year, authors, tripathi, license },
    failures,
    notes,
    venue: compareVenue(pub.venue, cr.container),
    details: compareDetails(pub, cr),
  };
}

function compareVenue(venue: string, container: string | null): string {
  if (!container) return "Crossref has no container title";
  const mine = titleKey(venue);
  const theirs = titleKey(container);
  if (mine === theirs) return "same";
  if (mine.includes(theirs)) return `contains ${quote(container)}`;
  return `differs: Crossref ${quote(container)}`;
}

const stripZeros = (value: string | null | undefined) => (value ?? "").trim().replace(/^0+(?=\w)/, "").toLowerCase();
const dashes = (value: string) => value.replace(/[\u2010-\u2015\u2212]/g, "-");

function compareDetails(pub: Publication, cr: SnapshotRecord): string {
  const crossref = [
    cr.volume && `vol ${cr.volume}`,
    cr.issue && `issue ${cr.issue}`,
    cr.page && `page ${cr.page}`,
    cr.articleNumber && `article ${cr.articleNumber}`,
  ]
    .filter(Boolean)
    .join(", ");
  if (!pub.details) return crossref ? `none on the site; Crossref has ${crossref}` : "none (none in Crossref)";
  const details = dashes(pub.details).trim();
  let volume: string | undefined;
  let issue: string | undefined;
  let locator = details;
  const pages = /^pp\.\s*(.+)$/.exec(details);
  const volumeIssue = /^(\w+)(?:\((\w+)\))?,\s*(.+)$/.exec(details);
  if (pages) locator = pages[1];
  else if (volumeIssue) [, volume, issue, locator] = volumeIssue;
  const problems: string[] = [];
  if (volume !== undefined && stripZeros(volume) !== stripZeros(cr.volume)) problems.push(`volume ${volume} (Crossref ${cr.volume ?? "none"})`);
  if (issue !== undefined && stripZeros(issue) !== stripZeros(cr.issue)) problems.push(`issue ${issue} (Crossref ${cr.issue ?? "none"})`);
  const loc = locator.replace(/\s+/g, "").toLowerCase();
  const page = dashes(cr.page ?? "").replace(/\s+/g, "").toLowerCase();
  const article = (cr.articleNumber ?? "").toLowerCase();
  let locNote: string;
  if (loc === page || loc === article) locNote = `${locator} matches`;
  else if ((pub.doi ?? "").toLowerCase().endsWith(loc)) locNote = `${locator} is the DOI's article ID (Crossref page ${cr.page ?? "none"})`;
  else locNote = `${locator} not in Crossref (${crossref || "no volume or pages"})`;
  return problems.length ? `${problems.join("; ")}; ${locNote}` : `${volume ? "volume/issue ok; " : ""}${locNote}`;
}

/* ------------------------------------------------------------------------------------------------
   Output
   ------------------------------------------------------------------------------------------------ */

function printTable(results: Result[]): void {
  const header = ["#", "id", "title", "year", "authors", "Tripathi", "license", "result"];
  const rows = results.map((r, i) => {
    const failed = r.failures.length > 0;
    return [
      String(i + 1),
      r.pub.id,
      r.cells.title.text,
      r.cells.year.text,
      r.cells.authors.text,
      r.cells.tripathi.text,
      r.cells.license.text,
      failed ? "FAIL" : r.notes.length ? "pass*" : "pass",
    ];
  });
  const widths = header.map((h, c) => Math.max(h.length, ...rows.map((row) => row[c].length)));
  const format = (row: string[]) => row.map((cell, c) => cell.padEnd(widths[c])).join("  ").trimEnd();
  console.log(format(header));
  console.log(widths.map((w) => "-".repeat(w)).join("  "));
  for (const row of rows) console.log(format(row));
}

function printSection(title: string, lines: string[]): void {
  if (!lines.length) return;
  console.log(`\n${title}`);
  for (const line of lines) console.log(`  ${line}`);
}

/* ------------------------------------------------------------------------------------------------
   ORCID watch
   ------------------------------------------------------------------------------------------------ */

interface OrcidExternalId {
  "external-id-type"?: string;
  "external-id-value"?: string;
  "external-id-normalized"?: { value?: string };
  "external-id-relationship"?: string;
}
interface OrcidGroup {
  "external-ids"?: { "external-id"?: OrcidExternalId[] };
  "work-summary"?: {
    title?: { title?: { value?: string } };
    type?: string;
    "publication-date"?: { year?: { value?: string } } | null;
  }[];
}
interface OrcidWork {
  dois: string[];
  title: string;
  year: string | null;
  type: string | null;
}

async function orcidWorks(orcid: string): Promise<OrcidWork[]> {
  const { status, body } = await getJson(`https://pub.orcid.org/v3.0/${orcid}/works`);
  if (status === 404 || body === null) throw new Error(`ORCID record ${orcid} not found`);
  const groups = (body as { group?: OrcidGroup[] }).group ?? [];
  return groups.map((group) => {
    const ids = group["external-ids"]?.["external-id"] ?? [];
    const dois = ids
      .filter((id) => id["external-id-type"]?.toLowerCase() === "doi" && (id["external-id-relationship"] ?? "self") === "self")
      .map((id) => normalizeDoi(id["external-id-normalized"]?.value ?? id["external-id-value"] ?? ""))
      .filter(Boolean);
    const summary = group["work-summary"]?.[0];
    return {
      dois: [...new Set(dois)],
      title: cleanText(summary?.title?.title?.value ?? "(untitled)"),
      year: summary?.["publication-date"]?.year?.value ?? null,
      type: summary?.type ?? null,
    };
  });
}

/** Every DOI the site shows: the record DOIs and any doi.org links (preprints included). */
export function siteDois(pubs: Publication[]): Set<string> {
  const dois = new Set<string>();
  for (const pub of pubs) {
    if (pub.doi) dois.add(normalizeDoi(pub.doi));
    for (const link of pub.links) if (/doi\.org\//i.test(link.href)) dois.add(normalizeDoi(link.href));
  }
  return dois;
}

const markdownCell = (value: string) =>
  value.replace(/\|/g, "\\|").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/@/g, "@\u200b");

async function runOrcid(pubs: Publication[], orcid: string, reportPath: string | undefined): Promise<number> {
  const works = await orcidWorks(orcid);
  const onSite = siteDois(pubs);
  const orcidDois = new Set(works.flatMap((w) => w.dois));
  const missing = works.filter((w) => w.dois.length > 0 && !w.dois.some((doi) => onSite.has(doi)));
  const withoutDoi = works.filter((w) => w.dois.length === 0);
  const notOnOrcid = pubs.filter((p) => p.doi && !orcidDois.has(normalizeDoi(p.doi)));

  console.log(`ORCID ${orcid}: ${works.length} works, ${works.length - withoutDoi.length} with a DOI. Site: ${pubs.length} records.`);
  printSection(
    missing.length ? `On ORCID but not on the site (${missing.length}):` : "Every DOI on ORCID is on the site.",
    missing.map((w) => `${w.dois.join(", ")}  ${w.year ?? "----"}  ${w.title}`),
  );
  printSection(
    `On ORCID without a DOI (check by hand, ${withoutDoi.length}):`,
    withoutDoi.map((w) => `${w.year ?? "----"}  ${w.title}`),
  );
  printSection(
    `On the site but not on ORCID (for the owner to add there; information only, ${notOnOrcid.length}):`,
    notOnOrcid.map((p) => `${p.doi}  ${p.id}`),
  );

  if (reportPath) {
    if (missing.length) {
      const rows = missing.map(
        (w) =>
          `| ${w.dois.map((doi) => `[${doi}](https://doi.org/${doi})`).join("<br>")} | ${markdownCell(w.title)} | ${w.year ?? ""} | ${w.type ?? ""} |`,
      );
      const report = [
        `The ORCID record [${orcid}](https://orcid.org/${orcid}) lists ${missing.length === 1 ? "a work" : `${missing.length} works`} with a DOI that the site does not show:`,
        "",
        "| DOI | Title (as on ORCID) | Year | Type |",
        "| --- | --- | --- | --- |",
        ...rows,
        "",
        "**Before adding one**, confirm it is Madhavi Tripathi's own work: other researchers publish under the same name.",
        "",
        '**To add one**, open Actions → **Add a paper** → **Run workflow**, and enter the DOI and a one-sentence summary. The workflow opens a pull request to review.',
        "",
        "_Opened by the Publications check workflow, which updates this issue while it stays open._",
        "",
      ].join("\n");
      writeFileSync(reportPath, report);
      console.log(`\nWrote ${reportPath}`);
    } else if (existsSync(reportPath)) {
      rmSync(reportPath);
    }
  }
  if (process.env.GITHUB_OUTPUT) appendFileSync(process.env.GITHUB_OUTPUT, `missing=${missing.length}\n`);
  return 0;
}

/* ------------------------------------------------------------------------------------------------
   Main
   ------------------------------------------------------------------------------------------------ */

const USAGE = `Usage:
  node scripts/enrich-publications.mts            fetch Crossref, write the snapshot, check every record
  node scripts/enrich-publications.mts --offline  check against the committed snapshot (no network)
  node scripts/enrich-publications.mts --orcid [--orcid-id <iD>] [--report <file.md>]
Options: --file <publications.ts>  --snapshot <publications.crossref.json>`;

async function main(): Promise<number> {
  let values: {
    offline?: boolean;
    orcid?: boolean;
    "orcid-id"?: string;
    report?: string;
    file?: string;
    snapshot?: string;
    help?: boolean;
  };
  try {
    ({ values } = parseArgs({
      options: {
        offline: { type: "boolean" },
        orcid: { type: "boolean" },
        "orcid-id": { type: "string" },
        report: { type: "string" },
        file: { type: "string" },
        snapshot: { type: "string" },
        help: { type: "boolean", short: "h" },
      },
    }));
  } catch (error) {
    console.error(`${error instanceof Error ? error.message : String(error)}\n\n${USAGE}`);
    return 2;
  }
  if (values.help) {
    console.log(USAGE);
    return 0;
  }

  const file = resolve(values.file ?? DEFAULT_PUBLICATIONS);
  const snapshotPath = resolve(values.snapshot ?? DEFAULT_SNAPSHOT);
  const pubs = await loadPublications(file);
  const orcid = values["orcid-id"] ?? (await ownerOrcid());
  if (!ORCID_ID.test(orcid)) {
    console.error(`Not an ORCID iD: ${orcid}`);
    return 2;
  }

  if (values.orcid) return runOrcid(pubs, orcid, values.report ? resolve(values.report) : undefined);

  const withDoi = pubs.filter((p) => p.doi);
  const withoutDoi = pubs.filter((p) => !p.doi);
  const shown = (path: string) => {
    const rel = relative(process.cwd(), path);
    return rel && !rel.startsWith("..") ? rel : path;
  };
  let snapshot: Snapshot;
  let source: string;
  let fetchFailed = false;

  if (values.offline) {
    if (!existsSync(snapshotPath)) {
      console.error(`No snapshot at ${shown(snapshotPath)}: run \`npm run enrich\` first.`);
      return 1;
    }
    snapshot = readSnapshot(snapshotPath);
    source = `snapshot ${shown(snapshotPath)}`;
    console.log(`Checking ${withDoi.length} records against the ${source} (offline).\n`);
  } else {
    source = "live Crossref";
    console.log(`Fetching ${withDoi.length} DOIs from Crossref...`);
    const previous = existsSync(snapshotPath) ? readSnapshot(snapshotPath) : {};
    snapshot = {};
    for (const pub of withDoi) {
      const doi = pub.doi as string;
      try {
        const work = await fetchCrossref(doi);
        if (work) snapshot[doi] = toSnapshotRecord(work);
        else {
          fetchFailed = true;
          console.log(`  not found: ${doi}`);
        }
      } catch (error) {
        fetchFailed = true;
        console.log(`  failed: ${doi}: ${error instanceof Error ? error.message : String(error)}`);
      }
    }
    if (fetchFailed) {
      console.log(`Snapshot not written: a DOI could not be fetched. ${shown(snapshotPath)} is unchanged.\n`);
    } else {
      const next = serializeSnapshot(snapshot);
      const before = existsSync(snapshotPath) ? readFileSync(snapshotPath, "utf8") : "";
      if (next === before) console.log(`Snapshot unchanged: ${shown(snapshotPath)}\n`);
      else {
        writeFileSync(snapshotPath, next);
        const changed = Object.keys(snapshot).filter(
          (doi) => JSON.stringify(snapshotEntry(previous, doi)) !== JSON.stringify(snapshot[doi]),
        );
        const removed = Object.keys(previous).filter((doi) => !snapshotEntry(snapshot, doi));
        console.log(`Snapshot written: ${shown(snapshotPath)} (${changed.length} new or changed, ${removed.length} removed)\n`);
      }
    }
  }

  const results = withDoi.map((pub) => validate(pub, snapshotEntry(snapshot, pub.doi as string), orcid, source));
  printTable(results);
  printSection(
    "Failures (correct src/content/publications.ts, or record a reviewed difference in ACCEPTED):",
    results.flatMap((r) => r.failures.map((f) => `${r.pub.id}  ${f}`)),
  );
  printSection(
    "Notes (not failures):",
    results.flatMap((r) => r.notes.map((n) => `${r.pub.id}  ${n}`)),
  );
  printSection(
    "Venue and details (information only):",
    results.map((r) => `${r.pub.id.padEnd(30)}  venue ${r.venue}; details ${r.details}`),
  );
  const stale = Object.keys(snapshot).filter((doi) => !withDoi.some((p) => (p.doi as string).toLowerCase() === doi.toLowerCase()));
  printSection("Snapshot entries with no record (run `npm run enrich` to prune):", stale);
  if (withoutDoi.length) console.log(`\nNo DOI, not checked: ${withoutDoi.map((p) => p.id).join(", ")}`);

  const failed = results.filter((r) => r.failures.length).length;
  console.log(
    `\n${results.length} checked against ${source}: ${results.length - failed} pass, ${failed} fail.` +
      ` Owner ORCID ${orcid}.${fetchFailed ? " Some DOIs could not be fetched." : ""}`,
  );
  return failed || fetchFailed ? 1 : 0;
}

const invokedDirectly = (() => {
  try {
    return !!process.argv[1] && realpathSync(process.argv[1]) === realpathSync(fileURLToPath(import.meta.url));
  } catch {
    return false;
  }
})();

if (invokedDirectly) {
  try {
    process.exitCode = await main();
  } catch (error) {
    console.error(`enrich-publications: ${error instanceof Error ? error.message : String(error)}`);
    process.exitCode = 1;
  }
}
