/*
  Serves out/ the way Cloudflare static assets will (wrangler.jsonc), so tests and measurements run
  against the real thing: /page serves page.html, unknown paths get 404.html with a 404 status, the rules
  in _headers and _redirects apply, and text is compressed.
  Two differences, both because this is plain http on localhost: upgrade-insecure-requests is dropped from
  the CSP (it would send the page's own requests to https), and absolute-URL header rules are skipped.

  Usage: node scripts/serve-out.mjs [--port 3218] [--dir out]
*/
import fs from "node:fs";
import http from "node:http";
import path from "node:path";
import zlib from "node:zlib";

const arg = (name, fallback) => {
  const i = process.argv.indexOf(`--${name}`);
  return i > -1 ? process.argv[i + 1] : fallback;
};
const ROOT = path.resolve(arg("dir", "out"));
const PORT = Number(arg("port", process.env.PORT ?? 3218));

if (!fs.existsSync(path.join(ROOT, "index.html"))) {
  console.error(`No build in ${ROOT}. Run npm run build first.`);
  process.exit(1);
}

const TYPES = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json",
  ".txt": "text/plain; charset=utf-8",
  ".xml": "application/xml",
  ".webmanifest": "application/manifest+json",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".avif": "image/avif",
  ".ico": "image/x-icon",
  ".woff2": "font/woff2",
  ".pdf": "application/pdf",
  ".bib": "application/x-bibtex",
};
const COMPRESSIBLE = /^(text\/|application\/(json|xml|manifest\+json|x-bibtex)|image\/svg)/;

/** _headers: a URL pattern, then indented "Name: value" lines. `:name` matches one segment, `*` the rest. */
function parseHeaders(file) {
  const rules = [];
  if (!fs.existsSync(file)) return rules;
  let current;
  for (const raw of fs.readFileSync(file, "utf8").split("\n")) {
    if (!raw.trim() || raw.trim().startsWith("#")) continue;
    if (!/^\s/.test(raw)) {
      current = { pattern: raw.trim(), headers: [] };
      rules.push(current);
    } else if (current) {
      const line = raw.trim();
      const i = line.indexOf(":");
      if (line.startsWith("! ")) current.headers.push({ name: line.slice(2).trim().toLowerCase(), remove: true });
      else if (i > 0) current.headers.push({ name: line.slice(0, i).trim().toLowerCase(), value: line.slice(i + 1).trim() });
    }
  }
  return rules;
}
const toRegex = (pattern) =>
  new RegExp(`^${pattern.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/:\w+/g, "[^/]+")}$`);
const headerRules = parseHeaders(path.join(ROOT, "_headers"))
  .filter((r) => r.pattern.startsWith("/"))
  .map((r) => ({ ...r, regex: toRegex(r.pattern) }));

const redirects = fs.existsSync(path.join(ROOT, "_redirects"))
  ? fs
      .readFileSync(path.join(ROOT, "_redirects"), "utf8")
      .split("\n")
      .map((l) => l.trim())
      .filter((l) => l && !l.startsWith("#"))
      .map((l) => {
        const [from, to, status = "302"] = l.split(/\s+/);
        return { regex: toRegex(from), to, status: Number(status) };
      })
  : [];

function headersFor(pathname) {
  const out = new Map();
  for (const rule of headerRules) {
    if (!rule.regex.test(pathname)) continue;
    for (const h of rule.headers) {
      if (h.remove) out.delete(h.name);
      else out.set(h.name, out.has(h.name) && h.name !== "content-type" ? `${out.get(h.name)}, ${h.value}` : h.value);
    }
  }
  const csp = out.get("content-security-policy");
  if (csp) out.set("content-security-policy", csp.replace(/;\s*upgrade-insecure-requests/, ""));
  return out;
}

/** Resolves a URL path to a file inside ROOT the way html_handling "auto-trailing-slash" does. */
function resolve(pathname) {
  const clean = path.posix.normalize(decodeURIComponent(pathname));
  const candidates = clean.endsWith("/") ? [`${clean}index.html`] : [clean, `${clean}.html`, `${clean}/index.html`];
  for (const c of candidates) {
    const file = path.join(ROOT, c);
    if (!file.startsWith(ROOT)) return null;
    if (fs.existsSync(file) && fs.statSync(file).isFile()) return file;
  }
  return null;
}

const cache = new Map();
function body(file, encoding) {
  const key = `${file}|${encoding}`;
  const stat = fs.statSync(file);
  const hit = cache.get(key);
  if (hit && hit.mtime === stat.mtimeMs) return hit.buf;
  const raw = fs.readFileSync(file);
  const buf =
    encoding === "br"
      ? zlib.brotliCompressSync(raw, { params: { [zlib.constants.BROTLI_PARAM_QUALITY]: 11 } })
      : encoding === "gzip"
        ? zlib.gzipSync(raw, { level: 9 })
        : raw;
  cache.set(key, { mtime: stat.mtimeMs, buf });
  return buf;
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url ?? "/", "http://localhost");
  let pathname = url.pathname;
  if (req.method !== "GET" && req.method !== "HEAD") {
    res.writeHead(405, { allow: "GET, HEAD" }).end();
    return;
  }
  for (const r of redirects) {
    if (r.regex.test(pathname)) {
      res.writeHead(r.status, { location: r.to }).end();
      return log(req, r.status);
    }
  }
  // auto-trailing-slash: /index.html and /page.html redirect to their clean form, /page/ to /page.
  if (pathname.endsWith("/index.html")) return redirect(res, req, pathname.slice(0, -"index.html".length) + url.search);
  if (pathname.endsWith(".html")) return redirect(res, req, pathname.slice(0, -5) + url.search);
  if (pathname.length > 1 && pathname.endsWith("/") && !fs.existsSync(path.join(ROOT, pathname, "index.html")))
    return redirect(res, req, pathname.slice(0, -1) + url.search);

  let file = resolve(pathname);
  let status = 200;
  if (!file) {
    file = path.join(ROOT, "404.html");
    status = 404;
    pathname = "/404.html";
  }
  const ext = path.extname(file);
  const headers = headersFor(pathname);
  const type = headers.get("content-type") ?? TYPES[ext] ?? "application/octet-stream";
  const accept = String(req.headers["accept-encoding"] ?? "");
  const encoding = COMPRESSIBLE.test(type) ? (/\bbr\b/.test(accept) ? "br" : /\bgzip\b/.test(accept) ? "gzip" : null) : null;
  const buf = body(file, encoding);
  headers.set("content-type", type);
  if (!headers.has("cache-control")) headers.set("cache-control", "public, max-age=0, must-revalidate");
  if (encoding) {
    headers.set("content-encoding", encoding);
    headers.set("vary", "accept-encoding");
  }
  headers.set("content-length", String(buf.length));
  res.writeHead(status, Object.fromEntries(headers));
  res.end(req.method === "HEAD" ? undefined : buf);
  log(req, status);
});

function redirect(res, req, location) {
  res.writeHead(307, { location }).end();
  log(req, 307);
}
function log(req, status) {
  if (process.env.QUIET) return;
  console.log(`${status} ${req.method} ${req.url}`);
}

server.listen(PORT, () => console.log(`Serving ${path.relative(process.cwd(), ROOT) || ROOT} at http://localhost:${PORT}`));
