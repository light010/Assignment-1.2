/*
  Google Scholar snapshot: the pure half of scripts/scholar-sync.mts. No network and no files, so the unit
  tests run every function here on fixtures (tests/unit/scholar.test.mts).

  parseProfile reads the public profile page by a few stable ids and classes:
    #gsc_prf_in                       the profile's name
    table#gsc_rsb_st                  Citations, h-index, i10-index; columns "All" and "Since <year>"
    .gsc_md_hist_b                    citations per year: year labels span.gsc_g_t and bars a.gsc_g_a, each
                                      placed by a CSS `right:` offset. A year without citations has no bar,
                                      so bars are matched to years by that offset, never by order.
    tbody#gsc_a_b tr.gsc_a_tr         one article: a.gsc_a_at (title; its citation_for_view is Scholar's id),
                                      two div.gs_gray (authors; venue with ", <year>" in span.gs_oph),
                                      a.gsc_a_ac (cited by, empty for none), span.gsc_a_h (year, may be empty)
  When Google changes that markup, parseProfile throws ScholarParseError (detectBlock treats a 200 page that
  still has some of the profile's markup as the profile, so a renamed element reads as a parse fault, not as a
  refusal), and the sync keeps the last snapshot.
*/

import type { ScholarArticle, ScholarSnapshot } from "../../src/content/scholar.ts";

export type { ScholarArticle, ScholarSnapshot };

export const SCHEMA = 1;
/** A Scholar user id, as in src/content/person.ts ("zZx1Td0AAAAJ"). */
export const PROFILE_ID = /^[\w-]{12}$/;
/** Refuse a drop larger than this, in total citations or in the article count, unless forced. */
export const MAX_DROP = 0.1;
/** An unchanged snapshot is rewritten once its checkedAt is older than this, so the site's date stays within a day. */
export const REFRESH_HOURS = 20;
/** `--check` warns when the committed snapshot is older than this. */
export const STALE_DAYS = 14;

/** The profile page, in the form src/content/person.ts uses. */
export const profileUrl = (id: string) => `https://scholar.google.com/citations?user=${id}&hl=en`;
/** Scholar's list of works citing an article ("cites" is one id, or several joined by commas for merged versions). */
export const citedByUrl = (cites: string) => `https://scholar.google.com/scholar?cites=${cites}&hl=en`;
/** Scholar's page for one article. */
export const articleUrl = (id: string) =>
  `https://scholar.google.com/citations?view_op=view_citation&hl=en&user=${id.split(":")[0]}&citation_for_view=${id}`;

/**
  Scholar entries that normalized-title matching can't pair with the site's record, by Scholar id → the site's
  publication id. Empty today: every entry on the profile matches by title and year. Add a line when Scholar
  shows a paper under another title or year (the scholar-watch issue lists it as not on the site).
*/
export const OVERRIDES: Readonly<Record<string, string>> = {};

/**
  Scholar entries the owner leaves off the site on purpose, by Scholar id → the reason. They stay in the
  snapshot (with pub null) but are left out of the scholar-watch issue and the warnings. Empty today.
*/
export const IGNORED: Readonly<Record<string, string>> = {};

/** The page or JSON isn't what the parser expects: Google changed the markup, or it isn't a profile at all. */
export class ScholarParseError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ScholarParseError";
  }
}

/* ------------------------------------------------------------------------------------------------
   Text: charset, entities, tags
   ------------------------------------------------------------------------------------------------ */

/**
  The page as text. Scholar sometimes answers in ISO-8859-1 (charset in the Content-Type header and a
  <meta>), with raw Latin-1 bytes for names like "Timaná" and numeric entities for the rest, so the bytes are
  decoded by the declared charset: the header, else the <meta>, else UTF-8.
*/
export function decodeHtml(bytes: Uint8Array, contentType?: string | null): string {
  const declared =
    /charset\s*=\s*["']?([\w.:-]+)/i.exec(contentType ?? "")?.[1] ??
    /<meta\b[^>]*charset\s*=\s*["']?([\w.:-]+)/i.exec(new TextDecoder("latin1").decode(bytes.subarray(0, 4096)))?.[1];
  try {
    return new TextDecoder(declared ?? "utf-8").decode(bytes);
  } catch {
    return new TextDecoder("utf-8").decode(bytes);
  }
}

// HTML 4's Latin-1 names, U+00A0 to U+00FF in order.
const LATIN1 =
  "nbsp iexcl cent pound curren yen brvbar sect uml copy ordf laquo not shy reg macr deg plusmn sup2 sup3 acute " +
  "micro para middot cedil sup1 ordm raquo frac14 frac12 frac34 iquest Agrave Aacute Acirc Atilde Auml Aring AElig " +
  "Ccedil Egrave Eacute Ecirc Euml Igrave Iacute Icirc Iuml ETH Ntilde Ograve Oacute Ocirc Otilde Ouml times Oslash " +
  "Ugrave Uacute Ucirc Uuml Yacute THORN szlig agrave aacute acirc atilde auml aring aelig ccedil egrave eacute ecirc " +
  "euml igrave iacute icirc iuml eth ntilde ograve oacute ocirc otilde ouml divide oslash ugrave uacute ucirc uuml " +
  "yacute thorn yuml";
const GREEK =
  "alpha beta gamma delta epsilon zeta eta theta iota kappa lambda mu nu xi omicron pi rho sigmaf sigma tau upsilon " +
  "phi chi psi omega";
const ENTITIES: Record<string, string> = {
  amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", ndash: "\u2013", mdash: "\u2014", minus: "\u2212",
  hellip: "\u2026", lsquo: "\u2018", rsquo: "\u2019", sbquo: "\u201a", ldquo: "\u201c", rdquo: "\u201d",
  bdquo: "\u201e", bull: "\u2022", prime: "\u2032", Prime: "\u2033", thinsp: "\u2009", ensp: "\u2002",
  emsp: "\u2003", zwnj: "\u200c", zwj: "\u200d", lrm: "\u200e", rlm: "\u200f", trade: "\u2122", le: "\u2264",
  ge: "\u2265", ne: "\u2260", asymp: "\u2248", infin: "\u221e", rarr: "\u2192", larr: "\u2190",
  Gamma: "\u0393", Delta: "\u0394", Theta: "\u0398", Lambda: "\u039b", Pi: "\u03a0", Sigma: "\u03a3",
  Phi: "\u03a6", Psi: "\u03a8", Omega: "\u03a9",
};
LATIN1.split(" ").forEach((name, i) => (ENTITIES[name] = String.fromCharCode(0xa0 + i)));
GREEK.split(" ").forEach((name, i) => (ENTITIES[name] = String.fromCharCode(0x3b1 + i)));

const ENTITY = /&(#[xX][0-9a-fA-F]+|#[0-9]+|[A-Za-z][A-Za-z0-9]*);/g;
/** A tag: "<" and a letter or "/", then attributes, quoted values may hold ">". */
const TAG = /<\/?[A-Za-z][^\s/>]*(?:[^>"']|"[^"]*"|'[^']*')*>/g;
const COMBINING_MARKS = new RegExp("\\p{M}+", "gu");
const NOT_LETTER_OR_DIGIT = new RegExp("[^\\p{L}\\p{N}]+", "gu");

export function decodeEntities(value: string): string {
  return value.replace(ENTITY, (whole, body: string) => {
    if (body.startsWith("#")) {
      const hex = body[1] === "x" || body[1] === "X";
      const codePoint = Number.parseInt(body.slice(hex ? 2 : 1), hex ? 16 : 10);
      return codePoint > 0 && codePoint <= 0x10ffff ? String.fromCodePoint(codePoint) : whole;
    }
    return Object.hasOwn(ENTITIES, body) ? ENTITIES[body] : whole;
  });
}

/** External text on one line, for logs: a line starting "::" would be a GitHub Actions command. */
export const oneLine = (value: string) => value.replace(/\s+/g, " ").trim();

/** Visible text of an HTML fragment: tags dropped, entities decoded, white space collapsed. */
export function textOf(html: string): string {
  return decodeEntities(html.replace(TAG, "")).replace(/\s+/g, " ").trim();
}

/** Comparison key for titles: case, accents, punctuation, dashes, markup, and spaces ignored. */
export function normalizeTitle(value: string): string {
  return decodeEntities(value.replace(TAG, " "))
    .normalize("NFKD")
    .replace(COMBINING_MARKS, "")
    .toLowerCase()
    .replace(NOT_LETTER_OR_DIGIT, "");
}

/** Name tokens, folded ("José Timaná" → jose, timana). */
const nameTokens = (value: string) =>
  value
    .normalize("NFKD")
    .replace(COMBINING_MARKS, "")
    .toLowerCase()
    .split(NOT_LETTER_OR_DIGIT)
    .filter(Boolean);

/** Every word of the expected name appears in Scholar's ("Madhavi Tripathi" in "Dr. Madhavi Tripathi"). */
export function sameName(scholarName: string, expected: string): boolean {
  const shown = new Set(nameTokens(scholarName));
  const wanted = nameTokens(expected);
  return wanted.length > 0 && wanted.every((token) => shown.has(token));
}

/* ------------------------------------------------------------------------------------------------
   A small HTML reader: enough for Scholar's markup, not a general parser
   ------------------------------------------------------------------------------------------------ */

type Attrs = Record<string, string>;
interface Element {
  attrs: Attrs;
  inner: string;
  /** Offsets of the whole element in the searched string. */
  start: number;
  end: number;
}

// An unquoted value runs to white space or ">", as in HTML ("=" and "/" included).
const ATTR = /([^\s"'<>/=]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'<>`]+)))?/g;
const VOID_TAGS = new Set(["br", "img", "input", "link", "meta", "hr"]);

function parseAttrs(source: string): Attrs {
  const attrs: Attrs = {};
  for (const m of source.matchAll(ATTR)) {
    const name = m[1].toLowerCase();
    if (!(name in attrs)) attrs[name] = decodeEntities(m[2] ?? m[3] ?? m[4] ?? "");
  }
  return attrs;
}

/** Scripts, styles, and comments removed: Scholar's CSS names every class this module looks for. */
function stripNoise(html: string): string {
  return html
    .replace(/<script\b[\s\S]*?<\/script\s*>/gi, "")
    .replace(/<style\b[\s\S]*?<\/style\s*>/gi, "")
    .replace(/<!--[\s\S]*?-->/g, "");
}

/**
  Every <tag> in `html` whose attributes pass `test`, with its inner HTML; nested tags of the same name are
  counted. As in HTML, only void tags (input, link, ...) have no content: "<div/>" opens a div.
*/
function elements(html: string, tag: string, test: (attrs: Attrs) => boolean = () => true): Element[] {
  const found: Element[] = [];
  const open = new RegExp(`<${tag}(?=[\\s/>])((?:[^>"']|"[^"]*"|'[^']*')*)>`, "gi");
  const edge = new RegExp(`<(/?)${tag}(?=[\\s/>])(?:[^>"']|"[^"]*"|'[^']*')*>`, "gi");
  for (const m of html.matchAll(open)) {
    // A trailing "/" after white space or a quote is the self-closing mark, not part of a value.
    const attrs = parseAttrs(m[1].replace(/(^|[\s"'])\/\s*$/, "$1"));
    if (!test(attrs)) continue;
    const start = m.index ?? 0;
    const contentStart = start + m[0].length;
    if (VOID_TAGS.has(tag)) {
      found.push({ attrs, inner: "", start, end: contentStart });
      continue;
    }
    edge.lastIndex = contentStart;
    let depth = 1;
    let contentEnd = html.length;
    let end = html.length;
    for (let e = edge.exec(html); e; e = edge.exec(html)) {
      if (!e[1]) {
        depth++;
      } else if (--depth === 0) {
        contentEnd = e.index;
        end = e.index + e[0].length;
        break;
      }
    }
    found.push({ attrs, inner: html.slice(contentStart, contentEnd), start, end });
  }
  return found;
}

const withClass = (name: string) => (attrs: Attrs) => (attrs.class ?? "").split(/\s+/).includes(name);
const withId = (id: string) => (attrs: Attrs) => attrs.id === id;

function one(html: string, tag: string, test: (attrs: Attrs) => boolean, what: string): Element {
  const found = elements(html, tag, test);
  if (!found.length) throw new ScholarParseError(`${what} not found`);
  return found[0];
}

/** "1,234" or "1234" → 1234; "" → null; anything else throws. */
function count(text: string, what: string): number | null {
  const digits = text.replace(/[,\s\u00a0]/g, "");
  if (!digits) return null;
  if (!/^\d+$/.test(digits)) throw new ScholarParseError(`${what}: "${text}" is not a number`);
  return Number(digits);
}

function required(text: string, what: string): number {
  const value = count(text, what);
  if (value === null) throw new ScholarParseError(`${what} is empty`);
  return value;
}

/** A query parameter from an href as written in the page (relative or absolute). */
function param(href: string, name: string): string | null {
  try {
    return new URL(href, "https://scholar.google.com/").searchParams.get(name);
  } catch {
    return null;
  }
}

/* ------------------------------------------------------------------------------------------------
   The profile page
   ------------------------------------------------------------------------------------------------ */

export type ParsedArticle = Omit<ScholarArticle, "pub">;

/** What one read of Scholar gives, before the articles are matched to the site's publications. */
export interface ParsedProfile {
  profile: ScholarSnapshot["profile"];
  totals: ScholarSnapshot["totals"];
  recent: ScholarSnapshot["recent"];
  byYear: ScholarSnapshot["byYear"];
  articles: ParsedArticle[];
  /**
    False when Scholar has more articles than it listed (its "Show more" button is enabled, or SerpApi offers a
    next page). The page as requested lists 20; the sync then prefers SerpApi (100) when it has a key.
  */
  complete: boolean;
}

/**
  Why a response is not the profile page, or null when it is. Google's refusals: HTTP 429, 403, or 503;
  a redirect (to /sorry/ or elsewhere); an "unusual traffic" or "automated queries" page; a CAPTCHA form;
  or a page without the profile's name element (#gsc_prf_in) or any other part of the profile. A 200 page
  that has some of the profile's markup but not the name is left to parseProfile, which reports what's missing:
  that is Google changing the page, not refusing it.
*/
export function detectBlock(status: number, html: string, location?: string | null): string | null {
  const page = stripNoise(html);
  // A 200 with the profile's name element is the profile, whatever else the page mentions.
  const hasName = elements(page, "div", withId("gsc_prf_in")).length > 0;
  if (status === 200 && hasName) return null;
  const profileParts =
    elements(page, "table", withId("gsc_rsb_st")).length +
    elements(page, "tbody", withId("gsc_a_b")).length +
    elements(page, "div", withId("gsc_prf")).length +
    elements(page, "link", (a) => (a.rel ?? "").toLowerCase() === "canonical" && /\/citations\?(?:[^#]*&)?user=/.test(a.href ?? "")).length;
  const visible = textOf(page);
  const captcha =
    /<form\b[^>]*\bid=["']?(?:captcha-form|gs_captcha_f)\b/i.test(page) ||
    /\bg-recaptcha\b/i.test(page) ||
    /<div\b[^>]*\bid=["']?recaptcha\b/i.test(page) ||
    /google\.com\/recaptcha\//i.test(html);
  const unusual = /unusual traffic/i.test(visible);
  const automated = /automated queries/i.test(visible);
  const sorry = /\/sorry\//i.test(location ?? "") || /<form\b[^>]*\baction=["']?[^"'>]*\/sorry\//i.test(page);
  const signs = [
    unusual && '"unusual traffic" page',
    automated && '"automated queries" page',
    captcha && "CAPTCHA",
    sorry && "Google's /sorry/ page",
  ].filter(Boolean);
  const also = signs.length ? ` (${signs.join(", ")})` : "";
  if (status === 200 && profileParts > 0 && !signs.length) return null;

  if (status === 429) return `HTTP 429 Too Many Requests: Google is limiting requests from this address${also}`;
  if (status === 403) return `HTTP 403 Forbidden: Google refused the request${also}`;
  if (status === 503) return `HTTP 503 Service Unavailable: Google refused or couldn't serve the request${also}`;
  if (status >= 300 && status < 400) {
    const where = location ? ` to ${location.split("?")[0]}` : "";
    return `HTTP ${status}: redirected${where} instead of the profile${also}`;
  }
  if (status === 404) return "HTTP 404: the profile was not found (made private, deleted, or a wrong id in person.ts?)";
  if (status !== 200) return `HTTP ${status} from Google Scholar${also}`;
  if (signs.length) return `Google answered with a block page${also}`;
  return "the page is not the profile (no #gsc_prf_in): probably a consent, error, or block page";
}

/** Reads the whole profile page. Throws ScholarParseError when a part is missing or doesn't add up. */
export function parseProfile(rawHtml: string): ParsedProfile {
  const html = stripNoise(rawHtml);
  const name = textOf(one(html, "div", withId("gsc_prf_in"), "The profile name (#gsc_prf_in)").inner);
  if (!name) throw new ScholarParseError("The profile name (#gsc_prf_in) is empty");
  const id = profileIdOf(html);
  const { totals, recent } = parseTotals(one(html, "table", withId("gsc_rsb_st"), "The Cited by table (#gsc_rsb_st)").inner);
  const histogram = elements(html, "div", withClass("gsc_md_hist_b"));
  if (!histogram.length && totals.citations > 0) {
    throw new ScholarParseError("The citations-per-year chart (.gsc_md_hist_b) not found, though the profile has citations");
  }
  const byYear = histogram.length ? parseHistogram(histogram[0].inner) : [];
  const { articles, complete } = parseArticles(html);
  return { profile: { id, url: profileUrl(id), name }, totals, recent, byYear, articles, complete };
}

/** From the canonical link, else the page's hidden "user" field, else the articles' ids. */
function profileIdOf(html: string): string {
  const canonical = elements(html, "link", (a) => (a.rel ?? "").toLowerCase() === "canonical")[0];
  const fromLink = canonical ? param(canonical.attrs.href ?? "", "user") : null;
  const fromInput = elements(html, "input", (a) => a.name === "user")[0]?.attrs.value;
  const fromArticle = /citation_for_view=([\w-]+):/.exec(decodeEntities(html))?.[1];
  const id = fromLink ?? fromInput ?? fromArticle;
  if (!id || !PROFILE_ID.test(id)) throw new ScholarParseError("The profile id (canonical link, user field, or article ids) not found");
  return id;
}

const METRIC_ROWS: Readonly<Record<string, "citations" | "hIndex" | "i10Index">> = {
  citations: "citations",
  "h-index": "hIndex",
  "i10-index": "i10Index",
};

function parseTotals(table: string): Pick<ScholarSnapshot, "totals" | "recent"> {
  const headers = elements(table, "th").map((th) => textOf(th.inner));
  const sinceText = headers.find((h) => /^Since \d{4}$/.test(h));
  if (!sinceText || !headers.includes("All")) {
    throw new ScholarParseError(`The Cited by table's columns are not "All" and "Since <year>" (found ${JSON.stringify(headers)})`);
  }
  const all: Partial<Record<"citations" | "hIndex" | "i10Index", number>> = {};
  const since: Partial<Record<"citations" | "hIndex" | "i10Index", number>> = {};
  for (const row of elements(table, "tr")) {
    const label = textOf(elements(row.inner, "td", withClass("gsc_rsb_sc1"))[0]?.inner ?? "").toLowerCase();
    if (!Object.hasOwn(METRIC_ROWS, label)) continue;
    const key = METRIC_ROWS[label];
    const cells = elements(row.inner, "td", withClass("gsc_rsb_std")).map((td) => textOf(td.inner));
    if (cells.length !== 2) throw new ScholarParseError(`The Cited by table's ${label} row has ${cells.length} values, not 2`);
    all[key] = required(cells[0], `${label} (all)`);
    since[key] = required(cells[1], `${label} (${sinceText})`);
  }
  const missing = Object.keys(METRIC_ROWS).filter((label) => all[METRIC_ROWS[label]] === undefined);
  if (missing.length) throw new ScholarParseError(`The Cited by table has no ${missing.join(", ")} row`);
  return {
    totals: { citations: all.citations ?? 0, hIndex: all.hIndex ?? 0, i10Index: all.i10Index ?? 0 },
    recent: {
      since: Number(sinceText.slice(-4)),
      citations: since.citations ?? 0,
      hIndex: since.hIndex ?? 0,
      i10Index: since.i10Index ?? 0,
    },
  };
}

const rightOffset = (attrs: Attrs) => {
  const m = /(?:^|;)\s*right\s*:\s*(-?\d+(?:\.\d+)?)px/i.exec(attrs.style ?? "");
  return m ? Number(m[1]) : null;
};

/**
  Citations per year, oldest first, zero-filled from the first to the last year label. Labels and bars are
  both placed by `right:` (the chart is right-to-left, one column per year); every bar sits the same few
  pixels left of its label (5 today, a larger `right:`). The labels fix the column width, and each bar takes
  the year of the column it falls in, so a year without a bar, anywhere in the chart, can't shift the others.
  An offset near half a column would be ambiguous (which label is the bar's?), so anything outside
  0 to 0.4 of a column to the left is a parse fault rather than a guess.
*/
export function parseHistogram(chart: string): ScholarSnapshot["byYear"] {
  const labels = elements(chart, "span", withClass("gsc_g_t")).map((span) => {
    const year = Number(textOf(span.inner));
    const right = rightOffset(span.attrs);
    if (!Number.isInteger(year) || year < 1900 || right === null) {
      throw new ScholarParseError(`A year label in the chart is unreadable: "${textOf(span.inner)}" at ${span.attrs.style ?? "no style"}`);
    }
    return { year, right };
  });
  if (!labels.length) throw new ScholarParseError("The citations-per-year chart has no year labels (span.gsc_g_t)");
  labels.sort((a, b) => a.year - b.year);
  const first = labels[0];
  const last = labels[labels.length - 1];
  // Pixels per year, from the labels; every label must sit on that grid.
  const step = labels.length > 1 ? (first.right - last.right) / (last.year - first.year) : 32;
  if (!(step > 0)) throw new ScholarParseError("The chart's year labels are not laid out right to left");
  for (const label of labels) {
    const expected = last.right + (last.year - label.year) * step;
    if (Math.abs(label.right - expected) > 2) throw new ScholarParseError(`The chart's year labels are unevenly spaced (${label.year})`);
  }
  const bars = elements(chart, "a", withClass("gsc_g_a")).map((bar) => {
    const right = rightOffset(bar.attrs);
    const value = elements(bar.inner, "span", withClass("gsc_g_al"))[0];
    if (right === null || !value) throw new ScholarParseError(`A bar in the chart is unreadable: ${bar.attrs.style ?? "no style"}`);
    // Columns to the left of the last label's column; a whole number plus the bar's constant offset.
    return { right, columns: (last.right - right) / step, text: textOf(value.inner) };
  });
  // The bars' common offset, as a fraction of a column: negative when they sit left of their labels (today -0.16).
  const fractions = bars.map((b) => b.columns - Math.round(b.columns)).sort((a, b) => a - b);
  const shift = fractions.length ? fractions[Math.floor(fractions.length / 2)] : 0;
  if (!(shift > -0.4 && shift <= 0.05)) {
    throw new ScholarParseError(`The chart's bars sit ${Math.round(-shift * step)}px off their year labels, too far to tell their years apart`);
  }
  const counts = new Map<number, number>();
  for (const bar of bars) {
    const columns = bar.columns - shift;
    if (Math.abs(columns - Math.round(columns)) > 0.2) throw new ScholarParseError(`A bar in the chart (right:${bar.right}px) falls between two years`);
    const year = last.year + Math.round(columns);
    if (year < first.year || year > last.year) throw new ScholarParseError(`A bar in the chart (right:${bar.right}px) is outside the labeled years`);
    if (counts.has(year)) throw new ScholarParseError(`Two bars in the chart fall on ${year}`);
    counts.set(year, required(bar.text, `The chart's bar for ${year}`));
  }
  const byYear: ScholarSnapshot["byYear"] = [];
  for (let year = first.year; year <= last.year; year++) byYear.push({ year, citations: counts.get(year) ?? 0 });
  return byYear;
}

function parseArticles(html: string): { articles: ParsedArticle[]; complete: boolean } {
  const body = one(html, "tbody", withId("gsc_a_b"), "The article list (tbody#gsc_a_b)").inner;
  const rows = elements(body, "tr", withClass("gsc_a_tr"));
  const articles = rows.map((row, i) => parseArticle(row.inner, i + 1));

  // "Articles 1–15": the page's own count of the rows it shows.
  const shown = elements(html, "span", withId("gsc_a_nn"))[0];
  const range = shown ? /(\d+)\D+(\d+)/.exec(textOf(shown.inner)) : null;
  if (range && Number(range[2]) - Number(range[1]) + 1 !== rows.length) {
    throw new ScholarParseError(`The page lists "${textOf(shown?.inner ?? "")}" but ${rows.length} article rows were read`);
  }
  const more = elements(html, "button", withId("gsc_bpf_more"))[0];
  const complete = more ? "disabled" in more.attrs : rows.length < 20;
  return { articles, complete };
}

function parseArticle(row: string, n: number): ParsedArticle {
  const where = `Article row ${n}`;
  const link = one(row, "a", withClass("gsc_a_at"), `${where}: the title link (a.gsc_a_at)`);
  const title = textOf(link.inner);
  // Scholar has put the article's address in data-href (with href="javascript:void(0)") in some layouts.
  const id = param(link.attrs.href ?? "", "citation_for_view") ?? param(link.attrs["data-href"] ?? "", "citation_for_view");
  if (!title) throw new ScholarParseError(`${where}: the title is empty`);
  if (!id || !/^[\w-]+:[\w-]+$/.test(id)) throw new ScholarParseError(`${where}: no Scholar id (citation_for_view) in the title link`);

  const gray = elements(row, "div", withClass("gs_gray"));
  if (gray.length !== 2) throw new ScholarParseError(`${where} ("${title}"): ${gray.length} gray lines, not 2 (authors, venue)`);
  const authors = textOf(gray[0].inner);
  // The venue line ends with the year in span.gs_oph (", 2022"), shown only on phones: drop it (outermost spans
  // only, from the end, so the offsets stay valid).
  let venueHtml = gray[1].inner;
  const years = elements(venueHtml, "span", withClass("gs_oph"));
  const outermost = years.filter((s) => !years.some((o) => o !== s && o.start <= s.start && s.end <= o.end));
  for (const span of outermost.reverse()) venueHtml = venueHtml.slice(0, span.start) + venueHtml.slice(span.end);
  const venue = textOf(venueHtml);

  const cited = one(row, "a", withClass("gsc_a_ac"), `${where} ("${title}"): the Cited by link (a.gsc_a_ac)`);
  const citedBy = count(textOf(cited.inner), `${where}: Cited by`) ?? 0;
  const article: ParsedArticle = { id, title, authors, venue, year: null, citedBy };
  if (citedBy > 0) {
    const cites = param(cited.attrs.href ?? "", "cites");
    if (!cites || !/^\d+(,\d+)*$/.test(cites)) throw new ScholarParseError(`${where} ("${title}"): no cites= id in the Cited by link`);
    article.citedByUrl = citedByUrl(cites);
  }
  const yearText = textOf(one(row, "span", withClass("gsc_a_h"), `${where} ("${title}"): the year (span.gsc_a_h)`).inner);
  if (yearText && !/^\d{4}$/.test(yearText)) throw new ScholarParseError(`${where} ("${title}"): the year "${yearText}" is not a year`);
  article.year = yearText ? Number(yearText) : null;
  return article;
}

/* ------------------------------------------------------------------------------------------------
   SerpApi's Google Scholar Author API (the fallback when Google refuses the page)
   ------------------------------------------------------------------------------------------------ */

type Json = Record<string, unknown>;
const isRecord = (value: unknown): value is Json => typeof value === "object" && value !== null && !Array.isArray(value);
const stringOr = (value: unknown, fallback = "") => (typeof value === "string" ? value : fallback);

/**
  Maps the JSON of https://serpapi.com/search.json?engine=google_scholar_author&author_id=<id>&hl=en&num=100
  (shape from SerpApi's documentation; untested against a live key). Throws ScholarParseError on an error
  response or a missing part.
*/
export function fromSerpApi(json: unknown): ParsedProfile {
  if (!isRecord(json)) throw new ScholarParseError("SerpApi: the response is not a JSON object");
  if (typeof json.error === "string") throw new ScholarParseError(`SerpApi: ${oneLine(json.error)}`);
  const status = isRecord(json.search_metadata) ? json.search_metadata.status : undefined;
  if (status !== undefined && status !== "Success") throw new ScholarParseError(`SerpApi: search status ${JSON.stringify(status)}`);
  if (!isRecord(json.author)) throw new ScholarParseError("SerpApi: no author in the response");
  const name = oneLine(stringOr(json.author.name));
  if (!name) throw new ScholarParseError("SerpApi: the author has no name");

  const rawArticles = Array.isArray(json.articles) ? json.articles : [];
  const articles = rawArticles.map((raw, i) => serpArticle(raw, i + 1));
  const requested = isRecord(json.search_parameters) ? stringOr(json.search_parameters.author_id) : "";
  const id = requested || (articles[0]?.id.split(":")[0] ?? "");
  if (!PROFILE_ID.test(id)) throw new ScholarParseError("SerpApi: no author id in the response");

  const citedBy = isRecord(json.cited_by) ? json.cited_by : {};
  // Documented as a list of one-key objects ([{ citations: {...} }, { h_index: {...} }, ...]); a plain object is accepted too.
  const table: Json = {};
  for (const entry of Array.isArray(citedBy.table) ? citedBy.table : [citedBy.table]) {
    if (isRecord(entry)) Object.assign(table, entry);
  }
  const metric = (key: string) => {
    const cell = table[key];
    if (!isRecord(cell) || typeof cell.all !== "number") throw new ScholarParseError(`SerpApi: no ${key} in cited_by.table`);
    const sinceKey = Object.keys(cell).find((k) => /^since_\d{4}$/.test(k));
    const recentValue = sinceKey ? cell[sinceKey] : undefined;
    if (!sinceKey || typeof recentValue !== "number") throw new ScholarParseError(`SerpApi: no since_<year> value for ${key}`);
    return { all: cell.all, recent: recentValue, since: Number(sinceKey.slice(-4)) };
  };
  const citations = metric("citations");
  const hIndex = metric("h_index");
  const i10Index = metric("i10_index");

  const graph = (Array.isArray(citedBy.graph) ? citedBy.graph : []).map((point) => {
    if (!isRecord(point) || !Number.isInteger(point.year) || !Number.isInteger(point.citations)) {
      throw new ScholarParseError("SerpApi: an unreadable point in cited_by.graph");
    }
    return { year: point.year as number, citations: point.citations as number };
  });
  const byYear: ScholarSnapshot["byYear"] = [];
  if (graph.length) {
    const years = graph.map((p) => p.year);
    const counts = new Map(graph.map((p) => [p.year, p.citations]));
    for (let year = Math.min(...years); year <= Math.max(...years); year++) byYear.push({ year, citations: counts.get(year) ?? 0 });
  }

  const pagination = isRecord(json.serpapi_pagination) ? json.serpapi_pagination : {};
  return {
    profile: { id, url: profileUrl(id), name },
    totals: { citations: citations.all, hIndex: hIndex.all, i10Index: i10Index.all },
    recent: { since: citations.since, citations: citations.recent, hIndex: hIndex.recent, i10Index: i10Index.recent },
    byYear,
    articles,
    complete: typeof pagination.next !== "string",
  };
}

function serpArticle(raw: unknown, n: number): ParsedArticle {
  if (!isRecord(raw)) throw new ScholarParseError(`SerpApi: article ${n} is not an object`);
  const id = stringOr(raw.citation_id);
  const title = oneLine(stringOr(raw.title));
  if (!/^[\w-]+:[\w-]+$/.test(id) || !title) throw new ScholarParseError(`SerpApi: article ${n} has no citation_id or title`);
  const yearText = stringOr(raw.year, typeof raw.year === "number" ? String(raw.year) : "").trim();
  const year = /^\d{4}$/.test(yearText) ? Number(yearText) : null;
  // "Archives of general psychiatry 62 (6), 593-602, 2005": the profile page shows the venue without the year.
  // Only a ", <year>" ending goes ("... Imaging and Sensing 2026" keeps its year); a bare year is no venue.
  let venue = oneLine(stringOr(raw.publication));
  if (year !== null) venue = venue === String(year) ? "" : venue.replace(new RegExp(`,\\s*${year}$`), "");
  const cited = isRecord(raw.cited_by) ? raw.cited_by : {};
  const citedBy = Number.isInteger(cited.value) && (cited.value as number) > 0 ? (cited.value as number) : 0;
  const article: ParsedArticle = { id, title, authors: oneLine(stringOr(raw.authors)), venue, year, citedBy };
  if (citedBy > 0) {
    const cites = stringOr(cited.cites_id) || (param(stringOr(cited.link), "cites") ?? "");
    if (!/^\d+(,\d+)*$/.test(cites)) throw new ScholarParseError(`SerpApi: article ${n} ("${title}") has citations but no cites id`);
    article.citedByUrl = citedByUrl(cites);
  }
  return article;
}

/* ------------------------------------------------------------------------------------------------
   Matching Scholar's entries to the site's publications
   ------------------------------------------------------------------------------------------------ */

/** The fields of a src/content/publications.ts record that matching needs. */
export interface PubRef {
  id: string;
  title: string;
  year: number;
}

export interface Matched {
  /** Scholar's entries in Scholar's order, each with the site's publication id or null. */
  articles: ScholarArticle[];
  /** Site publications no Scholar entry matched. */
  missing: string[];
  /** Duplicates and overrides worth reading. */
  notes: string[];
}

/**
  Pairs each Scholar entry with a site publication: an explicit override first, else equal normalized titles
  with an equal year, or no year on Scholar (the thesis has none). Each publication is claimed at most once;
  when Scholar lists a paper twice, the better match (same year, then more citations) keeps it.
*/
export function matchArticles(articles: ParsedArticle[], publications: PubRef[], overrides: Readonly<Record<string, string>> = OVERRIDES): Matched {
  const notes: string[] = [];
  const byKey = new Map<string, PubRef[]>();
  for (const pub of publications) {
    const key = normalizeTitle(pub.title);
    byKey.set(key, [...(byKey.get(key) ?? []), pub]);
  }
  const byId = new Map(publications.map((p) => [p.id, p]));
  type Choice = { pub: PubRef; rank: number };
  const choices = articles.map((article): Choice | null => {
    const forced = Object.hasOwn(overrides, article.id) ? overrides[article.id] : undefined;
    if (forced) {
      const pub = byId.get(forced);
      if (pub) return { pub, rank: 3 };
      notes.push(`OVERRIDES maps ${article.id} to "${forced}", which is not in publications.ts`);
    }
    const candidates = (byKey.get(normalizeTitle(article.title)) ?? []).filter((p) => article.year === null || article.year === p.year);
    if (candidates.length > 1) {
      notes.push(`"${article.title}" matches ${candidates.map((p) => p.id).join(" and ")}: add it to OVERRIDES`);
      return null;
    }
    return candidates.length ? { pub: candidates[0], rank: article.year === null ? 1 : 2 } : null;
  });

  // One Scholar entry per publication: the higher rank, then more citations, then the smaller id.
  const beats = (i: number, j: number) => {
    const [a, b] = [choices[i] as Choice, choices[j] as Choice];
    if (a.rank !== b.rank) return a.rank > b.rank;
    if (articles[i].citedBy !== articles[j].citedBy) return articles[i].citedBy > articles[j].citedBy;
    return articles[i].id < articles[j].id;
  };
  const winner = new Map<string, number>();
  choices.forEach((choice, i) => {
    if (!choice) return;
    const held = winner.get(choice.pub.id);
    if (held === undefined) {
      winner.set(choice.pub.id, i);
      return;
    }
    const [kept, dropped] = beats(i, held) ? [i, held] : [held, i];
    winner.set(choice.pub.id, kept);
    notes.push(
      `Scholar lists "${articles[dropped].title}" twice (${articles[kept].id} kept, ${articles[dropped].id} not matched): merge the versions on Scholar`,
    );
  });
  const pubOf = new Map([...winner].map(([pubId, i]) => [i, pubId]));
  return {
    articles: articles.map((article, i) => ({ ...article, pub: pubOf.get(i) ?? null })),
    missing: publications.filter((p) => !winner.has(p.id)).map((p) => p.id),
    notes,
  };
}

/* ------------------------------------------------------------------------------------------------
   Checks
   ------------------------------------------------------------------------------------------------ */

export interface Verdict {
  errors: string[];
  warnings: string[];
}

const isCount = (value: unknown): value is number => Number.isInteger(value) && (value as number) >= 0;
/** An exact UTC time to the second ("2026-09-28T10:14:54Z"), and a real one (no 30 February). */
export const isIsoSeconds = (value: unknown): value is string =>
  typeof value === "string" &&
  /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/.test(value) &&
  !Number.isNaN(Date.parse(value)) &&
  isoSeconds(new Date(value)) === value;
/** How far ahead of this machine's clock a checkedAt may be before it counts as "in the future". */
const CLOCK_SLACK_MS = 10 * 60_000;
const CITED_BY_URL = /^https:\/\/scholar\.google\.com\/scholar\?cites=\d+(,\d+)*&hl=en$/;
const ARTICLE_KEYS = new Set(["id", "title", "authors", "venue", "year", "citedBy", "citedByUrl", "pub"]);

/** Everything the file format promises (src/content/scholar.ts), checked on untrusted JSON. */
export function shapeErrors(value: unknown): string[] {
  const errors: string[] = [];
  const bad = (where: string, what: string) => errors.push(`${where}: ${what}`);
  if (!isRecord(value)) return ["the snapshot is not a JSON object"];

  if (value.schema !== SCHEMA) bad("schema", `must be ${SCHEMA}, is ${JSON.stringify(value.schema)}`);
  const profile = isRecord(value.profile) ? value.profile : null;
  const profileId = typeof profile?.id === "string" && PROFILE_ID.test(profile.id) ? profile.id : null;
  if (!profile) bad("profile", "missing");
  else {
    if (!profileId) bad("profile.id", `${JSON.stringify(profile.id)} is not a Scholar user id`);
    else if (profile.url !== profileUrl(profileId)) bad("profile.url", `must be ${profileUrl(profileId)}`);
    if (typeof profile.name !== "string" || !profile.name.trim()) bad("profile.name", "missing");
  }
  if (value.source !== "profile-page" && value.source !== "serpapi") bad("source", `must be "profile-page" or "serpapi"`);
  if (!isIsoSeconds(value.checkedAt)) bad("checkedAt", "must be an ISO 8601 UTC time such as 2026-09-28T10:14:54Z");

  const totals = isRecord(value.totals) ? value.totals : null;
  if (!totals) bad("totals", "missing");
  else for (const key of ["citations", "hIndex", "i10Index"]) if (!isCount(totals[key])) bad(`totals.${key}`, "must be a non-negative integer");
  const recent = isRecord(value.recent) ? value.recent : null;
  if (!recent) bad("recent", "missing");
  else {
    if (!Number.isInteger(recent.since) || (recent.since as number) < 1900 || (recent.since as number) > 2200) bad("recent.since", "must be a year");
    for (const key of ["citations", "hIndex", "i10Index"]) if (!isCount(recent[key])) bad(`recent.${key}`, "must be a non-negative integer");
  }

  if (!Array.isArray(value.byYear)) bad("byYear", "must be a list");
  else {
    const years: unknown[] = value.byYear;
    years.forEach((entry, i) => {
      if (!isRecord(entry) || !Number.isInteger(entry.year) || !isCount(entry.citations) || Object.keys(entry).length !== 2) {
        bad(`byYear[${i}]`, "must be { year, citations } with a non-negative integer count");
        return;
      }
      const before = years[i - 1];
      if (isRecord(before) && Number.isInteger(before.year) && entry.year !== (before.year as number) + 1) {
        bad(`byYear[${i}]`, `${entry.year} follows ${before.year}: years must ascend one by one (zero-filled)`);
      }
    });
    if (!years.length && totals && isCount(totals.citations) && totals.citations > 0) bad("byYear", "empty, though there are citations");
  }

  if (!Array.isArray(value.articles)) bad("articles", "must be a list");
  else {
    const ids = new Set<string>();
    const pubs = new Map<string, string>();
    const articles: unknown[] = value.articles;
    articles.forEach((article, i) => {
      const where = `articles[${i}]`;
      if (!isRecord(article)) {
        bad(where, "must be an object");
        return;
      }
      const extra = Object.keys(article).filter((k) => !ARTICLE_KEYS.has(k));
      if (extra.length) bad(where, `unexpected ${extra.join(", ")}`);
      const id = typeof article.id === "string" ? article.id : "";
      if (!/^[\w-]+:[\w-]+$/.test(id)) bad(`${where}.id`, "must be Scholar's citation id (<user>:<article>)");
      else if (profileId && !id.startsWith(`${profileId}:`)) bad(`${where}.id`, `${id} belongs to another profile`);
      if (ids.has(id)) bad(`${where}.id`, `${id} appears twice`);
      ids.add(id);
      if (typeof article.title !== "string" || !article.title.trim()) bad(`${where}.title`, "missing");
      if (typeof article.authors !== "string") bad(`${where}.authors`, "must be text");
      if (typeof article.venue !== "string") bad(`${where}.venue`, "must be text (may be empty)");
      if (article.year !== null && (!Number.isInteger(article.year) || (article.year as number) < 1800 || (article.year as number) > 2200)) {
        bad(`${where}.year`, "must be a year or null");
      }
      if (!isCount(article.citedBy)) bad(`${where}.citedBy`, "must be a non-negative integer");
      else if (article.citedBy > 0 && (typeof article.citedByUrl !== "string" || !CITED_BY_URL.test(article.citedByUrl))) {
        bad(`${where}.citedByUrl`, "must be https://scholar.google.com/scholar?cites=<id>&hl=en when citedBy > 0");
      } else if (article.citedBy === 0 && "citedByUrl" in article) bad(`${where}.citedByUrl`, "must be absent when citedBy is 0");
      if (article.pub !== null && (typeof article.pub !== "string" || !article.pub)) bad(`${where}.pub`, "must be a publication id or null");
      else if (typeof article.pub === "string") {
        if (pubs.has(article.pub)) bad(`${where}.pub`, `"${article.pub}" is also claimed by ${pubs.get(article.pub)}`);
        pubs.set(article.pub, id);
      }
    });
  }
  return errors;
}

const pct = (from: number, to: number) => `${Math.round(((from - to) / from) * 1000) / 10}%`;

/**
  Whether a freshly read snapshot may replace the committed one. Errors: a malformed snapshot, another
  profile or name, no articles, figures that can't be true together, a read time in the future, a read older
  than the committed one, and a drop of more than 10% in total citations or in the article count (usually a
  parse fault, or a namesake's papers merged into the profile and then removed): `force` turns the last three
  into warnings. `incomplete`: the read lists only part of the profile (the page's first 20 articles).
*/
export function validate(
  next: ScholarSnapshot,
  previous: ScholarSnapshot | undefined,
  options: { profileId: string; name: string; force?: boolean; incomplete?: boolean; now?: Date },
): Verdict {
  const errors = shapeErrors(next);
  const warnings: string[] = [];
  const unlessForced = (message: string) => (options.force ? warnings.push(`${message} (accepted with --force)`) : errors.push(message));
  const now = options.now ?? new Date();

  if (Date.parse(next.checkedAt) > now.getTime() + CLOCK_SLACK_MS) errors.push(`the read time ${next.checkedAt} is in the future`);
  if (next.profile.id !== options.profileId) errors.push(`profile ${next.profile.id} is not the site's profile ${options.profileId}`);
  if (!sameName(next.profile.name, options.name)) errors.push(`Scholar's name "${next.profile.name}" is not "${options.name}"`);
  if (!next.articles.length) errors.push("Scholar listed no articles");
  const { totals, recent } = next;
  if (recent.citations > totals.citations || recent.hIndex > totals.hIndex || recent.i10Index > totals.i10Index) {
    errors.push(`the since-${recent.since} figures exceed the all-time ones: a parse fault`);
  }
  // Fewer than 10 papers with 10 or more citations each means the h-index counts at least all of them.
  if (totals.i10Index > totals.hIndex && totals.hIndex < 10) errors.push("the i10-index exceeds an h-index below 10: a parse fault");
  if (recent.i10Index > recent.hIndex && recent.hIndex < 10) errors.push(`the since-${recent.since} i10-index exceeds its h-index: a parse fault`);
  const perYear = next.byYear.reduce((sum, y) => sum + y.citations, 0);
  if (perYear > totals.citations) warnings.push(`citations per year add up to ${perYear}, more than the ${totals.citations} in total`);

  if (previous && previous.profile.id === next.profile.id) {
    if (next.checkedAt < previous.checkedAt) unlessForced(`this read (${next.checkedAt}) is older than the committed snapshot (${previous.checkedAt})`);
    const before = previous.totals.citations;
    if (before > 0 && totals.citations < before * (1 - MAX_DROP)) {
      unlessForced(`total citations fell from ${before} to ${totals.citations} (${pct(before, totals.citations)}), more than ${MAX_DROP * 100}%`);
    } else if (totals.citations < before) warnings.push(`total citations fell from ${before} to ${totals.citations} (Scholar does remove some)`);
    const had = previous.articles.length;
    const partly = options.incomplete ? "; this read lists only part of the profile (the page shows 20 articles; SerpApi lists 100)" : "";
    if (had > 0 && next.articles.length < had * (1 - MAX_DROP)) {
      unlessForced(`the article count fell from ${had} to ${next.articles.length} (${pct(had, next.articles.length)}), more than ${MAX_DROP * 100}%${partly}`);
    } else if (next.articles.length < had) warnings.push(`the article count fell from ${had} to ${next.articles.length}${partly}`);
  } else if (previous) {
    warnings.push(`the committed snapshot is for profile ${previous.profile.id}; it will be replaced`);
  }
  return { errors, warnings };
}

/** Scholar entries the site doesn't show, leaving out the ones in IGNORED. */
export const unlistedOf = (snapshot: ScholarSnapshot, ignored: Readonly<Record<string, string>> = IGNORED) =>
  snapshot.articles.filter((a) => a.pub === null && !Object.hasOwn(ignored, a.id));

/**
  The same snapshot with every entry paired again with today's publications.ts and OVERRIDES: what
  `--rematch` writes after a paper is removed, renamed, or added, without asking Scholar again.
*/
export function rematch(snapshot: ScholarSnapshot, publications: PubRef[], overrides: Readonly<Record<string, string>> = OVERRIDES): ScholarSnapshot {
  return { ...snapshot, articles: matchArticles(snapshot.articles, publications, overrides).articles };
}

const REMATCH_HINT = "run `npm run scholar -- --rematch` to pair the snapshot with publications.ts again (no network)";

/**
  The offline check of a committed snapshot (`--check`, before every build): its shape, the profile in
  src/content/person.ts, and publication ids that exist, each claimed once. Warnings: Scholar entries the site
  doesn't list, site papers Scholar doesn't list, pairings that today's matching would make differently, and a
  snapshot older than 14 days.
*/
export function checkSnapshot(
  value: unknown,
  context: { profileId: string; name: string; publications: PubRef[]; now: Date; ignored?: Readonly<Record<string, string>> },
): Verdict {
  const errors = shapeErrors(value);
  const warnings: string[] = [];
  if (errors.length || !isRecord(value)) return { errors, warnings };
  const snapshot = value as unknown as ScholarSnapshot;
  if (snapshot.profile.id !== context.profileId) errors.push(`profile.id ${snapshot.profile.id} is not the Scholar id in person.ts (${context.profileId})`);
  if (!sameName(snapshot.profile.name, context.name)) errors.push(`profile.name "${snapshot.profile.name}" is not "${context.name}"`);
  const known = new Set(context.publications.map((p) => p.id));
  const dangling = snapshot.articles.filter((a) => a.pub !== null && !known.has(a.pub));
  for (const article of dangling) errors.push(`${article.id}: pub "${article.pub}" is not in publications.ts: ${REMATCH_HINT}`);
  const age = context.now.getTime() - Date.parse(snapshot.checkedAt);
  if (age < -CLOCK_SLACK_MS) errors.push(`checkedAt ${snapshot.checkedAt} is in the future`);
  else if (age > STALE_DAYS * 86_400_000) {
    warnings.push(`Scholar was last read ${Math.floor(age / 86_400_000)} days ago (${snapshot.checkedAt}): see docs/scholar-sync.md`);
  }
  const unlisted = unlistedOf(snapshot, context.ignored);
  if (unlisted.length) {
    warnings.push(`Scholar lists ${unlisted.length} entr${unlisted.length === 1 ? "y" : "ies"} the site does not show: ${unlisted.map((a) => `"${a.title}"`).join("; ")}`);
  }
  const claimed = new Set(snapshot.articles.map((a) => a.pub));
  const missing = context.publications.filter((p) => !claimed.has(p.id));
  if (missing.length) warnings.push(`${missing.length} site paper(s) not found on Scholar: ${missing.map((p) => p.id).join(", ")}`);
  if (!dangling.length) {
    const today = rematch(snapshot, context.publications);
    const moved = snapshot.articles.filter((a, i) => a.pub !== today.articles[i].pub).length;
    if (moved) warnings.push(`${moved} entr${moved === 1 ? "y is" : "ies are"} paired differently by today's matching: ${REMATCH_HINT}`);
  }
  return { errors, warnings };
}

/* ------------------------------------------------------------------------------------------------
   Writing
   ------------------------------------------------------------------------------------------------ */

/** Newest first (no year last), then by title, then by id: stable across runs, whatever the counts do. */
function articleOrder(a: ScholarArticle, b: ScholarArticle): number {
  if (a.year !== b.year) return a.year === null ? 1 : b.year === null ? -1 : b.year - a.year;
  const ta = normalizeTitle(a.title);
  const tb = normalizeTitle(b.title);
  if (ta !== tb) return ta < tb ? -1 : 1;
  return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
}

/** The file's exact text: fixed key order, articles in a stable order, 2-space indent, trailing newline. */
export function serializeSnapshot(s: ScholarSnapshot): string {
  const ordered = {
    schema: s.schema,
    profile: { id: s.profile.id, url: s.profile.url, name: s.profile.name },
    source: s.source,
    checkedAt: s.checkedAt,
    totals: { citations: s.totals.citations, hIndex: s.totals.hIndex, i10Index: s.totals.i10Index },
    recent: { since: s.recent.since, citations: s.recent.citations, hIndex: s.recent.hIndex, i10Index: s.recent.i10Index },
    byYear: [...s.byYear].sort((a, b) => a.year - b.year).map(({ year, citations }) => ({ year, citations })),
    articles: [...s.articles].sort(articleOrder).map((a) => ({
      id: a.id,
      title: a.title,
      authors: a.authors,
      venue: a.venue,
      year: a.year,
      citedBy: a.citedBy,
      ...(a.citedByUrl ? { citedByUrl: a.citedByUrl } : {}),
      pub: a.pub,
    })),
  };
  return `${JSON.stringify(ordered, null, 2)}\n`;
}

/**
  Whether anything Scholar shows differs: checkedAt and source don't count (a read through SerpApi that
  finds the same figures as the page is no change), and neither does article order.
*/
export function dataChanged(a: ScholarSnapshot, b: ScholarSnapshot): boolean {
  const key = (s: ScholarSnapshot) => serializeSnapshot({ ...s, checkedAt: "", source: "profile-page" });
  return key(a) !== key(b);
}

/**
  Why the new snapshot should be written, or null to keep the file as it is: "new" (no snapshot yet),
  "changed" (the data differs), or "refresh" (same data, but the committed checkedAt is more than 20 hours
  older than this read, so the site's "checked" date stays within a day without a commit every 4 hours).
*/
export function needsWrite(previous: ScholarSnapshot | undefined, next: ScholarSnapshot): "new" | "changed" | "refresh" | null {
  if (!previous) return "new";
  if (dataChanged(previous, next)) return "changed";
  return Date.parse(next.checkedAt) - Date.parse(previous.checkedAt) > REFRESH_HOURS * 3_600_000 ? "refresh" : null;
}

/** 2026-09-28T10:14:54.123Z → 2026-09-28T10:14:54Z. */
export const isoSeconds = (date: Date) => date.toISOString().replace(/\.\d{3}Z$/, "Z");

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
/** "28 Sep 2026", in UTC. */
export function dayLabel(iso: string): string {
  const d = new Date(iso);
  return `${d.getUTCDate()} ${MONTHS[d.getUTCMonth()]} ${d.getUTCFullYear()}`;
}

/** Scholar's text as inert Markdown in a table cell: no links, emphasis, code, tags, or @mentions. */
const markdownCell = (value: string) =>
  oneLine(value)
    .replace(/[\\`*_[\]()|]/g, "\\$&")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/@/g, "@​");

/**
  The workflow's issue body: Scholar entries the site doesn't show (less IGNORED), or null when there are none.
  Only fields that rarely change (no counts, no dates), so the issue is edited only when the list changes.
*/
export function unlistedReport(snapshot: ScholarSnapshot, ignored: Readonly<Record<string, string>> = IGNORED): string | null {
  const unlisted = unlistedOf(snapshot, ignored).sort(articleOrder);
  if (!unlisted.length) return null;
  const { profile } = snapshot;
  return [
    `The Google Scholar profile [${markdownCell(profile.name)}](${profile.url}) lists ${unlisted.length === 1 ? "an entry" : `${unlisted.length} entries`} that the site does not show:`,
    "",
    "| Title (as on Scholar) | Authors | Venue | Year | Scholar id |",
    "| --- | --- | --- | --- | --- |",
    ...unlisted.map(
      (a) => `| [${markdownCell(a.title)}](${articleUrl(a.id)}) | ${markdownCell(a.authors)} | ${markdownCell(a.venue)} | ${a.year ?? ""} | \`${a.id}\` |`,
    ),
    "",
    "**Before adding one**, confirm it is Madhavi Tripathi's own work: other researchers publish under the same name, and Scholar sometimes adds their papers to a profile. If it isn't hers, delete it from the Scholar profile.",
    "",
    "**To add one with a DOI**, open Actions → **Add a paper** → **Run workflow**, and enter the DOI and a one-sentence summary.",
    "",
    "**If the site already shows it** under a different title or year, add its Scholar id to `OVERRIDES` in `latest_app/research-hero/scripts/lib/scholar.mts`. **If it is hers but stays off the site** on purpose, add the id to `IGNORED` there, and it leaves this list.",
    "",
    "_Opened by the Google Scholar snapshot workflow, which updates this issue while it stays open._",
    "",
  ].join("\n");
}
