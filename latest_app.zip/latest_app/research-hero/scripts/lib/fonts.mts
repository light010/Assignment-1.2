/*
  Just enough of WOFF2 and the OpenType cmap to answer one question: does this font file have a glyph
  for this character? Used by check-built to prove every character on the page renders in the site's own
  fonts, not a fallback. (WOFF2: https://www.w3.org/TR/WOFF2/; cmap: OpenType spec, formats 4 and 12.)
*/
import zlib from "node:zlib";

const KNOWN_TAGS = [
  "cmap", "head", "hhea", "hmtx", "maxp", "name", "OS/2", "post", "cvt ", "fpgm", "glyf", "loca", "prep", "CFF ", "VORG", "EBDT",
  "EBLC", "gasp", "hdmx", "kern", "LTSH", "PCLT", "VDMX", "vhea", "vmtx", "BASE", "GDEF", "GPOS", "GSUB", "EBSC", "JSTF", "MATH",
  "CBDT", "CBLC", "COLR", "CPAL", "SVG ", "sbix", "acnt", "avar", "bdat", "bloc", "bsln", "cvar", "fdsc", "feat", "fmtx", "fvar",
  "gvar", "hsty", "just", "lcar", "mort", "morx", "opbd", "prop", "trak", "Zapf", "Silf", "Glat", "Gloc", "Feat", "Sill",
];

export interface FontInfo {
  family: string;
  italic: boolean;
  has: (codePoint: number) => boolean;
}

/** Reads the tables out of a WOFF2 file (no glyph data is decoded, only cmap, head, and name). */
export function readWoff2(buf: Buffer): FontInfo {
  if (buf.toString("latin1", 0, 4) !== "wOF2") throw new Error("not a WOFF2 file");
  const numTables = buf.readUInt16BE(12);
  const compressedSize = buf.readUInt32BE(20);
  let pos = 48;
  const base128 = () => {
    let value = 0;
    for (let i = 0; i < 5; i++) {
      const byte = buf[pos++];
      value = value * 128 + (byte & 0x7f);
      if (!(byte & 0x80)) return value;
    }
    throw new Error("bad UIntBase128");
  };
  const tables: { tag: string; length: number }[] = [];
  for (let i = 0; i < numTables; i++) {
    const flags = buf[pos++];
    const tagIndex = flags & 0x3f;
    const version = flags >> 6;
    let tag: string;
    if (tagIndex === 63) {
      tag = buf.toString("latin1", pos, pos + 4);
      pos += 4;
    } else tag = KNOWN_TAGS[tagIndex];
    const origLength = base128();
    // glyf and loca are transformed at version 0; every other table is transformed at versions 1–3.
    const transformed = tag === "glyf" || tag === "loca" ? version !== 3 : version !== 0;
    const length = transformed ? base128() : origLength;
    tables.push({ tag, length });
  }
  const data = zlib.brotliDecompressSync(buf.subarray(pos, pos + compressedSize));
  const table = new Map<string, Buffer>();
  let offset = 0;
  for (const t of tables) {
    table.set(t.tag, data.subarray(offset, offset + t.length));
    offset += t.length;
  }
  const cmap = table.get("cmap");
  const head = table.get("head");
  const name = table.get("name");
  if (!cmap || !head || !name) throw new Error("missing cmap, head, or name");
  return { family: familyName(name), italic: (head.readUInt16BE(44) & 0x02) !== 0, has: cmapLookup(cmap) };
}

function familyName(name: Buffer): string {
  const count = name.readUInt16BE(2);
  const strings = name.readUInt16BE(4);
  let family = "";
  for (let i = 0; i < count; i++) {
    const r = 6 + i * 12;
    const [platform, , , nameId, length, offset] = [0, 2, 4, 6, 8, 10].map((o) => name.readUInt16BE(r + o));
    if (platform !== 3 || (nameId !== 1 && nameId !== 16)) continue;
    const raw = name.subarray(strings + offset, strings + offset + length);
    const text = String.fromCharCode(...Array.from({ length: raw.length / 2 }, (_, k) => raw.readUInt16BE(k * 2)));
    if (nameId === 16 || !family) family = text;
  }
  return family;
}

function cmapLookup(cmap: Buffer): (cp: number) => boolean {
  const count = cmap.readUInt16BE(2);
  const subtables: { platform: number; encoding: number; offset: number; format: number }[] = [];
  for (let i = 0; i < count; i++) {
    const r = 4 + i * 8;
    const offset = cmap.readUInt32BE(r + 4);
    subtables.push({ platform: cmap.readUInt16BE(r), encoding: cmap.readUInt16BE(r + 2), offset, format: cmap.readUInt16BE(offset) });
  }
  const f12 = subtables.find((s) => s.format === 12 && (s.platform === 3 || s.platform === 0));
  if (f12) {
    const groups = cmap.readUInt32BE(f12.offset + 12);
    const ranges: [number, number][] = [];
    for (let g = 0; g < groups; g++) {
      const r = f12.offset + 16 + g * 12;
      ranges.push([cmap.readUInt32BE(r), cmap.readUInt32BE(r + 4)]);
    }
    return (cp) => ranges.some(([a, b]) => cp >= a && cp <= b);
  }
  const f4 = subtables.find((s) => s.format === 4 && (s.platform === 3 || s.platform === 0));
  if (!f4) throw new Error("no Unicode cmap (format 4 or 12)");
  const o = f4.offset;
  const segs = cmap.readUInt16BE(o + 6) / 2;
  const ends = o + 14;
  const starts = ends + segs * 2 + 2;
  const deltas = starts + segs * 2;
  const rangeOffsets = deltas + segs * 2;
  return (cp) => {
    if (cp > 0xffff) return false;
    for (let i = 0; i < segs; i++) {
      const end = cmap.readUInt16BE(ends + i * 2);
      if (cp > end) continue;
      const start = cmap.readUInt16BE(starts + i * 2);
      if (cp < start) return false;
      const delta = cmap.readInt16BE(deltas + i * 2);
      const rangeOffset = cmap.readUInt16BE(rangeOffsets + i * 2);
      if (rangeOffset === 0) return ((cp + delta) & 0xffff) !== 0;
      const glyph = cmap.readUInt16BE(rangeOffsets + i * 2 + rangeOffset + (cp - start) * 2);
      return glyph !== 0 && ((glyph + delta) & 0xffff) !== 0;
    }
    return false;
  };
}
