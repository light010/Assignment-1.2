/*
  Every state the lab can be in, and the metric values its instruments can report, so the checks can
  read every caption, readout, label, and evidence link the visitor could ever see.
*/
import { CHAPTER_ORDER, CHAPTERS, type Metrics } from "../../src/content/chapters.ts";
import { DEFAULT_STATE, type LabState } from "../../src/lab/state.ts";

/** One state per combination of a chapter's controls; the overview has none. */
export function allStates(): LabState[] {
  const states: LabState[] = [{ ...DEFAULT_STATE, chapter: "overview" }];
  for (const chapter of CHAPTER_ORDER) {
    let slices: Record<string, string>[] = [{ ...(DEFAULT_STATE[chapter] as Record<string, string>) }];
    for (const control of CHAPTERS[chapter].controls) {
      slices = slices.flatMap((slice) => control.options.map((o) => ({ ...slice, [control.key]: o.value })));
    }
    for (const slice of slices) states.push({ ...DEFAULT_STATE, chapter, [chapter]: slice } as LabState);
  }
  return states;
}

/** Instrument values that change the wording: none yet, and one value on each side of every cutoff. */
export function metricSamples(s: LabState): Metrics[] {
  if (s.chapter === "ultrasound") return [{}, { gcnr: 0.52 }, { gcnr: 0.91 }];
  if (s.chapter === "photoacoustic")
    return [{}, { light: 0.1, clutter: 0.1, visibility: 0.1 }, { light: 0.5, clutter: 0.5, visibility: 0.5 }, { light: 0.9, clutter: 0.9, visibility: 0.9 }];
  return [{}];
}

/** "photoacoustic · map=particles, skin=darker, beamformer=coherence", for messages. */
export function describe(s: LabState): string {
  if (s.chapter === "overview") return "overview";
  const slice = s[s.chapter] as Record<string, string>;
  return `${s.chapter} (${Object.entries(slice).map(([k, v]) => `${k}=${v}`).join(", ")})`;
}
