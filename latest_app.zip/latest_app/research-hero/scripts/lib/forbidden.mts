/*
  Text that must never reach the page: the old site builder's affordances, placeholders, and links
  back to the old ChatGPT-hosted site. Checked in the content (check-content) and again in the
  built output (check-built), because a component can print text the content files never held.
*/
export const FORBIDDEN: ReadonlyArray<{ pattern: RegExp; why: string }> = [
  { pattern: /edit website/i, why: "old site builder control" },
  { pattern: /add portrait/i, why: "old site builder control" },
  { pattern: /coming soon/i, why: "placeholder" },
  { pattern: /\[to confirm\]/i, why: "placeholder; use confirmed: false instead" },
  { pattern: /chatgpt\.site/i, why: "link to the old, login-only site" },
  { pattern: /\blorem\b/i, why: "placeholder text" },
  { pattern: /\bTODO\b|\bTBD\b|\bFIXME\b/, why: "unfinished note" },
];

export function forbiddenIn(text: string): string[] {
  return FORBIDDEN.filter((f) => f.pattern.test(text)).map((f) => `${f.pattern.source} (${f.why})`);
}
