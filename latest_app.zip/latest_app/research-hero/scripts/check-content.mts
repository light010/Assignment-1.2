/*
  The content gate. Runs before every build (npm run build → prebuild) and fails on anything that would
  put an untrue, broken, or unfinished statement on the page:
  - a required fact that isn't confirmed (role, current position, bios, email, profile links)
  - duplicate or malformed IDs, and references to IDs that don't exist: themes, featured papers,
    lab chapters, and the lab's evidence links
  - the counts the layout relies on: one owner per author list, 4–5 skills and 1–2 featured papers per theme
  - malformed DOIs, ORCID iDs, links, and dates, and facts that contradict each other
  - builder leftovers and placeholders ("Edit website", "[TO CONFIRM]", chatgpt.site)
  It also lists every unconfirmed fact, since a production build renders none of them.

  Usage: node scripts/check-content.mts
*/
import { recognition, updates } from "../src/content/about.ts";
import { CHAPTER_ORDER, evidence } from "../src/content/chapters.ts";
import { person } from "../src/content/person.ts";
import { profile } from "../src/content/profile.ts";
import { publications } from "../src/content/publications.ts";
import { recognitionPhotos } from "../src/content/recognition-photos.ts";
import { renders } from "../src/content/renders.ts";
import { DESCRIPTION, SECTIONS, UPDATED } from "../src/content/site.ts";
import { RESEARCH_DECK, directions, themes } from "../src/content/themes.ts";
import type { Fact } from "../src/content/types.ts";
import { allStates, describe } from "./lib/lab-states.mts";
import { forbiddenIn } from "./lib/forbidden.mts";

const problems: string[] = [];
const fail = (where: string, message: string) => problems.push(`${where}: ${message}`);

const SLUG = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const DOI = /^10\.\d{4,9}\/\S+$/;
const MONTH = /^\d{4}-(0[1-9]|1[0-2])$/;
const DAY = /^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/;
const TODAY = UPDATED.iso;
const THIS_YEAR = Number(TODAY.slice(0, 4));

const isFact = (v: unknown): v is Fact<unknown> =>
  typeof v === "object" && v !== null && "value" in v && "source" in v && "confirmed" in v;

/** Every string and fact under a value, with its path. */
function walk(value: unknown, path: string, strings: [string, string][], facts: [string, Fact<unknown>][]) {
  if (typeof value === "string") strings.push([path, value]);
  else if (Array.isArray(value)) value.forEach((v, i) => walk(v, `${path}[${i}]`, strings, facts));
  else if (typeof value === "object" && value !== null) {
    if (isFact(value)) facts.push([path, value]);
    for (const [k, v] of Object.entries(value)) walk(v, `${path}.${k}`, strings, facts);
  }
}

const strings: [string, string][] = [];
const facts: [string, Fact<unknown>][] = [];
walk({ person, publications, themes, directions, recognition, updates, profile }, "content", strings, facts);
strings.push(["themes.RESEARCH_DECK", RESEARCH_DECK], ["site.DESCRIPTION", DESCRIPTION]);

// ── Facts ────────────────────────────────────────────────────────────────────────────────────────
const REQUIRED: [string, Fact<unknown>][] = [
  ["person.role", person.role],
  ["person.now", person.now],
  ["person.bio", person.bio],
  ["person.shortBio", person.shortBio],
  ["person.email", person.email],
  ["person.links.orcid", person.links.orcid],
  ["person.links.linkedin", person.links.linkedin],
];
for (const [where, fact] of REQUIRED) if (!fact.confirmed) fail(where, "required fact is not confirmed");

for (const [where, fact] of facts) {
  if (!DAY.test(fact.source.checked)) fail(`${where}.source.checked`, `"${fact.source.checked}" is not an ISO date`);
  else if (fact.source.checked > TODAY) fail(`${where}.source.checked`, "is later than the content date");
  if (fact.source.url && !fact.source.url.startsWith("https://")) fail(`${where}.source.url`, "must use https");
}
const unconfirmed = facts.filter(([, f]) => !f.confirmed).map(([where]) => where.replace(/^content\./, ""));

// ── Person ───────────────────────────────────────────────────────────────────────────────────────
if (!/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(person.email.value)) fail("person.email", "is not an email address");
if (!orcidValid(person.links.orcid.value)) fail("person.links.orcid", `"${person.links.orcid.value}" fails the ORCID checksum`);
if (!/^https:\/\/www\.linkedin\.com\/in\/[\w-]+\/?$/.test(person.links.linkedin.value)) fail("person.links.linkedin", "is not a LinkedIn profile URL");
if (!/^https:\/\/scholar\.google\.com\/citations\?user=[\w-]{12}(&|$)/.test(person.links.scholar)) fail("person.links.scholar", "is not a Google Scholar profile URL");
if (!MONTH.test(person.now.value.since)) fail("person.now.since", "must be YYYY-MM");

const current = person.positions.filter((p) => !p.end);
if (current.length !== 1) fail("person.positions", `${current.length} current positions (no end date); expected 1`);
const [now] = current;
if (now && (now.title.value !== person.now.value.title || now.org !== person.now.value.org || now.start.value !== person.now.value.since))
  fail("person.now", "disagrees with the current position in person.positions (title, organization, or start)");

person.positions.forEach((p, i) => {
  const where = `person.positions[${i}]`;
  if (!MONTH.test(p.start.value)) fail(`${where}.start`, "must be YYYY-MM");
  if (p.end && !MONTH.test(p.end.value)) fail(`${where}.end`, "must be YYYY-MM");
  if (p.end && p.end.value < p.start.value) fail(where, "ends before it starts");
  if (p.start.value > TODAY) fail(`${where}.start`, "is in the future");
  if (i > 0 && p.start.value > person.positions[i - 1].start.value) fail(where, "positions must be newest first");
  if (p.link && !p.link.href.startsWith("https://")) fail(`${where}.link`, "must use https");
});
person.education.forEach((e, i) => {
  const where = `person.education[${i}]`;
  if (!MONTH.test(e.end.value)) fail(`${where}.end`, "must be YYYY-MM");
  if (i > 0 && e.end.value > person.education[i - 1].end.value) fail(where, "education must be newest first");
  if (e.link && !e.link.href.startsWith("https://")) fail(`${where}.link`, "must use https");
});

// ── Publications ─────────────────────────────────────────────────────────────────────────────────
const THEME_IDS = new Set(themes.map((t) => t.id));
const CHAPTERS = new Set<string>(CHAPTER_ORDER);
const TYPES = new Set(["journal-article", "review", "conference-paper", "book-chapter", "thesis"]);
const ACCESS = new Set(["open-access", "free-to-read", "lab-pdf", "subscription", "restricted"]);
const LINK_KINDS = new Set(["doi", "pdf", "preprint", "pmc", "record"]);
const anchors = new Map<string, string>();

publications.forEach((p, i) => {
  const where = `publications[${i}] ${p.id}`;
  for (const id of [p.id, ...(p.aliases ?? [])]) {
    if (!SLUG.test(id)) fail(where, `"${id}" is not a lowercase slug`);
    if (anchors.has(id)) fail(where, `id "${id}" is already used by ${anchors.get(id)}`);
    anchors.set(id, p.id);
  }
  if (p.title !== p.title.trim() || /\s{2,}/.test(p.title) || !p.title) fail(where, "title has stray whitespace or is empty");
  if (/[.]$/.test(p.title)) fail(where, "title ends with a period");

  const mine = p.authors.filter((a) => a.me);
  if (mine.length !== 1) fail(where, `${mine.length} authors marked as the owner; expected 1`);
  else if (mine[0].name !== person.name) fail(where, `owner is listed as "${mine[0].name}", not "${person.name}"`);
  const names = p.authors.map((a) => a.name);
  if (new Set(names).size !== names.length) fail(where, "an author is listed twice");
  for (const a of p.authors) if (a.family && !a.name.endsWith(a.family)) fail(where, `family name "${a.family}" doesn't end "${a.name}"`);

  if (!TYPES.has(p.type)) fail(where, `unknown type "${p.type}"`);
  if (!ACCESS.has(p.access)) fail(where, `unknown access "${p.access}"`);
  if (p.license && p.access !== "open-access") fail(where, "a license is set but the paper isn't open access");
  if (!p.venue.trim()) fail(where, "venue is empty");
  if (p.venueShort !== undefined && (!p.venueShort.trim() || p.venueShort.length >= p.venue.length))
    fail(where, "venueShort must be a shorter form of the venue");
  if (!Number.isInteger(p.year) || p.year < 1990 || p.year > THIS_YEAR) fail(where, `year ${p.year} is out of range`);
  if (i > 0 && p.year > publications[i - 1].year) fail(where, "publications must be newest first");

  if (p.doi === undefined) {
    if (p.type !== "thesis") fail(where, "every paper except the thesis needs a DOI");
  } else {
    if (!DOI.test(p.doi)) fail(where, `"${p.doi}" is not a DOI`);
    if (p.doi !== p.doi.trim() || /^https?:/.test(p.doi)) fail(where, "store the bare DOI, without https://doi.org/");
    const doiLink = p.links.find((l) => l.kind === "doi");
    if (!doiLink || doiLink.href !== `https://doi.org/${p.doi}`) fail(where, "needs a doi link that matches its DOI");
  }
  if (p.links.length === 0) fail(where, "has no links");
  p.links.forEach((l) => {
    if (!LINK_KINDS.has(l.kind)) fail(where, `unknown link kind "${l.kind}"`);
    if (!l.href.startsWith("https://")) fail(where, `link "${l.href}" must use https`);
    if (!l.label.trim()) fail(where, "a link has no label");
  });
  const kinds = p.links.map((l) => l.kind);
  if (new Set(kinds).size !== kinds.length) fail(where, "two links of the same kind");

  for (const t of p.themes) if (!THEME_IDS.has(t)) fail(where, `unknown theme "${t}"`);
  if (new Set(p.themes).size !== p.themes.length) fail(where, "a theme is listed twice");
  for (const c of p.chapters) if (!CHAPTERS.has(c)) fail(where, `unknown lab chapter "${c}"`);
  if (new Set(p.chapters).size !== p.chapters.length) fail(where, "a chapter is listed twice");

  if (!p.summary.trim()) fail(where, "summary is empty");
  if (p.role) {
    if (p.role.credit.length === 0 || p.role.credit.some((r) => !r.trim())) fail(where, "role lists no contribution");
    if (!p.role.source.startsWith("https://")) fail(where, "role source must be an https link");
  }
});

// ── Themes and research directions ─────────────────────────────────────────────────────────────
if (THEME_IDS.size !== themes.length) fail("themes", "duplicate theme ids");
const directionIds = new Set(directions.map((d) => d.id));
if (directionIds.size !== directions.length) fail("directions", "duplicate direction ids");
for (const d of directions) {
  const where = `directions.${d.id}`;
  if (!THEME_IDS.has(d.theme)) fail(where, `unknown theme "${d.theme}"`);
  if (d.skills.length < 3 || d.skills.length > 5) fail(where, `${d.skills.length} skills; the card expects 3–5`);
  for (const c of d.chapters) if (!CHAPTERS.has(c)) fail(where, `unknown lab chapter "${c}"`);
  if (!publications.some((p) => p.themes.includes(d.theme))) fail(where, `no papers in its group "${d.theme}"`);
}
// Every lab chapter belongs to exactly one direction, so each card's lab links and the lab agree.
for (const c of CHAPTER_ORDER) {
  const owners = directions.filter((d) => d.chapters.includes(c)).length;
  if (owners !== 1) fail("directions", `lab chapter "${c}" is in ${owners} directions; expected 1`);
}

// ── Lab evidence links ───────────────────────────────────────────────────────────────────────────
const SECTION_IDS = new Set<string>(SECTIONS.map((s) => s.id));
const SHOW = new Set<string>(["all", "first-author", ...THEME_IDS]);
const byDoi = new Map(publications.filter((p) => p.doi).map((p) => [`https://doi.org/${p.doi}`, p]));
for (const s of allStates()) {
  const e = evidence(s);
  if (!e) continue;
  const where = `lab evidence, ${describe(s)}`;
  if (e.external) {
    const paper = byDoi.get(e.href);
    if (!paper) fail(where, `${e.href} isn't the DOI of a paper on the page`);
    else if (s.chapter !== "overview" && !paper.chapters.includes(s.chapter))
      fail(where, `${paper.id} doesn't list the "${s.chapter}" chapter, so its entry won't link back`);
  } else {
    const url = new URL(e.href, "https://example.org");
    const show = url.searchParams.get("show");
    if (url.pathname !== "/") fail(where, `${e.href} leaves the page`);
    if (!SECTION_IDS.has(url.hash.slice(1))) fail(where, `${e.href} points at a section that doesn't exist`);
    if (show !== null && !SHOW.has(show)) fail(where, `?show=${show} isn't a filter value`);
    if (show && THEME_IDS.has(show as never) && !publications.some((p) => p.themes.includes(show as never)))
      fail(where, `?show=${show} would show no papers`);
  }
}

// ── Recognition and updates ──────────────────────────────────────────────────────────────────────
const unique = (ids: string[], where: string) => {
  const seen = new Set<string>();
  for (const id of ids) {
    if (!SLUG.test(id)) fail(where, `"${id}" is not a lowercase slug`);
    if (seen.has(id)) fail(where, `id "${id}" is used twice`);
    seen.add(id);
  }
};
unique(recognition.map((r) => r.id), "recognition");
unique(updates.map((u) => u.id), "updates");
for (const r of recognition) {
  const where = `recognition.${r.id}`;
  if (!/^\d{4}(–(\d{4}|present))?$/.test(r.when)) fail(where, `when "${r.when}" must read "2025" or "2024–present"`);
  if (r.photo) {
    if (!recognitionPhotos[r.id]) fail(where, `has photo details but no file: add assets/originals/recognition/${r.id}.jpg and run npm run photos`);
    if (!r.photo.credit.trim()) fail(where, "a photo needs its credit");
    if (!r.photo.alt.trim()) fail(where, "a photo needs alt text");
  }
  if (r.still && !renders.some((x) => x.id === r.still?.render && (x.framing === "card" || x.framing === "wide"))) fail(where, `lab still "${r.still.render}" doesn't exist`);
}
for (const id of Object.keys(recognitionPhotos))
  if (!recognition.some((r) => r.id === id && r.photo)) fail(`recognition-photos.${id}`, "a processed photo no item uses: add photo: { alt, credit } to that item in about.ts");
updates.forEach((u, i) => {
  const where = `updates.${u.id}`;
  if (!DAY.test(u.date) && !MONTH.test(u.date)) fail(where, "date must be YYYY-MM-DD or YYYY-MM");
  if (u.date > TODAY) fail(where, "is dated after the content date");
  if (i > 0 && u.date > updates[i - 1].date) fail(where, "updates must be newest first");
  if (u.link && !u.link.href.startsWith("https://")) fail(where, "link must use https");
});

// ── Navigation ───────────────────────────────────────────────────────────────────────────────────
if (SECTION_IDS.size !== SECTIONS.length) fail("site.SECTIONS", "duplicate section ids");
for (const n of profile.nav) if (!SECTION_IDS.has(n.href.slice(1))) fail("profile.nav", `${n.href} isn't a section`);

// ── Text: placeholders, links ────────────────────────────────────────────────────────────────────
for (const [where, text] of strings) {
  for (const hit of forbiddenIn(text)) fail(where.replace(/^content\./, ""), `forbidden text ${hit}`);
  for (const url of text.match(/https?:\/\/[^\s"'<>)]+/g) ?? []) {
    if (url.startsWith("http://")) fail(where.replace(/^content\./, ""), `${url} must use https`);
    if (/localhost|127\.0\.0\.1/.test(url)) fail(where.replace(/^content\./, ""), `${url} points at this computer`);
  }
}

// ── Report ───────────────────────────────────────────────────────────────────────────────────────
const count = (f: (p: (typeof publications)[number]) => boolean) => publications.filter(f).length;
console.log("Content check");
console.log(
  `  ${publications.length} publications: ${themes.map((t) => `${count((p) => p.themes.includes(t.id))} ${t.id}`).join(", ")}, ` +
    `${count((p) => p.themes.length === 0)} other; ${count((p) => p.authors[0]?.me === true)} first-author; ` +
    `${count((p) => p.access === "open-access" || p.access === "free-to-read")} free to read`,
);
console.log(`  ${themes.length} themes, ${recognition.length} recognition items, ${updates.length} updates, ${person.positions.length} positions, ${person.education.length} degrees`);
console.log(`  ${allStates().length} lab states checked for evidence links`);
console.log(unconfirmed.length ? `  Unconfirmed, so not shown in production:\n${unconfirmed.map((u) => `    - ${u}`).join("\n")}` : "  Every fact is confirmed.");
if (problems.length) {
  console.error(`\n✗ ${problems.length} problem${problems.length === 1 ? "" : "s"}:\n${problems.map((p) => `  - ${p}`).join("\n")}`);
  process.exit(1);
}
console.log("✓ Content is consistent.");

function orcidValid(id: string) {
  if (!/^\d{4}-\d{4}-\d{4}-\d{3}[\dX]$/.test(id)) return false;
  const digits = id.replace(/-/g, "");
  let total = 0;
  for (const ch of digits.slice(0, 15)) total = (total + Number(ch)) * 2;
  const result = (12 - (total % 11)) % 11;
  return digits[15] === (result === 10 ? "X" : String(result));
}
