/**
 * Renders stills of the 3D lab for posters, no-WebGL fallbacks and share cards.
 *
 *   npm run dev                      # in another terminal (development exposes window.__lab)
 *   npm run render:stills            # every state at both framings
 *   node scripts/render-stills.mts --only overview,design --framing phone
 *
 * For each state and framing: load the page, click the chapter and its controls (React owns the
 * state), let the scene play until it settles, stop time at a chosen moment, raise the canvas to the
 * device pixel ratio, hide everything but the canvas, and screenshot the canvas box as lossless PNG
 * (kept in a temp folder). sharp writes AVIF and WebP to public/renders/, and the manifest is
 * regenerated from what is on disk in src/content/renders.ts.
 *
 * The dev server may hot-reload while this runs: a capture starts over if the page navigates, the
 * engine is rebuilt, or the canvas changes size before the screenshot is taken.
 */
import { chromium, type BrowserContext, type Page } from "@playwright/test";
import sharp from "sharp";
import { randomUUID } from "node:crypto";
import { access, mkdir, mkdtemp, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { parseArgs } from "node:util";

/* ---------- what to render ---------- */

type FramingId = "wide" | "phone" | "card";
type StateId = "overview" | "design" | "delivery" | "photoacoustics" | "ultrasound";
type Format = "avif" | "webp";

interface Framing {
  id: FramingId;
  context: { viewport: { width: number; height: number }; deviceScaleFactor: number; isMobile?: boolean; hasTouch?: boolean };
  /** Output widths in pixels. */
  widths: number[];
  /** The states this framing is rendered for; all of them when omitted. */
  states?: StateId[];
  /** Page styles applied once the engine runs, before the state is set: they reshape the scene frame. */
  css?: string;
}

interface Moment {
  /** The event to time from: a light pulse, or an ultrasound transmit. `pulse()` fires it. */
  after: "light" | "transmit";
  /** Scene seconds after the event at which time stops. */
  seconds: number;
}

interface State {
  id: StateId;
  /** Chapter button text; none for the default page. */
  chapter?: string;
  /** [radio group label, option text], clicked in order. */
  controls: Array<[string, string]>;
  /** The state the engine should hold once React has passed it on (checked when exposed). */
  engine: Record<string, unknown>;
  /** How long the scene plays before time stops: camera moves, build steps, heating. */
  settleMs: number;
  /** When set, time stops at this moment rather than whenever the settle ends. */
  moment?: Moment;
  alt: string;
}

const FRAMINGS: Framing[] = [
  { id: "wide", context: { viewport: { width: 1440, height: 900 }, deviceScaleFactor: 2 }, widths: [480, 768, 1200, 1600] },
  {
    id: "phone",
    context: { viewport: { width: 390, height: 844 }, deviceScaleFactor: 3, isMobile: true, hasTouch: true },
    widths: [360, 712, 1068],
  },
  {
    // A 3:2 card with the subject centred (the Recognition section's Design card). A portrait viewport
    // keeps the stacked layout, whose framing centres the subject; the scene frame is then reshaped to
    // 1200x800 and the engine fits the shot to it.
    id: "card",
    context: { viewport: { width: 1200, height: 1600 }, deviceScaleFactor: 1.5 },
    widths: [600, 900, 1200, 1800],
    states: ["design"],
    css: `#top div:has(> [data-status]) { position: fixed !important; inset: 0 auto auto 0 !important; width: 1200px !important;
      height: 800px !important; margin: 0 !important; border: 0 !important; aspect-ratio: auto !important; border-radius: 0 !important; z-index: 50 !important; }`,
  },
];

const STATES: State[] = [
  {
    id: "overview",
    controls: [],
    engine: { chapter: "overview" },
    // Past the first pulse's screen ripple, then 0.7 s after a fresh pulse: sound rings mid-flight
    // around the tumor, the moment the reduced-motion scene freezes on.
    settleMs: 5000,
    moment: { after: "light", seconds: 0.7 },
    alt: "Simulated lab: a tissue block with a tumor, a probe on top, and one nanoparticle shown cut open in a magnifier.",
  },
  {
    id: "design",
    chapter: "Design",
    controls: [
      ["Build", "Membrane coat"],
      ["View", "Taken apart"],
    ],
    engine: { chapter: "design", design: { step: "coat", view: "exploded" } },
    // The layers slide apart and the lab fades out over about 4 s.
    settleMs: 6500,
    alt: "Simulated nanoparticle taken apart: light-absorbing cores, the heat-responsive gel holding the drug, and the membrane coat, side by side.",
  },
  {
    id: "delivery",
    chapter: "Delivery",
    controls: [
      ["Particle", "Gel carrier"],
      ["After", "Hours"],
      ["Light", "Continuous"],
    ],
    engine: { chapter: "deliver", deliver: { particle: "gel", elapsed: "hours", light: "continuous" } },
    // Heat, tumor damage and drug release build up for several seconds under continuous light.
    settleMs: 11000,
    alt: "Simulated delivery: gel carriers wait at the tumor rim while continuous light heats them; the freed drug spreads into the tumor.",
  },
  {
    id: "photoacoustics",
    chapter: "Photoacoustics",
    controls: [
      ["Show", "Blood oxygen"],
      ["Skin tone", "Darker"],
      ["Beamformer", "Coherence"],
    ],
    engine: { chapter: "photoacoustic", photoacoustic: { map: "oxygenation", skin: "darker", beamformer: "coherence" } },
    // 0.7 s after a pulse: sound on its way up to the probe, the image on the plane complete.
    settleMs: 6000,
    moment: { after: "light", seconds: 0.7 },
    alt: "Simulated photoacoustic image through darker skin with coherence beamforming: oxygenated blood in green, deoxygenated blood in red.",
  },
  {
    id: "ultrasound",
    chapter: "Ultrasound",
    controls: [
      ["Lesion", "Cyst"],
      ["Beamformer", "Coherence"],
      ["View", "Image"],
    ],
    engine: { chapter: "ultrasound", ultrasound: { lesion: "cyst", beamformer: "coherence", view: "image" } },
    // 1.6 s after a transmit: the image sweep has finished and echoes are returning from the cyst.
    settleMs: 6000,
    moment: { after: "transmit", seconds: 1.6 },
    alt: "Simulated ultrasound: the probe over a cyst, with a coherence image of the tissue below, where the fluid-filled cyst goes dark.",
  },
];

/** Encoder settings; the overview posters step quality down if they miss their budget. */
const QUALITY: Record<Format, number> = { avif: 50, webp: 72 };
const QUALITY_FLOOR: Record<Format, number> = { avif: 30, webp: 50 };
const EFFORT: Record<Format, number> = { avif: 6, webp: 6 };
/** The poster (LCP image) budget, in bytes (decimal KB, the stricter reading), at these widths. */
const POSTER_BUDGET: Record<Format, number> = { avif: 30_000, webp: 45_000 };
const POSTER_WIDTH: Record<FramingId, number> = { wide: 1200, phone: 712, card: 1200 };
const POSTER_STATE: StateId = "overview";

const LAUNCH_ARGS = ["--use-angle=metal", "--ignore-gpu-blocklist", "--enable-gpu", "--hide-scrollbars"];
const ATTEMPTS = 4;

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const OUT_DIR = path.join(ROOT, "public", "renders");
const MANIFEST = path.join(ROOT, "src", "content", "renders.ts");

/* ---------- the page side ---------- */

/** The slice of the engine this script touches. Fields past the public methods are dev-build internals: every use is guarded. */
interface Lab {
  setPlaying(playing: boolean): void;
  pulse(): void;
  setSize(w: number, h: number, dpr: number): void;
  setScroll?(progress: number): void;
  renderer?: { domElement?: unknown };
  state?: Record<string, unknown>;
  playing?: boolean;
  time?: number;
  laserT?: number;
  usT?: number;
  nextPulse?: number;
  waveWall?: number;
  qualityStep?: number;
  pendingFrames?: number;
  __stillToken?: string;
}

interface Helpers {
  /** The canvas the engine draws into (the hero also holds the instrument panel's canvases). */
  canvas(): HTMLCanvasElement | null;
  /** Resolves on the first animation frame where `pred` holds. */
  until(pred: () => boolean, timeoutMs: number, label: string): Promise<void>;
}

type StillWindow = Window & { __lab?: Lab; __stills?: Helpers; __stillMarker?: string };

/** Installed before any page script on every load (addInitScript). */
function installHelpers() {
  const w = window as unknown as StillWindow;
  w.__stills = {
    canvas() {
      const own = w.__lab?.renderer?.domElement;
      if (own instanceof HTMLCanvasElement && own.isConnected) return own;
      const all = Array.from(document.querySelectorAll<HTMLCanvasElement>("canvas"));
      const area = (c: HTMLCanvasElement) => c.getBoundingClientRect().width * c.getBoundingClientRect().height;
      return (
        all.find((c) => c.hasAttribute("data-on")) ??
        all.find((c) => c.parentElement?.hasAttribute("data-status")) ??
        all.sort((a, b) => area(b) - area(a))[0] ??
        null
      );
    },
    until(pred, timeoutMs, label) {
      return new Promise((resolve, reject) => {
        const start = performance.now();
        const tick = () => {
          let ok = false;
          try {
            ok = pred();
          } catch {
            ok = false;
          }
          if (ok) resolve();
          else if (performance.now() - start > timeoutMs) reject(new Error(`timed out waiting for ${label}`));
          else requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      });
    },
  };
}

/* ---------- capture ---------- */

interface Box {
  x: number;
  y: number;
  width: number;
  height: number;
  bufferWidth: number;
  bufferHeight: number;
}

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

async function capture(page: Page, url: string, framing: Framing, state: State): Promise<{ png: Buffer; box: Box }> {
  // Real document loads only: Next's router also updates history in place, which isn't a reload.
  let navigations = 0;
  page.on("domcontentloaded", () => navigations++);
  page.on("pageerror", (err) => console.warn(`    page error: ${err.message.split("\n")[0]}`));

  await page.goto(url, { waitUntil: "load", timeout: 120_000 });
  const loads = navigations;
  const token = randomUUID();

  // 1. The engine exists and its canvas has faded in.
  await page.waitForFunction(
    () => {
      const w = window as unknown as StillWindow;
      const c = w.__stills?.canvas();
      return !!w.__lab && !!c && c.isConnected && c.width > 0 && getComputedStyle(c).opacity === "1";
    },
    undefined,
    { timeout: 60_000, polling: 100 },
  );
  await page.evaluate((t) => {
    const w = window as unknown as StillWindow;
    w.__stillMarker = t;
    if (w.__lab) w.__lab.__stillToken = t;
  }, token);
  if (framing.css) {
    await page.addStyleTag({ content: framing.css });
    await sleep(300);
  }

  // 2. Set the state the way a visitor would. dispatchEvent clicks without scrolling, and the
  //    scroll position steers the camera.
  if (state.chapter) {
    const button = page.locator("button[aria-pressed]").filter({ hasText: state.chapter }).first();
    await button.waitFor({ state: "attached", timeout: 15_000 });
    if ((await button.getAttribute("aria-pressed")) !== "true") await button.dispatchEvent("click");
    await page.locator("button[aria-pressed='true']").filter({ hasText: state.chapter }).first().waitFor({ state: "attached", timeout: 10_000 });
  }
  for (const [group, option] of state.controls) {
    let radio = page.getByRole("radiogroup", { name: group, exact: true }).getByRole("radio", { name: option, exact: true }).first();
    try {
      await radio.waitFor({ state: "attached", timeout: 5_000 });
    } catch {
      // The group label changed: the option text alone is still unique within one chapter.
      radio = page.getByRole("radio", { name: option, exact: true }).first();
      await radio.waitFor({ state: "attached", timeout: 5_000 });
    }
    if ((await radio.getAttribute("aria-checked")) !== "true") await radio.dispatchEvent("click");
    await radio.and(page.locator("[aria-checked='true']")).waitFor({ state: "attached", timeout: 10_000 });
  }
  const mismatch = await page
    .waitForFunction(
      (expected) => {
        const actual = (window as unknown as StillWindow).__lab?.state;
        if (!actual) return "unchecked";
        const same = (e: unknown, a: unknown): boolean =>
          e !== null && typeof e === "object"
            ? a !== null && typeof a === "object" && Object.entries(e).every(([k, v]) => same(v, (a as Record<string, unknown>)[k]))
            : e === a;
        return same(expected, actual) ? "ok" : false;
      },
      state.engine,
      { timeout: 5_000 },
    )
    .then((h) => h.jsonValue())
    .catch(() => "mismatch");
  if (mismatch === "mismatch") throw new Error(`engine state is not ${JSON.stringify(state.engine)}`);
  if (mismatch === "unchecked") console.warn("    engine state not exposed; trusting the checked controls");
  await page.evaluate(() => window.scrollTo({ top: 0, left: 0, behavior: "instant" }));

  // 3. Let the scene play, then stop time (at a set moment after a pulse, where the state has one).
  await sleep(state.settleMs);
  await assertSameEngine(page, token);
  await page.evaluate(async (moment) => {
    const w = window as unknown as StillWindow;
    const lab = w.__lab!;
    const until = w.__stills!.until;
    const clock = [lab.time, lab.laserT, lab.usT, lab.nextPulse].every((v) => typeof v === "number");
    const age = (key: "laserT" | "usT") => lab.time! - lab[key]!;
    if (clock) {
      // Sound from a light pulse shows in the tissue for 3.2 s and an ultrasound transmit's for 2.8 s.
      // Start from a gap so the still holds one event, not the tail of the one before.
      if (moment?.after === "light") await until(() => age("laserT") >= 2.6, 10_000, "a gap between light pulses");
      // The overview's next pulse stays scheduled after a chapter change; let it fire and fade.
      else await until(() => lab.nextPulse! - lab.time! > 5 && age("laserT") > 3.4, 15_000, "the last light pulse to fade");
      if (moment?.after === "transmit") await until(() => age("usT") >= 1.2, 5_000, "a gap between transmits");
    }
    if (moment) {
      const key = moment.after === "light" ? "laserT" : "usT";
      const before = lab[key];
      lab.pulse();
      if (clock) {
        await until(() => lab[key] !== before && age(key) >= moment.seconds, 10_000, `${moment.after} + ${moment.seconds} s`);
      } else {
        // No clock exposed: the light leaves the fibre 0.62 s after pulse(), a transmit goes at once.
        await new Promise((r) => setTimeout(r, ((moment.after === "light" ? 0.62 : 0) + moment.seconds) * 1000));
      }
    }
    lab.setPlaying(false);
  }, state.moment ?? null);

  // 4. Full-resolution frame, then only the canvas left on screen.
  const dpr = framing.context.deviceScaleFactor;
  const box = await page.evaluate(async (dpr) => {
    const w = window as unknown as StillWindow;
    const lab = w.__lab!;
    const helpers = w.__stills!;
    const canvas = helpers.canvas()!;
    let r = canvas.getBoundingClientRect();
    if (r.top < 0 || r.bottom > window.innerHeight) {
      canvas.scrollIntoView({ block: "nearest", behavior: "instant" });
      await new Promise((res) => requestAnimationFrame(() => requestAnimationFrame(res)));
      lab.setScroll?.(0);
      r = canvas.getBoundingClientRect();
    }
    // A pulse's screen-space ripple runs on wall time even while paused; let it finish.
    if (typeof lab.waveWall === "number") await helpers.until(() => performance.now() - lab.waveWall! > 2700, 6_000, "the ripple to pass");
    // The page renders at up to 1.5x (1.25x on low-power devices) and steps down when frames run
    // slow; a still gets the device ratio, so its largest size isn't an upscale.
    if (typeof lab.qualityStep === "number") lab.qualityStep = 0;
    lab.setSize(r.width, r.height, dpr);
    canvas.setAttribute("data-still-target", "");
    const style = document.createElement("style");
    // The page background turns a sentinel color, so any pixel of it in the shot can be found and cut.
    style.textContent = `body * { visibility: hidden !important; } [data-still-target] { visibility: visible !important; }
      html, body { background: rgb(255 0 255) !important; }`;
    document.head.append(style);
    // The phone frame's rounded clip would cut the corners out of the still.
    for (let el = canvas.parentElement; el && el !== document.body; el = el.parentElement) {
      const cs = getComputedStyle(el);
      if (cs.overflow !== "visible" && parseFloat(cs.borderTopLeftRadius) > 0) el.style.borderRadius = "0";
    }
    await helpers.until(() => (lab.pendingFrames ?? 0) <= 0, 5_000, "the resized frame");
    await new Promise((res) => requestAnimationFrame(() => requestAnimationFrame(res)));
    return { x: r.x, y: r.y, width: r.width, height: r.height, bufferWidth: canvas.width, bufferHeight: canvas.height };
  }, dpr);
  const want = [Math.floor(box.width * dpr), Math.floor(box.height * dpr)];
  if (box.bufferWidth !== want[0] || box.bufferHeight !== want[1]) {
    throw new Error(`canvas renders at ${box.bufferWidth}x${box.bufferHeight}, wanted ${want.join("x")}`);
  }
  const covered = await page.evaluate(() => {
    const c = document.querySelector("[data-still-target]")!;
    const r = c.getBoundingClientRect();
    const points = [[0.5, 0.5], [0.08, 0.08], [0.92, 0.08], [0.08, 0.92], [0.92, 0.92]];
    return points.filter(([fx, fy]) => document.elementFromPoint(r.left + fx * r.width, r.top + fy * r.height) !== c).length;
  });
  if (covered) throw new Error("something is drawn over the canvas (an error overlay?)");

  // 5. Screenshot until two in a row match: the engine has stopped drawing.
  const target = page.locator("[data-still-target]");
  let png = await target.screenshot({ type: "png", timeout: 30_000 });
  for (let i = 0; ; i++) {
    await sleep(350);
    const again = await target.screenshot({ type: "png", timeout: 30_000 });
    if (again.equals(png)) break;
    png = again;
    if (i >= 12) throw new Error("the canvas kept changing after time stopped");
  }

  // 6. Nothing was swapped out underneath the capture.
  await assertSameEngine(page, token);
  const after = await page.evaluate(() => {
    const c = document.querySelector<HTMLCanvasElement>("[data-still-target]");
    const r = c?.getBoundingClientRect();
    return { playing: (window as unknown as StillWindow).__lab?.playing, box: r ? [r.x, r.y, r.width, r.height] : null, buffer: c ? [c.width, c.height] : null };
  });
  if (navigations !== loads) throw new Error("the page reloaded during the capture");
  if (after.playing === true) throw new Error("the scene started playing again");
  if (JSON.stringify(after.box) !== JSON.stringify([box.x, box.y, box.width, box.height])) throw new Error("the canvas moved or resized");
  if (JSON.stringify(after.buffer) !== JSON.stringify([box.bufferWidth, box.bufferHeight])) throw new Error("the canvas was resized by the page");
  return { png: await trimToCanvas(png, box.bufferWidth, box.bufferHeight), box };
}

/**
 * Playwright widens element clips to whole CSS pixels, and the canvas can sit at a fractional
 * offset (the phone frame does), so the shot may carry a row or column of page background. That
 * background is the sentinel color: cut the sentinel rows and columns from the edges, then require
 * exactly the canvas's pixel size and no sentinel left inside (which would mean something clips it).
 */
async function trimToCanvas(png: Buffer, width: number, height: number) {
  const { data, info } = await sharp(png).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  const { width: w, height: h, channels } = info;
  const sentinel = (x: number, y: number) => {
    const i = (y * w + x) * channels;
    return data[i] === 255 && data[i + 1] === 0 && data[i + 2] === 255;
  };
  const row = (y: number) => Array.from({ length: w }, (_, x) => x).every((x) => sentinel(x, y));
  const column = (x: number, y0: number, y1: number) => Array.from({ length: y1 - y0 }, (_, i) => y0 + i).every((y) => sentinel(x, y));
  let top = 0;
  let bottom = h;
  let left = 0;
  let right = w;
  while (top < bottom && row(top)) top++;
  while (bottom > top && row(bottom - 1)) bottom--;
  while (left < right && column(left, top, bottom)) left++;
  while (right > left && column(right - 1, top, bottom)) right--;
  if (right - left !== width || bottom - top !== height) {
    throw new Error(`the canvas measures ${right - left}x${bottom - top} in the screenshot, expected ${width}x${height}`);
  }
  let stray = 0;
  for (let y = top; y < bottom; y++) for (let x = left; x < right; x++) if (sentinel(x, y)) stray++;
  if (stray) throw new Error(`${stray} page-background pixels inside the canvas box: something clips it`);
  return sharp(png).extract({ left, top, width, height }).png().toBuffer();
}

async function assertSameEngine(page: Page, token: string) {
  const same = await page.evaluate((t) => {
    const w = window as unknown as StillWindow;
    return { page: w.__stillMarker === t, engine: w.__lab?.__stillToken === t };
  }, token);
  if (!same.page) throw new Error("the page reloaded");
  if (!same.engine) throw new Error("the engine was rebuilt (hot reload)");
}

async function captureWithRetry(context: BrowserContext, url: string, framing: Framing, state: State) {
  for (let attempt = 1; ; attempt++) {
    const page = await context.newPage();
    try {
      return await capture(page, url, framing, state);
    } catch (err) {
      const message = err instanceof Error ? err.message.split("\n")[0] : String(err);
      if (attempt >= ATTEMPTS) throw new Error(`${state.id}/${framing.id}: ${message}`);
      console.warn(`    attempt ${attempt} failed (${message}); retrying`);
      await sleep(1500);
    } finally {
      await page.close().catch(() => {});
    }
  }
}

/* ---------- encode ---------- */

interface Encoded {
  file: string;
  format: Format;
  width: number;
  height: number;
  bytes: number;
  quality: number;
}

const fileName = (state: StateId, framing: FramingId, width: number, format: Format) => `${state}-${framing}-${width}.${format}`;

async function encode(png: Buffer, state: StateId, framing: Framing, format: Format, quality: number): Promise<Encoded[]> {
  const out: Encoded[] = [];
  for (const width of framing.widths) {
    const file = path.join(OUT_DIR, fileName(state, framing.id, width, format));
    const resized = sharp(png).resize({ width, kernel: "lanczos3" });
    const encoded = format === "avif" ? resized.avif({ quality, effort: EFFORT.avif }) : resized.webp({ quality, effort: EFFORT.webp });
    const info = await encoded.toFile(file);
    out.push({ file, format, width: info.width, height: info.height, bytes: info.size, quality });
  }
  return out;
}

/** Encodes one still; the poster steps quality down until its budget width fits. */
async function encodeStill(png: Buffer, state: StateId, framing: Framing) {
  const files: Encoded[] = [];
  for (const format of ["avif", "webp"] as const) {
    let quality = QUALITY[format];
    let set = await encode(png, state, framing, format, quality);
    if (state === POSTER_STATE) {
      const budgeted = () => set.find((f) => f.width === POSTER_WIDTH[framing.id])!;
      while (budgeted().bytes > POSTER_BUDGET[format] && quality - 2 >= QUALITY_FLOOR[format]) {
        quality -= 2;
        set = await encode(png, state, framing, format, quality);
      }
      const b = budgeted();
      const verdict = b.bytes <= POSTER_BUDGET[format] ? "within" : "OVER";
      console.log(`    poster ${format} ${b.width} w: ${b.bytes} B at q${quality}, ${verdict} the ${POSTER_BUDGET[format]} B budget`);
    }
    files.push(...set);
  }
  return files;
}

/* ---------- manifest ---------- */

const exists = (file: string) =>
  access(file).then(
    () => true,
    () => false,
  );

/** Prints a value as TypeScript with unquoted keys. */
function literal(value: unknown, indent = ""): string {
  const next = `${indent}  `;
  if (Array.isArray(value)) {
    if (value.every((v) => v === null || typeof v !== "object")) return `[${value.map((v) => literal(v)).join(", ")}]`;
    return `[\n${value.map((v) => `${next}${literal(v, next)},`).join("\n")}\n${indent}]`;
  }
  if (value !== null && typeof value === "object") {
    const entries = Object.entries(value);
    if (entries.every(([, v]) => v === null || typeof v !== "object") && entries.length <= 2) {
      return `{ ${entries.map(([k, v]) => `${k}: ${literal(v)}`).join(", ")} }`;
    }
    return `{\n${entries.map(([k, v]) => `${next}${k}: ${literal(v, next)},`).join("\n")}\n${indent}}`;
  }
  return JSON.stringify(value);
}

async function writeManifest() {
  const renders = [];
  for (const state of STATES) {
    for (const framing of FRAMINGS) {
      const sources: Record<Format, Array<{ src: string; w: number }>> = { avif: [], webp: [] };
      let largest = { width: 0, height: 0 };
      for (const format of ["avif", "webp"] as const) {
        for (const width of framing.widths) {
          const name = fileName(state.id, framing.id, width, format);
          const file = path.join(OUT_DIR, name);
          if (!(await exists(file))) continue;
          const meta = await sharp(file).metadata();
          sources[format].push({ src: `/renders/${name}`, w: meta.width });
          if (meta.width > largest.width) largest = { width: meta.width, height: meta.height };
        }
      }
      if (!sources.avif.length && !sources.webp.length) continue;
      renders.push({ id: state.id, framing: framing.id, alt: state.alt, width: largest.width, height: largest.height, sources });
    }
  }
  const source = `// Generated by scripts/render-stills.mts from the files in public/renders. Do not edit by hand:
// run \`npm run render:stills\` (with \`npm run dev\` running) to render the lab and rewrite this file.

/** Which lab state a still shows. */
export type RenderId = ${STATES.map((s) => JSON.stringify(s.id)).join(" | ")};

/**
 * "wide" is the full-bleed scene at 1440x900 (16:10); "phone" is the square scene frame at 390 px; "card"
 * is a 3:2 frame with the subject centred (1200x800 at 1.5x), rendered for some states only.
 */
export type RenderFraming = ${FRAMINGS.map((f) => JSON.stringify(f.id)).join(" | ")};

export interface RenderSource {
  /** Public path of the file. */
  src: string;
  /** Intrinsic width in pixels, for a srcset \`w\` descriptor. */
  w: number;
}

export interface Render {
  id: RenderId;
  framing: RenderFraming;
  /** Starts with "Simulated": these are engine renders, not measurements. */
  alt: string;
  /** Intrinsic size of the largest source; every source shares its aspect ratio. */
  width: number;
  height: number;
  /** Smallest first, per format. */
  sources: { avif: RenderSource[]; webp: RenderSource[] };
}

export const renders: readonly Render[] = ${literal(renders)};
`;
  await writeFile(MANIFEST, source);
  return renders.length;
}

/* ---------- run ---------- */

const { values: args } = parseArgs({
  options: {
    url: { type: "string", default: process.env.RENDER_URL ?? "http://localhost:3217/" },
    only: { type: "string" },
    framing: { type: "string" },
    /** Rewrite the manifest from the files already in public/renders (after an alt-text edit). */
    manifest: { type: "boolean", default: false },
  },
});
const only = args.only?.split(",").map((s) => s.trim());
const states = STATES.filter((s) => !only || only.includes(s.id));
const framings = FRAMINGS.filter((f) => !args.framing || f.id === args.framing);
if (!states.length || !framings.length) throw new Error(`nothing to render for --only ${args.only} --framing ${args.framing}`);
for (const s of STATES) if (s.alt.length > 150 || !s.alt.startsWith("Simulated")) throw new Error(`alt text for ${s.id} breaks the rules`);
if (args.manifest) {
  console.log(`Wrote ${path.relative(ROOT, MANIFEST)} (${await writeManifest()} renders)`);
  process.exit(0);
}

const response = await fetch(args.url).catch(() => null);
if (!response?.ok) throw new Error(`no dev server at ${args.url}: start it with \`npm run dev\``);

await mkdir(OUT_DIR, { recursive: true });
const tmp = await mkdtemp(path.join(tmpdir(), "render-stills-"));
console.log(`Rendering ${states.length} state(s) x ${framings.length} framing(s) from ${args.url}; lossless PNGs in ${tmp}`);

const browser = await chromium.launch({ channel: "chrome", headless: true, args: LAUNCH_ARGS });
const encoded: Encoded[] = [];
try {
  for (const framing of framings) {
    const context = await browser.newContext({ ...framing.context });
    await context.addInitScript(installHelpers);
    try {
      for (const state of states) {
        if (framing.states && !framing.states.includes(state.id)) continue;
        const started = Date.now();
        console.log(`  ${state.id} / ${framing.id}`);
        const { png, box } = await captureWithRetry(context, args.url, framing, state);
        const pngPath = path.join(tmp, `${state.id}-${framing.id}.png`);
        await writeFile(pngPath, png);
        console.log(
          `    canvas ${box.width}x${box.height} CSS px drawn at ${box.bufferWidth}x${box.bufferHeight}; PNG ${png.length} B (${((Date.now() - started) / 1000).toFixed(1)} s)`,
        );
        encoded.push(...(await encodeStill(png, state.id, framing)));
      }
    } finally {
      await context.close();
    }
  }
} finally {
  await browser.close();
}

const count = await writeManifest();
console.log(`\nWrote ${path.relative(ROOT, MANIFEST)} (${count} renders)\n`);
console.log(`${"file".padEnd(38)}${"size".padStart(10)}  q`);
for (const f of encoded) console.log(`${path.relative(ROOT, f.file).padEnd(38)}${`${f.bytes} B`.padStart(10)}  ${f.quality}`);
const total = encoded.reduce((sum, f) => sum + f.bytes, 0);
console.log(`${encoded.length} files, ${total} B`);
