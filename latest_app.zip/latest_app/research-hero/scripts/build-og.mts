/**
 * Builds the share image and the Apple touch icon.
 *
 *   npm run render:stills     # first: the share image uses the wide overview still
 *   npm run build:og
 *   node scripts/build-og.mts --still /path/to/overview-wide.png   # a lossless still instead
 *
 * - src/app/opengraph-image.jpg (1200x630, JPEG q82, target 100 KB or less) and opengraph-image.alt.txt:
 *   scripts/og-template.html filled with the real woff2 fonts from tools/perf/fonts and the wide overview
 *   still, rendered in Chrome at 2x once document.fonts is ready, then downsampled by sharp.
 * - src/app/apple-icon.png (180x180): src/app/icon.svg on a solid void background (iOS shows no transparency).
 */
import { chromium } from "@playwright/test";
import sharp from "sharp";
import { access, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { parseArgs } from "node:util";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const at = (...parts: string[]) => path.join(ROOT, ...parts);

/** The words, as in src/content/profile.ts (checked below, so a copy edit there flags a stale image). */
const NAME = "Madhavi Tripathi";
const ROLE = "Translational scientist";
const HEADLINE = ["Nanomaterials for delivery.", "Light and sound for imaging."] as const;
const ALT =
  "Madhavi Tripathi, translational scientist. Nanomaterials for delivery. Light and sound for imaging. Beside the words, a simulated lab: tissue with a tumor, a probe on top, and one nanoparticle shown cut open in a magnifier.";

const FONTS = {
  NEWSREADER_ROMAN: at("tools/perf/fonts/newsreader-roman-latin--wght_350-500_opsz_6-72.woff2"),
  NEWSREADER_ITALIC: at("tools/perf/fonts/newsreader-italic-latin--wght_400_static_opsz_6-72.woff2"),
  MONA_SANS: at("tools/perf/fonts/mona-sans-latin--wght_400-600_wdth_85-100.woff2"),
};
const STILLS = [at("public/renders/overview-wide-1600.avif"), at("public/renders/overview-wide-1600.webp")];
const TEMPLATE = at("scripts/og-template.html");
const ICON_SVG = at("src/app/icon.svg");
const OUT = {
  og: at("src/app/opengraph-image.jpg"),
  alt: at("src/app/opengraph-image.alt.txt"),
  icon: at("src/app/apple-icon.png"),
};

const SIZE = { width: 1200, height: 630 };
const JPEG_QUALITY = 82;
const OG_TARGET_BYTES = 100_000;
const VOID = "#060a0c";

const MIME: Record<string, string> = { ".avif": "image/avif", ".webp": "image/webp", ".png": "image/png", ".jpg": "image/jpeg", ".woff2": "font/woff2" };
const dataUrl = async (file: string) => `data:${MIME[path.extname(file)] ?? "application/octet-stream"};base64,${(await readFile(file)).toString("base64")}`;
const escape = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const exists = (file: string) =>
  access(file).then(
    () => true,
    () => false,
  );

const { values: args } = parseArgs({ options: { still: { type: "string" } } });

/* ---------- share image ---------- */

const profile = await readFile(at("src/content/profile.ts"), "utf8");
for (const words of [NAME, ROLE, ...HEADLINE]) {
  if (!profile.includes(`"${words}"`)) console.warn(`warning: "${words}" is no longer in src/content/profile.ts; update this script`);
}

let still = args.still ? path.resolve(args.still) : undefined;
if (!still) for (const candidate of STILLS) if (!still && (await exists(candidate))) still = candidate;
if (!still || !(await exists(still))) throw new Error("no overview still: run `npm run render:stills` first");

const tokens: Record<string, string> = {
  NEWSREADER_ROMAN: await dataUrl(FONTS.NEWSREADER_ROMAN),
  NEWSREADER_ITALIC: await dataUrl(FONTS.NEWSREADER_ITALIC),
  MONA_SANS: await dataUrl(FONTS.MONA_SANS),
  STILL: await dataUrl(still),
  NAME: escape(NAME),
  ROLE: escape(ROLE),
  LINE_1: escape(HEADLINE[0]),
  LINE_2: escape(HEADLINE[1]),
};
const html = (await readFile(TEMPLATE, "utf8")).replace(/\{\{([A-Z_0-9]+)\}\}/g, (match, key: string) => {
  if (!(key in tokens)) throw new Error(`the template uses an unknown token ${match}`);
  return tokens[key];
});

const browser = await chromium.launch({ channel: "chrome", headless: true, args: ["--use-angle=metal", "--ignore-gpu-blocklist", "--enable-gpu", "--hide-scrollbars"] });
let png: Buffer;
try {
  const page = await browser.newPage({ viewport: SIZE, deviceScaleFactor: 2 });
  await page.setContent(html, { waitUntil: "load" });
  const check = await page.evaluate(async () => {
    const faces = Array.from(document.fonts);
    await Promise.all(faces.map((f) => f.load().catch(() => f)));
    await document.fonts.ready;
    const img = document.querySelector("img")!;
    await img.decode().catch(() => {});
    const inside = (el: Element) => {
      const r = el.getBoundingClientRect();
      return r.left >= 0 && r.top >= 0 && r.right <= window.innerWidth && r.bottom <= window.innerHeight;
    };
    return {
      fonts: faces.map((f) => `${f.family} ${f.style} ${f.status}`),
      image: img.naturalWidth > 0,
      // Each headline sentence on one line, and every text box on the canvas.
      oneLine: Array.from(document.querySelectorAll("h1 span")).every((s) => s.getClientRects().length === 1),
      inside: Array.from(document.querySelectorAll(".name, .role, h1 span")).every(inside),
    };
  });
  if (check.fonts.length !== 3 || check.fonts.some((f) => !f.endsWith("loaded"))) throw new Error(`fonts did not load: ${check.fonts.join(", ")}`);
  if (!check.image) throw new Error(`the still did not decode: ${still}`);
  if (!check.oneLine || !check.inside) throw new Error("the text does not fit the layout");
  png = await page.screenshot({ type: "png", clip: { x: 0, y: 0, ...SIZE } });
} finally {
  await browser.close();
}

const og = await sharp(png).resize(SIZE.width, SIZE.height, { kernel: "lanczos3" }).jpeg({ quality: JPEG_QUALITY, mozjpeg: true }).toBuffer();
await writeFile(OUT.og, og);
await writeFile(OUT.alt, ALT);

/* ---------- Apple touch icon ---------- */

// Rasterize the 32-unit viewBox at 360 px, then downsample, so curves are smooth at 180 px.
const icon = await sharp(await readFile(ICON_SVG), { density: (72 * 360) / 32 })
  .resize(180, 180, { kernel: "lanczos3" })
  .flatten({ background: VOID })
  .png({ compressionLevel: 9 })
  .toBuffer();
await writeFile(OUT.icon, icon);

/* ---------- report ---------- */

for (const [file, bytes] of [
  [OUT.og, og.length],
  [OUT.alt, Buffer.byteLength(ALT)],
  [OUT.icon, icon.length],
] as const) {
  const meta = file.endsWith(".txt") ? "" : await sharp(await readFile(file)).metadata().then((m) => ` ${m.width}x${m.height} ${m.format}${m.hasAlpha ? " with alpha" : ""}`);
  console.log(`${path.relative(ROOT, file).padEnd(34)}${`${bytes} B`.padStart(9)}${meta}`);
}
console.log(`share image from ${path.relative(ROOT, still)}; ${og.length <= OG_TARGET_BYTES ? "within" : "OVER"} the ${OG_TARGET_BYTES} B target`);
