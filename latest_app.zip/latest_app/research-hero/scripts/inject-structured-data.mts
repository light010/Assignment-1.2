/*
  Puts the home page's structured data (JSON-LD) into the exported page.

    node scripts/inject-structured-data.mts        (runs after `next build`, before scripts/check-built.mts)

  The build writes the JSON-LD to out/structured-data.json (src/app/structured-data.json/route.ts, from
  src/lib/jsonld.ts). This script adds it to out/index.html as <script type="application/ld+json"> just before
  </body>, then deletes the file, which isn't a page of its own. Why not render it from React: everything a
  server component renders is also sent in the React payload that hydration reads, so the same 15 KB went out
  twice. Search engines read the tag in the HTML; React never needed it. React 19 leaves tags it didn't render
  in <body> alone during hydration.

  Exit status: 0 when the tag is in place (also when a previous run already put it there), 1 otherwise.
*/

import fs from "node:fs";
import path from "node:path";

const OUT = path.resolve(import.meta.dirname, "..", "out");
const SOURCE = path.join(OUT, "structured-data.json");
const PAGE = path.join(OUT, "index.html");
const TAG = '<script type="application/ld+json">';

function fail(message: string): never {
  console.error(`Structured data: ${message}`);
  process.exit(1);
}

if (!fs.existsSync(PAGE)) fail("out/index.html is missing; run the build first.");
let html = fs.readFileSync(PAGE, "utf8");

if (!fs.existsSync(SOURCE)) {
  if (html.includes(TAG)) {
    console.log("Structured data: already in out/index.html.");
    process.exit(0);
  }
  fail("out/structured-data.json is missing: the build should have written it (src/app/structured-data.json/route.ts).");
}

const json = fs.readFileSync(SOURCE, "utf8");
try {
  JSON.parse(json);
} catch (error) {
  fail(`out/structured-data.json isn't JSON (${(error as Error).message}).`);
}
// src/lib/jsonld.ts escapes "<", so nothing in the data can close the element early.
if (json.includes("<")) fail('the JSON-LD contains "<"; it must be escaped (src/lib/jsonld.ts).');
if (html.includes(TAG)) fail("out/index.html already has a JSON-LD script; the page shouldn't render one (src/app/page.tsx).");

const at = html.lastIndexOf("</body>");
if (at < 0) fail("out/index.html has no </body>.");
html = `${html.slice(0, at)}${TAG}${json}</script>${html.slice(at)}`;
fs.writeFileSync(PAGE, html);
fs.rmSync(SOURCE);
console.log(`Structured data: ${json.length.toLocaleString("en-US")} characters of JSON-LD in out/index.html.`);
