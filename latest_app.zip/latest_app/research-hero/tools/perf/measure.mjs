// Lab measurement of the hero: LCP, CLS, long tasks, LoAF, resource timing, three.js chunk timing,
// and interaction latency for scripted clicks. Playwright + local Chrome + CDP throttling.
// Usage: node measure.mjs <profile> <runs> [url] [--no-webgl] [--shot name.png] [--interact]
// Profiles:
//   mobile4x : 390x844 @DPR3, touch, Android UA, Slow-4G/Fast-3G network (562.5 ms RTT, 1.44 Mbps down, 675 kbps up), 4x CPU
//   mobile6x : same, 6x CPU (sensitivity check: the host is an Apple M4 Pro, far faster than a mid-tier phone)
//   desktop  : 1440x900 @DPR1, 40 ms RTT, 10 Mbps down, 1x CPU (Lighthouse desktop-like)
import { chromium } from 'playwright-core';
import fs from 'node:fs';

const [profileName = 'mobile4x', runsArg = '3', urlArg] = process.argv.slice(2).filter((a) => !a.startsWith('--'));
const flags = process.argv.slice(2);
const noWebGL = flags.includes('--no-webgl');
const interact = flags.includes('--interact');
const reduced = flags.includes('--reduced');
const shotIdx = flags.indexOf('--shot');
const shotName = shotIdx >= 0 ? flags[shotIdx + 1] : null;
const url = urlArg && urlArg.startsWith('http') ? urlArg : 'http://localhost:3291/';
const runs = Number(runsArg);

const ANDROID_UA =
  'Mozilla/5.0 (Linux; Android 11; moto g power (2022)) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36';
const PROFILES = {
  mobile4x: { viewport: { width: 390, height: 844 }, dpr: 3, mobile: true, net: { latency: 562.5, down: 180000, up: 84375 }, cpu: 4 },
  mobile6x: { viewport: { width: 390, height: 844 }, dpr: 3, mobile: true, net: { latency: 562.5, down: 180000, up: 84375 }, cpu: 6 },
  desktop: { viewport: { width: 1440, height: 900 }, dpr: 1, mobile: false, net: { latency: 40, down: 1250000, up: 1250000 }, cpu: 1 },
  desktopFast: { viewport: { width: 1440, height: 900 }, dpr: 2, mobile: false, net: null, cpu: 1 },
};
const P = PROFILES[profileName];
if (!P) throw new Error('unknown profile ' + profileName);

const INIT = () => {
  const P = (window.__perf = { lcp: [], shifts: [], longtasks: [], loaf: [], fcp: null, events: [], ready: null, gl: null });
  const safe = (fn) => { try { fn(); } catch (e) { P.err = (P.err || '') + e.message + ';'; } };
  const describe = (el) => {
    if (!el) return null;
    const r = el.getBoundingClientRect();
    return {
      tag: el.tagName,
      cls: (el.className && el.className.toString ? el.className.toString() : '').slice(0, 90),
      text: (el.textContent || '').trim().slice(0, 90),
      rect: [Math.round(r.x), Math.round(r.y), Math.round(r.width), Math.round(r.height)],
    };
  };
  safe(() => new PerformanceObserver((l) => { for (const e of l.getEntries()) P.lcp.push({ t: e.startTime, size: e.size, url: e.url, el: describe(e.element) }); }).observe({ type: 'largest-contentful-paint', buffered: true }));
  safe(() => new PerformanceObserver((l) => { for (const e of l.getEntries()) P.shifts.push({ t: e.startTime, v: e.value, input: e.hadRecentInput, src: (e.sources || []).map((s) => describe(s.node)) }); }).observe({ type: 'layout-shift', buffered: true }));
  safe(() => new PerformanceObserver((l) => { for (const e of l.getEntries()) P.longtasks.push({ t: e.startTime, d: e.duration }); }).observe({ type: 'longtask', buffered: true }));
  safe(() => new PerformanceObserver((l) => { for (const e of l.getEntries()) P.loaf.push({ t: e.startTime, d: e.duration, block: e.blockingDuration, scripts: [...(e.scripts || [])].sort((a, b) => b.duration - a.duration).slice(0, 3).map((s) => ({ src: (s.sourceURL || '').split('/').pop(), fn: s.sourceFunctionName, inv: s.invoker, d: Math.round(s.duration) })) }); }).observe({ type: 'long-animation-frame', buffered: true }));
  safe(() => new PerformanceObserver((l) => { for (const e of l.getEntries()) if (e.name === 'first-contentful-paint') P.fcp = e.startTime; }).observe({ type: 'paint', buffered: true }));
  safe(() => new PerformanceObserver((l) => { for (const e of l.getEntries()) if (e.interactionId) P.events.push({ id: e.interactionId, name: e.name, t: e.startTime, d: e.duration, input: e.processingStart - e.startTime, proc: e.processingEnd - e.processingStart, pres: e.startTime + e.duration - e.processingEnd, target: describe(e.target)?.text?.slice(0, 30) }); }).observe({ type: 'event', buffered: true, durationThreshold: 16 }));
  // When the lab reveals the canvas (wrapper data-status flips to "ready"), note the time.
  const mo = new MutationObserver(() => {
    const w = document.querySelector('[data-status]');
    if (w && !P.status0) P.status0 = { s: w.getAttribute('data-status'), t: performance.now() };
    if (w && w.getAttribute('data-status') === 'ready' && P.ready == null) P.ready = performance.now();
  });
  document.addEventListener('DOMContentLoaded', () => mo.observe(document.body, { subtree: true, attributes: true, attributeFilter: ['data-status'], childList: true }));
};

function median(a) {
  const s = [...a].filter((x) => x != null && !Number.isNaN(x)).sort((x, y) => x - y);
  if (!s.length) return null;
  const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
}
function clsSessionMax(shifts) {
  let max = 0, cur = 0, start = -1, last = -1;
  for (const s of shifts.filter((x) => !x.input).sort((a, b) => a.t - b.t)) {
    if (start < 0 || s.t - last > 1000 || s.t - start > 5000) { cur = 0; start = s.t; }
    cur += s.v; last = s.t; max = Math.max(max, cur);
  }
  return max;
}

const launchArgs = ['--use-angle=metal', '--ignore-gpu-blocklist', '--enable-gpu', '--hide-scrollbars'];
if (noWebGL) launchArgs.push('--disable-webgl', '--disable-3d-apis');
const browser = await chromium.launch({ channel: 'chrome', headless: true, args: launchArgs });
const results = [];
for (let i = 0; i < runs; i++) {
  const ctx = await browser.newContext({
    viewport: P.viewport,
    deviceScaleFactor: P.dpr,
    isMobile: P.mobile,
    hasTouch: P.mobile,
    userAgent: P.mobile ? ANDROID_UA : undefined,
    reducedMotion: reduced ? 'reduce' : 'no-preference',
  });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text().slice(0, 200)); });
  const cdp = await ctx.newCDPSession(page);
  await cdp.send('Network.enable');
  await cdp.send('Network.setCacheDisabled', { cacheDisabled: true });
  if (P.net) await cdp.send('Network.emulateNetworkConditions', { offline: false, latency: P.net.latency, downloadThroughput: P.net.down, uploadThroughput: P.net.up });
  if (P.cpu > 1) await cdp.send('Emulation.setCPUThrottlingRate', { rate: P.cpu });
  await page.addInitScript(INIT);
  const t0 = Date.now();
  await page.goto(url, { waitUntil: 'load', timeout: 120000 });
  const loadWall = Date.now() - t0;
  // Wait for the lab to reveal the canvas (or give up: no WebGL / fallback).
  const hasWebGL = await page.evaluate(() => { try { return !!document.createElement('canvas').getContext('webgl2'); } catch { return false; } });
  if (hasWebGL) await page.waitForFunction(() => window.__perf.ready != null, null, { timeout: 90000 }).catch(() => {});
  await page.waitForTimeout(4000); // let post-ready work (instrument images, first frames) land
  let interactions = null;
  if (interact) {
    const clicks = ['Ultrasound', 'Photoacoustics', 'Delivery', 'Design'];
    for (const label of clicks) {
      const btn = page.locator('[aria-label="What I do"] button', { hasText: label }).first();
      if (await btn.count()) { await btn.click(); await page.waitForTimeout(1500); }
    }
    // A segmented control inside the open chapter (Design: View -> Exploded), then Ultrasound -> Beamformer: Coherence.
    const exploded = page.getByRole('radio', { name: 'Exploded' });
    if (await exploded.count()) { await exploded.click(); await page.waitForTimeout(1500); }
    await page.locator('[aria-label="What I do"] button', { hasText: 'Ultrasound' }).first().click();
    await page.waitForTimeout(1200);
    const coh = page.getByRole('radio', { name: 'Coherence' }).first();
    if (await coh.count()) { await coh.click(); await page.waitForTimeout(1500); }
  }
  const data = await page.evaluate(() => {
    const nav = performance.getEntriesByType('navigation')[0];
    const res = performance.getEntriesByType('resource').map((r) => ({ name: r.name.replace(location.origin, ''), type: r.initiatorType, start: r.startTime, end: r.responseEnd, transfer: r.transferSize, body: r.encodedBodySize, decoded: r.decodedBodySize }));
    let gl = null;
    try {
      const c = document.createElement('canvas').getContext('webgl2');
      const ext = c && c.getExtension('WEBGL_debug_renderer_info');
      gl = c ? (ext ? c.getParameter(ext.UNMASKED_RENDERER_WEBGL) : 'webgl2 (renderer masked)') : null;
    } catch { gl = null; }
    return {
      perf: window.__perf,
      nav: { ttfb: nav.responseStart, dcl: nav.domContentLoadedEventEnd, load: nav.loadEventEnd, htmlTransfer: nav.transferSize, htmlBody: nav.encodedBodySize },
      res,
      gl,
      status: document.querySelector('[data-status]')?.getAttribute('data-status'),
      now: performance.now(),
    };
  });
  if (shotName && i === 0) await page.screenshot({ path: new URL('./' + shotName, import.meta.url).pathname, fullPage: false });
  const p = data.perf;
  const lcpLast = p.lcp[p.lcp.length - 1];
  const three = data.res.find((r) => r.name.includes('/_next/static/chunks/') && r.body > 100000 && r.decoded > 600000);
  const js = data.res.filter((r) => r.name.endsWith('.js'));
  const initialJs = js.filter((r) => r !== three);
  const fonts = data.res.filter((r) => r.name.endsWith('.woff2'));
  const css = data.res.filter((r) => r.name.endsWith('.css'));
  const lt = p.longtasks;
  const tbtUntil = (t) => lt.filter((x) => x.t < t).reduce((s, x) => s + Math.max(0, x.d - 50), 0);
  // Interactions: max duration per interactionId.
  const byId = new Map();
  for (const e of p.events) { const cur = byId.get(e.id); if (!cur || e.d > cur.d) byId.set(e.id, e); }
  const inter = [...byId.values()].sort((a, b) => a.t - b.t);
  const r = {
    run: i + 1,
    gl: data.gl,
    status: data.status,
    ttfb: Math.round(data.nav.ttfb),
    fcp: p.fcp != null ? Math.round(p.fcp) : null,
    lcp: lcpLast ? Math.round(lcpLast.t) : null,
    lcpEl: lcpLast ? lcpLast.el : null,
    lcpCandidates: p.lcp.map((e) => ({ t: Math.round(e.t), size: e.size, tag: e.el?.tag, text: e.el?.text?.slice(0, 40) })),
    cls: +clsSessionMax(p.shifts).toFixed(4),
    shifts: p.shifts.filter((s) => !s.input).map((s) => ({ t: Math.round(s.t), v: +s.v.toFixed(4), src: s.src.map((x) => x && `${x.tag}.${x.cls.slice(0, 40)}`) })),
    dcl: Math.round(data.nav.dcl),
    load: Math.round(data.nav.load),
    ready: p.ready != null ? Math.round(p.ready) : null,
    threeChunk: three ? { name: three.name.split('/').pop(), start: Math.round(three.start), end: Math.round(three.end), transfer: three.transfer, decoded: three.decoded } : null,
    initialJsTransfer: initialJs.reduce((s, x) => s + x.transfer, 0),
    initialJsDecoded: initialJs.reduce((s, x) => s + x.decoded, 0),
    initialJsLastEnd: Math.round(Math.max(...initialJs.map((x) => x.end))),
    fonts: fonts.map((f) => ({ name: f.name.split('/').pop(), transfer: f.transfer, end: Math.round(f.end) })),
    cssTransfer: css.reduce((s, x) => s + x.transfer, 0),
    htmlTransfer: data.nav.htmlTransfer,
    totalTransfer: data.res.reduce((s, x) => s + x.transfer, 0) + data.nav.htmlTransfer,
    longTasks: lt.length,
    longTaskMax: Math.round(Math.max(0, ...lt.map((x) => x.d))),
    tbtToLcp: Math.round(tbtUntil(lcpLast ? lcpLast.t : 0)),
    tbtToReady: Math.round(tbtUntil(p.ready ?? data.now)),
    tbtTotal: Math.round(tbtUntil(Infinity)),
    longTaskList: lt.map((x) => [Math.round(x.t), Math.round(x.d)]),
    loafTop: p.loaf.sort((a, b) => b.d - a.d).slice(0, 6).map((l) => ({ t: Math.round(l.t), d: Math.round(l.d), block: Math.round(l.block), scripts: l.scripts })),
    interactions: inter.map((e) => ({ target: e.target, name: e.name, d: Math.round(e.d), input: Math.round(e.input), proc: Math.round(e.proc), pres: Math.round(e.pres) })),
    errors,
    loadWall,
  };
  results.push(r);
  await ctx.close();
}
await browser.close();

const summary = {
  profile: profileName,
  url,
  runs,
  noWebGL,
  reduced,
  median: {
    ttfb: median(results.map((r) => r.ttfb)),
    fcp: median(results.map((r) => r.fcp)),
    lcp: median(results.map((r) => r.lcp)),
    cls: median(results.map((r) => r.cls)),
    dcl: median(results.map((r) => r.dcl)),
    load: median(results.map((r) => r.load)),
    ready: median(results.map((r) => r.ready)),
    threeStart: median(results.map((r) => r.threeChunk?.start)),
    threeEnd: median(results.map((r) => r.threeChunk?.end)),
    longTasks: median(results.map((r) => r.longTasks)),
    longTaskMax: median(results.map((r) => r.longTaskMax)),
    tbtToLcp: median(results.map((r) => r.tbtToLcp)),
    tbtToReady: median(results.map((r) => r.tbtToReady)),
    tbtTotal: median(results.map((r) => r.tbtTotal)),
    maxInteraction: median(results.map((r) => (r.interactions.length ? Math.max(...r.interactions.map((x) => x.d)) : null))),
  },
  range: {
    lcp: [Math.min(...results.map((r) => r.lcp)), Math.max(...results.map((r) => r.lcp))],
    fcp: [Math.min(...results.map((r) => r.fcp)), Math.max(...results.map((r) => r.fcp))],
    cls: [Math.min(...results.map((r) => r.cls)), Math.max(...results.map((r) => r.cls))],
  },
  results,
};
const out = new URL(`./result-${profileName}${noWebGL ? '-nowebgl' : ''}${reduced ? '-reduced' : ''}${interact ? '-interact' : ''}.json`, import.meta.url).pathname;
fs.writeFileSync(out, JSON.stringify(summary, null, 2));
console.log(JSON.stringify({ ...summary, results: undefined }, null, 2));
const r0 = results[0];
console.log('run1 LCP el:', JSON.stringify(r0.lcpEl), '\ncandidates:', JSON.stringify(r0.lcpCandidates));
console.log('run1 three:', JSON.stringify(r0.threeChunk), 'gl:', r0.gl, 'status:', r0.status);
console.log('run1 fonts:', JSON.stringify(r0.fonts));
console.log('run1 initial JS transfer/decoded:', r0.initialJsTransfer, r0.initialJsDecoded, 'css', r0.cssTransfer, 'html', r0.htmlTransfer, 'total', r0.totalTransfer);
console.log('run1 shifts:', JSON.stringify(r0.shifts));
console.log('run1 long tasks:', JSON.stringify(r0.longTaskList));
console.log('run1 LoAF top:', JSON.stringify(r0.loafTop));
if (interact) console.log('run1 interactions:', JSON.stringify(r0.interactions));
console.log('errors:', JSON.stringify(results.map((r) => r.errors)));
