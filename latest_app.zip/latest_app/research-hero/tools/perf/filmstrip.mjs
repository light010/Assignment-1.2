// Filmstrip of the first seconds on a throttled phone (Slow 4G, 4x CPU), 390x844 CSS px.
import { chromium } from 'playwright-core';
const browser = await chromium.launch({ channel: 'chrome', headless: true, args: ['--use-angle=metal', '--ignore-gpu-blocklist', '--enable-gpu'] });
const UA = 'Mozilla/5.0 (Linux; Android 11; moto g power (2022)) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36';
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1, isMobile: true, hasTouch: true, userAgent: UA });
const page = await ctx.newPage();
const cdp = await ctx.newCDPSession(page);
await cdp.send('Network.enable');
await cdp.send('Network.setCacheDisabled', { cacheDisabled: true });
await cdp.send('Network.emulateNetworkConditions', { offline: false, latency: 562.5, downloadThroughput: 180000, uploadThroughput: 84375 });
await cdp.send('Emulation.setCPUThrottlingRate', { rate: 4 });
const frames = [];
cdp.on('Page.screencastFrame', async (f) => { frames.push({ t: f.metadata.timestamp, data: f.data }); cdp.send('Page.screencastFrameAck', { sessionId: f.sessionId }).catch(() => {}); });
await cdp.send('Page.startScreencast', { format: 'jpeg', quality: 60, maxWidth: 390, maxHeight: 844, everyNthFrame: 1 });
const wall0 = Date.now() / 1000;
await page.goto('http://localhost:3291/', { waitUntil: 'commit' });
await new Promise((r) => setTimeout(r, 9000));
await cdp.send('Page.stopScreencast');
const fs = await import('node:fs');
const targets = [1.0, 1.6, 2.5, 3.5, 4.2, 4.8, 6.0, 7.5];
const picked = [];
for (const s of targets) {
  // last frame at or before wall0 + s
  const cand = frames.filter((f) => f.t <= wall0 + s).pop();
  if (!cand) continue;
  const name = `film_${s.toFixed(1)}s.jpg`;
  fs.writeFileSync(new URL('./' + name, import.meta.url).pathname, Buffer.from(cand.data, 'base64'));
  picked.push(`${name} (frame at +${(cand.t - wall0).toFixed(2)}s)`);
}
console.log(frames.length, 'frames;', picked.join('\n'));
await browser.close();
