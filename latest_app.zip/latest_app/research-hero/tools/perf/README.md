# Performance and accessibility measurement tools

Saved from the engineering review of the site plan (`docs/site-plan/D-engineering.md`), so the baseline can
be re-measured and the budgets enforced in CI (milestone M0).

- `measure.mjs`: LCP, CLS, long tasks, and lab-ready time under CDP throttling (phone and desktop profiles).
- `inp-raw.mjs`, `inp-stress.mjs`: taps sent as raw input during long tasks (Playwright clicks wait for idle).
- `budget-check.mjs` + `budgets.example.json`: per-route bytes (JS, CSS, HTML, preloaded fonts).
- `filmstrip.mjs`, `nojs.mjs`, `axe.mjs`, `csp-test.mjs`, `attribute.mjs`, `still.mjs`, `poster.mjs`,
  `worker-check.mjs`, `navcheck.mjs`: see D-engineering.md, Appendix B.
- `fonts/`: trimmed Newsreader and Mona Sans instances and the scripts that made them (font option B).
- `results/`: the measured baseline (27 September 2026). `evidence/`: filmstrip, no-WebGL render, posters,
  and the share-image prototype.

Paths inside some scripts point at the throwaway build copies used during the review; adjust them to this
project when wiring CI. Install with `npm install` in this folder (playwright-core uses the local Chrome).
