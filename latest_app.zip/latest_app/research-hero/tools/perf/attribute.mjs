// Attribute minified bytes of each client chunk to source modules/packages using production source maps.
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import { SourceMapConsumer } from 'source-map';
const dir = process.argv[2];
const html = fs.readFileSync(process.argv[3], 'utf8');
const initial = new Set([...html.matchAll(/<script\b([^>]*)\bsrc="\/_next\/static\/chunks\/([^"]+)"([^>]*)>/g)].filter((m) => !/noModule/i.test(m[1] + m[3])).map((m) => m[2]));
const group = (src) => {
  if (!src) return '(unmapped)';
  const s = src.replace(/^.*?node_modules\//, 'node_modules/');
  let m;
  if ((m = s.match(/^node_modules\/(@[^/]+\/[^/]+|[^/]+)/))) {
    const pkg = m[1];
    if (pkg === 'next') { const sub = s.match(/^node_modules\/next\/dist\/(compiled\/[^/]+|client|shared|[^/]+)/); return 'next/' + (sub ? sub[1] : ''); }
    return pkg;
  }
  const t = s.match(/src\/(.+)$/);
  return t ? 'src/' + t[1] : s.slice(-60);
};
const totals = {};
for (const f of fs.readdirSync(dir).filter((f) => f.endsWith('.js'))) {
  const code = fs.readFileSync(path.join(dir, f), 'utf8');
  const mm = code.match(/\/\/# sourceMappingURL=(\S+)\s*$/);
  const mapFile = mm ? path.join(dir, mm[1]) : path.join(dir, f + '.map');
  if (!fs.existsSync(mapFile)) continue;
  const raw = JSON.parse(fs.readFileSync(mapFile, 'utf8'));
  const lines = code.split('\n');
  const bytes = {};
  await SourceMapConsumer.with(raw, null, (c) => {
    const byLine = new Map();
    c.eachMapping((m) => { if (!byLine.has(m.generatedLine)) byLine.set(m.generatedLine, []); byLine.get(m.generatedLine).push(m); });
    for (const [ln, maps] of byLine) {
      maps.sort((a, b) => a.generatedColumn - b.generatedColumn);
      const len = (lines[ln - 1] || '').length;
      for (let i = 0; i < maps.length; i++) {
        const end = i + 1 < maps.length ? maps[i + 1].generatedColumn : len;
        const k = group(maps[i].source);
        bytes[k] = (bytes[k] || 0) + Math.max(0, end - maps[i].generatedColumn);
      }
    }
  });
  const total = Buffer.byteLength(code);
  const gz = zlib.gzipSync(code, { level: 9 }).length;
  const kind = initial.has(f) ? 'initial' : 'lazy';
  const top = Object.entries(bytes).sort((a, b) => b[1] - a[1]).slice(0, 9);
  console.log(`\n${f} [${kind}] raw ${(total / 1024).toFixed(1)} KB, gzip ${(gz / 1024).toFixed(1)} KB`);
  for (const [k, v] of top) { console.log(`   ${(v / 1024).toFixed(1).padStart(7)} KB raw ~${((v / total) * gz / 1024).toFixed(1).padStart(5)} KB gz  ${k}`); totals[kind + ':' + k] = (totals[kind + ':' + k] || 0) + (v / total) * gz; }
}
console.log('\n== initial JS by package/module (approx. gzip KB, proportional attribution)');
for (const [k, v] of Object.entries(totals).filter(([k]) => k.startsWith('initial:')).sort((a, b) => b[1] - a[1]).slice(0, 16)) console.log(`   ${(v / 1024).toFixed(1).padStart(6)}  ${k.slice(8)}`);
