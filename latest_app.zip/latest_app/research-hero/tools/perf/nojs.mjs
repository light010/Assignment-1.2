import { chromium } from 'playwright-core';
const browser = await chromium.launch({ channel: 'chrome', headless: true });
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, javaScriptEnabled: false });
const page = await ctx.newPage();
await page.goto('http://localhost:3291/', { waitUntil: 'load' });
await page.waitForTimeout(800);
await page.screenshot({ path: new URL('./nojs-1440.png', import.meta.url).pathname });
const vis = await page.evaluate(() => {
  const q = (s) => document.querySelector(s);
  const op = (el) => { let o = 1; while (el) { o *= Number(getComputedStyle(el).opacity); el = el.parentElement; } return o; };
  return {
    headerName: op(q('header a')),
    nav: op(q('nav[aria-label="Primary"]')),
    console: op(q('[aria-label="What I do"]')),
    instrument: op(q('figure')),
    h1: op(q('h1')),
  };
});
console.log('effective opacity with JS disabled:', JSON.stringify(vis));
await browser.close();
