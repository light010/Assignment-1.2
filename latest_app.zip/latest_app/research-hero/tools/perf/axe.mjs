// axe-core 4.13 scan (WCAG 2.0/2.1/2.2 A+AA tags) of the hero in several states, at 390 and 1440 px.
import { chromium } from 'playwright-core';
import fs from 'node:fs';
const axeSrc = fs.readFileSync(new URL('./node_modules/axe-core/axe.min.js', import.meta.url), 'utf8');
const url = process.argv[2] || 'http://localhost:3291/';
const browser = await chromium.launch({ channel: 'chrome', headless: true, args: ['--use-angle=metal', '--ignore-gpu-blocklist', '--enable-gpu'] });
const all = {};
for (const vp of [{ w: 390, h: 844, mobile: true }, { w: 1440, h: 900, mobile: false }]) {
  const ctx = await browser.newContext({ viewport: { width: vp.w, height: vp.h }, isMobile: vp.mobile, hasTouch: vp.mobile });
  const page = await ctx.newPage();
  await page.goto(url, { waitUntil: 'load' });
  await page.waitForSelector('[data-status="ready"]', { timeout: 30000 }).catch(() => {});
  await page.waitForTimeout(2500);
  const states = [['overview', null], ['design', 'Design'], ['deliver', 'Delivery'], ['photoacoustic', 'Photoacoustics'], ['ultrasound', 'Ultrasound']];
  for (const [name, label] of states) {
    if (label) { await page.locator('[aria-label="What I do"] button', { hasText: label }).first().click(); await page.waitForTimeout(1800); }
    await page.addScriptTag({ content: axeSrc });
    const res = await page.evaluate(async () => {
      const r = await window.axe.run(document, { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22aa', 'best-practice'] }, resultTypes: ['violations', 'incomplete'] });
      const pick = (v) => ({ id: v.id, impact: v.impact, tags: v.tags.filter((t) => t.startsWith('wcag')).join(','), n: v.nodes.length, nodes: v.nodes.slice(0, 4).map((n) => (n.target.join(' ') + ' :: ' + (n.failureSummary || '').replace(/\s+/g, ' ')).slice(0, 260)) });
      return { violations: r.violations.map(pick), incomplete: r.incomplete.map((v) => ({ id: v.id, n: v.nodes.length, why: (v.nodes[0]?.any?.[0]?.message || '').slice(0, 140) })) };
    });
    all[`${vp.w}:${name}`] = res;
  }
  await ctx.close();
}
await browser.close();
fs.writeFileSync(new URL('./axe-results.json', import.meta.url), JSON.stringify(all, null, 2));
for (const [k, v] of Object.entries(all)) {
  console.log(`\n== ${k}: ${v.violations.length} violation types; incomplete: ${v.incomplete.map((i) => `${i.id}(${i.n})`).join(', ')}`);
  for (const x of v.violations) { console.log(`  [${x.impact}] ${x.id} (${x.tags || 'best-practice'}) x${x.n}`); for (const n of x.nodes) console.log('     ', n); }
}
