// Raw-input INP stress test. Playwright's click() waits for the page's main thread (actionability checks),
// so it can never land a tap *during* a long task. Here taps are sent as raw CDP mouse events at fixed
// times, so the browser timestamps them when "the finger lands" and the Event Timing API reports how long
// the page took to respond (input delay + processing + presentation).
import { chromium } from 'playwright-core';
const cpu = Number(process.argv[2] || 4);
const runs = Number(process.argv[3] || 3);
const browser = await chromium.launch({ channel: 'chrome', headless: true, args: ['--use-angle=metal', '--ignore-gpu-blocklist', '--enable-gpu'] });
const UA = 'Mozilla/5.0 (Linux; Android 11; moto g power (2022)) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36';
const opts = { viewport: { width: 390, height: 844 }, deviceScaleFactor: 3, isMobile: true, hasTouch: true, userAgent: UA };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// 1) Coordinates from an unthrottled load (same viewport, so the same layout).
const probe = await (await browser.newContext(opts)).newPage();
await probe.goto('http://localhost:3291/', { waitUntil: 'load' });
await probe.waitForSelector('[data-status="ready"]', { timeout: 30000 });
await sleep(1500);
const center = async (loc) => { await loc.scrollIntoViewIfNeeded(); const b = await loc.boundingBox(); return { x: b.x + b.width / 2, y: b.y + b.height / 2 }; };
const paBtn = await center(probe.locator('[aria-label="What I do"] button', { hasText: 'Photoacoustics' }).first());
const scrollY0 = await probe.evaluate(() => scrollY);
await probe.locator('[aria-label="What I do"] button', { hasText: 'Photoacoustics' }).first().click();
await sleep(1500);
const medium = await center(probe.getByRole('radio', { name: 'Medium' }));
const darker = await center(probe.getByRole('radio', { name: 'Darker' }));
const scrollY1 = await probe.evaluate(() => scrollY);
console.log('coords', { paBtn, medium, darker, scrollY0, scrollY1 });
await probe.context().close();

async function setup() {
  const ctx = await browser.newContext(opts);
  const page = await ctx.newPage();
  const cdp = await ctx.newCDPSession(page);
  await cdp.send('Network.enable');
  await cdp.send('Network.setCacheDisabled', { cacheDisabled: true });
  await cdp.send('Network.emulateNetworkConditions', { offline: false, latency: 562.5, downloadThroughput: 180000, uploadThroughput: 84375 });
  await cdp.send('Emulation.setCPUThrottlingRate', { rate: cpu });
  await page.addInitScript(() => {
    window.__ev = [];
    new PerformanceObserver((l) => { for (const e of l.getEntries()) if (e.interactionId) window.__ev.push({ id: e.interactionId, name: e.name, t: Math.round(e.startTime), d: e.duration, wait: Math.round(e.processingStart - e.startTime), txt: (e.target?.textContent || '').slice(0, 20) }); }).observe({ type: 'event', buffered: true, durationThreshold: 16 });
  });
  return { ctx, page, cdp };
}
const tap = (cdp, p) => {
  cdp.send('Input.dispatchMouseEvent', { type: 'mousePressed', x: p.x, y: p.y, button: 'left', clickCount: 1 }).catch(() => {});
  setTimeout(() => cdp.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: p.x, y: p.y, button: 'left', clickCount: 1 }).catch(() => {}), 60);
};
const worst = (ev) => { const m = new Map(); for (const e of ev) { const c = m.get(e.id); if (!c || e.d > c.d) m.set(e.id, e); } return [...m.values()].map((e) => `${e.txt || '?'} ${e.name}@${e.t}ms: ${e.d}ms (input delay ${e.wait}ms)`); };
const res = { cpu, A: [], B: [] };
for (let i = 0; i < runs; i++) {
  { // A: tap the Photoacoustics chapter at 4.8 s, 5.2 s and 5.6 s after navigation (the console is visible from ~4.5 s).
    const { ctx, page, cdp } = await setup();
    const t0 = Date.now();
    await page.goto('http://localhost:3291/', { waitUntil: 'commit' });
    for (const at of [4800]) { const wait = at - (Date.now() - t0); if (wait > 0) await sleep(wait); tap(cdp, paBtn); }
    await sleep(6000);
    res.A.push(worst(await page.evaluate(() => window.__ev)));
    await ctx.close();
  }
  { // B: after the lab is ready and Photoacoustics has drawn once, tap Medium then Darker 150 ms apart.
    const { ctx, page, cdp } = await setup();
    await page.goto('http://localhost:3291/', { waitUntil: 'load' });
    await page.waitForSelector('[data-status="ready"]', { timeout: 60000 });
    await page.evaluate((y) => window.scrollTo(0, y), scrollY0);
    await sleep(3000);
    tap(cdp, paBtn);
    await sleep(3500);
    res.B.push('scrollY=' + (await page.evaluate(() => scrollY)) + ' chapter open: ' + (await page.evaluate(() => document.querySelector('[aria-label="What I do"] [aria-pressed="true"]')?.textContent)));
    await page.evaluate(() => (window.__ev = []));
    tap(cdp, medium);
    await sleep(150);
    tap(cdp, darker);
    await sleep(5000);
    res.B.push(worst(await page.evaluate(() => window.__ev)));
    res.B.push('skin now: ' + (await page.evaluate(() => [...document.querySelectorAll('[role=radio][aria-checked=true]')].map((b) => b.textContent).join(','))));
    await ctx.close();
  }
}
await browser.close();
console.log(JSON.stringify(res, null, 1));
