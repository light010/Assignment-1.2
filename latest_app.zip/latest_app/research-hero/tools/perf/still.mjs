// Capture an engine still (overview state) for the OG prototype.
import { chromium } from 'playwright-core';
const browser = await chromium.launch({ channel: 'chrome', headless: true, args: ['--use-angle=metal', '--ignore-gpu-blocklist', '--enable-gpu', '--hide-scrollbars'] });
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1, reducedMotion: 'reduce' });
const page = await ctx.newPage();
await page.goto('http://localhost:3291/', { waitUntil: 'load' });
await page.waitForSelector('[data-status="ready"]', { timeout: 30000 });
await page.waitForTimeout(2500);
// Hide the copy, callouts and instrument so only the scene remains.
await page.addStyleTag({ content: 'header, h1, .text-lede, [aria-label="What I do"], figure, [aria-live], button { visibility: hidden !important; } .wide\\:block.bg-\\[linear-gradient\\(90deg\\,var\\(--color-void\\)_0\\%\\,rgb\\(6_10_12\\/0\\.9\\)_30\\%\\,rgb\\(6_10_12\\/0\\.45\\)_48\\%\\,transparent_64\\%\\)\\] { display: none !important; }' });
await page.waitForTimeout(600);
await page.screenshot({ path: new URL('./hero-export/assets/og/scene.jpg', import.meta.url).pathname, type: 'jpeg', quality: 78, clip: { x: 610, y: 130, width: 760, height: 660 } });
await browser.close();
console.log('ok');
