// Per-route size budget check for a Next.js build (prototype for CI).
// Next 16 no longer prints "First Load JS" in `next build`, so this reads the prerendered HTML, follows the
// <script src>, stylesheet and font-preload references, and sums compressed sizes per route.
// Usage: node budget-check.mjs <html-root> <static-root> [budgets.json]
//   static export:  node budget-check.mjs out out
//   server build:   node budget-check.mjs .next/server/app .next   (static URLs /_next/static/... map to .next/static/...)
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

const [htmlRoot, staticRoot, budgetsFile] = process.argv.slice(2);
if (!htmlRoot || !staticRoot) { console.error('usage: node budget-check.mjs <html-root> <static-root> [budgets.json]'); process.exit(2); }
const budgets = budgetsFile ? JSON.parse(fs.readFileSync(budgetsFile, 'utf8')) : null;
const kb = (n) => Math.round(n / 102.4) / 10;

function walk(dir) {
  const out = [];
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) out.push(...walk(p));
    else if (e.name.endsWith('.html')) out.push(p);
  }
  return out;
}
const cache = new Map();
function sizes(url) {
  if (cache.has(url)) return cache.get(url);
  const rel = url.replace(/^\/_next\//, staticRoot.endsWith('.next') ? '' : '_next/').split('?')[0];
  const file = path.join(staticRoot, rel);
  if (!fs.existsSync(file)) { cache.set(url, null); return null; }
  const buf = fs.readFileSync(file);
  const s = {
    raw: buf.length,
    gzip: zlib.gzipSync(buf, { level: 9 }).length,
    br: url.endsWith('.woff2') ? buf.length : zlib.brotliCompressSync(buf, { params: { [zlib.constants.BROTLI_PARAM_QUALITY]: 11 } }).length,
    three: url.endsWith('.js') && buf.includes('WebGLRenderer'),
  };
  cache.set(url, s);
  return s;
}

const rows = [];
let failed = false;
for (const file of walk(htmlRoot)) {
  const html = fs.readFileSync(file, 'utf8');
  const route = '/' + path.relative(htmlRoot, file).replace(/\\/g, '/').replace(/(^|\/)index\.html$/, '').replace(/\.html$/, '');
  const scripts = [...html.matchAll(/<script\b([^>]*)\bsrc="([^"]+)"([^>]*)>/g)]
    .filter((m) => !/noModule/i.test(m[1] + m[3]))
    .map((m) => m[2]);
  const css = [...html.matchAll(/<link\b[^>]*rel="stylesheet"[^>]*href="([^"]+)"/g)].map((m) => m[1]);
  const fonts = [...html.matchAll(/<link\b[^>]*rel="preload"[^>]*href="([^"]+\.woff2)"[^>]*as="font"/g)].map((m) => m[1]);
  const sum = (urls, key) => [...new Set(urls)].reduce((t, u) => t + (sizes(u)?.[key] ?? 0), 0);
  const threeInInitial = [...new Set(scripts)].some((u) => sizes(u)?.three);
  const r = {
    route,
    jsGzip: sum(scripts, 'gzip'),
    jsBr: sum(scripts, 'br'),
    jsRaw: sum(scripts, 'raw'),
    cssGzip: sum(css, 'gzip'),
    fontBytes: sum(fonts, 'raw'),
    htmlGzip: zlib.gzipSync(Buffer.from(html), { level: 9 }).length,
    threeInInitial,
  };
  const b = budgets?.[route] ?? budgets?.['*'];
  if (b) {
    r.over = [];
    if (b.jsGzipKB != null && r.jsGzip / 1024 > b.jsGzipKB) r.over.push(`js ${kb(r.jsGzip)} > ${b.jsGzipKB} KB`);
    if (b.fontKB != null && r.fontBytes / 1024 > b.fontKB) r.over.push(`fonts ${kb(r.fontBytes)} > ${b.fontKB} KB`);
    if (b.cssGzipKB != null && r.cssGzip / 1024 > b.cssGzipKB) r.over.push(`css ${kb(r.cssGzip)} > ${b.cssGzipKB} KB`);
    if (b.htmlGzipKB != null && r.htmlGzip / 1024 > b.htmlGzipKB) r.over.push(`html ${kb(r.htmlGzip)} > ${b.htmlGzipKB} KB`);
    if (b.noThreeInInitial && threeInInitial) r.over.push('three.js in the initial chunks');
    if (r.over.length) failed = true;
  }
  rows.push(r);
}
rows.sort((a, b) => a.route.localeCompare(b.route));
console.log('route'.padEnd(34), 'JS gz KB', 'JS br KB', 'JS raw KB', 'CSS gz KB', 'fonts KB', 'HTML gz KB', 'three?', 'budget');
for (const r of rows) {
  console.log(
    r.route.padEnd(34),
    String(kb(r.jsGzip)).padStart(8), String(kb(r.jsBr)).padStart(8), String(kb(r.jsRaw)).padStart(9),
    String(kb(r.cssGzip)).padStart(9), String(kb(r.fontBytes)).padStart(8), String(kb(r.htmlGzip)).padStart(10),
    String(r.threeInInitial).padStart(6), r.over ? (r.over.length ? 'FAIL: ' + r.over.join('; ') : 'ok') : '',
  );
}
const lazyThree = [...cache.entries()].filter(([, s]) => s?.three);
if (!lazyThree.length) {
  // three.js is loaded lazily, so it is not referenced by any HTML; report its chunk from the static folder.
  const dir = path.join(staticRoot, staticRoot.endsWith('.next') ? 'static/chunks' : '_next/static/chunks');
  const limit = budgets?.['/']?.lazyThreeGzipKB;
  for (const f of fs.existsSync(dir) ? fs.readdirSync(dir) : []) {
    const buf = fs.readFileSync(path.join(dir, f));
    if (!f.endsWith('.js') || !buf.includes('WebGLRenderer')) continue;
    const gz = zlib.gzipSync(buf, { level: 9 }).length;
    const over = limit != null && gz / 1024 > limit;
    if (over) failed = true;
    console.log(`lazy three.js chunk ${f}: ${kb(buf.length)} KB raw, ${kb(gz)} KB gzip, ${kb(zlib.brotliCompressSync(buf).length)} KB brotli${limit != null ? (over ? ` FAIL: > ${limit} KB` : ' ok') : ''}`);
  }
}
process.exit(failed ? 1 : 0);
