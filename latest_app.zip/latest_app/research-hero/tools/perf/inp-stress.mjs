// Rapid-tap stress test: how long does a tap wait when it lands during the lab's deferred image work?
// Scenario A: tap "Photoacoustics" as soon as the console is visible (startup long task window).
// Scenario B: after ready, open Photoacoustics, then tap Skin tone "Medium" and 150 ms later "Darker".
import { chromium } from 'playwright-core';
const cpu = Number(process.argv[2] || 4);
const browser = await chromium.launch({ channel: 'chrome', headless: true, args: ['--use-angle=metal', '--ignore-gpu-blocklist', '--enable-gpu'] });
const UA = 'Mozilla/5.0 (Linux; Android 11; moto g power (2022)) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36';
async function setup() {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 3, isMobile: true, hasTouch: true, userAgent: UA });
  const page = await ctx.newPage();
  const cdp = await ctx.newCDPSession(page);
  await cdp.send('Network.enable');
  await cdp.send('Network.setCacheDisabled', { cacheDisabled: true });
  await cdp.send('Network.emulateNetworkConditions', { offline: false, latency: 562.5, downloadThroughput: 180000, uploadThroughput: 84375 });
  await cdp.send('Emulation.setCPUThrottlingRate', { rate: cpu });
  await page.addInitScript(() => {
    window.__ev = [];
    new PerformanceObserver((l) => { for (const e of l.getEntries()) if (e.interactionId) window.__ev.push({ id: e.interactionId, name: e.name, t: Math.round(e.startTime), d: e.duration, wait: Math.round(e.processingStart - e.startTime), txt: (e.target?.textContent || '').slice(0, 24) }); }).observe({ type: 'event', buffered: true, durationThreshold: 16 });
  });
  return { ctx, page };
}
const worst = (ev) => { const m = new Map(); for (const e of ev) { const c = m.get(e.id); if (!c || e.d > c.d) m.set(e.id, e); } return [...m.values()]; };
const out = { cpu, A: [], B: [] };
for (let run = 0; run < 3; run++) {
  { // A
    const { ctx, page } = await setup();
    await page.goto('http://localhost:3291/', { waitUntil: 'commit' });
    const btn = page.locator('[aria-label="What I do"] button', { hasText: 'Photoacoustics' }).first();
    await page.waitForFunction(() => { const g = document.querySelector('[aria-label="What I do"]'); if (!g) return false; let el = g; while (el) { if (getComputedStyle(el).opacity !== '1' && Number(getComputedStyle(el).opacity) < 0.6) return false; el = el.parentElement; } return true; }, null, { timeout: 60000, polling: 50 });
    const tVisible = await page.evaluate(() => Math.round(performance.now()));
    await btn.click({ timeout: 60000 });
    await page.waitForTimeout(4000);
    const ev = worst(await page.evaluate(() => window.__ev));
    out.A.push({ tVisible, interactions: ev.map((e) => `${e.txt}:${e.name}@${e.t}: ${e.d}ms (input delay ${e.wait})`) });
    await ctx.close();
  }
  { // B
    const { ctx, page } = await setup();
    await page.goto('http://localhost:3291/', { waitUntil: 'load' });
    await page.waitForSelector('[data-status="ready"]', { timeout: 60000 });
    await page.waitForTimeout(3000);
    await page.locator('[aria-label="What I do"] button', { hasText: 'Photoacoustics' }).first().click();
    await page.waitForTimeout(3000); // let the first photoacoustic image finish
    await page.evaluate(() => (window.__ev = []));
    await page.getByRole('radio', { name: 'Medium' }).click();
    await page.waitForTimeout(150);
    await page.getByRole('radio', { name: 'Darker' }).click();
    await page.waitForTimeout(4000);
    const ev = worst(await page.evaluate(() => window.__ev));
    out.B.push(ev.map((e) => `${e.txt}:${e.name}@${e.t}: ${e.d}ms (input delay ${e.wait})`));
    await ctx.close();
  }
}
await browser.close();
console.log(JSON.stringify(out, null, 1));
