import { chromium } from 'playwright-core';
const browser = await chromium.launch({ channel: 'chrome', headless: true });
console.log('chrome', browser.version());
for (const mode of ['emulateNetworkConditions', 'none']) {
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  const cdp = await ctx.newCDPSession(page);
  await cdp.send('Network.enable');
  await cdp.send('Network.setCacheDisabled', { cacheDisabled: true });
  if (mode !== 'none') await cdp.send('Network.emulateNetworkConditions', { offline: false, latency: 562.5, downloadThroughput: 180000, uploadThroughput: 84375 });
  const t0 = Date.now();
  await page.goto('http://localhost:3291/', { waitUntil: 'domcontentloaded' });
  const wall = Date.now() - t0;
  const nav = await page.evaluate(() => { const n = performance.getEntriesByType('navigation')[0].toJSON(); return Object.fromEntries(['startTime','fetchStart','requestStart','responseStart','responseEnd','domInteractive','domContentLoadedEventEnd','transferSize'].map(k => [k, Math.round(n[k])])); });
  console.log(mode, 'wall to DCL', wall, JSON.stringify(nav));
  await ctx.close();
}
await browser.close();
