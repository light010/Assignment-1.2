// Capture scene-only stills (UI hidden) as a stand-in for the poster, to size the poster budget.
import { chromium } from 'playwright-core';
const browser = await chromium.launch({ channel: 'chrome', headless: true, args: ['--use-angle=metal', '--ignore-gpu-blocklist', '--enable-gpu', '--hide-scrollbars'] });
const hideUI = `section > header, h1, .text-lede, [aria-label="What I do"], figure, [aria-live], button, [data-placed] { visibility: hidden !important; }`;
for (const v of [{ name: 'poster-desktop.png', w: 1600, h: 1000, dpr: 1, mobile: false }, { name: 'poster-mobile.png', w: 390, h: 844, dpr: 3, mobile: true }]) {
  const ctx = await browser.newContext({ viewport: { width: v.w, height: v.h }, deviceScaleFactor: v.dpr, isMobile: v.mobile, hasTouch: v.mobile, reducedMotion: 'reduce' });
  const page = await ctx.newPage();
  await page.goto('http://localhost:3291/', { waitUntil: 'load' });
  await page.waitForSelector('[data-status="ready"]', { timeout: 30000 });
  await page.waitForTimeout(2500);
  await page.addStyleTag({ content: hideUI });
  await page.waitForTimeout(500);
  const box = await page.locator('[data-status]').boundingBox();
  await page.screenshot({ path: new URL('./' + v.name, import.meta.url).pathname, clip: box });
  console.log(v.name, JSON.stringify(box));
  await ctx.close();
}
await browser.close();
