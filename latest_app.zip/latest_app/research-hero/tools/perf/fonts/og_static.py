# Static TTF instances for next/og (Satori needs ttf/otf/woff, and static rather than variable fonts).
import sys, os
from fontTools.ttLib import TTFont
from fontTools.varLib import instancer
M, OUT = sys.argv[1], sys.argv[2]
jobs = [
  ('d38f3bca7db33566-s.p.0op912u62qdhl.woff2', {'wght': 380, 'opsz': 72}, 'Newsreader-Display-380.ttf'),
  ('2b7d3311b69a4dca-s.p.1elj1f4z6aq4a.woff2', {'wght': 400, 'opsz': 72}, 'Newsreader-Display-Italic-400.ttf'),
  ('c89730c3ffa99552-s.p.1zjat_zsa1d11.woff2', {'wght': 450, 'wdth': 100}, 'MonaSans-450.ttf'),
]
for src, loc, name in jobs:
    f = TTFont(os.path.join(M, src))
    inst = instancer.instantiateVariableFont(f, loc, updateFontNames=False)
    inst.flavor = None
    p = os.path.join(OUT, name)
    inst.save(p)
    print(name, os.path.getsize(p), 'bytes')
