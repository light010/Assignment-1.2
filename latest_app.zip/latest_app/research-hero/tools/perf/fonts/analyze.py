import sys, os, io
from fontTools.ttLib import TTFont
from fontTools.varLib import instancer
from fontTools import subset

M = sys.argv[1]
OUT = os.path.dirname(os.path.abspath(__file__))
files = {
  'newsreader-roman-latin': 'd38f3bca7db33566-s.p.0op912u62qdhl.woff2',
  'newsreader-italic-latin': '2b7d3311b69a4dca-s.p.1elj1f4z6aq4a.woff2',
  'mona-sans-latin': 'c89730c3ffa99552-s.p.1zjat_zsa1d11.woff2',
}
def woff2_size(font):
    font.flavor = 'woff2'
    b = io.BytesIO(); font.save(b); return len(b.getvalue())
def info(path):
    f = TTFont(path)
    axes = [(a.axisTag, a.minValue, a.defaultValue, a.maxValue) for a in f['fvar'].axes] if 'fvar' in f else []
    feats = sorted({fr.FeatureTag for fr in f['GSUB'].table.FeatureList.FeatureRecord}) if 'GSUB' in f else []
    featsP = sorted({fr.FeatureTag for fr in f['GPOS'].table.FeatureList.FeatureRecord}) if 'GPOS' in f else []
    return f, axes, len(f.getGlyphOrder()), feats, featsP
plans = {
  'newsreader-roman-latin': [
     ('wght 350-500, opsz 6-72', {'wght': (350, 500)}),
     ('wght 350-500, opsz 16-72', {'wght': (350, 500), 'opsz': (16, 72)}),
  ],
  'newsreader-italic-latin': [
     ('wght 400 static, opsz 6-72', {'wght': 400}),
     ('wght 400, opsz 20 (static instance)', {'wght': 400, 'opsz': 20}),
  ],
  'mona-sans-latin': [
     ('wght 400-600, wdth 85-100', {'wght': (400, 600), 'wdth': (85, 100)}),
     ('wght 400-600, wdth 88-100', {'wght': (400, 600), 'wdth': (88, 100)}),
  ],
}
for key, fn in files.items():
    p = os.path.join(M, fn)
    f, axes, n, feats, featsP = info(p)
    print(f"\n{key}: {os.path.getsize(p):,} B woff2, {n} glyphs, axes {axes}")
    print(f"   GSUB {feats}\n   GPOS {featsP}")
    for label, limits in plans[key]:
        f2 = TTFont(p)
        inst = instancer.instantiateVariableFont(f2, limits, updateFontNames=False)
        size = woff2_size(inst)
        out = os.path.join(OUT, f"{key}--{label.replace(' ', '_').replace(',', '').replace('(', '').replace(')', '')}.woff2")
        inst.flavor = 'woff2'; inst.save(out)
        print(f"   {label}: {size:,} B ({100*size/os.path.getsize(p):.0f}%)")
