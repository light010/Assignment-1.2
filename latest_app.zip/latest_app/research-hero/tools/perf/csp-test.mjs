// Does the hero (three.js, next/font, Motion) run under a given CSP? Policy either from the server (next.config headers)
// or injected into the document response with page.route (to try stricter variants without rebuilding).
import { chromium } from 'playwright-core';
const url = process.argv[2] || 'http://localhost:3292/';
const variants = {
  server: null,
  strictScripts: "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'",
  strictStyles: "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self'; img-src 'self' data: blob:; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'",
  styleAttrOnly: "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self'; style-src-attr 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'",
};
const browser = await chromium.launch({ channel: 'chrome', headless: true, args: ['--use-angle=metal', '--ignore-gpu-blocklist', '--enable-gpu'] });
for (const [name, policy] of Object.entries(variants)) {
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await ctx.newPage();
  const logs = [];
  page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') logs.push(m.text().slice(0, 160)); });
  await page.addInitScript(() => { window.__csp = []; document.addEventListener('securitypolicyviolation', (e) => window.__csp.push(`${e.violatedDirective} <- ${e.blockedURI || 'inline'} (${(e.sample || '').slice(0, 40)})`)); });
  if (policy) {
    await page.route(url, async (route) => {
      const resp = await route.fetch();
      const headers = { ...resp.headers(), 'content-security-policy': policy };
      await route.fulfill({ response: resp, headers });
    });
  }
  await page.goto(url, { waitUntil: 'load' });
  const ready = await page.waitForSelector('[data-status="ready"]', { timeout: 15000 }).then(() => true).catch(() => false);
  await page.waitForTimeout(1500);
  const r = await page.evaluate(() => ({
    csp: [...new Set(window.__csp)].slice(0, 8),
    hydrated: getComputedStyle(document.querySelector('nav[aria-label="Primary"]')).opacity,
    fonts: [...document.fonts].filter((f) => f.status === 'loaded').map((f) => f.family + ' ' + f.style).join(', '),
  }));
  console.log(`\n## ${name}: lab ready=${ready}, nav opacity=${r.hydrated}, fonts loaded=[${r.fonts}]`);
  console.log('   violations:', r.csp.length ? r.csp.join(' | ') : 'none');
  if (logs.length) console.log('   console:', [...new Set(logs)].slice(0, 4).join(' | '));
  await ctx.close();
}
await browser.close();
