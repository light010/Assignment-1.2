# Madhavi Tripathi: research website

A one-page site for a translational scientist who builds nanoparticles for drug delivery and works on
photoacoustic and ultrasound imaging. It opens on an interactive lab where every control changes the
physics on screen, then gives the record: Recognition and service, Research (three directions), Publications,
About, and Contact. `docs/HANDOFF.md` records what was built, how it was verified, and what is still open.

It is a static site. `npm run build` checks the content, writes every page and file to `out/`, and checks
the result; any static host can serve that folder (the plan is Cloudflare, at no cost).

## Run

Node 22.18 or later (the scripts use Node's built-in TypeScript support; `.nvmrc` pins 24).

```bash
npm install
npm run dev          # http://localhost:3217
npm run build        # content and copy checks → static export to out/ → built-site checks
npm run serve        # serves out/ like the host does, at http://localhost:3218
npm run check:budgets
npm run scholar      # reads the Google Scholar profile once and updates src/content/scholar.json
npm run test:unit    # the Google Scholar parser and its safety checks
```

`npm run verify` runs types, lint, the build, the byte budgets, and the browser tests in one go.

## Edit the content

Everything a visitor reads lives in `src/content/`. Components only lay it out.

| File | What it holds |
| --- | --- |
| `person.ts` | Role, current position, both bios, email, profile links, positions, education |
| `publications.ts` | The 15 papers, newest first: verbatim titles, authors, venue, DOI, links, access, themes, lab chapters, summary, CRediT role |
| `scholar.json` | Google Scholar's figures for the profile (citations, h-index, i10-index, per year, per paper), with the time they were read. Written by `npm run scholar` and the 4-hour workflow; not edited by hand |
| `themes.ts` | Research: the deck, the bridge line, and the two halves of the work |
| `about.ts` | Recognition and service, and recent updates |
| `site.ts` | The production address, the "Updated" date, section names and decks, the search description |
| `profile.ts` | The hero's headline and lede |
| `chapters.ts` | The lab: chapter names, controls, every caption, readout, 3D label, legend, and evidence link |

**Facts are confirmed or they don't show.** Every statement about the owner is a `Fact`: a value, where it
was read, and `confirmed`. A production build renders only confirmed facts, and the build fails if a required
one (role, current position, bios, email, profile links) is unconfirmed. When something changes, update the
fact and its source, and move `UPDATED` in `site.ts`.

**Adding a paper.** Let the script draft it from Crossref, so the title, authors, and venue are right:

```bash
npm run add-paper -- --doi 10.1093/radadv/umaf037 --summary "One sentence, in your words." --themes imaging
```

It refuses a DOI that is already listed, one Crossref doesn't know, or a paper without the owner among its
authors, and it keeps the list newest first. `--dry-run` shows the record without writing it. The GitHub
workflow in `.github/workflows/add-paper.yml` does the same from a web form and opens a pull request (see the
note at the top of that file for switching it on). Summaries use "we", say what was done and found, and
describe skills rather than materials. `npm run enrich` refreshes the Crossref snapshot the build checks
against; `docs/content-verification.md` records what was checked and how.

**Google Scholar numbers.** The Publications readout and each paper's "Cited by" come from the public profile
page, read at most once every 4 hours by `.github/workflows/scholar.yml` (switch it on as the other workflows
say) and by hand with `npm run scholar`. A read writes `src/content/scholar.json` when a number changed, or at
least once a day so "Checked" stays current; when Google refuses a read, the last snapshot stays and the page
says when it was checked. Papers new on Scholar are never added by themselves (other researchers publish under
the same name): the workflow lists them in an issue, and `npm run add-paper` adds one with its DOI. The whole
arrangement, and the paid fallback for when Google blocks the workflow, is in `docs/scholar-sync.md`.

**Recognition photos.** Put the owner's photos in `assets/originals/recognition/` (named by the item's id in
`about.ts`), run `npm run photos`, and add `photo: { alt, credit }` to that item. Until then an item can show
the lab still of the work it recognizes, labeled "Simulated".

**Words.** `design-system/MASTER.md` holds the voice, the glossary (one name per thing), and the length
budgets. `npm run copy-deck` writes every string to `docs/copy-deck.md` for review; the build lints the same
text and fails on a broken rule.

## The checks

| Check | When | Fails on |
| --- | --- | --- |
| `scripts/enrich-publications.mts --offline` | Before every build | A curated paper whose title, year, authors, the owner's position, or license disagrees with the committed Crossref snapshot |
| `scripts/check-content.mts` | Before every build | An unconfirmed required fact; duplicate or dangling IDs; a featured paper, chapter, or evidence link that doesn't exist; malformed DOIs, ORCID iD, links, or dates; facts that contradict each other; placeholders and old-site text |
| `scripts/copy-deck.mts --check` | Before every build | Length budgets, banned words, glossary terms, material names in site copy, British spelling, straight quotes, characters the fonts lack |
| `scripts/scholar-sync.mts --check` | Before every build | A Google Scholar snapshot that isn't well formed, belongs to another profile, or names a paper the site doesn't have (papers only on Scholar, or a snapshot over two weeks old, are warnings) |
| `npm run test:unit` | CI | The Scholar page parser, matching, and safety checks, against a saved profile page |
| `scripts/inject-structured-data.mts` | After every build | Puts the JSON-LD the build wrote into `out/index.html` (from React it would ship twice) |
| `scripts/check-built.mts` | After every build | A missing page or file; placeholder text anywhere in `out/`; title, description, canonical, share tags, or structured data that are wrong or broken; in-page links without a target; duplicate IDs; images without alt text; any character on the page that the site's fonts don't have |
| `npm run check:budgets` | CI | Initial JavaScript, CSS, HTML, and preloaded fonts over budget (`budgets.json`); three.js in the initial load |
| `npx tsc --noEmit`, `npm run lint` | CI | Type and lint errors |

## Deploy

1. Set the real address and build: `NEXT_PUBLIC_SITE_URL=https://example.com npm run build`. (A build without it
   points canonical links at localhost; the built-site check refuses that on CI and Cloudflare.)
2. Publish `out/` with `npx wrangler deploy` (settings in `wrangler.jsonc`); `npx wrangler versions upload` makes
   a preview address first.
3. Security headers and caching live in `public/_headers`, redirects in `public/_redirects` (the `/cv` redirect
   goes live once the CV PDF is in `public/`). Unknown paths get `404.html` with a real 404 status.

## The lab

| Chapter | Controls | What changes |
| --- | --- | --- |
| **Design** (building in layers) | Build: Core, Gel and drug, Membrane coat. View: Cut open, Taken apart | The particle is built in lab order: light-absorbing cores with a capping layer, a heat-responsive gel loaded with drug, then a red blood cell membrane coat with its proteins. Each step has its own camera angle and electron micrograph. Taken apart lays the layers out side by side. |
| **Delivery** (reaching the tumor) | Particle: Large, Ultrasmall, Gel carrier. After: Minutes, Hours, A day. Light: Off, Pulsed, Continuous | The size trade-off. Large particles stall at the tumor rim; ultrasmall ones reach deep but wash out; the gel carrier holds at the rim until continuous light heats it, the gel shrinks and squeezes out the drug, and heat damages tumor cells. Pulsed light makes the same particles emit sound for imaging. |
| **Photoacoustics** (listening to light) | Show: Blood oxygen, Nanoparticles. Skin tone: Lighter, Medium, Darker. Beamformer: Delay-and-sum, Coherence | Oxygenated blood in green and deoxygenated blood in red, or the particles on a heat scale. Darker skin absorbs light at the surface, so less reaches deep targets and reverberation clutter buries them. Coherence beamforming cuts most of the clutter. |
| **Ultrasound** (listening to echoes) | Lesion: Cyst, Solid mass. Beamformer: Delay-and-sum, Coherence. View: Image, Raw echoes | B-mode against short-lag spatial coherence (SLSC). gCNR is measured from the rendered image's lesion and background histograms; coherence images are read against the study's 0.76 cutoff. Raw echoes shows each element's signal with the delay curve or the agreement between neighbors. |

Visitors can take a guided tour, click the scene to fire a light pulse (or an ultrasound transmit), and pause
everything. Deep links open a chapter: `#lab-design`, `#lab-delivery`, `#lab-photoacoustics`, `#lab-ultrasound`.
The pictures are simulations for explanation, not measurements, and say so.

## Accuracy notes (from the science and copy reviews)

Independent science and copy reviews checked every string against the researcher's papers and each other's
suggestions. What they settled, so later edits don't undo it:

- **gCNR cutoff.** The study chose 0.76 for gCNR on coherence (SLSC) images; B-mode was read by eye.
  So only coherence images get a verdict ("reads as a cyst"); B-mode shows the number and "Cyst or solid?".
- **Solid masses.** In B-mode a solid mass looks dark, like a cluttered cyst; under coherence it blends in
  while the cyst stands out, the direction the study reports.
- **Photoacoustics.** Oxygen maps need several colors of light; coherence cuts clutter but can't quantify
  oxygen or restore light that melanin absorbed ("lost light stays lost"). Melanin is modeled as a loss at the
  skin surface, reported as "Light through skin". Particles "emit sound"; "ringing" is reserved for the skin's
  reverberation artifact.
- **Gel carrier.** Heat shrinks the gel and squeezes out the drug; the cores stay inside. Heating in the first
  minutes would release the drug before the carriers reach the tumor.
- **Materials.** Paper titles stay verbatim. Everything written around them names skills, not materials,
  drugs, or wavelengths.
- **Light into sound.** Absorbed light always becomes heat; it becomes sound only in short pulses. The bridge line
  says so ("absorbed light turns into heat, and pulsed light into sound").
- **Skin injury, not a safe dose.** The Journal of Biomedical Optics study measured the pulsed-light dose that
  injures pig skin of different tones; safety limits sit well below it. Never "safe dose", never "human skin".
- **Coherence and skin tone.** Coherence (SLSC) helped deep targets most under darker skin; delay-and-sum did better
  for targets near the skin. Under lighter skin coherence still brings out faint vessels.
- **Solid masses.** The confusion is with dark (hypoechoic) solid masses: "many solid masses look dark", not all.
- **Summaries.** Every paper summary was checked against its abstract or full text by the science review
  (`docs/reviews/`), then vetted for voice by the copy review, and each reviewer vetted the other's changes.

## Where things are

| Path | What it does |
| --- | --- |
| `src/app/` | The page, the 404, metadata routes (sitemap, robots, manifest), `/publications.bib` |
| `src/components/site/` | Recognition (list and picture panel; phone rail), Research (three cards and their diagrams), Publications (the index with Show and Sort, the Google Scholar tiles), About, Contact, footer, section bar, the theme toggle (`theme-toggle.tsx`), the page's motion (`reveals.tsx`, rising figures and swapping counts), the static fallback for the lab |
| `src/components/hero/` | The hero: headline, console (chapters, controls, readouts, caption, tour), instrument panel, 3D labels |
| `src/lab/` | The lab: state and tour (`state.ts`), the three.js engine, scene objects, and the instruments that render and measure the images |
| `src/lib/` | Formatting (dates, citations, BibTeX), structured data, typesetting helpers |
| `scripts/` | The checks, the copy deck, the local server, the Google Scholar sync, the structured-data step |
| `tools/perf/` | Measurement scripts: paint and tap timing, byte budgets, CSP, posters |
| `docs/site-plan/` | The plan this site implements, with its appendices |
| `design-system/MASTER.md` | Voice, glossary, length budgets, tokens |

## Built-in care

- **Truth**: only confirmed facts render; papers are curated by DOI; citation counts only as Google Scholar reports
  them, with the date they were read and a link to the profile; every lab picture is labeled "Simulated".
- **Performance**: three.js loads in its own chunk after first paint, never in the initial load; the italic
  font loads without a preload; byte budgets are enforced.
- **Motion**: below the lab, each block plays one moment the first time it is scrolled to (headings rise, pictures
  are acquired behind a scan line, the research diagrams play their physics, Scholar's figures rise and its charts
  draw), and controls answer with motion that shows what changed (gliding thumbs, rows, folds); nothing loops
  (`design-system/MASTER.md`, "Motion"; `src/components/site/reveals.tsx`). Under `prefers-reduced-motion` all of it
  is a cut, the lab opens paused, camera moves become cuts, and there is no letter wave. A pause button is always
  available. Without JavaScript or in print, nothing waits to appear.
- **Two themes**: dark is the lab and the default; light is the paper, chosen with the toggle in the header (and
  the section bar from `sm` up) or taken from the system preference, resolved before first paint and remembered.
  The lab, the chart wells, and the renders stay dark in both: instruments keep their screens. Every light value
  is computed against WCAG 2.2 (`design-system/MASTER.md`, "Two themes"). Without JavaScript the page is dark.
- **Access**: a "Skip the lab" link comes first; the headline reads as plain text; every control is a keyboard
  radio group; captions and copy confirmations are announced politely; focus rings are visible; text contrast
  is at least 4.5:1 in either theme; touch targets are 44 px on touch screens. Without JavaScript the whole
  record still reads.
- **Layout**: full-bleed on wide, landscape screens; stacked below that; no horizontal scroll at 320 px.
