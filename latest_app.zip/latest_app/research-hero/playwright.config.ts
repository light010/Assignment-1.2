import fs from "node:fs";
import { chromium, defineConfig, devices, firefox, webkit } from "@playwright/test";

/*
  Browser tests for the static export (docs/site-plan/D-engineering.md §4 and §7).

  The tests run against a built site, never the dev server: scripts/serve-out.mjs serves a build the
  way the host does (404 status for unknown paths, _headers including the CSP, compression).

    OUT_DIR   folder to serve (default: out). Point it at a copy when other work is rebuilding out/.
    QA_PORT   port for that server (default: 3219).
    PW_OUTPUT_DIR / PW_REPORT_DIR   where results and the HTML report go (defaults below).

  Projects: "chromium" runs every spec. "webkit" and "firefox" run the journeys only, and are skipped
  (not failed) when their browsers aren't installed: `npx playwright install webkit firefox` adds them.
  "chromium" uses Playwright's own Chromium when it is installed and the local Google Chrome otherwise
  (PW_CHROMIUM_CHANNEL overrides, e.g. "chrome" or "chromium").
*/

const PORT = Number(process.env.QA_PORT ?? 3219);
const OUT_DIR = process.env.OUT_DIR ?? "out";
const BASE_URL = `http://localhost:${PORT}`;

const installed = (type: { executablePath(): string }) => {
  try {
    return fs.existsSync(type.executablePath());
  } catch {
    return false;
  }
};

const chromiumChannel = process.env.PW_CHROMIUM_CHANNEL ?? (installed(chromium) ? undefined : "chrome");

// WebGL for the lab: Metal on macOS, SwiftShader on GPU-less Linux runners (D-engineering §7, Performance).
const chromiumArgs =
  process.platform === "linux"
    ? ["--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"]
    : process.platform === "darwin"
      ? ["--use-angle=metal", "--ignore-gpu-blocklist"]
      : ["--ignore-gpu-blocklist"];

export default defineConfig({
  testDir: "./tests",
  // tests/unit holds node:test files (npm run test:unit), not browser tests.
  testIgnore: "**/unit/**",
  outputDir: process.env.PW_OUTPUT_DIR ?? "test-results",
  // Baselines per project and platform: fonts rasterize differently on macOS and in the Linux Docker image.
  snapshotPathTemplate: "{testDir}/__screenshots__/{projectName}-{platform}/{testFileName}/{arg}{ext}",
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 1 : 0,
  workers: process.env.CI ? 2 : 4,
  timeout: 60_000,
  expect: {
    timeout: 10_000,
    toHaveScreenshot: {
      animations: "disabled",
      caret: "hide",
      scale: "css",
      maxDiffPixelRatio: 0.002,
    },
  },
  reporter: [
    ["list"],
    ["html", { open: "never", outputFolder: process.env.PW_REPORT_DIR ?? "playwright-report" }],
  ],
  use: {
    baseURL: BASE_URL,
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
    colorScheme: "dark",
  },
  webServer: {
    command: `node scripts/serve-out.mjs --dir "${OUT_DIR}" --port ${PORT}`,
    url: `${BASE_URL}/`,
    env: { QUIET: "1" },
    reuseExistingServer: !process.env.CI,
    stdout: "ignore",
    stderr: "pipe",
    timeout: 30_000,
  },
  projects: [
    {
      name: "chromium",
      use: {
        ...devices["Desktop Chrome"],
        channel: chromiumChannel,
        launchOptions: { args: chromiumArgs },
      },
    },
    {
      name: "webkit",
      testMatch: /journeys\.spec\.ts/,
      use: { ...devices["Desktop Safari"] },
      metadata: { installed: installed(webkit) },
    },
    {
      name: "firefox",
      testMatch: /journeys\.spec\.ts/,
      use: { ...devices["Desktop Firefox"] },
      metadata: { installed: installed(firefox) },
    },
  ],
});
