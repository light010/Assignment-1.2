/*
  Contact sheet for reviewing the visual baselines (and any other folder of screenshots).

  Usage:
    node tests/tools/contact-sheet.mjs [--dir <png folder>]... [--out <folder>]

  Defaults: the Chromium baselines for this platform, written to test-results/contact-sheet/.
  Pass --dir more than once to add folders (e.g. the forced-colors screenshots the accessibility spec
  writes to <outputDir>/forced-colors). Writes index.html (every image, grouped by viewport, linked to
  full size), sheet-folds.png (every above-the-fold capture side by side) and sheet-full.png (every
  full-page capture side by side), copying the PNGs so the folder stands alone.
*/
import fs from "node:fs";
import path from "node:path";
import sharp from "sharp";

const args = process.argv.slice(2);
const values = (name) => args.flatMap((a, i) => (a === `--${name}` ? [args[i + 1]] : []));
const platform = process.platform;
const dirs = values("dir").length ? values("dir") : [`tests/__screenshots__/chromium-${platform}/visual.spec.ts`];
const out = path.resolve(values("out")[0] ?? "test-results/contact-sheet");

const images = [];
for (const dir of dirs) {
  if (!fs.existsSync(dir)) {
    console.error(`No such folder: ${dir}`);
    process.exit(1);
  }
  for (const file of fs.readdirSync(dir).filter((f) => f.endsWith(".png")).sort()) {
    const meta = await sharp(path.join(dir, file)).metadata();
    const group = file.match(/^(?:forced-colors-)?(\d+x\d+(?:-landscape-phone)?|\d+)/)?.[1] ?? "other";
    images.push({ dir, file, group: file.startsWith("forced-colors") ? `forced colors ${group}` : group, width: meta.width, height: meta.height });
  }
}
if (!images.length) {
  console.error("No PNG files found.");
  process.exit(1);
}

fs.mkdirSync(path.join(out, "img"), { recursive: true });
for (const img of images) fs.copyFileSync(path.join(img.dir, img.file), path.join(out, "img", img.file));

const byWidth = (a, b) => Number.parseInt(a, 10) - Number.parseInt(b, 10) || a.localeCompare(b);
const groups = [...new Set(images.map((i) => i.group))].sort((a, b) => byWidth(a.replace(/^forced colors /, "9"), b.replace(/^forced colors /, "9")));
const esc = (s) => s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);

const html = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Visual baselines: contact sheet</title>
<style>
  :root { color-scheme: dark; --bg: #0b0f12; --fg: #ece7df; --muted: #aaa59d; --line: #2a3238; }
  body { margin: 0; padding: 24px 16px 64px; background: var(--bg); color: var(--fg); font: 14px/1.5 system-ui, sans-serif; }
  h1 { font-size: 20px; margin: 0 0 4px; } p { color: var(--muted); margin: 0 0 24px; max-width: 70ch; }
  h2 { font-size: 16px; margin: 32px 0 12px; padding-top: 16px; border-top: 1px solid var(--line); }
  .row { display: flex; flex-wrap: wrap; gap: 16px; align-items: flex-start; }
  figure { margin: 0; } figcaption { color: var(--muted); font-size: 12px; margin-top: 4px; max-width: 280px; overflow-wrap: anywhere; }
  img { display: block; max-height: 420px; max-width: 280px; height: auto; width: auto; border: 1px solid var(--line); background: #000; }
  a:focus-visible { outline: 2px solid #8fe1f0; outline-offset: 2px; }
</style></head><body>
<h1>Visual baselines</h1>
<p>${images.length} captures from ${dirs.map(esc).join(", ")}. Generated ${new Date().toISOString()}. The WebGL canvas is masked in every capture: its area shows the lab's poster (a rendered still) where the build has one, otherwise the page background. Select an image for full size.</p>
${groups
  .map(
    (g) => `<h2>${esc(g)}</h2><div class="row">${images
      .filter((i) => i.group === g)
      .map((i) => `<figure><a href="img/${encodeURIComponent(i.file)}"><img loading="lazy" src="img/${encodeURIComponent(i.file)}" alt="${esc(i.file)}"></a><figcaption>${esc(i.file)} · ${i.width}×${i.height}</figcaption></figure>`)
      .join("")}</div>`,
  )
  .join("\n")}
</body></html>
`;
fs.writeFileSync(path.join(out, "index.html"), html);

/** Places images side by side at one height, on the page's own dark background. */
async function montage(list, height, file) {
  if (!list.length) return;
  const gap = 24;
  const scaled = await Promise.all(
    list.map(async (i) => {
      const width = Math.max(1, Math.round((i.width * height) / i.height));
      return { input: await sharp(path.join(i.dir, i.file)).resize({ width, height, fit: "fill" }).png().toBuffer(), width };
    }),
  );
  const total = scaled.reduce((sum, s) => sum + s.width + gap, gap);
  let left = gap;
  const composites = scaled.map((s) => {
    const c = { input: s.input, left, top: gap };
    left += s.width + gap;
    return c;
  });
  await sharp({ create: { width: total, height: height + gap * 2, channels: 3, background: "#0b0f12" } })
    .composite(composites)
    .png()
    .toFile(path.join(out, file));
}

const sorted = (re) => images.filter((i) => re.test(i.file)).sort((a, b) => byWidth(a.group, b.group));
await montage(sorted(/^\d.*-fold\.png$/), 480, "sheet-folds.png");
await montage(sorted(/^\d.*-full\.png$/), 3200, "sheet-full.png");
console.log(`Contact sheet: ${path.join(out, "index.html")} (${images.length} images)`);
