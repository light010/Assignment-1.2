import fs from "node:fs";
import { test as base, expect, firefox, webkit, type BrowserContext, type Page } from "@playwright/test";

/*
  The guard every test runs under: no console errors, no uncaught exceptions, no Content Security
  Policy violations, and no same-origin request answered with an error status. Problems are collected
  for the whole browser context (every page a test opens) and checked when the test ends.
  A test that expects one (the 404 page's own status) calls `guard.allow(/pattern/)` first.
*/

export type Problem = { kind: "console" | "pageerror" | "csp" | "http"; text: string; url?: string };

export interface Guard {
  problems: Problem[];
  /** Tolerate problems whose "kind text url" matches. */
  allow(pattern: RegExp): void;
}

export const INSTALL_HINT = "Browser not installed. Add it with: npx playwright install webkit firefox";

/** WebKit and Firefox run only when installed; Chromium falls back to the local Chrome (see the config). */
export function browserInstalled(browserName: string): boolean {
  const type = browserName === "webkit" ? webkit : browserName === "firefox" ? firefox : null;
  if (!type) return true;
  try {
    return fs.existsSync(type.executablePath());
  } catch {
    return false;
  }
}

const CSP_MARK = "[csp-violation]";

function watch(page: Page, problems: Problem[], origin: string) {
  page.on("console", (msg) => {
    if (msg.type() !== "error") return;
    const text = msg.text();
    problems.push({ kind: text.startsWith(CSP_MARK) ? "csp" : "console", text, url: msg.location().url });
  });
  page.on("pageerror", (error) => problems.push({ kind: "pageerror", text: `${error.name}: ${error.message}` }));
  page.on("response", (response) => {
    const url = response.url();
    if (response.status() >= 400 && url.startsWith(origin)) {
      problems.push({ kind: "http", text: `${response.status()} ${response.request().method()}`, url });
    }
  });
}

async function installCspListener(context: BrowserContext) {
  await context.addInitScript((mark: string) => {
    document.addEventListener("securitypolicyviolation", (e) => {
      console.error(`${mark} ${e.effectiveDirective} blocked ${e.blockedURI || "inline"} at ${e.sourceFile || "?"}:${e.lineNumber}`);
    });
  }, CSP_MARK);
}

export const test = base.extend<{ guard: Guard }>({
  guard: [
    async ({ context, baseURL }, use, testInfo) => {
      const problems: Problem[] = [];
      const allowed: RegExp[] = [];
      const origin = new URL(baseURL ?? "http://localhost").origin;
      await installCspListener(context);
      context.on("page", (page) => watch(page, problems, origin));
      for (const page of context.pages()) watch(page, problems, origin);

      await use({ problems, allow: (pattern) => allowed.push(pattern) });

      const unexpected = problems.filter((p) => !allowed.some((re) => re.test(`${p.kind} ${p.text} ${p.url ?? ""}`)));
      if (problems.length) {
        await testInfo.attach("console-and-csp.json", { body: JSON.stringify(problems, null, 2), contentType: "application/json" });
      }
      expect(unexpected, "console errors, page errors, CSP violations, or failed same-origin requests").toEqual([]);
    },
    { auto: true },
  ],
});

export { expect };
