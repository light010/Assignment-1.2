import type { APIRequestContext, BrowserContext, Locator, Page } from "@playwright/test";
import { publications } from "../../src/content/publications";

/*
  What the tests know about the page. Structure comes from src/components/site/* and
  src/components/hero/*; paper IDs are read from the served HTML and the count from the content, so adding a
  paper never breaks a test.
*/

export const TOTAL_PAPERS = publications.length;

export const SECTIONS = [
  { id: "research", label: "Research" },
  { id: "publications", label: "Publications" },
  { id: "about", label: "About" },
  { id: "contact", label: "Contact" },
] as const;

export const LAB = [
  { slug: "lab-design", name: "Design", controls: ["Build", "View"] },
  { slug: "lab-delivery", name: "Delivery", controls: ["Particle", "After", "Light"] },
  { slug: "lab-photoacoustics", name: "Photoacoustics", controls: ["Show", "Skin tone", "Beamformer"] },
  { slug: "lab-ultrasound", name: "Ultrasound", controls: ["Lesion", "Beamformer", "View"] },
] as const;

export type ShowValue = "all" | "delivery" | "imaging" | "first-author";
export const SHOW: ReadonlyArray<{ value: ShowValue; label: string }> = [
  { value: "all", label: "All" },
  { value: "delivery", label: "Delivery" },
  { value: "imaging", label: "Imaging" },
  { value: "first-author", label: "First author" },
];

export const HEADLINE = "Nanomaterials for delivery. Light and sound for imaging.";

/** External hosts the page links to; tests answer them locally so no test depends on the network. */
const EXTERNAL = /^https:\/\/([a-z0-9-]+\.)*(doi\.org|google\.com|orcid\.org|linkedin\.com|jhu\.edu|iisc\.ac\.in|ssrn\.com)\//;

export async function stubExternalSites(context: BrowserContext) {
  await context.route(EXTERNAL, (route) =>
    route.fulfill({
      status: 200,
      contentType: "text/html; charset=utf-8",
      body: `<!doctype html><title>External page (stub)</title><h1>External page (stub)</h1><p>${route.request().url()}</p>`,
    }),
  );
}

/** Every section after the hero, in page order (Research, Publications, … plus any section added later). */
export async function pageSectionIds(page: Page): Promise<string[]> {
  return page.evaluate(() => Array.from(document.querySelectorAll("main section[id]")).map((s) => s.id).filter((id) => id !== "top"));
}

/** The hero lab and the Show filter are client islands: wait until React owns them. */
export async function waitForApp(page: Page) {
  await page.waitForFunction(() => {
    const el = document.getElementById("lab-design");
    return !!el && Object.keys(el).some((k) => k.startsWith("__reactProps$"));
  });
  await page.locator('[role="radiogroup"][aria-labelledby="show-label"]').waitFor({ state: "attached" });
}

/**
 * Waits for the 3D lab to settle into a final state and returns it: "ready" (WebGL running), or the
 * poster's end states ("declined" on a constrained device, "unsupported" without WebGL, "lost", or the
 * older build's "fallback"). The lab starts as "poster" and loads only after `load`, an idle moment, and
 * with its frame near the viewport, so a page opened further down stays "poster": that is returned too.
 */
export async function waitForLab(page: Page, timeout = 25_000): Promise<string> {
  const frame = page.locator("[data-status]").first();
  await page
    .waitForFunction(
      () => {
        const el = document.querySelector("[data-status]");
        if (!el) return true;
        const status = el.getAttribute("data-status");
        if (status !== "poster" && status !== "loading") return true;
        // Not near the viewport: the lab won't start until someone scrolls to it.
        const r = el.getBoundingClientRect();
        return status === "poster" && (r.top > innerHeight * 2 || r.bottom < -innerHeight);
      },
      null,
      { timeout },
    )
    .catch(() => {});
  return (await frame.getAttribute("data-status").catch(() => null)) ?? "missing";
}

/** Lets every finite animation and transition finish, then waits two frames. */
/**
 * Brings every block below the lab to rest: marks each [data-reveal] block as revealed (as scrolling to it would)
 * and waits for its moment to finish. For checks of the page as it stands (contrast, spacing, targets), not of motion.
 */
export async function atRest(page: Page) {
  await page.evaluate(() => document.querySelectorAll("[data-reveal]").forEach((el) => el.setAttribute("data-in", "")));
  await settle(page);
}

export async function settle(page: Page, timeout = 5_000) {
  await page
    .waitForFunction(
      () =>
        document.getAnimations().every((a) => {
          if (a.playState !== "running") return true;
          const end = a.effect?.getComputedTiming().endTime;
          return typeof end === "number" && !Number.isFinite(end);
        }),
      null,
      { timeout },
    )
    .catch(() => {});
  await page.evaluate(() => new Promise<void>((r) => requestAnimationFrame(() => requestAnimationFrame(() => r()))));
}

/** Waits until the page stops scrolling (smooth scrolls, scroll restoration, late layout). */
export async function waitForScrollToSettle(page: Page, quietMs = 250, timeout = 5_000) {
  await page.evaluate(
    ({ quietMs, timeout }) =>
      new Promise<void>((resolve) => {
        const start = performance.now();
        let last = scrollY;
        let since = performance.now();
        const tick = () => {
          const now = performance.now();
          if (scrollY !== last) {
            last = scrollY;
            since = now;
          }
          if (now - since >= quietMs || now - start > timeout) resolve();
          else requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      }),
    { quietMs, timeout },
  );
}

/** Scroll jumps from here on, never glides (the site sets `scroll-behavior: smooth` on <html>). */
export async function instantScroll(page: Page) {
  await page.evaluate(() => document.documentElement.style.setProperty("scroll-behavior", "auto", "important"));
}

/** Brings an element to the top of the viewport instantly, respecting scroll-padding-top. */
export async function scrollToId(page: Page, id: string, block: "start" | "center" = "start") {
  await page.evaluate(
    ({ id, block }) => document.getElementById(id)?.scrollIntoView({ block, behavior: "instant" as ScrollBehavior }),
    { id, block },
  );
  await page.evaluate(() => new Promise<void>((r) => requestAnimationFrame(() => requestAnimationFrame(() => r()))));
}

/** Scrolls so the element's top edge sits `offset` px below the viewport top, instantly. */
export async function scrollElementTopTo(page: Page, id: string, offset = 0) {
  await page.evaluate(
    ({ id, offset }) => {
      const el = document.getElementById(id);
      if (!el) return;
      window.scrollTo({ top: scrollY + el.getBoundingClientRect().top - offset, behavior: "instant" as ScrollBehavior });
    },
    { id, offset },
  );
  await page.evaluate(() => new Promise<void>((r) => requestAnimationFrame(() => requestAnimationFrame(() => r()))));
}

/** Product of the opacities of an element and its ancestors: what a reader actually sees. */
export async function effectiveOpacity(locator: Locator): Promise<number> {
  return locator.evaluate((el) => {
    let opacity = 1;
    for (let n: Element | null = el; n; n = n.parentElement) opacity *= Number.parseFloat(getComputedStyle(n).opacity);
    return opacity;
  });
}

export interface BarState {
  visible: string | null;
  inert: boolean;
  opacity: number;
  current: string[];
  bottom: number;
}

export async function sectionBar(page: Page): Promise<BarState> {
  return page.locator('nav[aria-label="Sections"]').evaluate((nav) => ({
    visible: nav.getAttribute("data-visible"),
    inert: nav.hasAttribute("inert"),
    opacity: Number.parseFloat(getComputedStyle(nav).opacity),
    current: Array.from(nav.querySelectorAll("a[aria-current]")).map((a) => `${a.textContent?.trim()}=${a.getAttribute("aria-current")}`),
    bottom: nav.getBoundingClientRect().bottom,
  }));
}

/** Where an element sits relative to the viewport and the section bar. */
export async function placement(locator: Locator) {
  return locator.evaluate((el) => {
    const r = el.getBoundingClientRect();
    const bar = document.querySelector('nav[aria-label="Sections"]');
    const barShown = bar?.getAttribute("data-visible") === "true";
    const barBottom = barShown && bar ? bar.getBoundingClientRect().bottom : 0;
    return { top: r.top, bottom: r.bottom, height: r.height, viewport: innerHeight, barBottom, barShown, scrollY };
  });
}

/** Paper IDs (without the "pub-" prefix) that the current filter shows, whether or not a disclosure is closed. */
export async function papersShownByFilter(page: Page): Promise<string[]> {
  return page.evaluate(() =>
    Array.from(document.querySelectorAll<HTMLElement>('#publication-list li[id^="pub-"]'))
      .filter((li) => {
        for (let n: HTMLElement | null = li; n && n.id !== "publication-list"; n = n.parentElement) {
          if (n.tagName !== "DETAILS" && getComputedStyle(n).display === "none") return false;
        }
        return true;
      })
      .map((li) => li.id.slice(4)),
  );
}

export interface PaperIndex {
  /** Paper IDs in the served order: newest first. */
  all: string[];
  /** By half of the work ("delivery", "imaging"), and "other". */
  byGroup: Record<string, string[]>;
  firstAuthor: string[];
  /** Google Scholar's count of citing papers, as each row carries it (data-cited). */
  cited: Record<string, number>;
}

/** Reads the paper list from the served HTML: every `li#pub-*`, its topics, its first-author mark, and its citation count. */
export async function paperIndex(request: APIRequestContext): Promise<PaperIndex> {
  const html = await (await request.get("/")).text();
  const list = html.slice(html.indexOf('id="publication-list"'));
  const byGroup: Record<string, string[]> = { delivery: [], imaging: [], other: [] };
  const firstAuthor: string[] = [];
  const all: string[] = [];
  const cited: Record<string, number> = {};
  for (const m of list.matchAll(/<li id="pub-([^"]+)"([^>]*)>/g)) {
    const [, id, attrs] = m;
    all.push(id);
    for (const theme of attrs.match(/data-themes="([^"]*)"/)?.[1].split(" ") ?? []) (byGroup[theme] ??= []).push(id);
    if (/data-first(="")?[\s>]/.test(`${attrs}>`)) firstAuthor.push(id);
    cited[id] = Number(attrs.match(/data-cited="(\d+)"/)?.[1] ?? 0);
  }
  return { all, byGroup, firstAuthor, cited };
}

export function expectedShown(index: PaperIndex, value: ShowValue): string[] {
  if (value === "all") return index.all;
  if (value === "first-author") return index.firstAuthor;
  return index.byGroup[value] ?? [];
}

export type SortValue = "newest" | "cited";

/** The order the list should show: newest first, or by citations with ties kept newest first. */
export function expectedOrder(index: PaperIndex, show: ShowValue, sort: SortValue): string[] {
  const shown = expectedShown(index, show);
  const order = index.all.filter((id) => shown.includes(id));
  return sort === "cited" ? [...order].sort((a, b) => index.cited[b] - index.cited[a]) : order;
}

/** Rows in the order the list shows them, skipping those the filter hides and those waiting behind "Show all". */
export async function rowOrder(page: Page): Promise<string[]> {
  return page.evaluate(() =>
    Array.from(document.querySelectorAll<HTMLElement>("#publication-list .pub-row"))
      .filter((row) => getComputedStyle(row).display !== "none" && row.getBoundingClientRect().height > 0)
      .map((row) => row.id.slice(4)),
  );
}

/** Opens a paper's row (the summary, authors, role, links, and Cite), as its Summary button does. */
export async function openPaper(page: Page, id: string) {
  const toggle = page.locator(`#pub-${id} .pub-toggle`);
  if ((await toggle.getAttribute("aria-expanded")) !== "true") await toggle.click();
  await page.locator(`#m-${id}`).waitFor({ state: "visible" });
}

/** BibTeX key the site derives from a paper ID (src/lib/format.ts bibKey). */
export const bibKey = (id: string) => id.replace(/[^a-z0-9]+/gi, "_");

/** Splits a .bib file into entries keyed by citation key. */
export function parseBib(text: string): Map<string, string> {
  const entries = new Map<string, string>();
  const re = /^@\w+\{([^,\s]+),[\s\S]*?\n\}/gm;
  for (const m of text.matchAll(re)) entries.set(m[1], m[0]);
  return entries;
}

export const normalizeSpace = (s: string) => s.replace(/\s+/g, " ").trim();

/**
 * Clipboard: Chromium grants real clipboard access and the test reads it back. WebKit and Firefox
 * can't grant it headless, so there the page's writeText is recorded instead (the app code still runs).
 */
export async function prepareClipboard(context: BrowserContext, browserName: string, baseURL: string) {
  if (browserName === "chromium") {
    await context.grantPermissions(["clipboard-read", "clipboard-write"], { origin: new URL(baseURL).origin });
    return;
  }
  await context.addInitScript(() => {
    const w = window as Window & { __copied?: string[] };
    w.__copied = [];
    Object.defineProperty(navigator, "clipboard", {
      configurable: true,
      value: {
        writeText: async (text: string) => {
          w.__copied?.push(text);
        },
        readText: async () => w.__copied?.at(-1) ?? "",
      },
    });
  });
}

export async function readClipboard(page: Page): Promise<string> {
  return page.evaluate(() => navigator.clipboard.readText());
}

/** Tab key that reaches links in every engine (WebKit skips links on plain Tab, as Safari does by default). */
export const tabKey = (browserName: string) => (browserName === "webkit" ? "Alt+Tab" : "Tab");

/** The focused element, described for failure messages. */
export async function describeFocus(page: Page) {
  return page.evaluate(() => {
    const a = document.activeElement as HTMLElement | null;
    if (!a || a === document.body) return "body";
    const name = (a.getAttribute("aria-label") ?? a.textContent ?? "").replace(/\s+/g, " ").trim().slice(0, 50);
    return `${a.tagName.toLowerCase()}${a.id ? `#${a.id}` : ""} "${name}"`;
  });
}
