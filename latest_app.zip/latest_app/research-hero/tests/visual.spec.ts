import type { Page } from "@playwright/test";
import { expect, test } from "./support/fixtures";
import { LAB, instantScroll, pageSectionIds, scrollElementTopTo, settle, waitForApp, waitForLab } from "./support/helpers";

/*
  Visual baselines (D-engineering §7 "Visual"; PLAN §5.6 and §8 Sweep 3), Chromium only.
  Widths 320, 360, 390, 768, 1024, 1280×760, 1440, 2560, and a landscape phone: above the fold, the
  full page, and each section; each lab chapter and the section bar at 390 and 1440.

  What keeps them stable: fonts loaded before capture, animations disabled, reduced motion (the lab
  opens paused and its camera snaps instead of drifting), instant scrolling, and the WebGL canvas masked
  with the lab's poster (a rendered still) shown in its place: "canvas masked, poster compared". The
  instrument panel's images are seeded simulations, so they stay in. Baselines live in
  tests/__screenshots__/chromium-<platform>/visual.spec.ts/. Create or refresh them with
  `npx playwright test tests/visual.spec.ts --update-snapshots`, then review them (a contact sheet:
  `node tests/tools/contact-sheet.mjs`).

  A quirk to know: Playwright's screenshot of an element taller than the screen drops touch emulation for the rest
  of the page's life (it reports a fine pointer afterwards). So at the touch sizes, section captures after the
  first show the fine-pointer layout; at 768 the publication list appears as the scrolling panel a mouse gets,
  where a touch tablet shows five rows. The journeys check the touch behavior ("on a touch tablet").
*/

const VIEWPORTS = [
  { name: "320x568", width: 320, height: 568, touch: true },
  { name: "360x800", width: 360, height: 800, touch: true },
  { name: "390x844", width: 390, height: 844, touch: true },
  { name: "768x1024", width: 768, height: 1024, touch: true },
  { name: "1024x768", width: 1024, height: 768, touch: false },
  { name: "1280x760", width: 1280, height: 760, touch: false },
  { name: "1440x900", width: 1440, height: 900, touch: false },
  { name: "2560x1440", width: 2560, height: 1440, touch: false },
  { name: "844x390-landscape-phone", width: 844, height: 390, touch: true },
] as const;

const DETAILED = new Set(["390x844", "1440x900"]);

/** Fonts in, lab settled, canvas masked, instrument image drawn, pointer parked. */
async function prepare(page: Page, url = "/") {
  await page.goto(url);
  await waitForApp(page);
  await waitForLab(page).catch(() => "timeout");
  await page.evaluate(async () => {
    await document.fonts.ready;
  });
  await instantScroll(page);
  await maskScene(page);
  await page.waitForFunction(() => !!document.querySelector('figure canvas[role="img"]'), null, { timeout: 10_000 }).catch(() => {});
  await page.mouse.move(0, 0);
  await page.waitForTimeout(300);
  await settle(page);
}

/**
 * "Canvas masked, poster compared" (D-engineering §7): the WebGL scene changes every frame on every GPU,
 * so its pixels are hidden and the lab's rendered poster (a still image) is shown in its place, whether
 * or not the live lab has taken over. Done through CSSOM, so the CSP is untouched.
 */
async function maskScene(page: Page) {
  await page.evaluate(() => {
    document.querySelectorAll<HTMLCanvasElement>("[data-status] canvas").forEach((c) => c.style.setProperty("visibility", "hidden", "important"));
    document.querySelectorAll<HTMLElement>("[data-status] picture").forEach((p) => {
      p.closest<HTMLElement>("[data-on]")?.style.setProperty("opacity", "1", "important");
    });
  });
  await page
    .waitForFunction(() => Array.from(document.querySelectorAll<HTMLImageElement>("[data-status] img")).every((i) => i.complete && i.naturalWidth > 0), null, {
      timeout: 10_000,
    })
    .catch(() => {});
}

/** Section captures hide the fixed section bar, which would otherwise be drawn across them. */
async function hideSectionBar(page: Page, hidden: boolean) {
  await page.evaluate((hidden) => {
    const bar = document.querySelector<HTMLElement>('nav[aria-label="Sections"]');
    if (bar) bar.style.visibility = hidden ? "hidden" : "";
  }, hidden);
}

for (const vp of VIEWPORTS) {
  test.describe(`Visual ${vp.name}`, () => {
    test.use({
      viewport: { width: vp.width, height: vp.height },
      reducedMotion: "reduce",
      hasTouch: vp.touch,
      isMobile: vp.touch,
      deviceScaleFactor: 1,
    });

    test("above the fold", async ({ page }) => {
      await prepare(page);
      await expect(page).toHaveScreenshot(`${vp.name}-fold.png`);
    });

    test("full page", async ({ page }) => {
      test.setTimeout(120_000);
      await prepare(page);
      await expect(page).toHaveScreenshot(`${vp.name}-full.png`, { fullPage: true, timeout: 60_000 });
    });

    test("each section", async ({ page }) => {
      test.setTimeout(120_000);
      await prepare(page);
      await hideSectionBar(page, true);
      for (const id of await pageSectionIds(page)) {
        await scrollElementTopTo(page, id);
        await settle(page);
        await expect(page.locator(`section#${id}`)).toHaveScreenshot(`${vp.name}-section-${id}.png`, { timeout: 30_000 });
      }
      const footer = page.locator("body > footer");
      await footer.scrollIntoViewIfNeeded();
      await settle(page);
      await expect(footer).toHaveScreenshot(`${vp.name}-footer.png`);
    });

    if (DETAILED.has(vp.name)) {
      for (const lab of LAB) {
        test(`lab chapter: ${lab.name}`, async ({ page }) => {
          await prepare(page);
          await page.locator(`#${lab.slug}`).click();
          await expect(page.locator(`#${lab.slug}`)).toHaveAttribute("aria-pressed", "true");
          await page.mouse.move(0, 0);
          await page.waitForTimeout(600);
          await maskScene(page);
          await settle(page);
          await expect(page.locator("#top")).toHaveScreenshot(`${vp.name}-lab-${lab.slug}.png`);
        });
      }

      test("section bar over Publications; a paper open with its Cite panel; the list by most cited", async ({ page }) => {
        await prepare(page);
        await scrollElementTopTo(page, "publications", 0);
        await expect(page.locator('nav[aria-label="Sections"]')).toHaveAttribute("data-visible", "true");
        await settle(page);
        await expect(page).toHaveScreenshot(`${vp.name}-section-bar.png`);

        const row = page.locator("#publication-list .pub-row").first();
        await row.locator(".pub-toggle").click();
        await row.locator("summary", { hasText: "Cite" }).click();
        await page.mouse.move(0, 0);
        await hideSectionBar(page, true);
        await settle(page);
        await expect(page.locator(".pub-panel")).toHaveScreenshot(`${vp.name}-paper-open-cite.png`);

        await page.locator("#publications").getByRole("radio", { name: "Most cited" }).click();
        await page.mouse.move(0, 0);
        await settle(page);
        await expect(page.locator(".pub-panel")).toHaveScreenshot(`${vp.name}-most-cited.png`);
      });
    }
  });
}

test.describe("Visual 404", () => {
  test.use({ reducedMotion: "reduce", deviceScaleFactor: 1 });
  for (const vp of VIEWPORTS.filter((v) => ["320x568", "390x844", "1440x900"].includes(v.name))) {
    test(`404 at ${vp.name}`, async ({ page, guard }) => {
      guard.allow(/(http 404 GET|status of 404).*\/no-such-page/);
      await page.setViewportSize({ width: vp.width, height: vp.height });
      await page.goto("/no-such-page");
      await page.evaluate(async () => {
        await document.fonts.ready;
      });
      await settle(page);
      await expect(page).toHaveScreenshot(`${vp.name}-404.png`, { fullPage: true });
    });
  }
});

/*
  The paper theme (design-system/MASTER.md, "Two themes"), at the two detailed widths: the fold (the lab
  band over paper), the full page, and the two sections whose surfaces changed most (Publications with the
  black instrument well on a white plate; Research's cards and diagrams in the darker inks).
*/
for (const vp of VIEWPORTS.filter((v) => DETAILED.has(v.name))) {
  test.describe(`Visual, on paper: ${vp.name}`, () => {
    test.use({ viewport: { width: vp.width, height: vp.height }, hasTouch: vp.touch });

    test.beforeEach(async ({ page }) => {
      await page.addInitScript(() => {
        try {
          localStorage.setItem("theme", "light");
        } catch {
          /* Then these captures would be dark and the comparison fails loudly. */
        }
      });
    });

    test("above the fold", async ({ page }) => {
      await prepare(page);
      await expect(page.locator("html")).toHaveAttribute("data-theme", "light");
      await expect(page).toHaveScreenshot(`${vp.name}-paper-fold.png`);
    });

    test("full page", async ({ page }) => {
      await prepare(page);
      await expect(page).toHaveScreenshot(`${vp.name}-paper-full.png`, { fullPage: true, timeout: 60_000 });
    });

    for (const id of ["publications", "research"]) {
      test(`section: ${id}`, async ({ page }) => {
        await prepare(page);
        await scrollElementTopTo(page, id);
        await settle(page);
        await expect(page.locator(`section#${id}`)).toHaveScreenshot(`${vp.name}-paper-section-${id}.png`, { timeout: 30_000 });
      });
    }
  });
}
