/*
  Unit tests for the Google Scholar snapshot: scripts/lib/scholar.mts, scripts/scholar-sync.mts, and
  src/content/scholar.ts. No network: fetch is replaced where a test needs Google or SerpApi to answer, and the
  command-line runs start with fetch disabled.

    npm run test:unit

  Fixtures:
    tests/fixtures/scholar-profile.html        the profile page as fetched on 2026-09-28T10:14:54Z, trimmed to the
                                               parts the parser reads; ISO-8859-1, like the original
    tests/fixtures/scholar-publications.json   the site's 15 records (id, title, year) that day, frozen
    tests/fixtures/serpapi-author.json         SerpApi's documented example for the Google Scholar Author API
*/

import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { existsSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { after, before, describe, mock, test } from "node:test";
import { publications as livePublications } from "../../src/content/publications.ts";
import { scholar, scholarFor } from "../../src/content/scholar.ts";
import {
  checkSnapshot,
  dataChanged,
  decodeEntities,
  decodeHtml,
  detectBlock,
  fromSerpApi,
  isIsoSeconds,
  matchArticles,
  needsWrite,
  normalizeTitle,
  parseProfile,
  rematch,
  ScholarParseError,
  serializeSnapshot,
  shapeErrors,
  unlistedReport,
  validate,
  type ParsedProfile,
  type PubRef,
  type ScholarSnapshot,
} from "../../scripts/lib/scholar.mts";
import { readProfilePage, runSync, USER_AGENT, type Owner } from "../../scripts/scholar-sync.mts";

const APP = join(import.meta.dirname, "..", "..");
const SCRIPT = join(APP, "scripts", "scholar-sync.mts");
const FIXTURES = join(APP, "tests", "fixtures");
const FIXTURE = join(FIXTURES, "scholar-profile.html");
const CHECKED = "2026-09-28T10:14:54Z";
const PROFILE = "https://scholar.google.com/citations?user=zZx1Td0AAAAJ&hl=en";
const OWNER: Owner = { name: "Madhavi Tripathi", profileId: "zZx1Td0AAAAJ" };
const PUBS = (JSON.parse(readFileSync(join(FIXTURES, "scholar-publications.json"), "utf8")) as { publications: PubRef[] }).publications;
const LIVE_PUBS = livePublications.map(({ id, title, year }) => ({ id, title, year }));
const SERPAPI_EXAMPLE: unknown = JSON.parse(readFileSync(join(FIXTURES, "serpapi-author.json"), "utf8"));

const page = decodeHtml(new Uint8Array(readFileSync(FIXTURE)));
const parsed = parseProfile(page);

/** The snapshot the fixture gives, as the sync would build it. */
function snapshotOf(profile: ParsedProfile, checkedAt = CHECKED): ScholarSnapshot {
  return {
    schema: 1,
    profile: profile.profile,
    source: "profile-page",
    checkedAt,
    totals: profile.totals,
    recent: profile.recent,
    byYear: profile.byYear,
    articles: matchArticles(profile.articles, PUBS).articles,
  };
}
const base = snapshotOf(parsed);
const copy = (s: ScholarSnapshot): ScholarSnapshot => structuredClone(s);
const hoursLater = (iso: string, hours: number) => new Date(Date.parse(iso) + hours * 3_600_000).toISOString().replace(/\.\d{3}Z$/, "Z");
const article = (id: string) => {
  const found = parsed.articles.find((a) => a.id === `zZx1Td0AAAAJ:${id}`);
  assert.ok(found, id);
  return found;
};
const entryFor = (s: ScholarSnapshot, pub: string) => {
  const found = s.articles.find((a) => a.pub === pub);
  assert.ok(found, pub);
  return found;
};

/** One chart bar, by the year label it belongs to (its right offset is the label's plus 5 px). */
function withoutBar(html: string, labelRight: number): string {
  const bar = new RegExp(`<a href="javascript:void\\(0\\)" class="gsc_g_a" style="right:${labelRight + 5}px;[^"]*"><span class="gsc_g_al">\\d+</span></a>`);
  assert.match(html, bar);
  return html.replace(bar, "");
}

/** The SerpApi answer for the fixture's profile, built from the page's own figures. */
function serpApiFor(profile: ParsedProfile) {
  return {
    search_metadata: { status: "Success" },
    search_parameters: { engine: "google_scholar_author", author_id: profile.profile.id, hl: "en", num: "100" },
    author: { name: profile.profile.name },
    articles: profile.articles.map((a) => ({
      title: a.title,
      citation_id: a.id,
      authors: a.authors,
      publication: [a.venue, a.year].filter((part) => part !== "" && part !== null).join(", "),
      cited_by: a.citedByUrl ? { value: a.citedBy, cites_id: /cites=([\d,]+)/.exec(a.citedByUrl)?.[1] } : { value: null },
      year: a.year === null ? "" : String(a.year),
    })),
    cited_by: {
      table: [
        { citations: { all: profile.totals.citations, since_2021: profile.recent.citations } },
        { h_index: { all: profile.totals.hIndex, since_2021: profile.recent.hIndex } },
        { i10_index: { all: profile.totals.i10Index, since_2021: profile.recent.i10Index } },
      ],
      graph: profile.byYear,
    },
  };
}

describe("the saved profile page", () => {
  test("is decoded by its declared charset (ISO-8859-1), so Latin-1 names survive", () => {
    assert.match(page, /J Timaná/);
    const utf8 = new TextEncoder().encode("<p>Timaná</p>");
    assert.equal(decodeHtml(utf8, "text/html; charset=UTF-8"), "<p>Timaná</p>");
    assert.equal(decodeHtml(utf8), "<p>Timaná</p>");
  });

  test("profile and totals", () => {
    assert.deepEqual(parsed.profile, { id: "zZx1Td0AAAAJ", url: PROFILE, name: "Madhavi Tripathi" });
    assert.deepEqual(parsed.totals, { citations: 104, hIndex: 7, i10Index: 3 });
    assert.deepEqual(parsed.recent, { since: 2021, citations: 98, hIndex: 6, i10Index: 3 });
    assert.equal(parsed.complete, true);
  });

  test("citations per year, oldest first", () => {
    assert.deepEqual(
      parsed.byYear.map((y) => [y.year, y.citations]),
      [[2018, 1], [2019, 1], [2020, 2], [2021, 3], [2022, 8], [2023, 15], [2024, 20], [2025, 31], [2026, 21]],
    );
  });

  test("a year without a bar is zero-filled and the other bars keep their years (matched by offset, not order)", () => {
    // 2019's label sits at right:227px, 2018's at 259px, 2026's at 3px.
    const middle = parseProfile(withoutBar(page, 227)).byYear;
    assert.deepEqual(middle.slice(0, 3), [{ year: 2018, citations: 1 }, { year: 2019, citations: 0 }, { year: 2020, citations: 2 }]);
    assert.equal(middle.length, 9);
    const first = parseProfile(withoutBar(page, 259)).byYear;
    assert.deepEqual(first.slice(0, 2), [{ year: 2018, citations: 0 }, { year: 2019, citations: 1 }]);
    const last = parseProfile(withoutBar(page, 3)).byYear;
    assert.deepEqual(last.slice(-2), [{ year: 2025, citations: 31 }, { year: 2026, citations: 0 }]);
    const gaps = parseProfile(withoutBar(withoutBar(withoutBar(page, 227), 131), 3)).byYear;
    assert.deepEqual(gaps.map((y) => y.citations), [1, 0, 2, 3, 0, 15, 20, 31, 0]);
  });

  test("bars in any document order land on the same years", () => {
    const chart = /<div class="gsc_md_hist_b">([\s\S]*?)<\/div>/.exec(page)?.[1] ?? "";
    const labels = chart.match(/<span class="gsc_g_t"[^>]*>\d+<\/span>/g) ?? [];
    const bars = chart.match(/<a [^>]*class="gsc_g_a"[\s\S]*?<\/a>/g) ?? [];
    assert.equal(bars.length, 9);
    const shuffled = page.replace(chart, [...labels, ...[...bars].reverse()].join(""));
    assert.deepEqual(parseProfile(shuffled).byYear, parsed.byYear);
  });

  test("bars too far from their labels to tell the years apart are a parse fault, not a guess", () => {
    // 20 px on a 32 px column: past half a column, a bar could belong to either neighbor.
    const shifted = page.replace(/class="gsc_g_a" style="right:(\d+)px;/g, (_, right: string) => `class="gsc_g_a" style="right:${Number(right) + 15}px;`);
    assert.throws(() => parseProfile(withoutBar(shifted, 259 + 15)), /too far to tell their years apart/);
  });

  test("articles: ids, entities decoded, venue without the year", () => {
    assert.equal(parsed.articles.length, 15);
    assert.deepEqual(article("Tyk-4Ss8FVUC"), {
      id: "zZx1Td0AAAAJ:Tyk-4Ss8FVUC",
      title: "Curing behavior and mechanical properties of tetra-functional epoxy reinforced with polyethyleneimine-functionalized MXene",
      authors: "R Wazalwar, M Tripathi, AM Raichur",
      venue: "ACS Applied Polymer Materials 4 (4), 2573-2584",
      year: 2022,
      citedBy: 34,
      citedByUrl: "https://scholar.google.com/scholar?cites=134142379856010976&hl=en",
    });
    assert.equal(article("W7OEmFMy1HYC").title, "Seed-mediated galvanic synthesis of CuS–Au nanohybrids for photo-theranostic applications");
    assert.equal(article("qjMakFHDy7sC").venue, "Tropical Medicine & International Health 20 (12), 1636-1638");
    assert.equal(article("hqOjcs7Dif8C").authors, "J Enslein, M Tripathi, B Panigrahi, K Myers, J Wei Chen, J Timaná, ...");
    assert.deepEqual(
      parsed.articles.map((a) => a.citedBy),
      [34, 17, 15, 9, 8, 8, 7, 3, 1, 1, 1, 0, 0, 0, 0],
    );
  });

  test("an empty Cited by is 0 with no link; an empty year is null; an empty venue is empty", () => {
    const npj = article("hqOjcs7Dif8C");
    assert.equal(npj.citedBy, 0);
    assert.equal("citedByUrl" in npj, false);
    const thesis = article("ufrVoPGSRksC");
    assert.equal(thesis.year, null);
    assert.equal(thesis.venue, "");
    assert.equal(thesis.citedBy, 0);
  });

  test("markup variants: data-href, unquoted values with '=', nested year spans", () => {
    const variant = page
      .replace(
        '<a href="/citations?view_op=view_citation&amp;hl=en&amp;oe=ASCII&amp;user=zZx1Td0AAAAJ&amp;citation_for_view=zZx1Td0AAAAJ:Tyk-4Ss8FVUC" class="gsc_a_at">',
        '<a href="javascript:void(0)" data-href="/citations?view_op=view_citation&amp;citation_for_view=zZx1Td0AAAAJ:Tyk-4Ss8FVUC" class="gsc_a_at">',
      )
      .replace(
        '<a href="https://scholar.google.com/scholar?oi=bibs&amp;hl=en&amp;oe=ASCII&amp;cites=10659421031527364510" class="gsc_a_ac gs_ibl">',
        "<a href=https://scholar.google.com/scholar?oi=bibs&amp;cites=10659421031527364510 class=gsc_a_ac>",
      )
      .replace('<span class="gs_oph">, 2024</span>', '<span class="gs_oph">, <span class="gs_oph">20</span>24</span> (print)');
    const articles = parseProfile(variant).articles;
    assert.equal(articles[0].id, "zZx1Td0AAAAJ:Tyk-4Ss8FVUC");
    assert.equal(articles[1].citedByUrl, "https://scholar.google.com/scholar?cites=10659421031527364510&hl=en");
    assert.equal(articles.find((a) => a.id.endsWith("eQOLeE2rZwMC"))?.venue, "ACS Applied Bio Materials 7 (3), 1671-1681 (print)");
  });

  test("a row count that disagrees with the page's own count is a parse fault", () => {
    const oneRowLess = page.replace(/<tr class="gsc_a_tr">[\s\S]*?<\/tr>/, "");
    assert.throws(() => parseProfile(oneRowLess), ScholarParseError);
  });

  test("missing parts are parse faults, not zeros", () => {
    assert.throws(() => parseProfile(page.replace('id="gsc_rsb_st"', 'id="gsc_rsb_other"')), /Cited by table/);
    assert.throws(() => parseProfile(page.replace(/class="gsc_md_hist_b"/, 'class="gsc_other"')), /citations-per-year chart/);
    assert.throws(() => parseProfile(page.replace(/<span class="gsc_g_al">8<\/span>/, '<span class="gsc_g_al">eight</span>')), /not a number/);
    assert.throws(() => parseProfile(page.replace('id="gsc_prf_in"', 'id="gsc_prf_name"')), /profile name/);
  });

  test("an enabled Show more button marks the list incomplete", () => {
    assert.equal(parseProfile(page.replace('id="gsc_bpf_more" disabled', 'id="gsc_bpf_more"')).complete, false);
  });

  test("entity names are looked up safely", () => {
    assert.equal(decodeEntities("&constructor; &toString; &amp; &#8211; &aacute;"), "&constructor; &toString; & – á");
  });
});

describe("detectBlock", () => {
  const sorryPage =
    '<html><head><title>https://scholar.google.com/citations?user=zZx1Td0AAAAJ&amp;hl=en</title></head><body><div style="max-width:400px;">' +
    '<form id="captcha-form" action="index" method="post"><script src="https://www.google.com/recaptcha/api.js" async defer></script>' +
    '<div id="recaptcha" class="g-recaptcha" data-sitekey="x"></div></form><div style="font-size:13px;"><b>About this page</b><br><br>' +
    "Our systems have detected unusual traffic from your computer network. This page checks to see if it&#39;s really you sending the requests, and not a robot.</div></div></body></html>";

  test("the profile page is not a block", () => {
    assert.equal(detectBlock(200, page), null);
  });

  test("HTTP 429, 403, and 503", () => {
    assert.match(detectBlock(429, sorryPage) ?? "", /429.*unusual traffic.*CAPTCHA/);
    assert.match(detectBlock(403, "<html><body><h1>We're sorry...</h1><p>... but your computer or network may be sending automated queries.</p></body></html>") ?? "", /403.*automated queries/);
    assert.match(detectBlock(503, "") ?? "", /503/);
    assert.match(detectBlock(429, page) ?? "", /429/);
  });

  test('an "unusual traffic" page served with 200', () => {
    assert.match(detectBlock(200, sorryPage) ?? "", /unusual traffic/);
  });

  test("Scholar's own CAPTCHA form", () => {
    assert.match(detectBlock(200, '<form id="gs_captcha_f" method="post"><h1>Please show you&#39;re not a robot</h1></form>') ?? "", /CAPTCHA/);
  });

  test("a redirect, to /sorry/ or elsewhere", () => {
    assert.match(detectBlock(302, "", "https://www.google.com/sorry/index?continue=https://scholar.google.com/citations") ?? "", /302.*\/sorry\//);
    assert.match(detectBlock(302, "", "https://consent.google.com/ml?continue=x") ?? "", /redirected to https:\/\/consent\.google\.com\/ml/);
  });

  test("a page without the profile", () => {
    const home = '<!doctype html><html><head><title>Google Scholar</title></head><body><div id="gs_hdr_frm"><form action="/scholar"></form></div></body></html>';
    assert.match(detectBlock(200, home) ?? "", /#gsc_prf_in/);
    // The profile's name in a comment or a style sheet doesn't count.
    assert.match(detectBlock(200, `<style>#gsc_prf_in{}</style><!-- <div id="gsc_prf_in">x</div> -->`) ?? "", /#gsc_prf_in/);
  });

  test("the profile with a renamed name element is Google changing the page, not refusing it", () => {
    const renamed = page.replace('id="gsc_prf_in"', 'id="gsc_prf_name"');
    assert.equal(detectBlock(200, renamed), null);
    assert.throws(() => parseProfile(renamed), ScholarParseError);
  });
});

describe("matching Scholar's entries to the site's papers", () => {
  test("all 15 entries match the 15 curated papers, one each", () => {
    const { articles, missing, notes } = matchArticles(parsed.articles, PUBS);
    assert.equal(PUBS.length, 15);
    assert.deepEqual(missing, []);
    assert.deepEqual(notes, []);
    assert.equal(new Set(articles.map((a) => a.pub)).size, 15);
    assert.deepEqual(
      Object.fromEntries(articles.map((a) => [a.id.split(":")[1], a.pub])),
      {
        "Tyk-4Ss8FVUC": "wazalwar-2022-mxene-epoxy",
        W7OEmFMy1HYC: "tripathi-2023-nanohybrids",
        "IjCSPb-OGe4C": "jain-2021-biopolymer",
        eQOLeE2rZwMC: "tripathi-2024-nanoflakes",
        _FxGoFyzp5QC: "tripathi-2025-mucin",
        qjMakFHDy7sC: "tripathi-2015-malaria",
        UeHWp8X0CEIC: "jain-2021-hydroxychloroquine",
        LkGwnXOMwfcC: "sharma-2025-gcnr-slsc",
        Se3iqnhoufwC: "enslein-2026-spie",
        roLk4NBRz8UC: "drabek-2026-spie",
        zYLM7Y9cAGgC: "tripathi-2015-stem-cells",
        hqOjcs7Dif8C: "enslein-2026-npj-imaging",
        UebtZRa9Y70C: "arroyo-2026-jbo",
        Y0pCki6q_DkC: "tripathi-2023-hydrogels",
        ufrVoPGSRksC: "tripathi-phd-thesis",
      },
    );
  });

  test("titles compare without case, entities, dashes, or punctuation", () => {
    const key = normalizeTitle("Seed-mediated galvanic synthesis of CuS–Au nanohybrids for photo-theranostic applications");
    assert.equal(normalizeTitle("Seed-mediated galvanic synthesis of CuS&#8211;Au nanohybrids for photo-theranostic applications"), key);
    assert.equal(normalizeTitle("SEED MEDIATED galvanic synthesis of cus au nanohybrids, for photo theranostic applications."), key);
    assert.notEqual(normalizeTitle("Seed-mediated synthesis of CuS–Au nanohybrids"), key);
  });

  test("a different year does not match; a missing year does", () => {
    const moved = { ...article("qjMakFHDy7sC"), year: 2016 };
    assert.equal(matchArticles([moved], PUBS).articles[0].pub, null);
    assert.equal(matchArticles([{ ...moved, year: null }], PUBS).articles[0].pub, "tripathi-2015-malaria");
  });

  test("a paper Scholar lists twice is claimed once, by the entry with the year", () => {
    const twin = { ...article("qjMakFHDy7sC"), id: "zZx1Td0AAAAJ:TWINxxxxxxxC", year: null, citedBy: 50 };
    const { articles, notes } = matchArticles([twin, article("qjMakFHDy7sC")], PUBS);
    assert.deepEqual(articles.map((a) => a.pub), [null, "tripathi-2015-malaria"]);
    assert.match(notes[0], /twice/);
  });

  test("an override pairs an entry whose title differs", () => {
    const renamed = { ...article("qjMakFHDy7sC"), title: "DNA barcodes for malaria parasites" };
    assert.equal(matchArticles([renamed], PUBS).articles[0].pub, null);
    assert.equal(matchArticles([renamed], PUBS, { [renamed.id]: "tripathi-2015-malaria" }).articles[0].pub, "tripathi-2015-malaria");
  });

  test("rematch pairs a snapshot again after a paper is renamed on the site", () => {
    const renamedPubs = PUBS.map((p) => (p.id === "tripathi-2015-malaria" ? { ...p, id: "tripathi-2015-barcodes" } : p));
    const again = rematch(base, renamedPubs);
    assert.equal(entryFor(again, "tripathi-2015-barcodes").id, "zZx1Td0AAAAJ:qjMakFHDy7sC");
    assert.equal(again.checkedAt, base.checkedAt);
    assert.equal(dataChanged(base, again), true);
  });
});

describe("validate: whether a new read may replace the committed snapshot", () => {
  const now = new Date(hoursLater(CHECKED, 5));
  const opts = { profileId: "zZx1Td0AAAAJ", name: "Madhavi Tripathi", now };
  const later = (edit: (s: ScholarSnapshot) => void) => {
    const next = copy(base);
    next.checkedAt = hoursLater(CHECKED, 4);
    edit(next);
    return next;
  };

  test("the fixture's own snapshot passes", () => {
    assert.deepEqual(validate(base, undefined, opts), { errors: [], warnings: [] });
    assert.deepEqual(validate(later(() => {}), base, opts).errors, []);
  });

  test("refuses a drop of more than 10% in total citations, unless forced", () => {
    const citations = (n: number) =>
      later((s) => {
        s.totals.citations = n;
        s.recent.citations = n - 6;
      });
    const dropped = citations(93); // 10.6% below 104
    assert.match(validate(dropped, base, opts).errors.join(), /fell from 104 to 93 \(10\.6%\)/);
    const forced = validate(dropped, base, { ...opts, force: true });
    assert.deepEqual(forced.errors, []);
    assert.match(forced.warnings.join(), /--force/);
    const small = validate(citations(94), base, opts); // 9.6%
    assert.deepEqual(small.errors, []);
    assert.match(small.warnings.join(), /fell from 104 to 94/);
  });

  test("refuses a drop of more than 10% in the article count, unless forced; says so when the read was partial", () => {
    const fewer = later((s) => (s.articles = s.articles.slice(0, 13))); // 13.3% fewer
    assert.match(validate(fewer, base, opts).errors.join(), /article count fell from 15 to 13/);
    assert.match(validate(fewer, base, { ...opts, incomplete: true }).errors.join(), /lists only part of the profile/);
    assert.deepEqual(validate(fewer, base, { ...opts, force: true }).errors, []);
    assert.deepEqual(validate(later((s) => (s.articles = s.articles.slice(0, 14))), base, opts).errors, []);
  });

  test("refuses another profile, another name, no articles, and figures that can't be true together", () => {
    assert.match(validate(base, undefined, { ...opts, profileId: "AAAAAAAAAAAA" }).errors.join(), /not the site's profile/);
    assert.match(validate(base, undefined, { ...opts, name: "Manjari Tripathi" }).errors.join(), /is not "Manjari Tripathi"/);
    assert.match(validate(later((s) => (s.articles = [])), undefined, opts).errors.join(), /no articles/);
    assert.match(validate(later((s) => (s.recent.citations = 105)), undefined, opts).errors.join(), /exceed the all-time/);
    assert.match(validate(later((s) => (s.totals.i10Index = 8)), undefined, opts).errors.join(), /i10-index exceeds/);
  });

  test("refuses a read older than the committed snapshot, unless forced", () => {
    const older = copy(base);
    older.checkedAt = hoursLater(CHECKED, -1);
    assert.match(validate(older, base, opts).errors.join(), /older than the committed snapshot/);
    assert.deepEqual(validate(older, base, { ...opts, force: true }).errors, []);
  });

  test("refuses a read time in the future, even with --force (it would fail every build's check)", () => {
    const future = later((s) => (s.checkedAt = hoursLater(CHECKED, 6)));
    assert.match(validate(future, base, opts).errors.join(), /in the future/);
    assert.match(validate(future, base, { ...opts, force: true }).errors.join(), /in the future/);
    assert.deepEqual(validate(later((s) => (s.checkedAt = hoursLater(CHECKED, 5.1))), base, opts).errors, []); // within 10 minutes
  });

  test("the name may carry more than the site's (a title, a middle name)", () => {
    const titled = later((s) => (s.profile.name = "Dr. Madhavi Tripathi"));
    assert.deepEqual(validate(titled, base, opts).errors, []);
  });
});

describe("when to write", () => {
  test("dataChanged ignores checkedAt, the source, and article order, and sees any figure", () => {
    const same = copy(base);
    same.checkedAt = hoursLater(CHECKED, 30);
    same.source = "serpapi";
    same.articles.reverse();
    assert.equal(dataChanged(base, same), false);
    const cited = copy(base);
    cited.articles[0].citedBy += 1;
    assert.equal(dataChanged(base, cited), true);
    const perYear = copy(base);
    perYear.byYear[8].citations = 22;
    assert.equal(dataChanged(base, perYear), true);
  });

  test("the 20-hour rule: unchanged data is rewritten only once the committed checkedAt is over 20 hours old", () => {
    const at = (hours: number) => ({ ...copy(base), checkedAt: hoursLater(CHECKED, hours) });
    assert.equal(needsWrite(undefined, base), "new");
    assert.equal(needsWrite(base, at(4)), null);
    assert.equal(needsWrite(base, at(19.99)), null);
    assert.equal(needsWrite(base, at(20)), null);
    assert.equal(needsWrite(base, at(20.01)), "refresh");
    const changed = at(0.5);
    changed.totals.citations = 105;
    assert.equal(needsWrite(base, changed), "changed");
  });

  test("the same figures through SerpApi 4 hours later are no change (no commit)", () => {
    const viaSerpApi: ScholarSnapshot = {
      ...snapshotOf(fromSerpApi(serpApiFor(parsed)), hoursLater(CHECKED, 4)),
      source: "serpapi",
    };
    assert.equal(needsWrite(base, viaSerpApi), null);
  });
});

describe("the snapshot file", () => {
  test("is stable: fixed key order, newest first, 2-space indent, trailing newline", () => {
    const text = serializeSnapshot(base);
    assert.equal(serializeSnapshot(JSON.parse(text) as ScholarSnapshot), text);
    const shuffled = copy(base);
    shuffled.articles.reverse();
    shuffled.byYear.reverse();
    assert.equal(serializeSnapshot(shuffled), text);
    assert.ok(text.endsWith("}\n") && text.startsWith('{\n  "schema": 1,\n  "profile": {\n    "id"'));
    const years = (JSON.parse(text) as ScholarSnapshot).articles.map((a) => a.year);
    assert.deepEqual(years, [2026, 2026, 2026, 2026, 2025, 2025, 2024, 2023, 2023, 2022, 2021, 2021, 2015, 2015, null]);
  });

  test("times must be real UTC seconds", () => {
    assert.equal(isIsoSeconds(CHECKED), true);
    for (const bad of ["2026-02-30T00:00:00Z", "2026-13-45T99:99:99Z", "2026-09-28T10:14:54.000Z", "2026-09-28 10:14:54Z"]) {
      assert.equal(isIsoSeconds(bad), false, bad);
    }
    assert.match(shapeErrors({ ...base, checkedAt: "2026-02-30T00:00:00Z" }).join(), /checkedAt/);
  });

  test("the committed src/content/scholar.json is in the script's layout and passes the offline check", () => {
    const raw = readFileSync(join(APP, "src", "content", "scholar.json"), "utf8");
    const committed = JSON.parse(raw) as ScholarSnapshot;
    assert.equal(serializeSnapshot(committed), raw);
    assert.deepEqual(checkSnapshot(committed, { ...OWNER, publications: LIVE_PUBS, now: new Date(committed.checkedAt) }).errors, []);
  });

  test("src/content/scholar.ts loads in Node (JSON import attribute) and looks entries up by publication id", () => {
    assert.equal(scholar.schema, 1);
    assert.equal(scholar.profile.id, "zZx1Td0AAAAJ");
    for (const entry of scholar.articles) if (entry.pub) assert.equal(scholarFor(entry.pub), entry);
    assert.equal(scholarFor("no-such-paper"), undefined);
  });
});

describe("checkSnapshot (--check, before every build)", () => {
  const context = { ...OWNER, publications: PUBS, now: new Date(hoursLater(CHECKED, 1)) };

  test("passes the fixture's snapshot with no warnings", () => {
    assert.deepEqual(checkSnapshot(base, context), { errors: [], warnings: [] });
  });

  test("fails on an unknown or twice-claimed publication id, a gap in the years, a negative count, another profile", () => {
    const unknown = copy(base);
    unknown.articles[0].pub = "no-such-paper";
    assert.match(checkSnapshot(unknown, context).errors.join(), /"no-such-paper" is not in publications\.ts: run `npm run scholar -- --rematch`/);
    const twice = copy(base);
    twice.articles[1].pub = twice.articles[0].pub;
    assert.match(checkSnapshot(twice, context).errors.join(), /is also claimed by/);
    const gap = copy(base);
    gap.byYear.splice(3, 1);
    assert.match(checkSnapshot(gap, context).errors.join(), /zero-filled/);
    const negative = copy(base);
    negative.articles[2].citedBy = -1;
    assert.match(checkSnapshot(negative, context).errors.join(), /non-negative integer/);
    const fraction = copy(base);
    fraction.totals.hIndex = 7.5;
    assert.match(checkSnapshot(fraction, context).errors.join(), /totals\.hIndex/);
    assert.match(checkSnapshot(base, { ...context, profileId: "AAAAAAAAAAAA" }).errors.join(), /not the Scholar id in person\.ts/);
    assert.match(checkSnapshot({ ...base, schema: 2 }, context).errors.join(), /schema/);
    assert.match(checkSnapshot({ ...base, checkedAt: hoursLater(CHECKED, 2) }, context).errors.join(), /in the future/);
  });

  test("warns about entries the site doesn't list, papers Scholar doesn't list, stale pairings, and an old snapshot", () => {
    const unlisted = copy(base);
    entryFor(unlisted, "enslein-2026-spie").pub = null;
    const { errors, warnings } = checkSnapshot(unlisted, { ...context, now: new Date(hoursLater(CHECKED, 15 * 24)) });
    assert.deepEqual(errors, []);
    assert.equal(warnings.length, 4);
    const text = warnings.join("\n");
    assert.match(text, /15 days ago/);
    assert.match(text, /1 entry the site does not show/);
    assert.match(text, /1 site paper\(s\) not found on Scholar: enslein-2026-spie/);
    assert.match(text, /1 entry is paired differently by today's matching/);
  });

  test("an IGNORED entry is not reported as missing from the site", () => {
    const unlisted = copy(base);
    const entry = entryFor(unlisted, "tripathi-2015-malaria");
    entry.pub = null;
    const ignored = { [entry.id]: "kept off the site" };
    assert.doesNotMatch(checkSnapshot(unlisted, { ...context, ignored }).warnings.join(), /does not show/);
    assert.equal(unlistedReport(unlisted, ignored), null);
  });

  test("the report lists the entries the site doesn't show, with no counts or dates, as inert Markdown", () => {
    assert.equal(unlistedReport(base), null);
    const unlisted = copy(base);
    const entry = entryFor(unlisted, "tripathi-2015-malaria");
    entry.pub = null;
    const report = unlistedReport(unlisted) ?? "";
    assert.match(report, /lists an entry that the site does not show/);
    assert.match(report, /\| \[Genotyping malaria parasites with DNA barcodes\]\(https:\/\/scholar\.google\.com\/citations\?view_op=view_citation&hl=en&user=zZx1Td0AAAAJ&citation_for_view=zZx1Td0AAAAJ:qjMakFHDy7sC\) \| M Tripathi, A Das \|/);
    assert.doesNotMatch(report, /Cited by|2026-09/);
    entry.title = "A [link](https://example.com) *bold* `code` | pipe <b> @someone";
    const escaped = unlistedReport(unlisted) ?? "";
    assert.match(escaped, /A \\\[link\\\]\\\(https:\/\/example\.com\\\) \\\*bold\\\* \\`code\\` \\\| pipe &lt;b&gt; @​someone/);
  });
});

describe("fromSerpApi (SerpApi's documented example)", () => {
  test("maps the author, totals, recent figures, and citations per year", () => {
    const profile = fromSerpApi(SERPAPI_EXAMPLE);
    assert.deepEqual(profile.profile, { id: "EicYvbwAAAAJ", url: "https://scholar.google.com/citations?user=EicYvbwAAAAJ&hl=en", name: "Ronald C Kessler" });
    assert.deepEqual(profile.totals, { citations: 466834, hIndex: 314, i10Index: 1164 });
    assert.deepEqual(profile.recent, { since: 2016, citations: 184564, hIndex: 197, i10Index: 936 });
    assert.deepEqual(profile.byYear, [{ year: 1993, citations: 1180 }, { year: 1994, citations: 1553 }, { year: 1995, citations: 1981 }]);
    assert.equal(profile.complete, true);
  });

  test("maps articles the way the profile page reads them", () => {
    const [first] = fromSerpApi(SERPAPI_EXAMPLE).articles;
    assert.deepEqual(first, {
      id: "EicYvbwAAAAJ:UeHWp8X0CEIC",
      title: "Lifetime prevalence and age-of-onset distributions of DSM-IV disorders in the National Comorbidity Survey Replication",
      authors: "RC Kessler, P Berglund, O Demler, R Jin, KR Merikangas, EE Walters",
      venue: "Archives of general psychiatry 62 (6), 593-602",
      year: 2005,
      citedBy: 29693,
      citedByUrl:
        "https://scholar.google.com/scholar?cites=2173726401600747709,7905695317477875023,11857341765727177149,16204114791750186183,8105499853130787711,12694166320960692368&hl=en",
    });
  });

  test("gives the page's own figures for the fixture's profile", () => {
    const viaSerpApi = fromSerpApi(serpApiFor(parsed));
    assert.deepEqual({ ...viaSerpApi, complete: true }, parsed);
  });

  test("an article without citations or year, a venue ending in a year, a year gap, more pages (shapes assumed, not documented)", () => {
    const edited = structuredClone(SERPAPI_EXAMPLE) as {
      articles: Record<string, unknown>[];
      cited_by: { graph: { year: number; citations: number }[] };
      serpapi_pagination?: { next: string };
    };
    edited.articles.push({ title: "A thesis", citation_id: "EicYvbwAAAAJ:abcdefghijkC", authors: "RC Kessler", publication: "", cited_by: { value: null }, year: "" });
    edited.articles.push({ title: "A talk", citation_id: "EicYvbwAAAAJ:bcdefghijklC", authors: "RC Kessler", publication: "Imaging and Sensing 2026", year: "2026" });
    edited.articles.push({ title: "A note", citation_id: "EicYvbwAAAAJ:cdefghijklmC", authors: "RC Kessler", publication: "2019", year: "2019" });
    edited.cited_by.graph.push({ year: 1997, citations: 2 });
    edited.serpapi_pagination = { next: "https://serpapi.com/search.json?start=100" };
    const profile = fromSerpApi(edited);
    const [thesis, talk, note] = profile.articles.slice(3);
    assert.equal(thesis.citedBy, 0);
    assert.equal("citedByUrl" in thesis, false);
    assert.equal(thesis.year, null);
    assert.equal(talk.venue, "Imaging and Sensing 2026");
    assert.equal(note.venue, "");
    assert.deepEqual(profile.byYear.slice(-2), [{ year: 1996, citations: 0 }, { year: 1997, citations: 2 }]);
    assert.equal(profile.complete, false);
  });

  test("errors in the response are parse faults, on one line", () => {
    assert.throws(() => fromSerpApi({ error: "Invalid API key.\n::error::injected" }), /SerpApi: Invalid API key\. ::error::injected$/);
    assert.throws(() => fromSerpApi({ ...(SERPAPI_EXAMPLE as object), search_metadata: { status: "Error" } }), /status "Error"/);
    assert.throws(() => fromSerpApi({ ...(SERPAPI_EXAMPLE as object), cited_by: {} }), /no citations in cited_by\.table/);
  });
});

describe("scholar-sync.mts with Google and SerpApi stubbed (one request each, at most)", () => {
  let dir = "";
  let snapshotPath = "";
  let committedText = "";
  const logs: string[] = [];
  const env = { key: process.env.SERPAPI_API_KEY, output: process.env.GITHUB_OUTPUT, actions: process.env.GITHUB_ACTIONS };

  before(() => {
    dir = mkdtempSync(join(tmpdir(), "scholar-sync-"));
    snapshotPath = join(dir, "scholar.json");
    committedText = serializeSnapshot(base);
    delete process.env.GITHUB_OUTPUT;
    delete process.env.GITHUB_ACTIONS;
    mock.method(console, "log", (...args: unknown[]) => logs.push(args.join(" ")));
  });
  after(() => {
    mock.restoreAll();
    rmSync(dir, { recursive: true, force: true });
    for (const [name, value] of [["SERPAPI_API_KEY", env.key], ["GITHUB_OUTPUT", env.output], ["GITHUB_ACTIONS", env.actions]] as const) {
      if (value === undefined) delete process.env[name];
      else process.env[name] = value;
    }
  });

  /** Replaces fetch for one run: Google answers with `google`, SerpApi with `serpapi`; every request is recorded. */
  function stub(google: () => Response, serpapi?: () => Response) {
    const calls: { url: string; init?: RequestInit }[] = [];
    const fake = mock.method(globalThis, "fetch", async (input: string | URL | Request, init?: RequestInit) => {
      const url = String(input instanceof Request ? input.url : input);
      calls.push({ url, init });
      if (url.startsWith("https://scholar.google.com/")) return google();
      if (url.startsWith("https://serpapi.com/") && serpapi) return serpapi();
      throw new Error(`unexpected request to ${url}`);
    });
    return { calls, restore: () => fake.mock.restore() };
  }
  const sync = (report?: string) => runSync({ snapshotPath, force: false, report }, OWNER, PUBS);
  const latin1 = (text: string) => Uint8Array.from(text, (c) => c.charCodeAt(0));
  const pageResponse = (html = page) => () => new Response(latin1(html), { status: 200, headers: { "content-type": "text/html; charset=ISO-8859-1" } });
  const sorry = () => new Response("<html><body>Our systems have detected unusual traffic from your computer network.</body></html>", { status: 429 });

  test("one polite GET: honest User-Agent, Accept-Language en, no redirects followed; nothing but the profile page", async () => {
    const { calls, restore } = stub(pageResponse());
    try {
      const read = await readProfilePage(PROFILE);
      assert.equal(read.ok, true);
      assert.equal(calls.length, 1);
      const headers = new Headers(calls[0].init?.headers);
      assert.equal(headers.get("user-agent"), USER_AGENT);
      assert.equal(headers.get("accept-language"), "en");
      assert.equal(calls[0].init?.redirect, "manual");
      await assert.rejects(readProfilePage(`${PROFILE}&cstart=20`), /cstart/);
      await assert.rejects(readProfilePage("https://scholar.google.com/citations?view_op=list_works&user=zZx1Td0AAAAJ"), /only the profile page/);
      assert.equal(calls.length, 1);
    } finally {
      restore();
    }
  });

  test("blocked, no key: exit 3 after one request, and the snapshot is left as it was", async () => {
    writeFileSync(snapshotPath, committedText);
    delete process.env.SERPAPI_API_KEY;
    const { calls, restore } = stub(sorry);
    const code = await sync();
    restore();
    assert.equal(code, 3);
    assert.equal(calls.length, 1);
    assert.equal(readFileSync(snapshotPath, "utf8"), committedText);
  });

  test("a profile page that no longer parses: exit 1, nothing written", async () => {
    writeFileSync(snapshotPath, committedText);
    delete process.env.SERPAPI_API_KEY;
    for (const broken of [page.replace('id="gsc_rsb_st"', 'id="gsc_rsb_other"'), page.replace('id="gsc_prf_in"', 'id="gsc_prf_name"')]) {
      const { restore } = stub(pageResponse(broken));
      const code = await sync();
      restore();
      assert.equal(code, 1);
      assert.equal(readFileSync(snapshotPath, "utf8"), committedText);
    }
  });

  test("blocked, with SERPAPI_API_KEY: one SerpApi request, same figures so nothing written, key never printed", async () => {
    writeFileSync(snapshotPath, committedText);
    const key = "test-key-0123456789abcdef";
    process.env.SERPAPI_API_KEY = key;
    logs.length = 0;
    const { calls, restore } = stub(sorry, () => Response.json(serpApiFor(parsed)));
    const code = await sync();
    restore();
    assert.equal(code, 0);
    assert.equal(calls.length, 2);
    const serpUrl = new URL(calls[1].url);
    assert.equal(serpUrl.searchParams.get("engine"), "google_scholar_author");
    assert.equal(serpUrl.searchParams.get("author_id"), "zZx1Td0AAAAJ");
    assert.equal(serpUrl.searchParams.get("num"), "100");
    assert.equal(serpUrl.searchParams.get("api_key"), key);
    assert.equal(readFileSync(snapshotPath, "utf8"), committedText, "same figures through SerpApi: no write, no commit");
    assert.match(logs.join("\n"), /Snapshot unchanged/);
    assert.doesNotMatch(logs.join("\n"), new RegExp(key));
    assert.doesNotMatch(logs.join("\n"), /serpapi\.com\/search/);
  });

  test("an unparseable page covered by SerpApi: written, and flagged in the Actions summary", async () => {
    writeFileSync(snapshotPath, committedText);
    process.env.SERPAPI_API_KEY = "test-key-flag";
    process.env.GITHUB_ACTIONS = "true";
    logs.length = 0;
    const newer = serpApiFor(parsed);
    newer.articles[0].cited_by = { value: 35, cites_id: "134142379856010976" };
    const { restore } = stub(pageResponse(page.replace('id="gsc_rsb_st"', 'id="gsc_rsb_other"')), () => Response.json(newer));
    const code = await sync();
    restore();
    delete process.env.GITHUB_ACTIONS;
    assert.equal(code, 0);
    const written = JSON.parse(readFileSync(snapshotPath, "utf8")) as ScholarSnapshot;
    assert.equal(written.source, "serpapi");
    assert.equal(entryFor(written, "wazalwar-2022-mxene-epoxy").citedBy, 35);
    assert.match(logs.join("\n"), /^::warning title=Scholar page parser needs attention::/m);
  });

  test("a page that lists only part of the profile: SerpApi is asked for the rest when there is a key", async () => {
    writeFileSync(snapshotPath, committedText);
    process.env.SERPAPI_API_KEY = "test-key-partial";
    const partial = page.replace('id="gsc_bpf_more" disabled', 'id="gsc_bpf_more"');
    const { calls, restore } = stub(pageResponse(partial), () => Response.json(serpApiFor(parsed)));
    const code = await sync();
    restore();
    assert.equal(code, 0);
    assert.deepEqual(calls.map((c) => new URL(c.url).host), ["scholar.google.com", "serpapi.com"]);
  });

  test("SerpApi's refusal is reported without the key: exit 3", async () => {
    writeFileSync(snapshotPath, committedText);
    const key = "test-key-fedcba9876543210";
    process.env.SERPAPI_API_KEY = key;
    logs.length = 0;
    const { restore } = stub(sorry, () => Response.json({ error: `Invalid API key ${key}.` }, { status: 401 }));
    const code = await sync();
    restore();
    assert.equal(code, 3);
    assert.match(logs.join("\n"), /HTTP 401: Invalid API key \[key\]/);
    assert.doesNotMatch(logs.join("\n"), new RegExp(key));
    assert.equal(readFileSync(snapshotPath, "utf8"), committedText);
  });
});

describe("scholar-sync.mts on the command line (no network)", () => {
  let dir = "";
  before(() => (dir = mkdtempSync(join(tmpdir(), "scholar-cli-"))));
  after(() => rmSync(dir, { recursive: true, force: true }));

  // Every child process starts with fetch disabled, so a regression can't reach Google.
  const NO_NETWORK = `data:text/javascript,globalThis.fetch=()=>{throw new Error("network disabled in tests")}`;
  const run = (...args: string[]) => {
    const outputs = join(dir, "outputs.txt");
    rmSync(outputs, { force: true });
    // No SerpApi key, whatever the shell has (child_process skips undefined values).
    const env = { ...process.env, GITHUB_OUTPUT: outputs, SERPAPI_API_KEY: undefined, GITHUB_ACTIONS: undefined };
    const result = spawnSync(process.execPath, [`--import=${NO_NETWORK}`, SCRIPT, ...args], { encoding: "utf8", env });
    return { ...result, outputs: existsSync(outputs) ? readFileSync(outputs, "utf8") : "" };
  };

  test("--from writes the snapshot, then leaves it alone until it is over 20 hours old; a future time is refused", () => {
    // Read times in the past (a time after this machine's clock is refused).
    const [t0, t8, t21] = [hoursLater(CHECKED, -30), hoursLater(CHECKED, -22), hoursLater(CHECKED, -9)];
    const snapshot = join(dir, "scholar.json");
    const report = join(dir, "unlisted.md");
    const first = run("--from", FIXTURE, "--checked-at", t0, "--snapshot", snapshot, "--report", report);
    assert.equal(first.status, 0, first.stderr);
    assert.equal(readFileSync(snapshot, "utf8"), serializeSnapshot({ ...base, checkedAt: t0 }));
    assert.match(first.outputs, /^result=written$/m);
    assert.match(first.outputs, /^citations=104$/m);
    assert.match(first.outputs, /^checked_day=27 Sep 2026$/m);
    assert.match(first.outputs, /^unlisted=0$/m);
    assert.equal(existsSync(report), false);

    const second = run("--from", FIXTURE, "--checked-at", t8, "--snapshot", snapshot);
    assert.equal(second.status, 0, second.stderr);
    assert.match(second.stdout, /Snapshot unchanged/);
    assert.equal(JSON.parse(readFileSync(snapshot, "utf8")).checkedAt, t0);

    const third = run("--from", FIXTURE, "--checked-at", t21, "--snapshot", snapshot);
    assert.equal(third.status, 0, third.stderr);
    assert.match(third.stdout, /Snapshot written.*over 20 hours ago/);
    assert.equal(JSON.parse(readFileSync(snapshot, "utf8")).checkedAt, t21);

    const future = run("--from", FIXTURE, "--checked-at", "2999-01-01T00:00:00Z", "--snapshot", snapshot);
    assert.equal(future.status, 1);
    assert.match(future.stdout, /in the future/);
    assert.equal(JSON.parse(readFileSync(snapshot, "utf8")).checkedAt, t21);
  });

  test("--check passes the committed snapshot and fails a broken one; --rematch repairs a stale pairing", () => {
    assert.equal(run("--check").status, 0);
    const broken = copy(base);
    broken.articles[1].pub = broken.articles[0].pub;
    const path = join(dir, "broken.json");
    writeFileSync(path, serializeSnapshot(broken));
    const result = run("--check", "--snapshot", path);
    assert.equal(result.status, 1);
    assert.match(result.stderr, /Problems:\n {2}articles\[\d+\]\.pub: "[\w-]+" is also claimed by zZx1Td0AAAAJ:/);
    const missing = run("--check", "--snapshot", join(dir, "absent.json"));
    assert.equal(missing.status, 1);
    assert.match(missing.stderr, /missing: run `npm run scholar`/);

    const renamed = copy(base);
    entryFor(renamed, "tripathi-2015-malaria").pub = "tripathi-2015-old-id";
    const stale = join(dir, "stale.json");
    writeFileSync(stale, serializeSnapshot(renamed));
    const before = run("--check", "--snapshot", stale);
    assert.equal(before.status, 1);
    assert.match(before.stderr, /"tripathi-2015-old-id" is not in publications\.ts: run `npm run scholar -- --rematch`/);
    const fixed = run("--rematch", "--snapshot", stale);
    assert.equal(fixed.status, 0, fixed.stderr);
    assert.match(fixed.stdout, /tripathi-2015-old-id → tripathi-2015-malaria/);
    assert.equal(JSON.parse(readFileSync(stale, "utf8")).checkedAt, CHECKED);
    assert.equal(run("--check", "--snapshot", stale).status, 0);
    assert.match(run("--rematch", "--snapshot", stale).stdout, /nothing to write/);
  });

  test("a saved block page is a failure (1); usage errors are 2", () => {
    const blocked = join(dir, "blocked.html");
    writeFileSync(blocked, "<html><body>Our systems have detected unusual traffic from your computer network.</body></html>");
    const result = run("--from", blocked, "--snapshot", join(dir, "none.json"));
    assert.equal(result.status, 1);
    assert.match(result.stdout, /unusual traffic/);
    assert.equal(existsSync(join(dir, "none.json")), false);
    for (const args of [
      ["--check", "--force"],
      ["--check", "--rematch"],
      ["--rematch", "--from", FIXTURE],
      ["--nonsense"],
      ["--checked-at", CHECKED],
      ["--from", FIXTURE, "--checked-at", "2026-13-45T99:99:99Z"],
      ["--from", dir],
      ["positional"],
    ]) {
      assert.equal(run(...args).status, 2, args.join(" "));
    }
  });
});
