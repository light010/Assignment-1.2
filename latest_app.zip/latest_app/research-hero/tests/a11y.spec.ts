import fs from "node:fs";
import path from "node:path";
import AxeBuilder from "@axe-core/playwright";
import type { Locator, Page, TestInfo } from "@playwright/test";
import sharp from "sharp";
import { expect, test } from "./support/fixtures";
import { LAB, SHOW, atRest, effectiveOpacity, instantScroll, pageSectionIds, scrollElementTopTo, settle, waitForApp, waitForLab } from "./support/helpers";

/*
  Accessibility (D-engineering §4; PLAN §8 Sweep 2), Chromium only.
  axe (WCAG 2.0 A/AA, 2.1 AA, 2.2 AA) in every lab chapter, every ?show= value, with a Cite panel open,
  and on the 404, at 390 and 1440 px: any violation fails; "incomplete" results (text over the WebGL
  canvas and glass, which axe can't measure) are listed per test and attached as JSON.
  Then: 320 px reflow, WCAG 1.4.12 text spacing, target size (2.5.8, plus a 44 px report for touch),
  a visible focus indicator on every Tab stop (also under forced colors), and forced-colors screenshots.
*/

const AXE_TAGS = ["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"];
const VIEWPORTS = [
  { width: 390, height: 844 },
  { width: 1440, height: 900 },
] as const;

type Finding = Record<string, unknown>;

/** Loads the home page (or another path), waits for React, the lab, and the entrance to finish. */
async function open(page: Page, url = "/") {
  await page.goto(url);
  await waitForApp(page);
  await waitForLab(page).catch(() => "timeout");
  // Every block at rest, as it is once scrolled to (a block waiting for its moment isn't what these checks are about).
  await atRest(page);
}

async function openChapter(page: Page, slug: string) {
  const button = page.locator(`#${slug}`);
  if ((await button.getAttribute("aria-pressed")) !== "true") await button.click();
  await expect(button).toHaveAttribute("aria-pressed", "true");
  // Park the pointer: the chapter buttons scale up on hover, which would skew every measurement.
  await page.mouse.move(1, 1);
  await page.waitForTimeout(500);
  await settle(page);
}

/** Opens the first paper in the list, then its Cite panel. */
async function openFirstPaper(page: Page) {
  const first = page.locator("#publication-list .pub-row").first();
  await first.locator(".pub-toggle").click();
  await first.locator("summary", { hasText: "Cite" }).click();
}

/** "Show all" (phones) or "Show the whole list": every row where its box is, in the page. */
async function showWholeList(page: Page) {
  const length = page.locator('#publications button[aria-controls="publication-list"][aria-expanded="false"]');
  if (await length.count()) await length.click();
}

/** The whole list, every paper open with its Cite panel: the longest the section gets. */
async function openWholeList(page: Page) {
  await showWholeList(page);
  const rows = page.locator("#publication-list .pub-row");
  for (let i = 0; i < (await rows.count()); i++) {
    await rows.nth(i).locator(".pub-toggle").click();
    await rows.nth(i).locator("summary", { hasText: "Cite" }).click();
  }
}

async function attachJson(testInfo: TestInfo, name: string, data: unknown) {
  await testInfo.attach(name, { body: JSON.stringify(data, null, 2), contentType: "application/json" });
}

async function axe(page: Page, testInfo: TestInfo, label: string) {
  const results = await new AxeBuilder({ page }).withTags(AXE_TAGS).analyze();
  const violations = results.violations.map((v) => ({
    id: v.id,
    impact: v.impact,
    help: v.help,
    nodes: v.nodes.map((n) => ({ target: n.target.join(" "), summary: n.failureSummary })),
  }));
  const incomplete = results.incomplete.map((v) => ({
    id: v.id,
    count: v.nodes.length,
    reasons: [...new Set(v.nodes.flatMap((n) => [...n.any, ...n.all, ...n.none].map((c) => c.message)))].slice(0, 6),
    targets: v.nodes.slice(0, 40).map((n) => n.target.join(" ")),
  }));
  await attachJson(testInfo, `axe-${label}.json`, { url: page.url(), label, violations, incomplete, passes: results.passes.length });
  testInfo.annotations.push({
    type: "axe-incomplete",
    description: `${label}: ${incomplete.map((i) => `${i.id} ×${i.count}`).join(", ") || "none"}`,
  });
  expect(violations, `axe violations: ${label}`).toEqual([]);
}

for (const viewport of VIEWPORTS) {
  test.describe(`axe at ${viewport.width}×${viewport.height}`, () => {
    test.use({ viewport });

    test("home, lab overview", async ({ page }, testInfo) => {
      await open(page);
      await axe(page, testInfo, `${viewport.width}-overview`);
    });

    for (const lab of LAB) {
      test(`lab chapter: ${lab.name}`, async ({ page }, testInfo) => {
        await open(page);
        await openChapter(page, lab.slug);
        await axe(page, testInfo, `${viewport.width}-${lab.slug}`);
      });
    }

    for (const { value } of SHOW) {
      test(`?show=${value}`, async ({ page }, testInfo) => {
        await open(page, `/?show=${value}#publications`);
        await axe(page, testInfo, `${viewport.width}-show-${value}`);
      });
    }

    test("a paper open with its Cite panel, the list by most cited", async ({ page }, testInfo) => {
      await open(page, "/?sort=cited#publications");
      const first = page.locator("#publication-list .pub-row").first();
      await first.locator(".pub-toggle").click();
      const summary = first.locator("summary", { hasText: "Cite" });
      await summary.click();
      await expect(summary.locator("xpath=..")).toHaveAttribute("open", "");
      await settle(page);
      await axe(page, testInfo, `${viewport.width}-cite-open`);
    });

    test("the 404 page", async ({ page, guard }, testInfo) => {
      guard.allow(/(http 404 GET|status of 404).*\/no-such-page/);
      await page.goto("/no-such-page");
      await settle(page);
      await axe(page, testInfo, `${viewport.width}-404`);
    });
  });
}

/* ------------------------------------------------------------------------------------------------
   Reflow at 320 px (WCAG 1.4.10): no horizontal scrolling and nothing cut off at the viewport edge.
------------------------------------------------------------------------------------------------ */

async function overflow(page: Page) {
  return page.evaluate(() => {
    const vw = document.documentElement.clientWidth;
    const before = scrollX;
    window.scrollTo({ left: 200, top: scrollY, behavior: "instant" as ScrollBehavior });
    const scrolledX = scrollX;
    window.scrollTo({ left: before, top: scrollY, behavior: "instant" as ScrollBehavior });
    const cutOff: string[] = [];
    const textCutOff: string[] = [];
    // Content inside a scroller that itself fits the viewport (a card rail, say) is clipped on purpose. Walk past
    // clipping boxes that are themselves off-screen (a card's own image frame) to the one that fits.
    const clippedByAncestor = (start: Element | null) => {
      for (let a = start; a && a !== document.body; a = a.parentElement) {
        if (getComputedStyle(a).overflowX !== "visible") {
          const ar = a.getBoundingClientRect();
          if (ar.right <= vw + 0.5 && ar.left >= -0.5) return true;
        }
      }
      return false;
    };
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      const el = node.parentElement;
      if (!el || !node.textContent?.trim() || el.closest(".sr-only, [inert], script, style")) continue;
      if (!el.checkVisibility({ opacityProperty: true, visibilityProperty: true })) continue;
      const range = document.createRange();
      range.selectNodeContents(node);
      const out = Array.from(range.getClientRects()).find((r) => r.width > 0 && (r.right > vw + 0.5 || r.left < -0.5));
      if (!out || clippedByAncestor(el)) continue;
      textCutOff.push(`text in ${el.tagName.toLowerCase()}${el.id ? `#${el.id}` : ""} "${node.textContent.trim().slice(0, 50)}" runs to x ${Math.round(out.right)} (viewport ${vw})`);
    }
    for (const el of Array.from(document.querySelectorAll<HTMLElement>("body *"))) {
      if (!el.checkVisibility({ opacityProperty: true, visibilityProperty: true })) continue;
      if (el.closest(".sr-only, [inert]")) continue;
      const r = el.getBoundingClientRect();
      if (r.width < 1 || r.height < 1) continue;
      if (r.right <= vw + 0.5 && r.left >= -0.5) continue;
      // Ignore what an ancestor clips on purpose, as long as that ancestor itself fits.
      if (clippedByAncestor(el.parentElement)) continue;
      // Report the outermost offender only.
      const parent = el.parentElement?.getBoundingClientRect();
      if (parent && (parent.right > vw + 0.5 || parent.left < -0.5) && el.parentElement !== document.body) continue;
      const name = (el.getAttribute("aria-label") ?? el.textContent ?? "").replace(/\s+/g, " ").trim().slice(0, 40);
      cutOff.push(`${el.tagName.toLowerCase()}${el.id ? `#${el.id}` : ""} "${name}" spans x ${Math.round(r.left)}–${Math.round(r.right)} (viewport ${vw})`);
    }
    return { vw, scrollWidth: document.documentElement.scrollWidth, bodyScrollWidth: document.body.scrollWidth, scrolledX, cutOff, textCutOff };
  });
}

test.describe("Reflow at 320 px", () => {
  test.use({ viewport: { width: 320, height: 568 } });

  async function expectReflow(page: Page, where: string) {
    const r = await overflow(page);
    expect.soft(r.scrollWidth, `${where}: document scrollWidth`).toBeLessThanOrEqual(r.vw);
    expect.soft(r.scrolledX, `${where}: horizontal scroll possible`).toBe(0);
    expect.soft(r.textCutOff, `${where}: text cut off at the viewport edge`).toEqual([]);
    // Boxes (padding, focus rings) past the edge don't lose content: reported, not failed.
    for (const box of r.cutOff) {
      const note = `${where}: ${box}`;
      if (!test.info().annotations.some((a) => a.description?.endsWith(box))) test.info().annotations.push({ type: "box-past-edge", description: note });
    }
  }

  test("every section, with the section bar showing", async ({ page }) => {
    await open(page);
    await instantScroll(page);
    await expectReflow(page, "top of the page");
    for (const id of await pageSectionIds(page)) {
      await scrollElementTopTo(page, id);
      await settle(page);
      await expectReflow(page, `#${id}`);
    }
    await page.evaluate(() => window.scrollTo({ top: document.documentElement.scrollHeight, behavior: "instant" as ScrollBehavior }));
    await settle(page);
    await expectReflow(page, "footer");
  });

  test("every lab chapter", async ({ page }) => {
    await open(page);
    for (const lab of LAB) {
      await openChapter(page, lab.slug);
      await expectReflow(page, lab.slug);
    }
  });

  test("publications: every filter, then the whole list with every paper and Cite panel open", async ({ page }) => {
    for (const { value } of SHOW) {
      await open(page, `/?show=${value}#publications`);
      await expectReflow(page, `?show=${value}`);
    }
    await open(page, "/#publications");
    await instantScroll(page);
    await openWholeList(page);
    await settle(page);
    await expectReflow(page, "every paper and Cite panel open");
  });

  test("the 404 page", async ({ page, guard }) => {
    guard.allow(/(http 404 GET|status of 404).*\/no-such-page/);
    await page.goto("/no-such-page");
    await settle(page);
    await expectReflow(page, "404");
  });
});

/* ------------------------------------------------------------------------------------------------
   Text spacing (WCAG 1.4.12). The override needs a <style>, which the site's CSP forbids, so these
   pages bypass the CSP: nothing else about them changes.
------------------------------------------------------------------------------------------------ */

const TEXT_SPACING = `
  *, *::before, *::after { line-height: 1.5 !important; letter-spacing: 0.12em !important; word-spacing: 0.16em !important; }
  p { margin-bottom: 2em !important; }
`;

/** Text that leaves its control, is cut by an overflow box, is truncated with an ellipsis, or collides with a sibling control. */
async function spacingProblems(page: Page, scope: string) {
  return page.evaluate((scope) => {
    const problems: string[] = [];
    const root = document.querySelector(scope) ?? document.body;
    const describe = (el: Element) => {
      const name = (el.getAttribute("aria-label") ?? el.textContent ?? "").replace(/\s+/g, " ").trim().slice(0, 36);
      return `${el.tagName.toLowerCase()}${el.id ? `#${el.id}` : ""} "${name}"`;
    };
    const srOnly = (el: Element) => {
      for (let n: Element | null = el; n; n = n.parentElement) {
        const r = n.getBoundingClientRect();
        if (r.width <= 1 && r.height <= 1 && getComputedStyle(n).overflow !== "visible") return true;
      }
      return false;
    };
    const controls = Array.from(root.querySelectorAll<HTMLElement>('a[href], button, summary, [role="radio"], [data-anchor]'));
    const controlOf = (el: Element) => el.closest<HTMLElement>('a[href], button, summary, [role="radio"], [data-anchor]');
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      const el = node.parentElement;
      if (!el || !node.textContent?.trim()) continue;
      if (!el.checkVisibility({ opacityProperty: true, visibilityProperty: true })) continue;
      if (srOnly(el) || el.closest("[inert], script, style, noscript")) continue;
      const range = document.createRange();
      range.selectNodeContents(node);
      const rects = Array.from(range.getClientRects()).filter((r) => r.width > 0.5 && r.height > 0.5);
      if (!rects.length) continue;
      const control = controlOf(el);
      if (control && !control.hasAttribute("data-anchor")) {
        const box = control.getBoundingClientRect();
        const out = rects.find((r) => r.left < box.left - 1 || r.right > box.right + 1 || r.top < box.top - 2 || r.bottom > box.bottom + 2);
        if (out) problems.push(`text leaves its control: ${describe(control)} (text ${Math.round(out.left)}–${Math.round(out.right)} × ${Math.round(out.top)}–${Math.round(out.bottom)}, control ${Math.round(box.left)}–${Math.round(box.right)} × ${Math.round(box.top)}–${Math.round(box.bottom)})`);
      }
      for (let a: HTMLElement | null = el; a && a !== document.documentElement; a = a.parentElement) {
        const cs = getComputedStyle(a);
        const clipX = cs.overflowX === "hidden" || cs.overflowX === "clip";
        const clipY = cs.overflowY === "hidden" || cs.overflowY === "clip";
        if (!clipX && !clipY) continue;
        const b = a.getBoundingClientRect();
        const left = b.left + a.clientLeft;
        const top = b.top + a.clientTop;
        const cut = rects.find(
          (r) => (clipX && (r.left < left - 1 || r.right > left + a.clientWidth + 1)) || (clipY && (r.top < top - 1 || r.bottom > top + a.clientHeight + 1)),
        );
        if (cut) {
          problems.push(`text cut off by an overflow box: ${describe(el)} inside ${describe(a)}`);
          break;
        }
      }
      const cs = getComputedStyle(el);
      if (cs.textOverflow === "ellipsis" && el.scrollWidth > el.clientWidth + 1) problems.push(`text truncated with an ellipsis: ${describe(el)}`);
    }
    // Controls in the same row or group must not overlap. A control scrolled out of view inside a scrolling box
    // (the publication list) isn't drawn where its box would be, so it can't overlap anything there.
    const scrolledAway = (el: Element) => {
      const r = el.getBoundingClientRect();
      for (let a = el.parentElement; a && a !== document.documentElement; a = a.parentElement) {
        const cs = getComputedStyle(a);
        if (!/(auto|scroll)/.test(cs.overflowX + cs.overflowY)) continue;
        const b = a.getBoundingClientRect();
        if (r.bottom <= b.top || r.top >= b.bottom || r.right <= b.left || r.left >= b.right) return true;
      }
      return false;
    };
    const visible = controls.filter(
      (c) => c.checkVisibility({ opacityProperty: true, visibilityProperty: true }) && !c.closest("[inert]") && !c.hasAttribute("data-anchor") && !scrolledAway(c),
    );
    for (let i = 0; i < visible.length; i++) {
      for (let j = i + 1; j < visible.length; j++) {
        const a = visible[i];
        const b = visible[j];
        if (a.contains(b) || b.contains(a)) continue;
        const ra = a.getBoundingClientRect();
        const rb = b.getBoundingClientRect();
        const w = Math.min(ra.right, rb.right) - Math.max(ra.left, rb.left);
        const h = Math.min(ra.bottom, rb.bottom) - Math.max(ra.top, rb.top);
        if (w > 1 && h > 1) problems.push(`controls overlap: ${describe(a)} and ${describe(b)} (${Math.round(w)}×${Math.round(h)} px)`);
      }
    }
    return [...new Set(problems)];
  }, scope);
}

for (const viewport of VIEWPORTS) {
  test.describe(`Text spacing (1.4.12) at ${viewport.width}×${viewport.height}`, () => {
    test.use({ viewport, bypassCSP: true });

    test("lab: every chapter's controls, readouts, caption, and labels", async ({ page }, testInfo) => {
      await open(page);
      await page.addStyleTag({ content: TEXT_SPACING });
      await settle(page);
      const all: Finding = {};
      all.overview = await spacingProblems(page, "#top");
      for (const lab of LAB) {
        await openChapter(page, lab.slug);
        await page.waitForTimeout(300);
        all[lab.slug] = await spacingProblems(page, "#top");
      }
      await page.screenshot({ path: testInfo.outputPath(`text-spacing-lab-${viewport.width}.png`) });
      await attachJson(testInfo, "text-spacing-lab.json", all);
      for (const [state, problems] of Object.entries(all)) expect.soft(problems, `text spacing in the lab, ${state}`).toEqual([]);
    });

    test("below the lab: filter, chips, links, Cite panel, copy buttons", async ({ page }, testInfo) => {
      await open(page, "/#publications");
      await page.addStyleTag({ content: TEXT_SPACING });
      await openFirstPaper(page);
      await showWholeList(page);
      await settle(page);
      const all: Finding = {};
      const scopes = ["nav[aria-label='Sections']", ...(await pageSectionIds(page)).map((id) => `#${id}`), "body > footer"];
      for (const scope of scopes) all[scope] = await spacingProblems(page, scope);
      await attachJson(testInfo, "text-spacing-sections.json", all);
      for (const [scope, problems] of Object.entries(all)) expect.soft(problems, `text spacing in ${scope}`).toEqual([]);
    });
  });
}

/* ------------------------------------------------------------------------------------------------
   Target size (WCAG 2.5.8): at least 24×24, or the spacing or inline exception. Plus a report of
   everything under 44 px on a touch profile (the plan's phone standard; not a failure).
------------------------------------------------------------------------------------------------ */

async function targets(page: Page) {
  return page.evaluate(() => {
    const sel = 'a[href], button:not([disabled]), summary, [role="radio"], [role="button"], input, select, textarea, [tabindex]:not([tabindex="-1"])';
    // A target scrolled out of view inside a scrolling box (the publication list) isn't where its box is; it's
    // measured when scrolled into view instead (the list is walked with "Show all" in the sections state).
    const scrolledAway = (el: Element) => {
      const r = el.getBoundingClientRect();
      for (let a = el.parentElement; a && a !== document.documentElement; a = a.parentElement) {
        const cs = getComputedStyle(a);
        if (!/(auto|scroll)/.test(cs.overflowX + cs.overflowY)) continue;
        const b = a.getBoundingClientRect();
        if (r.bottom <= b.top || r.top >= b.bottom || r.right <= b.left || r.left >= b.right) return true;
      }
      return false;
    };
    const items = Array.from(document.querySelectorAll<HTMLElement>(sel)).filter(
      (el) =>
        el.checkVisibility({ opacityProperty: true, visibilityProperty: true }) &&
        !el.closest("[inert], .sr-only, [aria-hidden='true']") &&
        el.getBoundingClientRect().width > 1 &&
        !scrolledAway(el),
    );
    const rects = items.map((el) => el.getBoundingClientRect());
    const undersized = rects.map((r) => r.width < 24 || r.height < 24);
    const centre = (r: DOMRect) => [r.left + r.width / 2, r.top + r.height / 2] as const;
    return items.map((el, i) => {
      const r = rects[i];
      const name = (el.getAttribute("aria-label") ?? el.textContent ?? "").replace(/\s+/g, " ").trim().slice(0, 40);
      const small = undersized[i];
      // Inline: a link inside a sentence, its height set by the line height of the text around it.
      const block = el.parentElement;
      const inline =
        getComputedStyle(el).display === "inline" &&
        !!block &&
        (block.textContent ?? "").replace(/\s+/g, " ").trim().length > (el.textContent ?? "").replace(/\s+/g, " ").trim().length + 2;
      // Spacing: a 24 px circle on the target's centre touches no other target, nor the circle of another
      // undersized target.
      const [cx, cy] = centre(r);
      const spaced = rects.every((o, j) => {
        if (j === i) return true;
        const dx = Math.max(o.left - cx, 0, cx - o.right);
        const dy = Math.max(o.top - cy, 0, cy - o.bottom);
        if (Math.hypot(dx, dy) < 12) return false;
        const [ox, oy] = centre(o);
        return !undersized[j] || Math.hypot(ox - cx, oy - cy) >= 24;
      });
      const where = el.closest("section, nav, footer, header, main");
      return {
        name,
        tag: el.tagName.toLowerCase(),
        role: el.getAttribute("role") ?? "",
        where: where ? `${where.tagName.toLowerCase()}${where.id ? `#${where.id}` : where.getAttribute("aria-label") ? `[${where.getAttribute("aria-label")}]` : ""}` : "",
        width: Math.round(r.width * 10) / 10,
        height: Math.round(r.height * 10) / 10,
        small,
        inline,
        spaced,
      };
    });
  });
}

test.describe("Target size", () => {
  test("2.5.8: every target is at least 24×24 CSS px (or spaced, or inline) at 1440 and 390, lab and sections", async ({ page }, testInfo) => {
    const failures: string[] = [];
    const report: Finding = {};
    for (const viewport of VIEWPORTS) {
      await page.setViewportSize(viewport);
      await open(page);
      await instantScroll(page);
      const states: Array<[string, () => Promise<void>]> = [
        ["overview", async () => {}],
        ...LAB.map((lab) => [lab.name, () => openChapter(page, lab.slug)] as [string, () => Promise<void>]),
        [
          "sections",
          async () => {
            await openFirstPaper(page);
            await showWholeList(page);
            await scrollElementTopTo(page, "publications");
            await settle(page);
          },
        ],
      ];
      for (const [state, enter] of states) {
        await enter();
        const list = await targets(page);
        report[`${viewport.width}-${state}`] = list.filter((t) => t.small);
        for (const t of list.filter((t) => t.small && !t.inline && !t.spaced)) {
          failures.push(`${viewport.width}px, ${state}: ${t.tag}${t.role ? `[role=${t.role}]` : ""} "${t.name}" in ${t.where} is ${t.width}×${t.height}`);
        }
      }
    }
    await attachJson(testInfo, "targets-under-24.json", report);
    expect([...new Set(failures)], "targets under 24×24 without spacing").toEqual([]);
  });

  test.describe("touch profile", () => {
    test.use({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true });

    test("report: targets under 44×44 on a coarse pointer (the plan's phone standard; informational)", async ({ page }, testInfo) => {
      await open(page);
      expect(await page.evaluate(() => matchMedia("(pointer: coarse)").matches), "coarse pointer emulated").toBe(true);
      const rows: string[] = [];
      const seen = new Set<string>();
      const collect = async (state: string) => {
        for (const t of await targets(page)) {
          if (t.width >= 44 && t.height >= 44) continue;
          const key = `${t.where}|${t.name}|${t.width}|${t.height}`;
          if (seen.has(key)) continue;
          seen.add(key);
          rows.push(`${state.padEnd(15)} ${`${t.width}×${t.height}`.padEnd(12)} ${t.where.padEnd(24)} ${t.tag}${t.role ? `[${t.role}]` : ""} "${t.name}"${t.inline ? " (inline)" : ""}`);
        }
      };
      await collect("overview");
      for (const lab of LAB) {
        await openChapter(page, lab.slug);
        await collect(lab.name);
      }
      await instantScroll(page);
      await openFirstPaper(page);
      await showWholeList(page);
      await scrollElementTopTo(page, "publications");
      await settle(page);
      await collect("sections");
      await testInfo.attach("targets-under-44-touch.txt", { body: rows.join("\n") || "none", contentType: "text/plain" });
      testInfo.annotations.push({ type: "targets-under-44", description: `${rows.length} targets under 44×44 on the touch profile (see attachment)` });
      expect(rows.length).toBeGreaterThanOrEqual(0);
    });
  });
});

/* ------------------------------------------------------------------------------------------------
   Focus: every Tab stop shows a visible indicator, is on screen, and isn't hidden under the section
   bar (2.4.7, 2.4.11). Forced colors (Windows High Contrast) drops box-shadow rings, so the same walk
   runs there too.
------------------------------------------------------------------------------------------------ */

interface Stop {
  key: string;
  label: string;
  indicator: string;
  problem: string | null;
  rect: { x: number; y: number; width: number; height: number };
}

/** Reads the focused element's indicator by comparing its focused and unfocused styles. */
async function inspectFocus(page: Page): Promise<Stop | null> {
  return page.evaluate(() => {
    const el = document.activeElement as HTMLElement | null;
    if (!el || el === document.body || el === document.documentElement) return null;
    const pick = (cs: CSSStyleDeclaration) => ({
      outline: `${cs.outlineStyle} ${cs.outlineWidth} ${cs.outlineColor}`,
      outlineStyle: cs.outlineStyle,
      outlineWidth: Number.parseFloat(cs.outlineWidth) || 0,
      outlineColor: cs.outlineColor,
      shadow: cs.boxShadow,
      border: cs.borderColor,
      borderWidth: ["Top", "Right", "Bottom", "Left"].reduce((sum, side) => sum + (Number.parseFloat(cs.getPropertyValue(`border-${side.toLowerCase()}-width`)) || 0), 0),
      background: cs.backgroundColor,
      decoration: `${cs.textDecorationLine} ${cs.textDecorationColor}`,
    });
    const transparent = (c: string) => /rgba\([^)]*,\s*0\)$/.test(c) || c === "transparent";
    const shadowVisible = (s: string) =>
      s !== "none" &&
      s
        .split(/,(?![^(]*\))/)
        .some((part) => {
          const color = part.match(/rgba?\([^)]*\)/)?.[0] ?? "";
          const nums = part.replace(/rgba?\([^)]*\)/, "").trim().split(/\s+/).map((n) => Number.parseFloat(n));
          const [, , blur = 0, spread = 0] = nums;
          return !!color && !transparent(color) && (spread > 0 || blur > 0);
        });
    const focused = pick(getComputedStyle(el));
    el.blur();
    const rest = pick(getComputedStyle(el));
    el.focus({ preventScroll: true });
    const cues: string[] = [];
    if (focused.outlineStyle !== "none" && focused.outlineWidth >= 1 && !transparent(focused.outlineColor)) cues.push(`outline ${focused.outline}`);
    if (focused.shadow !== rest.shadow && shadowVisible(focused.shadow)) cues.push("ring (box-shadow)");
    // A border colour change only shows if there is a border to see.
    if (focused.border !== rest.border && focused.borderWidth >= 1) cues.push("border colour");
    if (focused.background !== rest.background) cues.push("background");
    if (focused.decoration !== rest.decoration && !focused.decoration.startsWith("none")) cues.push("underline");

    const r = el.getBoundingClientRect();
    let opacity = 1;
    for (let n: Element | null = el; n; n = n.parentElement) opacity *= Number.parseFloat(getComputedStyle(n).opacity);
    const bar = document.querySelector('nav[aria-label="Sections"]');
    const inBar = !!bar && bar.contains(el);
    const points = [
      [r.left + r.width / 2, r.top + r.height / 2],
      [r.left + 2, r.top + 2],
      [r.right - 2, r.top + 2],
      [r.left + 2, r.bottom - 2],
      [r.right - 2, r.bottom - 2],
    ].filter(([x, y]) => x >= 0 && y >= 0 && x < innerWidth && y < innerHeight);
    const covered =
      points.length > 0 &&
      points.every(([x, y]) => {
        const top = document.elementFromPoint(x, y);
        return !!top && !el.contains(top) && !top.contains(el) && !!bar && bar.contains(top) && !inBar;
      });
    let problem: string | null = null;
    if (!cues.length) problem = "no visible focus indicator";
    else if (r.width < 1 || r.height < 1) problem = "zero size";
    else if (opacity < 0.5) problem = `nearly transparent (opacity ${opacity.toFixed(2)})`;
    else if (r.bottom <= 0 || r.top >= innerHeight || r.right <= 0 || r.left >= innerWidth) problem = "off screen";
    else if (covered) problem = "hidden under the section bar";
    const name = (el.getAttribute("aria-label") ?? el.textContent ?? "").replace(/\s+/g, " ").trim().slice(0, 40);
    const path: string[] = [];
    for (let n: Element | null = el; n && path.length < 3; n = n.parentElement) path.push(n.tagName.toLowerCase() + (n.id ? `#${n.id}` : ""));
    return {
      key: `${path.join("<")}|${name}|${Math.round(r.top + scrollY)}|${Math.round(r.left)}`,
      label: `${path.reverse().join(" > ")} "${name}"`,
      indicator: cues.join(", ") || "none",
      problem,
      rect: { x: r.x, y: r.y, width: r.width, height: r.height },
    };
  });
}

async function walkFocus(page: Page, testInfo: TestInfo, tag: string) {
  // Focus scrolling follows the page's smooth scroll-behavior; measure where each stop lands, not mid-glide.
  await instantScroll(page);
  const stops: Stop[] = [];
  const seen = new Set<string>();
  const shots = path.join(testInfo.outputDir, `focus-${tag}`);
  for (let i = 0; i < 400; i++) {
    await page.keyboard.press("Tab");
    await page.evaluate(() => new Promise<void>((r) => requestAnimationFrame(() => requestAnimationFrame(() => r()))));
    const stop = await inspectFocus(page);
    if (!stop || seen.has(stop.key)) break;
    seen.add(stop.key);
    stops.push(stop);
    if (stop.problem) {
      fs.mkdirSync(shots, { recursive: true });
      const pad = 16;
      const vp = page.viewportSize()!;
      const x = Math.max(0, stop.rect.x - pad);
      const y = Math.max(0, stop.rect.y - pad);
      const clip = { x, y, width: Math.max(1, Math.min(vp.width - x, stop.rect.width + pad * 2)), height: Math.max(1, Math.min(vp.height - y, stop.rect.height + pad * 2)) };
      if (clip.width > 1 && clip.height > 1 && y < vp.height && x < vp.width) {
        await page.screenshot({ path: path.join(shots, `${String(stops.length).padStart(3, "0")}.png`), clip }).catch(() => {});
      }
    }
  }
  await testInfo.attach(`tab-order-${tag}.txt`, {
    body: stops.map((s, i) => `${String(i + 1).padStart(3)}  ${s.problem ? `FAIL (${s.problem})` : "ok"}  ${s.label}  [${s.indicator}]`).join("\n"),
    contentType: "text/plain",
  });
  return stops;
}

for (const viewport of VIEWPORTS) {
  test.describe(`Focus at ${viewport.width}×${viewport.height}`, () => {
    test.use({ viewport });

    test("every Tab stop shows a focus indicator, on screen and clear of the section bar", async ({ page }, testInfo) => {
      test.setTimeout(180_000);
      await open(page);
      const stops = await walkFocus(page, testInfo, `${viewport.width}`);
      expect(stops.length, "Tab stops reached").toBeGreaterThan(40);
      expect(stops[0].label, "first Tab stop").toContain("Skip the lab");
      expect(stops.filter((s) => s.problem).map((s) => `${s.label}: ${s.problem}`)).toEqual([]);
    });
  });
}

test.describe("Forced colors", () => {
  test.use({ viewport: { width: 1440, height: 900 }, forcedColors: "active" });

  test("every Tab stop keeps a visible focus indicator under forced colors", async ({ page }, testInfo) => {
    test.setTimeout(180_000);
    await open(page);
    expect(await page.evaluate(() => matchMedia("(forced-colors: active)").matches)).toBe(true);
    const stops = await walkFocus(page, testInfo, "forced-colors");
    expect(stops.length).toBeGreaterThan(40);
    const failing = stops.filter((s) => s.problem);
    expect(failing.map((s) => `${s.label}: ${s.problem}`), `${failing.length} of ${stops.length} Tab stops`).toEqual([]);
  });
});

/**
 * Under forced colors, backgrounds and shadows become system colours, so a selection shown only by a
 * filled background disappears. Compares the padding pixels (no text) of the selected control and an
 * unselected neighbour: if they match, a reader can't tell which one is selected.
 */
async function selectionVisible(page: Page, selected: Locator, other: Locator) {
  const sample = async (loc: Locator) => {
    await loc.scrollIntoViewIfNeeded();
    const box = (await loc.boundingBox())!;
    const png = await page.screenshot({ clip: box, animations: "disabled" });
    const { data, info } = await sharp(png).raw().toBuffer({ resolveWithObject: true });
    const at = (x: number, y: number) => {
      const i = (Math.min(info.height - 1, Math.max(0, Math.round(y))) * info.width + Math.min(info.width - 1, Math.max(0, Math.round(x)))) * info.channels;
      return [data[i], data[i + 1], data[i + 2]];
    };
    const { width: w, height: h } = info;
    return [at(5, h / 2), at(w - 6, h / 2), at(w / 2, 3), at(w / 2, h - 4), at(8, 5), at(w - 9, h - 6)];
  };
  const a = await sample(selected);
  const b = await sample(other);
  const diff = Math.max(...a.map((p, i) => Math.max(...p.map((v, c) => Math.abs(v - b[i][c])))));
  return diff;
}

/** Every selection the page shows by fill: the open chapter, the lab's checked options, the Show filter. */
async function selectionContrasts(page: Page) {
  await open(page);
  await instantScroll(page);
  const results: Array<{ what: string; diff: number }> = [];
  const check = async (what: string, selected: Locator, other: Locator) => results.push({ what, diff: await selectionVisible(page, selected, other) });
  await openChapter(page, "lab-photoacoustics");
  await check("open chapter button (Photoacoustics) vs Design", page.locator("#lab-photoacoustics"), page.locator("#lab-design"));
  for (const name of ["Show", "Skin tone", "Beamformer"]) {
    const group = page.locator("#top").getByRole("radiogroup", { name });
    await check(`lab "${name}" checked option`, group.getByRole("radio", { checked: true }), group.getByRole("radio", { checked: false }).first());
  }
  for (const name of ["Show", "Sort"]) {
    const group = page.locator("#publications").getByRole("radiogroup", { name });
    await check(`publications ${name} checked option`, group.getByRole("radio", { checked: true }), group.getByRole("radio", { checked: false }).first());
  }
  return results;
}

test.describe("Forced colors: selection state", () => {
  test.use({ viewport: { width: 390, height: 844 }, forcedColors: "active", reducedMotion: "reduce" });

  test("the open chapter, every checked lab option, and the checked Show and Sort options stay distinguishable", async ({ page }) => {
    const results = await selectionContrasts(page);
    const indistinct = results.filter((r) => r.diff < 24).map((r) => `${r.what} (largest padding-pixel difference ${r.diff}/255)`);
    expect(indistinct, "selected and unselected look the same under forced colors").toEqual([]);
  });
});

test.describe("Forced colors: selection state (control, normal colours)", () => {
  test.use({ viewport: { width: 390, height: 844 }, forcedColors: "none", reducedMotion: "reduce" });

  test("the same comparison tells selected from unselected in normal colours", async ({ page }) => {
    const results = await selectionContrasts(page);
    for (const r of results) expect(r.diff, r.what).toBeGreaterThanOrEqual(24);
  });
});

for (const viewport of VIEWPORTS) {
  test.describe(`Forced-colors screenshots at ${viewport.width}×${viewport.height}`, () => {
    test.use({ viewport, forcedColors: "active", reducedMotion: "reduce" });

    test("above the fold, a chapter open, a focused control, and the full page", async ({ page }, testInfo) => {
      await open(page);
      await instantScroll(page);
      const dir = path.join(testInfo.project.outputDir, "forced-colors");
      fs.mkdirSync(dir, { recursive: true });
      const shot = async (name: string, fullPage = false) => {
        const file = path.join(dir, `forced-colors-${viewport.width}-${name}.png`);
        await page.screenshot({ path: file, fullPage, animations: "disabled" });
        await testInfo.attach(name, { path: file, contentType: "image/png" });
      };
      await shot("fold");
      await openChapter(page, "lab-photoacoustics");
      await shot("chapter-photoacoustics");
      await page.locator("#lab-ultrasound").focus();
      await page.keyboard.press("Shift+Tab");
      await page.keyboard.press("Tab");
      await shot("focused-chapter-button");
      await page.locator("#lab-photoacoustics").click();
      await settle(page);
      await shot("full", true);
      await scrollElementTopTo(page, "publications");
      await settle(page);
      await shot("publications-with-bar");
      // A sanity check that forced colors took effect: the page background is a system colour.
      expect(await effectiveOpacity(page.locator("body"))).toBe(1);
    });
  });
}

/*
  The paper theme (design-system/MASTER.md, "Two themes"): the same gates in light. The palette was computed
  against WCAG 2.2 before it shipped; these tests hold the rendered page to it — axe on the busiest states,
  and the full focus walk, since every focus ring changes color with the theme.
*/
async function onPaper(page: Page) {
  await page.addInitScript(() => {
    try {
      localStorage.setItem("theme", "light");
    } catch {
      /* Then the page stays dark and these tests still pass axe, but prove nothing new. */
    }
  });
}

for (const viewport of VIEWPORTS) {
  test.describe(`Paper theme: axe at ${viewport.width}×${viewport.height}`, () => {
    test.use({ viewport });

    test("home, lab overview, on paper", async ({ page }, testInfo) => {
      await onPaper(page);
      await open(page);
      await expect(page.locator("html")).toHaveAttribute("data-theme", "light");
      await axe(page, testInfo, `paper-${viewport.width}-overview`);
    });

    test("a paper open with its Cite panel, the list by most cited, on paper", async ({ page }, testInfo) => {
      await onPaper(page);
      await open(page, "/?sort=cited#publications");
      await openFirstPaper(page);
      await axe(page, testInfo, `paper-${viewport.width}-cite-cited`);
    });

    test("the 404 page, on paper", async ({ page, guard }, testInfo) => {
      guard.allow(/(http 404 GET|status of 404).*\/no-such-page/);
      await onPaper(page);
      await page.goto("/no-such-page/");
      await axe(page, testInfo, `paper-${viewport.width}-404`);
    });
  });
}

test.describe("Paper theme: focus", () => {
  test.use({ viewport: { width: 1440, height: 900 } });

  test("every Tab stop shows a focus indicator on paper", async ({ page }, testInfo) => {
    test.setTimeout(180_000);
    await onPaper(page);
    await open(page);
    await expect(page.locator("html")).toHaveAttribute("data-theme", "light");
    const stops = await walkFocus(page, testInfo, "paper-1440");
    expect(stops.length, "Tab stops reached").toBeGreaterThan(40);
    expect(stops.filter((s) => s.problem).map((s) => `${s.label}: ${s.problem}`)).toEqual([]);
  });
});
