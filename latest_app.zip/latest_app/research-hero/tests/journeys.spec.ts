import fs from "node:fs";
import path from "node:path";
import { INSTALL_HINT, browserInstalled, expect, test } from "./support/fixtures";
import {
  HEADLINE,
  LAB,
  SECTIONS,
  SHOW,
  TOTAL_PAPERS,
  bibKey,
  describeFocus,
  effectiveOpacity,
  expectedOrder,
  expectedShown,
  instantScroll,
  normalizeSpace,
  openPaper,
  pageSectionIds,
  paperIndex,
  papersShownByFilter,
  parseBib,
  placement,
  prepareClipboard,
  readClipboard,
  rowOrder,
  scrollElementTopTo,
  sectionBar,
  settle,
  stubExternalSites,
  tabKey,
  waitForApp,
  waitForLab,
  waitForScrollToSettle,
  type PaperIndex,
  type ShowValue,
} from "./support/helpers";
import type { Page } from "@playwright/test";

/** The fields of src/content/scholar.json these tests read. */
interface ScholarSnapshotFile {
  profile: { url: string };
  totals: { citations: number; hIndex: number; i10Index: number };
  recent: { since: number; citations: number };
  byYear: Array<{ year: number; citations: number }>;
  articles: Array<{ pub: string | null; citedBy: number; citedByUrl?: string }>;
}

/*
  Journeys (D-engineering §7; PLAN §3.2 and §6.6): the page from every way in, and every way back.
  Runs in Chromium, WebKit, and Firefox; engines that aren't installed are skipped, not failed.
*/

test.skip(({ browserName }) => !browserInstalled(browserName), INSTALL_HINT);

let papers: PaperIndex;
test.beforeAll(async ({ playwright }, workerInfo) => {
  const request = await playwright.request.newContext({ baseURL: workerInfo.project.use.baseURL });
  papers = await paperIndex(request);
  await request.dispose();
});

/** The publications filter (the lab's photoacoustics chapter has its own "Show" group). */
const showGroup = (page: Page) => page.locator("#publications").getByRole("radiogroup", { name: "Show" });

/** The filter as a reader meets it: the list, the checked option, the rows, and the address. */
async function expectFilter(page: Page, value: ShowValue, { soft = false } = {}) {
  const label = SHOW.find((s) => s.value === value)!.label;
  const group = showGroup(page);
  const check = soft ? expect.soft : expect;
  await check(page.locator("#publication-list"), "data-show on the list").toHaveAttribute("data-show", value);
  await check(group.getByRole("radio", { checked: true }), "the checked Show option").toHaveAccessibleName(new RegExp(`^${label}\\b`));
  const shown = await papersShownByFilter(page);
  check(shown.sort(), `papers shown for ${value}`).toEqual([...expectedShown(papers, value)].sort());
}

/** The element is in the viewport and not under the section bar. */
async function expectLanded(page: Page, selector: string) {
  const target = page.locator(selector);
  await expect(target).toBeVisible();
  const p = await placement(target);
  expect(p.top, `${selector} top edge is below the section bar (bar bottom ${p.barBottom}px)`).toBeGreaterThanOrEqual(p.barBottom - 1);
  expect(p.top, `${selector} top edge is inside the viewport (${p.viewport}px tall)`).toBeLessThan(p.viewport * 0.5);
}

test.describe("Direct entry and reload", () => {
  test("the home page answers 200 with its security headers, name, headline, sections, and 15 papers", async ({ page }) => {
    const response = await page.goto("/");
    expect(response?.status()).toBe(200);
    const headers = response!.headers();
    expect(headers["content-security-policy"]).toContain("default-src 'self'");
    expect(headers["x-content-type-options"]).toBe("nosniff");
    await waitForApp(page);

    await expect(page).toHaveTitle(/Madhavi Tripathi/);
    await expect(page.locator("#top header a").first()).toContainText("Madhavi Tripathi");
    await expect(page.getByRole("heading", { level: 1, name: HEADLINE })).toBeVisible();
    await expect(page.getByRole("main")).toHaveCount(1);
    const nav = page.getByRole("navigation", { name: "Primary" });
    await expect(nav.getByRole("link")).toHaveText(SECTIONS.map((s) => s.label));
    for (const s of SECTIONS) {
      await expect(page.locator(`section#${s.id}`)).toBeAttached();
      await expect(page.locator(`#${s.id}-title`)).toHaveText(s.label);
    }
    await expect(page.locator('li[id^="pub-"]')).toHaveCount(TOTAL_PAPERS);
    expect(papers.all).toHaveLength(TOTAL_PAPERS);
  });

  test("reload keeps the address, the filter, and the place on the page", async ({ page }) => {
    await page.goto("/?show=delivery#publications");
    await waitForApp(page);
    await expectFilter(page, "delivery");
    await page.reload();
    await waitForApp(page);
    await expect(page).toHaveURL(/\/\?show=delivery#publications$/);
    await expectFilter(page, "delivery");

    await page.goto("/#contact");
    await waitForApp(page);
    await waitForScrollToSettle(page);
    await page.reload();
    await waitForApp(page);
    await waitForScrollToSettle(page);
    await expectLanded(page, "#contact");
  });
});

test.describe("Show filter (?show=)", () => {
  for (const { value } of SHOW) {
    test(`?show=${value} on load shows exactly its papers and checks its option`, async ({ page }) => {
      await page.goto(`/?show=${value}`);
      await waitForApp(page);
      await expectFilter(page, value);
    });
  }

  test("an unknown ?show= value falls back to all", async ({ page }) => {
    await page.goto("/?show=bogus");
    await waitForApp(page);
    await expectFilter(page, "all");
  });

  test('choosing an option filters the list, writes ?show= to the address, and announces "N of 15 publications."', async ({
    page,
  }) => {
    await page.goto("/#publications");
    await waitForApp(page);
    const group = showGroup(page);
    const status = page.locator('#publications p[role="status"]');
    for (const value of ["delivery", "imaging", "first-author", "all"] as const) {
      const label = SHOW.find((s) => s.value === value)!.label;
      const n = expectedShown(papers, value).length;
      await group.getByRole("radio", { name: new RegExp(`^${label}\\b`) }).click();
      // The words match the list's header ("6 of 15 publications"); the count is the requirement.
      await expect(status, `live region after choosing ${label}`).toHaveText(
        value === "all" ? new RegExp(`^${TOTAL_PAPERS} publications\\.$`) : new RegExp(`^${n} of ${TOTAL_PAPERS} publications\\.$`),
      );
      const url = new URL(page.url());
      expect(url.searchParams.get("show"), `address after choosing ${label}`).toBe(value === "all" ? null : value);
      await expectFilter(page, value);
    }
  });

  test("the Show control is a keyboard radio group: arrows, Home, and End move the choice and the focus", async ({ page }) => {
    await page.goto("/#publications");
    await waitForApp(page);
    const group = showGroup(page);
    await group.getByRole("radio", { checked: true }).focus();
    const expectChecked = async (value: ShowValue) => {
      const label = SHOW.find((s) => s.value === value)!.label;
      const radio = group.getByRole("radio", { name: new RegExp(`^${label}\\b`) });
      await expect(radio).toBeFocused();
      await expect(radio).toHaveAttribute("aria-checked", "true");
      await expect(radio).toHaveAttribute("tabindex", "0");
      await expect(page.locator("#publication-list")).toHaveAttribute("data-show", value);
    };
    await page.keyboard.press("ArrowRight");
    await expectChecked("delivery");
    await page.keyboard.press("ArrowRight");
    await expectChecked("imaging");
    await page.keyboard.press("End");
    await expectChecked("first-author");
    await page.keyboard.press("Home");
    await expectChecked("all");
    await page.keyboard.press("ArrowLeft");
    await expectChecked("first-author");
  });

  test("a filter in the address survives leaving the site and coming Back", async ({ page, context }) => {
    await stubExternalSites(context);
    await page.goto("/?show=imaging#publications");
    await waitForApp(page);
    await expectFilter(page, "imaging");
    const paper = papers.byGroup.imaging[0];
    await page.locator(`#pub-${paper} h3 a`).click();
    await page.waitForURL(/doi\.org|\/\/[^/]*(google|ssrn)/);
    await page.goBack();
    await waitForApp(page);
    await expect(page).toHaveURL(/\/\?show=imaging#publications$/);
    await expectFilter(page, "imaging");
    await page.goForward();
    await expect(page).not.toHaveURL(/localhost/);
    await page.goBack();
    await waitForApp(page);
    await expectFilter(page, "imaging");
  });

  test("a filter chosen on the page is in the address, so Back returns to it", async ({ page, context }) => {
    await stubExternalSites(context);
    await page.goto("/#publications");
    await waitForApp(page);
    await showGroup(page).getByRole("radio", { name: /^First author\b/ }).click();
    await expect(page).toHaveURL(/\?show=first-author/);
    await expectFilter(page, "first-author");
    await page.locator(`#pub-${papers.firstAuthor[0]} h3 a`).click();
    await page.waitForURL((url) => !url.href.startsWith("http://localhost"));
    await page.goBack();
    await waitForApp(page);
    await expectFilter(page, "first-author");
  });
});

test.describe("Sort (?sort=)", () => {
  test('"Most cited" orders the list by Google Scholar counts, writes ?sort=cited, announces it, and survives reload', async ({ page }) => {
    await page.goto("/#publications");
    await waitForApp(page);
    const sort = page.locator("#publications").getByRole("radiogroup", { name: "Sort" });
    await sort.getByRole("radio", { name: "Most cited" }).click();
    await expect(page.locator('#publications p[role="status"]')).toHaveText("Most cited first.");
    expect(new URL(page.url()).searchParams.get("sort")).toBe("cited");
    expect(await rowOrder(page)).toEqual(expectedOrder(papers, "all", "cited"));
    await page.reload();
    await waitForApp(page);
    await expect(sort.getByRole("radio", { checked: true })).toHaveAccessibleName("Most cited");
    expect(await rowOrder(page)).toEqual(expectedOrder(papers, "all", "cited"));
    await sort.getByRole("radio", { name: "Newest" }).click();
    expect(await rowOrder(page)).toEqual(expectedOrder(papers, "all", "newest"));
    expect(new URL(page.url()).searchParams.get("sort")).toBeNull();
  });

  test("the list's header says how many the filter shows", async ({ page }) => {
    await page.goto("/#publications");
    await waitForApp(page);
    const count = page.locator("#publications .pub-panel .panel-head > p");
    await expect(count).toHaveText(`${TOTAL_PAPERS} publications`);
    await showGroup(page).getByRole("radio", { name: /^Imaging\b/ }).click();
    await expect(count).toHaveText(`${expectedShown(papers, "imaging").length} of ${TOTAL_PAPERS} publications`);
  });

  test("a sort and a filter combine, in the address and in the list", async ({ page }) => {
    await page.goto("/?show=first-author&sort=cited#publications");
    await waitForApp(page);
    await expectFilter(page, "first-author");
    expect(await rowOrder(page)).toEqual(expectedOrder(papers, "first-author", "cited"));
  });
});

test.describe("A paper's row", () => {
  test("Summary opens and closes the row in place; the title still goes to the paper", async ({ page }) => {
    await page.goto("/#publications");
    await waitForApp(page);
    const id = papers.all[0];
    const toggle = page.locator(`#pub-${id} .pub-toggle`);
    const panel = page.locator(`#m-${id}`);
    await expect(toggle).toHaveAttribute("aria-expanded", "false");
    await expect(toggle).toHaveAccessibleName(/^Summary \S/);
    await expect(panel).toBeHidden();
    await toggle.click();
    await expect(toggle).toHaveAttribute("aria-expanded", "true");
    await expect(panel).toBeVisible();
    await expect(panel.getByRole("link", { name: /^Paper/ })).toBeVisible();
    await expect(panel.locator("summary", { hasText: "Cite" })).toBeVisible();
    await toggle.click();
    await expect(toggle).toHaveAttribute("aria-expanded", "false");
    await expect(panel).toBeHidden();
    await expect(page.locator(`#pub-${id} h3 a`)).toHaveAttribute("href", /^https:\/\//);
  });

  test("closed rows stay findable: hidden until found, where the browser supports it", async ({ page }) => {
    await page.goto("/#publications");
    await waitForApp(page);
    const supported = await page.evaluate(() => "onbeforematch" in document.body);
    await expect(page.locator('#publication-list .pub-more[hidden="until-found"]')).toHaveCount(supported ? TOTAL_PAPERS : 0);
  });
});

test.describe("Fragments", () => {
  test("a text-fragment link into a closed summary opens that row", async ({ page }) => {
    const id = papers.byGroup.imaging.find((p) => p.includes("gcnr")) ?? papers.byGroup.imaging[0];
    await page.goto("/");
    const phrase = await page.locator(`#m-${id} p`).first().evaluate((p) => p.textContent!.split(" ").slice(2, 6).join(" "));
    await page.goto(`/#:~:text=${encodeURIComponent(phrase)}`);
    await waitForApp(page);
    const supported = await page.evaluate(() => "onbeforematch" in document.body);
    test.skip(!supported, "This browser doesn't support hidden=until-found.");
    await expect(page.locator(`#pub-${id} .pub-toggle`)).toHaveAttribute("aria-expanded", "true");
  });

  for (const fragment of ["%", "pub-100%", "lab-%E2%80"]) {
    test(`a malformed fragment (#${fragment}) leaves the page working`, async ({ page }) => {
      await page.goto(`/#${fragment}`);
      await waitForApp(page);
      await expect(page.getByRole("heading", { level: 1, name: HEADLINE })).toBeVisible();
      await expect(page.locator('li[id^="pub-"]')).toHaveCount(TOTAL_PAPERS);
    });
  }
});

test.describe("The list's length", () => {
  test("on wide screens the list scrolls in its panel until Show the whole list lets it run with the page", async ({ page }) => {
    await page.goto("/#publications");
    await waitForApp(page);
    const list = page.locator("#publication-list");
    const size = () => list.evaluate((el) => ({ scroll: el.scrollHeight, client: el.clientHeight }));
    let s = await size();
    expect(s.scroll, "the list is taller than its panel").toBeGreaterThan(s.client + 1);
    // Every row has links, so the list needs no Tab stop of its own (one would restart Tab from the top of it).
    await expect(list).not.toHaveAttribute("tabindex");
    const whole = page.locator("#publications").getByRole("button", { name: "Show the whole list" });
    await expect(whole).toHaveAttribute("aria-expanded", "false");
    await whole.click();
    await settle(page);
    s = await size();
    expect(s.scroll, "after Show the whole list, nothing scrolls inside the panel").toBeLessThanOrEqual(s.client + 1);
    // Focus moves to the first paper that was out of view.
    await expect(page.locator("#publication-list h3 a:focus")).toHaveCount(1);
    const collapse = page.locator("#publications").getByRole("button", { name: "Collapse the list" });
    await expect(collapse).toHaveAttribute("aria-expanded", "true");
    await collapse.click();
    await settle(page);
    s = await size();
    expect(s.scroll).toBeGreaterThan(s.client + 1);
  });

  test.describe("on a phone", () => {
    test.use({ viewport: { width: 390, height: 844 } });

    test("five rows of what the filter keeps, then Show all for the rest; no button when five or fewer", async ({ page }) => {
      await page.goto("/#publications");
      await waitForApp(page);
      expect(await rowOrder(page)).toEqual(papers.all.slice(0, 5));
      await page.locator("#publications").getByRole("button", { name: `Show all ${TOTAL_PAPERS}` }).click();
      expect(await rowOrder(page)).toEqual(papers.all);
      // Focus moves to the sixth paper, the first one "Show all" revealed.
      await expect(page.locator(`#pub-${papers.all[5]} h3 a`)).toBeFocused();

      const delivery = expectedShown(papers, "delivery");
      expect(delivery.length, "a filter with more than five papers").toBeGreaterThan(5);
      await page.goto("/?show=delivery#publications");
      await waitForApp(page);
      await expect(page.locator("#publication-list")).toHaveAttribute("data-show", "delivery");
      expect(await rowOrder(page)).toEqual(delivery.slice(0, 5));
      // The rest stay findable: hidden until found, where the browser supports it.
      const supported = await page.evaluate(() => "onbeforematch" in document.body);
      if (supported) await expect(page.locator(`#pub-${delivery[5]}`)).toHaveAttribute("hidden", "until-found");
      await page.locator("#publications").getByRole("button", { name: `Show all ${delivery.length}` }).click();
      expect(await rowOrder(page)).toEqual(delivery);

      const imaging = expectedShown(papers, "imaging");
      if (imaging.length <= 5) {
        await page.goto("/?show=imaging#publications");
        await waitForApp(page);
        await expect(page.locator("#publication-list")).toHaveAttribute("data-show", "imaging");
        await expect(page.locator('#publications button[aria-controls="publication-list"]')).toHaveCount(0);
      }
    });

    test("a link to a paper past the first five shows the whole list and lands on it", async ({ page }) => {
      const id = papers.all[papers.all.length - 1];
      await page.goto(`/#pub-${id}`);
      await waitForApp(page);
      await waitForScrollToSettle(page);
      await expect(page.locator(`#pub-${id}`)).toBeVisible();
      await expectLanded(page, `#pub-${id}`);
    });
  });

  test.describe("on a touch tablet", () => {
    test.use({ viewport: { width: 768, height: 1024 }, hasTouch: true });

    test("a touch screen gets five rows and Show all, not a box to scroll with a finger", async ({ page }) => {
      await page.goto("/#publications");
      await waitForApp(page);
      test.skip(!(await page.evaluate(() => matchMedia("(pointer: coarse)").matches)), "This browser reports no coarse pointer under touch emulation.");
      expect(await rowOrder(page)).toEqual(papers.all.slice(0, 5));
      await expect(page.locator("#publications").getByRole("button", { name: `Show all ${TOTAL_PAPERS}` })).toBeVisible();
      const size = await page.locator("#publication-list").evaluate((el) => ({ scroll: el.scrollHeight, client: el.clientHeight }));
      expect(size.scroll, "the list doesn't scroll inside its panel").toBeLessThanOrEqual(size.client + 1);
    });
  });
});

test.describe("Google Scholar readout", () => {
  const snapshot = JSON.parse(fs.readFileSync(path.join(process.cwd(), "src/content/scholar.json"), "utf8")) as ScholarSnapshotFile;

  test("the readout and every row's count match the committed snapshot, and link to Google Scholar", async ({ page }) => {
    await page.goto("/#publications");
    await waitForApp(page);
    const section = page.locator("#publications");
    const { totals, recent } = snapshot;
    // Three tiles, each a term and its figure: the figure's text is the number (the rolling columns are drawing only).
    const tiles = section.locator(".scholar dl");
    await expect(tiles.getByRole("term")).toHaveText(["Citations", "h-index", "i10-index"]);
    await expect(tiles.locator(".tile-figure")).toHaveText([String(totals.citations), String(totals.hIndex), String(totals.i10Index)]);
    // The words keep their figures whole with no-break spaces; the text match treats them as spaces.
    await expect(tiles.getByText(`${recent.citations} since ${recent.since}`)).toBeVisible();
    await expect(tiles.getByText(`${totals.hIndex} papers each cited at least ${totals.hIndex} times`)).toBeVisible();
    await expect(tiles.getByText(`${totals.i10Index} papers each cited at least 10 times`)).toBeVisible();
    // Each index draws the papers ranked by citations against its line, the papers that count drawn bright.
    const ranked = snapshot.articles.map((a) => a.citedBy).sort((a, b) => b - a);
    await expect(tiles.locator('.ranks[data-line] > [data-on]').first()).toBeAttached();
    expect(await tiles.locator(".ranks").first().locator("> [data-on]").count(), "h-index: the papers that count").toBe(totals.hIndex);
    expect(await tiles.locator(".ranks").nth(1).locator("> [data-on]").count(), "i10-index: the papers that count").toBe(ranked.filter((c) => c >= 10).length);
    const years = snapshot.byYear.slice(-12);
    const stems = section.getByRole("list", { name: "Citations per year" }).getByRole("listitem");
    await expect(stems).toHaveCount(years.length);
    for (const [i, y] of years.entries()) {
      await expect(stems.nth(i).locator(".stem-year-full")).toHaveText(String(y.year));
      await expect(stems.nth(i).locator(".stem-value")).toHaveText(new RegExp(`^${y.citations}\\s+citations?\\b`));
    }
    await expect(section.getByRole("link", { name: "Google Scholar profile" })).toHaveAttribute("href", snapshot.profile.url);
    for (const article of snapshot.articles.filter((a) => a.pub)) {
      const cites = page.locator(`#pub-${article.pub} .pub-cites`);
      if (article.citedBy > 0) {
        await expect(cites, `${article.pub}: cited by`).toHaveText(`Cited by ${article.citedBy}`);
        await expect(cites).toHaveAttribute("href", article.citedByUrl!);
      } else {
        await expect(cites, `${article.pub}: no count when Scholar shows none`).toHaveCount(0);
      }
    }
  });

  test("a Research card's link filters the list in place, without reloading the page", async ({ page }) => {
    await page.goto("/#research");
    await waitForApp(page);
    await page.evaluate(() => ((window as Window & { __kept?: number }).__kept = 1));
    await page.locator('#research a[href="/?show=imaging#publications"]').first().click();
    await expect(page).toHaveURL(/\/\?show=imaging#publications$/);
    await expectFilter(page, "imaging");
    expect(await page.evaluate(() => (window as Window & { __kept?: number }).__kept), "the same page, not a reload").toBe(1);
    // Focus follows the reader to the list, and the new count is said.
    await expect(page.locator("#publications-title")).toBeFocused();
    await expect(page.locator('#publications p[role="status"]')).toHaveText(`${expectedShown(papers, "imaging").length} of ${TOTAL_PAPERS} publications.`);
    // Back returns to the whole list.
    await page.goBack();
    await expectFilter(page, "all");
  });
});

test.describe("Deep links to a paper (#pub-{id})", () => {
  test("a link to a paper lands on it, clear of the section bar", async ({ page }) => {
    const id = papers.byGroup.delivery[papers.byGroup.delivery.length - 1];
    await page.goto(`/#pub-${id}`);
    await waitForApp(page);
    await waitForScrollToSettle(page);
    await expectLanded(page, `#pub-${id}`);
    expect((await sectionBar(page)).visible).toBe("true");
  });

  test("a link to a paper opens its row, and brings it into the list's view from far down the list", async ({ page }) => {
    // The last paper sits far below the list's height limit: the list scrolls inside its panel to reach it.
    const id = papers.all[papers.all.length - 1];
    await page.goto(`/#pub-${id}`);
    await waitForApp(page);
    await waitForScrollToSettle(page);
    await expect(page.locator(`#pub-${id} .pub-toggle`)).toHaveAttribute("aria-expanded", "true");
    await expect(page.locator(`#m-${id}`)).toBeVisible();
    await expectLanded(page, `#pub-${id}`);
    const list = await page.locator("#publication-list").evaluate((el) => ({ scrollTop: el.scrollTop, top: el.getBoundingClientRect().top }));
    expect(list.scrollTop, "the list scrolled inside its panel").toBeGreaterThan(0);
  });

  test("a link to a paper wins over a filter in the address that would hide it", async ({ page }) => {
    const id = papers.byGroup.delivery.find((p) => !papers.byGroup.imaging.includes(p))!;
    await page.goto(`/?show=imaging#pub-${id}`);
    await waitForApp(page);
    await waitForScrollToSettle(page);
    await expectLanded(page, `#pub-${id}`);
    // The paper is shown, so the view is "all" again: list, checked option, and address must agree.
    await expect.soft(page).not.toHaveURL(/show=imaging/);
    await expectFilter(page, "all", { soft: true });
  });

  test("a link to a paper lands on it when a filter that includes it is in the address", async ({ page }) => {
    const id = papers.byGroup.other.find((p) => papers.firstAuthor.includes(p)) ?? papers.firstAuthor.at(-1)!;
    await page.goto(`/?show=first-author#pub-${id}`);
    await waitForApp(page);
    await waitForScrollToSettle(page);
    await expectLanded(page, `#pub-${id}`);
    await expectFilter(page, "first-author", { soft: true });
  });

  test("every in-page link on the page has a target, and a paper link from Research lands clear of the bar", async ({ page }) => {
    await page.goto("/");
    await waitForApp(page);
    const missing = await page.evaluate(() =>
      Array.from(document.querySelectorAll<HTMLAnchorElement>('a[href^="#"], a[href^="/#"]'))
        .map((a) => a.getAttribute("href")!.replace(/^\/?#/, ""))
        .filter((id) => id && !document.getElementById(decodeURIComponent(id))),
    );
    expect([...new Set(missing)], "in-page links without a target").toEqual([]);

    const paperLink = page.locator('#research a[href^="#pub-"]').first();
    if (await paperLink.count()) {
      const href = (await paperLink.getAttribute("href"))!;
      await paperLink.click();
      await expect(page).toHaveURL(new RegExp(`${href}$`));
      await waitForScrollToSettle(page);
      await expectLanded(page, href);
    } else {
      test.info().annotations.push({ type: "info", description: "Research links its featured papers to their DOIs, not to #pub- entries: nothing to land on." });
    }
  });
});

test.describe("Deep links to the lab (#lab-*)", () => {
  for (const lab of LAB) {
    test(`#${lab.slug} opens the ${lab.name} chapter with its controls`, async ({ page }) => {
      await page.goto(`/#${lab.slug}`);
      await waitForApp(page);
      await waitForScrollToSettle(page);
      await expect(page.locator(`#${lab.slug}`)).toHaveAttribute("aria-pressed", "true");
      for (const other of LAB.filter((l) => l.slug !== lab.slug)) {
        await expect(page.locator(`#${other.slug}`)).toHaveAttribute("aria-pressed", "false");
      }
      const hero = page.locator("#top");
      for (const name of lab.controls) await expect(hero.getByRole("radiogroup", { name })).toBeVisible();
      expect(Math.abs((await placement(hero)).top), "the lab is at the top of the screen").toBeLessThanOrEqual(2);
    });
  }

  test("a lab link further down the page opens the chapter and brings the lab into view", async ({ page }) => {
    await page.goto("/#research");
    await waitForApp(page);
    await waitForScrollToSettle(page);
    const chip = page.locator('#research a[href="#lab-ultrasound"]').filter({ visible: true }).first();
    await chip.click();
    await expect(page).toHaveURL(/#lab-ultrasound$/);
    await expect(page.locator("#lab-ultrasound")).toHaveAttribute("aria-pressed", "true");
    await waitForScrollToSettle(page);
    expect(Math.abs((await placement(page.locator("#top"))).top)).toBeLessThanOrEqual(2);
  });

  test("the lab's evidence link lands on Publications with the matching filter", async ({ page }) => {
    await page.goto("/");
    await waitForApp(page);
    await page.locator("#lab-design").click();
    await page.getByRole("link", { name: "See the papers behind this" }).click();
    await expect(page).toHaveURL(/\/\?show=delivery#publications$/);
    await waitForScrollToSettle(page);
    await expectFilter(page, "delivery");
    await expectLanded(page, "#publications");
  });
});

test.describe("Back and Forward", () => {
  test("Research → lab chapter → paper → Back → Back → Forward, then Contact → Copy email (PLAN §3.2)", async ({
    page,
    context,
    browserName,
    baseURL,
  }) => {
    await stubExternalSites(context);
    await prepareClipboard(context, browserName, baseURL!);
    await page.goto("/");
    await waitForApp(page);

    await page.getByRole("navigation", { name: "Primary" }).getByRole("link", { name: "Research" }).click();
    await expect(page).toHaveURL(/#research$/);
    await waitForScrollToSettle(page);

    const chip = page.locator('#research a[href="#lab-ultrasound"]').filter({ visible: true }).first();
    await chip.scrollIntoViewIfNeeded();
    const chipTop = (await placement(chip)).top;
    await chip.click();
    await expect(page).toHaveURL(/#lab-ultrasound$/);
    await expect(page.locator("#lab-ultrasound")).toHaveAttribute("aria-pressed", "true");
    await page.locator("#top").getByRole("radiogroup", { name: "Beamformer" }).getByRole("radio", { name: "Coherence" }).click();

    // The chapter's evidence link: the paper behind what the lab shows (its wording is copy, so found by address).
    await page.locator('#top a[href^="https://doi.org/"]').click();
    await page.waitForURL(/doi\.org/);

    await page.goBack();
    await expect(page).toHaveURL(/\/#lab-ultrasound$/);
    await waitForApp(page);
    await waitForScrollToSettle(page);
    await expect(page.locator("#lab-ultrasound"), "Back from the paper returns to the lab chapter").toHaveAttribute("aria-pressed", "true");
    expect(Math.abs((await placement(page.locator("#top"))).top)).toBeLessThanOrEqual(2);
    const beam = await page.locator("#top").getByRole("radiogroup", { name: "Beamformer" }).getByRole("radio", { checked: true }).textContent();
    test.info().annotations.push({
      type: "info",
      description: `After Back from the paper, the Beamformer shows "${beam}" (chosen: Coherence). Control choices aren't in the address, so they survive only when the browser restores the page from its back/forward cache.`,
    });

    await page.goBack();
    await expect(page).toHaveURL(/\/#research$/);
    await waitForScrollToSettle(page);
    const restored = await placement(chip);
    expect(restored.top, "Back again returns to where the reader was in Research").toBeGreaterThanOrEqual(0);
    expect(restored.bottom).toBeLessThanOrEqual(restored.viewport);
    expect(Math.abs(restored.top - chipTop)).toBeLessThanOrEqual(40);

    await page.goForward();
    await expect(page).toHaveURL(/\/#lab-ultrasound$/);
    await waitForScrollToSettle(page);
    await expect(page.locator("#lab-ultrasound")).toHaveAttribute("aria-pressed", "true");
    expect(Math.abs((await placement(page.locator("#top"))).top)).toBeLessThanOrEqual(2);

    await page.getByRole("navigation", { name: "Primary" }).getByRole("link", { name: "Contact" }).click();
    await expect(page).toHaveURL(/#contact$/);
    await waitForScrollToSettle(page);
    await expectLanded(page, "#contact");
    // The button's name changes to "Copied", so it is found by place, not by name.
    const copy = page.locator("#contact button");
    await expect(copy).toHaveAccessibleName("Copy email");
    await copy.click();
    await expect(copy).toHaveAccessibleName("Copied");
    expect(await readClipboard(page)).toBe(normalizeSpace((await page.locator("#contact-email").textContent())!));
  });
});

test.describe("Keyboard entry", () => {
  test('"Skip the lab" is the first Tab stop, is visible when focused, and moves the focus past the lab', async ({ page, browserName }) => {
    await page.goto("/");
    await waitForApp(page);
    await page.keyboard.press(tabKey(browserName));
    const skip = page.getByRole("link", { name: "Skip the lab" });
    await expect(skip, `first Tab stop was ${await describeFocus(page)}`).toBeFocused();
    await settle(page);
    const box = (await skip.boundingBox())!;
    expect(box.y).toBeGreaterThanOrEqual(0);
    expect(await effectiveOpacity(skip)).toBeGreaterThan(0.99);

    // It skips to the first section after the lab (the brief named #research; a section added before
    // Research moves the target, which is right as long as it is the next thing after the lab).
    const next = (await pageSectionIds(page))[0];
    await expect(skip).toHaveAttribute("href", `#${next}`);
    await page.keyboard.press("Enter");
    await expect(page).toHaveURL(new RegExp(`#${next}$`));
    await page.keyboard.press(tabKey(browserName));
    const where = await page.evaluate((next) => {
      const a = document.activeElement;
      const target = document.getElementById(next);
      return {
        inHero: !!a?.closest("#top"),
        atOrAfterTarget: !!a && !!target && (target.contains(a) || !!(target.compareDocumentPosition(a) & Node.DOCUMENT_POSITION_FOLLOWING)),
      };
    }, next);
    expect(where, `the Tab after the skip link reached ${await describeFocus(page)}`).toEqual({ inHero: false, atOrAfterTarget: true });
  });
});

for (const viewport of [
  { width: 1440, height: 900 },
  { width: 390, height: 844 },
]) {
  test.describe(`Section bar at ${viewport.width}×${viewport.height}`, () => {
    test.use({ viewport });

    test("hidden and inert over the hero, shown once the hero has left, marking the section in view", async ({ page }) => {
      await page.goto("/");
      await waitForApp(page);
      await instantScroll(page);
      await settle(page);
      const bar = page.locator('nav[aria-label="Sections"]');

      const top = await sectionBar(page);
      expect(top.visible).toBe("false");
      expect(top.inert, "inert while hidden, so keyboard and screen readers never meet it").toBe(true);
      expect(top.opacity).toBe(0);

      for (const s of SECTIONS) {
        await scrollElementTopTo(page, s.id, 0);
        await expect(bar).toHaveAttribute("data-visible", "true");
        await settle(page);
        const state = await sectionBar(page);
        expect(state.inert, `inert removed at ${s.id}`).toBe(false);
        expect(state.opacity, `opaque at ${s.id}`).toBe(1);
        await expect(bar.locator("a[aria-current]"), `aria-current at ${s.id}`).toHaveText(s.label);
        await expect(bar.getByRole("link", { name: s.label })).toHaveAttribute("aria-current", "location");
      }

      await page.evaluate(() => window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior }));
      await expect(bar).toHaveAttribute("data-visible", "false");
      await expect(bar).toHaveAttribute("inert", "");
      await expect(bar.locator("a[aria-current]")).toHaveCount(0);
    });

    test("landing past the lab (skip link, or Research in the navigation) shows the bar the anchors leave room for", async ({ page }) => {
      const problems: string[] = [];
      const check = async (how: string) => {
        await waitForScrollToSettle(page);
        await settle(page);
        const state = await sectionBar(page);
        const hero = await placement(page.locator("#top"));
        if (state.visible !== "true") {
          problems.push(`${how}: bar hidden while ${Math.max(0, Math.round(hero.bottom))}px of the lab is still on screen (anchors reserve ${await page.evaluate(() => getComputedStyle(document.documentElement).scrollPaddingTop)} for the bar)`);
        }
      };
      await page.goto("/");
      await waitForApp(page);
      await page.getByRole("link", { name: "Skip the lab" }).focus();
      await page.keyboard.press("Enter");
      await check(`skip link → ${new URL(page.url()).hash}`);
      await page.evaluate(() => window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior }));
      await page.getByRole("navigation", { name: "Primary" }).getByRole("link", { name: "Research" }).click();
      await check("Primary nav → #research");
      expect(problems).toEqual([]);
    });
  });
}

test.describe("Copy buttons", () => {
  test("Cite opens the panel; Copy citation, Copy BibTeX, and Copy link put the right text on the clipboard", async ({
    page,
    context,
    browserName,
    baseURL,
    request,
  }) => {
    await prepareClipboard(context, browserName, baseURL!);
    const id = papers.byGroup.imaging[0];
    await page.goto(`/#pub-${id}`);
    await waitForApp(page);
    const item = page.locator(`#pub-${id}`);
    const cite = item.locator("details").filter({ has: page.locator("summary", { hasText: "Cite" }) });
    await expect(cite).not.toHaveAttribute("open", "");
    await item.locator("summary", { hasText: "Cite" }).click();
    await expect(cite).toHaveAttribute("open", "");
    await expect(item.locator(`#cite-${id}`)).toBeVisible();

    const bib = parseBib(await (await request.get("/publications.bib")).text());
    const expected = {
      "Copy citation": normalizeSpace((await item.locator(`#cite-${id}`).textContent())!),
      "Copy BibTeX": bib.get(bibKey(id)) ?? `(no entry ${bibKey(id)} in /publications.bib)`,
      "Copy link": `${new URL(baseURL!).origin}/#pub-${id}`,
    };

    const buttons = cite.locator("button");
    await expect(buttons).toHaveCount(3);
    for (const [i, [label, text]] of Object.entries(expected).entries()) {
      // Found by place: each button's name changes to "Copied" once clicked.
      const button = buttons.nth(i);
      await expect(button).toHaveAccessibleName(label);
      await button.click();
      await expect(button).toHaveAccessibleName("Copied");
      await expect(button.locator("xpath=following-sibling::*[@role='status']")).toHaveText("Copied");
      expect(normalizeSpace(await readClipboard(page)), `${label} copies`).toBe(normalizeSpace(text));
    }
  });

  test("every paper's Copy BibTeX copies its entry in /publications.bib", async ({ page, context, browserName, baseURL, request }) => {
    test.setTimeout(120_000);
    await prepareClipboard(context, browserName, baseURL!);
    const bib = parseBib(await (await request.get("/publications.bib")).text());
    await page.goto("/#publications");
    await waitForApp(page);
    for (const id of papers.all) {
      const item = page.locator(`#pub-${id}`);
      await openPaper(page, id);
      await item.locator("summary", { hasText: "Cite" }).click();
      const button = item.locator("details button").nth(1);
      await expect(button).toHaveAccessibleName("Copy BibTeX");
      await button.click();
      await expect(button).toHaveAccessibleName("Copied");
      expect(await readClipboard(page), `Copy BibTeX for ${id}`).toBe(bib.get(bibKey(id)));
    }
  });

  test("Copy email and Copy short bio copy the address and the bio", async ({ page, context, browserName, baseURL }) => {
    await prepareClipboard(context, browserName, baseURL!);
    await page.goto("/#about");
    await waitForApp(page);

    const bio = page.locator("#about aside button");
    await expect(bio).toHaveAccessibleName("Copy short bio");
    await bio.click();
    await expect(bio).toHaveAccessibleName("Copied");
    expect(normalizeSpace(await readClipboard(page))).toBe(normalizeSpace((await page.locator("#short-bio-text").textContent())!));

    const email = page.locator("#contact button");
    await expect(email).toHaveAccessibleName("Copy email");
    await email.click();
    await expect(email).toHaveAccessibleName("Copied");
    const address = normalizeSpace((await page.locator("#contact-email").textContent())!);
    expect(address).toMatch(/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/);
    await expect(page.locator("#contact-email")).toHaveAttribute("href", `mailto:${address}`);
    expect(await readClipboard(page)).toBe(address);
  });
});

test.describe("404", () => {
  test.beforeEach(({ guard }) => {
    // The not-found page itself answers 404: that status (and the browser's console note about it) is the point.
    guard.allow(/(http 404 GET|console Failed to load resource: the server responded with a status of 404).*\/no-such-page/);
  });

  test("an unknown address answers 404 with the not-found page, noindex, and three exits", async ({ page, request }) => {
    const raw = await request.get("/no-such-page");
    expect(raw.status()).toBe(404);
    expect(raw.headers()["content-type"]).toContain("text/html");

    const response = await page.goto("/no-such-page");
    expect(response?.status()).toBe(404);
    await expect(page).toHaveTitle("Page not found · Madhavi Tripathi");
    const robots = await page.locator('meta[name="robots"]').evaluateAll((ms) => ms.map((m) => m.getAttribute("content") ?? ""));
    expect(robots.some((c) => /noindex/.test(c))).toBe(true);
    if (robots.length > 1) {
      test.info().annotations.push({ type: "P2", description: `${robots.length} <meta name="robots"> tags on the 404 page: ${robots.join(" | ")}` });
    }
    await expect(page.getByRole("heading", { level: 1 })).toHaveText("Page not found");
    await expect(page.getByRole("main").getByRole("link")).toHaveText(["Home", "Publications", "Contact"]);
  });

  test("404 → Home lands on the top of the home page", async ({ page }) => {
    await page.goto("/no-such-page");
    await page.getByRole("main").getByRole("link", { name: "Home", exact: true }).click();
    await expect(page).toHaveURL(/\/$/);
    await waitForApp(page);
    await waitForScrollToSettle(page, 400);
    await expect(page.getByRole("heading", { level: 1, name: HEADLINE })).toBeInViewport();
    expect(await page.evaluate(() => scrollY), "scroll position after 404 → Home").toBeLessThanOrEqual(2);
  });

  for (const exit of ["Publications", "Contact"] as const) {
    test(`404 → ${exit} lands on the ${exit} section`, async ({ page }) => {
      await page.goto("/no-such-page");
      await page.getByRole("main").getByRole("link", { name: exit, exact: true }).click();
      await expect(page).toHaveURL(new RegExp(`/#${exit.toLowerCase()}$`));
      await waitForApp(page);
      await waitForScrollToSettle(page, 400);
      await expectLanded(page, `#${exit.toLowerCase()}`);
    });
  }
});

test.describe("Files beside the page", () => {
  test("/publications.bib is plain text with one entry per paper", async ({ request }) => {
    const response = await request.get("/publications.bib");
    expect(response.status()).toBe(200);
    expect(response.headers()["content-type"]).toBe("text/plain; charset=utf-8");
    const entries = parseBib(await response.text());
    expect(entries.size).toBe(TOTAL_PAPERS);
    expect([...entries.keys()].sort()).toEqual(papers.all.map(bibKey).sort());
  });

  test("sitemap, robots, manifest, and every icon the manifest names are served", async ({ request }) => {
    const sitemap = await request.get("/sitemap.xml");
    expect(sitemap.status()).toBe(200);
    expect(sitemap.headers()["content-type"]).toContain("xml");
    expect(await sitemap.text()).toContain("<loc>");

    const robots = await request.get("/robots.txt");
    expect(robots.status()).toBe(200);
    expect(await robots.text()).toMatch(/^Sitemap: \S+\/sitemap\.xml$/m);

    const manifest = await request.get("/manifest.webmanifest");
    expect(manifest.status()).toBe(200);
    const icons = ((await manifest.json()) as { icons: Array<{ src: string; type: string }> }).icons;
    for (const icon of icons) {
      const res = await request.get(icon.src);
      expect(res.status(), `manifest icon ${icon.src}`).toBe(200);
      expect(res.headers()["content-type"]).toBe(icon.type);
    }
  });
});

test.describe("No errors anywhere", () => {
  test("every chapter, every control, the tour, a pulse, every filter, a Cite panel, and every section: no console errors or CSP violations", async ({
    page,
    guard,
  }) => {
    test.setTimeout(120_000);
    await page.goto("/");
    await waitForApp(page);
    const status = await waitForLab(page);
    const hero = page.locator("#top");
    if (status === "ready") {
      await page.getByRole("button", { name: "Take the tour" }).click();
      await page.waitForTimeout(1200);
      await page.getByRole("button", { name: "Stop the tour" }).click();
      const scene = (await page.locator("[data-status]").boundingBox())!;
      await page.mouse.click(scene.x + scene.width * 0.72, scene.y + scene.height * 0.45);
    }
    for (const lab of LAB) {
      const button = page.locator(`#${lab.slug}`);
      if ((await button.getAttribute("aria-pressed")) !== "true") await button.click();
      await expect(button).toHaveAttribute("aria-pressed", "true");
      for (const name of lab.controls) {
        const radios = hero.getByRole("radiogroup", { name }).getByRole("radio");
        const count = await radios.count();
        for (let i = 0; i < count; i++) {
          await radios.nth(i).click();
          await page.waitForTimeout(120);
        }
      }
    }
    if (status === "ready") {
      await page.getByRole("button", { name: /animation$/ }).click();
      await page.getByRole("button", { name: /animation$/ }).click();
    }
    await page.getByRole("button", { name: "Zoom out" }).click();
    await instantScroll(page);
    for (const { label } of [...SHOW.slice(1), SHOW[0]]) {
      await showGroup(page).getByRole("radio", { name: new RegExp(`^${label}\\b`) }).click();
    }
    for (const control of await page.locator("main section:not(#top) button[aria-controls]").all()) {
      if (await control.isVisible()) await control.click();
    }
    const publications = page.locator("#publications");
    for (const name of ["Most cited", "Newest"]) await publications.getByRole("radio", { name }).click();
    await openPaper(page, papers.all[0]);
    await page.locator(`#pub-${papers.all[0]} summary`, { hasText: "Cite" }).click();
    // The list's length button (whatever state the loop above left it in), both ways.
    const length = publications.locator('button[aria-controls="publication-list"]');
    await length.click();
    await length.click();
    for (const s of SECTIONS) await scrollElementTopTo(page, s.id);
    await page.evaluate(() => window.scrollTo({ top: document.documentElement.scrollHeight, behavior: "instant" as ScrollBehavior }));
    await page.waitForTimeout(500);
    expect(guard.problems.filter((p) => p.kind === "csp")).toEqual([]);
  });
});

test.describe("Without JavaScript", () => {
  test.use({ javaScriptEnabled: false });

  test("nothing below the lab waits for a script that isn't there: headings, figures, and charts are at rest", async ({ page }) => {
    await page.goto("/");
    await page.waitForTimeout(500);
    expect(await page.locator("html").getAttribute("data-reveals"), "the page never holds anything back").toBeNull();
    await page.locator(".scholar").scrollIntoViewIfNeeded();
    expect(await restState(page), "at rest").toEqual({ digits: true, stems: true, ranks: true, headings: true });
  });

  test("the name, navigation, headline, all 15 papers, and the contact address are visible", async ({ page }) => {
    await page.goto("/");
    await page.waitForTimeout(1500); // the CSS entrance (at most 360 ms delay + 700 ms)
    const name = page.locator("#top header a").first();
    await expect(name).toContainText("Madhavi Tripathi");
    expect(await effectiveOpacity(name)).toBeGreaterThan(0.99);
    const nav = page.getByRole("navigation", { name: "Primary" });
    for (const s of SECTIONS) {
      const link = nav.getByRole("link", { name: s.label });
      await expect(link).toBeVisible();
      expect(await effectiveOpacity(link), `nav link ${s.label}`).toBeGreaterThan(0.99);
    }
    const h1 = page.getByRole("heading", { level: 1, name: HEADLINE });
    await expect(h1).toBeVisible();
    expect(await effectiveOpacity(h1)).toBeGreaterThan(0.99);

    // Every paper, open: its summary, links, and Cite. The controls that need JavaScript aren't drawn at all.
    const rows = page.locator('#publication-list li[id^="pub-"]');
    await expect(rows).toHaveCount(TOTAL_PAPERS);
    for (let i = 0; i < TOTAL_PAPERS; i++) {
      await expect(rows.nth(i)).toBeVisible();
      await expect(rows.nth(i).locator(".pub-more")).toBeVisible();
      await expect(rows.nth(i).locator(".pub-toggle")).toBeHidden();
    }
    await expect(page.locator("#publications").getByRole("radiogroup")).toHaveCount(0);
    const list = await page.locator("#publication-list").evaluate((el) => ({ scroll: el.scrollHeight, client: el.clientHeight, tabindex: el.getAttribute("tabindex") }));
    expect(list.scroll, "without JavaScript the list runs with the page (no height limit)").toBeLessThanOrEqual(list.client + 1);
    expect(list.tabindex, "and it isn't a Tab stop").toBeNull();

    const email = page.locator("#contact-email");
    await expect(email).toBeVisible();
    await expect(email).toHaveAttribute("href", /^mailto:/);
    expect(await effectiveOpacity(email)).toBeGreaterThan(0.99);
  });

  test("every Tab stop is visible (nothing focusable is hidden at opacity 0)", async ({ page, browserName }) => {
    await page.goto("/");
    await page.waitForTimeout(1500);
    const invisible: string[] = [];
    const seen = new Set<string>();
    for (let i = 0; i < 400; i++) {
      await page.keyboard.press(tabKey(browserName));
      const stop = await page.evaluate(() => {
        const a = document.activeElement as HTMLElement | null;
        if (!a || a === document.body) return null;
        let opacity = 1;
        let hidden = false;
        for (let n: Element | null = a; n; n = n.parentElement) {
          const cs = getComputedStyle(n);
          opacity *= Number.parseFloat(cs.opacity);
          if (cs.visibility === "hidden") hidden = true;
        }
        const r = a.getBoundingClientRect();
        const path: string[] = [];
        for (let n: Element | null = a; n && path.length < 4; n = n.parentElement) path.push(n.tagName.toLowerCase() + (n.id ? `#${n.id}` : ""));
        const label = (a.getAttribute("aria-label") ?? a.textContent ?? "").replace(/\s+/g, " ").trim().slice(0, 40);
        return { key: `${path.join("<")}|${label}|${Math.round(r.top + scrollY)}`, label, where: path.reverse().join(" > "), opacity, hidden, size: r.width * r.height };
      });
      if (!stop) break;
      if (seen.has(stop.key)) break;
      seen.add(stop.key);
      if (stop.opacity < 0.1 || stop.hidden || stop.size === 0) invisible.push(`${stop.where} "${stop.label}" (opacity ${stop.opacity.toFixed(2)})`);
    }
    expect(seen.size, "Tab reached the page").toBeGreaterThan(10);
    expect(invisible, "focusable but invisible without JavaScript").toEqual([]);
  });
});

test.describe("Reduced motion", () => {
  test.use({ reducedMotion: "reduce" });

  test("the lab starts paused, the entrance doesn't animate, and anchor links jump instead of gliding", async ({ page }) => {
    await page.goto("/");
    await waitForApp(page);
    const status = await waitForLab(page);
    if (status === "ready") {
      await expect(page.getByRole("button", { name: "Play animation" }), "the lab opens paused").toBeVisible();
    } else {
      test.info().annotations.push({ type: "skipped-check", description: `Lab status "${status}" (no WebGL): the paused start can't be checked here.` });
    }
    const animated = await page.locator("#top .enter, #top .line-in").evaluateAll((els) =>
      els.filter((el) => getComputedStyle(el).animationName !== "none").length,
    );
    expect(animated, "entrance animations under reduced motion").toBe(0);
    expect(await page.evaluate(() => getComputedStyle(document.documentElement).scrollBehavior)).toBe("auto");

    const jump = await page.evaluate(async () => {
      const link = document.querySelector<HTMLAnchorElement>('nav[aria-label="Primary"] a[href="#publications"]')!;
      link.click();
      await new Promise<void>((r) => requestAnimationFrame(() => r()));
      const pad = Number.parseFloat(getComputedStyle(document.documentElement).scrollPaddingTop) || 0;
      return { top: document.getElementById("publications")!.getBoundingClientRect().top, pad };
    });
    expect(Math.abs(jump.top - jump.pad), "one frame after the click, Publications is already in place").toBeLessThanOrEqual(2);
  });

  test("control: without reduced motion the same link glides (so the check above can fail)", async ({ browser, baseURL }) => {
    const context = await browser.newContext({ baseURL, reducedMotion: "no-preference" });
    const page = await context.newPage();
    await page.goto("/");
    await waitForApp(page);
    // In-page links glide once the page has loaded (a link into the page jumps).
    await expect(page.locator("html")).toHaveAttribute("data-smooth", "");
    expect(await page.evaluate(() => getComputedStyle(document.documentElement).scrollBehavior)).toBe("smooth");
    const top = await page.evaluate(async () => {
      document.querySelector<HTMLAnchorElement>('nav[aria-label="Primary"] a[href="#publications"]')!.click();
      await new Promise<void>((r) => requestAnimationFrame(() => r()));
      return document.getElementById("publications")!.getBoundingClientRect().top;
    });
    expect(top).toBeGreaterThan(200);
    await context.close();
  });
});

/**
 * Whether the motion blocks below the lab are at rest: every rolling column on its digit, every stem and ranked bar at
 * its height, and every section heading in its line. Read from computed styles, so it holds whether or not anything
 * animated to get there.
 */
async function restState(page: Page) {
  return page.evaluate(() => {
    const px = (v: string) => Number.parseFloat(v) || 0;
    const still = (el: Element, pseudo?: string) => ["none", "0px", "0px 0px"].includes(getComputedStyle(el, pseudo).translate);
    const digits = Array.from(document.querySelectorAll(".rise-digits > span")).every((d) => still(d));
    const stems = Array.from(document.querySelectorAll<HTMLElement>(".stem-value")).every((v) => {
      const bar = px(getComputedStyle(v, "::after").height);
      const well = v.closest<HTMLElement>(".scholar-well")!;
      const ws = getComputedStyle(well);
      const inside = well.clientHeight - px(ws.paddingTop) - px(ws.paddingBottom);
      const want = 9 + Number(v.parentElement!.style.getPropertyValue("--v")) * (inside - 52);
      return Math.abs(bar - want) < 2 && getComputedStyle(v).color !== "rgba(0, 0, 0, 0)";
    });
    const on = getComputedStyle(document.documentElement).getPropertyValue("--color-bone").trim();
    const ranks = Array.from(document.querySelectorAll<HTMLElement>(".ranks > [data-on]")).every((b) => {
      const probe = document.createElement("i");
      probe.style.color = on;
      document.body.append(probe);
      const bone = getComputedStyle(probe).color;
      probe.remove();
      return getComputedStyle(b).backgroundColor === bone;
    });
    const headings = Array.from(document.querySelectorAll(".rise > span")).every((h) => still(h));
    return { digits, stems, ranks, headings };
  });
}

test.describe("Motion below the lab", () => {
  test.use({ viewport: { width: 1440, height: 900 } });

  test("a block below the screen waits for its moment, plays it once, and comes to rest where it would have been anyway", async ({ browser, baseURL }) => {
    const context = await browser.newContext({ baseURL, reducedMotion: "no-preference", viewport: { width: 1440, height: 900 } });
    const page = await context.newPage();
    await page.goto("/");
    await waitForApp(page);
    await expect(page.locator("html")).toHaveAttribute("data-reveals", "");
    const scholar = page.locator(".scholar");
    expect(await scholar.getAttribute("data-in"), "below the screen: held").toBeNull();
    await scholar.scrollIntoViewIfNeeded();
    await expect(scholar).toHaveAttribute("data-in", "");
    await expect(page.locator("#publications [data-reveal]").first()).toHaveAttribute("data-in", "");
    // The longest part (the index tiles lighting their papers) ends by about 2.4 s.
    await page.waitForTimeout(3000);
    expect(await restState(page)).toEqual({ digits: true, stems: true, ranks: true, headings: expect.any(Boolean) });
    await context.close();
  });

  test("a link to a section lands with its heading in place", async ({ browser, baseURL }) => {
    const context = await browser.newContext({ baseURL, reducedMotion: "no-preference", viewport: { width: 1440, height: 900 } });
    const page = await context.newPage();
    await page.goto("/#publications");
    await waitForApp(page);
    await waitForScrollToSettle(page);
    await expect(page.locator("html")).toHaveAttribute("data-reveals", "");
    const heading = page.locator("#publications-title .rise > span");
    await expect(page.locator("#publications > div > [data-reveal]").first()).toHaveAttribute("data-in", /^(now)?$/);
    await settle(page);
    expect(await heading.evaluate((el) => getComputedStyle(el).translate)).toMatch(/^(none|0px)$/);
    expect(await heading.evaluate((el) => el.getBoundingClientRect().top)).toBeLessThan(900);
    await context.close();
  });

  test("with reduced motion nothing waits and nothing below the lab moves", async ({ browser, baseURL }) => {
    const context = await browser.newContext({ baseURL, reducedMotion: "reduce", viewport: { width: 1440, height: 900 } });
    const page = await context.newPage();
    await page.goto("/");
    await waitForApp(page);
    expect(await page.locator("html").getAttribute("data-reveals"), "nothing is held back").toBeNull();
    await page.locator(".scholar").scrollIntoViewIfNeeded();
    expect(await restState(page)).toEqual({ digits: true, stems: true, ranks: true, headings: true });
    // Controls answer with a cut: choosing a filter and opening a row start no animations.
    await page.locator("#publications").getByRole("radio", { name: /^Delivery/ }).click();
    await page.locator("#publication-list .pub-toggle").filter({ visible: true }).first().click();
    // Tone changes (color, 150 to 250 ms) are allowed and over by now; any movement would still be running.
    await page.waitForTimeout(400);
    const running = await page.evaluate(() =>
      document.getAnimations().filter((a) => {
        const target = (a.effect as KeyframeEffect | null)?.target;
        return target instanceof Element && !target.closest("#top") && a.playState === "running";
      }).length,
    );
    expect(running, "animations running below the lab").toBe(0);
    await context.close();
  });
});

test.describe("Motion answers input", () => {
  test.use({ viewport: { width: 1440, height: 900 } });

  test("the Show thumb and the section bar's underline glide rather than jump, and the first Recognition row keeps its shape", async ({ browser, baseURL }) => {
    const context = await browser.newContext({ baseURL, reducedMotion: "no-preference", viewport: { width: 1440, height: 900 } });
    const page = await context.newPage();
    await page.goto("/#publications");
    await waitForApp(page);
    await settle(page);
    const thumb = page.locator('[aria-labelledby="show-label"] > .seg-thumb');
    await page.locator("#publications").getByRole("radio", { name: /^Delivery/ }).click();
    expect(await thumb.evaluate((el) => el.getAnimations().length), "the thumb is gliding").toBeGreaterThan(0);
    const mark = page.locator('nav[aria-label="Sections"] .bar-mark');
    await page.locator("#about").scrollIntoViewIfNeeded();
    await expect.poll(() => mark.evaluate((el) => el.getAnimations().length), { message: "the underline glides to About" }).toBeGreaterThan(0);
    // The marker sits after the rows, so the first row keeps its own spacing once the page has hydrated.
    const first = page.locator('#recognition [role="tab"]').first();
    expect(await first.evaluate((el) => getComputedStyle(el).paddingTop)).toBe("4px");
    await context.close();
  });

  test("choosing a filter while a summary is folding leaves the count and the dimmed years right", async ({ browser, baseURL }) => {
    const context = await browser.newContext({ baseURL, reducedMotion: "no-preference", viewport: { width: 1440, height: 900 } });
    const page = await context.newPage();
    await page.goto("/#publications");
    await waitForApp(page);
    await page.locator("#publication-list .pub-toggle").first().click();
    await page.waitForTimeout(80);
    await page.locator("#publications").getByRole("radio", { name: /^Delivery/ }).click();
    await page.waitForTimeout(1000);
    const shown = await page.locator("#publication-list .pub-row").evaluateAll((rows) => rows.filter((r) => getComputedStyle(r).display !== "none").length);
    await expect(page.locator("#publications .panel-head p").first()).toHaveText(`${shown} of ${TOTAL_PAPERS} publications`);
    await context.close();
  });
});

/*
  The theme toggle (design-system/MASTER.md, "Two themes"): dark is the lab and the default; light is the
  paper. The head's inline script resolves a stored choice, else the system preference, before first paint;
  the toggle persists a choice, updates the browser chrome, and the swap crosses in 350 ms — never under
  reduced motion, and the lab never flips.
*/
test.describe("The lab and the paper", () => {
  test("dark by default, light when the system asks: the first paint is already right", async ({ browser }) => {
    const dark = await browser.newContext({ colorScheme: "dark" });
    const darkPage = await dark.newPage();
    await darkPage.goto("/");
    await expect(darkPage.locator("html")).not.toHaveAttribute("data-theme");
    await dark.close();

    const light = await browser.newContext({ colorScheme: "light" });
    const page = await light.newPage();
    await page.goto("/");
    // Set by the inline script, before hydration: no stored choice, so the system decides.
    await expect(page.locator("html")).toHaveAttribute("data-theme", "light");
    expect(await page.evaluate(() => getComputedStyle(document.body).backgroundColor)).toBe("rgb(244, 242, 238)");
    // The lab stays the lab: the hero's pinned palette never lightens.
    expect(await page.evaluate(() => getComputedStyle(document.getElementById("top")!).getPropertyValue("--color-void").trim())).toBe("#060a0c");
    await light.close();
  });

  test("the toggle flips, remembers, and tells the browser chrome; both copies agree", async ({ page }) => {
    await page.goto("/");
    await waitForApp(page);
    const toggle = page.locator("#top .theme-toggle");
    await expect(toggle).toHaveAttribute("aria-pressed", "false");
    await toggle.click();
    await expect(page.locator("html")).toHaveAttribute("data-theme", "light");
    await expect(toggle).toHaveAttribute("aria-pressed", "true");
    expect(await page.evaluate(() => document.querySelector<HTMLMetaElement>('meta[name="theme-color"]')?.content)).toBe("#f4f2ee");
    expect(await page.evaluate(() => localStorage.getItem("theme"))).toBe("light");
    // The choice survives a reload, before hydration.
    await page.reload();
    await expect(page.locator("html")).toHaveAttribute("data-theme", "light");
    await waitForApp(page);
    // The section bar's copy reads the same document state.
    await instantScroll(page);
    await scrollElementTopTo(page, "publications");
    await expect(page.locator('nav[aria-label="Sections"] .theme-toggle')).toHaveAttribute("aria-pressed", "true");
    // Back to the lab, from either copy.
    await page.locator('nav[aria-label="Sections"] .theme-toggle').click();
    await expect(page.locator("html")).not.toHaveAttribute("data-theme");
    expect(await page.evaluate(() => localStorage.getItem("theme"))).toBe("dark");
  });

  test("the swap crosses once, and reduced motion cuts it", async ({ browser }) => {
    const moving = await browser.newContext({ reducedMotion: "no-preference" });
    const page = await moving.newPage();
    await page.goto("/");
    await waitForApp(page);
    await page.locator("#top .theme-toggle").click();
    // The crossing attribute is set for the swap and removed when it lands.
    await expect(page.locator("html")).toHaveAttribute("data-theme-swap");
    await expect(page.locator("html")).not.toHaveAttribute("data-theme-swap", { timeout: 2000 });
    await moving.close();

    const still = await browser.newContext({ reducedMotion: "reduce" });
    const cut = await still.newPage();
    let swapped = false;
    await cut.exposeFunction("sawSwap", () => (swapped = true));
    await cut.goto("/");
    await waitForApp(cut);
    await cut.evaluate(() => {
      new MutationObserver(() => {
        if (document.documentElement.hasAttribute("data-theme-swap")) (window as unknown as { sawSwap(): void }).sawSwap();
      }).observe(document.documentElement, { attributes: true });
    });
    await cut.locator("#top .theme-toggle").click();
    await expect(cut.locator("html")).toHaveAttribute("data-theme", "light");
    await cut.waitForTimeout(300);
    expect(swapped, "reduced motion never sets the crossing attribute").toBe(false);
    await still.close();
  });

  test("while no choice is stored, the theme follows the system; a choice ends that", async ({ page }) => {
    await page.goto("/");
    await waitForApp(page);
    await page.emulateMedia({ colorScheme: "light" });
    await expect(page.locator("html")).toHaveAttribute("data-theme", "light");
    await page.emulateMedia({ colorScheme: "dark" });
    await expect(page.locator("html")).not.toHaveAttribute("data-theme");
    // Choose dark explicitly (flip to light and back): the system no longer decides.
    await page.locator("#top .theme-toggle").click();
    await expect(page.locator("html")).toHaveAttribute("data-theme", "light");
    await page.locator("#top .theme-toggle").click();
    await expect(page.locator("html")).not.toHaveAttribute("data-theme");
    await page.emulateMedia({ colorScheme: "light" });
    await page.waitForTimeout(200);
    await expect(page.locator("html")).not.toHaveAttribute("data-theme");
  });

  test("without JavaScript there is no toggle, and the page is the lab", async ({ browser }) => {
    const context = await browser.newContext({ javaScriptEnabled: false, colorScheme: "light" });
    const page = await context.newPage();
    await page.goto("/");
    await expect(page.locator("html")).not.toHaveAttribute("data-theme");
    for (const toggle of await page.locator(".theme-toggle").all()) {
      await expect(toggle, "a control that would do nothing is not shown").toBeHidden();
    }
    await context.close();
  });
});

test.describe("Print from the paper theme", () => {
  test("print stays print: its palette wins over a toggled light theme", async ({ page }) => {
    await page.addInitScript(() => {
      try {
        localStorage.setItem("theme", "light");
      } catch {
        /* Then this proves nothing new. */
      }
    });
    await page.goto("/");
    await expect(page.locator("html")).toHaveAttribute("data-theme", "light");
    await page.emulateMedia({ media: "print" });
    const tokens = await page.evaluate(() => {
      const s = getComputedStyle(document.documentElement);
      return { bone: s.getPropertyValue("--color-bone").trim(), void: s.getPropertyValue("--color-void").trim() };
    });
    // The print block's values (globals.css @media print; the export minifies hex), not the screen theme's.
    expect(["#111", "#111111"]).toContain(tokens.bone);
    expect(["#fff", "#ffffff"]).toContain(tokens.void);
  });
});
