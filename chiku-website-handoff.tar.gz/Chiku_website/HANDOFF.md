# Handoff — chiku-website migration

**Written:** 2026-09-25 · **Purpose:** resume this build on another machine.

Read this file top to bottom before touching anything. It is written so you can pick up
without the prior conversation.

---

## 0. Restoring from the transfer archive

The archive is `chiku-website-handoff.tar.gz` (~15 MB). It carries the full git history,
every recorded fixture, and all AI-DLC records. It **omits everything regenerable** —
`.venv`, `node_modules`, `.sites-runtime`, build output and caches — which is why 2.5 GB
on disk becomes 15 MB.

```bash
tar -xzf chiku-website-handoff.tar.gz
cd Chiku_website

git status                 # expect: clean, on branch construction/backend-units-1-5
git log --oneline -3

# Backend — uv creates the venv from the committed lockfile.
cd chiku-website/backend
uv sync
uv run pytest              # expect: 935 passed
uv run ruff check && uv run ruff format --check && uv run mypy --strict app tests
```

That is the whole restore for the work that remains. **You do not need to run the source
app again** — its behaviour is already captured in the 91 recorded fixtures, and
re-recording is a deliberate operator action, not part of any test run.

If you ever do need the reference app running (only to record a fixture that does not
exist, and only while it still boots):

```bash
cd madhavi-tripathi
pnpm install               # restores the ~1 GB node_modules
node scripts/run-framework.mjs dev     # NOT `pnpm dev` — see fixtures/README.md
```

**Two per-clone files were deliberately excluded**: `aidlc/.aidlc-clone-id` and
`aidlc/.aidlc-sessions/`. The new machine mints its own on first run. Shipping the old
clone-id would make both machines append to the same audit shard, which is exactly the
conflict the workspace layout exists to prevent.

The engine's `source-review` cache (80 MB of derived snapshots) was also excluded; the
receipts that matter — reviews, sensors, guard refusals, the steering key — are included.

---

## 1. What this project is

Migrate the Next.js / Cloudflare-Workers academic site in `madhavi-tripathi/` into
`chiku-website/`, under a **strict language boundary**:

- **Next.js is frontend-only. It renders; it decides nothing.**
- **A single Python FastAPI backend owns ALL application logic** — authentication,
  authorization, authoritative validation, business rules, persistence, uploads,
  publishing.

Forbidden in the frontend, and checked by grep at the merge gate: `'use server'`,
`app/**/route.ts`, `middleware.ts`.

### Non-negotiable project rules

| Rule | Detail |
|---|---|
| **Zero recurring cost** | Hard target. No paid, metered or recurring component. No introductory credits or trials. |
| **No cloud provisioning** | Google Cloud is **plan-only**. No project, service, bucket, credential or billing change. Writing adapter *code* is fine; provisioning is not. |
| **No default credentials** | No seeded, sample or hard-coded credential anywhere. A fresh start against an empty volume must have **no account anyone can sign in to**. |
| **Parity** | Never change layout or content while porting a page. **User-facing error strings are product copy** and fall under parity. |
| **`madhavi-tripathi/` stays intact** | It is the reference and rollback baseline. Read it freely; never modify it. |
| **No secrets in logs, commits, images** | No secret through Docker `ARG`/`ENV`. Use build secret mounts if ever needed. |
| **Reuse-first** | Prefer a maintained public library over custom code. |

---

## 2. Current state — where to resume

### Backend: green and substantial

```
cd chiku-website/backend
uv run pytest                     # 935 passed
uv run ruff check                 # clean
uv run ruff format --check        # clean
uv run mypy --strict app tests    # clean  (NOTE: bare `mypy --strict` does NOT run — see §6)
uv run coverage report --fail-under=80    # 99% aggregate branch
```

### Units complete (5 of 12)

| Unit | Delivers | Status |
|---|---|---|
| `source-fixtures` | **91 recorded fixtures** in `chiku-website/fixtures/` | done |
| `storage-ports` | `ContentStore` / `IdentityStore` / `AssetStore` + SQLite/volume adapters + in-memory fakes + conformance suite | done |
| `cloud-adapters` | Firestore/GCS adapters, code-complete, **explicitly unverified** against real services | done |
| `content-core` | 31-field schema, seed, combined write, draft recovery, published-doc cache, revision ledger | done |
| `identity-and-session` | argon2id sign-in, sessions, CSRF, rate limiting, one-shot provisioning | done |

### Units remaining (7 of 12) — build in this order

1. **`media`** — upload (byte-signature typing, WebVTT validation, Pillow variants) and
   delivery (asset visibility, 7 range branches). **Two hazards.** Needs `pillow` added.
2. **`http-api`** — FastAPI routes, the error envelope, the nine-step check order, CORS /
   same-origin / CSRF middleware. **This is where the app becomes runnable.**
3. **`api-client`** — generated TypeScript types from `/openapi.json` via
   `openapi-typescript`.
4. **`public-site`** — the ported public Next.js render layer.
5. **`owner-editor`** — the ported editor. **Carries 12 open findings** — see
   `chiku-website/CARRIED-FINDINGS.json`.
6. **`containers`** — two Dockerfiles, `compose.yaml`, `.env.example`, the end-to-end flow.
7. **`deployment-plan`** — deferred (cloud, plan-only).

---

## 3. The workflow (AI-DLC) — how each unit is built

This repo runs an AI-DLC workflow. Each unit's code generation is six steps:

```bash
cd /path/to/Chiku_website

# 1. Ask what's next. Returns a `load-steering` directive in 4 parts.
aidlc engine orchestrate next

# 2. Chain the continuation token (POSITIONAL, not --token) until you get `run-stage`.
aidlc engine orchestrate continue "<continue_token>"

# 3. Write the plan + unit-test instructions into
#    aidlc/spaces/default/intents/260924-chiku-website-migration/construction/<unit>/code-generation/

# 4. Append the Testing Contract byte-exact:
aidlc engine testing-posture render >> .../code-generation/code-generation-plan.md

# 5. Fingerprint, write the questions file with a BLANK [Answer]:, then:
aidlc engine testing-posture fingerprint --unit <unit>
aidlc engine log decision --stage code-generation --checkpoint plan-approval \
  --session 252bae3e-1f47-4da7-99d5-f5d725d19282 \
  --questions-file ".../code-generation-questions.md" \
  --decision "Approve this exact Code Generation plan?" \
  --options "Approve Plan,Request Changes" --unit <unit>
# ... ask the human ... then fill [Answer]: Approve Plan ... then:
aidlc engine log answer --stage code-generation --checkpoint plan-approval \
  --session 252bae3e-1f47-4da7-99d5-f5d725d19282 \
  --questions-file ".../code-generation-questions.md" \
  --details "Approve Plan" --unit <unit>

# 6. Generate, then write code-summary.md + source-manifest.json + traceability.json,
#    then re-run `next` for the following unit.
```

### Gotchas that cost real time

- **`log decision` must run BEFORE you present the approval question.** The receipt binds
  to a challenge minted at `decision` time; an answer collected earlier is refused.
- **The questions file must contain exactly `[Answer]:` (blank) when `decision` runs.**
- **`orchestrate continue` takes its token positionally**, not `--token`.
- **Continuation tokens are single-use and ~660 chars.** If you truncate output to read
  them, use at least `tail -c 950` or you will slice the token and have to restart.
- **The plan-approval guard blocks compound shell commands** (`cmd && cmd`, `sed -n`)
  for a unit until its plan is approved. Use the Read tool instead.
- **`source-manifest.json` must use the strict schema**: `{stage, unit, version,
  writes:[{path}]}`. Subagents tend to invent a richer one; normalise it.
- Write `produces[]` artifacts with a file-writing tool, **never a shell heredoc** —
  heredocs are invisible to the write-recording hook and the review is refused.

---

## 4. The testing posture — this is the load-bearing part

**Methodology is `custom`, and it is NOT test-after.** From `aidlc/spaces/default/memory/team.md`:

> Within each unit, the characterization tests for that unit's **hazard-register
> behaviours and for the storage port** are written and **observed to fail** before the
> Python implementation of that behaviour exists; every other backend test is written
> immediately after the code it covers.

**Why:** under test-after, a developer who misreads a dense source line implements from
the misreading and then writes the test from the same misreading. Green, covered, wrong.

### Coverage floors — inputs, not suggestions

- **80% branch** over `chiku-website/backend/` (currently 99%).
- **100% branch** on every hazard module. Currently nine:
  `app/auth/sessions.py`, `app/auth/hashing.py`, `app/owner/identity.py`,
  `app/content/defaults.py`, `app/content/statements.py`, `app/content/recovery.py`,
  `app/cloud/content_firestore.py`, `app/content/store_sqlite.py`,
  `app/auth/store_sqlite.py`.
  **`media` will add two more.**

**Never relax a floor to make a step pass** — not by editing a threshold, adding an
`omit`, or narrowing an `--include`. Surface the gap instead.

### The recorded fixtures are the oracle

`chiku-website/fixtures/` holds **91 recordings** from the running source app, with
`MANIFEST.json` as index and `README.md` as the guide. Where a fixture covers a
behaviour, **read the expected value out of the recording** rather than choosing it.

**This capability has expired for practical purposes** — re-recording needs the source
app running. Two gaps were closed on 2026-09-25 by uploading and publishing an asset
through the app's own routes and re-recording in full.

---

## 5. Facts proven against the running source that contradict the design docs

**Trust the fixtures over the prose.** These are already handled in code; do not "fix"
them back.

1. **The 1,500,000 request-body cap counts UTF-16 code units** — not characters, not
   UTF-8 bytes. `route.ts:11` tests JavaScript `bodyText.length`.
   - `F6-size-astral-under-in-units`: 1,400,000 units / 708,326 codepoints / 2,783,379
     bytes → **200**. A byte cap would reject it.
   - `F6-size-astral-over-in-units`: 1,600,000 units / 808,326 codepoints / 3,183,379
     bytes → **413**. A codepoint cap would accept it.
   - Implemented in `app/content/limits.py` as `len(text.encode("utf-16-le")) // 2`.
   - `rules.md` BR4.20 still says "characters". It is wrong.

2. **The media route diverges by publication, not identity.** `F7-draftonly-anon` → 404
   (9 bytes, `Not found`) vs `F7-draftonly-owner` → 200 (188,618 bytes); `F7-published-anon`
   and `F7-published-owner` are **both 200** with byte-identical bodies.

3. **Four upload-route branches share one message.** The four conditions on `route.ts`
   line 28 all return *"The prepared image sizes could not be verified."* — so a port
   implementing only one passes any test written against a single fixture. Recorded as
   `FIX-6` in `fixtures/MANIFEST.json`.

4. **Cross-origin and oversized-body rejections are dev-server artifacts** (`FIX-3`,
   `FIX-5`). The status is source-accurate; the body is not. Nine fixtures carry a
   `recorderCaveat` — do not assert on those bodies.

---

## 6. Open findings that need someone's decision

| ID | Severity | What |
|---|---|---|
| **Gate command broken** | Major | `mypy --strict` as written in `team.md`'s merge gate **does not run** — `pyproject.toml` sets no `files`/`packages`, so it exits `Missing target module, package, files, or command`. Use `mypy --strict app tests`. Owner: Build and Test. Deliberately not "fixed" by reshaping config. |
| **U1-F7** | Major | Upload **cancellation** (the two `Upload cancelled.` literals and the best-effort cleanup path) cannot be recorded over HTTP. Port from `route.ts`'s **six** `checkCancelled()` call sites; a port placing fewer loses cleanup coverage. Owner: `media`. |
| **U1-F9** | Major | One of the four prepared-variant conditions is not expressible over a multipart wire body; three are recorded and asserted together. Owner: `media`. |
| **U3-F3** | **Major** | **BR23.2's reclamation half is not implementable.** The rule requires an expired session record to be *deleted as it is rejected*. `IdentityStore` exposes `session` create / read / touch / revoke and **no delete** — fixed by `contract-design` § C3, declared in `app/auth/store.py`, implemented by all three adapters. U3 has no operation with which to reclaim the record, and adding one would change an approved inception contract and land a port operation outside the conformance suite that is the port's evidence. **Owner: `storage-ports` (U2), at a gate.** The implemented half — the record is rejected, stably, at +9h, +10h and +30d — is asserted. |
| **U3-F2** | Minor | **No session retention policy.** Revoked and expired session records accumulate with nothing to sweep them. **U3-F3 makes this strictly worse than the design assumed**: with no delete, BR23.2 reclaims *nothing*, so every session record accumulates rather than only the revoked and never-revisited ones. **Decide these two together.** |
| **Recovery window** | Open | Draft recovery accepts up to 6,000,000 characters; save rejects above 1,500,000. Both limits reproduced, neither aligned. **Needs the site owner.** |
| **`owner-editor`** | 3 Critical + 9 Major | See `chiku-website/CARRIED-FINDINGS.json`. Most likely to be lost silently: **R-11** — the source's `manualSave` runs a client-side pre-flight parse that blocks the save *before dispatch* and raises `Check these fields before saving. Your edits are kept in this browser.` Replacing it with the backend's `issues[]` drops that sentence, and under the parity rule a user-facing error string is product copy. |

### One incident worth knowing about — resolved, and not a defect

Mid-run the tree was briefly observed with 5 failing tests: `app/auth/store_memory.py`'s
`session_touch` advancing `absolute_expires_at` alongside `last_seen_at`. **No such
defect ever shipped.** That was `identity-and-session`'s own **mutation probe**, applied
for seconds to prove the hazard assertions discriminate. Its revert (`cp <backup>
<target>`) hit a `cp -i` alias, blocked on the prompt, and was backgrounded — so the tree
sat mutated for a window, and that window was read and written up as a discovered defect.

It was retracted in place rather than overwritten silently (`U3-F1`, status
`Rejected: …`, in that unit's `traceability.json`), because a reader of the earlier
version would have believed a shipped defect had been found in `storage-ports`.

**Verified correct:** `session_touch` reads `replace(existing, last_seen_at=now)` exactly
as U2 wrote it, and 935 tests pass.

Two things are worth carrying forward from it. **Do not treat a transient tree state as
evidence** — check whether a background command is mid-flight before writing a finding
against another unit's file. And the substantive lesson still stands: **mutation probes
are how a suite with no oracle earns trust.** U3 applied eight and all eight were caught;
two of them (refreshing the absolute bound, dropping the absolute-bound check) leave
*every* idle-expiry test green, which is why one test drives 192 simulated hourly
requests and asserts the refusal lands at hour 169.

---

## 7. Architecture you must not break

```
app/
  sqlite.py          <- the ONLY module permitted to `import sqlite3`
  errors.py          <- five-member taxonomy; routes never construct envelopes
  content/           <- schema, defaults, seed, statements, recovery, cache, ledger, authority
  auth/              <- hashing, tokens, sessions, guard + IdentityStore adapters
  owner/             <- identity, provisioning
  assets/            <- ranges + AssetStore adapters
  cloud/             <- Firestore/GCS adapters (no SDK dependency — structural Protocols)
  routers/           <- EMPTY. This is http-api's job.
```

- **Every port operation is `async`.** Blocking drivers are wrapped in
  `anyio.to_thread.run_sync` **inside the adapter only**.
- **Ports are `typing.Protocol`** so `mypy --strict` checks conformance at call sites.
- **Wire format is `camelCase` and frozen.** Python identifiers are `snake_case`
  everywhere including columns. One conversion point: a shared Pydantic base with
  `alias_generator=to_camel, populate_by_name=True`.
- **The error envelope is ported, not redesigned.** `{error: '<sentence>'}` plus
  `issues: [{path, message}]` on validation failures; statuses 400 / 403 / 409 / 413 /
  503. FastAPI's `{"detail": ...}` default **silently breaks** the editor's conflict
  recovery and field highlighting.
- **503, not 500**, for the catch-all — matching the source.
- **`app/routers/` must not import a `store` module or `sqlite3`.** A pytest walks the AST
  and asserts this; write it in `http-api`.

### The cloud adapters' key decision

They are written against **structural `Protocol`s** (`FirestoreLike`, `TransactionLike`,
`BucketLike`) — **no `google-cloud-*` dependency is installed.** This keeps the image
small, keeps `mypy --strict` clean without a blanket suppression, and lets the conformance
suite run against limit-enforcing fakes. Wiring a real client later needs one small shim
for `FirestoreLike.transaction()`; no adapter logic changes.

---

## 8. Next unit: `media` — what the plan must cover

Design artifacts:
`aidlc/spaces/default/intents/260924-chiku-website-migration/construction/media/functional-design/{functional-spec,entities,rules}.md`

**Two hazards, each needing a test per enumerated branch and a 100% floor:**

**A. Byte-signature typing (FR6.2).** The three image parsers are *simultaneously* the
dimension extractor and the format validator — **returning no dimensions IS a rejection.**
- **PNG and JPEG are big-endian. EVERY WebP field is little-endian. JPEG stores HEIGHT
  BEFORE WIDTH.** The source inherits big-endian defaults from JS `DataView`; Python's
  `int.from_bytes` has no default to inherit, so **every read must be transcribed
  individually with its byteorder stated.**
- **How many bytes are read is itself a rule** (BR6.9): images and VTT read the **entire
  file**; PDF/MP4/WebM read **the first 32 bytes only**.
- **Do not substitute an imaging library** for the parsers (BR6.10).

**B. Asset visibility (FR7.2).** An asset is public **iff the literal `/api/media/<key>`
appears ANYWHERE in the serialised published document** — including inside free prose.
A structured-field check makes strictly fewer assets public, passes every test written
against the structured fields, and 404s exactly the images nobody enumerated.
**Do not "improve" it.**
- **Step 1 (key regex) runs before any storage access** — it is the path-traversal
  defence, and the content schema's `url` form is more permissive than it.
- **Step 3 (public check) runs before step 4 (identity)** — a public asset costs no
  authorization lookup.
- **Every denial is a 404, never a 403.** A 403 anywhere on this path is a defect.

**Also:** all seven range branches (`HEAD` always 200 with full `Content-Length`, before
any range parsing; `HEAD` and `GET` must not share range logic), variant generation
server-side with **Pillow** (a new dependency — add it), the sum-not-per-file size
ceiling, orphan-free failure with a gather-all-results cleanup primitive, and the 499.

`app/assets/ranges.py` already exists and already ports `parseByteRange` branch-for-branch
with 18 recorded fixtures behind it. **Reuse it.**

---

## 9. Key paths

| What | Where |
|---|---|
| Backend | `chiku-website/backend/` |
| Fixtures + recorder | `chiku-website/fixtures/` (`README.md`, `MANIFEST.json`, `record.py`) |
| Unit plan / chunking | `chiku-website/UNITS.md` |
| Editor findings | `chiku-website/CARRIED-FINDINGS.json` |
| Design artifacts | `aidlc/spaces/default/intents/260924-chiku-website-migration/construction/<unit>/functional-design/` |
| Code-gen records | `.../construction/<unit>/code-generation/` |
| Project rules | `aidlc/spaces/default/memory/{org,team,project}.md` |
| Reference source | `madhavi-tripathi/` — **read only** |
| Session id | `252bae3e-1f47-4da7-99d5-f5d725d19282` |

### The merge gate (from `team.md`)

```
ruff check
ruff format --check
mypy --strict app tests          # NOT bare `mypy --strict` — see §6
pytest --cov --cov-branch
coverage report --fail-under=80
coverage report --fail-under=100 --include=<hazard module globs>
tsc --noEmit
pnpm lint
git diff --no-index madhavi-tripathi/app/<f> chiku-website/frontend/app/<f>
<boundary grep: 'use server' / app/**/route.ts / middleware.ts>
<openapi-typescript regeneration — gate fails if committed output is dirty>
uv export --frozen --no-dev --no-emit-project -o .audit/requirements.txt && uvx pip-audit -r .audit/requirements.txt
pnpm audit --prod --audit-level high
docker compose up  +  the end-to-end flow
```

Verbatim output is pasted into the gate approval. **Gate approval is refused without it.**
Weakening a gate to make a Bolt pass is an incident, not a shortcut.

---

## 10. Running AI-DLC under GitHub Copilot on the other machine

**Copilot is a first-class supported harness** — `aidlc` 2.9.0 ships a Copilot flavour.
You do not port anything by hand.

### What is portable and what is not

| Directory | Portable? | Why |
|---|---|---|
| `aidlc/` | **Yes — this is everything** | Harness-neutral: memory, intents, all five units' records, the audit trail, the active-space cursor. |
| `chiku-website/`, `madhavi-tripathi/` | **Yes** | Ordinary source. |
| `.claude/` | **No — regenerate** | The Claude Code shell: hooks, settings, skills, agent personas. Copilot uses a different surface. |

The Copilot shell is a different set of files for the same content:

| Claude Code | Copilot |
|---|---|
| `.claude/` runtime dir | `.aidlc/` runtime dir |
| `.claude/CLAUDE.md` + `@`-import stub | **`AGENTS.md` at the project root**, whose `@`-import lines are the method include |
| `.claude/agents/aidlc-*.md` | `.github/agents/aidlc-*.md` (native custom agents) + `.aidlc/agents/` inline twins |
| `.claude/settings.json` hooks | Copilot's own hook surface, written by `aidlc config` |

### The steps

```bash
# 1. Same binary version — the workspace records are version-bound.
#    This machine runs: aidlc 2.9.0 (runtime 2.9.0)
aidlc version            # on the new machine, must match
aidlc use 2.9.0          # if it does not

# 2. Clone the repo (it IS a git repo; commit before you leave this machine).

# 3. Guided setup — select GitHub Copilot as the harness.
aidlc config

# 4. Verify before running any stage.
aidlc doctor
```

`aidlc config` writes `.aidlc/`, `AGENTS.md` and `.github/agents/`, and repoints every
method include at `aidlc/spaces/default/memory/`. It does **not** touch `aidlc/`, so all
existing work is preserved.

### Three things that will bite

1. **Copilot needs BYOK provider configuration, and it is a manual step.** Setup pauses
   with *"Configure Copilot BYOK provider variables before acknowledging this step"* and
   records a pending action `copilot-byok-configuration`. Until you complete it and
   acknowledge, the workflow will not dispatch agents. Clear it with
   `aidlc config providers --acknowledge` (or `--mark-done copilot-byok-configuration`).

   This machine's `.claude/settings.json` routed through **AWS Bedrock** (`us-east-1`,
   Opus/Sonnet/Haiku aliases). That routing is Claude-Code-specific and does **not**
   carry over — you are configuring Copilot's own provider path.

2. **`.github/` is shared with your own content.** The framework deliberately touches
   only `aidlc-`prefixed or plugin-owned personas there. Do not rename them.

3. **Hooks must actually fire, or plan approvals cannot be recorded.** The
   plan-approval receipt binds to a challenge minted by a hook. If `log decision` refuses
   with *"hooks are not firing in this session"*, stop — do not re-run it. Fix the
   runtime first: `aidlc config runtime --check`, then `aidlc doctor`. Approve the hooks
   when Copilot prompts, and **fully restart the editor** afterwards; a reload is not
   enough.

### Before you leave this machine

```bash
git add -A && git commit -m "handoff: 5 of 12 units complete, 935 tests green"
```

`aidlc/.aidlc-clone-id`, `aidlc/.aidlc-sessions/` and the active-intent cursor are
gitignored **by design** — they are per-clone. The new clone mints its own. The session
id in §9 belongs to this machine and will differ there; read the new one from
`aidlc/.aidlc-sessions/.current-session` after the first run.

### What does not change

The workflow itself is identical — same `aidlc engine orchestrate next` loop, same
directives, same plan-approval ritual, same stage files. Everything in §3 applies
unchanged. The harness swap changes where the *personas and hooks* live, not how the
workflow runs.

---

## 11. If you are not running AI-DLC on the other machine

You do not need the framework to continue — it is bookkeeping around the real work. To
build a unit without it:

1. Read that unit's three `functional-design/` artifacts.
2. Write the hazard tests first and **run them; watch them fail.**
3. Implement to green.
4. Keep `uv run pytest`, `ruff check`, `ruff format --check`,
   `mypy --strict app tests` clean, and both coverage floors met.
5. Take expected values from `chiku-website/fixtures/` wherever one exists.

The AI-DLC records under `aidlc/` are an audit trail. Skipping them loses traceability,
not correctness — but if you intend to return to this machine and resume the workflow,
write the three record artifacts per unit so the engine can still settle them.
