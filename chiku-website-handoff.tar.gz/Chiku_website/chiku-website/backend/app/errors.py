"""The error envelope, ported rather than redesigned.

This is the highest-probability silent regression in the migration. The source's four
routes share one shape -- ``{"error": "<sentence>"}``, plus ``issues: [{path, message}]``
on validation failures -- and the frontend is built on it: `editor-workflow.ts` branches
on ``409`` to enter conflict recovery and reads ``result.issues`` to highlight fields.

FastAPI's defaults (``{"detail": ...}``, and Pydantic's ``loc``/``msg`` instead of
``path``/``message``) break field highlighting and conflict recovery **while appearing to
work**: the request still fails with the right status, and nothing in the type system or
the test suite notices that the editor has stopped highlighting anything.

So: one envelope, produced by exception handlers rather than by each route. Services
raise these; routers never construct a response.

The sentences below are **product copy** under the parity rule -- they are what the site
owner reads -- and are byte-identical to the recorded fixtures, including the U+2019
curly apostrophe in `owner's`. They are not to be reworded.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import Request
from fastapi.responses import JSONResponse, PlainTextResponse

logger = logging.getLogger("chiku.errors")

# --- product copy, verbatim from the recorded fixtures ----------------------------- #
NOT_SIGNED_IN = "Please sign in with the website owner\u2019s account."  # U+2019
UNVERIFIED_REQUEST = "This request could not be verified. Refresh and try again."
TOO_LARGE = "This update is too large."
UNREADABLE_UPDATE = "The update could not be read."
INVALID_SAVE = "Invalid save request."
CHECK_FIELDS = "Please check the highlighted fields before saving."
CONFLICT = (
    "This draft changed in another tab. Your edits are still here. "
    "Review the latest saved draft before saving again."
)
SAVE_FAILED = "Your changes could not be saved. They are still in the form. Please try again."
LOAD_FAILED = "Unable to load your draft. Please try again."

# The media route answers in plain text, not JSON. Fixtures F7/F9/F10 are 9 bytes of
# `Not found`; a JSON body there would be a visible change of behaviour.
MEDIA_NOT_FOUND = "Not found"
MEDIA_UNAVAILABLE = "File temporarily unavailable"


class AppError(Exception):
    """Base of the taxonomy. `extra` merges into the envelope at the TOP level.

    Top-level matters: the 409 carries `revision`, `updatedAt`, `publishedAt` and
    `hasUnpublishedChanges` as siblings of `error`, not nested under a key, because that
    is the shape `editor-workflow.ts` reads during conflict recovery.
    """

    status: int = 503
    message: str = SAVE_FAILED

    def __init__(self, message: str | None = None, **extra: Any) -> None:
        super().__init__(message or self.message)
        self.message = message or self.message
        self.extra: dict[str, Any] = extra


class NotAuthorized(AppError):
    status = 403
    message = NOT_SIGNED_IN


class Conflict(AppError):
    status = 409
    message = CONFLICT


class TooLarge(AppError):
    status = 413
    message = TOO_LARGE


class Invalid(AppError):
    """400. Carries `issues` when the failure is per-field."""

    status = 400
    message = INVALID_SAVE

    def __init__(
        self,
        message: str | None = None,
        issues: list[dict[str, Any]] | None = None,
        **extra: Any,
    ) -> None:
        super().__init__(message, **extra)
        # An empty list and a missing key are different on the wire: the frontend tests
        # `issues?.length`, so only a non-empty list is emitted.
        if issues:
            self.extra["issues"] = issues


class Cancelled(AppError):
    """499. The client went away before the response was produced.

    Not in the source's taxonomy -- the source has no path that reports it -- but it is
    reachable here because the Python runtime can observe a disconnect that the Workers
    runtime hid. It is given its own member rather than being folded into 503 so that an
    abandoned request is never counted as a server fault.
    """

    status = 499
    message = "Request cancelled."


def envelope(error: AppError) -> dict[str, Any]:
    return {"error": error.message, **error.extra}


async def app_error_handler(request: Request, exc: Exception) -> JSONResponse:
    assert isinstance(exc, AppError)  # noqa: S101 - handler is registered for AppError only
    if exc.status >= 500:
        logger.exception("Unhandled application error", exc_info=exc)
    return JSONResponse(
        envelope(exc), status_code=exc.status, headers={"Cache-Control": "no-store"}
    )


async def unexpected_error_handler(request: Request, exc: Exception) -> JSONResponse:
    """Anything not in the taxonomy becomes 503, matching the source's catch blocks.

    503 rather than 500 is deliberate: every `catch` in the source's four routes answers
    503, and the frontend treats 503 as retryable with no specific handling.
    """
    logger.exception("Unexpected error", exc_info=exc)
    return JSONResponse(
        {"error": SAVE_FAILED}, status_code=503, headers={"Cache-Control": "no-store"}
    )


async def media_not_found() -> PlainTextResponse:
    return PlainTextResponse(MEDIA_NOT_FOUND, status_code=404)
