"""The ``ContentStore`` port and the three shapes it persists.

This module is a *definition*, not an implementation: a `Protocol` plus frozen record
shapes, no I/O, no SQL, no business rule. The port is a ``Protocol`` rather than an ABC
so an adapter conforms **structurally** and ``mypy --strict`` checks that conformance at
every call site, including for an adapter this unit never sees.

**Boundary, in one line:** this unit defines and implements persistence and owns no
business rule -- *it does not know what a revision means, only how to store one*.

Field names below are the **storage-level** spelling: ``snake_case`` everywhere,
including columns. The frozen ``camelCase`` wire format is produced by the consumer's
single conversion point and appears nowhere in this unit; an adapter that renamed on the
way in or out would have created a second conversion point that can drift.

Two things the store is handed rather than knowing, and the reason for each:

* **The seed payload** reaches an implementation at construction. ``read_state`` must
  return the seeded document when no record exists (BR4.1) and ``commit`` must write it
  at bootstrap (BR4.8) -- but *what the seed contains* is U4's business. Passing it in
  keeps ``read_state()`` argument-free, as `contract-summary.md` § C2 writes it, without
  the store holding a copy of anything it could disagree with its owner about.
* **The listing cap** likewise. 52 is ``30 + 20 + 2`` *by construction* (BR5.3): the cap
  and the retention counts are the same number, and changing one without the other
  silently truncates history or shows nothing new. `listing_cap_for` derives it from the
  policy so the two cannot drift; an adapter that hard-coded 52 has taken ownership of a
  policy it does not own, exactly as BR5.9 forbids for 30 and 20.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Literal, Protocol

# `draft` | `publish`. A `Literal` rather than an enum on purpose: an enum would have to
# be reconstructed from storage on every read, and `Action("something-else")` raises --
# which is a validation the store is forbidden to perform (BR22.6).
type Action = Literal["draft", "publish"]

# A constant, not a generated identifier, and not a collection key: exactly one content
# document ever exists.
CONTENT_DOCUMENT_ID = "singleton"

# The two fixed baseline identities of BR4.9. Insert-if-absent under these keys is what
# makes each capture succeed at most once in the document's lifetime.
BASELINE_PUBLISHED_ID = "starting-published"
BASELINE_DRAFT_ID = "starting-draft"


@dataclass(frozen=True, slots=True)
class ContentState:
    """What ``read_state`` and a successful ``commit`` return.

    ``updated_at`` is ``None`` only in the synthesised seed -- BR4.1 specifies a null
    there, and that null is the one port-level observable that distinguishes a store
    which wrote nothing from one that lazily created the record (the column is
    NOT NULL, so a lazy create has to invent a value).
    """

    draft: str
    published: str
    revision: int
    updated_at: datetime | None
    published_at: datetime | None


@dataclass(frozen=True, slots=True)
class CommitConflict:
    """``base_revision`` no longer matches: someone else wrote first.

    A **return value, not an exception**. An optimistic write losing a race is an
    ordinary outcome, and the consumer owns what a caller is told about it. A store that
    could not answer at all -- a lost connection, a failed write -- raises instead, and
    the consumer maps that to the catch-all.
    """


CONFLICT = CommitConflict()

type CommitResult = ContentState | CommitConflict


@dataclass(frozen=True, slots=True)
class RevisionSummary:
    """One row of the revision listing. Summaries, not content.

    ``read_revision`` fetches an entry's content one at a time; the listing does not
    carry 52 documents, any one of which may exceed 4 MB.
    """

    id: str
    revision: int
    action: Action
    created_at: datetime
    baseline: bool


@dataclass(frozen=True, slots=True)
class RevisionEntry:
    """A revision entry with its full content, as ``read_revision`` returns it.

    ``id`` holds two value shapes in one identity column -- a write's mutation token for
    a normal entry, or one of the two fixed baseline literals. Deliberate, reproduced
    rather than tidied. ``revision`` is **not** unique: a baseline pair and a normal
    entry can share one, and an adapter must not add a uniqueness constraint.
    """

    id: str
    revision: int
    action: Action
    content: str
    created_at: datetime
    baseline: bool


@dataclass(frozen=True, slots=True)
class AssetMetadataRecord:
    """The row half of an asset. Row-shaped, so it lives here and not in `AssetStore`.

    Its ``media_type`` is the value the serving response carries (BR7.18) -- **not**
    `AssetStore.head`'s. The two stores hold the value independently and agree only
    because both were written from the same value at upload time. The port does not
    reconcile them and an adapter must not (BR22.12).
    """

    key: str
    filename: str
    media_type: str
    byte_size: int
    width: int | None
    height: int | None
    created_at: datetime
    derived_from: str | None


@dataclass(frozen=True, slots=True)
class RetentionPolicy:
    """The policy `RevisionLedger` supplies. An argument, never a constant in an adapter.

    ``permanent_ids`` names the entries that are permanent -- the two baselines. It is
    here because the contract says the policy carries it, and it is what `listing_cap_for`
    counts.

    **It is not the prune's exclusion mechanism.** BR5.8 and BR22.1 require baselines to
    be excluded from the delete set **by the `baseline` predicate**, not by an id list and
    not by happening to sort high. An adapter that excluded by these ids would spare
    exactly the two entries it was told about and prune any future permanent entry
    silently -- and the capture is once-ever, so it cannot be recreated.
    """

    draft_keep: int
    publish_keep: int
    permanent_ids: tuple[str, ...]


def listing_cap_for(retention: RetentionPolicy) -> int:
    """The listing cap, derived from the retention policy rather than restated.

    BR5.3: 52 is ``30 drafts + 20 publishes + 2 baselines``. The cap and the policy are
    the same number *by construction*, and this function is that construction.
    """
    return retention.draft_keep + retention.publish_keep + len(retention.permanent_ids)


class ContentStore(Protocol):
    """The contract U4 `content-core` and U5 `media` persist through.

    Every operation is ``async``: where an adapter's driver is synchronous the adapter
    moves the call off the event loop, and a consumer never touches a blocking driver
    (BR22.7).

    Absence is a return value, not an error. Reading something that is not there returns
    absence; only a store that could not answer raises.
    """

    async def read_state(self) -> ContentState:
        """The five stored values, or the seeded document when no record exists.

        A **pure read** (BR4.1). It takes no lock, creates no record and performs no
        bootstrap; bootstrap belongs to `commit` alone, under its two guards. An adapter
        that lazily creates the record on first read defeats the ``base_revision = 0``
        guard and lets a client at revision 5 resurrect a deleted document.

        It also computes no change flag -- ``hasUnpublishedChanges`` has no column and is
        derived by the consumer on every read -- and applies no default and runs no
        transform.
        """
        ...

    async def commit(
        self,
        *,
        content: str,
        base_revision: int,
        action: Action,
        mutation_token: str,
        retention: RetentionPolicy,
        now: datetime,
    ) -> CommitResult:
        """THE combined write: one call, one transaction, six effects, all-or-none.

        Atomicity is **required** (BR4.16); splitting the effects across calls or
        transactions is what FR4.5 exists to prevent.

        ``mutation_token`` is unique per request and guards the **side effects**, whose
        guard condition (``revision = base_revision + 1``) is *not* unique to the writer.
        That is the ABA defence of BR4.13 and it is not optional.

        ``now`` is supplied by the consumer rather than read from an adapter clock, so
        the content record's ``updated_at`` and its revision entry's ``created_at`` are
        the same instant by construction rather than by luck.

        Returns the new state, or `CONFLICT` when ``base_revision`` no longer matches --
        in which case **no side effect fires**: no revision entry, no prune, no timestamp
        movement.
        """
        ...

    async def list_revisions(self) -> list[RevisionSummary]:
        """Summaries ordered ``revision`` DESC, then ``baseline`` ASC, then ``action`` DESC.

        All three parts are load-bearing and differ only on a tied revision, which is why
        the conformance suite asserts the order across a tie (BR5.1, BR5.2).

        **Not a paginated operation** (BR22.2). The cap is small and fixed; a cursor over
        an order with ties can repeat or skip an entry at a page boundary.
        """
        ...

    async def read_revision(self, revision_id: str) -> RevisionEntry | None:
        """The entry with its full content, byte-identical to what was stored, or absence.

        The id is taken as given: this operation validates no pattern and enforces no
        length (BR5.5 is the consumer's). A well-formed id that names nothing and an entry
        that was pruned both return absence.
        """
        ...

    async def asset_metadata_register(self, record: AssetMetadataRecord) -> None:
        """Store the record exactly as given.

        The store validates no media type, derives no extension, and inspects no filename.
        """
        ...

    async def asset_metadata_read(self, key: str) -> AssetMetadataRecord | None:
        """The record or absence. Its media type is what the serving response carries."""
        ...

    async def asset_metadata_remove(self, key: str) -> None:
        """**Idempotent**: removing an absent key is a success (BR22.10).

        It exists for the best-effort cleanup of a failed or cancelled upload and for no
        other purpose -- there is no ordinary asset-deletion path anywhere in the system.
        A remove that raised on an absent key would turn best-effort cleanup into a second
        failure that masks the first, which BR6.24 forbids.
        """
        ...
