"""The locally verified `ContentStore` adapter. **Hazard module: the combined write.**

`commit` here is the port of the single highest-risk behaviour in the system -- the
source's seven-statement batch, which its runtime executed as one implicit transaction.
The pure-versus-execute split survives the port: `commit_effects` *performs* the six
effects against an open transaction and `SqliteContentStore.commit` is the thin executor
around it, because that factoring is what makes the batch inspectable. Flattening it
loses the property.

**What breaks silently here.** Nothing errors and nothing logs. The history list grows a
row the owner never saved, or loses a row it should have kept. It is invisible to
single-user testing and invisible to a coverage percentage, and it is only reproducible
by two writers holding the same base revision -- which is why every guard below is spelled
out rather than inferred, and why the two floors this module is measured against leave no
room.

Four obligations that no ordinary correctness assertion catches, and where each lives:

* **One transaction, six effects, all-or-none** (BR4.16). `SqliteDatabase.transaction`
  opens it; `_StaleWrite` is how a conflict leaves nothing behind.
* **The compare-and-set outcome is read BY NAME** (BR4.17). ``RETURNING`` plus a
  `sqlite3.Row` factory. The source read it as `results[3]` -- by numeric index into the
  batch, unmarked -- so inserting a statement anywhere before it made the write read the
  wrong result, most likely nothing at all, which the route then reported as a **409
  conflict**. The failure mode is spurious "this draft changed in another tab" errors,
  not a crash.
* **The prune is read-the-survivors-then-delete-the-rest**, per action, inside the
  transaction, with baselines excluded **by predicate** (BR4.18, BR22.1). No
  ``DELETE ... WHERE id NOT IN (subquery)``: a SQL-shaped prune is satisfiable by one
  adapter, and this contract has to be satisfiable by a document store too.
* **The survivor ordering is `revision` DESC alone and is deliberately not
  tiebreak-stable** (BR4.19). That indeterminacy is inherited from the source. An adapter
  must not add a tie-break to make its own results deterministic, because that changes
  which entries survive.
"""

from __future__ import annotations

from datetime import datetime
from typing import cast

from app.content.store import (
    BASELINE_DRAFT_ID,
    BASELINE_PUBLISHED_ID,
    CONFLICT,
    CONTENT_DOCUMENT_ID,
    Action,
    AssetMetadataRecord,
    CommitResult,
    ContentState,
    RetentionPolicy,
    RevisionEntry,
    RevisionSummary,
)
from app.sqlite import (
    Connection,
    Row,
    SqliteDatabase,
    flag,
    instant,
    number,
    optional_instant,
    optional_number,
    optional_text,
    text,
)


class _StaleWrite(Exception):
    """Internal control flow: abort the transaction so a stale write leaves nothing.

    Raising is what makes "a conflicting commit performs no side effect" true **by
    construction** rather than by argument about which guards happened to have matched.
    It never escapes this module: `SqliteContentStore.commit` turns it into the port's
    conflict signal, which is a return value.
    """


def _state_from_row(row: Row) -> ContentState:
    """Read the compare-and-set outcome by name. BR4.17 is this function existing."""
    return ContentState(
        draft=text(row["draft"]),
        published=text(row["published"]),
        revision=number(row["revision"]),
        updated_at=instant(row["updated_at"]),
        published_at=optional_instant(row["published_at"]),
    )


def _summary_from_row(row: Row) -> RevisionSummary:
    return RevisionSummary(
        id=text(row["id"]),
        # A cast, not a coercion. The column holds what the caller wrote; re-deriving or
        # re-checking it here is exactly the validation BR22.6 forbids a store to do.
        revision=number(row["revision"]),
        action=cast(Action, text(row["action"])),
        created_at=instant(row["created_at"]),
        baseline=flag(row["baseline"]),
    )


def prune(
    connection: Connection,
    *,
    action: Action,
    keep: int,
    next_revision: int,
    mutation_token: str,
) -> None:
    """Read this action's survivors, then delete the rest. Inside the caller's transaction.

    Three things are load-bearing and each has broken a port before:

    * **Per action.** Two independent selections, never one combined set of
      ``draft_keep + publish_keep``: a run of drafts would then evict publishes (BR5.7).
    * **Baselines are excluded in the predicate** (``baseline = 0``), not by sorting
      high. They carry the *lowest* revision in the store, so ordering is what would
      reach them first -- and the capture is once-ever, so a pruned baseline cannot be
      recreated (BR5.8).
    * **The survivor ids are read first and the delete names them**, rather than the
      delete carrying a predicate over the live table. Firestore has no
      ``DELETE ... WHERE id NOT IN (subquery)``, so a SQL-shaped prune would make this
      port satisfiable by one adapter only (BR4.18).

    The ``EXISTS`` clause is the mutation-token guard of BR4.12, kept in SQL rather than
    as a Python branch. A stale writer's selection then returns nothing, so its delete
    set is empty and it prunes nothing. BR4.15: it stays even though the surrounding
    transaction already serialises the writes -- the guard does not depend on isolation,
    and a future adapter with weaker isolation inherits it.
    """
    candidates = connection.execute(
        "SELECT id FROM content_revision"
        " WHERE action = ? AND baseline = 0"
        "   AND EXISTS ("
        "       SELECT 1 FROM content_document"
        "       WHERE id = ? AND revision = ? AND last_mutation = ?"
        "   )"
        " ORDER BY revision DESC",
        (action, CONTENT_DOCUMENT_ID, next_revision, mutation_token),
    ).fetchall()
    doomed = [(text(row["id"]),) for row in candidates[keep:]]
    connection.executemany("DELETE FROM content_revision WHERE id = ?", doomed)


def commit_effects(
    connection: Connection,
    *,
    seed: str,
    content: str,
    base_revision: int,
    action: Action,
    mutation_token: str,
    retention: RetentionPolicy,
    now: datetime,
) -> ContentState:
    """The six effects, in order, against an already-open transaction.

    Separate from the executor on purpose (ADR-001's pure-versus-execute split): the
    sequence and its guards are readable in one screen, which is the only defence a
    reviewer has against a batch whose failure mode is silent.

    Raises `_StaleWrite` when the compare-and-set matches nothing.
    """
    now_text = now.isoformat()
    next_revision = base_revision + 1
    publishing = action == "publish"

    # --- Effect 0: bootstrap the singleton, under TWO guards, both load-bearing ------ #
    # `base_revision = 0` fires only when the caller claims revision 0, so a client at
    # revision 5 can never resurrect a deleted document. `ON CONFLICT DO NOTHING` makes a
    # concurrent bootstrap harmless. The seed goes into BOTH payload columns at revision
    # 0 with `published_at` NULL -- the seeded document is not "published" (BR4.8).
    if base_revision == 0:
        connection.execute(
            "INSERT INTO content_document"
            " (id, draft, published, revision, updated_at, published_at, last_mutation)"
            " VALUES (?, ?, ?, 0, ?, NULL, NULL)"
            " ON CONFLICT(id) DO NOTHING",
            (CONTENT_DOCUMENT_ID, seed, seed, now_text),
        )

    # --- Effects 1 and 2: capture the two permanent baselines, once ever ------------- #
    # Fixed identities plus insert-if-absent are what make each succeed AT MOST ONCE in
    # the document's lifetime -- genuinely idempotent under concurrency, not a
    # read-then-write. They capture the state BEFORE this write, and `created_at` is the
    # time of capture, never a guessed original publication date. The `revision = ?`
    # guard means a stale writer captures nothing (BR4.9).
    connection.execute(
        "INSERT INTO content_revision (id, revision, action, content, created_at, baseline)"
        " SELECT ?, revision, 'publish', published, ?, 1 FROM content_document"
        " WHERE id = ? AND revision = ?"
        " ON CONFLICT(id) DO NOTHING",
        (BASELINE_PUBLISHED_ID, now_text, CONTENT_DOCUMENT_ID, base_revision),
    )
    connection.execute(
        "INSERT INTO content_revision (id, revision, action, content, created_at, baseline)"
        " SELECT ?, revision, 'draft', draft, ?, 1 FROM content_document"
        " WHERE id = ? AND revision = ?"
        " ON CONFLICT(id) DO NOTHING",
        (BASELINE_DRAFT_ID, now_text, CONTENT_DOCUMENT_ID, base_revision),
    )

    # --- Effect 3: the compare-and-set. This is the concurrency control -------------- #
    # `revision = base_revision` is the optimistic guard: a stale base revision matches
    # zero rows, the update returns nothing, and the caller gets a conflict signal.
    # `draft` moves on EVERY accepted write, publishes included; `published` and
    # `published_at` move only on a publish; `revision` increments unconditionally
    # (BR4.10).
    updated = connection.execute(
        "UPDATE content_document SET"
        "   draft = ?,"
        "   published = CASE WHEN ? THEN ? ELSE published END,"
        "   revision = revision + 1,"
        "   updated_at = ?,"
        "   published_at = CASE WHEN ? THEN ? ELSE published_at END,"
        "   last_mutation = ?"
        " WHERE id = ? AND revision = ?"
        " RETURNING draft, published, revision, updated_at, published_at",
        (
            content,
            publishing,
            content,
            now_text,
            publishing,
            now_text,
            mutation_token,
            CONTENT_DOCUMENT_ID,
            base_revision,
        ),
    ).fetchall()
    if not updated:
        raise _StaleWrite
    state = _state_from_row(updated[0])

    # --- Effect 4: the history entry, gated on the TOKEN as well as the revision ----- #
    # Three things are load-bearing. The entry's id IS the mutation token. Its `content`
    # is read back from the record's `draft` column and its `created_at` from the
    # record's `updated_at`, so the entry is byte-identical to what effect 3 just STORED
    # rather than to what the caller sent -- which differ whenever validation or defaults
    # changed the value, i.e. most of the time. For a publish, `draft` and `published`
    # are equal, so reading `draft` is correct for both actions (BR4.11).
    #
    # The `last_mutation = ?` guard is the ABA defence. `revision = next_revision` is NOT
    # unique to this writer: when a winner advances the document to that very number, a
    # loser's guard is satisfied by the winner's write, and without the token the loser
    # would insert a phantom entry carrying the winner's content under its own action
    # (BR4.13, BR4.14).
    connection.execute(
        "INSERT INTO content_revision (id, revision, action, content, created_at, baseline)"
        " SELECT ?, revision, ?, draft, updated_at, 0 FROM content_document"
        " WHERE id = ? AND revision = ? AND last_mutation = ?",
        (mutation_token, action, CONTENT_DOCUMENT_ID, next_revision, mutation_token),
    )

    # --- Effects 5 and 6: retention, per action, under the same token guard ---------- #
    # The counts arrive as an ARGUMENT and are never constants here: `RevisionLedger`
    # owns the policy, and an adapter that hard-coded 30 and 20 would have taken
    # ownership of a policy it does not own (BR5.9).
    prune(
        connection,
        action="draft",
        keep=retention.draft_keep,
        next_revision=next_revision,
        mutation_token=mutation_token,
    )
    prune(
        connection,
        action="publish",
        keep=retention.publish_keep,
        next_revision=next_revision,
        mutation_token=mutation_token,
    )

    return state


class SqliteContentStore:
    """`ContentStore` over one SQLite database file.

    ``seed`` and ``listing_cap`` are supplied by the consumer: the store returns the seed
    when no record exists and bootstraps with it, but *what the seed contains* and *what
    the cap is* are U4's, and a store that held its own copy of either could disagree
    with its owner.
    """

    def __init__(self, database: SqliteDatabase, *, seed: str, listing_cap: int) -> None:
        self._db = database
        self._seed = seed
        self._listing_cap = listing_cap

    async def read_state(self) -> ContentState:
        def work(connection: Connection) -> Row | None:
            row: Row | None = connection.execute(
                "SELECT draft, published, revision, updated_at, published_at"
                " FROM content_document WHERE id = ?",
                (CONTENT_DOCUMENT_ID,),
            ).fetchone()
            return row

        row = await self._db.run(work)
        if row is None:
            # BR4.1: synthesise, and WRITE NOTHING. No bootstrap, no lazily created row,
            # no lock. `updated_at` is null here and the column is NOT NULL, which is
            # what makes a lazy create detectable from outside the store.
            return ContentState(
                draft=self._seed,
                published=self._seed,
                revision=0,
                updated_at=None,
                published_at=None,
            )
        return _state_from_row(row)

    async def commit(
        self,
        *,
        content: str,
        base_revision: int,
        action: Action,
        mutation_token: str,
        retention: RetentionPolicy,
        now: datetime,
    ) -> CommitResult:
        def work(connection: Connection) -> ContentState:
            return commit_effects(
                connection,
                seed=self._seed,
                content=content,
                base_revision=base_revision,
                action=action,
                mutation_token=mutation_token,
                retention=retention,
                now=now,
            )

        try:
            return await self._db.transaction(work)
        except _StaleWrite:
            # Losing an optimistic race is an ordinary outcome, so it is a return value.
            # The transaction has already rolled back, so no effect survives.
            return CONFLICT

    async def list_revisions(self) -> list[RevisionSummary]:
        cap = self._listing_cap

        def work(connection: Connection) -> list[Row]:
            rows: list[Row] = connection.execute(
                "SELECT id, revision, action, created_at, baseline FROM content_revision"
                " ORDER BY revision DESC, baseline ASC, action DESC"
                " LIMIT ?",
                (cap,),
            ).fetchall()
            return rows

        return [_summary_from_row(row) for row in await self._db.run(work)]

    async def read_revision(self, revision_id: str) -> RevisionEntry | None:
        def work(connection: Connection) -> Row | None:
            row: Row | None = connection.execute(
                "SELECT id, revision, action, content, created_at, baseline"
                " FROM content_revision WHERE id = ?",
                (revision_id,),
            ).fetchone()
            return row

        row = await self._db.run(work)
        if row is None:
            return None
        return RevisionEntry(
            id=text(row["id"]),
            revision=number(row["revision"]),
            action=cast(Action, text(row["action"])),
            content=text(row["content"]),
            created_at=instant(row["created_at"]),
            baseline=flag(row["baseline"]),
        )

    async def asset_metadata_register(self, record: AssetMetadataRecord) -> None:
        def work(connection: Connection) -> None:
            # `OR REPLACE` so that registering the same key twice stores the record
            # exactly as given, which is what the operation is specified to do, and so
            # that both implementations of this port answer identically -- the in-memory
            # fake's mapping assignment has the same effect, and a port whose two
            # implementations diverge on a case the suite does not cover is a port with
            # an undeclared behaviour.
            connection.execute(
                "INSERT OR REPLACE INTO asset_metadata"
                " (key, filename, media_type, byte_size, width, height, created_at,"
                "  derived_from)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    record.key,
                    record.filename,
                    record.media_type,
                    record.byte_size,
                    record.width,
                    record.height,
                    record.created_at.isoformat(),
                    record.derived_from,
                ),
            )

        await self._db.run(work)

    async def asset_metadata_read(self, key: str) -> AssetMetadataRecord | None:
        def work(connection: Connection) -> Row | None:
            row: Row | None = connection.execute(
                "SELECT key, filename, media_type, byte_size, width, height, created_at,"
                "       derived_from"
                " FROM asset_metadata WHERE key = ?",
                (key,),
            ).fetchone()
            return row

        row = await self._db.run(work)
        if row is None:
            return None
        return AssetMetadataRecord(
            key=text(row["key"]),
            filename=text(row["filename"]),
            media_type=text(row["media_type"]),
            byte_size=number(row["byte_size"]),
            width=optional_number(row["width"]),
            height=optional_number(row["height"]),
            created_at=instant(row["created_at"]),
            derived_from=optional_text(row["derived_from"]),
        )

    async def asset_metadata_remove(self, key: str) -> None:
        def work(connection: Connection) -> None:
            # Idempotent without a branch: a DELETE that matches nothing is a success,
            # which is what the best-effort cleanup path needs (BR22.10).
            connection.execute("DELETE FROM asset_metadata WHERE key = ?", (key,))

        await self._db.run(work)
