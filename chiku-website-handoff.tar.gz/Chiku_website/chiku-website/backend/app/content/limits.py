"""The request-body size cap, ported from `app/api/content/route.ts:11`.

    const bodyText = await request.text();
    if (bodyText.length > 1500000) return reply({error:'This update is too large.'}, 413);

`bodyText.length` is a JavaScript string length, which is a count of **UTF-16 code
units** -- not characters, not codepoints, and not UTF-8 bytes. The distinction is
invisible in ASCII and decisive outside it, and getting it wrong is silent in both
directions:

* Counting UTF-8 **bytes** rejects a body the source accepts. Fixture
  ``F6-size-astral-under-in-units``: 1,400,000 UTF-16 units but ~2.8M UTF-8 bytes ->
  the source returns **200**.
* Counting **characters** accepts a body the source rejects. Fixture
  ``F6-size-astral-over-in-units``: 1,600,000 UTF-16 units from only ~800,000
  codepoints -> the source returns **413**.

Every character outside the Basic Multilingual Plane -- emoji, historic scripts, many
CJK extension characters -- counts as two units. The owner's longest transcript is
exactly where this surfaces, and it surfaces as a rejected save with no explanation.
"""

from __future__ import annotations

# The literal from the source. Not a tunable: changing it changes observable behaviour
# at a boundary the fixtures pin.
MAX_BODY_UTF16_UNITS = 1_500_000

TOO_LARGE_MESSAGE = "This update is too large."


def utf16_length(text: str) -> int:
    """Count UTF-16 code units, the unit JavaScript's String#length reports.

    `utf-16-le` is used rather than `utf-16` because the latter emits a 2-byte byte-order
    mark, which would add one unit to every measurement.
    """
    return len(text.encode("utf-16-le")) // 2


def exceeds_body_limit(text: str) -> bool:
    """True when the source would answer 413 for this body.

    The comparison is strictly greater-than: a body of exactly 1,500,000 units passes.
    Fixture ``F6-size-at-limit`` (200) and ``F6-size-over-limit`` (413) pin both sides.
    """
    return utf16_length(text) > MAX_BODY_UTF16_UNITS
