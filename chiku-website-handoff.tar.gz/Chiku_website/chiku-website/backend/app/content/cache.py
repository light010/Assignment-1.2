"""The published-document cache. **A security parameter, not a tuning one** (BR7.1, BR24.1).

It lives in `ContentAuthority` so that invalidation never crosses a component boundary: a
second cache in a consuming component would not receive the publish invalidation, because
this one invalidates itself and knows nothing about anyone else's. Placement is what makes
invalidation a **local** operation, and a local invalidation is the only kind this system
can actually guarantee. `u5-media` consumes this cache on its public read path and holds
none of its own; consuming is not owning.

**Why the interval is a security parameter.** The cache feeds the asset-visibility test:
an asset is public **iff the literal `/api/media/<key>` appears anywhere in the serialised
published document**, and this is where that document comes from. A stale entry therefore
means an asset the owner has just unreferenced **stays public for the remaining lifetime
of the entry**. That is an authorization defect. It is not a slow page, not a stale render
and not an inconsistency a refresh fixes.

**The bound is 5 seconds, stated as a MAXIMUM.**

* **Bounded from above by exposure.** The obvious reading -- that invalidation-on-publish
  handles the real case and the interval is only a backstop -- is wrong as soon as there
  is more than one warm instance. The cache is in-process, so a publish invalidates only
  the instance that served it; every other warm instance keeps serving its own document
  until its entry expires. The interval **is** the exposure window for every instance that
  did not handle the publish. Five seconds is the largest value that still reads as
  "immediately" to an owner who unreferences an asset, publishes, and then checks.
* **Bounded from below by the hard zero-recurring-cost target.** Worst case is one
  published-document read per interval per warm instance: `86,400 / interval` reads per
  instance-day. At 5 s that is 17,280, which leaves room for two concurrently warm
  instances inside the free tier's 50,000 reads/day. At 1 s it would be 86,400, which
  breaks the target on a single instance before any other read is counted.

A deployment may choose **lower, never higher**, and **changing the value is a security
change that gets the same review as changing an authorization rule**. An interval above
the maximum is refused at construction rather than clamped: a value that was accepted and
quietly reduced would leave the operator believing a number that is not in force, and
"fail at boot, not at first request" is the rule for every required setting here.

**The cache holds exactly one entry -- the published document.** No key, no per-asset
entries. That is what makes BR24.2's invalidation unconditional.

**Time is injected.** `now` is a caller argument, as it is throughout this unit, so the
interval is exercised by advancing a value rather than by sleeping.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

#: The stated ceiling. Not a default to be tuned upward -- see the module docstring.
MAX_CACHE_INTERVAL_SECONDS = 5.0


@dataclass(frozen=True, slots=True)
class _Entry:
    payload: str
    stored_at: datetime


class PublishedDocumentCache:
    """One entry, no key, an injected clock, and a stated ceiling on its lifetime."""

    def __init__(self, *, interval_seconds: float = MAX_CACHE_INTERVAL_SECONDS) -> None:
        if interval_seconds < 0:
            raise ValueError(
                f"The published-document cache interval cannot be negative: {interval_seconds}"
            )
        if interval_seconds > MAX_CACHE_INTERVAL_SECONDS:
            raise ValueError(
                "The published-document cache interval is a security parameter with a stated "
                f"maximum of {MAX_CACHE_INTERVAL_SECONDS} seconds; a deployment may choose "
                f"lower, never higher. Refusing {interval_seconds}."
            )
        self._interval_seconds = interval_seconds
        self._entry: _Entry | None = None

    @property
    def interval_seconds(self) -> float:
        return self._interval_seconds

    def read(self, now: datetime) -> str | None:
        """The cached published document, or absence once the interval has elapsed."""
        entry = self._entry
        if entry is None:
            return None
        if (now - entry.stored_at).total_seconds() >= self._interval_seconds:
            self._entry = None
            return None
        return entry.payload

    def store(self, payload: str, now: datetime) -> None:
        """Replace the one entry. A second document does not become a second entry."""
        self._entry = _Entry(payload=payload, stored_at=now)

    def invalidate(self) -> None:
        """Unconditional, because there is one entry and it has no key.

        Invalidating an empty cache is a success, not an error: the caller's obligation is
        that nothing stale survives, and there is nothing to report if nothing was there.
        """
        self._entry = None
