"""Recoverable versus corrupting. **HAZARD module -- FR8.3, BR8.1-BR8.5, ADR-006.**

The rule that used to live in the browser. The editor holds the bytes and renders the
verdict; the classification is a correctness rule and lives here.

## The port implements the rule as written, not as the source behaves (D9)

The source allowlists four zod issue codes -- `too_small`, `too_big`, `custom`,
`invalid_format` -- and discards the draft if **any** issue falls outside that list. Two
defects compound: `invalid_format` is a zod **v4** code while the installed package
resolves to the **v3** API, so that entry **can never match**; and `invalid_enum_value`,
which v3 does emit, is **absent**. Net effect: **one bad enum discards the owner's entire
recovered draft**, along with every other unsaved edit in that record -- while the
source's own comment states the opposite intent (*"Retain these recoverable edits, but
reject malformed field types or shapes."*).

Carried with its hedge: this is **a latent defect with a proven mechanism, not a confirmed
user-visible failure**. The scan demonstrated the code mismatch empirically but could not
exercise the editor to observe a discarded draft. **The port's behaviour does not depend
on resolving that**, because the requirement specifies the intended rule rather than the
observed one.

## BR8.5 -- re-expressed in this validator's taxonomy, never by copying code strings

Pydantic's error types share no names with either zod version. Copying the four strings
across would carry the inherited bug forward **and add a second one**. The rule is stated
in terms of *what went wrong with the value*, which is portable; code names are not.

| What went wrong with the value | Class |
|---|---|
| Below a minimum length or size | **recoverable** |
| Above a maximum length or size | **recoverable** |
| A custom or refinement predicate failed | **recoverable** |
| A string format or pattern check failed | **recoverable** |
| **Not a member of an enumerated set** | **recoverable** |
| Wrong type for the declared field | corrupting |
| A required key is missing | corrupting |
| Not an object or array where one is required | corrupting |
| Not parseable as JSON at all | corrupting |

**The enumerated-set row is the whole hazard in one line.** Every other row would be
classified the same way by anyone reasoning from first principles. The enum row is the one
a reasonable implementer puts on the *other* side -- "a value that is not a member of the
enum is not a valid value of that type, so the record is malformed" -- and that reasoning
is exactly the source's bug. The failure is invisible in normal use precisely because the
enum fields are edited through select and radio controls: it bites on a draft written by
an older schema version or through the browser-tool path, which is exactly the case
recovery exists for.

## A verdict is DATA; a failure is an EXCEPTION (BR8.7)

When inspect is **unreachable**, the editor **holds** the draft and shows an
unavailable-and-retry state -- a third state that is not "discard it". So this module
returns `CorruptedRecord` and never raises it, and never catches an error it did not
expect: an over-broad `except` here would turn *"we could not check"* into *"throw your
work away"*.

## A recorded open question, preserved rather than silently closed

This path accepts a stored draft up to **6,000,000** characters while the save path
rejects anything over **1,500,000**. A draft between those bounds is **restorable into the
editor and unsavable from it** -- every save attempt fails as too-large, including every
autosave. The two limits were chosen independently in the source and nothing relates them.
Aligning them would change observable behaviour under an otherwise absolute parity rule,
and warning at recovery time adds product copy and a new state to the editor. **Neither is
chosen here**; both limits are reproduced and the window is recorded by a test.

**One stated divergence.** `savedAt` is checked with `datetime.fromisoformat`, where the
source uses `Date.parse`. Every timestamp the editor writes is `Date.toISOString()` output
and parses identically; a human-written form such as `March 5, 2026`, which `Date.parse`
accepts, is refused here.
"""

from __future__ import annotations

import json
import uuid
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Literal, cast

from pydantic import ValidationError
from pydantic_core import ErrorDetails

from app.content.defaults import links_for_id, topic_for_id
from app.content.limits import utf16_length
from app.content.schema import ContentDocument
from app.content.seed import seed_document

type Classification = Literal["recoverable", "corrupting"]

# The ceiling this path applies. **Not the save cap** -- see the open question above.
MAX_RECOVERY_UTF16_UNITS = 6_000_000

# The five recoverable rows of BR8.3's table, in Pydantic's vocabulary. Every member is a
# type this validator can actually emit; an entry that can never match is precisely what
# made `invalid_format` useless in the source, so the suite checks that against
# `pydantic_core.list_all_errors()`.
RECOVERABLE_ERROR_TYPES: frozenset[str] = frozenset(
    {
        # ...below a minimum length or size
        "too_short",
        "string_too_short",
        "greater_than",
        "greater_than_equal",
        # ...above a maximum length or size
        "too_long",
        "string_too_long",
        "less_than",
        "less_than_equal",
        # ...a custom or refinement predicate failed
        "value_error",
        # ...a string format or pattern check failed
        "string_pattern_mismatch",
        # ...NOT A MEMBER OF AN ENUMERATED SET. The row the source gets wrong.
        "enum",
        "literal_error",
    }
)

COLLECTIONS = ("achievements", "research", "publications", "journey", "news")

_UNUSABLE = "The saved draft could not be read."
_ENVELOPE = "The saved draft is not a recovery record."


@dataclass(frozen=True, slots=True)
class RecoveryIssue:
    """One validation failure, with the class BR8.3 puts it in.

    `error_type` is carried so a caller -- and the suite -- can see *which* outcome was
    classified, not merely the verdict. A classification whose keys the validator never
    emits looks identical from the verdict alone.
    """

    path: list[str | int]
    message: str
    error_type: str
    classification: Classification


@dataclass(frozen=True, slots=True)
class RecoverableDraft:
    """Keep the draft: repaired against schema defaults, with the issues for review.

    `content` is the owner's document with **the invalid values still in it** -- that is
    the point. Freshly added schema fields are filled from the seed so a legacy record
    gains them, while invalid text stays editable so the owner can fix it.
    """

    content: dict[str, Any]
    revision: int
    saved_at: str
    issues: tuple[RecoveryIssue, ...]


@dataclass(frozen=True, slots=True)
class CorruptedRecord:
    """The record is unusable. A **returned verdict**, never a raised exception."""

    issues: tuple[RecoveryIssue, ...]


type RecoveryVerdict = RecoverableDraft | CorruptedRecord


def classify_error_type(error_type: str) -> Classification:
    """BR8.3, stated as what went wrong with the value rather than as a code name."""
    if error_type in RECOVERABLE_ERROR_TYPES:
        return "recoverable"
    return "corrupting"


def _issue(path: list[str | int], message: str, error_type: str) -> RecoveryIssue:
    return RecoveryIssue(
        path=path,
        message=message,
        error_type=error_type,
        classification=classify_error_type(error_type),
    )


def _classified(detail: ErrorDetails) -> RecoveryIssue:
    return _issue(list(detail["loc"]), detail["msg"], detail["type"])


def _is_integer(value: object) -> bool:
    """`Number.isInteger` semantics: a boolean is not a number, and `3.0` is an integer."""
    if isinstance(value, bool):
        return False
    if isinstance(value, int):
        return True
    return isinstance(value, float) and value.is_integer()


def _is_instant(value: str) -> bool:
    try:
        datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return False
    return True


def _blank_item() -> dict[str, Any]:
    """The source's `newItem()`: a blank record under a fresh identity."""
    item_id = str(uuid.uuid4())
    return {
        "id": item_id,
        "title": "",
        "subtitle": "",
        "description": "",
        "year": "",
        "image": "",
        "imageAlt": "",
        "imageSources": [],
        "focalX": 50,
        "focalY": 50,
        "link": "",
        "code": "",
        "dataset": "",
        "video": "",
        "captions": "",
        "transcript": "",
        "featured": False,
        "citations": "",
        "citationsAsOf": "",
        "researchTopic": topic_for_id(item_id),
        "researchIds": links_for_id(item_id),
        "contribution": "",
        "approach": "",
        "outcome": "",
    }


def _present(raw: Mapping[str, Any], key: str, fallback: Any) -> Any:
    """`??` semantics: both an absent key and an explicit null fall through."""
    value = raw.get(key)
    if value is None:
        return fallback
    return value


def _repair_item(item: Any) -> dict[str, Any]:
    raw = cast(Mapping[str, Any], item)
    repaired = {**_blank_item(), **raw}
    repaired["researchTopic"] = _present(raw, "researchTopic", topic_for_id(raw.get("id")))
    repaired["researchIds"] = list(_present(raw, "researchIds", links_for_id(raw.get("id"))))
    return repaired


def repair(candidate: Mapping[str, Any]) -> dict[str, Any]:
    """Merge the candidate over the seed so freshly added defaults survive a failed parse.

    Validation errors must not discard schema fields that were added after this record was
    written: a legacy local record receives the new fields, while its invalid text remains
    editable. Nothing here re-validates and nothing here corrects a value.
    """
    seed = seed_document().model_dump(by_alias=True)
    repaired: dict[str, Any] = {**seed, **candidate}
    for group in ("scene", "scholarHighlights", "sections"):
        repaired[group] = {**seed[group], **candidate.get(group, {})}
    repaired["copy"] = {
        name: {**fields, **candidate.get("copy", {}).get(name, {})}
        for name, fields in seed["copy"].items()
    }
    for collection in COLLECTIONS:
        repaired[collection] = [
            _repair_item(item) for item in candidate.get(collection, seed[collection])
        ]
    return repaired


def inspect_draft(raw: str) -> RecoveryVerdict:
    """Classify a recovered draft record. Returns a verdict; raises only on a real failure."""
    if not raw or utf16_length(raw) > MAX_RECOVERY_UTF16_UNITS:
        return CorruptedRecord((_issue([], _UNUSABLE, "record_unusable"),))

    try:
        record = json.loads(raw)
    except json.JSONDecodeError:
        return CorruptedRecord((_issue([], _UNUSABLE, "json_invalid"),))

    if not isinstance(record, dict):
        return CorruptedRecord((_issue([], _ENVELOPE, "model_type"),))

    revision = record.get("revision")
    saved_at = record.get("savedAt")
    if not _is_integer(revision) or not isinstance(saved_at, str) or not _is_instant(saved_at):
        return CorruptedRecord((_issue([], _ENVELOPE, "record_unusable"),))

    candidate = record.get("content")
    try:
        document = ContentDocument.model_validate(candidate)
    except ValidationError as failure:
        issues = tuple(_classified(detail) for detail in failure.errors())
        corrupting = [issue for issue in issues if issue.classification == "corrupting"]
        if corrupting:
            return CorruptedRecord(issues)
        # Every issue is one an owner produces by typing, so the draft is kept, repaired
        # against schema defaults, and presented for review.
        return RecoverableDraft(
            content=repair(cast(Mapping[str, Any], candidate)),
            revision=int(cast(int, revision)),
            saved_at=saved_at,
            issues=issues,
        )

    return RecoverableDraft(
        content=document.model_dump(by_alias=True),
        revision=int(cast(int, revision)),
        saved_at=saved_at,
        issues=(),
    )
