"""`ContentAuthority` -- the content operations, and the order they run in.

**This unit raises; it never composes a response.** No status code, no sentence, no
envelope is built here: the four taxonomy members in `app.errors` are raised and `HttpApi`
renders them (BR10.3). The corollary matters as much -- an internal error is **never**
dressed as one of the four to get a nicer status. It belongs in the catch-all, where it is
logged with a traceback and answered **503, not 500**, which is what the source returns on
all four routes.

**Persistence is reached only through `ContentStore`**, which validates nothing and
defaults nothing. Everything the schema does happens here.

## The check order is part of the rule

Steps 1 and 2 -- origin and session -- are transport concerns and belong to `HttpApi`.
Steps 3 to 9 run **here, in this order**, because the order decides which status a
multiply-invalid request receives:

3. decoded body over the cap -> too large (BR4.20, **after the read and before the parse**)
4. JSON parse failure -> invalid, **distinctly** from a validation failure
5. body falsy, not an object, or an array -> invalid
6. **content schema validation -> invalid carrying per-field issues** (BR4.6)
7. envelope validation -> invalid **without** issues (BR10.12)
8. the combined write
9. a conflict signal -> conflict, **with the current state alongside** (BR4.7)

**Step 6 runs before step 7** (BR10.11): a request with both a malformed document and a
bad revision returns the *content* error, which is the one the editor can highlight.
Reordering them silently changes what the owner sees.

The rules for steps 4, 5 and 7 are declared by `HttpApi` and enforced here, because here
is where the decoded body first meets the schema.
"""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any

from pydantic import ValidationError

from app.content.cache import PublishedDocumentCache
from app.content.limits import TOO_LARGE_MESSAGE, exceeds_body_limit
from app.content.recovery import RecoveryVerdict, inspect_draft
from app.content.schema import (
    ContentDocument,
    ContentMetadata,
    ContentStateView,
    SaveOutcome,
    instant_to_wire,
    serialise,
)
from app.content.statements import combined_write, mint_mutation_token
from app.content.store import Action, CommitConflict, ContentState, ContentStore, RetentionPolicy
from app.errors import CHECK_FIELDS, INVALID_SAVE, UNREADABLE_UPDATE, Conflict, Invalid, TooLarge

# `Number.MAX_SAFE_INTEGER`. A base revision must be BELOW it, not equal to it.
MAX_SAFE_INTEGER = 9_007_199_254_740_991

ACTIONS: tuple[Action, ...] = ("draft", "publish")


def _issues(failure: ValidationError) -> list[dict[str, Any]]:
    """BR10.2's shape: `path` and `message`, **not** Pydantic's `loc` and `msg`.

    The editor builds a field id from `path` and highlights it. With the defaults it
    appears to work -- the request still fails with the right status -- and nothing
    highlights.
    """
    return [{"path": list(detail["loc"]), "message": detail["msg"]} for detail in failure.errors()]


def _instant(moment: datetime | None) -> str | None:
    """`null` is a value on this wire, not an absence: it is how "never published" reads."""
    if moment is None:
        return None
    return instant_to_wire(moment)


def _safe_integer(value: object) -> bool:
    """`Number.isSafeInteger`: a boolean is not a number, and `3.0` is an integer."""
    if isinstance(value, bool):
        return False
    if isinstance(value, int):
        return True
    return isinstance(value, float) and value.is_integer()


class ContentAuthority:
    """The document in draft and published form, and every operation over it."""

    def __init__(
        self,
        store: ContentStore,
        *,
        retention: RetentionPolicy,
        cache: PublishedDocumentCache | None = None,
    ) -> None:
        self._store = store
        # An ARGUMENT, never a constant here (BR5.9). `RevisionLedger` owns the policy and
        # performs no write; this component applies it inside the one combined write.
        self._retention = retention
        # The cache lives HERE so that invalidation never crosses a component boundary
        # (BR7.1). A second cache in a consuming component would miss the invalidation and
        # leave an asset the owner has just unreferenced public for its own lifetime.
        self._cache = PublishedDocumentCache() if cache is None else cache

    # ----------------------------------------------------------------------------- #
    # Read content -- owner
    # ----------------------------------------------------------------------------- #

    async def read_state(self) -> ContentStateView:
        """Both documents plus the revision, both timestamps and the change flag.

        **A read never writes, never locks and never bootstraps** (BR4.1). When no
        document exists the store synthesises the seeded state at revision 0 with both
        timestamps null, and nothing is created: a read that created the document would
        defeat the bootstrap's revision-0 guard and let a client at revision 5 resurrect a
        deleted one.

        Parsing both documents through the schema is what applies the content-carrying
        defaults on the read path -- **every time**, not once on write (BR9.2).
        """
        state = await self._store.read_state()
        draft, published = self._parsed(state)
        return ContentStateView(
            draft=draft,
            published=published,
            revision=state.revision,
            updated_at=_instant(state.updated_at),
            published_at=_instant(state.published_at),
            has_unpublished_changes=draft != published,
        )

    # ----------------------------------------------------------------------------- #
    # Read content -- public
    # ----------------------------------------------------------------------------- #

    async def read_published(self, *, now: datetime) -> ContentDocument:
        """The **published document only**. No draft content, in any field, at any time.

        This route does not exist in the source -- it returns 404 there -- so its behaviour
        is specified rather than preserved and has no parity fixture. What it must not do
        is still a hard rule (BR24.3, realising NFR11), and it is checked by its own test.

        The document is re-parsed on every call, which is what applies the content-carrying
        defaults on the public path as much as on the owner path (BR9.2).
        """
        return ContentDocument.model_validate(json.loads(await self.published_payload(now=now)))

    async def published_payload(self, *, now: datetime) -> str:
        """The serialised published document, which is what the visibility test reads.

        An asset is public **iff its literal media URL appears anywhere in this string**
        (BR7.4, owned by `MediaDelivery`). It is the **normalised** document rather than
        the stored bytes, so a media URL sitting in a defaulted field is still visible to
        that test -- the substring relation is a security check and reading a narrower
        string would make it answer "not public" for something that is.
        """
        cached = self._cache.read(now)
        if cached is not None:
            return cached
        state = await self._store.read_state()
        payload = serialise(ContentDocument.model_validate(json.loads(state.published)))
        self._cache.store(payload, now)
        return payload

    # ----------------------------------------------------------------------------- #
    # Save or publish
    # ----------------------------------------------------------------------------- #

    async def save(self, *, body: str, now: datetime) -> SaveOutcome:
        """Steps 3 to 9, in that order. `body` is the decoded request text."""
        # Step 3. The cap counts UTF-16 code units and is checked AFTER the body is fully
        # read and BEFORE the parse (BR4.22): moving it changes which status a too-large
        # malformed body receives, which an owner can reach by pasting.
        if exceeds_body_limit(body):
            raise TooLarge(TOO_LARGE_MESSAGE)

        # Step 4. A parse failure is a DIFFERENT sentence from a validation failure.
        try:
            payload = json.loads(body)
        except json.JSONDecodeError:
            raise Invalid(UNREADABLE_UPDATE) from None

        # Step 5. Falsy, not an object, or an array.
        if not payload or not isinstance(payload, dict):
            raise Invalid(INVALID_SAVE)

        # Step 6. Authoritative validation, in the backend, before anything is persisted.
        # The browser's generated mirror is for responsiveness only and is never the
        # enforcement.
        try:
            document = ContentDocument.model_validate(payload.get("content"))
        except ValidationError as failure:
            raise Invalid(CHECK_FIELDS, issues=_issues(failure)) from None

        # Step 7. The envelope, as ONE predicate. It runs after step 6 on purpose.
        revision = payload.get("revision")
        action = payload.get("action")
        autosave = payload.get("autosave")
        if (
            not _safe_integer(revision)
            or not isinstance(revision, int | float)
            or revision < 0
            or revision >= MAX_SAFE_INTEGER
            or action not in ACTIONS
            or (autosave is not None and not isinstance(autosave, bool))
            or (autosave is True and action != "draft")
        ):
            raise Invalid(INVALID_SAVE)

        # Step 8. One call, one caller, one transaction, six effects. The token is minted
        # fresh per request and guards the side effects, whose condition is not unique to
        # this writer.
        plan = combined_write(
            content=serialise(document),
            base_revision=int(revision),
            action=action,
            mutation_token=mint_mutation_token(),
            retention=self._retention,
            now=now,
        )
        result = await self._store.commit(**plan.arguments())

        # Step 9. A conflict carries the CURRENT STATE alongside the error, so the caller
        # can reconcile; the caller's edits are untouched.
        if isinstance(result, CommitConflict):
            current = await self._store.read_state()
            raise Conflict(**self._metadata(current).model_dump(by_alias=True))

        # Step 10. A successful publish invalidates the cached published document
        # SYNCHRONOUSLY, inside the operation that succeeded and before it returns
        # (BR24.2), so the instance that handled the publish serves the new document on
        # the very next request. Without this, even the publishing instance keeps serving
        # the previous document for the whole interval -- which turns BR24.1's bound from
        # a residual exposure into the normal one, and leaves an asset the owner has just
        # unreferenced public. Unconditional: the cache holds one entry and has no key.
        if plan.publishing:
            self._cache.invalidate()

        return SaveOutcome(
            **self._metadata(result).model_dump(by_alias=True),
            published=plan.publishing,
        )

    # ----------------------------------------------------------------------------- #
    # Inspect a recovered draft
    # ----------------------------------------------------------------------------- #

    async def inspect_recovered_draft(self, raw: str) -> RecoveryVerdict:
        """Classify a recovered draft. A verdict is returned; a failure is raised.

        A thin delegate on purpose: the classification is pure, and keeping it that way is
        what lets the hazard be exercised branch by branch without a store, a clock or a
        request.
        """
        return inspect_draft(raw)

    # ----------------------------------------------------------------------------- #
    # Shared
    # ----------------------------------------------------------------------------- #

    def _metadata(self, state: ContentState) -> ContentMetadata:
        """The four values a read and a write both report.

        `hasUnpublishedChanges` is **computed here, on every call, by comparison** -- it
        has no column and no flag the write path maintains (BR4.2). A maintained flag
        drifts from the documents it describes and nothing would reveal the drift.

        Both documents are parsed through the schema, which is what applies the
        content-carrying defaults on the **read** path (BR9.2).
        """
        draft, published = self._parsed(state)
        return ContentMetadata(
            revision=state.revision,
            updated_at=_instant(state.updated_at),
            published_at=_instant(state.published_at),
            has_unpublished_changes=draft != published,
        )

    def _parsed(self, state: ContentState) -> tuple[ContentDocument, ContentDocument]:
        """Both stored documents, re-validated and re-transformed on every read (BR9.2).

        The comparison that follows is **by value**. The source compared serialised JSON,
        which is key-order sensitive; here both sides are produced by the same schema, so
        the two are equivalent and value comparison does not depend on key order.
        """
        return (
            ContentDocument.model_validate(json.loads(state.draft)),
            ContentDocument.model_validate(json.loads(state.published)),
        )
