"""The combined write, built as data. **HAZARD module -- FR4.5, BR4.8-BR4.19.**

**The pure-versus-execute split survives the port.** The source expresses this write as
seven statements in one batch, built by `contentWriteStatements()` and run by a thin
`writeContent()`. That factoring is what makes the batch inspectable -- every guard is a
value you can read and assert on rather than a condition buried inside an adapter -- and
flattening it loses the property. Here the builder is this module and the executor is
`ContentStore.commit`.

**Nothing in this module performs I/O**, and that is deliberate: the defence below is
timing-dependent and cannot be reproduced by single-user testing, so it has to be
assertable without concurrency as well as with it.

## The two guards defend different things

* **`revision` (the compare-and-set) protects the CONTENT WRITE.** It answers *"is the
  caller's view of the document still current?"*
* **`mutation_token` protects the SIDE EFFECTS.** It answers *"is the row in its current
  state because **I** put it there?"*

The second is **not redundant**, because statements 4-6 are guarded on
`revision = next_revision` -- a value that is **not unique to this writer**:

> The document sits at **revision 5**. Writers **A** and **B** both load revision 5.
> **B** commits first: the row advances to **revision 6**, stamped with **B's** token.
> **A's** compare-and-set (`WHERE revision = 5`) matches nothing and A correctly gets a
> conflict. **But A's statements 4-6 test `revision = 6`, because A's `next_revision` is
> also 6 -- and B's write satisfies exactly that condition.**

Without the token, statement 4 inserts a history row keyed by **A's** mutation id
carrying **B's** content under **A's** action -- a phantom revision nobody ever saved --
and statements 5 and 6 run **A's** retention pass off the back of **B's** write, pruning
history A had no right to prune and potentially deleting a revision B had just created.

Adding the token makes all three guards test **identity rather than position**. A stale
writer's `next_revision` may collide with the winner's `revision`; its random token will
not. This is a classic **ABA defence**: the revision counter alone cannot distinguish
"unchanged" from "changed to a coincidentally equal value by someone else".

**The token is not optional and not an optimisation** (BR4.14), and it does **not** depend
on transactional isolation (BR4.15). Re-expressing this as "compare-and-set on revision,
then insert history, then prune" without it reintroduces both defects, and they will not
appear in single-user testing -- which is the entire reason this is written out.

**What breaks silently:** nothing errors and nothing logs. The history list grows a row
the owner never saved, or loses a row it should have kept.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from app.content.store import (
    BASELINE_DRAFT_ID,
    BASELINE_PUBLISHED_ID,
    Action,
    RetentionPolicy,
)


@dataclass(frozen=True, slots=True)
class Guard:
    """What an effect tests before it fires.

    The two revision fields are **different questions** and collapsing them is the whole
    hazard: `stored_revision` is what the row must currently hold, `claimed_revision` is
    what the CALLER must have asserted. Only the bootstrap tests the second, and that is
    what stops a client at revision 5 from resurrecting a deleted document.
    """

    stored_revision: int | None = None
    claimed_revision: int | None = None
    mutation_token: str | None = None
    #: insert-if-absent / on-conflict-do-nothing. What makes a capture succeed at most
    #: once in the document's lifetime, and a concurrent bootstrap harmless.
    idempotent: bool = False


@dataclass(frozen=True, slots=True)
class WriteEffect:
    """One statement of the batch, with the guard that decides whether it fires."""

    name: str
    guard: Guard
    #: The identity an insert writes: a baseline literal, or the mutation token itself.
    entry_id: str | None = None
    #: Which action a prune applies to. Retention is counted per action, independently.
    action: Action | None = None
    #: How many entries of that action survive. An argument, never a constant (BR5.9).
    keep: int | None = None


@dataclass(frozen=True, slots=True)
class CombinedWrite:
    """The whole batch as a value: six effects plus the bootstrap, and their guards."""

    content: str
    base_revision: int
    next_revision: int
    action: Action
    mutation_token: str
    retention: RetentionPolicy
    now: datetime
    #: `published` and `published_at` move only when this is true. The two conditional
    #: expressions ARE how publish is expressed; collapsing them publishes on every save.
    publishing: bool
    effects: tuple[WriteEffect, ...]

    def arguments(self) -> dict[str, Any]:
        """Exactly what `ContentStore.commit` takes. One call, one transaction, all-or-none."""
        return {
            "content": self.content,
            "base_revision": self.base_revision,
            "action": self.action,
            "mutation_token": self.mutation_token,
            "retention": self.retention,
            "now": self.now,
        }


def mint_mutation_token() -> str:
    """A fresh random identity per request (source: `crypto.randomUUID()`).

    Freshness is the whole defence: a reused token would let a second write satisfy the
    first's identity guard, which is the condition the token exists to make impossible.
    """
    return str(uuid.uuid4())


def combined_write(
    *,
    content: str,
    base_revision: int,
    action: Action,
    mutation_token: str,
    retention: RetentionPolicy,
    now: datetime,
) -> CombinedWrite:
    """Build the batch. Pure: it reads nothing, writes nothing and mints nothing."""
    next_revision = base_revision + 1
    publishing = action == "publish"

    # The guard statements 1-3 share: the stored row must still be where the caller left
    # it. A stale writer therefore captures nothing and changes nothing.
    current = Guard(stored_revision=base_revision)
    # The guard statements 4-6 share: the row must be at the revision THIS write produced
    # **and** carry THIS write's identity. The revision alone is not unique to the writer.
    mine = Guard(stored_revision=next_revision, mutation_token=mutation_token)

    effects = (
        WriteEffect(
            name="bootstrap",
            guard=Guard(claimed_revision=0, idempotent=True),
        ),
        WriteEffect(
            name="capture-published-baseline",
            guard=Guard(stored_revision=base_revision, idempotent=True),
            entry_id=BASELINE_PUBLISHED_ID,
            action="publish",
        ),
        WriteEffect(
            name="capture-draft-baseline",
            guard=Guard(stored_revision=base_revision, idempotent=True),
            entry_id=BASELINE_DRAFT_ID,
            action="draft",
        ),
        WriteEffect(name="compare-and-set", guard=current),
        WriteEffect(name="record-revision", guard=mine, entry_id=mutation_token, action=action),
        WriteEffect(name="prune-drafts", guard=mine, action="draft", keep=retention.draft_keep),
        WriteEffect(
            name="prune-publishes", guard=mine, action="publish", keep=retention.publish_keep
        ),
    )

    return CombinedWrite(
        content=content,
        base_revision=base_revision,
        next_revision=next_revision,
        action=action,
        mutation_token=mutation_token,
        retention=retention,
        now=now,
        publishing=publishing,
        effects=effects,
    )
