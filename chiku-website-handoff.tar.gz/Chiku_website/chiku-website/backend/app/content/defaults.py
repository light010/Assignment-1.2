"""The content-carrying defaults. **HAZARD module -- FR9.2, BR9.1-BR9.3.**

Ported from `madhavi-tripathi/app/research-identity.ts` and the `initialResearchLinks` map
in `app/site-copy.ts`.

**This is logic, not a field default, and it runs on EVERY PARSE -- which includes every
read out of storage.** A model declaration cannot express it, which is exactly why a
type-correct port is behaviourally wrong: `research_topic: Topic | None = None` produces
`None` where the original produces a real topic, and `research_ids: list[str] = []`
produces the empty list where the original produces the seeded editorial links.

**What breaks when this is wrong is invisible.** Three identical slate research cards
instead of three distinct ones; zero related papers on every card; a publications topic
filter that returns nothing for every theme; and the editor's "Card identity" control
showing `general` for cards the owner never set, rewriting their identity on the next
save. The page renders cleanly throughout, and a port doing all of that passes `ruff`,
`mypy --strict`, `tsc`, the Compose end-to-end flow and 100% *line* coverage.

**The operator is `??`, not `||` -- test ABSENCE, never truthiness.** For `researchTopic`
the difference is invisible (no falsy value is a member of the set). For `researchIds` it
is destructive: an explicitly emptied list must stay empty, and a falsy-test port
resurrects links the owner deliberately deleted, on **every read**, so the owner cannot
clear them at all and there is no error to report.

**Why the maps exist.** Both fields were added *after* the original cards and publications
were already published, so their stored documents carry neither. Rather than a data
migration, the item's `id` infers them. The source comment states the intent verbatim:
*"Existing published cards acquire a stable identity without changing their text or
order."* A fresh install depends on them entirely, because the seeded document is
constructed *through* them.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal

# The four topics, in the source's declaration order (`researchTopics`). The order is
# part of the enumerated set's identity: the editor renders the control from it.
type Topic = Literal["materials", "ultrasound", "photoacoustic", "general"]

RESEARCH_TOPICS: tuple[Topic, ...] = ("materials", "ultrasound", "photoacoustic", "general")

# The floor, reached only after the map misses. Never the first answer.
FALLBACK_TOPIC: Topic = "general"

# `originalTopics` in full (`app/research-identity.ts:11-18`). These three ids are the
# research cards that existed before `researchTopic` did.
ORIGINAL_TOPICS: Mapping[str, Topic] = {
    "nano-materials": "materials",
    "ultrasound-imaging": "ultrasound",
    "photoacoustics": "photoacoustic",
}

# `initialResearchLinks` in full (`app/site-copy.ts:37-43`). **The values are research-CARD
# ids -- the same ids `ORIGINAL_TOPICS` keys on -- and NOT topic enum values.** Two
# vocabularies that look alike; confusing them empties the filter silently.
INITIAL_RESEARCH_LINKS: Mapping[str, tuple[str, ...]] = {
    "breast-imaging-2026": ("photoacoustics",),
    "ultrasound-coherence-2025": ("ultrasound-imaging",),
    "mucin-cus-2025": ("nano-materials", "photoacoustics"),
    "nanoflakes-2024": ("nano-materials",),
    "nanohybrids-2023": ("nano-materials", "photoacoustics"),
}

# The two keys, in both spellings. `populate_by_name` means a model can also be built from
# the Python name, and absence has to be detected in whichever spelling the caller used --
# otherwise constructing an item in Python would silently re-run the map over a value the
# caller supplied.
WIRE_TOPIC_KEY = "researchTopic"
PYTHON_TOPIC_KEY = "research_topic"
WIRE_LINKS_KEY = "researchIds"
PYTHON_LINKS_KEY = "research_ids"


def topic_for_id(item_id: object) -> Topic:
    """The id map, then the floor. Never `None`, and never the floor before the map."""
    if not isinstance(item_id, str):
        return FALLBACK_TOPIC
    return ORIGINAL_TOPICS.get(item_id, FALLBACK_TOPIC)


def links_for_id(item_id: object) -> list[str]:
    """The seeded editorial linkage, keyed by publication id; otherwise the empty list.

    A **fresh** list each time: a shared one would let one item's edit reach another's.
    """
    if not isinstance(item_id, str):
        return []
    return list(INITIAL_RESEARCH_LINKS.get(item_id, ()))


def apply_content_carrying_defaults(row: Mapping[str, Any]) -> dict[str, Any]:
    """Resolve an item's two content-carrying fields, **by absence of the key**.

    Called before field validation so that absence is still visible -- once a field has a
    declared default, "absent" and "defaulted" are indistinguishable. A present value is
    left exactly as it is, including a present-but-empty list and including a value that
    will go on to fail validation: this function supplies what is missing and repairs
    nothing.

    The row is never mutated; the caller's mapping is left alone.
    """
    resolved = dict(row)
    item_id = resolved.get("id")
    if WIRE_TOPIC_KEY not in resolved and PYTHON_TOPIC_KEY not in resolved:
        resolved[WIRE_TOPIC_KEY] = topic_for_id(item_id)
    if WIRE_LINKS_KEY not in resolved and PYTHON_LINKS_KEY not in resolved:
        resolved[WIRE_LINKS_KEY] = links_for_id(item_id)
    return resolved
