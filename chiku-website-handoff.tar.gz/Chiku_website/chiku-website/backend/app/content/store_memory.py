"""The in-memory `ContentStore`. **A second real implementation, not a mock.**

Its whole job is to be the second implementation that proves the conformance suite tests
the **port** rather than SQLite (BR22.4). It holds the same shapes, the same nullability,
the same identity columns and the same ordering guarantees; the only permitted difference
is durability across a process boundary.

**It computes the order rather than inheriting it** (BR22.3). A fake whose container
happens to be insertion-ordered passes every ordering assertion without ever computing an
order -- while the real adapter fails them. That is the exact inversion of what the
two-implementation rule exists to catch, so `list_revisions` below sorts explicitly, in
three passes, and the retention selection reproduces the tie-break-free ordering of
BR4.19 rather than repairing it.

`MemoryContentStorage` is separate from the store for the same reason a database file is
separate from an adapter: several conformance assertions need **a second, independent
handle over the same storage**, and a store that owned its own dictionaries could not
offer one.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from app.content.store import (
    BASELINE_DRAFT_ID,
    BASELINE_PUBLISHED_ID,
    CONFLICT,
    Action,
    AssetMetadataRecord,
    CommitResult,
    ContentState,
    RetentionPolicy,
    RevisionEntry,
    RevisionSummary,
)


@dataclass
class DocumentRow:
    """The singleton, with the same columns and the same nullability as the table."""

    draft: str
    published: str
    revision: int
    updated_at: datetime
    published_at: datetime | None
    last_mutation: str | None


@dataclass
class RevisionRow:
    """One revision entry. `baseline` is a real boolean here; SQLite stores an integer."""

    id: str
    revision: int
    action: Action
    content: str
    created_at: datetime
    baseline: bool


@dataclass
class MemoryContentStorage:
    """The storage every handle opened over it shares. The fake's equivalent of a file."""

    document: DocumentRow | None = None
    revisions: dict[str, RevisionRow] = field(default_factory=dict)
    assets: dict[str, AssetMetadataRecord] = field(default_factory=dict)


class InMemoryContentStore:
    """`ContentStore` over a `MemoryContentStorage`."""

    def __init__(self, storage: MemoryContentStorage, *, seed: str, listing_cap: int) -> None:
        self._storage = storage
        self._seed = seed
        self._listing_cap = listing_cap

    async def read_state(self) -> ContentState:
        document = self._storage.document
        if document is None:
            # BR4.1: synthesise and write nothing. No lazily created row, and in
            # particular no `updated_at` invented to fill a column.
            return ContentState(
                draft=self._seed,
                published=self._seed,
                revision=0,
                updated_at=None,
                published_at=None,
            )
        return ContentState(
            draft=document.draft,
            published=document.published,
            revision=document.revision,
            updated_at=document.updated_at,
            published_at=document.published_at,
        )

    async def commit(
        self,
        *,
        content: str,
        base_revision: int,
        action: Action,
        mutation_token: str,
        retention: RetentionPolicy,
        now: datetime,
    ) -> CommitResult:
        """The six effects, all-or-none.

        Atomicity here is structural rather than transactional: every effect is computed
        against **working copies**, and the storage is replaced only once all six have
        succeeded. There is no `await` anywhere between the guard and the assignment, so
        a concurrent task cannot be scheduled into the middle of the write and observe a
        half-applied state.

        The mutation token has no work to do in this implementation -- nothing can
        interleave -- and it is carried and stamped anyway. BR4.14: dropping it because
        "the transaction already serialises the writes" is the argument the rule exists
        to refuse, and an implementation that quietly omitted it would still pass every
        test in the suite while diverging from the contract it is meant to certify.
        """
        storage = self._storage
        document = storage.document
        revisions = dict(storage.revisions)

        # Effect 0 -- bootstrap, under both guards (BR4.8).
        if base_revision == 0 and document is None:
            document = DocumentRow(
                draft=self._seed,
                published=self._seed,
                revision=0,
                updated_at=now,
                published_at=None,
                last_mutation=None,
            )

        # Effect 3's guard, evaluated up front: it is the same `revision = base_revision`
        # condition the baseline captures are gated on, so a stale writer captures
        # nothing and writes nothing.
        if document is None or document.revision != base_revision:
            return CONFLICT

        # Effects 1 and 2 -- the two permanent baselines, once ever, under fixed
        # identities, capturing the state BEFORE this write. `created_at` is the time of
        # capture, never a guessed original publication date (BR4.9).
        captures: tuple[tuple[str, Action, str], ...] = (
            (BASELINE_PUBLISHED_ID, "publish", document.published),
            (BASELINE_DRAFT_ID, "draft", document.draft),
        )
        for baseline_id, baseline_action, payload in captures:
            if baseline_id not in revisions:
                revisions[baseline_id] = RevisionRow(
                    id=baseline_id,
                    revision=document.revision,
                    action=baseline_action,
                    content=payload,
                    created_at=now,
                    baseline=True,
                )

        # Effect 3 -- the compare-and-set. `draft` moves on every accepted write;
        # `published` and `published_at` move only on a publish; `revision` increments
        # unconditionally (BR4.10).
        publishing = action == "publish"
        updated = DocumentRow(
            draft=content,
            published=content if publishing else document.published,
            revision=document.revision + 1,
            updated_at=now,
            published_at=now if publishing else document.published_at,
            last_mutation=mutation_token,
        )

        # Effect 4 -- the history entry: id IS the token, content read back from the
        # STORED draft, `created_at` from the record's `updated_at` (BR4.11).
        revisions[mutation_token] = RevisionRow(
            id=mutation_token,
            revision=updated.revision,
            action=action,
            content=updated.draft,
            created_at=updated.updated_at,
            baseline=False,
        )

        # Effects 5 and 6 -- retention, per action, with the counts supplied as an
        # argument (BR5.9) and baselines excluded by the predicate rather than by
        # ordering (BR5.8): they hold the LOWEST revision here, so ordering would reach
        # them first.
        policy: tuple[tuple[Action, int], ...] = (
            ("draft", retention.draft_keep),
            ("publish", retention.publish_keep),
        )
        for pruned_action, keep in policy:
            candidates = [
                row
                for row in revisions.values()
                if row.action == pruned_action and not row.baseline
            ]
            # `revision` DESCENDING and nothing else. BR4.19: which entry survives a tie
            # at the boundary is unspecified, and adding a tie-break to make this
            # implementation deterministic would turn an inherited indeterminacy into a
            # specified behaviour nobody decided.
            candidates.sort(key=lambda row: row.revision, reverse=True)
            for doomed in candidates[keep:]:
                del revisions[doomed.id]

        storage.document = updated
        storage.revisions = revisions
        return ContentState(
            draft=updated.draft,
            published=updated.published,
            revision=updated.revision,
            updated_at=updated.updated_at,
            published_at=updated.published_at,
        )

    async def list_revisions(self) -> list[RevisionSummary]:
        """BR22.3: the three-part order is COMPUTED here, never inherited.

        Three stable passes applied in reverse key order. Python's sort is stable, so
        composing them this way expresses a multi-key sort whose parts run in different
        directions -- without hard-coding a rank for the two known actions, which would
        stop being a sort and start being a lookup table.
        """
        rows = list(self._storage.revisions.values())
        rows.sort(key=lambda row: row.action, reverse=True)  # action DESC
        rows.sort(key=lambda row: row.baseline)  # baseline ASC: False before True
        rows.sort(key=lambda row: row.revision, reverse=True)  # revision DESC
        return [
            RevisionSummary(
                id=row.id,
                revision=row.revision,
                action=row.action,
                created_at=row.created_at,
                baseline=row.baseline,
            )
            # Capped, in one result. Not a page: a cursor over an order with ties can
            # repeat or skip an entry at a boundary (BR22.2).
            for row in rows[: self._listing_cap]
        ]

    async def read_revision(self, revision_id: str) -> RevisionEntry | None:
        row = self._storage.revisions.get(revision_id)
        if row is None:
            return None
        return RevisionEntry(
            id=row.id,
            revision=row.revision,
            action=row.action,
            content=row.content,
            created_at=row.created_at,
            baseline=row.baseline,
        )

    async def asset_metadata_register(self, record: AssetMetadataRecord) -> None:
        self._storage.assets[record.key] = record

    async def asset_metadata_read(self, key: str) -> AssetMetadataRecord | None:
        return self._storage.assets.get(key)

    async def asset_metadata_remove(self, key: str) -> None:
        # Idempotent without a branch (BR22.10).
        self._storage.assets.pop(key, None)
