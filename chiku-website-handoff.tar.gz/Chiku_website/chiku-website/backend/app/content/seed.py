"""The seeded document -- the content a fresh install holds before anything is written.

This is **instance data, not schema**. Every `.default()` the schema itself carries lives
in `schema.py`; what is here is the one document BR4.1 synthesises when no record exists,
reproduced from the source's `initialContent` constructor
(`madhavi-tripathi/app/content.ts`) and cross-checked against the recorded fixture
`F3-content-owner`, which is the same document as the running source serialises it.

**Two independent sources, deliberately.** The transcription below is read from the
constructor; the test asserts it against the recording. A transcription error in either
direction fails that test rather than shipping.

**The source materialises the content-carrying defaults at construction.** Its `record()`
helper writes `researchTopic: researchIdentity({id})` and
`researchIds: initialResearchLinks.get(id) ?? []` into every seeded item, so the seeded
document carries them explicitly and the read-path transform of BR9.1-BR9.3 has nothing
left to resolve here. Those values are spelled out below rather than derived, because the
seed is data; `test_defaults.py` asserts that what is spelled out agrees with the maps.

**Non-ASCII punctuation is written as a NAMED escape, never as a literal glyph.** MIDDLE
DOT, EN DASH and EM DASH are all content here, and all three are visually confusable with
an ASCII character a careless edit would silently substitute -- which under the parity
rule is a change to what the site owner sees. A named escape says which codepoint is
meant, survives a copy-paste through a tool that normalises punctuation, and needs no
lint suppression.
"""

from __future__ import annotations

from app.content.defaults import Topic
from app.content.schema import (
    ContentDocument,
    ContentItem,
    ScholarHighlights,
    SectionVisibility,
    SiteCopy,
    default_scene,
    serialise,
)


def _record(
    item_id: str,
    *,
    title: str,
    subtitle: str = "",
    description: str = "",
    year: str = "",
    link: str = "",
    featured: bool = False,
    research_topic: Topic = "general",
    research_ids: tuple[str, ...] = (),
) -> ContentItem:
    """The source's `record()` helper: a blank item with the named values applied.

    Every field the source leaves blank is blank here -- empty strings, `[]`, `false`,
    focal point 50/50 -- and is written out rather than left to a default, because the
    seed is the document a fresh install serves and its stored form is exactly these
    values.
    """
    return ContentItem(
        id=item_id,
        title=title,
        subtitle=subtitle,
        description=description,
        year=year,
        image="",
        image_alt="",
        image_sources=[],
        focal_x=50,
        focal_y=50,
        link=link,
        code="",
        dataset="",
        video="",
        captions="",
        transcript="",
        featured=featured,
        citations="",
        citations_as_of="",
        research_topic=research_topic,
        research_ids=list(research_ids),
        contribution="",
        approach="",
        outcome="",
    )


_BIO = (
    "I am a translational scientist working across biomaterials, drug delivery, "
    "ultrasound, and photoacoustic imaging. I earned my Ph.D. in Materials Engineering "
    "at IISc and completed postdoctoral training in the PULSE Lab at Johns Hopkins "
    "University.\n\nMy work connects material synthesis and biological evaluation with "
    "image reconstruction, quantitative analysis, and clinical imaging studies. I now "
    "lead scientific and AI/ML strategy at SynapSeek, developing reproducible workflows "
    "for a neuro-diagnostic mapping platform.\n\nAlongside research, I mentor junior "
    "scientists and serve on the Women in Molecular Imaging Network leadership committee."
)


def seed_document() -> ContentDocument:
    """A fresh copy of the seeded document.

    A function rather than a module constant: the caller owns a mutable model tree, and a
    shared instance could be edited by one caller and observed by the next.
    """
    return ContentDocument(
        name="Madhavi Tripathi",
        role="Translational scientist",
        affiliation="Lead Scientist \N{MIDDLE DOT} SynapSeek",
        location="Remote",
        headline="Nanomaterials for delivery.\nLight & sound for imaging.",
        intro=(
            "I develop nanomaterials for drug delivery and explore photoacoustic and "
            "ultrasound imaging\N{EM DASH}connecting how we deliver with how we see."
        ),
        bio=_BIO,
        email="madhavi.tri16@gmail.com",
        photo="",
        photo_alt="Madhavi Tripathi",
        photo_sources=[],
        photo_focal_x=50,
        photo_focal_y=35,
        copy_=SiteCopy(),
        cv="",
        scholar="https://scholar.google.com/citations?user=zZx1Td0AAAAJ&hl=en",
        orcid="https://orcid.org/0000-0002-4736-9134",
        github="",
        linkedin="https://www.linkedin.com/in/mtri16",
        accent="blue",
        motion=True,
        scene=default_scene(),
        scholar_highlights=ScholarHighlights(
            visible=True,
            citations="104",
            h_index="",
            i10_index="",
            as_of="23 September 2026",
            affiliation="Johns Hopkins University",
            interests=(
                "Bioengineering, Nanotheranostics, Bioimaging, Photothermal therapy, "
                "Optoacoustic imaging"
            ),
        ),
        show_notice=False,
        notice="",
        sections=SectionVisibility(
            achievements=True,
            research=True,
            publications=True,
            journey=True,
            news=True,
            contact=True,
        ),
        achievements=[
            _record(
                "iisc-gold-medal",
                title="Best Thesis Award \N{MIDDLE DOT} Gold Medal",
                subtitle="Indian Institute of Science",
                description=(
                    "Recognition for doctoral research in Materials Engineering and "
                    "cancer theranostics."
                ),
                year="2025",
                featured=True,
            ),
            _record(
                "wimin-leadership",
                title="Women in Molecular Imaging",
                subtitle="Leadership committee",
                description=("Contributing to a community of women working in molecular imaging."),
                year="2024\N{EN DASH}present",
            ),
            _record(
                "materials-symposium",
                title="Bringing researchers together",
                subtitle="Symposium convener \N{MIDDLE DOT} IISc",
                description="Convener of the 36th Annual Symposium of Materials Engineering.",
                year="2023",
            ),
        ],
        research=[
            _record(
                "nano-materials",
                title="Nanomaterials & drug delivery",
                subtitle="How can a carrier respond when it matters?",
                description=(
                    "Designing CuS, CuS\N{EN DASH}Au, and thermoresponsive nanogel platforms, "
                    "from synthesis and characterization to drug delivery, 3D tumor "
                    "models, and preclinical evaluation."
                ),
                link="https://etd.iisc.ac.in/handle/2005/6575",
                research_topic="materials",
            ),
            _record(
                "ultrasound-imaging",
                title="Ultrasound imaging",
                subtitle="What can the echoes tell us more clearly?",
                description=(
                    "Working with DAS and SLSC beamforming, RF-data analysis, and "
                    "quantitative contrast metrics, including breast cyst and "
                    "solid-mass characterization."
                ),
                link="https://doi.org/10.1093/radadv/umaf037",
                research_topic="ultrasound",
            ),
            _record(
                "photoacoustics",
                title="Photoacoustic imaging",
                subtitle="How can light and sound reveal more?",
                description=(
                    "Connecting contrast-agent development with sound-speed selection, "
                    "oxygenation mapping, and target-detectability studies across "
                    "simulations, phantoms, and clinical images."
                ),
                link="https://doi.org/10.1038/s44303-026-00193-4",
                research_topic="photoacoustic",
            ),
        ],
        publications=[
            _record(
                "breast-imaging-2026",
                title=(
                    "In vivo photoacoustic breast imaging and the interactive effects of "
                    "skin tone, wavelength, beamformer, and depth on target detectability"
                ),
                subtitle="Jamie Enslein, Madhavi Tripathi, et al. \N{MIDDLE DOT} npj Imaging",
                description=(
                    "A study of 29 patients examines how skin tone and imaging choices "
                    "interact to affect photoacoustic target visibility."
                ),
                year="2026",
                link="https://doi.org/10.1038/s44303-026-00193-4",
                featured=True,
                research_ids=("photoacoustics",),
            ),
            _record(
                "ultrasound-coherence-2025",
                title=(
                    "Generalized contrast-to-noise ratio applied to short-lag spatial "
                    "coherence ultrasound differentiates breast cysts from solid masses"
                ),
                subtitle=(
                    "Arunima Sharma, Eniola T. Oluyemi, Madhavi Tripathi, et al. "
                    "\N{MIDDLE DOT} Radiology Advances"
                ),
                description=(
                    "Evaluates an objective contrast metric with coherence-based "
                    "ultrasound for distinguishing complicated cysts from solid breast "
                    "masses."
                ),
                year="2025",
                link="https://doi.org/10.1093/radadv/umaf037",
                featured=True,
                research_ids=("ultrasound-imaging",),
            ),
            _record(
                "mucin-cus-2025",
                title=(
                    "Mucin-capped CuS nanoparticles for mitochondrial targeted NIR-II "
                    "photothermal therapy and photoacoustic imaging"
                ),
                subtitle=(
                    "Madhavi Tripathi, Ananya Sharma, Victor A. Ajisafe, Sanhita "
                    "Sinharay & Ashok M. Raichur \N{MIDDLE DOT} Journal of Drug Delivery Science "
                    "and Technology"
                ),
                description=(
                    "Explores mucin-capped copper sulfide nanoparticles for photothermal "
                    "therapy and photoacoustic imaging."
                ),
                year="2025",
                link="https://doi.org/10.1016/j.jddst.2025.106668",
                featured=True,
                research_ids=("nano-materials", "photoacoustics"),
            ),
            _record(
                "nanoflakes-2024",
                title=(
                    "Effect of PVP Molecular Weights on the Synthesis of Ultrasmall CuS "
                    "Nanoflakes: Synthesis, Properties, and Potential Application for "
                    "Phototheranostics"
                ),
                subtitle=(
                    "Madhavi Tripathi, Ananya Sharma, Sanhita Sinharay & Ashok M. "
                    "Raichur \N{MIDDLE DOT} ACS Applied Bio Materials"
                ),
                description=(
                    "Investigates how polymer molecular weight influences ultrasmall "
                    "copper sulfide nanoflakes and their phototheranostic properties."
                ),
                year="2024",
                link="https://doi.org/10.1021/acsabm.3c01123",
                featured=True,
                research_ids=("nano-materials",),
            ),
            _record(
                "nanohybrids-2023",
                title=(
                    "Seed-Mediated Galvanic Synthesis of CuS\N{EN DASH}Au Nanohybrids for "
                    "Photo-Theranostic Applications"
                ),
                subtitle=(
                    "Madhavi Tripathi, Swathi Padmanabhan, Jaya Prakash & Ashok M. "
                    "Raichur \N{MIDDLE DOT} ACS Applied Nano Materials"
                ),
                description=(
                    "Combines copper sulfide and gold in ultrasmall nanohybrids to "
                    "investigate light-driven heating and photoacoustic contrast."
                ),
                year="2023",
                link="https://doi.org/10.1021/acsanm.3c02405",
                featured=True,
                research_ids=("nano-materials", "photoacoustics"),
            ),
        ],
        journey=[
            _record(
                "synapseek-current",
                title="Lead Scientist",
                subtitle="SynapSeek \N{MIDDLE DOT} Remote",
                description=(
                    "Leading scientific and AI/ML strategy, data pipelines, model "
                    "evaluation, and validation for a neuro-diagnostic mapping platform."
                ),
                year="Feb 2026\N{EN DASH}present",
            ),
            _record(
                "pulse-lab",
                title="Postdoctoral Research Fellow",
                subtitle="PULSE Lab \N{MIDDLE DOT} Johns Hopkins University",
                description=(
                    "Ultrasound and photoacoustic image reconstruction, quantitative "
                    "analysis, and breast-imaging studies with Prof. Muyinatu A. Lediju "
                    "Bell."
                ),
                year="Dec 2024\N{EN DASH}Jan 2026",
                link="https://pulselab.jhu.edu/people/",
            ),
            _record(
                "phd-iisc",
                title="Ph.D. in Materials Engineering",
                subtitle="Indian Institute of Science \N{MIDDLE DOT} Bengaluru",
                description=(
                    "Doctoral research on nanotheranostic platforms for photoacoustic "
                    "imaging and image-guided therapy. Best Thesis Award / Gold Medal, "
                    "2025. Advisor: Prof. Ashok M. Raichur."
                ),
                year="March 2025",
                link="https://etd.iisc.ac.in/handle/2005/6575",
            ),
            _record(
                "masters-iiit",
                title="Integrated M.Tech. in Biomedical Engineering",
                subtitle="Indian Institute of Information Technology \N{MIDDLE DOT} Allahabad",
                description=(
                    "A five-year foundation in biomedical engineering, bringing together "
                    "engineering methods and biological questions."
                ),
                year="July 2018",
            ),
        ],
        news=[
            _record(
                "new-imaging-paper",
                title="A closer look at photoacoustic breast imaging",
                subtitle="New publication",
                year="04 Sep 2026",
                description=(
                    "New work in npj Imaging examines the interacting effects of skin "
                    "tone and imaging parameters."
                ),
                link="https://www.nature.com/articles/s44303-026-00193-4",
            ),
            _record(
                "synapseek-appointment",
                title="A new chapter in translational science",
                subtitle="Research appointment",
                year="February 2026",
                description=(
                    "Joining SynapSeek as Lead Scientist to lead scientific and AI/ML "
                    "strategy for neuro-diagnostic mapping."
                ),
            ),
            _record(
                "gold-medal-2025",
                title="IISc Best Thesis Award \N{MIDDLE DOT} Gold Medal",
                subtitle="Recognition",
                year="2025",
                description="Recognition for doctoral research in Materials Engineering.",
            ),
            _record(
                "iisc-research-highlight",
                title="Hybrid nanoparticles in the spotlight",
                subtitle="Research feature",
                year="11 Sep 2023",
                description=(
                    "IISc shares the story behind copper sulfide\N{EN DASH}gold nanohybrids "
                    "and their potential for light-based applications."
                ),
                link=(
                    "https://www.iisc.ac.in/events/"
                    "hybrid-nanoparticles-shine-new-light-on-targeting-cancer-cells/"
                ),
            ),
        ],
    )


def seed_payload() -> str:
    """The seeded document serialised, which is what the store is handed at construction."""
    return serialise(seed_document())
