"""The authoritative content schema -- every field, every cap, every default.

Transcribed from `construction/content-core/functional-design/entities.md` § ENT-4 and
§ *The cap census*, which are normative. **Not from the source file and not from memory**:
a cap transcribed wrong is a field that silently accepts or rejects the wrong input, and
nothing anywhere reports it.

Three properties of this module that are load-bearing:

* **The wire format is `camelCase` and frozen** (FR9.4). It is inherited rather than
  chosen: the ported components read this shape unchanged, and the persisted content *is*
  this JSON, so a rename would also be a data migration. `WireModel` is the **single**
  conversion point -- no `camelCase` identifier appears in Python and no `snake_case` key
  reaches the wire.
* **Validation is strict** (`strict=True`). zod coerces nothing: `z.number()` refuses
  `"50"`, `z.boolean()` refuses `1`. Pydantic's lax mode accepts both, which would make
  this port *more permissive* than the system it preserves -- and would quietly move a
  wrong-type failure out of the corrupting class in `recovery.py`, where BR8.3 puts it.
* **Unknown keys are dropped, not rejected.** `z.object()` strips by default, which is
  Pydantic's `extra="ignore"` default. A model that rejected extras would fail documents
  the source accepts.

**Where the source is asymmetric it is reproduced, not tidied**, and each asymmetry is
named at the point it appears so a later reader cannot mistake it for a slip.

**One stated divergence.** `citationDate`'s round-trip check rejects the year `0000`,
which the source accepts (`Date.parse('0000-01-01')` succeeds in JavaScript and Python's
`date` has no year zero). No other date differs, and no snapshot date an owner types can
reach the case.
"""

from __future__ import annotations

import json
import re
from collections.abc import Mapping
from datetime import UTC, date, datetime
from typing import Annotated, Any, Literal

from pydantic import (
    AfterValidator,
    BaseModel,
    BeforeValidator,
    ConfigDict,
    Field,
    StringConstraints,
    model_validator,
)
from pydantic.alias_generators import to_camel
from pydantic_core import PydanticCustomError

from app.content.defaults import Topic, apply_content_carrying_defaults
from app.content.store import Action

# --------------------------------------------------------------------------------- #
# The single conversion point
# --------------------------------------------------------------------------------- #


def wire_name(field_name: str) -> str:
    """Python `snake_case` -> the frozen `camelCase` wire spelling.

    A **trailing underscore escapes a name Python or Pydantic has already taken** and is
    removed before conversion, so `copy_` is `copy` on the wire. Pydantic refuses a field
    literally named `copy` because it shadows `BaseModel.copy`, and a hand-written
    `alias="copy"` would have been a *second* conversion point -- exactly the thing
    `stateFromRow()`'s single conversion in the source avoids.
    """
    return to_camel(field_name.rstrip("_"))


class WireModel(BaseModel):
    """The shared base every request and response model in the system inherits.

    It is the one place `snake_case` becomes `camelCase`. `populate_by_name` keeps the
    Python spelling usable from Python without putting it on the wire.
    """

    model_config = ConfigDict(
        alias_generator=wire_name,
        populate_by_name=True,
        strict=True,
    )


def instant_to_wire(moment: datetime) -> str:
    """An aware instant in the wire's ISO-8601 form: milliseconds, `Z`, never an offset.

    The source produces every timestamp with `Date.toISOString()`, and the recorded
    fixtures carry exactly three fractional digits and a literal `Z`
    (`2026-09-25T03:12:29.956Z`). `datetime.isoformat()` emits six digits and `+00:00`,
    both of which are a visible change to a value the editor displays and compares.
    """
    utc = moment.astimezone(UTC)
    return f"{utc.strftime('%Y-%m-%dT%H:%M:%S')}.{utc.microsecond // 1000:03d}Z"


# --------------------------------------------------------------------------------- #
# Shared building blocks -- entities.md § "ENT-4 shared building blocks"
# --------------------------------------------------------------------------------- #

# `\d` in JavaScript is ASCII-only; Python's `\d` matches every Unicode decimal digit.
# `[0-9]` is the faithful spelling, and the difference is invisible until an owner pastes
# a citation count in Devanagari digits and the port accepts what the source refused.
_DIGITS = re.compile(r"[0-9]+")
_ISO_DATE = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}")
# Case-INSENSITIVE, as the source writes it.
_HTTP_URL = re.compile(r"https?://[^\s]+", re.IGNORECASE)
# Case-SENSITIVE, as the source writes it. Deliberately more permissive than the media
# route's own key pattern: a document may legally hold a media URL the media route 404s.
_MEDIA_URL = re.compile(r"/api/media/[a-zA-Z0-9.-]+")
_EMAIL = re.compile(r"[^\s@]+@[^\s@]+\.[^\s@]+")


def _refuse(message: str) -> PydanticCustomError:
    """A refinement failure carrying the source's verbatim message.

    `PydanticCustomError` rather than `ValueError` because Pydantic prefixes a raised
    `ValueError` with `Value error, `, and these sentences are product copy the owner
    reads in the editor's field highlighting. The error *type* stays `value_error`, which
    is Pydantic's own name for "a custom predicate failed" -- the class BR8.3 calls
    recoverable.
    """
    return PydanticCustomError("value_error", message)


def _emptied(message: str) -> PydanticCustomError:
    """A minimum-length failure carrying the source's verbatim message.

    The type is `string_too_short`, which is what Pydantic emits for its own
    `min_length`, so the classification in `recovery.py` sees one kind of failure and not
    two.
    """
    return PydanticCustomError("string_too_short", message)


def _check_url(value: str) -> str:
    if not value or _HTTP_URL.fullmatch(value) or _MEDIA_URL.fullmatch(value):
        return value
    raise _refuse("Use a full https:// link.")


def _check_email(value: str) -> str:
    if not value or _EMAIL.fullmatch(value):
        return value
    raise _refuse("Enter a valid email.")


def _check_citation_count(value: str) -> str:
    if value == "" or _DIGITS.fullmatch(value):
        return value
    raise _refuse("Use a whole, non-negative citation count, or leave it blank.")


def _check_citation_date(value: str) -> str:
    """Reject a well-formed but non-existent date, and never normalise one.

    The regex alone is not enough: `2026-02-30` matches it, and JavaScript's `Date.parse`
    *accepts* the string and silently normalises it to March 2. The source's defence is
    the ISO round-trip equality, and this is its equivalent -- `date.fromisoformat`
    refuses the impossible day outright, and the value is returned unchanged either way.
    """
    if not value:
        return value
    if _ISO_DATE.fullmatch(value):
        try:
            parsed = date.fromisoformat(value)
        except ValueError:
            parsed = None
        if parsed is not None and parsed.isoformat() == value:
            return value
    raise _refuse("Use a valid snapshot date.")


def _required_title(value: str) -> str:
    if not value:
        raise _emptied("Add a title before saving.")
    return value


def _required_label(value: str) -> str:
    if not value:
        raise _emptied("Add a label.")
    return value


def _required_heading(value: str) -> str:
    if not value:
        raise _emptied("Add a heading.")
    return value


def _integral(value: Any) -> Any:
    """`1200.0` is an integer in JavaScript, and `z.number().int()` accepts it.

    Python's `json` decodes `1200.0` as a float, which strict mode then refuses -- so the
    port would reject an image width the source accepts, and would classify the refusal
    as a *corrupting* wrong-type failure. A fractional value is left alone and still
    fails.
    """
    if isinstance(value, float) and value.is_integer():
        return int(value)
    return value


# `text`: string, max 10000, no trim and no refinement. Used by ten fields.
type Text = Annotated[str, StringConstraints(max_length=10000)]

# `url`: max 2000 plus the three-way refinement. Used by eleven fields.
type Url = Annotated[str, StringConstraints(max_length=2000), AfterValidator(_check_url)]

# `citationCount`: TRIMMED first, then max 9, then digits-or-empty.
type CitationCount = Annotated[
    str,
    StringConstraints(strip_whitespace=True, max_length=9),
    AfterValidator(_check_citation_count),
]

# `citationDate`: max 10, **NOT trimmed** -- the asymmetry with `citationCount` is real.
# A leading space in `citationsAsOf` fails; a leading space in `citations` is stripped.
type CitationDate = Annotated[
    str, StringConstraints(max_length=10), AfterValidator(_check_citation_date)
]

# The four focal-point percentages. `max(100)` here is a NUMERIC bound, not a length --
# the same literal is a string length on `item.id` and an array length on three
# collections. `int | float` rather than `float`: JSON `50` must serialise back as `50`,
# and `float` would put `50.0` on the wire and into the stored document.
type Percentage = Annotated[int | float, Field(ge=0, le=100)]

# `imageSource.width` / `.height`: integers, 1..16000.
type Pixels = Annotated[int, BeforeValidator(_integral), Field(ge=1, le=16000)]

type ItemId = Annotated[str, StringConstraints(max_length=100)]

# `label(fallback)` from `site-copy.ts`: trim, min 1 with `Add a label.`, max 80.
type Label = Annotated[
    str, StringConstraints(strip_whitespace=True, max_length=80), AfterValidator(_required_label)
]

# `section(value).title`: trim, min 1 with `Add a heading.`, max 200.
type SectionTitle = Annotated[
    str, StringConstraints(strip_whitespace=True, max_length=200), AfterValidator(_required_heading)
]

type SectionDescription = Annotated[str, StringConstraints(max_length=1000)]

# `accent`: exactly one of three, in that declaration order. **No default; required.**
type Accent = Literal["blue", "burgundy", "forest"]

# `scene.initialView`: exactly one of three, in that declaration order.
type SceneView = Literal["delivery", "photoacoustic", "ultrasound"]


# --------------------------------------------------------------------------------- #
# ENT-4 `imageSource`
# --------------------------------------------------------------------------------- #


class ImageSource(WireModel):
    """`{src, width, height}` -- all three required."""

    src: Url
    width: Pixels
    height: Pixels


# --------------------------------------------------------------------------------- #
# ENT-4 `item` -- 24 declared fields, identical for all five collections
# --------------------------------------------------------------------------------- #


class ContentItem(WireModel):
    """The shape shared by `achievements`, `research`, `publications`, `journey`, `news`.

    There is no per-collection variation. What varies is the **array** maximum on the
    field that holds them, and those four maxima are all different.

    `researchTopic` and `researchIds` are declared **required and non-nullable on
    purpose** (W-1, W-2). A model declaring `research_topic: Topic | None = None` is
    type-correct and behaviourally wrong: it produces `None` where the original produces
    a real topic. They are absent from a stored document and are supplied by the
    content-carrying transform before field validation runs.
    """

    @model_validator(mode="before")
    @classmethod
    def _resolve_content_carrying_defaults(cls, data: Any) -> Any:
        """BR9.2: the transform runs on **every parse**, which includes every read.

        `mode="before"` because absence is what the rule tests, and a declared default
        would make "absent" and "defaulted" indistinguishable by the time an after-
        validator could look. A value that is present and *wrong* is left alone and goes
        on to fail validation, which is what puts a bad enum in the recoverable class.

        Anything that is not a mapping is handed back untouched, so a non-object item
        still reports `model_type` -- the corrupting class -- rather than raising here.
        """
        if not isinstance(data, Mapping):
            return data
        return apply_content_carrying_defaults(data)

    id: ItemId
    title: Annotated[
        str,
        StringConstraints(strip_whitespace=True, max_length=1000),
        AfterValidator(_required_title),
    ]
    subtitle: Text
    description: Text
    year: Annotated[str, StringConstraints(max_length=40)]
    image: Url
    image_alt: Text
    image_sources: Annotated[list[ImageSource], Field(max_length=4)] = Field(default_factory=list)
    focal_x: Percentage = 50
    focal_y: Percentage = 50
    link: Url
    code: Url
    dataset: Url
    video: Url
    # The only `url` field in `item` that carries a default.
    captions: Url = ""
    # 60000 -- six times any `text` field.
    transcript: Annotated[str, StringConstraints(max_length=60000)] = ""
    featured: bool
    citations: CitationCount = ""
    citations_as_of: CitationDate = ""
    research_topic: Topic
    research_ids: Annotated[list[ItemId], Field(max_length=100)]
    contribution: Text = ""
    approach: Text = ""
    outcome: Text = ""


# --------------------------------------------------------------------------------- #
# ENT-4 `scholarHighlights`
# --------------------------------------------------------------------------------- #


class ScholarHighlights(WireModel):
    """All members are plain strings except `visible`, and **none carries a refinement**.

    `citations` here is a max-20 string with no digits check -- unlike `item.citations`,
    which is a `citationCount`. Two fields with the same name and different rules.
    """

    visible: bool
    citations: Annotated[str, StringConstraints(max_length=20)]
    h_index: Annotated[str, StringConstraints(max_length=20)]
    i10_index: Annotated[str, StringConstraints(max_length=20)]
    as_of: Annotated[str, StringConstraints(max_length=100)]
    affiliation: Annotated[str, StringConstraints(max_length=200)]
    interests: Annotated[str, StringConstraints(max_length=1000)]


def default_scholar_highlights() -> ScholarHighlights:
    """The object-level `.default()`, verbatim."""
    return ScholarHighlights(
        visible=False,
        citations="",
        h_index="",
        i10_index="",
        as_of="",
        affiliation="",
        interests="",
    )


# --------------------------------------------------------------------------------- #
# ENT-4 `sceneStory` / `sceneSchema`
# --------------------------------------------------------------------------------- #


class SceneStory(WireModel):
    """All three members required, no defaults."""

    title: Annotated[str, StringConstraints(max_length=150)]
    description: Annotated[str, StringConstraints(max_length=600)]
    link: Url


class SceneSettings(WireModel):
    """A legacy `autoTour` field was deliberately retired; it is not accepted as an alias."""

    offer_tour: bool = True
    initial_view: SceneView
    delivery: SceneStory
    photoacoustic: SceneStory
    ultrasound: SceneStory


def default_scene() -> SceneSettings:
    """`initialScene`, verbatim.

    `photoacoustic.description` carries a **U+2014 EM DASH** immediately after `signals`,
    with no surrounding spaces. It is content, not punctuation to be normalised.
    """
    return SceneSettings(
        offer_tour=True,
        initial_view="delivery",
        delivery=SceneStory(
            title="Small carriers. Purposeful delivery.",
            description=(
                "A thermoresponsive nanogel brings a drug payload and CuS nanoparticles "
                "together, with release designed to respond to heat."
            ),
            link="https://etd.iisc.ac.in/handle/2005/6575",
        ),
        photoacoustic=SceneStory(
            title="Light in. Sound out.",
            description=(
                "Light-absorbing materials generate acoustic signals\N{EM DASH}connecting "
                "nanoscale material design with photoacoustic imaging."
            ),
            link="https://doi.org/10.1021/acsanm.3c02405",
        ),
        ultrasound=SceneStory(
            title="From echoes to clearer insight.",
            description=(
                "Ultrasound transmits sound and receives echoes. My work explores "
                "coherence-based imaging to help distinguish breast cysts from solid masses."
            ),
            link="https://doi.org/10.1093/radadv/umaf037",
        ),
    )


# --------------------------------------------------------------------------------- #
# ENT-4 `copy` -- nine groups, 25 leaf defaults, defaulting at three nesting levels
# --------------------------------------------------------------------------------- #
#
# Each of the nine groups is its own class **because each leaf default differs per
# group**. `section(value)` in the source is a factory producing a distinct schema per
# group, and a single shared class could not carry nine different sets of defaults.
# An absent `copy`, an absent `copy.research` and an absent `copy.research.title` each
# produce a different but correct result, and each level is exercised by its own test.


class HeroCopy(WireModel):
    research_action: Label = "Explore my research"
    scholar_action: Label = "Google Scholar"
    discover: Label = "Scroll to discover"
    # MIDDLE DOT with a space either side, three times. Named escapes throughout this
    # module's copy defaults: the glyph is confusable with an ASCII full stop, and these
    # strings are product copy under the parity rule.
    topics: Annotated[str, StringConstraints(max_length=200)] = (
        "Drug delivery \N{MIDDLE DOT} Photoacoustics \N{MIDDLE DOT} Ultrasound"
    )


class SectionCopy(WireModel):
    """`section(value)` -- three fields. The subclasses below supply the nine defaults."""

    title: SectionTitle
    description: SectionDescription
    navigation: Label


class AchievementsCopy(SectionCopy):
    title: SectionTitle = "The work.\nThe moments behind it."
    description: SectionDescription = (
        "Recognition, shared discoveries, and the people along the way."
    )
    navigation: Label = "Highlights"


class ResearchCopy(SectionCopy):
    title: SectionTitle = "Small scale.\nWide possibilities."
    description: SectionDescription = (
        "Responsive carriers. Optical contrast.\nInformation carried by sound."
    )
    navigation: Label = "Research"


class PublicationsCopy(SectionCopy):
    title: SectionTitle = "Selected publications."
    description: SectionDescription = (
        "A curated selection. The complete record is on Google Scholar."
    )
    navigation: Label = "Publications"


class JourneyCopy(SectionCopy):
    title: SectionTitle = "Curiosity.\nA constant in motion."
    # The EMPTY STRING, not absent. Two of the 25 leaf defaults are empty.
    description: SectionDescription = ""
    navigation: Label = "About"


class NewsCopy(SectionCopy):
    title: SectionTitle = "From the research."
    description: SectionDescription = ""
    navigation: Label = "Updates"


class ContactCopy(SectionCopy):
    title: SectionTitle = "Good questions.\nNew connections."
    description: SectionDescription = "Research, collaboration,\nor a shared curiosity."
    navigation: Label = "Connect"


class ScholarCopy(WireModel):
    """`scholar.title`'s `min(1)` carries **no custom message**, unlike `section`'s."""

    title: Annotated[
        str, StringConstraints(strip_whitespace=True, min_length=1, max_length=200)
    ] = "A snapshot of\nthe research."
    profile_action: Label = "Explore the full profile"


class FooterCopy(WireModel):
    # A literal ampersand, not an entity.
    tagline: Annotated[str, StringConstraints(max_length=200)] = (
        "Materials. Delivery. Light & sound."
    )


class SiteCopy(WireModel):
    """`copySchema` -- nine groups, each defaulting independently of the whole."""

    hero: HeroCopy = Field(default_factory=HeroCopy)
    achievements: AchievementsCopy = Field(default_factory=AchievementsCopy)
    research: ResearchCopy = Field(default_factory=ResearchCopy)
    publications: PublicationsCopy = Field(default_factory=PublicationsCopy)
    journey: JourneyCopy = Field(default_factory=JourneyCopy)
    news: NewsCopy = Field(default_factory=NewsCopy)
    contact: ContactCopy = Field(default_factory=ContactCopy)
    scholar: ScholarCopy = Field(default_factory=ScholarCopy)
    footer: FooterCopy = Field(default_factory=FooterCopy)


# --------------------------------------------------------------------------------- #
# ENT-4 `sections` -- six booleans, asymmetric defaulting
# --------------------------------------------------------------------------------- #


class SectionVisibility(WireModel):
    """Only `achievements` is optional; the object itself has **no** default.

    Same back-compat origin as the collection asymmetry: achievements was added later.
    """

    achievements: bool = True
    research: bool
    publications: bool
    journey: bool
    news: bool
    contact: bool


# --------------------------------------------------------------------------------- #
# ENT-4 -- the 31 top-level fields
# --------------------------------------------------------------------------------- #


class ContentDocument(WireModel):
    """The one content document. 31 top-level fields, in the source's declaration order.

    **The collection asymmetry is real and is reproduced.** `achievements` has a default
    and a maximum of 60; `research`, `publications`, `journey` and `news` have **no
    default** and maxima of 100, **500**, 100 and 100. A model that defaulted all five
    would be more permissive than the original and would silently accept documents the
    source rejects.
    """

    name: Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=100)]
    role: Annotated[str, StringConstraints(max_length=200)]
    affiliation: Annotated[str, StringConstraints(max_length=200)]
    location: Annotated[str, StringConstraints(max_length=200)]
    headline: Annotated[str, StringConstraints(max_length=240)]
    intro: Text
    bio: Text
    email: Annotated[str, StringConstraints(max_length=200), AfterValidator(_check_email)]
    photo: Url
    photo_alt: Text
    photo_sources: Annotated[list[ImageSource], Field(max_length=4)] = Field(default_factory=list)
    photo_focal_x: Percentage = 50
    # 35, NOT 50 -- a deliberate portrait framing default, and the single most
    # transcription-error-prone value in the schema.
    photo_focal_y: Percentage = 35
    copy_: SiteCopy = Field(default_factory=SiteCopy)
    cv: Url
    scholar: Url
    orcid: Url
    github: Url
    linkedin: Url
    accent: Accent
    motion: bool = True
    scene: SceneSettings = Field(default_factory=default_scene)
    scholar_highlights: ScholarHighlights = Field(default_factory=default_scholar_highlights)
    show_notice: bool
    notice: Text
    sections: SectionVisibility
    achievements: Annotated[list[ContentItem], Field(max_length=60)] = Field(default_factory=list)
    research: Annotated[list[ContentItem], Field(max_length=100)]
    publications: Annotated[list[ContentItem], Field(max_length=500)]
    journey: Annotated[list[ContentItem], Field(max_length=100)]
    news: Annotated[list[ContentItem], Field(max_length=100)]


class RevisionSummaryView(WireModel):
    """One row of the history listing. Summaries, never content.

    The listing does not carry 52 documents, any one of which may exceed 4 MB; an entry's
    content is fetched one at a time.
    """

    id: str
    revision: int
    action: Action
    created_at: str
    baseline: bool


class RestoredRevision(RevisionSummaryView):
    """A summary with its full content, for review. **Restoring never publishes.**"""

    content: ContentDocument


class ContentMetadata(WireModel):
    """What a write reports back: the four values the editor tracks between saves.

    It is also the body the 409 carries alongside its sentence -- the editor reads these
    as **siblings of `error`**, not nested under a key, which is why the conflict merges
    this shape at the envelope's top level.
    """

    revision: int
    updated_at: str | None
    published_at: str | None
    has_unpublished_changes: bool


class SaveOutcome(ContentMetadata):
    """The metadata plus whether this write was a publish, as the source's 200 carries it."""

    published: bool


class ContentStateView(WireModel):
    """The owner read shape, confirmed against the running source rather than inferred.

    `hasUnpublishedChanges` is **computed on every read** and has no column (BR4.2); it
    appears here because it appears on the wire, not because anything stores it.
    """

    draft: ContentDocument
    published: ContentDocument
    revision: int
    updated_at: str | None
    published_at: str | None
    has_unpublished_changes: bool


def serialise(document: ContentDocument) -> str:
    """The document as it is stored and as it goes on the wire.

    Compact separators and `ensure_ascii=False` reproduce `JSON.stringify`: the persisted
    content *is* this string, so a different encoding of the same values is a different
    stored payload.
    """
    return json.dumps(document.model_dump(by_alias=True), ensure_ascii=False, separators=(",", ":"))
