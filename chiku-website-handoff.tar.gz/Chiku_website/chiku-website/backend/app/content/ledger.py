"""`RevisionLedger` -- the revision listing order and the retention policy.

**It owns the policy and performs NO write.** It supplies the numbers;
`ContentAuthority` applies them inside its one combined write, and this component's own
store access is **read-only** (BR5.9, ADR-001). Reading the entity-ownership table alone
would suggest otherwise, which is why it is stated here: if the ledger wrote directly, the
combined write would no longer be one call with one caller, and both of its guards would
lose their meaning.

**The listing order is a three-part sort, not "newest first"**: `revision` DESC, then
`baseline` ASC, then `action` DESC. All three parts are load-bearing for what the owner
sees, and they differ only on a tied revision -- so a port that sorted on revision alone
would list a tie in a different order **while passing any test written from a looser
wording**. The order is confirmed against data from the running source, not read off a
query: revisions 4, 3, 2, 1 as non-baseline drafts, then revision 0 `publish` baseline
(`starting-published`), then revision 0 `draft` baseline (`starting-draft`).

**52 is not a page size and there is no pagination.** It is `30 drafts + 20 publishes + 2
baselines` **by construction**, and `listing_cap_for` is that construction: changing one
number without the other would silently truncate history or produce a listing that can
never show a newly created entry.

**The two starting baselines are kept permanently.** Both retention deletes exclude them
**by the `baseline` predicate**, not by a coincidence of ordering -- a prune that relied on
baselines sorting high would eventually reach one, and the capture is once-ever, so what it
loses cannot be recreated.
"""

from __future__ import annotations

import json
import re

from app.content.schema import (
    ContentDocument,
    RestoredRevision,
    RevisionSummaryView,
    instant_to_wire,
)
from app.content.store import (
    BASELINE_DRAFT_ID,
    BASELINE_PUBLISHED_ID,
    ContentStore,
    RetentionPolicy,
    RevisionSummary,
    listing_cap_for,
)
from app.errors import Invalid

#: Kept independently, per action: a run of 30 drafts never evicts a publish.
DRAFT_KEEP = 30
PUBLISH_KEEP = 20

RETENTION = RetentionPolicy(
    draft_keep=DRAFT_KEEP,
    publish_keep=PUBLISH_KEEP,
    permanent_ids=(BASELINE_PUBLISHED_ID, BASELINE_DRAFT_ID),
)

#: Derived, never written down as 52. The cap and the policy are the same number.
LISTING_CAP = listing_cap_for(RETENTION)

MAX_REVISION_ID_LENGTH = 100
REVISION_ID_PATTERN = re.compile(r"[a-zA-Z0-9-]+")

# BR10.7 declares this copy in `HttpApi`, which renders the envelope. The sentences are
# stated here because these are the conditions **this** component raises and they are
# product copy under the parity rule -- a port that reworded one has changed what the site
# owner reads. They are not to be reworded, here or there.
HISTORY_ID_INVALID = "Choose a saved version from the history list."
HISTORY_NOT_FOUND = (
    "This version is no longer in the recent history. Your current draft is unchanged."
)


def _summary(row: RevisionSummary) -> RevisionSummaryView:
    return RevisionSummaryView(
        id=row.id,
        revision=row.revision,
        action=row.action,
        created_at=instant_to_wire(row.created_at),
        baseline=row.baseline,
    )


class RevisionLedger:
    """The revision entity, its ordering and its retention policy. **Read-only access.**"""

    def __init__(self, store: ContentStore) -> None:
        self._store = store

    @property
    def retention(self) -> RetentionPolicy:
        """The policy `ContentAuthority` is handed. An argument, never an adapter constant."""
        return RETENTION

    @property
    def listing_cap(self) -> int:
        return LISTING_CAP

    async def list_revisions(self) -> list[RevisionSummaryView]:
        """Summaries, in the three-part order, capped -- in one result, with no cursor.

        A cursor over an order with ties can repeat or skip an entry at a page boundary,
        and the cap is small and fixed, so there is nothing to paginate.
        """
        return [_summary(row) for row in await self._store.list_revisions()]

    async def read_revision(self, revision_id: str) -> RestoredRevision | None:
        """One entry with its content, or absence. **Restoring never publishes** (BR5.6).

        The id is validated **first** (BR5.5). Absence of the parameter altogether means
        *list* and is the caller's branch, not this one's; a parameter that is **present
        but empty**, longer than 100 characters, or failing the pattern is **invalid** --
        not a listing and not a not-found. Treating empty as absent would silently turn a
        malformed request into a successful listing and the caller would never learn its
        id was wrong.

        Absence is a **return value**: a well-formed id naming nothing, an entry that was
        pruned, and a row carrying no content all return `None`, and the caller answers
        with `HISTORY_NOT_FOUND` -- whose reassurance that the current draft is unaffected
        is part of the rule, not decoration. An owner who asks for a pruned version and
        gets a bare not-found has no way to know their unsaved work is still safe, and may
        reload to find out.

        A row whose content is present but **unparseable** is a different case and is left
        to propagate: the source answers 503 there, and this operation returning
        "no longer in the recent history" for an entry that demonstrably still exists
        would tell the owner something untrue.
        """
        if (
            not revision_id
            or len(revision_id) > MAX_REVISION_ID_LENGTH
            or not REVISION_ID_PATTERN.fullmatch(revision_id)
        ):
            raise Invalid(HISTORY_ID_INVALID)

        entry = await self._store.read_revision(revision_id)
        if entry is None or not entry.content:
            return None

        return RestoredRevision(
            id=entry.id,
            revision=entry.revision,
            action=entry.action,
            created_at=instant_to_wire(entry.created_at),
            baseline=entry.baseline,
            content=ContentDocument.model_validate(json.loads(entry.content)),
        )
