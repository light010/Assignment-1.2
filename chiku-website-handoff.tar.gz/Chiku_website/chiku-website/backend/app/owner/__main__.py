"""`python -m app.owner <database-path>` -- the operator's entry point.

**Wiring only.** Every decision this command makes lives in `app.owner.provision`, which
is tested; what is here is reading a terminal, opening the database and exiting with a
status. It is excluded from coverage by `pyproject.toml`'s `omit` for that reason, and it
is kept trivial so that the exclusion stays honest.

**It loads the full startup configuration, including the signing key**, although
provisioning issues no session. That is deliberate: this command runs in the same
container against the same environment as the service, and a provisioning that succeeded
under a configuration the service cannot boot with would leave an account nobody can use
and no obvious reason why.

**The password is read with `getpass`**, so it is never echoed and never lands in shell
history.
"""

from __future__ import annotations

import os
import sys
from datetime import UTC, datetime
from getpass import getpass
from pathlib import Path

import anyio

from app.auth.guard import LoginGuard
from app.auth.hashing import production_hashing
from app.auth.sessions import SessionAuthority
from app.auth.store_sqlite import SqliteIdentityStore
from app.auth.tokens import CookieSigner
from app.owner.identity import OwnerIdentity
from app.owner.provision import ProvisioningOutcome, provision_from_command_line
from app.settings import Settings, load_settings
from app.sqlite import SqliteDatabase

USAGE = "usage: python -m app.owner <database-path>"


async def _run(
    database_path: Path,
    settings: Settings,
    email: str,
    password: str,
    confirmation: str,
) -> ProvisioningOutcome:
    database = SqliteDatabase(database_path)
    await database.initialize()

    store = SqliteIdentityStore(database)
    identity = OwnerIdentity(
        store=store,
        hashing=production_hashing(),
        sessions=SessionAuthority(store, CookieSigner(settings.session_signing_key)),
        guard=LoginGuard(store),
        bootstrap_secret=settings.admin_bootstrap_secret,
    )
    return await provision_from_command_line(
        identity,
        email=email,
        password=password,
        confirmation=confirmation,
        now=datetime.now(UTC),
    )


def main(argv: list[str]) -> int:
    """Prompt, then run. The terminal reads happen **outside** the event loop.

    `input` and `getpass` block until a human types, which inside an async context would
    stall the loop indefinitely -- a lint rule catches it, and the fix is also the right
    shape: the configuration is validated before the operator is asked for anything, so a
    misconfigured environment fails immediately rather than after a password has been
    typed twice.
    """
    if len(argv) != 2:
        print(USAGE, file=sys.stderr)
        return 2

    settings = load_settings(os.environ)
    email = input("Owner email address: ").strip()
    password = getpass("Password: ")
    confirmation = getpass("Confirm password: ")

    outcome = anyio.run(_run, Path(argv[1]), settings, email, password, confirmation)
    print(outcome.message, file=sys.stdout if outcome.created else sys.stderr)
    return outcome.exit_code


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
