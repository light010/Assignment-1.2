"""`OwnerIdentity` -- sign-in, one-shot provisioning, and the step order. **Hazard module.**

## Sign-in runs four steps, in this order, and the order is the rule

1. **Read both rate-limit windows**, keyed on the **normalised submitted email** and on
   the source address. Before the owner lookup, because `owner_id` does not exist yet and
   because reading them afterwards would let the lookup outcome decide whether the counter
   read happens at all.
2. **Always run a verification** (BR23.1). With no owner record, verify the submitted
   password against a **fixed dummy argon2id hash** and discard the result, so absence and
   wrong-password cost the same.
3. **On any refusal** -- unknown account, wrong password, **or a limit already reached** --
   record the failure against **both** windows and raise the not-authorized member.
4. **On success**, clear the account-scoped counter and issue a session.

**Step 1 does not return early, and that is the whole point.** A limit check that refused
and returned would skip the hash and restore exactly the timing difference BR23.1 removes:
argon2id is deliberately slow, so a request that does no hashing answers measurably
faster, and an attacker who can time two requests learns which email is the owner's
**without a single byte of the response differing**. The natural implementation -- check
the limit, refuse, return -- passes every assertion about the refusal body and fails only
`test_an_exhausted_window_does_not_short_circuit_the_verification`.

**The three refusals are one refusal.** Same member, same message, same extras, no
`Retry-After` and no "too many attempts" (BR3.20). This module raises; it composes no
status, no body and no sentence. The sentence `HttpApi` renders for every refusal here is
`app.errors.NOT_SIGNED_IN`, which carries a U+2019 apostrophe captured verbatim from the
running source -- it is product copy under the parity rule and is not reworded.

## Provisioning has two paths and one gate

**The gate is the record's existence** (BR3.7). Not a consumed flag, not a marker file,
not an environment variable: every other formulation has a state that can be reset from
outside the data -- a flag flipped, a file deleted with the volume, a variable re-set by
the next deployment. The record is the only state whose existence *is* the thing being
protected, so a restart, a redeploy and a fresh container all leave the gate exactly where
it was.

**The gate is `owner_record_create_if_absent`'s own return value**, never a read followed
by a write. It is atomic against a concurrent caller (BR22.13), and a read-then-write
spelling would pass every sequential test while losing a provisioning under a real race.
That matters more here than anywhere else in the system, because the operation **can never
be re-run once it has succeeded**: a lost provisioning on a container with no interactive
shell leaves a system nobody can sign in to and no route that will let them.

**With the bootstrap secret unset and no owner, the service runs and refuses every
sign-in** (BR3.9). It does not create an account -- auto-creating one to "make it work" is
exactly the default credential FR3.7 forbids -- and it does not fail to start, which would
turn a recoverable configuration state into an outage.

**No default, seeded, sample or hard-coded credential exists here**, in the schema this
runs against, or in any fixture. A fresh start against empty storage has no account anyone
can sign in to (BR3.10).

## The plaintext goes nowhere

Only the argon2id hash is stored. The password is passed to `PasswordHashing` and dropped;
it is never logged, never returned, and never placed in a raised error. The stored hash
goes to the verifying component and nowhere else (BR3.6) -- never parsed, never compared
inside the store, never logged.
"""

from __future__ import annotations

import re
import secrets
from dataclasses import dataclass
from datetime import datetime

from app.auth.guard import LoginGuard, account_window_key
from app.auth.hashing import PasswordHashing
from app.auth.sessions import IssuedSession, SessionAuthority
from app.auth.store import IdentityStore, OwnerRecord
from app.auth.tokens import new_opaque_id
from app.errors import Invalid, NotAuthorized

# ENT-1, assumption A-1: carried from the content schema's `email` rule so the system uses
# one email rule rather than two. Neither bound was decided at a gate; both are recorded
# in `entities.md` as the constraint to revisit if a longer address must be supported.
EMAIL_MAX_LENGTH = 200
EMAIL_PATTERN = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


@dataclass(frozen=True, slots=True)
class SignedIn:
    """What a successful sign-in produces. The CSRF token travels inside `session`."""

    owner_id: str
    session: IssuedSession


class OwnerIdentity:
    """The owner account, its argon2id hash, sign-in, and one-shot provisioning."""

    def __init__(
        self,
        *,
        store: IdentityStore,
        hashing: PasswordHashing,
        sessions: SessionAuthority,
        guard: LoginGuard,
        bootstrap_secret: str | None = None,
    ) -> None:
        self._store = store
        self._hashing = hashing
        self._sessions = sessions
        self._guard = guard
        # `None` means the one-shot provisioning route does not exist. It never means
        # "use a default": there is no default, and absence is a legitimate state.
        self._bootstrap_secret = bootstrap_secret

    async def sign_in(
        self, *, email: str, password: str, source_address: str, now: datetime
    ) -> SignedIn:
        """Sign the owner in, or raise the not-authorized member. See the module docstring."""
        account_key = account_window_key(email)

        # Step 1. Both windows, keyed on the normalised email, before the owner lookup.
        exhausted = await self._guard.is_exhausted(
            account_key=account_key, source_address=source_address, now=now
        )

        # Step 2. A verification ALWAYS runs. With no owner record the dummy hash is
        # verified and the result discarded, so absence costs what a wrong password costs.
        owner = await self._store.owner_record_read()
        stored_hash = owner.password_hash if owner is not None else self._hashing.dummy_hash
        matched = await self._hashing.verify_password(stored_hash, password)

        # Compared on the normalised form on both sides. The stored address is kept
        # verbatim (ENT-1: "not trimmed") while the window is keyed on the normalised
        # form, and matching on anything else would count an attempt under one key and
        # refuse it under another.
        addresses_the_owner = owner is not None and account_window_key(owner.email) == account_key

        # Step 3. Every operand above is already evaluated: this decides, it does not
        # short-circuit any work. `owner is None` is last so the success path below is
        # narrowed without an assertion.
        if exhausted or not matched or not addresses_the_owner or owner is None:
            await self._guard.record_failure(
                account_key=account_key, source_address=source_address, now=now
            )
            # No argument, so nothing distinguishes the three cases -- not the message,
            # not an extra field, not a header. `HttpApi` renders one sentence for all.
            raise NotAuthorized()

        # Step 4. The account-scoped counter only; the address-scoped one is not this
        # account's counter and clearing it would let one source reset its own limit.
        await self._guard.clear_account(account_key)
        return SignedIn(
            owner_id=owner.owner_id,
            session=await self._sessions.issue(owner.owner_id, now),
        )

    async def provisioning_offered(self) -> bool:
        """Whether the one-shot route exists at all: **both** conditions, every time (BR3.8).

        Re-evaluated on every call rather than captured at startup, because the owner
        record can appear underneath a running process -- provisioned from the command
        line, or by another instance -- and a route that stayed open until the next
        restart is an open provisioning route on a live system.
        """
        if self._bootstrap_secret is None:
            return False
        return await self._store.owner_record_read() is None

    async def provision(self, *, email: str, password: str, now: datetime) -> bool:
        """Create the owner if and only if none exists. `True` when this call created it.

        The return value **is** the gate: it comes from the store's atomic
        `create_if_absent`, so two simultaneous callers produce one record and one
        refusal. Nothing here reads the record first and decides.
        """
        _require_acceptable(email, password)
        return await self._store.owner_record_create_if_absent(
            OwnerRecord(
                owner_id=new_opaque_id(),
                email=email,
                password_hash=await self._hashing.hash_password(password),
                created_at=now,
                password_updated_at=None,
            )
        )

    async def provision_with_secret(
        self, *, secret: str, email: str, password: str, now: datetime
    ) -> None:
        """The one-shot route's path. Raises the not-authorized member on any refusal.

        Three refusals, all identical to the caller: no secret is configured, the supplied
        secret does not match, or an owner already exists. The secret is checked **before**
        the gate so a caller without it learns nothing about whether the system is
        provisioned.
        """
        configured = self._bootstrap_secret
        if configured is None:
            raise NotAuthorized()
        if not secrets.compare_digest(secret.encode("utf-8"), configured.encode("utf-8")):
            raise NotAuthorized()
        if not await self.provision(email=email, password=password, now=now):
            raise NotAuthorized()


def _require_acceptable(email: str, password: str) -> None:
    """ENT-1's two declared constraints, plus the one an empty password would breach.

    Raises the taxonomy's `Invalid` member **with no message of its own**: this unit
    composes no user-facing sentence, and the sentence a rejected provisioning request
    renders is `HttpApi`'s to choose alongside the route it builds. The command-line path
    catches this and writes its own operator text, which is terminal output rather than
    product copy.

    An empty password is refused because it hashes perfectly well and would be a
    credential anyone can supply -- the shape BR3.10 forbids, arrived at from the other
    direction.
    """
    if len(email) > EMAIL_MAX_LENGTH or EMAIL_PATTERN.match(email) is None:
        raise Invalid()
    if password == "":
        raise Invalid()
