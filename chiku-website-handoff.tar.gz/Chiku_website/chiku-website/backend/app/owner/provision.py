"""The command-line provisioning path -- the normal way the owner is created.

**Two paths, one gate.** This is the normal path: an operator with a shell runs it, is
prompted for an address and a password, and the argon2id hash of that password is stored.
The one-shot HTTP route exists only for a container with no interactive shell, and both
paths refuse through the same gate -- `OwnerIdentity.provision`, whose return value comes
from the store's atomic `create_if_absent`.

**Everything decidable is decided here, and the I/O is not.** This module takes the
address, the password and its confirmation as arguments and returns an outcome; reading
them from a terminal and exiting with the status belongs to `__main__.py`. That split is
what makes the refusals testable: "the confirmation did not match", "an owner already
exists" and "that address is not acceptable" are three different operator experiences and
each of them is an assertion rather than a prompt someone has to try by hand.

**The messages here are terminal output, not product copy.** They are written for an
operator standing at a shell, and they are deliberately more specific than anything the
HTTP surface is allowed to say: there is no enumeration concern at a local command line,
and an operator who cannot tell "already provisioned" from "wrong password confirmation"
will guess.

**No message ever contains the password or the hash.** A provisioning transcript tends to
end up pasted into a ticket.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from app.errors import Invalid
from app.owner.identity import OwnerIdentity

CONFIRMATION_MISMATCH = "The two passwords did not match. No account was created."
UNACCEPTABLE_DETAILS = "That email address or password was not acceptable. No account was created."
ALREADY_PROVISIONED = (
    "An owner account already exists. Provisioning is one-shot and cannot be re-run;"
    " the existing account was left untouched."
)
CREATED = "Owner account created. Sign in with the address and password you just supplied."

# Distinct non-zero statuses so a wrapper script can tell "the operator mistyped" from
# "this system is already provisioned"; both are failures and neither is an error.
EXIT_OK = 0
EXIT_ALREADY_PROVISIONED = 1
EXIT_REJECTED_INPUT = 2


@dataclass(frozen=True, slots=True)
class ProvisioningOutcome:
    """What happened, what to print, and what to exit with."""

    created: bool
    message: str
    exit_code: int


async def provision_from_command_line(
    identity: OwnerIdentity,
    *,
    email: str,
    password: str,
    confirmation: str,
    now: datetime,
) -> ProvisioningOutcome:
    """Create the owner from operator input, or report why not.

    The confirmation is compared before anything is hashed or stored: a mistyped password
    that reached the store would be unrecoverable on the one operation that cannot be
    re-run.
    """
    if password != confirmation:
        return ProvisioningOutcome(False, CONFIRMATION_MISMATCH, EXIT_REJECTED_INPUT)

    try:
        created = await identity.provision(email=email, password=password, now=now)
    except Invalid:
        # The taxonomy member `OwnerIdentity` raises, rendered here as operator text
        # rather than as the HTTP sentence, which is `HttpApi`'s to choose.
        return ProvisioningOutcome(False, UNACCEPTABLE_DETAILS, EXIT_REJECTED_INPUT)

    if not created:
        return ProvisioningOutcome(False, ALREADY_PROVISIONED, EXIT_ALREADY_PROVISIONED)
    return ProvisioningOutcome(True, CREATED, EXIT_OK)
