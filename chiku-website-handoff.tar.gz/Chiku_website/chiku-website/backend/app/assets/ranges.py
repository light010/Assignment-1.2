"""Byte-range parsing, ported branch-for-branch from `app/media-utils.ts:15-22`.

This is a hazard module: every outcome below is a branch whose silent loss ships a
defect, and each one is pinned by a recorded fixture in `fixtures/http/F11-range-*`.

Three behaviours here look wrong and are preserved deliberately, under the parity rule:

* An **oversized suffix** (`bytes=-N` where N > size) clamps the start to 0 and returns
  ``206 Partial Content`` for the whole object rather than ``416``.
  Fixture: ``F11-range-oversized-suffix`` -> 206, ``Content-Range: bytes 0-188617/188618``.
* A **HEAD** request never reaches this parser at all: the route returns 200 with the
  full ``Content-Length`` and ignores ``Range`` entirely.
  Fixture: ``F8-head-with-range-owner``.
* An **ETag** is emitted but a matching ``If-None-Match`` never produces ``304``.
  Fixture: ``F8-if-none-match-owner``.

Do not "fix" any of them here. A port that disagrees with the recorded source is the
failure this module exists to prevent.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum

# JavaScript's Number.MAX_SAFE_INTEGER. The source guards every parsed value with
# Number.isSafeInteger, so the port must apply the same ceiling -- Python ints are
# arbitrary precision and would silently accept values the source rejects.
MAX_SAFE_INTEGER = 2**53 - 1

# `\d` in Python matches Unicode decimal digits; JavaScript's `\d` is ASCII-only.
# Spelling the class out keeps a header like "bytes=\u0660-\u0669" rejected,
# exactly as the source rejects it.
_RANGE_RE = re.compile(r"bytes=([0-9]*)-([0-9]*)")

# ECMAScript trims the WhiteSpace and LineTerminator sets, which include U+FEFF.
# Python's str.strip() does not strip U+FEFF, so it is named explicitly.
_JS_WHITESPACE = (
    "\t\n\v\f\r "
    "\u00a0\u1680\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007"
    "\u2008\u2009\u200a\u2028\u2029\u202f\u205f\u3000\ufeff"
)


class RangeOutcome(Enum):
    """The non-range results the source distinguishes.

    ``INVALID`` means 416 with ``Content-Range: bytes */<size>``; the absence of a range
    (``None``) means serve the whole object with 200.
    """

    INVALID = "invalid"


@dataclass(frozen=True, slots=True)
class ByteRange:
    offset: int
    length: int


ParsedRange = ByteRange | RangeOutcome | None


def _js_number(text: str) -> float:
    """Emulate JavaScript's Number(string) for a digit string: an IEEE-754 double."""
    return float(text)


def _is_safe_integer(value: float) -> bool:
    """Emulate Number.isSafeInteger."""
    return value.is_integer() and abs(value) <= MAX_SAFE_INTEGER


def effective_range_header(
    range_header: str | None, if_range: str | None, etag: str | None
) -> str | None:
    """Port of the ``If-Range`` gate at `app/api/media/[key]/route.ts:14`.

        parseByteRange(!ifRange || ifRange === metadata.httpEtag ? range : null, size)

    A non-matching ``If-Range`` suppresses the range entirely, so the whole object is
    served with 200 -- it does **not** produce a 416. Fixtures ``F11-ifrange-mismatch``
    (200, full body) and ``F11-ifrange-match`` (206, 100 bytes) pin both sides.
    """
    if not if_range or if_range == etag:
        return range_header
    return None


def parse_byte_range(header: str | None, size: int) -> ParsedRange:
    """Port of `parseByteRange`. Returns a range, ``RangeOutcome.INVALID``, or ``None``.

    ``None`` means "no Range header was supplied" and is distinct from ``INVALID``:
    the first serves 200 with the whole body, the second serves 416 with an empty body.
    """
    if not header:
        return None

    match = _RANGE_RE.fullmatch(header.strip(_JS_WHITESPACE))
    start_text, end_text = (match.group(1), match.group(2)) if match else ("", "")

    # One guard, four reasons: no match at all; `bytes=-` with both sides empty; a size
    # that is not a safe integer; an empty object. The source folds these together and
    # so does the port, because they share an outcome and splitting them would invent a
    # distinction the fixtures cannot confirm.
    if (
        match is None
        or (not start_text and not end_text)
        or not _is_safe_integer(float(size))
        or size < 1
    ):
        return RangeOutcome.INVALID

    if not start_text:
        # Suffix form: `bytes=-N` asks for the final N bytes.
        suffix = _js_number(end_text)
        if not _is_safe_integer(suffix) or suffix <= 0:
            return RangeOutcome.INVALID
        start = max(0, size - int(suffix))
        end = size - 1
    else:
        start_value = _js_number(start_text)
        end_value = _js_number(end_text) if end_text else float(size - 1)
        if (
            not _is_safe_integer(start_value)
            or not _is_safe_integer(end_value)
            or start_value >= size
            or end_value < start_value
        ):
            return RangeOutcome.INVALID
        start = int(start_value)
        end = min(int(end_value), size - 1)

    return ByteRange(offset=start, length=end - start + 1)
