"""The ``AssetStore`` port and the head record.

Separate from both row stores because **a blob is not a row**, and the cloud
implementation is an entirely different service with a different consistency and pricing
model.

Definition only -- a `Protocol`, one frozen record, two error types and the entity-tag
derivation the local implementations share.

**The ranged read lives in this port** (BR22.11, BR7.17). `get_range` is a first-class
operation, not a convenience wrapper over `get`: an adapter that reads the whole object
and returns a slice satisfies the signature, returns the correct bytes, and passes every
functional assertion in the suite -- while making a 50 MB video cost 50 MB of transfer
for every seek. On a metered object store the failure mode is **cost and latency, not
incorrectness**, so no correctness test catches it.

**The arithmetic is the caller's.** ``offset`` and ``length`` arrive already resolved.
Every range branch -- the multi-range rejection, the zero-byte object, the oversized
suffix that yields the whole object, and the start/end asymmetry where a start past the
end is an error but an end past the end is silently clamped -- is decided above this port
by U5, in `app/assets/ranges.py`. The adapter clamps nothing, re-interprets nothing and
validates nothing; moving any of that down here would move a rule across a unit boundary
and duplicate it.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True, slots=True)
class ObjectHead:
    """What ``head`` returns: the object's own size, entity tag and media type.

    ``media_type`` here is **not** the media type the response carries. That comes from
    the `AssetMetadataRecord` row in `ContentStore` (BR7.18). The two stores hold the
    value independently and agree only because both were written from the same value at
    upload time; anything that syncs only one will serve mismatched types. The port does
    not reconcile them and an adapter must not -- reconciling would hide exactly the
    divergence BR7.18 exists to warn about.
    """

    size: int
    etag: str
    media_type: str


class AssetStoreError(Exception):
    """A store that could not answer. Absence, by contrast, is a return value."""


class ObjectNotFound(AssetStoreError):
    """`get_range` was asked for a key that is not stored.

    `get` and `head` return absence for a missing key, because discovering presence is
    what they are for. `get_range` is different: the caller has already resolved an
    offset and a length against a size it obtained from `head`, so a missing key here is
    a **caller defect** and is reported rather than papered over.
    """


class RangeNotAvailable(AssetStoreError):
    """The requested window is not fully present in the object.

    A caller defect, reported rather than **served short silently** -- short bytes would
    surface far away, as a truncated video, with nothing in the logs.
    """


def compute_etag(data: bytes) -> str:
    """A strong entity tag derived from the bytes themselves.

    **Stability is the whole obligation.** The serving path's conditional-range
    comparison (`app/assets/ranges.effective_range_header`) is exact string equality, so
    a tag that changes for unchanged bytes turns that comparison into a coin flip -- and
    the symptom is a client that silently re-downloads a whole video on every seek.

    Derived from a content hash rather than from an mtime or an inode, neither of which
    survives a container rebuild or a volume restore: both would change while the bytes
    did not, which is precisely the failure this rules out. The quoting makes the value a
    well-formed HTTP strong entity tag, because the serving path emits it verbatim.
    """
    return f'"{hashlib.sha256(data).hexdigest()}"'


class AssetStore(Protocol):
    """The contract U5 `media` persists bytes through.

    Every operation is ``async``; a blocking driver never leaves an adapter (BR22.7).
    """

    async def put(self, key: str, data: bytes, media_type: str) -> None:
        """Store the bytes under the key, **unchanged**.

        No transcoding, no re-encoding, no normalisation and no inspection. The store
        never derives a key, an extension or a type from anything: every one of those
        decisions was made by the consumer before this call.

        Used for the original **and for each derived variant** -- a variant is an ordinary
        object with its own key, and its lineage is recorded in the metadata row, not
        here.
        """
        ...

    async def get(self, key: str) -> bytes | None:
        """The whole object's bytes, or absence. Used where the whole object is wanted."""
        ...

    async def get_range(self, key: str, offset: int, length: int) -> bytes:
        """Exactly ``length`` bytes starting at ``offset``, transferred as a window.

        Raises `ObjectNotFound` when the key is absent and `RangeNotAvailable` when the
        window is not fully present.
        """
        ...

    async def head(self, key: str) -> ObjectHead | None:
        """Size, entity tag and media type, or absence."""
        ...

    async def delete(self, key: str) -> None:
        """**Idempotent**: deleting an absent key is a success (BR22.10).

        It exists for the best-effort cleanup path on a failed or cancelled upload and for
        no other purpose. The cleanup path cannot know how far the failed write got, so a
        delete that raised on an absent key would turn cleanup into a second failure that
        masks the first (BR6.24).
        """
        ...
