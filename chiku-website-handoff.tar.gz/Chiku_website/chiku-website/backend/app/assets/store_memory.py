"""The in-memory `AssetStore`. A second real implementation, not a mock.

`MemoryAssetStorage` is separate from the store because several conformance assertions
need a second, independent handle over the same storage -- an entity tag that survives one
-- and because it is the fake's equivalent of the volume the real adapter writes to.

It exposes `read_all` and `read_window` as two distinct operations even though an
in-memory store transfers nothing. That is deliberate: BR22.11's obligation is that
`get_range` asks its underlying store for **the window** rather than for the object, and
if the fake had only one read operation the obligation would be unexpressible against it
-- so the two implementations would be certified by different assertions, which is exactly
what BR22.4 exists to prevent.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from app.assets.store import (
    ObjectHead,
    ObjectNotFound,
    RangeNotAvailable,
    compute_etag,
)


@dataclass
class StoredObject:
    """One object, with the same held values as the volume adapter's sidecar plus bytes."""

    data: bytes
    media_type: str
    etag: str


@dataclass
class MemoryAssetStorage:
    """The storage every handle opened over it shares."""

    objects: dict[str, StoredObject] = field(default_factory=dict)

    def read_all(self, key: str) -> bytes:
        return self.objects[key].data

    def read_window(self, key: str, offset: int, length: int) -> bytes:
        """Return only the requested window.

        There is no transfer to economise on in memory. What this method is for is
        making the *shape* of the request the same across both implementations, so the
        suite asserts one obligation rather than two different ones.
        """
        return self.objects[key].data[offset : offset + length]


class InMemoryAssetStore:
    """`AssetStore` over a `MemoryAssetStorage`."""

    def __init__(self, storage: MemoryAssetStorage) -> None:
        self._storage = storage

    async def put(self, key: str, data: bytes, media_type: str) -> None:
        # Stored unchanged. The entity tag is derived from the bytes at write time, the
        # same way and by the same function as the volume adapter's, so it is stable for
        # unchanged bytes and changes when they change.
        self._storage.objects[key] = StoredObject(
            data=data, media_type=media_type, etag=compute_etag(data)
        )

    async def get(self, key: str) -> bytes | None:
        if key not in self._storage.objects:
            return None
        return self._storage.read_all(key)

    async def get_range(self, key: str, offset: int, length: int) -> bytes:
        stored = self._storage.objects.get(key)
        if stored is None:
            raise ObjectNotFound(key)
        if offset < 0 or length < 0 or offset + length > len(stored.data):
            raise RangeNotAvailable(
                f"{key}: bytes {offset}-{offset + length - 1} of {len(stored.data)}"
            )
        # The window, asked for as a window (BR22.11).
        return self._storage.read_window(key, offset, length)

    async def head(self, key: str) -> ObjectHead | None:
        stored = self._storage.objects.get(key)
        if stored is None:
            return None
        return ObjectHead(size=len(stored.data), etag=stored.etag, media_type=stored.media_type)

    async def delete(self, key: str) -> None:
        # Idempotent without a branch (BR22.10).
        self._storage.objects.pop(key, None)
