"""The locally verified `AssetStore`: bytes on a mounted volume.

Each object is two files under the volume root -- the bytes, and a small sidecar holding
the size, the entity tag and the media type.

**The sidecar is what makes an object exist.** `head`, `get` and `get_range` all consult
it first, and the write order is bytes-then-sidecar while the delete order is
sidecar-then-bytes. So an interrupted write leaves an invisible orphan, which is
reclaimable garbage, rather than a record pointing at bytes that are not there, which is
corruption -- the same ordering argument BR22.8 makes for the cloud adapter's large
payloads.

**The entity tag is a content hash computed at `put` and stored in the sidecar**, never
derived from mtime or inode. Those change while the bytes do not -- a container rebuild,
a volume restore, a `cp -r` -- and the serving path's conditional-range comparison is
exact string equality, so an unstable tag silently suppresses every ranged read and
re-sends whole videos. This was the open question carried into generation and it is
resolved here rather than substituted quietly.

**A key never reaches the filesystem as a path component.** The store validates nothing
(BR22.6), so it cannot reject a key containing `/` or `..` -- and it must not be traversed
by one either. Encoding the key makes traversal structurally impossible instead of
checked, and the encoding is total, lossless and reversible, which is the representation
conversion BR22.6 permits.

Every filesystem call runs off the event loop through `anyio.to_thread.run_sync`: file
I/O is a blocking driver like any other, and a consumer never blocks on one (BR22.7).
"""

from __future__ import annotations

import base64
import json
import os
from functools import partial
from pathlib import Path

from anyio import to_thread

from app.assets.store import (
    ObjectHead,
    ObjectNotFound,
    RangeNotAvailable,
    compute_etag,
)

_OBJECT_SUFFIX = ".bin"
_SIDECAR_SUFFIX = ".json"


def encode_key(key: str) -> str:
    """The on-disk name for a key. Total, lossless, reversible, and never a path.

    URL-safe base64 without padding: its alphabet is ``A-Z a-z 0-9 - _``, none of which
    is a path separator and none of which can spell ``..``.
    """
    return base64.urlsafe_b64encode(key.encode("utf-8")).decode("ascii").rstrip("=")


def read_window(path: Path, offset: int, length: int) -> bytes:
    """Read exactly ``length`` bytes at ``offset``, without reading the rest of the file.

    Module level and named rather than inlined, because this is the seam at which
    BR22.11 is observable. That obligation is about **transfer volume**, and transfer
    volume is invisible to an assertion on the returned bytes: reading the whole object
    and slicing returns byte-identical results and passes every correctness test, while
    making a 50 MB video cost 50 MB per seek. `pread` is the call that makes the
    difference real -- it reads from the offset without pulling anything before it.
    """
    with path.open("rb") as handle:
        return os.pread(handle.fileno(), length, offset)


def _write_object(object_path: Path, sidecar_path: Path, data: bytes, media_type: str) -> None:
    object_path.parent.mkdir(parents=True, exist_ok=True)
    # Bytes first. The sidecar is what publishes the object, so the window in which a
    # crash is possible leaves garbage rather than a dangling record.
    object_path.write_bytes(data)
    sidecar_path.write_text(
        json.dumps({"size": len(data), "etag": compute_etag(data), "media_type": media_type}),
        encoding="utf-8",
    )


def _read_sidecar(sidecar_path: Path) -> ObjectHead | None:
    try:
        raw = sidecar_path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return None
    payload = json.loads(raw)
    return ObjectHead(
        size=int(payload["size"]),
        etag=str(payload["etag"]),
        media_type=str(payload["media_type"]),
    )


def _read_all(object_path: Path, sidecar_path: Path) -> bytes | None:
    if _read_sidecar(sidecar_path) is None:
        return None
    return object_path.read_bytes()


def _delete_object(object_path: Path, sidecar_path: Path) -> None:
    # Sidecar first, so the object stops existing before its bytes do. `missing_ok` is
    # the idempotence of BR22.10: the cleanup path cannot know how far a failed upload
    # got, and a delete that raised on an absent key would mask the original error.
    sidecar_path.unlink(missing_ok=True)
    object_path.unlink(missing_ok=True)


class VolumeAssetStore:
    """`AssetStore` over a directory on a durable volume."""

    def __init__(self, root: Path) -> None:
        self._root = root

    def _object_path(self, key: str) -> Path:
        return self._root / f"{encode_key(key)}{_OBJECT_SUFFIX}"

    def _sidecar_path(self, key: str) -> Path:
        return self._root / f"{encode_key(key)}{_SIDECAR_SUFFIX}"

    async def put(self, key: str, data: bytes, media_type: str) -> None:
        # Unchanged: no transcoding, no re-encoding, no normalisation, no inspection.
        # The store derives no key, no extension and no type from anything -- every one
        # of those decisions was taken by the consumer before this call.
        await to_thread.run_sync(
            partial(
                _write_object,
                self._object_path(key),
                self._sidecar_path(key),
                data,
                media_type,
            )
        )

    async def get(self, key: str) -> bytes | None:
        return await to_thread.run_sync(
            partial(_read_all, self._object_path(key), self._sidecar_path(key))
        )

    async def get_range(self, key: str, offset: int, length: int) -> bytes:
        head = await self.head(key)
        if head is None:
            raise ObjectNotFound(key)
        if offset < 0 or length < 0 or offset + length > head.size:
            # Reported, never served short. The adapter clamps nothing and
            # re-interprets nothing: every range branch -- the oversized suffix, the
            # zero-byte object, the end past the end that is silently clamped -- is
            # decided above this port, and repeating any of it here would duplicate a
            # rule across a unit boundary (BR22.11).
            raise RangeNotAvailable(f"{key}: bytes {offset}-{offset + length - 1} of {head.size}")
        return await to_thread.run_sync(
            partial(read_window, self._object_path(key), offset, length)
        )

    async def head(self, key: str) -> ObjectHead | None:
        return await to_thread.run_sync(partial(_read_sidecar, self._sidecar_path(key)))

    async def delete(self, key: str) -> None:
        await to_thread.run_sync(
            partial(_delete_object, self._object_path(key), self._sidecar_path(key))
        )
