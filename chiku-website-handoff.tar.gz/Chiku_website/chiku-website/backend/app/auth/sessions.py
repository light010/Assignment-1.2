"""`SessionAuthority` -- issue, verify, touch, revoke, and the two bounds. **Hazard module.**

## The one line that matters most

`session_touch` advances `last_seen_at` **and nothing else**. `absolute_expires_at` is
computed once, at issue, and is **never extended -- not by a touch, not by anything**.

The tempting simplification is one expiry timestamp refreshed on use. It satisfies BR3.14
exactly and destroys BR3.15 completely, and **every test written against idle expiry still
passes**, because a session used every hour never reaches the idle bound in either design.
The only test that separates the two runs for more than seven days of simulated time. This
is the closest thing in the unit to a silent failure, which is why the asymmetry is stated
in the port, in both adapters, and again here.

**The two expiry transitions are independent and whichever fires first wins.** A session
used every hour for eight days reaches the absolute bound; a session issued and left alone
reaches the idle bound after eight hours. They are not alternatives and not a maximum of
each other.

**There is no renewal path and no Renewed state.** Nothing extends a session; the owner
signs in again, which issues a new one with a new absolute bound.

## Identity or nothing

Verification returns the owner identity **or nothing, never a third answer** (BR3.16).
Revoked, idle-expired, absolutely expired, absent, tampered and unsigned are one outcome
to every caller. A three-valued result invites a caller to treat "expired" differently
from "absent" -- a distinction no caller needs and an attacker can use.

**A revoked record is retained; an expired one is meant to be deleted** (BR23.2). The
asymmetry follows from purpose: a revoked record must keep failing verification, so
deleting it would make revocation indistinguishable from an unknown session at the storage
layer. See § *The reclamation half of BR23.2* below for why the deletion does not happen
here.

## This unit composes no response

No status, no sentence, no envelope, no `Set-Cookie` header. `issue` returns a `CookieSpec`
describing the cookie BR3.11 requires and `HttpApi` renders it. The same-origin check
(BR3.3-BR3.5) is U6's and is **not** replaced by `require_csrf`; both apply to every
mutation.

## The reclamation half of BR23.2

BR23.2 says a record found past either bound is **deleted as it is rejected**, with the
deletion as housekeeping that never changes the outcome. **`IdentityStore` exposes no
delete.** Its session group is `create / read / touch / revoke`, fixed by
`contract-design` § C3 and implemented by all three adapters, so this unit has no
operation with which to reclaim the record it has just rejected.

That is **surfaced, not closed here**: adding an operation to another unit's port would
change an approved contract and land outside its conformance suite. It is recorded in
`code-summary.md` § *Gaps surfaced, not closed* with a named owner, alongside the unit's
already-carried open item that no session retention policy exists at all. What this module
does implement is the half that is reachable and the half that is load-bearing: the record
is rejected, and it stays rejected.
"""

from __future__ import annotations

import secrets
from dataclasses import dataclass
from datetime import datetime, timedelta

from app.auth.store import IdentityStore, SessionRecord
from app.auth.tokens import CookieSigner, CookieSpec, cleared_session_cookie, session_cookie
from app.auth.tokens import new_opaque_id as _new_opaque_id
from app.errors import NotAuthorized

# D2. Stated once, here, because this is the component that owns them.
IDLE_LIMIT = timedelta(hours=8)
ABSOLUTE_LIFETIME = timedelta(days=7)


@dataclass(frozen=True, slots=True)
class IssuedSession:
    """What a successful sign-in produces.

    `csrf_token` goes in the response **body**. `cookie` is the only cookie, and it
    carries only the signed session identifier.
    """

    session_id: str
    csrf_token: str
    cookie: CookieSpec


@dataclass(frozen=True, slots=True)
class VerifiedSession:
    """The owner identity, plus the token a mutation has to echo back.

    This is the "identity" half of *identity or nothing*. There is no variant of it that
    means "expired" or "revoked": those are the nothing.
    """

    session_id: str
    owner_id: str
    csrf_token: str


class SessionAuthority:
    """Sessions, their two bounds, their revocation and their CSRF token."""

    def __init__(
        self,
        store: IdentityStore,
        signer: CookieSigner,
        *,
        idle_limit: timedelta = IDLE_LIMIT,
        absolute_lifetime: timedelta = ABSOLUTE_LIFETIME,
    ) -> None:
        self._store = store
        self._signer = signer
        self._idle_limit = idle_limit
        self._absolute_lifetime = absolute_lifetime

    async def issue(self, owner_id: str, now: datetime) -> IssuedSession:
        """Issue a session. `absolute_expires_at` is computed **here and only here**."""
        session_id = _new_opaque_id()
        csrf_token = _new_opaque_id()
        await self._store.session_create(
            SessionRecord(
                session_id=session_id,
                owner_id=owner_id,
                issued_at=now,
                last_seen_at=now,
                # Once. Every later write in this module leaves this value alone.
                absolute_expires_at=now + self._absolute_lifetime,
                revoked_at=None,
                csrf_token=csrf_token,
            )
        )
        return IssuedSession(
            session_id=session_id,
            csrf_token=csrf_token,
            cookie=session_cookie(self._signer.sign(session_id)),
        )

    async def verify(self, signed_cookie: str | None, now: datetime) -> VerifiedSession | None:
        """The owner identity, or nothing.

        Both bounds are applied **here**: the store returns the record as stored and
        evaluates no expiry (BR22.14), so a filter in the adapter would be a second
        evaluation free to drift from this one.
        """
        session_id = self._signer.unsign(signed_cookie)
        if session_id is None:
            # Absent, empty, tampered or signed under another key. Anonymous, not an
            # error: an unsigned cookie is simply not a session.
            return None

        record = await self._store.session_read(session_id)
        if record is None:
            return None

        if record.revoked_at is not None:
            # Retained, not reclaimed. Its whole purpose is to keep failing.
            return None

        if now - record.last_seen_at > self._idle_limit:
            return None

        if now > record.absolute_expires_at:
            # Reached even though the session was used a moment ago. This is the branch
            # a single refreshed timestamp removes entirely.
            return None

        # `last_seen_at` only. `absolute_expires_at` is not passed, not recomputed, and
        # not reachable from here.
        await self._store.session_touch(session_id, now)
        return VerifiedSession(
            session_id=session_id,
            owner_id=record.owner_id,
            csrf_token=record.csrf_token,
        )

    async def sign_out(self, signed_cookie: str | None, now: datetime) -> CookieSpec:
        """Revoke server-side, then hand back the cookie that clears the browser copy.

        **The stored write is the rule and the cookie clear is the courtesy** (BR3.17): a
        stolen cookie must stop working, not merely vanish from the browser that had it
        legitimately, and a revoked session fails the very next verification.

        Signing out an unknown or unsigned cookie is a no-op that still returns the
        clearing cookie -- sign-out reveals nothing either.
        """
        session_id = self._signer.unsign(signed_cookie)
        if session_id is not None:
            await self._store.session_revoke(session_id, now)
        return cleared_session_cookie()

    def require_csrf(self, session: VerifiedSession, supplied: str | None) -> None:
        """Compare the request header against this session's stored token (BR3.12).

        Raises the not-authorized member on a mismatch or an absent header. It does
        **not** replace the same-origin check, which is U6's and runs on the same
        mutations; the double-submit is added on top of it, never instead of it.

        Compared byte-wise in constant time, and encoded first so a non-ASCII header
        value is a refusal rather than a `TypeError` that would surface as a 503.
        """
        if supplied is None or not secrets.compare_digest(
            supplied.encode("utf-8"), session.csrf_token.encode("utf-8")
        ):
            raise NotAuthorized()
