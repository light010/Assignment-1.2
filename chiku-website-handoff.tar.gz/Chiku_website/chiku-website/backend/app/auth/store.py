"""The ``IdentityStore`` port and the three shapes it persists.

Separate from `ContentStore` because identity has a different reason to change and a
different blast radius: the credential hash and the session records are the highest-value
data in the system, and **a defect in a content query cannot reach them through a port
that does not expose them**.

Definition only -- a `Protocol` plus frozen record shapes. No I/O, no rule, no threshold.

Three things this port deliberately does not do, each named because an implementer will
be tempted:

* **It evaluates no expiry** (BR22.14). ``session_read`` returns a record past either
  bound exactly as stored; the consumer applies both. A store that filtered expired
  sessions would enforce a rule it does not own, and the two evaluations would drift into
  two different expiry policies with no test that compares them.
* **It compares against no threshold.** 5 per account and 20 per source address are the
  consumer's numbers. `login_attempts_count_in_window` returns a count, not a verdict.
* **It never touches the hash** (BR3.6). ``password_hash`` is an argon2id PHC string
  stored verbatim and returned to the verifying component only. The store never parses
  it, never compares it, never derives from it and never logs it.

**No seeded credential exists anywhere in this unit** -- not in an adapter, not in schema
setup, not in a fixture. `owner_record_create_if_absent` is the one-shot provisioning
gate and its gate condition is the record's existence, so a restart cannot reopen it.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Literal, Protocol

# `account` | `ip`. The two scopes are counted independently, as separate records with
# separate scopes -- not one record with two counters.
type AttemptScope = Literal["account", "ip"]


@dataclass(frozen=True, slots=True)
class OwnerRecord:
    """The single site owner. Exactly one ever exists; the store ships none.

    ``owner_id`` is opaque and **never derived from the email**.
    """

    owner_id: str
    email: str
    password_hash: str
    created_at: datetime
    password_updated_at: datetime | None


@dataclass(frozen=True, slots=True)
class SessionRecord:
    """One issued session, with both expiry bounds stored separately.

    That asymmetry is the entire reason both timestamps exist: ``last_seen_at`` slides,
    ``absolute_expires_at`` never does. An adapter that "helpfully" refreshed both would
    destroy the absolute bound while every test that only checks idle expiry still passes.

    The store **generates nothing**: every opaque value arrives from the consumer.
    """

    session_id: str
    owner_id: str
    issued_at: datetime
    last_seen_at: datetime
    absolute_expires_at: datetime
    revoked_at: datetime | None
    csrf_token: str


@dataclass(frozen=True, slots=True)
class LoginAttemptWindow:
    """One rolling failure window for one counted subject in one scope.

    Identity is ``(scope, window_key)``. Persisted, so a process restart does not reset a
    window (BR3.22) -- an in-memory counter is not an acceptable real adapter.
    """

    scope: AttemptScope
    window_key: str
    failure_count: int
    window_started_at: datetime


def window_is_current(window_started_at: datetime, now: datetime, window_length: timedelta) -> bool:
    """Whether ``now`` still falls inside the window that began at ``window_started_at``.

    The window covers ``[window_started_at, window_started_at + window_length)``: an
    elapsed time of exactly ``window_length`` has rolled over.

    Both implementations share this one predicate deliberately. If the count operation
    and the record operation each carried their own copy, a rolled-over window could be
    counted as zero by one and incremented by the other, and the counter would drift in
    a direction nobody chose.
    """
    return now - window_started_at < window_length


class IdentityStore(Protocol):
    """The contract U3 `identity-and-session` persists through.

    Every operation is ``async``; a blocking driver never leaves an adapter (BR22.7).
    Absence is a return value, not an error.
    """

    async def owner_record_read(self) -> OwnerRecord | None:
        """The owner record including its stored hash, or absence.

        The hash goes to the verifying component and **nowhere else** (BR3.6).
        """
        ...

    async def owner_record_create_if_absent(self, record: OwnerRecord) -> bool:
        """Create the owner **only if none exists**; report which happened.

        Returns ``True`` when this call created the record and ``False`` when one already
        existed.

        This is the one-shot provisioning gate (BR3.7), and the gate condition is **the
        record's existence** -- not a consumed flag, not a marker file, not an environment
        variable. A restart cannot reopen it.

        **It must be atomic against a concurrent caller** (BR22.13): two simultaneous
        attempts produce one record and one refusal, never two records and never a lost
        one. A read-then-write implementation does not satisfy this. It matters more here
        than almost anywhere else in the system, because the operation can never be re-run
        once it has succeeded -- a lost provisioning on a container with no interactive
        shell leaves a system nobody can sign in to and no route that will let them.
        """
        ...

    async def session_create(self, record: SessionRecord) -> None:
        """Store the session as given. The store generates nothing."""
        ...

    async def session_read(self, session_id: str) -> SessionRecord | None:
        """The record as stored, or absence. **No expiry is evaluated** (BR22.14)."""
        ...

    async def session_touch(self, session_id: str, now: datetime) -> None:
        """Advance ``last_seen_at`` and **leave ``absolute_expires_at`` alone**.

        Touching a session that is not there is a no-op; the consumer discovers absence
        through `session_read`, which is the operation that reports it.
        """
        ...

    async def session_revoke(self, session_id: str, now: datetime) -> None:
        """Write ``revoked_at``. **Server-side** (BR3.17).

        A stolen cookie stops working rather than merely disappearing from one browser,
        and a revoked session must fail the **very next** `session_read`. Clearing a
        cookie does not satisfy this. Revoking an absent session is a no-op.
        """
        ...

    async def login_attempts_record_failure(
        self,
        scope: AttemptScope,
        window_key: str,
        now: datetime,
        window_length: timedelta,
    ) -> None:
        """Increment the counter for that scope and key, starting a new window on rollover.

        The two scopes are counted **independently**: one record keyed by account, one by
        source address, with separate rows and separate scopes -- not one row with two
        counters.

        ``window_length`` is here because the operation's own specified behaviour --
        *"starting a new window when the current one has rolled over"* -- is not decidable
        without it, and the persisted shape is a counter plus a window start rather than a
        list of instants. See `code-summary.md` § *Deviations*.
        """
        ...

    async def login_attempts_count_in_window(
        self,
        scope: AttemptScope,
        window_key: str,
        now: datetime,
        window_length: timedelta,
    ) -> int:
        """The failure count inside the current rolling window, or ``0`` once it rolled over.

        **It compares nothing against a threshold.** 5 per account and 20 per source
        address are the consumer's numbers, and a store that knew them would be enforcing
        a rule it does not own.
        """
        ...

    async def login_attempts_clear(self, scope: AttemptScope, window_key: str) -> None:
        """Reset that counter. Called on a successful sign-in for the account scope.

        Idempotent: clearing a counter that is not there is a success.
        """
        ...
