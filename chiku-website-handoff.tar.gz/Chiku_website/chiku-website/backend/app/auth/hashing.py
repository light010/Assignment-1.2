"""argon2id, and the fixed dummy hash that makes BR23.1 true. **Hazard module.**

**BR3.20 governs the body; it does not govern the clock.** A sign-in against a
non-existent account that returns without hashing anything produces a byte-identical
refusal and returns measurably faster -- and argon2id is *deliberately* slow, so the gap
is large rather than marginal. An attacker who can time two requests then learns which
email is the owner's, which is exactly what BR3.6 and BR3.20 exist to prevent, **without a
single byte of the response differing**.

`dummy_hash` is the answer: when there is no owner record, the submitted password is
verified against it and the result discarded, so absence and wrong-password cost the same.

**The dummy hash is generated, never written down**, and that is a correctness property
rather than tidiness:

* It is produced by **this instance's own hasher**, so its verification cost tracks the
  production cost by construction. A hard-coded PHC string freezes the parameters it was
  minted with, and a later change to the production cost silently re-opens the timing gap
  the constant was added to close -- with nothing failing.
* A malformed placeholder is **worse than useless**: argon2 rejects it before doing any
  work, so the equalisation quietly does not happen while every assertion about the
  refusal body still passes.
* Its preimage is 32 random bytes that are discarded immediately, so no password produces
  it and it is not a credential. Keeping it out of the source tree also keeps an argon2id
  digest out of the source tree, which is the shape BR3.10 forbids.

**The hash goes to the verifying component and nowhere else** (BR3.6). It is never
logged, never parsed, never compared inside the store, and `verify_password` answers a
plain yes or no -- never *why* a verification failed and never whether the account exists.
A malformed stored hash is a "no", not an error, for that reason: an exception that
escaped here would be a third answer.

**Both operations run off the event loop.** argon2id at the production parameters takes
tens of milliseconds of CPU, which is long enough to stall every other request in the
process. Event-loop blocking is invisible to every check on the merge gate, which is why
the thread hop is written into the component rather than left to a caller to remember.
"""

from __future__ import annotations

import secrets

from anyio import to_thread
from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError

# The preimage of the dummy hash. Generated, used once, and never retained.
DUMMY_PREIMAGE_BYTES = 32


def production_hasher() -> PasswordHasher:
    """argon2id at `argon2-cffi`'s current recommended parameters.

    Deferring to the library rather than pinning numbers here means a parameter the
    library raises for good reason is picked up by an ordinary dependency bump. The cost
    is a security setting; it is not a knob a test may turn.
    """
    return PasswordHasher()


def low_cost_hasher() -> PasswordHasher:
    """Deliberately weak parameters, for a test suite's clock. **Never for production.**

    It exists so that no test is ever tempted to lower `production_hasher`'s cost to make
    the suite fast. The properties the suite asserts -- that a verification always runs,
    that a malformed hash is a "no" -- hold at any cost; the milliseconds are asserted
    nowhere.
    """
    return PasswordHasher(time_cost=1, memory_cost=8, parallelism=1, hash_len=16, salt_len=8)


class PasswordHashing:
    """The only component in the system that hashes or verifies a password."""

    def __init__(self, hasher: PasswordHasher) -> None:
        self._hasher = hasher
        # Minted from this hasher, so it costs what a real verification costs. The
        # preimage goes out of scope on the next line and is never stored, logged or
        # returned.
        self._dummy_hash = hasher.hash(secrets.token_urlsafe(DUMMY_PREIMAGE_BYTES))

    @property
    def dummy_hash(self) -> str:
        """The hash to verify against when there is no owner record (BR23.1).

        Fixed for the lifetime of this component, so every attempt against an absent
        account costs the same as every other.
        """
        return self._dummy_hash

    async def hash_password(self, password: str) -> str:
        """The argon2id PHC string to store. The plaintext is not retained."""
        return await to_thread.run_sync(self._hasher.hash, password)

    async def verify_password(self, stored_hash: str, password: str) -> bool:
        """Matched, or not matched. **Never why, and never whether the account exists.**"""
        return await to_thread.run_sync(self._verify, stored_hash, password)

    def _verify(self, stored_hash: str, password: str) -> bool:
        try:
            return self._hasher.verify(stored_hash, password)
        except VerificationError, InvalidHashError:
            # `VerifyMismatchError` (wrong password) and `InvalidHashError` (a stored
            # string argon2 cannot parse) collapse to the same answer on purpose. A
            # caller that could tell them apart could tell a wrong password from a
            # corrupt record, and BR3.6 answers only the one question.
            return False


def production_hashing() -> PasswordHashing:
    """`PasswordHashing` at the production cost. Called once, at startup."""
    return PasswordHashing(production_hasher())
