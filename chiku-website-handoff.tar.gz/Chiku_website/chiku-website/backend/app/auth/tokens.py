"""Opaque identifiers, the signed session cookie, and the shape of that cookie.

**What is preserved here is not the source's mechanism.** The source's local identity came
from a vendored dev-server middleware that, on seeing one cookie, injected a fixed user id
and email as request headers -- and **stripped every client-supplied identity header
before injecting its own**, so sending those headers directly still returned 403. The
trust boundary was the middleware, not the header. The property that must survive the port
is therefore **"a client cannot assert its own identity"**, and it is carried by the two
things in this module:

* the cookie holds **only an opaque session identifier** -- no owner id, no expiry, no
  role, nothing the server then believes (BR3.11);
* the identifier is **signed**, so it cannot be authored, and it is **unguessable**, so it
  cannot be found.

A cookie that carried a claim would replace the platform auth in form and lose the only
security property it had. A self-describing token would also be unrevocable, which is what
makes `revoked_at` mean anything.

**This module composes no HTTP response.** `CookieSpec` is a description of the cookie
this unit requires, not a `Set-Cookie` header: `HttpApi` renders it, exactly as it renders
the error envelope. Stating the attributes here rather than at the route is what makes
BR3.11 a property of the unit that owns sessions instead of a convention the route layer
has to remember.

**The CSRF token is not in this cookie and is not in any cookie** (BR3.12). It is returned
in the sign-in response **body** and echoed back as a request header, because a
double-submit defence works only while the attacker's page cannot read the value -- and a
token the browser attaches automatically to every cross-site request defends nothing at
all. It is minted by the same generator as the session identifier because it needs exactly
the same property: unguessable, from a cryptographic RNG, derived from nothing.
"""

from __future__ import annotations

import secrets
from dataclasses import dataclass

from itsdangerous import BadData, URLSafeSerializer

SESSION_COOKIE_NAME = "chiku_session"

# Namespaces this signature. A value signed for one purpose does not verify for another
# even under the same key, which keeps a future signed artefact from being replayed as a
# session identifier.
SESSION_COOKIE_SALT = "chiku.session.v1"

# The request header the CSRF token comes back in. A header, never a cookie.
CSRF_HEADER_NAME = "X-CSRF-Token"

SAME_SITE_LAX = "lax"
COOKIE_PATH = "/"

# A-3 fixes no length. 32 bytes from `secrets` is at or above the strength the entity
# model asks for, and `token_urlsafe` renders them in 43 URL-safe characters.
OPAQUE_ID_BYTES = 32


def new_opaque_id() -> str:
    """An unguessable identifier from a cryptographic RNG, derived from nothing.

    Used for `owner_id`, `session_id` and `csrf_token` alike. Never derived from an
    email, from another identifier, or from anything a client supplied: a derivable
    identifier is a client-assertable identity, which is the thing the old middleware
    existed to prevent.
    """
    return secrets.token_urlsafe(OPAQUE_ID_BYTES)


@dataclass(frozen=True, slots=True)
class CookieSpec:
    """What the route layer must set, described rather than rendered."""

    name: str
    value: str
    http_only: bool
    secure: bool
    same_site: str
    path: str
    # `None` is a session cookie -- it lives until the browser closes. `0` clears it.
    # Nothing here is the authority on expiry: both bounds are evaluated server-side on
    # every request, and a cookie that outlives its record simply verifies as nothing.
    max_age: int | None


def session_cookie(signed_session_id: str) -> CookieSpec:
    """The cookie a successful sign-in sets (BR3.11).

    All three attributes are present and none is optional: a readable cookie
    (`HttpOnly` missing) or a cross-site-submittable one (`SameSite` missing) makes every
    other session rule weaker than it looks.
    """
    return CookieSpec(
        name=SESSION_COOKIE_NAME,
        value=signed_session_id,
        http_only=True,
        secure=True,
        same_site=SAME_SITE_LAX,
        path=COOKIE_PATH,
        max_age=None,
    )


def cleared_session_cookie() -> CookieSpec:
    """The cookie sign-out sets. **The courtesy, not the rule.**

    The rule is the stored revocation (BR3.17): a stolen cookie must stop working rather
    than merely disappear from the browser that had it legitimately. Clearing the cookie
    alone satisfies nothing.
    """
    return CookieSpec(
        name=SESSION_COOKIE_NAME,
        value="",
        http_only=True,
        secure=True,
        same_site=SAME_SITE_LAX,
        path=COOKIE_PATH,
        max_age=0,
    )


class CookieSigner:
    """Signs and recovers the session identifier, and nothing else.

    It deliberately has no "sign this arbitrary value" operation. The signing key
    authenticates exactly one kind of statement -- *this is a session identifier this
    server issued* -- and a general-purpose signer over the same key would let some other
    signed artefact be presented as one.
    """

    def __init__(self, signing_key: str) -> None:
        self._serializer = URLSafeSerializer(signing_key, salt=SESSION_COOKIE_SALT)

    def sign(self, session_id: str) -> str:
        return self._serializer.dumps(session_id)

    def unsign(self, signed: str | None) -> str | None:
        """The identifier this server signed, or nothing.

        Absent, empty, tampered, signed under another key, or correctly signed but of the
        wrong shape all return `None`. **There is no error and no distinct outcome**: an
        unsigned or tampered cookie is simply not a session, and a caller that could tell
        those cases apart would have a channel this unit does not offer.
        """
        if not signed:
            return None
        try:
            payload = self._serializer.loads(signed)
        except BadData:
            return None
        if not isinstance(payload, str):
            return None
        return payload
