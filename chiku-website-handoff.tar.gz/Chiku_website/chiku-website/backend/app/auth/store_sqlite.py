"""The locally verified `IdentityStore` adapter. **Hazard module: `create_if_absent`.**

`owner_record_create_if_absent` is the one-shot provisioning gate (BR3.7), and it is a
hazard for a reason no other operation here shares: **it can never be re-run once it has
succeeded.** A lost provisioning on a container with no interactive shell leaves a system
nobody can sign in to and no route that will let them.

**Atomicity comes from the statement, not from a lock** (BR22.13). The insert names the
`singleton` uniqueness constraint as a conflict target and does nothing on conflict, so
two simultaneous callers produce one record and one refusal inside SQLite itself. A
read-then-write spelling -- SELECT, then INSERT if absent -- would pass every sequential
test and lose a provisioning under a real race. It is also why `app/sqlite.py` gives each
operation its own connection: a shared connection behind a lock would have removed the
interleaving rather than survived it, and the suite's race would then certify nothing.

**The gate condition is the record's existence**, not a consumed flag, not a marker file,
not an environment variable -- so a container restart cannot reopen it.

**No credential is created, seeded or defaulted anywhere in this module**, nor in the
schema it runs against. A fresh start against an empty database has no account anyone can
sign in to. The argon2id hash is written and read verbatim and is never parsed, compared
or logged here (BR3.6).
"""

from __future__ import annotations

from datetime import datetime, timedelta

from app.auth.store import (
    AttemptScope,
    OwnerRecord,
    SessionRecord,
    window_is_current,
)
from app.sqlite import (
    Connection,
    Row,
    SqliteDatabase,
    instant,
    number,
    optional_instant,
    text,
)


def _optional_iso(value: datetime | None) -> str | None:
    if value is None:
        return None
    return value.isoformat()


class SqliteIdentityStore:
    """`IdentityStore` over one SQLite database file."""

    def __init__(self, database: SqliteDatabase) -> None:
        self._db = database

    async def owner_record_read(self) -> OwnerRecord | None:
        def work(connection: Connection) -> Row | None:
            row: Row | None = connection.execute(
                "SELECT owner_id, email, password_hash, created_at, password_updated_at"
                " FROM owner_record"
            ).fetchone()
            return row

        row = await self._db.run(work)
        if row is None:
            return None
        return OwnerRecord(
            owner_id=text(row["owner_id"]),
            email=text(row["email"]),
            # Returned verbatim to the verifying component and nowhere else. Never
            # parsed, never compared here, never logged.
            password_hash=text(row["password_hash"]),
            created_at=instant(row["created_at"]),
            password_updated_at=optional_instant(row["password_updated_at"]),
        )

    async def owner_record_create_if_absent(self, record: OwnerRecord) -> bool:
        def work(connection: Connection) -> int:
            # One statement. Two conflict targets, both named rather than relying on
            # `INSERT OR IGNORE`: `OR IGNORE` would also swallow a NOT NULL or CHECK
            # violation, and on the one operation that can never be re-run, an insert
            # that silently did nothing for the wrong reason is indistinguishable from a
            # correct refusal. `singleton` is the gate; `owner_id` covers a retry of the
            # same record.
            cursor = connection.execute(
                "INSERT INTO owner_record"
                " (owner_id, email, password_hash, created_at, password_updated_at,"
                "  singleton)"
                " VALUES (?, ?, ?, ?, ?, 1)"
                " ON CONFLICT(owner_id) DO NOTHING"
                " ON CONFLICT(singleton) DO NOTHING",
                (
                    record.owner_id,
                    record.email,
                    record.password_hash,
                    record.created_at.isoformat(),
                    _optional_iso(record.password_updated_at),
                ),
            )
            return cursor.rowcount

        # `rowcount` is 1 when this call inserted the record and 0 when a record already
        # existed. No branch, and no second read that another caller could win.
        return await self._db.run(work) == 1

    async def session_create(self, record: SessionRecord) -> None:
        def work(connection: Connection) -> None:
            connection.execute(
                "INSERT INTO session_record"
                " (session_id, owner_id, issued_at, last_seen_at, absolute_expires_at,"
                "  revoked_at, csrf_token)"
                " VALUES (?, ?, ?, ?, ?, ?, ?)",
                (
                    record.session_id,
                    record.owner_id,
                    record.issued_at.isoformat(),
                    record.last_seen_at.isoformat(),
                    record.absolute_expires_at.isoformat(),
                    _optional_iso(record.revoked_at),
                    record.csrf_token,
                ),
            )

        await self._db.run(work)

    async def session_read(self, session_id: str) -> SessionRecord | None:
        def work(connection: Connection) -> Row | None:
            # No expiry predicate, and none coming. BR22.14: a record past either bound
            # is returned AS STORED, because the consumer owns the two bounds and a
            # filter here would be a second evaluation that can drift from it.
            row: Row | None = connection.execute(
                "SELECT session_id, owner_id, issued_at, last_seen_at,"
                "       absolute_expires_at, revoked_at, csrf_token"
                " FROM session_record WHERE session_id = ?",
                (session_id,),
            ).fetchone()
            return row

        row = await self._db.run(work)
        if row is None:
            return None
        return SessionRecord(
            session_id=text(row["session_id"]),
            owner_id=text(row["owner_id"]),
            issued_at=instant(row["issued_at"]),
            last_seen_at=instant(row["last_seen_at"]),
            absolute_expires_at=instant(row["absolute_expires_at"]),
            revoked_at=optional_instant(row["revoked_at"]),
            csrf_token=text(row["csrf_token"]),
        )

    async def session_touch(self, session_id: str, now: datetime) -> None:
        def work(connection: Connection) -> None:
            # `last_seen_at` ONLY. `absolute_expires_at` is not in the SET list and must
            # never be: refreshing both destroys the absolute bound while every test that
            # checks idle expiry still passes. An UPDATE matching nothing is the no-op
            # this operation specifies for an absent session.
            connection.execute(
                "UPDATE session_record SET last_seen_at = ? WHERE session_id = ?",
                (now.isoformat(), session_id),
            )

        await self._db.run(work)

    async def session_revoke(self, session_id: str, now: datetime) -> None:
        def work(connection: Connection) -> None:
            # Server-side (BR3.17): a stored state change, so a stolen cookie stops
            # working rather than merely disappearing from one browser, and the very next
            # read sees it.
            connection.execute(
                "UPDATE session_record SET revoked_at = ? WHERE session_id = ?",
                (now.isoformat(), session_id),
            )

        await self._db.run(work)

    async def login_attempts_record_failure(
        self,
        scope: AttemptScope,
        window_key: str,
        now: datetime,
        window_length: timedelta,
    ) -> None:
        def work(connection: Connection) -> None:
            row: Row | None = connection.execute(
                "SELECT window_started_at FROM login_attempt_window"
                " WHERE scope = ? AND window_key = ?",
                (scope, window_key),
            ).fetchone()
            if row is None or not window_is_current(
                instant(row["window_started_at"]), now, window_length
            ):
                connection.execute(
                    "INSERT INTO login_attempt_window"
                    " (scope, window_key, failure_count, window_started_at)"
                    " VALUES (?, ?, 1, ?)"
                    " ON CONFLICT(scope, window_key) DO UPDATE SET"
                    "   failure_count = 1,"
                    "   window_started_at = excluded.window_started_at",
                    (scope, window_key, now.isoformat()),
                )
                return
            connection.execute(
                "UPDATE login_attempt_window SET failure_count = failure_count + 1"
                " WHERE scope = ? AND window_key = ?",
                (scope, window_key),
            )

        # A read followed by a write, so it needs the transaction: two failures arriving
        # together must count twice.
        await self._db.transaction(work)

    async def login_attempts_count_in_window(
        self,
        scope: AttemptScope,
        window_key: str,
        now: datetime,
        window_length: timedelta,
    ) -> int:
        def work(connection: Connection) -> Row | None:
            row: Row | None = connection.execute(
                "SELECT failure_count, window_started_at FROM login_attempt_window"
                " WHERE scope = ? AND window_key = ?",
                (scope, window_key),
            ).fetchone()
            return row

        row = await self._db.run(work)
        if row is None:
            return 0
        if not window_is_current(instant(row["window_started_at"]), now, window_length):
            return 0
        # A count, never a verdict: 5 per account and 20 per address are the consumer's
        # numbers, and a store that knew them would enforce a rule it does not own.
        return number(row["failure_count"])

    async def login_attempts_clear(self, scope: AttemptScope, window_key: str) -> None:
        def work(connection: Connection) -> None:
            connection.execute(
                "DELETE FROM login_attempt_window WHERE scope = ? AND window_key = ?",
                (scope, window_key),
            )

        await self._db.run(work)
