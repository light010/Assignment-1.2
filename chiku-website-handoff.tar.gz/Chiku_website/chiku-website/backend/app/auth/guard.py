"""`LoginGuard` -- two independent rolling windows, and the thresholds that live here.

**The numbers live here and nowhere else.** `IdentityStore.login_attempts_count_in_window`
returns a **count, never a verdict**: 5 per account and 20 per source address are this
component's policy, and a store that knew them would be enforcing a rule it does not own
-- which would then have to be kept in step across three adapters.

**Two counters, not one, and neither substitutes for the other** (BR3.18, BR3.19). The
account limit bounds guessing against the one account that matters, however many addresses
it comes from. The address limit bounds a flood from one source, whatever it is aimed at.
A design with only the first is defeated by patience; with only the second, by a botnet.
They are **separate records with separate scopes**, not two counters on one record.

**The account window is keyed on the normalised -- trimmed, lower-cased -- submitted
email, always**, whether or not an account matches. That is forced rather than chosen: the
window is read at step 1 of *Sign in*, **before** the owner lookup, so `owner_id` does not
exist yet. Reordering so the lookup came first was rejected, because it would let the
lookup outcome decide whether and when the counter read happens -- precisely the timing
channel BR23.1 exists to close. Keying on the email is also what preserves a per-account
limit for an account that does not exist.

**`is_exhausted` reads both windows before it decides.** The `or` is over two values that
have already been fetched, not over two calls: short-circuiting the second read would make
the number of storage operations depend on the first counter's state, which is the same
kind of channel in a different place.

**Nothing about these counters is visible to a caller** (BR3.20). No "too many attempts"
sentence, no `Retry-After`, no remaining-attempts count -- with exactly one account in the
system, any of the three tells an attacker that the email they submitted is the owner's,
the single fact the whole enumeration defence exists to withhold. This component therefore
returns a boolean to its own caller and composes nothing.

**Counters are persisted** (BR3.22), so a process restart does not reset a window. An
in-memory counter is not an acceptable real adapter: an attacker who can cause a restart
would otherwise reset the limit at will, and the rate limit becomes decorative.
"""

from __future__ import annotations

from datetime import datetime, timedelta

from app.auth.store import IdentityStore

# D3, FR3.5. The rolling window and both thresholds.
ACCOUNT_FAILURE_LIMIT = 5
ADDRESS_FAILURE_LIMIT = 20
WINDOW_LENGTH = timedelta(minutes=15)


def account_window_key(email: str) -> str:
    """The account-scoped window key: the submitted email, trimmed and lower-cased.

    The same derivation whether or not an account matches, and with no branch on that --
    which is what makes step 1's key derivation identical in both cases.
    """
    return email.strip().lower()


class LoginGuard:
    """Failed-attempt bounding, per account and per source address."""

    def __init__(
        self,
        store: IdentityStore,
        *,
        account_limit: int = ACCOUNT_FAILURE_LIMIT,
        address_limit: int = ADDRESS_FAILURE_LIMIT,
        window_length: timedelta = WINDOW_LENGTH,
    ) -> None:
        self._store = store
        self._account_limit = account_limit
        self._address_limit = address_limit
        self._window_length = window_length

    async def is_exhausted(self, *, account_key: str, source_address: str, now: datetime) -> bool:
        """Whether either window has reached its threshold. **Both are read, always.**"""
        account_failures = await self._store.login_attempts_count_in_window(
            "account", account_key, now, self._window_length
        )
        address_failures = await self._store.login_attempts_count_in_window(
            "ip", source_address, now, self._window_length
        )
        return account_failures >= self._account_limit or address_failures >= self._address_limit

    async def record_failure(self, *, account_key: str, source_address: str, now: datetime) -> None:
        """Record one failure against **both** windows.

        Against both on **any** refusal, including the one the limit itself produced: a
        refusal that did not count would let an attacker sit exactly at the threshold
        indefinitely.
        """
        await self._store.login_attempts_record_failure(
            "account", account_key, now, self._window_length
        )
        await self._store.login_attempts_record_failure(
            "ip", source_address, now, self._window_length
        )

    async def clear_account(self, account_key: str) -> None:
        """Clear **that account's** counter on a successful sign-in (BR3.21).

        The address-scoped counter is deliberately left alone. Clearing it too would let
        one address reset its own flood limit by signing in once, which is the attack
        BR3.19 exists to bound.
        """
        await self._store.login_attempts_clear("account", account_key)
