"""The in-memory `IdentityStore`. A second real implementation, not a mock.

It holds the same shapes with the same nullability and the same identity columns, and it
is under test exactly as the SQLite adapter is.

**It creates no owner record and no credential.** `MemoryIdentityStorage` starts with
`owner` as `None` and nothing in this module ever puts a record there except
`owner_record_create_if_absent` acting on a caller's argument.

BR3.22's durability obligation is on the real adapter: this one is exempt only in the
sense that its whole store is in memory. It must -- and does -- behave identically within
a process lifetime, which is why `MemoryIdentityStorage` is separate from the store and
survives a handle being reopened over it.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from datetime import datetime, timedelta

from app.auth.store import (
    AttemptScope,
    LoginAttemptWindow,
    OwnerRecord,
    SessionRecord,
    window_is_current,
)


@dataclass
class MemoryIdentityStorage:
    """The storage every handle opened over it shares.

    Login-attempt windows are keyed by the **pair** ``(scope, window_key)``, which is the
    identity the table declares: two scopes are separate records, not two counters on one
    record. A mapping keyed by the subject alone would merge the account and address
    counts and still look right in any fixture that used different keys for each.
    """

    owner: OwnerRecord | None = None
    sessions: dict[str, SessionRecord] = field(default_factory=dict)
    windows: dict[tuple[AttemptScope, str], LoginAttemptWindow] = field(default_factory=dict)


class InMemoryIdentityStore:
    """`IdentityStore` over a `MemoryIdentityStorage`."""

    def __init__(self, storage: MemoryIdentityStorage) -> None:
        self._storage = storage

    async def owner_record_read(self) -> OwnerRecord | None:
        return self._storage.owner

    async def owner_record_create_if_absent(self, record: OwnerRecord) -> bool:
        """BR22.13: atomic against a concurrent caller.

        Atomic by construction: the check and the write are one uninterrupted block with
        **no `await` between them**, so a second task cannot be scheduled into the gap.
        Spelling this as an awaited read followed by an awaited write would create
        exactly the gap the rule forbids -- and would still pass a sequential test.
        """
        if self._storage.owner is not None:
            return False
        self._storage.owner = record
        return True

    async def session_create(self, record: SessionRecord) -> None:
        self._storage.sessions[record.session_id] = record

    async def session_read(self, session_id: str) -> SessionRecord | None:
        # As stored. No expiry evaluated, nothing filtered (BR22.14).
        return self._storage.sessions.get(session_id)

    async def session_touch(self, session_id: str, now: datetime) -> None:
        existing = self._storage.sessions.get(session_id)
        if existing is None:
            return
        # `last_seen_at` alone. `absolute_expires_at` is deliberately not in this
        # `replace` call and must never be.
        self._storage.sessions[session_id] = replace(existing, last_seen_at=now)

    async def session_revoke(self, session_id: str, now: datetime) -> None:
        existing = self._storage.sessions.get(session_id)
        if existing is None:
            return
        self._storage.sessions[session_id] = replace(existing, revoked_at=now)

    async def login_attempts_record_failure(
        self,
        scope: AttemptScope,
        window_key: str,
        now: datetime,
        window_length: timedelta,
    ) -> None:
        key = (scope, window_key)
        existing = self._storage.windows.get(key)
        if existing is None or not window_is_current(
            existing.window_started_at, now, window_length
        ):
            self._storage.windows[key] = LoginAttemptWindow(
                scope=scope,
                window_key=window_key,
                failure_count=1,
                window_started_at=now,
            )
            return
        self._storage.windows[key] = replace(existing, failure_count=existing.failure_count + 1)

    async def login_attempts_count_in_window(
        self,
        scope: AttemptScope,
        window_key: str,
        now: datetime,
        window_length: timedelta,
    ) -> int:
        existing = self._storage.windows.get((scope, window_key))
        if existing is None:
            return 0
        if not window_is_current(existing.window_started_at, now, window_length):
            return 0
        return existing.failure_count

    async def login_attempts_clear(self, scope: AttemptScope, window_key: str) -> None:
        self._storage.windows.pop((scope, window_key), None)
