"""The connection, the schema, and the single point where a blocking driver leaves.

**This is the only module in the tree permitted to import `sqlite3`** (BR22.7). Every
driver call it makes runs inside `anyio.to_thread.run_sync`, so no consumer -- and no
adapter built on this -- ever blocks the event loop. Event-loop blocking is invisible to
every check on the merge gate, which is why confinement is a rule rather than something a
gate catches.

**A connection per operation, not one shared connection.** Two reasons, both load-bearing:

* A shared connection would need a lock around every transaction, and that lock -- not
  the storage -- would then be what serialises two concurrent writers. The conformance
  suite's provisioning race would pass against a read-then-write implementation, because
  the lock would have removed the interleaving the test exists to produce. With a
  connection each, two writers genuinely contend in SQLite, and atomicity has to come
  from the statement.
* It keeps the lifecycle trivial: nothing to close, nothing to leak, and a "second,
  independent handle over the same storage" is just another `SqliteDatabase` on the same
  path -- which is what several conformance assertions need.

The cost is one `open`/`close` per operation against a local file, which is small next to
the thread hop that was going to happen anyway.
"""

from __future__ import annotations

import sqlite3
from collections.abc import Callable
from contextlib import closing
from datetime import datetime
from pathlib import Path
from typing import cast

from anyio import to_thread

# The driver's types, re-exported so an adapter can annotate its work functions without
# importing `sqlite3` itself. Confinement is the point: one module knows the driver.
type Connection = sqlite3.Connection
type Row = sqlite3.Row

# Long enough that a writer waiting behind another writer waits rather than failing, and
# short enough that a genuine deadlock surfaces as an error instead of a hang.
LOCK_TIMEOUT_SECONDS = 30.0

SCHEMA = """
CREATE TABLE IF NOT EXISTS content_document (
    -- A fixed key, not a generated identifier: exactly one record ever exists.
    id            TEXT    PRIMARY KEY,
    -- Opaque serialised payloads. Stored and returned byte-identically (BR22.5).
    draft         TEXT    NOT NULL,
    published     TEXT    NOT NULL,
    revision      INTEGER NOT NULL,
    -- NOT NULL on purpose: it is what makes "read_state wrote nothing" observable.
    updated_at    TEXT    NOT NULL,
    published_at  TEXT,
    -- The ABA guard of BR4.13. Omitting this column silently removes a concurrency
    -- defence -- nothing errors and nothing logs; a losing writer records a phantom
    -- revision and prunes history it had no right to prune.
    last_mutation TEXT
);

CREATE TABLE IF NOT EXISTS content_revision (
    -- Two value shapes in one identity column: a write's mutation token for a normal
    -- entry, or one of the two fixed baseline literals. Deliberate, reproduced.
    id         TEXT    PRIMARY KEY,
    -- DELIBERATELY NOT UNIQUE. A baseline pair and a normal entry can share a revision,
    -- and an adapter that added a uniqueness constraint here would reject a legitimate
    -- write.
    revision   INTEGER NOT NULL,
    action     TEXT    NOT NULL,
    content    TEXT    NOT NULL,
    created_at TEXT    NOT NULL,
    -- SQLite has no boolean type, so this is a representation conversion (total,
    -- lossless, reversible), not the semantic coercion BR22.6 forbids.
    baseline   INTEGER NOT NULL DEFAULT 0
);

-- BR5.4 and BR22.9: a declared index is a deliverable, not a runtime detail. The
-- conformance suite asserts the order this index serves, so losing it fails a test
-- rather than silently reordering a list the owner reads.
CREATE INDEX IF NOT EXISTS content_revision_listing
    ON content_revision (revision DESC, baseline ASC, action DESC);

-- The prune selects survivors per action, ordered by revision alone.
CREATE INDEX IF NOT EXISTS content_revision_retention
    ON content_revision (action, baseline, revision DESC);

CREATE TABLE IF NOT EXISTS asset_metadata (
    key         TEXT    PRIMARY KEY,
    filename    TEXT    NOT NULL,
    media_type  TEXT    NOT NULL,
    byte_size   INTEGER NOT NULL,
    width       INTEGER,
    height      INTEGER,
    created_at  TEXT    NOT NULL,
    derived_from TEXT
);

CREATE TABLE IF NOT EXISTS owner_record (
    owner_id            TEXT PRIMARY KEY,
    email               TEXT NOT NULL,
    -- An argon2id PHC string, stored verbatim. Never parsed, compared or logged here.
    password_hash       TEXT NOT NULL,
    created_at          TEXT NOT NULL,
    password_updated_at TEXT,
    -- The singleton constraint, and the mechanism that makes BR22.13 satisfiable: a
    -- second insert violates it, so `INSERT ... ON CONFLICT DO NOTHING` refuses a
    -- concurrent caller in one statement rather than in a read followed by a write.
    -- This constrains the SHAPE (`cardinality: singleton`); it validates no value a
    -- caller supplied, so BR22.6 is untouched.
    singleton           INTEGER NOT NULL DEFAULT 1 UNIQUE CHECK (singleton = 1)
);

CREATE TABLE IF NOT EXISTS session_record (
    session_id          TEXT PRIMARY KEY,
    -- No FOREIGN KEY to owner_record. A referential constraint here would be a rule this
    -- port does not declare, and the in-memory fake -- the second implementation that
    -- proves the suite tests the port -- could not reproduce it, so the two would differ
    -- on exactly the kind of behaviour the suite exists to hold identical.
    owner_id            TEXT NOT NULL,
    issued_at           TEXT NOT NULL,
    last_seen_at        TEXT NOT NULL,
    absolute_expires_at TEXT NOT NULL,
    revoked_at          TEXT,
    csrf_token          TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS login_attempt_window (
    -- Identity is the pair. The two scopes are separate records, not two counters on
    -- one record.
    scope             TEXT    NOT NULL,
    window_key        TEXT    NOT NULL,
    failure_count     INTEGER NOT NULL DEFAULT 0,
    window_started_at TEXT    NOT NULL,
    PRIMARY KEY (scope, window_key)
);
"""


# --- column readers ---------------------------------------------------------------- #
#
# These are REPRESENTATION conversions, which BR22.6 explicitly permits: total, lossless,
# reversible, and invisible to the caller, who both writes and reads the port's type.
# `flag` is the one the rule names -- SQLite has no boolean type, so a revision entry's
# `baseline` is stored as an integer and returned as a boolean.
#
# None of them is a SEMANTIC coercion. Nothing here parses a string into a number,
# truncates to a maximum, substitutes a default for a null, or normalises a shape: the
# round trip is the identity function for every value the port's type admits. `text` and
# `number` narrow a value the driver hands back as `Any` to the type its column declares;
# they change no value.


def text(value: object) -> str:
    return cast(str, value)


def optional_text(value: object) -> str | None:
    if value is None:
        return None
    return cast(str, value)


def number(value: object) -> int:
    return cast(int, value)


def optional_number(value: object) -> int | None:
    if value is None:
        return None
    return cast(int, value)


def flag(value: object) -> bool:
    return bool(cast(int, value))


def instant(value: object) -> datetime:
    """Parse an instant back out of its ISO-8601 column.

    `datetime.isoformat` and `datetime.fromisoformat` are exact inverses for an aware
    datetime, offset included, so the round trip is the identity. The value is stored
    exactly as the consumer supplied it rather than normalised to UTC first: normalising
    would change the value on the way through, which is the thing this port is not
    allowed to do.
    """
    return datetime.fromisoformat(cast(str, value))


def optional_instant(value: object) -> datetime | None:
    if value is None:
        return None
    return datetime.fromisoformat(cast(str, value))


def _apply_schema(connection: sqlite3.Connection) -> None:
    # WAL is a property of the database file, set once. It lets a reader proceed while a
    # writer holds the write lock, which is what keeps the conformance suite's concurrent
    # cases contending on the write rather than on everything.
    connection.execute("PRAGMA journal_mode = WAL")
    connection.executescript(SCHEMA)


class SqliteDatabase:
    """A database file, and the two ways an adapter is allowed to reach it."""

    def __init__(self, path: Path) -> None:
        self._path = path

    async def initialize(self) -> None:
        """Create the schema if it is not there. Safe to run against an existing file.

        It seeds nothing. In particular it creates no owner record and no SQL that could:
        a fresh start against an empty file has no account anyone can sign in to.
        """
        await self.run(_apply_schema)

    async def run[T](self, work: Callable[[sqlite3.Connection], T]) -> T:
        """Run ``work`` against a connection, off the event loop, with no explicit transaction.

        For reads and for schema application. Each statement runs in SQLite's own
        implicit transaction.
        """
        return await to_thread.run_sync(self._run, work)

    async def transaction[T](self, work: Callable[[sqlite3.Connection], T]) -> T:
        """Run ``work`` inside one ``BEGIN IMMEDIATE`` transaction, off the event loop.

        Every effect commits together or none does. ``IMMEDIATE`` rather than the default
        deferred mode because these transactions read *and then* write: a deferred
        transaction takes its write lock late, which turns a lost race into
        ``SQLITE_BUSY`` mid-transaction instead of a clean wait at the start.

        ``work`` raising is the way to abort: the connection's context manager rolls the
        whole transaction back and re-raises.
        """
        return await to_thread.run_sync(self._transaction, work)

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self._path, isolation_level=None, timeout=LOCK_TIMEOUT_SECONDS)
        # Rows are read BY NAME, never by position (BR4.17). A positional read that
        # drifts produces spurious "this draft changed in another tab" errors rather
        # than a crash, so the row factory is part of the correctness argument.
        connection.row_factory = sqlite3.Row
        return connection

    def _run[T](self, work: Callable[[sqlite3.Connection], T]) -> T:
        with closing(self._connect()) as connection:
            return work(connection)

    def _transaction[T](self, work: Callable[[sqlite3.Connection], T]) -> T:
        with closing(self._connect()) as connection:
            connection.execute("BEGIN IMMEDIATE")
            with connection:
                return work(connection)
