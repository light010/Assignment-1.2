"""The `AssetStore` on Cloud Storage.

**UNVERIFIED AGAINST THE REAL SERVICE.** No code in this module has ever executed against
Cloud Storage. It passes the shared conformance suite against an in-process fake, which
proves it satisfies the port's contract as that suite expresses it and proves nothing about
the service; every statement here about Cloud Storage behaviour comes from published
documentation (BR31.5).

**The ranged read is the reason this port has a `get_range` at all** (BR22.11, BR7.17). An
adapter that downloaded the whole object and returned a slice would satisfy the signature,
return byte-identical bytes, and pass every functional assertion in the suite -- while
making a 50 MB video cost 50 MB of transfer for every seek. On a **metered** object store
the failure mode is cost and latency, not incorrectness, so no correctness test catches it;
`download_as_bytes(start, end)` is what makes the difference real.

**The entity tag is a content hash stored as object metadata at upload**, never Cloud
Storage's own ``etag``. The service's tag is tied to the object's generation and moves when
the same bytes are written again -- a container rebuild, a bucket restore -- and the serving
path compares ``If-Range`` by exact string equality, so a tag that moves for unchanged bytes
silently suppresses every ranged read and re-sends whole videos. `compute_etag` is the same
function the volume adapter uses, which is what keeps the two comparable.

**The published Cloud Storage client is synchronous** -- there is no async one -- so every
call runs inside ``anyio.to_thread.run_sync``. A blocking driver never leaves an adapter
(BR22.7), and event-loop blocking is invisible to every check on the merge gate, which is
why confinement is a rule rather than something a gate catches.
"""

from __future__ import annotations

from functools import partial
from typing import cast

from anyio import to_thread

from app.assets.store import (
    ObjectHead,
    ObjectNotFound,
    RangeNotAvailable,
    compute_etag,
)
from app.cloud.clients import NOT_FOUND_STATUS, BlobLike, BucketLike, document_id_for, tolerate

# The custom-metadata key carrying the content-derived entity tag.
ENTITY_TAG_METADATA_KEY = "etag"


def _put(blob: BlobLike, data: bytes, media_type: str) -> None:
    # Assigned BEFORE the upload, because custom metadata travels with the upload request
    # rather than as a second round trip that could fail on its own and leave an object
    # with no entity tag.
    blob.metadata = {ENTITY_TAG_METADATA_KEY: compute_etag(data)}
    # Stored unchanged: no transcoding, no re-encoding, no normalisation, no inspection.
    blob.upload_from_string(data, media_type)


def _head(blob: BlobLike) -> ObjectHead | None:
    if not blob.exists():
        return None
    blob.reload()
    metadata = cast("dict[str, str]", blob.metadata)
    return ObjectHead(
        # `reload` populates both; the Protocol has to declare them optional because a
        # blob handle before `reload` is a name and nothing else.
        size=cast("int", blob.size),
        # A KeyError rather than a fallback. An object this adapter did not write carries
        # no content-derived tag, and there is no safe substitute: a tag derived from
        # anything but the bytes is unstable, and an unstable tag fails silently.
        etag=metadata[ENTITY_TAG_METADATA_KEY],
        media_type=cast("str", blob.content_type),
    )


def _get(blob: BlobLike) -> bytes | None:
    if not blob.exists():
        return None
    return blob.download_as_bytes()


def _delete(blob: BlobLike) -> None:
    # Idempotent (BR22.10): the best-effort cleanup path of a failed or cancelled upload
    # cannot know how far the write got, so a delete that raised on an absent key would
    # turn cleanup into a second failure masking the first (BR6.24). `tolerate` swallows
    # exactly the not-found error and re-raises everything else, so a permissions failure
    # or an outage still reaches the consumer.
    tolerate(NOT_FOUND_STATUS, blob.delete, fallback=None)


class GcsAssetStore:
    """`AssetStore` over one Cloud Storage bucket."""

    def __init__(self, bucket: BucketLike) -> None:
        self._bucket = bucket

    def _blob(self, key: str) -> BlobLike:
        # The port validates nothing (BR22.6), so it cannot reject a key carrying a
        # newline or a path -- and an object name must not contain one either. The same
        # total, lossless, reversible encoding the Firestore adapter uses for document
        # names makes an illegal name structurally impossible rather than checked.
        return self._bucket.blob(document_id_for(key))

    async def put(self, key: str, data: bytes, media_type: str) -> None:
        await to_thread.run_sync(partial(_put, self._blob(key), data, media_type))

    async def get(self, key: str) -> bytes | None:
        return await to_thread.run_sync(partial(_get, self._blob(key)))

    async def get_range(self, key: str, offset: int, length: int) -> bytes:
        """Exactly ``length`` bytes from ``offset``, transferred as a window.

        The bounds are checked against `head` rather than inferred from what the service
        returns for an out-of-range request, because the service's behaviour there is a
        documented claim this unit has never tested -- and the port's obligation is exact:
        a window that is not fully present is **reported**, never served short. Short bytes
        surface far away, as a truncated video, with nothing in the logs.

        The adapter clamps nothing, re-interprets nothing and validates nothing else: every
        range branch -- the multi-range rejection, the zero-byte object, the oversized
        suffix, the start/end asymmetry -- is decided above this port by U5.
        """
        head = await self.head(key)
        if head is None:
            raise ObjectNotFound(key)
        if offset < 0 or length < 0 or offset + length > head.size:
            raise RangeNotAvailable(f"{key}: bytes {offset}-{offset + length - 1} of {head.size}")
        blob = self._blob(key)
        # `start` and `end` are an INCLUSIVE range in the published client, and this is the
        # one place in the codebase that converts to it.
        return await to_thread.run_sync(
            partial(blob.download_as_bytes, offset, offset + length - 1)
        )

    async def head(self, key: str) -> ObjectHead | None:
        return await to_thread.run_sync(partial(_head, self._blob(key)))

    async def delete(self, key: str) -> None:
        await to_thread.run_sync(partial(_delete, self._blob(key)))
