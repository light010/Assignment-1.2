"""The `ContentStore` on Firestore. **Hazard module: the combined write.**

**UNVERIFIED AGAINST THE REAL SERVICE.** No code in this module has ever executed against
Firestore or Cloud Storage. It passes the shared conformance suite against an in-process
fake, which proves it satisfies the port's contract **as that suite expresses it** -- and
proves nothing about the service. Every statement below about Firestore behaviour comes
from published documentation (BR31.5). Code that passes a conformance suite looks exactly
like code that works, which is why this paragraph is here and not only in a README.

**Two Critical review findings shaped this file, and both are still live risks if anyone
edits it.**

*R-01 -- substitution is per stored field.* An earlier algorithm substituted the content
document and wrote the revision entry inline. `contract-summary.md` C2 ``payload_size``
says it outright: a revision entry stores the **full** content, so it is the shape that
cannot fit. The fix is in `app.cloud.blobs`; what this file must not do is stop applying
it to `ContentRevision.content`.

*R-05 -- every read precedes every write.* A Firestore transaction is a sequence of reads
followed by a sequence of writes, and it **rejects a read issued after a write**. The
pre-fix order read the retention prune's survivors after two writes, and by this design's
own pruning invariant the prune fires on **every** combined write once the retention cap
is reached -- so that transaction would have failed at runtime on essentially every save,
not on a rare path. The order below is therefore load-bearing and literal:

    read-content, read-survivors, write-content, write-revision, delete-pruned, commit

with the blob writes **complete before the transaction opens** (BR31.2). Those two
orderings are independent of each other: step 2's position is a corruption argument --
orphan garbage beats a dangling reference -- and the read/write split is an API-legality
one. `tests/cloud/fake_firestore.py` enforces both, so undoing either fails the build
rather than the deployment.

**What breaks silently here.** Nothing errors and nothing logs when the prune is wrong:
the history list grows an entry the owner never saved, or loses one it should have kept.
It is invisible to single-user testing and invisible to a coverage percentage, which is
why this module carries a 100% branch-coverage floor alongside the two SQLite hazard
modules and why every guard below is spelled out rather than inferred.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from datetime import datetime
from typing import Any, cast

from app.cloud.blobs import (
    LARGE_PAYLOAD_THRESHOLD_BYTES,
    blob_key_for,
    carried_fields,
    plan_substitution,
    resolve_payload,
    substituted_fields,
    write_payload,
)
from app.cloud.clients import (
    ASCENDING,
    DESCENDING,
    FIRESTORE_DOCUMENT_LIMIT_BYTES,
    BucketLike,
    DocumentData,
    DocumentReferenceLike,
    FirestoreLike,
    QueryLike,
    TransactionLike,
    document_fields,
    document_id_for,
    flag,
    instant,
    number,
    optional_instant,
    optional_number,
    optional_text,
    text,
)
from app.content.store import (
    BASELINE_DRAFT_ID,
    BASELINE_PUBLISHED_ID,
    CONFLICT,
    CONTENT_DOCUMENT_ID,
    Action,
    AssetMetadataRecord,
    CommitResult,
    ContentState,
    RetentionPolicy,
    RevisionEntry,
    RevisionSummary,
)

# --- the storage mapping, as `entities.md` declares it ------------------------------- #

CONTENT_COLLECTION = "content"
REVISIONS_COLLECTION = "revisions"
ASSETS_COLLECTION = "assets"

DRAFT_FIELD = "draft"
PUBLISHED_FIELD = "published"
CONTENT_FIELD = "content"
ID_FIELD = "id"
REVISION_FIELD = "revision"
ACTION_FIELD = "action"
CREATED_AT_FIELD = "created_at"
UPDATED_AT_FIELD = "updated_at"
PUBLISHED_AT_FIELD = "published_at"
BASELINE_FIELD = "baseline"
LAST_MUTATION_FIELD = "last_mutation"

# The fixed field order that breaks a substitution tie (BR31.2). `draft` first.
SUBSTITUTION_ORDER: tuple[str, ...] = (DRAFT_FIELD, PUBLISHED_FIELD)

# The ONE declared composite index this unit requires, serving the three-part listing
# order. Its definition travels with the deployment artifacts -- see `app/cloud/INDEXES.md`
# -- because without it the listing query fails at runtime (BR31.4).
REVISION_LISTING_INDEX: tuple[tuple[str, str], ...] = (
    (REVISION_FIELD, DESCENDING),
    (BASELINE_FIELD, ASCENDING),
    (ACTION_FIELD, DESCENDING),
)

# The two permanent baselines of BR4.9, and the field each captures. Fixed identities plus
# capture-if-absent are what make each succeed AT MOST ONCE in the document's lifetime.
BASELINE_CAPTURES: tuple[tuple[str, Action, str], ...] = (
    (BASELINE_PUBLISHED_ID, "publish", PUBLISHED_FIELD),
    (BASELINE_DRAFT_ID, "draft", DRAFT_FIELD),
)


class _StaleWrite(Exception):
    """Internal control flow: abort the transaction so a stale write leaves nothing.

    Raising is what makes "a conflicting commit performs no side effect" true **by
    construction** rather than by argument about which guards happened to match. It never
    escapes this module: `FirestoreContentStore.commit` turns it into the port's conflict
    signal, which is a return value, because losing an optimistic race is an ordinary
    outcome rather than a failure.
    """


@dataclass(frozen=True, slots=True)
class CombinedWrite:
    """Everything the transaction needs, decided **before** it opens.

    Deciding it up front is not an optimisation. The blob writes have to complete before
    the transaction exists (BR31.2), and a blob write cannot be planned without knowing
    which fields are oversized -- so the substitution decision, and therefore the whole
    stored field map, is settled outside the transaction and simply written inside it.
    """

    content: str
    content_fields: dict[str, Any]
    revision_fields: dict[str, Any]
    substituted: tuple[str, ...]
    base_revision: int
    action: Action
    mutation_token: str
    retention: RetentionPolicy
    now: datetime


def select_pruned(
    entries: Sequence[DocumentData],
    *,
    retention: RetentionPolicy,
    new_action: Action,
) -> list[str]:
    """The existing entries that fall outside the retention cap once the new entry lands.

    ``entries`` arrives already ordered ``revision`` DESC, from **one unfiltered read of
    the whole bounded set**, and is partitioned by action **here, in memory**. The filtered
    alternative -- equality on ``action`` plus ``orderBy revision DESC``, one query per
    action -- returns the same survivors and would require a composite index on
    ``(action, revision DESC)`` that nothing declares; an undeclared composite index fails
    at runtime, which is the exact failure BR31.4 exists to prevent.

    Three things are load-bearing and each has broken a port before:

    * **Per action**, two independent selections -- never one combined cap of
      ``draft_keep + publish_keep``, under which a run of drafts evicts publishes (BR5.7).
    * **Baselines are excluded by the predicate**, not by sorting high. They carry the
      *lowest* revision in the store, so ordering is what would reach them first -- and the
      capture is once-ever, so a pruned baseline cannot be recreated (BR5.8).
    * **Read the survivors, then delete the rest.** Never a predicate over the set to
      remove: Firestore has no ``DELETE ... WHERE id NOT IN (subquery)``, and a SQL-shaped
      prune would be satisfiable by exactly one adapter (BR31.3, C2 ``prune_shape``).

    **Why the new entry is not read.** It ranks first for its own action under ``revision
    DESC`` -- its number is ``base_revision + 1``, necessarily the highest -- so it is
    always a survivor and never decides which *existing* entry falls outside the cap. Its
    action is a caller argument. The survivor set therefore needs no fact that exists only
    once the entry is persisted, which is precisely why R-05's fix was pure resequencing
    and changed no prune logic. It occupies one slot of its own action's allowance.

    The ordering is ``revision`` DESC **alone** and is deliberately not tiebreak-stable
    (BR4.19). That indeterminacy is inherited from the source, and adding a tie-break to
    make this adapter's results deterministic would change which entries survive.
    """
    policy: tuple[tuple[Action, int], ...] = (
        ("draft", retention.draft_keep),
        ("publish", retention.publish_keep),
    )
    doomed: list[str] = []
    for pruned_action, keep in policy:
        candidates = [
            entry
            for entry in entries
            if entry[ACTION_FIELD] == pruned_action and not flag(entry[BASELINE_FIELD])
        ]
        allowance = keep - 1 if pruned_action == new_action else keep
        doomed.extend(text(entry[ID_FIELD]) for entry in candidates[max(allowance, 0) :])
    return doomed


def _summary_from(data: DocumentData) -> RevisionSummary:
    return RevisionSummary(
        id=text(data[ID_FIELD]),
        # A cast, not a coercion: the field holds what the caller wrote, and re-deriving
        # or re-checking it here is exactly the validation BR22.6 forbids a store to do.
        revision=number(data[REVISION_FIELD]),
        action=cast("Action", text(data[ACTION_FIELD])),
        created_at=instant(data[CREATED_AT_FIELD]),
        baseline=flag(data[BASELINE_FIELD]),
    )


class FirestoreContentStore:
    """`ContentStore` over one Firestore database and one Cloud Storage bucket.

    ``seed`` and ``listing_cap`` are supplied by the consumer: the store returns the seed
    when no document exists and bootstraps with it, but *what the seed contains* and *what
    the cap is* are U4's, and a store holding its own copy of either could disagree with
    its owner (BR5.9).
    """

    def __init__(
        self,
        client: FirestoreLike,
        bucket: BucketLike,
        *,
        seed: str,
        listing_cap: int,
    ) -> None:
        self._client = client
        self._bucket = bucket
        self._seed = seed
        self._listing_cap = listing_cap

    # --- references ------------------------------------------------------------------ #

    def _content_reference(self) -> DocumentReferenceLike:
        # The id is a fixed constant this package chose, so it is used verbatim; only a
        # value that arrives from a caller is encoded (see `document_id_for`).
        return self._client.collection(CONTENT_COLLECTION).document(CONTENT_DOCUMENT_ID)

    def _revision_reference(self, revision_id: str) -> DocumentReferenceLike:
        return self._client.collection(REVISIONS_COLLECTION).document(document_id_for(revision_id))

    def _asset_reference(self, key: str) -> DocumentReferenceLike:
        return self._client.collection(ASSETS_COLLECTION).document(document_id_for(key))

    def _revisions_by_revision_descending(self) -> QueryLike:
        """The survivor read's query: **one ordering clause, no filter, no limit**.

        A single-field ordering is served by Firestore's automatic single-field indexes,
        and the declared listing index covers it as a prefix in any case -- so this query
        needs no index of its own, which is the whole reason it is shaped this way.
        """
        return self._client.collection(REVISIONS_COLLECTION).order_by(REVISION_FIELD, DESCENDING)

    def _seeded_document(self, now: datetime) -> dict[str, Any]:
        """The bootstrap document (BR4.8), **as a value rather than as a write**.

        In SQLite, effect 0 is an ``INSERT ... ON CONFLICT DO NOTHING`` at revision 0 that
        the compare-and-set then updates. Here there is one write per document, so the
        seeded document exists only as the *base* the compare-and-set runs against -- and
        that is what keeps BR4.8's two guards intact. ``base_revision = 0`` is enforced
        because this base carries revision 0 and the guard below is an equality: a client
        at revision 5 finds ``0 != 5`` and cannot resurrect a deleted document. The seed
        goes into **both** payload fields with ``published_at`` null -- the seeded document
        is not "published".
        """
        return {
            DRAFT_FIELD: self._seed,
            PUBLISHED_FIELD: self._seed,
            REVISION_FIELD: 0,
            UPDATED_AT_FIELD: now.isoformat(),
            PUBLISHED_AT_FIELD: None,
            LAST_MUTATION_FIELD: None,
        }

    # --- reads ----------------------------------------------------------------------- #

    async def read_state(self) -> ContentState:
        snapshot = await self._content_reference().get()
        data = snapshot.to_dict()
        if data is None:
            # BR4.1: synthesise, and WRITE NOTHING. No bootstrap, no lazily created
            # document, no lock. `updated_at` is null here, and that null is the one
            # port-level observable that distinguishes a store which wrote nothing from
            # one that created the record on read and had to invent an instant.
            return ContentState(
                draft=self._seed,
                published=self._seed,
                revision=0,
                updated_at=None,
                published_at=None,
            )
        return ContentState(
            draft=await resolve_payload(self._bucket, data, DRAFT_FIELD),
            published=await resolve_payload(self._bucket, data, PUBLISHED_FIELD),
            revision=number(data[REVISION_FIELD]),
            updated_at=instant(data[UPDATED_AT_FIELD]),
            published_at=optional_instant(data[PUBLISHED_AT_FIELD]),
        )

    async def list_revisions(self) -> list[RevisionSummary]:
        """Summaries ordered ``revision`` DESC, then ``baseline`` ASC, then ``action`` DESC.

        **This is the one query in the unit that needs a declared composite index**
        (BR31.4). Without it Firestore fails the query at runtime rather than returning a
        differently ordered list -- the better failure, but only if the definition travels
        with the deployment artifacts.

        Not a paginated operation (BR22.2): the cap is small and fixed, and a cursor over
        an order with ties can repeat or skip an entry at a page boundary.
        """
        query: QueryLike = self._client.collection(REVISIONS_COLLECTION)
        for field_path, direction in REVISION_LISTING_INDEX:
            query = query.order_by(field_path, direction)
        return [
            _summary_from(document_fields(snapshot))
            async for snapshot in query.limit(self._listing_cap).stream()
        ]

    async def read_revision(self, revision_id: str) -> RevisionEntry | None:
        snapshot = await self._revision_reference(revision_id).get()
        data = snapshot.to_dict()
        if data is None:
            # A well-formed id that names nothing and an entry that was pruned both
            # return absence. The id is taken as given: no pattern is validated and no
            # length enforced (BR5.5 is the consumer's).
            return None
        return RevisionEntry(
            id=text(data[ID_FIELD]),
            revision=number(data[REVISION_FIELD]),
            action=cast("Action", text(data[ACTION_FIELD])),
            content=await resolve_payload(self._bucket, data, CONTENT_FIELD),
            created_at=instant(data[CREATED_AT_FIELD]),
            baseline=flag(data[BASELINE_FIELD]),
        )

    # --- the combined write ----------------------------------------------------------- #

    async def commit(
        self,
        *,
        content: str,
        base_revision: int,
        action: Action,
        mutation_token: str,
        retention: RetentionPolicy,
        now: datetime,
    ) -> CommitResult:
        """One call, one transaction, six effects -- with the blob writes ahead of all of it.

        **The atomicity guarantee is weaker here than on the verified SQLite path, and that
        is stated rather than hidden** (C2 ``payload_size``): it is "the transaction is
        atomic, and the blob write precedes it and is idempotent" rather than "everything
        commits in one transaction". The weakening buys the ability to store a payload the
        port must accept and one Firestore document cannot hold.
        """
        write = await self._prepare(
            content=content,
            base_revision=base_revision,
            action=action,
            mutation_token=mutation_token,
            retention=retention,
            now=now,
        )
        try:
            async with self._client.transaction() as transaction:
                await self._run_combined_write(transaction, write)
        except _StaleWrite:
            # The transaction rolled back, so no effect survives: no revision entry, no
            # prune, no timestamp movement. A blob written before it may survive, which is
            # the reclaimable orphan BR31.2 chooses over a dangling reference.
            return CONFLICT
        return await self._state_after(write)

    async def _prepare(
        self,
        *,
        content: str,
        base_revision: int,
        action: Action,
        mutation_token: str,
        retention: RetentionPolicy,
        now: datetime,
    ) -> CombinedWrite:
        """Steps 1 and 2: serialise, decide the substitutions, and land every blob.

        **This issues one read outside the transaction, and it has to.** The spec's step 1
        says *serialise the content document*, and on a draft write the document's
        ``published`` field is the **existing** value -- which only a read supplies. The
        read is safe precisely because the compare-and-set inside the transaction is what
        certifies it: if the document moves in between, its revision moves too, the write
        is refused, and nothing survives but an orphan blob. Its cost is one extra document
        read per save.
        """
        snapshot = await self._content_reference().get()
        existing = snapshot.to_dict()
        previous = existing if existing is not None else self._seeded_document(now)
        publishing = action == "publish"

        # The three fields that can carry a full content document, split into those whose
        # text this write has in hand -- the substitution candidates -- and those carried
        # forward verbatim from storage. `draft` moves on EVERY accepted write, publishes
        # included; `published` moves only on a publish (BR4.10).
        candidates: dict[str, str] = {DRAFT_FIELD: content}
        carried: dict[str, Any] = {}
        if publishing:
            candidates[PUBLISHED_FIELD] = content
        else:
            unchanged = carried_fields(previous, PUBLISHED_FIELD, PUBLISHED_FIELD)
            if PUBLISHED_FIELD in unchanged:
                candidates[PUBLISHED_FIELD] = text(unchanged[PUBLISHED_FIELD])
            else:
                # Already substituted: carried by KEY, so a draft save never downloads,
                # rehashes and re-uploads a payload it did not touch.
                carried.update(unchanged)

        content_other: dict[str, Any] = {
            REVISION_FIELD: base_revision + 1,
            UPDATED_AT_FIELD: now.isoformat(),
            PUBLISHED_AT_FIELD: now.isoformat() if publishing else previous[PUBLISHED_AT_FIELD],
            # The ABA guard of BR4.13, stamped even though this adapter's single read
            # already establishes the precondition the SQLite adapter re-tests per
            # statement. BR4.14: dropping it because "the transaction already serialises
            # the writes" is the argument the rule exists to refuse.
            LAST_MUTATION_FIELD: mutation_token,
            **carried,
        }
        content_chosen = plan_substitution(
            candidates,
            order=tuple(name for name in SUBSTITUTION_ORDER if name in candidates),
            other_fields=content_other,
            threshold=LARGE_PAYLOAD_THRESHOLD_BYTES,
            limit=FIRESTORE_DOCUMENT_LIMIT_BYTES,
        )

        # The revision entry, checked INDEPENDENTLY -- this is the R-01 correction, and the
        # entry is the shape the size conflict is really about. Its id IS the mutation
        # token, and its content is what this write stores as the draft: this adapter
        # stores the caller's value unchanged, so the stored draft and `content` are the
        # same string, which is what BR4.11's read-back exists to guarantee.
        revision_candidates = {CONTENT_FIELD: content}
        revision_other: dict[str, Any] = {
            ID_FIELD: mutation_token,
            REVISION_FIELD: base_revision + 1,
            ACTION_FIELD: action,
            CREATED_AT_FIELD: now.isoformat(),
            BASELINE_FIELD: False,
        }
        revision_chosen = plan_substitution(
            revision_candidates,
            order=(CONTENT_FIELD,),
            other_fields=revision_other,
            threshold=LARGE_PAYLOAD_THRESHOLD_BYTES,
            limit=FIRESTORE_DOCUMENT_LIMIT_BYTES,
        )

        # BR31.2: every blob lands BEFORE the transaction opens, and each is awaited.
        await self._write_payloads(
            [candidates[name] for name in content_chosen]
            + [revision_candidates[name] for name in revision_chosen]
        )

        return CombinedWrite(
            content=content,
            content_fields={**content_other, **substituted_fields(candidates, content_chosen)},
            revision_fields={
                **revision_other,
                **substituted_fields(revision_candidates, revision_chosen),
            },
            substituted=content_chosen + revision_chosen,
            base_revision=base_revision,
            action=action,
            mutation_token=mutation_token,
            retention=retention,
            now=now,
        )

    async def _write_payloads(self, payloads: Sequence[str]) -> None:
        """Land every substituted payload, de-duplicated by key.

        A draft save of an oversized payload substitutes the same text twice -- once as the
        document's ``draft`` and once as the revision entry's ``content`` -- and
        content-addressing makes those the same object, so writing it once is not a
        shortcut but the same result for half the transfer.
        """
        written: set[str] = set()
        for payload in payloads:
            key = blob_key_for(payload)
            if key not in written:
                written.add(key)
                await write_payload(self._bucket, payload)

    async def _run_combined_write(self, transaction: TransactionLike, write: CombinedWrite) -> None:
        """Steps 3 to 9. **The order of these calls is the R-05 fix and is not stylistic.**

        Read phase, then write phase, and nothing crosses back.
        """
        # --- READ PHASE: every read the transaction needs, before its first write ------ #
        #
        # Step 4: the content document, and the compare-and-set guard. A mismatch aborts
        # HERE -- no write has been issued, so the abort costs nothing and nothing has to
        # be undone. This read is also where every fact the write phase needs is obtained:
        # the pre-write payloads the baselines capture, and which baselines already exist.
        existing = await self._read_content(transaction)
        previous = existing if existing is not None else self._seeded_document(write.now)
        if number(previous[REVISION_FIELD]) != write.base_revision:
            raise _StaleWrite

        # Step 5: ONE unfiltered `revision DESC` read of the bounded set, with the survivor
        # set computed NOW, before anything is written. See `select_pruned` for why that is
        # possible and why the read is not filtered.
        entries = await self._read_revisions(transaction)
        doomed = select_pruned(entries, retention=write.retention, new_action=write.action)
        captured = {text(entry[ID_FIELD]) for entry in entries}

        # --- WRITE PHASE: after this point no read is issued --------------------------- #
        #
        # Effects 1 and 2 -- the two permanent baselines, once ever, under fixed
        # identities, capturing the state BEFORE this write. `created_at` is the time of
        # CAPTURE, never a guessed original publication date (BR4.9). Capture-if-absent is
        # decided from the read phase's own result, so it costs no second lookup; an
        # oversized payload is carried by key, so it costs no blob write either.
        for baseline_id, baseline_action, source in BASELINE_CAPTURES:
            if baseline_id not in captured:
                self._write_revision(
                    transaction,
                    baseline_id,
                    {
                        ID_FIELD: baseline_id,
                        REVISION_FIELD: number(previous[REVISION_FIELD]),
                        ACTION_FIELD: baseline_action,
                        CREATED_AT_FIELD: write.now.isoformat(),
                        BASELINE_FIELD: True,
                        **carried_fields(previous, source, CONTENT_FIELD),
                    },
                )

        # Step 6 -- the content update (effects 0 and 3), each oversized field carried as a
        # blob key and the rest inline.
        self._write_content(transaction, write.content_fields)
        # Step 7 -- the revision entry, its content inline or as a key by the same rule.
        self._write_revision(transaction, write.mutation_token, write.revision_fields)
        # Step 8 -- delete the entries that fell outside the survivor set computed at
        # step 5. Step 9, the commit, is the context manager's clean exit.
        self._delete_revisions(transaction, doomed)

    # --- the transaction's individual operations, named so the phases are readable ----- #

    async def _read_content(self, transaction: TransactionLike) -> dict[str, Any] | None:
        """The content document, or ``None``. A read; it belongs in the read phase."""
        # A document read yields exactly one snapshot, whose `exists` may be false -- so
        # there is one element and `to_dict()` is what reports absence.
        snapshots = [snapshot async for snapshot in transaction.get(self._content_reference())]
        return snapshots[0].to_dict()

    async def _read_revisions(self, transaction: TransactionLike) -> list[dict[str, Any]]:
        """The whole bounded revision set, ordered ``revision`` DESC. A read."""
        return [
            document_fields(snapshot)
            async for snapshot in transaction.get(self._revisions_by_revision_descending())
        ]

    def _write_content(self, transaction: TransactionLike, fields: DocumentData) -> None:
        """A write. Nothing may be read after this."""
        transaction.set(self._content_reference(), fields)

    def _write_revision(
        self, transaction: TransactionLike, revision_id: str, fields: DocumentData
    ) -> None:
        """A write. Nothing may be read after this."""
        transaction.set(self._revision_reference(revision_id), fields)

    def _delete_revisions(self, transaction: TransactionLike, revision_ids: Sequence[str]) -> None:
        """Writes. The delete **names the doomed ids**; it carries no predicate (BR31.3)."""
        for revision_id in revision_ids:
            transaction.delete(self._revision_reference(revision_id))

    async def _state_after(self, write: CombinedWrite) -> ContentState:
        """The new state, assembled **outside** the transaction window.

        ``published`` is resolved rather than remembered, because on a draft write it may
        be a payload this write never held. That costs one object read per draft save whose
        published document is oversized, and it is unavoidable: the port returns the
        document's text, not its storage representation.
        """
        return ContentState(
            draft=write.content,
            published=await resolve_payload(self._bucket, write.content_fields, PUBLISHED_FIELD),
            revision=number(write.content_fields[REVISION_FIELD]),
            updated_at=instant(write.content_fields[UPDATED_AT_FIELD]),
            published_at=optional_instant(write.content_fields[PUBLISHED_AT_FIELD]),
        )

    # --- asset metadata: row-shaped, so it lives here and not in `AssetStore` ---------- #

    async def asset_metadata_register(self, record: AssetMetadataRecord) -> None:
        # Stored exactly as given: no media type validated, no extension derived, no
        # filename inspected. `set` replaces, so registering the same key twice stores the
        # record as given -- which is what the operation is specified to do and what every
        # other implementation of this port does.
        await self._asset_reference(record.key).set(
            {
                "key": record.key,
                "filename": record.filename,
                "media_type": record.media_type,
                "byte_size": record.byte_size,
                "width": record.width,
                "height": record.height,
                CREATED_AT_FIELD: record.created_at.isoformat(),
                "derived_from": record.derived_from,
            }
        )

    async def asset_metadata_read(self, key: str) -> AssetMetadataRecord | None:
        snapshot = await self._asset_reference(key).get()
        data = snapshot.to_dict()
        if data is None:
            return None
        return AssetMetadataRecord(
            key=text(data["key"]),
            filename=text(data["filename"]),
            media_type=text(data["media_type"]),
            byte_size=number(data["byte_size"]),
            width=optional_number(data["width"]),
            height=optional_number(data["height"]),
            created_at=instant(data[CREATED_AT_FIELD]),
            derived_from=optional_text(data["derived_from"]),
        )

    async def asset_metadata_remove(self, key: str) -> None:
        # Idempotent without a branch: deleting an absent document succeeds, which is what
        # the best-effort cleanup path of a failed upload needs (BR22.10).
        await self._asset_reference(key).delete()
