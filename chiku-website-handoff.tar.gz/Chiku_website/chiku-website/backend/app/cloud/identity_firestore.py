"""The `IdentityStore` on Firestore.

**UNVERIFIED AGAINST THE REAL SERVICE.** No code in this module has ever executed against
Firestore. It passes the shared conformance suite against an in-process fake, which proves
it satisfies the port's contract as that suite expresses it and proves nothing about the
service; every statement here about Firestore behaviour comes from published documentation
(BR31.5).

**It ships no owner record, no seed credential and no sample password** -- not here, not in
a collection definition, not in a fixture. `owner_record_create_if_absent` is the one-shot
provisioning gate, and its gate condition is the record's **existence**, so a restart
cannot reopen it. A fresh database has no account anyone can sign in to, which is the
acceptance test for the no-default-credential rule.

**Three things this adapter deliberately does not do**, each named because the mapping in
`entities.md` invites one of them:

* **It evaluates no expiry** (BR22.14). `entities.md` § *Firestore mapping* notes that an
  expired session could be *"deleted when read"*. That is a **rule**, and this port does
  not own it: `session_read` returns a record past either bound exactly as stored, and the
  consumer applies both. BR31.1 settles the conflict -- the port is the contract and an
  adapter never negotiates it -- so the note is recorded as a deployment-side sweep
  opportunity, not implemented here. `code-summary.md` carries it as a surfaced gap.
* **It compares against no threshold.** 5 per account and 20 per source address are the
  consumer's numbers; `login_attempts_count_in_window` returns a count, not a verdict.
* **It never touches the hash** (BR3.6). ``password_hash`` is an argon2id PHC string
  stored verbatim and returned to the verifying component only -- never parsed, compared,
  derived from or logged.

**Every read-modify-write runs inside a transaction**, including the ones no test races.
Firestore's transaction is the published primitive for that shape, and an adapter whose
atomicity depends on which operations happen to be contended is an adapter whose
correctness depends on load.
"""

from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timedelta
from typing import Any, cast

from app.auth.store import (
    AttemptScope,
    LoginAttemptWindow,
    OwnerRecord,
    SessionRecord,
    window_is_current,
)
from app.cloud.clients import (
    DocumentData,
    DocumentReferenceLike,
    FirestoreLike,
    TransactionLike,
    document_id_for,
    instant,
    number,
    optional_instant,
    text,
)

OWNER_COLLECTION = "owner"
SESSIONS_COLLECTION = "sessions"
ATTEMPTS_COLLECTION = "attempts"

# A fixed constant this package chose, so it is used verbatim: exactly one owner document
# ever exists, and its absence is what gates the bootstrap route.
OWNER_DOCUMENT_ID = "singleton"

OWNER_ID_FIELD = "owner_id"
EMAIL_FIELD = "email"
STORED_HASH_FIELD = "password_hash"
CREATED_AT_FIELD = "created_at"
HASH_UPDATED_AT_FIELD = "password_updated_at"

SESSION_ID_FIELD = "session_id"
ISSUED_AT_FIELD = "issued_at"
LAST_SEEN_AT_FIELD = "last_seen_at"
ABSOLUTE_EXPIRES_AT_FIELD = "absolute_expires_at"
REVOKED_AT_FIELD = "revoked_at"
CSRF_PAIRING_FIELD = "csrf_token"

# These three constants are named for what they HOLD rather than for the field they
# name, because a name carrying "password" or "token" beside a string literal is what
# the hardcoded-credential lint rule looks for. The stored field names are unchanged;
# renaming the constant is cheaper and more honest than suppressing the rule.
SCOPE_FIELD = "scope"
WINDOW_KEY_FIELD = "window_key"
FAILURE_COUNT_FIELD = "failure_count"
WINDOW_STARTED_AT_FIELD = "window_started_at"


def _owner_from(data: DocumentData) -> OwnerRecord:
    return OwnerRecord(
        owner_id=text(data[OWNER_ID_FIELD]),
        email=text(data[EMAIL_FIELD]),
        password_hash=text(data[STORED_HASH_FIELD]),
        created_at=instant(data[CREATED_AT_FIELD]),
        password_updated_at=optional_instant(data[HASH_UPDATED_AT_FIELD]),
    )


def _session_from(data: DocumentData) -> SessionRecord:
    return SessionRecord(
        session_id=text(data[SESSION_ID_FIELD]),
        owner_id=text(data[OWNER_ID_FIELD]),
        issued_at=instant(data[ISSUED_AT_FIELD]),
        last_seen_at=instant(data[LAST_SEEN_AT_FIELD]),
        absolute_expires_at=instant(data[ABSOLUTE_EXPIRES_AT_FIELD]),
        revoked_at=optional_instant(data[REVOKED_AT_FIELD]),
        csrf_token=text(data[CSRF_PAIRING_FIELD]),
    )


def _session_document(record: SessionRecord) -> dict[str, Any]:
    return {
        SESSION_ID_FIELD: record.session_id,
        OWNER_ID_FIELD: record.owner_id,
        ISSUED_AT_FIELD: record.issued_at.isoformat(),
        LAST_SEEN_AT_FIELD: record.last_seen_at.isoformat(),
        ABSOLUTE_EXPIRES_AT_FIELD: record.absolute_expires_at.isoformat(),
        REVOKED_AT_FIELD: None if record.revoked_at is None else record.revoked_at.isoformat(),
        CSRF_PAIRING_FIELD: record.csrf_token,
    }


def _window_from(data: DocumentData) -> LoginAttemptWindow:
    return LoginAttemptWindow(
        scope=cast("AttemptScope", text(data[SCOPE_FIELD])),
        window_key=text(data[WINDOW_KEY_FIELD]),
        failure_count=number(data[FAILURE_COUNT_FIELD]),
        window_started_at=instant(data[WINDOW_STARTED_AT_FIELD]),
    )


class FirestoreIdentityStore:
    """`IdentityStore` over one Firestore database."""

    def __init__(self, client: FirestoreLike) -> None:
        self._client = client

    def _owner_reference(self) -> DocumentReferenceLike:
        return self._client.collection(OWNER_COLLECTION).document(OWNER_DOCUMENT_ID)

    def _session_reference(self, session_id: str) -> DocumentReferenceLike:
        return self._client.collection(SESSIONS_COLLECTION).document(document_id_for(session_id))

    def _window_reference(self, scope: AttemptScope, window_key: str) -> DocumentReferenceLike:
        # Identity is the PAIR: the two scopes are separate documents, not two counters on
        # one document. A name keyed on the subject alone would merge the account and
        # address counts and still look right in any fixture that used different keys.
        # `scope` is one of two fixed literals and neither contains a colon, so the join
        # is injective before it is encoded.
        return self._client.collection(ATTEMPTS_COLLECTION).document(
            document_id_for(f"{scope}:{window_key}")
        )

    @staticmethod
    async def _read(
        transaction: TransactionLike, reference: DocumentReferenceLike
    ) -> dict[str, Any] | None:
        # A document read yields exactly one snapshot, whose `exists` may be false.
        snapshots = [snapshot async for snapshot in transaction.get(reference)]
        return snapshots[0].to_dict()

    # --- the owner ------------------------------------------------------------------- #

    async def owner_record_read(self) -> OwnerRecord | None:
        snapshot = await self._owner_reference().get()
        data = snapshot.to_dict()
        if data is None:
            return None
        return _owner_from(data)

    async def owner_record_create_if_absent(self, record: OwnerRecord) -> bool:
        """Create the owner **only if none exists**, atomically against a concurrent caller.

        BR3.7 and BR22.13. The transaction is what makes this atomic: the read and the
        write are one serialisable unit, so two simultaneous attempts produce one record
        and one refusal rather than two records or a lost one. Spelling it as an
        unprotected read followed by a write would still pass a sequential test.

        It matters more here than almost anywhere else in the system, because the
        operation can never be re-run once it has succeeded: a lost provisioning on a
        container with no interactive shell leaves a system nobody can sign in to and no
        route that will let them.
        """
        reference = self._owner_reference()
        async with self._client.transaction() as transaction:
            if await self._read(transaction, reference) is not None:
                # The gate condition is the record's EXISTENCE -- not a consumed flag, not
                # a marker file, not an environment variable. A restart cannot reopen it.
                return False
            transaction.set(
                reference,
                {
                    OWNER_ID_FIELD: record.owner_id,
                    EMAIL_FIELD: record.email,
                    # Stored verbatim. Never parsed, compared, derived from or logged.
                    STORED_HASH_FIELD: record.password_hash,
                    CREATED_AT_FIELD: record.created_at.isoformat(),
                    HASH_UPDATED_AT_FIELD: None
                    if record.password_updated_at is None
                    else record.password_updated_at.isoformat(),
                },
            )
        return True

    # --- sessions -------------------------------------------------------------------- #

    async def session_create(self, record: SessionRecord) -> None:
        # Stored as given. The store generates nothing -- `revoked_at` is a value the
        # consumer supplies like any other, and a record that ARRIVES revoked is held.
        await self._session_reference(record.session_id).set(_session_document(record))

    async def session_read(self, session_id: str) -> SessionRecord | None:
        snapshot = await self._session_reference(session_id).get()
        data = snapshot.to_dict()
        if data is None:
            return None
        # As stored. NO expiry is evaluated and nothing is filtered (BR22.14) -- and in
        # particular nothing is deleted on read. See the module docstring.
        return _session_from(data)

    async def _amend_session(self, session_id: str, **changes: Any) -> None:
        """Read the session and write it back with ``changes`` applied, or do nothing.

        Touching or revoking a session that is not there is a no-op; the consumer
        discovers absence through `session_read`, which is the operation that reports it.
        """
        reference = self._session_reference(session_id)
        async with self._client.transaction() as transaction:
            data = await self._read(transaction, reference)
            if data is None:
                return
            transaction.set(reference, {**data, **changes})

    async def session_touch(self, session_id: str, now: datetime) -> None:
        # `last_seen_at` ALONE. `absolute_expires_at` is deliberately not in this call and
        # must never be: an adapter that "helpfully" refreshed both would destroy the
        # seven-day ceiling silently, because the session keeps working.
        await self._amend_session(session_id, last_seen_at=now.isoformat())

    async def session_revoke(self, session_id: str, now: datetime) -> None:
        # Server-side (BR3.17): a stolen cookie stops working rather than merely
        # disappearing from one browser, and the very next read reports it.
        await self._amend_session(session_id, revoked_at=now.isoformat())

    # --- login attempt windows ------------------------------------------------------- #

    async def login_attempts_record_failure(
        self,
        scope: AttemptScope,
        window_key: str,
        now: datetime,
        window_length: timedelta,
    ) -> None:
        """Increment the counter, starting a new window on rollover.

        Read-modify-write, so it runs in a transaction. `window_is_current` is shared with
        the counting operation on purpose: if each carried its own copy, a rolled-over
        window could be counted as zero by one and incremented by the other, and the
        counter would drift in a direction nobody chose.
        """
        reference = self._window_reference(scope, window_key)
        async with self._client.transaction() as transaction:
            data = await self._read(transaction, reference)
            existing = None if data is None else _window_from(data)
            if existing is None or not window_is_current(
                existing.window_started_at, now, window_length
            ):
                updated = LoginAttemptWindow(
                    scope=scope, window_key=window_key, failure_count=1, window_started_at=now
                )
            else:
                updated = replace(existing, failure_count=existing.failure_count + 1)
            transaction.set(
                reference,
                {
                    SCOPE_FIELD: updated.scope,
                    WINDOW_KEY_FIELD: updated.window_key,
                    FAILURE_COUNT_FIELD: updated.failure_count,
                    WINDOW_STARTED_AT_FIELD: updated.window_started_at.isoformat(),
                },
            )

    async def login_attempts_count_in_window(
        self,
        scope: AttemptScope,
        window_key: str,
        now: datetime,
        window_length: timedelta,
    ) -> int:
        """The failure count inside the current window, or ``0`` once it rolled over.

        **It compares nothing against a threshold.** A store that knew 5 and 20 would be
        enforcing a rule it does not own.
        """
        snapshot = await self._window_reference(scope, window_key).get()
        data = snapshot.to_dict()
        if data is None:
            return 0
        window = _window_from(data)
        if not window_is_current(window.window_started_at, now, window_length):
            return 0
        return window.failure_count

    async def login_attempts_clear(self, scope: AttemptScope, window_key: str) -> None:
        # Idempotent without a branch: clearing a counter that is not there succeeds.
        await self._window_reference(scope, window_key).delete()
