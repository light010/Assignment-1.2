# Firestore indexes — a deployment deliverable

> **These adapters are code-complete and UNVERIFIED against the real services.** Nothing
> in `app/cloud/` has ever executed against Firestore or Cloud Storage. They pass the
> shared conformance suite against an in-process fake, which proves they satisfy the
> storage ports' contract **as that suite expresses it** — and proves nothing about the
> services. Every statement in this file about Firestore behaviour comes from published
> documentation, not from execution (BR31.5). Code that passes a conformance suite looks
> exactly like code that works; that is why this paragraph is first.

## There is exactly one composite index, and that count is deliberate

```json
{
  "indexes": [
    {
      "collectionGroup": "revisions",
      "queryScope": "COLLECTION",
      "fields": [
        { "fieldPath": "revision", "order": "DESCENDING" },
        { "fieldPath": "baseline", "order": "ASCENDING" },
        { "fieldPath": "action",   "order": "DESCENDING" }
      ]
    }
  ],
  "fieldOverrides": []
}
```

It serves the revision listing's three-part order — revision descending, then non-baseline
before baseline, then publish before draft — which `ContentStore.list_revisions` returns
and the owner's revision history displays.

**This definition has to travel with the deployment artifacts.** Without it the listing
query fails at runtime rather than returning a differently ordered list. That is the better
failure of the two, but only if the definition exists somewhere a deployer will apply it
(BR31.4).

## Why "one" is a claim and not a coincidence

An **undeclared** composite index also fails at runtime. So a rule whose whole purpose is
to prevent that class of failure must not itself depend on a *second* instance of the class
being remembered by whoever writes the next query. Naming the count converts "the indexes"
— a list someone has to maintain — into "one index", which a deployer can check.

The retention prune's survivor read is shaped to honour that. It is a **single unfiltered
`revision` descending read of the bounded set**, partitioned by action **in memory**
(`select_pruned` in `content_firestore.py`). The obvious alternative — an equality filter
on `action` plus `orderBy revision DESC`, one query per action — returns exactly the same
survivors and would require a second composite index on `(action, revision DESCENDING)`
that nothing here declares. Three reasons the unfiltered form wins:

1. **It needs no second index.** A single-field ordering is served by Firestore's automatic
   single-field indexes, and the index above covers that ordering as its prefix in any case.
2. **The invariant makes it free.** Every combined write prunes, so the stored revision set
   never exceeds the retention cap of 52 — reading the whole thing costs no more than the
   filtered reads it replaces, and it is *one* round trip rather than one per action.
3. **It makes the baseline exemption checkable.** In memory the "baselines are never
   pruned" rule is a filter any reader can see and any test can assert.

`app.cloud.clients.QueryLike` carries **no `where`**, so a filtered read is not merely
discouraged — it is unwritable against the surface the adapters compile against. If anyone
widens that Protocol, `tests/cloud/test_transaction_ordering.py` shows what happens next:
the fake refuses the query for want of a declared index, which is the runtime failure this
page exists to keep out of a deployment.

## Region — one region, and it is a billing constraint

Firestore, Cloud Storage and the runtime services go in the **same region** (BR31.6).
Cross-region placement is not a performance trade here: it moves service-to-service traffic
from free to chargeable, and for Cloud Storage it forfeits the free tier entirely outside
`us-west1`, `us-central1` and `us-east1`. The zero-recurring-cost target fails if that is
got wrong.

**No region is named in code, and none is chosen here.** The choice is a deployment
decision recorded as a constraint, not a literal an adapter carries.

## What else the deployment has to provide, and what it must not

* **One Cloud Storage bucket**, reachable by the same service account. It holds two kinds
  of object, distinguishable by name: uploaded assets, and the content-addressed payload
  blobs under the `content-payloads/` prefix that `blobs.py` writes when a field exceeds
  the substitution threshold. Asset object names are URL-safe base64 and never contain
  `/`, so an asset can never land under that prefix.
* **No seeded owner record and no seed document of any kind.** The `owner` collection
  starts empty, and its emptiness is what gates the one-shot provisioning route. A fresh
  database has no account anyone can sign in to.
* **Nothing reclaims orphaned payload blobs.** A transaction that fails after its blobs
  landed leaves them behind. They are harmless by construction — the key is a hash of the
  content, so a retry collides with the identical object rather than duplicating it — but
  no sweep exists. This is an open question carried from `functional-design/entities.md`,
  recorded here because a deployer is the person who will eventually notice the storage.

## Nothing here has been provisioned

No Google Cloud project exists, no database, no bucket, no service account, no credential,
and no billing change has been made. This file is a plan for a deployment that has not
happened (`project.md`: cloud work in this piece of work is plan-only).
