"""Content-addressed substitution: the threshold, the ordering, and the reversal.

**UNVERIFIED AGAINST THE REAL SERVICES.** Nothing here has ever written to Cloud Storage.

**The conflict this resolves is real, and it is not a tuning question.** FR4.6 requires the
`ContentStore` port to accept a content document of up to 1,500,000 decoded characters,
which in UTF-8 can exceed 4 MB. Firestore's per-document limit is 1,048,576 bytes, and a
revision entry stores the **full** content -- so a save the port *must* accept cannot fit
in one Firestore document. SQLite has no such limit, so the verified adapter is unaffected
and this module has no counterpart there.

**Substitution is per stored field, not per write** (the R-01 correction). Each of the
three fields that can carry a full content document -- ``ContentDocument.draft``,
``ContentDocument.published`` and ``ContentRevision.content`` -- is checked and substituted
independently. An earlier version substituted the content document and wrote the revision
entry inline, which resolved the size conflict **for the wrong object**.

**And the order is fixed, because an unspecified branch cannot be asserted.** A field that
does not itself exceed the threshold can still need substituting when the fields' *sum*
does not fit -- reachable only for `ContentDocument`, the one document carrying two
full-content fields. `plan_substitution` settles that branch: largest serialised size
first, rechecking after each, ties broken ``draft`` before ``published``. Either outcome
fits and reads reverse both transparently, so nothing functional distinguishes them; what
the fixed order buys is **one** predictable stored state that a test can assert.

**The blob is written before the transaction, never after** (BR31.2). The key is a hash of
the content, so the write is idempotent and a transaction that then fails leaves an
orphaned blob -- reclaimable garbage -- rather than a document referencing a blob that
never landed, which is corruption. Nothing currently reclaims orphans; that is an open
question carried from `entities.md`, not an oversight.
"""

from __future__ import annotations

import hashlib
from collections.abc import Mapping, Sequence
from functools import partial
from typing import Any

from anyio import to_thread

from app.cloud.clients import (
    FIRESTORE_DOCUMENT_LIMIT_BYTES,
    BucketLike,
    DocumentData,
    estimate_document_bytes,
    text,
)

# The per-field trigger, derived from the limit rather than chosen: **half**, and the half
# is load-bearing in both directions. Above half, step 1 could leave two surviving fields
# whose sum exceeds the limit by an unbounded amount, so the largest-first loop would be
# doing the real work and the threshold would be decoration. Below half, two surviving
# fields can never collide, so the largest-first branch becomes unreachable -- and an
# unreachable branch cannot carry the 100% floor this module's caller is measured against.
# At exactly half, the collision is possible and bounded, which is the only setting where
# both rules mean something. This closes the "threshold is unset" open question in
# `entities.md`; it is a correctness boundary, not a tuning knob.
LARGE_PAYLOAD_THRESHOLD_BYTES = FIRESTORE_DOCUMENT_LIMIT_BYTES // 2

# Blobs live under their own prefix so an operator can tell a substituted payload from an
# uploaded asset in the same bucket. Base64 document names never contain `/`, so an asset
# key can never encode into this prefix.
PAYLOAD_PREFIX = "content-payloads/"
PAYLOAD_MEDIA_TYPE = "application/octet-stream"

# A substituted field moves to a DIFFERENT field name rather than holding a key in the
# same one. A sentinel inside the original field would be a value the port is forbidden to
# invent, and it would be indistinguishable from content that happened to look like one.
BLOB_FIELD_SUFFIX = "_blob"


def blob_field(name: str) -> str:
    """The field that holds ``name``'s blob key when ``name`` is substituted."""
    return f"{name}{BLOB_FIELD_SUFFIX}"


def blob_key_for(content: str) -> str:
    """The object name for a payload: a hash of the payload itself.

    Content-addressing is what makes the before-the-transaction write **idempotent**, and
    idempotence is the whole reason that ordering is safe: a retry writes the same object
    to the same name, and an abandoned attempt leaves an object a later identical save
    will simply overwrite.
    """
    return f"{PAYLOAD_PREFIX}{hashlib.sha256(content.encode('utf-8')).hexdigest()}"


def plan_substitution(
    inline_fields: Mapping[str, str],
    *,
    order: Sequence[str],
    other_fields: DocumentData,
    threshold: int,
    limit: int,
) -> tuple[str, ...]:
    """Which fields to substitute, in the order the decision was taken.

    ``order`` is the fixed field order that breaks a tie -- ``draft`` before ``published``
    for the content document -- and every candidate must appear in it.

    Two steps, and returning the **decision sequence** rather than a set is deliberate: it
    is what lets a test assert that the larger field was chosen first rather than merely
    that the document ended up fitting.

    1. Substitute every field whose own serialised size exceeds ``threshold``.
    2. While the document still does not fit, substitute the largest remaining candidate,
       rechecking after each.

    It terminates by construction: substituting every field leaves only short keys, and the
    loop stops when nothing is left regardless. ``threshold`` and ``limit`` are arguments
    rather than constants read from this module, for the same reason the retention counts
    are arguments to `commit` -- a caller owning a policy cannot be second-guessed by the
    code that applies it.
    """
    sizes = {name: len(inline_fields[name].encode("utf-8")) for name in order}

    def trial(chosen: Sequence[str]) -> dict[str, Any]:
        fields: dict[str, Any] = dict(other_fields)
        fields.update(substituted_fields(inline_fields, chosen))
        return fields

    chosen = [name for name in order if sizes[name] > threshold]
    remaining = sorted(
        (name for name in order if name not in chosen),
        # Largest first; a tie falls back to the caller's fixed field order.
        key=lambda name: (-sizes[name], order.index(name)),
    )
    while remaining and estimate_document_bytes(trial(chosen)) > limit:
        chosen.append(remaining.pop(0))
    return tuple(chosen)


def substituted_fields(inline_fields: Mapping[str, str], chosen: Sequence[str]) -> dict[str, Any]:
    """The stored representation of the candidate fields: text inline, or a key beside it."""
    fields: dict[str, Any] = {}
    for name, content in inline_fields.items():
        if name in chosen:
            fields[blob_field(name)] = blob_key_for(content)
        else:
            fields[name] = content
    return fields


def carried_fields(data: DocumentData, source: str, target: str) -> dict[str, Any]:
    """Copy a stored field into another field name **without touching Cloud Storage**.

    Because the key is a hash of the content, a substituted field can be carried by key: a
    baseline capture of an oversized draft, or a ``published`` a draft write never touched,
    costs no download, no rehash and no upload. Rewriting it would be harmless and
    invisible -- the key would be identical -- which is exactly why nothing else would
    catch the cost.
    """
    key = data.get(blob_field(source))
    if key is None:
        return {target: data[source]}
    return {blob_field(target): key}


async def write_payload(bucket: BucketLike, content: str) -> str:
    """Store a payload as a content-addressed object and answer its key.

    The published Cloud Storage client is synchronous, so the call is moved off the event
    loop -- a blocking driver never leaves an adapter (BR22.7).
    """
    key = blob_key_for(content)
    blob = bucket.blob(key)
    await to_thread.run_sync(
        partial(blob.upload_from_string, content.encode("utf-8"), PAYLOAD_MEDIA_TYPE)
    )
    return key


async def read_payload(bucket: BucketLike, key: str) -> str:
    """The payload stored under ``key``, decoded exactly as it was encoded."""
    blob = bucket.blob(key)
    data = await to_thread.run_sync(blob.download_as_bytes)
    return data.decode("utf-8")


async def resolve_payload(bucket: BucketLike, data: DocumentData, name: str) -> str:
    """``name``'s content, whether it is stored inline or as a key.

    This is the reversal, and it is what makes substitution **invisible** rather than
    merely intended: a caller of the port cannot tell a substituted field from an inline
    one, so both branches of every storage decision above are covered by the same
    conformance assertions.
    """
    key = data.get(blob_field(name))
    if key is None:
        return text(data[name])
    return await read_payload(bucket, text(key))
