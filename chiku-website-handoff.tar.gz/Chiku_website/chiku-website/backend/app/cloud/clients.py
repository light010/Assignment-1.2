"""The client surface these adapters use, as structural `Protocol`s, plus the field
readers that narrow what a client hands back.

**UNVERIFIED AGAINST THE REAL SDKs.** Every Protocol here is a *claim about an API*,
written from published documentation. No `google-cloud-firestore` or
`google-cloud-storage` package is installed, imported, or contacted -- in this module, in
the adapters that use it, or in the tests that exercise them (BR31.5).

**Why a Protocol instead of an SDK import**, stated once here because it shapes the whole
package. Writing the adapters against a structural surface buys four things at once, and
importing the SDK loses all four:

1. **No dependency is added**, so the backend image does not grow. Measured image size
   feeds the zero-recurring-cost target directly.
2. **`mypy --strict` stays clean** with no blanket ``ignore_missing_imports``. An
   unstubbed SDK would force exactly the suppression `team.md` forbids.
3. **The conformance suite can run**, against an in-process fake client. Without this the
   adapters would ship with no executable evidence at all.
4. **A real SDK client is a constructor argument, not a rewrite.**

The trade-off is stated rather than hidden: a Protocol can only describe the surface as
this design understands it from documentation. If the real SDK differs, the adapters fail
at first contact with the service. That is the same exposure the unit already carries as
"unverified"; it does not widen it.

**Where this surface is *shaped* rather than *copied*, and it is one place.** The
published async Firestore client drives a transaction's begin/commit/rollback through the
``@firestore.async_transactional`` decorator. A decorator is not a member of a client
object, so it cannot appear in a client Protocol at all. `TransactionLike` therefore
spells that lifecycle as an async context manager. Wiring a real client up needs one small
shim class implementing `FirestoreLike.transaction()` over `async_transactional`; **no
adapter logic changes.** Everything else below -- ``collection``, ``document``, ``get``,
``set``, ``delete``, ``order_by``, ``limit``, ``stream``, ``blob``,
``upload_from_string``, ``download_as_bytes``, ``exists``, ``reload`` -- is the published
spelling.

**Why the write methods are declared ``-> object``.** The published clients return a
write result (``WriteResult``, and so on) that these adapters ignore. A Protocol member
declared ``-> None`` would **not** be satisfied by a method returning one, because return
types are covariant. ``object`` is the honest declaration: a value is returned and this
code does not look at it.

**The asymmetry between the two services is theirs, not ours.** Firestore publishes an
``AsyncClient``, so `FirestoreLike` is async. Cloud Storage publishes no async client, so
`BucketLike` is synchronous and the adapter using it moves every call off the event loop
through ``anyio.to_thread.run_sync`` -- the same confinement `app/sqlite.py` applies to
the `sqlite3` driver (BR22.7).
"""

from __future__ import annotations

import base64
from collections.abc import AsyncIterator, Callable, Mapping
from datetime import datetime
from types import TracebackType
from typing import Any, Protocol, cast

# --- the service's own numbers ------------------------------------------------------ #
#
# Published constants, not tunables. They are here rather than in `blobs.py` because they
# describe *what the service is*; `blobs.py` decides what to do about it.

# Firestore's documented maximum size of a single document.
FIRESTORE_DOCUMENT_LIMIT_BYTES = 1_048_576

# Firestore's documented sort directions, as the client spells them.
ASCENDING = "ASCENDING"
DESCENDING = "DESCENDING"

# The HTTP statuses `google.api_core.exceptions.GoogleAPICallError` subclasses carry on
# their `code` attribute. Matching on the status rather than on the class is what lets
# this package recognise the client's errors without importing the client.
NOT_FOUND_STATUS = 404
ALREADY_EXISTS_STATUS = 409

# Firestore's documented per-document storage-size accounting. Reproduced rather than
# approximated, because the substitution planner budgets against it and the test fake
# enforces the limit with it: a guess on either side would make the two disagree.
_DOCUMENT_NAME_ALLOWANCE_BYTES = 1_024
_FIELD_NAME_TERMINATOR_BYTES = 1
_STRING_TERMINATOR_BYTES = 1
_NUMBER_BYTES = 8
_BOOLEAN_BYTES = 1
_NULL_BYTES = 1


type DocumentData = Mapping[str, Any]
"""One Firestore document's fields, as the client exchanges them."""


class DocumentSnapshotLike(Protocol):
    """Models ``google.cloud.firestore.DocumentSnapshot``.

    Deliberately **without** ``id``. A revision entry's identity is stored as a *field*,
    exactly as it is a column in the SQLite schema, so nothing in this package reads an
    identity off a document name -- which keeps the document name free to be an encoded
    form of a key the port is forbidden to validate.
    """

    @property
    def exists(self) -> bool:
        """Whether the document was there. Absence is a value, never an error."""
        ...

    def to_dict(self) -> dict[str, Any] | None:
        """The fields, or ``None`` for a snapshot of a document that does not exist."""
        ...


class DocumentReferenceLike(Protocol):
    """Models ``google.cloud.firestore.AsyncDocumentReference``."""

    async def get(self) -> DocumentSnapshotLike:
        """``AsyncDocumentReference.get()`` -- a read outside any transaction."""
        ...

    async def set(self, document_data: DocumentData) -> object:
        """``AsyncDocumentReference.set()`` -- replace the document wholesale."""
        ...

    async def delete(self) -> object:
        """``AsyncDocumentReference.delete()`` -- deleting an absent document succeeds."""
        ...


class QueryLike(Protocol):
    """Models ``google.cloud.firestore.AsyncQuery``.

    **No ``where``.** Not an omission: the only query this package issues over the
    ``revisions`` collection besides the listing is the retention prune's survivor read,
    and that read is deliberately **unfiltered** so it needs no composite index of its own
    (BR31.4). Leaving the filter off the surface these adapters are written against makes
    a filtered read impossible to write by accident rather than merely discouraged.
    """

    def order_by(self, field_path: str, direction: str) -> QueryLike:
        """``AsyncQuery.order_by()``. More than one clause needs a composite index."""
        ...

    def limit(self, count: int) -> QueryLike:
        """``AsyncQuery.limit()``."""
        ...

    def stream(self) -> AsyncIterator[DocumentSnapshotLike]:
        """``AsyncQuery.stream()`` -- a read outside any transaction."""
        ...


class CollectionLike(QueryLike, Protocol):
    """Models ``google.cloud.firestore.AsyncCollectionReference``, which is a query."""

    def document(self, document_id: str) -> DocumentReferenceLike:
        """``AsyncCollectionReference.document()``."""
        ...


class TransactionLike(Protocol):
    """Models ``google.cloud.firestore.AsyncTransaction``.

    **A transaction is a sequence of reads followed by a sequence of writes**, and a read
    issued after a write in the same transaction is rejected at runtime. That is the whole
    of BR31.3's second half, it is why `get` and `set` are separated so visibly here, and
    it is the constraint the test fake enforces rather than permits.

    ``set`` and ``delete`` are **not** ``async``: in the published client they buffer a
    write and the round trip happens at commit. The async context manager is this design's
    spelling of the begin/commit/rollback lifecycle -- see the module docstring for why
    that one member is shaped rather than copied.
    """

    async def __aenter__(self) -> TransactionLike:
        """Begin. The transaction is in its read phase."""
        ...

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        traceback: TracebackType | None,
    ) -> bool:
        """Commit when the block left cleanly, roll back when it raised.

        Returns ``False``: an exception raised inside the block is never swallowed here,
        because the adapter's own stale-write signal travels out this way.
        """
        ...

    def get(self, target: DocumentReferenceLike | QueryLike) -> AsyncIterator[DocumentSnapshotLike]:
        """``AsyncTransaction.get()``, which takes a document reference **or** a query.

        Always a stream, for both shapes, as the published client does: a document
        reference yields at most one snapshot.
        """
        ...

    def set(self, reference: DocumentReferenceLike, document_data: DocumentData) -> object:
        """``AsyncTransaction.set()`` -- buffered; the transaction is now in its write phase."""
        ...

    def delete(self, reference: DocumentReferenceLike) -> object:
        """``AsyncTransaction.delete()`` -- buffered, and likewise a write."""
        ...


class FirestoreLike(Protocol):
    """Models ``google.cloud.firestore.AsyncClient``."""

    def collection(self, collection_id: str) -> CollectionLike:
        """``AsyncClient.collection()``."""
        ...

    def transaction(self) -> TransactionLike:
        """``AsyncClient.transaction()``."""
        ...


class BlobLike(Protocol):
    """Models ``google.cloud.storage.Blob``. **Synchronous**, as the published client is."""

    metadata: dict[str, str] | None
    """Custom metadata, assigned before an upload and reloaded with the object."""

    @property
    def size(self) -> int | None:
        """The object's size in bytes, populated by ``reload``."""
        ...

    @property
    def content_type(self) -> str | None:
        """The object's stored media type, populated by ``reload``."""
        ...

    def exists(self) -> bool:
        """``Blob.exists()``."""
        ...

    def reload(self) -> object:
        """``Blob.reload()`` -- fetch the object's metadata without its bytes."""
        ...

    def upload_from_string(self, data: bytes, content_type: str) -> object:
        """``Blob.upload_from_string()``."""
        ...

    def download_as_bytes(self, start: int | None = None, end: int | None = None) -> bytes:
        """``Blob.download_as_bytes()``.

        ``start`` and ``end`` are an **inclusive** byte range, which is the published
        spelling and differs from this codebase's ``offset``/``length`` everywhere else.
        The conversion happens once, in `app.cloud.assets_gcs`, and is commented there.
        """
        ...

    def delete(self) -> object:
        """``Blob.delete()`` -- raises the not-found error when the object is absent."""
        ...


class BucketLike(Protocol):
    """Models ``google.cloud.storage.Bucket``. **Synchronous**, as the published client is."""

    def blob(self, blob_name: str) -> BlobLike:
        """``Bucket.blob()`` -- a handle, which does not itself touch the service."""
        ...


# --- recognising the client's errors without importing the client -------------------- #


def status_code_of(error: BaseException) -> int | None:
    """The HTTP status a ``GoogleAPICallError`` carries, or ``None`` for anything else.

    The published error hierarchy puts the status on ``code``. Matching on that rather
    than on the class is the one way this package can recognise "not found" without the
    SDK on the import path -- and it is a documented, stable part of the contract rather
    than a private detail.
    """
    code = getattr(error, "code", None)
    if isinstance(code, int):
        return code
    return None


def tolerate[T](status: int, call: Callable[[], T], *, fallback: T) -> T:
    """Run ``call``; answer ``fallback`` if it raised the client error carrying ``status``.

    The handler is **blind in spelling and narrow in effect**, and it has to be: the
    client's error *class* is not importable without the SDK, so the status carried on the
    error is the only thing there is to match on. **Nothing else is swallowed.** An error
    that does not carry exactly that status is re-raised unchanged, so a permissions
    failure or an outage still reaches the consumer and becomes a 503 rather than
    disappearing into a "not found" -- BR22.10 needs the absent case to succeed, and it
    does not license silence about anything else.
    """
    try:
        return call()
    except Exception as error:
        if status_code_of(error) != status:
            raise
        return fallback


def document_id_for(key: str) -> str:
    """The Firestore document name for a **caller-supplied** key.

    A document name may not contain ``/``, may not be ``.`` or ``..``, and may not match
    ``__.*__``. The ports this package implements **validate nothing** (BR22.6), so an
    adapter cannot reject a key that breaks one of those rules -- and it must not be broken
    by one either. URL-safe base64 without padding makes an illegal name structurally
    impossible rather than checked: its alphabet is ``A-Z a-z 0-9 - _``, none of which is a
    separator and none of which can spell ``..`` or a reserved name. The encoding is total,
    lossless and reversible, which is the representation conversion BR22.6 permits, and it
    is the same move `app/assets/store_volume.py` makes to keep a key off the filesystem.

    **A fixed constant this package chose is used verbatim** -- the content document's id,
    the owner document's id -- because no caller supplied it and nothing about it can be
    illegal. Only values that arrive from outside are encoded.

    Identity is never read back out of a document name: every shape stores its own id as a
    **field**, exactly as it is a column in the SQLite schema.
    """
    return base64.urlsafe_b64encode(key.encode("utf-8")).decode("ascii").rstrip("=")


def document_fields(snapshot: DocumentSnapshotLike) -> dict[str, Any]:
    """The fields of a snapshot **already known to exist**.

    A cast, not a check. Every caller has already established existence -- a query only
    streams documents that are there, and a document read branches on `to_dict()` being
    ``None`` before it gets here -- so a runtime check would be an unreachable branch in a
    module carrying a 100% branch-coverage floor. It narrows `Any`, exactly as `text` and
    `number` below do, and changes no value.
    """
    return cast("dict[str, Any]", snapshot.to_dict())


# --- field readers ------------------------------------------------------------------- #
#
# `to_dict()` hands back `dict[str, Any]`, and `mypy --strict` refuses to let `Any` leak
# out of a typed function. These narrow a field to the type its stored shape declares,
# exactly as `app/sqlite.py`'s column readers narrow what the driver returns. They are
# REPRESENTATION conversions -- total, lossless, reversible, invisible to a caller who
# both writes and reads the port's type -- and never the semantic coercion BR22.6 forbids:
# nothing here parses a number out of a string, applies a default, or normalises a shape.


def text(value: object) -> str:
    return cast(str, value)


def optional_text(value: object) -> str | None:
    if value is None:
        return None
    return cast(str, value)


def number(value: object) -> int:
    return cast(int, value)


def optional_number(value: object) -> int | None:
    if value is None:
        return None
    return cast(int, value)


def flag(value: object) -> bool:
    return cast(bool, value)


def instant(value: object) -> datetime:
    """Parse an instant back out of its ISO-8601 field.

    **Instants are stored as text, although Firestore has a native timestamp type.** The
    native type normalises to UTC and truncates to microseconds, so an offset-bearing
    value would come back changed -- and changing a value on the way through is the one
    thing this port is not allowed to do (BR22.5, BR22.6). `datetime.isoformat` and
    `datetime.fromisoformat` are exact inverses for an aware datetime, offset included, so
    text is the representation that round-trips. `app/sqlite.py` stores them the same way
    for the same reason, which is also what keeps the two adapters comparable.
    """
    return datetime.fromisoformat(cast(str, value))


def optional_instant(value: object) -> datetime | None:
    if value is None:
        return None
    return datetime.fromisoformat(cast(str, value))


# --- document size accounting -------------------------------------------------------- #


def value_bytes(value: object) -> int:
    """Firestore's documented storage size for one field value.

    From the published size-accounting table: a string costs its UTF-8 byte length plus
    one; an integer costs 8; a boolean or a null costs 1.

    **There is no `datetime` branch**, although Firestore has a native timestamp type,
    because this package stores every instant as a string (see `instant`) -- so a datetime
    reaching here is a mistake, and the `TypeError` is how it surfaces rather than being
    measured by a rule nobody decided.
    """
    if isinstance(value, str):
        return len(value.encode("utf-8")) + _STRING_TERMINATOR_BYTES
    if isinstance(value, bool):
        # Before `int`: `bool` IS an `int` in Python, and a boolean field costs 1, not 8.
        return _BOOLEAN_BYTES
    if isinstance(value, int):
        return _NUMBER_BYTES
    if value is None:
        return _NULL_BYTES
    raise TypeError(f"no documented Firestore size for {type(value).__name__}")


def estimate_document_bytes(data: DocumentData) -> int:
    """The stored size of a whole document, including an allowance for its name.

    The document's own name counts toward the limit and depends on the project and
    database path, which an adapter does not know. `_DOCUMENT_NAME_ALLOWANCE_BYTES` is a
    deliberate over-allowance for it: budgeting a little small is the safe direction,
    because the consequence of being wrong the other way is a write the service rejects.
    """
    total = _DOCUMENT_NAME_ALLOWANCE_BYTES
    for field_name, value in data.items():
        total += len(field_name.encode("utf-8")) + _FIELD_NAME_TERMINATOR_BYTES
        total += value_bytes(value)
    return total
