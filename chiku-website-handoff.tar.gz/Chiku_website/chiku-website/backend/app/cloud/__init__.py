"""The Google Cloud implementations of the three storage ports.

**UNVERIFIED AGAINST THE REAL SERVICES.** Nothing in this package has ever executed
against Firestore or Cloud Storage. Every statement it makes about service behaviour
comes from published documentation, and the conformance suite it passes proves only that
it satisfies the port's contract as that suite expresses it (BR31.5).

Named for the thing it owns rather than for a layer: these are the Google Cloud adapters
and nothing else lives here.
"""
