"""Startup configuration, and the asymmetry between the two secrets this system reads.

**The signing key stops the process; the bootstrap secret does not.** That asymmetry is
decided, not accidental, and it is the whole reason this module exists as its own thing
rather than as two `os.environ.get` calls at the point of use:

* A missing, empty or short **signing key** is a misconfiguration. Every session the
  process issues is worthless, and the operator has no way to find that out from the
  running system. It must stop the process (BR3.13).
* A missing **bootstrap secret** is a legitimate state -- an already-provisioned system
  that no longer needs the one-shot route, or one provisioned from the command line. It
  must not stop the process (BR3.9).

**There is no default, no fallback, and explicitly no auto-generated per-process key.**
An auto-generated key is the worse of the two failure modes *because it looks like it
works*: the service starts, sign-in succeeds, and every session silently dies at the next
restart with nothing in any log to say why. A raise at startup is loud, names the
variable, and is fixed in one line.

**All three signing-key conditions are checked separately** -- unset, empty, and under 32
bytes -- rather than folded into one falsy test. The present-but-short key is the one a
naive check misses and the one a human is most likely to produce by hand, which is also
why the key is *generated, never chosen*:

    python -c "import secrets; print(secrets.token_urlsafe(64))"

**The environment is an argument, not a global.** `load_settings` takes the mapping it
reads, so every condition below is exercised by an ordinary function call rather than by
mutating the process environment. The one place `os.environ` is read is the entry point
that starts the process.

**Nothing here seeds an owner**, under any configuration. `Settings` carries two strings
and no credential.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass

SESSION_SIGNING_KEY_VARIABLE = "SESSION_SIGNING_KEY"
ADMIN_BOOTSTRAP_VARIABLE = "ADMIN_BOOTSTRAP_SECRET"

# Bytes, not characters. A key of 32 non-ASCII characters is more than 32 bytes and a key
# of 32 characters is exactly 32 only in ASCII; the strength that matters is the byte
# length of the HMAC key, so that is what is measured.
MINIMUM_SIGNING_KEY_BYTES = 32


class StartupConfigurationError(RuntimeError):
    """A startup precondition that was not met.

    Deliberately **not** a member of the `app.errors` taxonomy: that taxonomy exists to be
    rendered into an HTTP response, and this is raised before any request exists. Left
    uncaught it terminates the interpreter with a non-zero status, which is the required
    behaviour and needs no `sys.exit` to arrange.
    """


@dataclass(frozen=True, slots=True)
class Settings:
    """Everything this unit reads from the environment, validated.

    An instance existing at all is the proof that the signing key passed its three
    checks -- there is no way to construct one from an environment that failed them
    except by writing the value in by hand, which is what a test does to build a valid
    one rather than to bypass a check.
    """

    session_signing_key: str
    # `None` means "the one-shot provisioning route does not exist". It never means
    # "use a default": there is no default.
    admin_bootstrap_secret: str | None


def load_settings(environ: Mapping[str, str]) -> Settings:
    """Read and validate the startup configuration, or raise.

    Raises `StartupConfigurationError` when `SESSION_SIGNING_KEY` is unset, empty, or
    under `MINIMUM_SIGNING_KEY_BYTES`. The message names the variable, because the
    operator reading a crashed container's last line of output has nothing else to go on.
    """
    return Settings(
        session_signing_key=_require_signing_key(environ),
        admin_bootstrap_secret=_read_bootstrap_secret(environ),
    )


def _require_signing_key(environ: Mapping[str, str]) -> str:
    raw = environ.get(SESSION_SIGNING_KEY_VARIABLE)
    if raw is None:
        raise StartupConfigurationError(
            f"{SESSION_SIGNING_KEY_VARIABLE} is not set. Generate one with"
            ' `python -c "import secrets; print(secrets.token_urlsafe(64))"`'
            " and supply it as an environment variable. There is no default."
        )
    if raw == "":
        raise StartupConfigurationError(
            f"{SESSION_SIGNING_KEY_VARIABLE} is set but empty."
            " There is no default and no per-process key is generated."
        )
    # Checked separately from the empty case on purpose: a present-but-short key is the
    # one a naive `if not value` test lets through.
    if len(raw.encode("utf-8")) < MINIMUM_SIGNING_KEY_BYTES:
        raise StartupConfigurationError(
            f"{SESSION_SIGNING_KEY_VARIABLE} is shorter than"
            f" {MINIMUM_SIGNING_KEY_BYTES} bytes. Generate one with"
            ' `python -c "import secrets; print(secrets.token_urlsafe(64))"`'
            " rather than choosing one by hand."
        )
    return raw


def _read_bootstrap_secret(environ: Mapping[str, str]) -> str | None:
    """Absence is a legitimate state and never fails startup (BR3.9).

    An **empty** value is treated as absence rather than as a secret. The alternative --
    honouring the empty string -- would open the one-shot provisioning route to anyone who
    sends an empty header, which is a shipped credential in everything but name.
    """
    raw = environ.get(ADMIN_BOOTSTRAP_VARIABLE)
    if raw is None or raw == "":
        return None
    return raw
