"""Fixture access.

Every assertion in this suite is a *characterization* assertion: its expected value was
recorded from the running source app, not chosen by whoever wrote the test. That is the
whole point. A test written from the same misreading as the implementation is green,
covered, and wrong.
"""

from __future__ import annotations

import json
import pathlib
from typing import Any

FIXTURES = pathlib.Path(__file__).resolve().parents[2] / "fixtures"


def manifest() -> dict[str, Any]:
    data: dict[str, Any] = json.loads((FIXTURES / "MANIFEST.json").read_text())
    return data


def meta(name: str) -> dict[str, Any]:
    data: dict[str, Any] = json.loads((FIXTURES / "http" / f"{name}.meta.json").read_text())
    return data


def body(name: str) -> bytes:
    return (FIXTURES / "http" / f"{name}.body").read_bytes()


def names(prefix: str) -> list[str]:
    return sorted(
        p.name.removesuffix(".meta.json") for p in (FIXTURES / "http").glob(f"{prefix}*.meta.json")
    )


def response_header(name: str, header: str) -> str | None:
    for key, value in meta(name)["response"]["headers"]:
        if key.lower() == header.lower():
            return str(value)
    return None
