"""`RevisionLedger` -- listing order, the cap, retention, id validation, restore.

Two properties here are the kind a looser test cannot see:

* **The listing order differs from "newest first" only on a tied revision.** A port that
  sorted on revision alone passes any test written from the looser wording, so the tie is
  asserted explicitly.
* **The cap and the retention counts are the same number by construction.** Asserting `52`
  as a literal would let the two drift apart silently; `listing_cap_for` is the
  construction and the assertion is against it.

Both real `ContentStore` implementations are exercised. Neither is mocked: the retention
outcome is a property of the write the store performs, and asserting it against a stand-in
would assert this unit's belief about the store rather than the store.
"""

from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any

import pytest

from app import errors
from app.content.authority import ContentAuthority
from app.content.ledger import (
    DRAFT_KEEP,
    HISTORY_ID_INVALID,
    HISTORY_NOT_FOUND,
    LISTING_CAP,
    PUBLISH_KEEP,
    RETENTION,
    RevisionLedger,
)
from app.content.store import (
    BASELINE_DRAFT_ID,
    BASELINE_PUBLISHED_ID,
    ContentStore,
    listing_cap_for,
)
from content.conftest import EXPECTED_LISTING_CAP, EXPECTED_RETENTION, at, wire_seed

pytestmark = pytest.mark.anyio


def save_body(document: dict[str, Any], revision: int, action: str) -> str:
    payload = {"content": document, "revision": revision, "action": action}
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


async def write(authority: ContentAuthority, revision: int, action: str, name: str) -> None:
    document = wire_seed()
    document["name"] = name
    await authority.save(body=save_body(document, revision, action), now=at(revision + 1))


# --------------------------------------------------------------------------------- #
# The policy -- owned here, supplied as an argument, and applied by the write
# --------------------------------------------------------------------------------- #


async def test_the_cap_is_the_retention_policy_by_construction(
    store_factory: Callable[[], ContentStore],
) -> None:
    """52 is `30 + 20 + 2`. Not a page size, and not a literal anyone can change alone."""
    ledger = RevisionLedger(store_factory())
    assert ledger.retention == RETENTION == EXPECTED_RETENTION
    assert DRAFT_KEEP == 30
    assert PUBLISH_KEEP == 20
    assert ledger.listing_cap == LISTING_CAP == listing_cap_for(RETENTION) == EXPECTED_LISTING_CAP
    assert LISTING_CAP == DRAFT_KEEP + PUBLISH_KEEP + len(RETENTION.permanent_ids) == 52


async def test_the_ledger_performs_no_write(
    store_factory: Callable[[], ContentStore],
) -> None:
    """BR5.9, ADR-001: the ledger supplies the policy; `ContentAuthority` applies it.

    If the ledger wrote directly, the combined write would no longer be one call with one
    caller -- which is the single-writer property both of that write's guards depend on.
    """
    store = store_factory()
    authority = ContentAuthority(store, retention=RevisionLedger(store).retention)
    await write(authority, 0, "draft", "First")

    ledger = RevisionLedger(store)
    before = await store.read_state()
    ids_before = [entry.id for entry in await store.list_revisions()]

    listed = await ledger.list_revisions()
    await ledger.read_revision(listed[0].id)
    await ledger.read_revision(BASELINE_DRAFT_ID)

    assert await store.read_state() == before
    assert [entry.id for entry in await store.list_revisions()] == ids_before


# --------------------------------------------------------------------------------- #
# BR5.1-BR5.4 -- the three-part order, and the cap
# --------------------------------------------------------------------------------- #


async def test_the_listing_order_is_asserted_across_a_tied_revision(
    store_factory: Callable[[], ContentStore],
) -> None:
    """`revision` DESC, then `baseline` ASC, then `action` DESC.

    The two baselines share revision 0, so the tie is real: only `action` DESC decides
    that `publish` precedes `draft` there. A single-key sort is identical to this one
    until there is a tie, which is why the tie is what gets asserted.
    """
    store = store_factory()
    authority = ContentAuthority(store, retention=RETENTION)
    for revision in range(3):
        await write(authority, revision, "draft", f"Draft {revision}")

    listing = await RevisionLedger(store).list_revisions()
    assert [(row.revision, row.baseline, row.action) for row in listing] == [
        (3, False, "draft"),
        (2, False, "draft"),
        (1, False, "draft"),
        (0, True, "publish"),
        (0, True, "draft"),
    ]
    assert [row.id for row in listing][-2:] == [BASELINE_PUBLISHED_ID, BASELINE_DRAFT_ID]


async def test_the_listing_carries_summaries_and_never_content(
    store_factory: Callable[[], ContentStore],
) -> None:
    """A listing of 52 documents, any one of which may exceed 4 MB, is not a listing."""
    store = store_factory()
    await write(ContentAuthority(store, retention=RETENTION), 0, "draft", "First")
    row = (await RevisionLedger(store).list_revisions())[0]
    assert set(row.model_dump(by_alias=True)) == {
        "id",
        "revision",
        "action",
        "createdAt",
        "baseline",
    }


async def test_retention_keeps_thirty_drafts_and_twenty_publishes_independently(
    store_factory: Callable[[], ContentStore],
) -> None:
    """A run of 30 drafts never evicts a publish, and the listing needs no pagination.

    The publishes are written **first** so that a combined cap -- or a prune that ordered
    across both actions -- would have reached them by the end of the draft run.
    """
    store = store_factory()
    authority = ContentAuthority(store, retention=RETENTION)
    revision = 0
    for index in range(PUBLISH_KEEP + 5):
        await write(authority, revision, "publish", f"Publish {index}")
        revision += 1
    for index in range(DRAFT_KEEP + 5):
        await write(authority, revision, "draft", f"Draft {index}")
        revision += 1

    listing = await RevisionLedger(store).list_revisions()
    drafts = [row for row in listing if row.action == "draft" and not row.baseline]
    publishes = [row for row in listing if row.action == "publish" and not row.baseline]
    baselines = [row for row in listing if row.baseline]

    assert len(drafts) == DRAFT_KEEP
    assert len(publishes) == PUBLISH_KEEP
    assert len(baselines) == 2, "both starting captures survived a prune of 10 entries"
    assert {row.id for row in baselines} == {BASELINE_PUBLISHED_ID, BASELINE_DRAFT_ID}
    assert len(listing) == LISTING_CAP == 52
    assert listing == await RevisionLedger(store).list_revisions(), "one result, no cursor"


async def test_the_baselines_survive_a_prune_that_ordering_alone_would_not_have_spared(
    store_factory: Callable[[], ContentStore],
) -> None:
    """They hold the LOWEST revision, so an ordering-based prune reaches them first.

    The exclusion has to be part of the delete predicate. A once-ever capture cannot be
    recreated: what an ordering accident deletes is the pre-migration state, permanently.
    """
    store = store_factory()
    authority = ContentAuthority(store, retention=RETENTION)
    for revision in range(DRAFT_KEEP + 3):
        await write(authority, revision, "draft", f"Draft {revision}")

    listing = await RevisionLedger(store).list_revisions()
    baselines = [row for row in listing if row.baseline]
    assert len(baselines) == 2
    assert min(row.revision for row in baselines) == 0
    assert min(row.revision for row in listing if not row.baseline) > 0


# --------------------------------------------------------------------------------- #
# BR5.5 -- the id is validated FIRST, and absent is not empty
# --------------------------------------------------------------------------------- #

MALFORMED_IDS = ("", " ", "a" * 101, "has space", "under_score", "dot.dot", "slash/slash", "%")


@pytest.mark.parametrize("revision_id", MALFORMED_IDS, ids=lambda v: repr(v))
async def test_a_malformed_revision_id_is_invalid_and_not_a_listing_or_a_not_found(
    store_factory: Callable[[], ContentStore], revision_id: str
) -> None:
    """**Present-but-empty is a real branch.** Treating it as absent would silently turn a
    malformed request into a successful listing, and the caller would never learn its id
    was wrong.
    """
    with pytest.raises(errors.Invalid) as raised:
        await RevisionLedger(store_factory()).read_revision(revision_id)
    assert raised.value.message == HISTORY_ID_INVALID
    assert "issues" not in raised.value.extra


async def test_an_id_at_the_hundred_character_boundary_is_accepted(
    store_factory: Callable[[], ContentStore],
) -> None:
    """The cap is 100, and one over is invalid -- both sides of the same boundary."""
    ledger = RevisionLedger(store_factory())
    assert await ledger.read_revision("a" * 100) is None, "well-formed, and names nothing"
    with pytest.raises(errors.Invalid):
        await ledger.read_revision("a" * 101)


async def test_a_well_formed_id_that_names_nothing_is_absence_not_an_error(
    store_factory: Callable[[], ContentStore],
) -> None:
    """BR5.10. Absence is a return value; the caller answers with the reassuring sentence."""
    assert await RevisionLedger(store_factory()).read_revision("nothing-here") is None
    assert HISTORY_NOT_FOUND == (
        "This version is no longer in the recent history. Your current draft is unchanged."
    )


async def test_a_pruned_entry_reads_as_absent(
    store_factory: Callable[[], ContentStore],
) -> None:
    store = store_factory()
    authority = ContentAuthority(store, retention=RETENTION)
    for revision in range(DRAFT_KEEP + 2):
        await write(authority, revision, "draft", f"Draft {revision}")

    ledger = RevisionLedger(store)
    surviving = {row.id for row in await ledger.list_revisions()}
    pruned = "b" * 36
    assert pruned not in surviving
    assert await ledger.read_revision(pruned) is None


async def test_a_row_carrying_no_content_reads_as_absent(
    store_factory: Callable[[], ContentStore],
) -> None:
    """The source tests the content column for truthiness; an empty column is a not-found.

    A row whose content is present but *unparseable* is deliberately a different case: it
    propagates, as the source's own catch does, because telling the owner the version is
    "no longer in the recent history" would be untrue of an entry that demonstrably exists.
    """
    store = store_factory()
    marker = "blank-content"
    await store.commit(
        content="",
        base_revision=0,
        action="draft",
        mutation_token=marker,
        retention=RETENTION,
        now=at(1),
    )
    assert await RevisionLedger(store).read_revision(marker) is None


# --------------------------------------------------------------------------------- #
# BR5.6 -- restoring never publishes
# --------------------------------------------------------------------------------- #


async def test_restoring_returns_the_content_for_review_and_publishes_nothing(
    store_factory: Callable[[], ContentStore],
) -> None:
    """A restore that published would put historical content live with one click."""
    store = store_factory()
    authority = ContentAuthority(store, retention=RETENTION)
    await write(authority, 0, "draft", "Historical")
    await write(authority, 1, "publish", "Current")

    before = await store.read_state()
    ledger = RevisionLedger(store)
    historical = next(
        row for row in await ledger.list_revisions() if row.revision == 1 and not row.baseline
    )
    restored = await ledger.read_revision(historical.id)

    assert restored is not None
    assert restored.content.name == "Historical"
    assert restored.revision == 1
    assert restored.action == "draft"
    assert restored.baseline is False
    assert await store.read_state() == before, "no write, and published did not move"
    assert json.loads((await store.read_state()).published)["name"] == "Current"


async def test_a_restored_entry_is_re_parsed_so_the_read_path_defaults_apply(
    store_factory: Callable[[], ContentStore],
) -> None:
    """BR9.2 reaches history too: a stored entry is re-validated and re-transformed."""
    store = store_factory()
    legacy = wire_seed()
    del legacy["research"][0]["researchTopic"]
    marker = "legacy-entry"
    await store.commit(
        content=json.dumps(legacy, ensure_ascii=False, separators=(",", ":")),
        base_revision=0,
        action="draft",
        mutation_token=marker,
        retention=RETENTION,
        now=at(1),
    )
    restored = await RevisionLedger(store).read_revision(marker)
    assert restored is not None
    assert restored.content.research[0].research_topic == "materials"
