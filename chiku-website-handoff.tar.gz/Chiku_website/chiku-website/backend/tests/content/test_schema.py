"""The 31-field schema, its caps at both sides of every boundary, and the seed.

The oracle for the seed is `F3-content-owner`, recorded from the running source. The
oracle for the caps is `entities.md` § ENT-4 and § *The cap census*, which enumerate them
from the source files directly.

**Every cap is asserted at the maximum accepted AND one over rejected.** A test that only
checks the rejecting side passes against a cap that is too small, and a test that only
checks the accepting side passes against a cap that is absent -- and `max(100)` is used in
this schema for three unrelated things (a string length, an array length and a *numeric*
upper bound), which is exactly the transcription a one-sided test cannot see.
"""

from __future__ import annotations

import json
from typing import Any

import pytest
from conftest import body
from pydantic import ValidationError
from pydantic_core import ErrorDetails

from app.content.schema import (
    ContentDocument,
    ContentItem,
    SiteCopy,
    instant_to_wire,
    serialise,
    wire_name,
)
from app.content.seed import seed_document
from content.conftest import blank_item, drop_at, recorded_document, set_at, wire_seed

# The 31 top-level field names, in the source's declaration order.
TOP_LEVEL_FIELDS = (
    "name",
    "role",
    "affiliation",
    "location",
    "headline",
    "intro",
    "bio",
    "email",
    "photo",
    "photoAlt",
    "photoSources",
    "photoFocalX",
    "photoFocalY",
    "copy",
    "cv",
    "scholar",
    "orcid",
    "github",
    "linkedin",
    "accent",
    "motion",
    "scene",
    "scholarHighlights",
    "showNotice",
    "notice",
    "sections",
    "achievements",
    "research",
    "publications",
    "journey",
    "news",
)


def plain(length: int) -> str:
    return "a" * length


def a_url(length: int) -> str:
    """A URL that passes the refinement and is exactly `length` characters."""
    prefix = "https://e.co/"
    return prefix + "a" * (length - len(prefix))


def an_email(length: int) -> str:
    return "a" * (length - len("@e.co")) + "@e.co"


def digits(length: int) -> str:
    return "1" * length


def parses(document: dict[str, Any]) -> bool:
    try:
        ContentDocument.model_validate(document)
    except ValidationError:
        return False
    return True


def errors_for(document: dict[str, Any]) -> list[ErrorDetails]:
    with pytest.raises(ValidationError) as raised:
        ContentDocument.model_validate(document)
    return raised.value.errors()


# --------------------------------------------------------------------------------- #
# The seed
# --------------------------------------------------------------------------------- #


def test_seed_matches_the_recorded_document_field_for_field() -> None:
    """The transcription is read from the constructor and asserted against the recording.

    **`photoSources` is the one deliberate exclusion, and it is not a discrepancy in the
    seed.** `fixtures/README.md` records that the recording session closed two gaps by
    performing a real upload and a real publish through the app's own routes, so the
    recorded document is the seed plus that one uploaded asset. Everything else -- all 30
    remaining top-level fields, all 19 items, all nine copy groups -- is identical.
    """
    recorded = recorded_document()
    seeded = wire_seed()
    assert recorded["photoSources"] == [
        {
            "src": "/api/media/558fe673-2562-492b-b383-235dc74058c3.webp",
            "width": 1536,
            "height": 1024,
        }
    ]
    assert seeded["photoSources"] == []

    seeded["photoSources"] = recorded["photoSources"]
    assert seeded == recorded


def test_seed_carries_exactly_the_recorded_top_level_field_set() -> None:
    assert tuple(wire_seed()) == TOP_LEVEL_FIELDS
    assert set(recorded_document()) == set(TOP_LEVEL_FIELDS)
    assert len(TOP_LEVEL_FIELDS) == 31


def test_seed_round_trips_through_the_schema_unchanged() -> None:
    """Re-parsing a stored document must not change it: every read re-validates."""
    once = wire_seed()
    twice = ContentDocument.model_validate(once).model_dump(by_alias=True)
    assert twice == once
    assert json.loads(serialise(seed_document())) == once


def test_seed_holds_the_five_collections_the_requirement_names() -> None:
    document = seed_document()
    assert [item.id for item in document.research] == [
        "nano-materials",
        "ultrasound-imaging",
        "photoacoustics",
    ]
    assert len(document.publications) == 5
    assert len(document.achievements) == 3
    assert len(document.journey) == 4
    assert len(document.news) == 4
    assert document.scholar_highlights.visible is True


# --------------------------------------------------------------------------------- #
# The default that is most likely to be mistyped
# --------------------------------------------------------------------------------- #


def test_photo_focal_y_defaults_to_thirty_five_not_fifty() -> None:
    """35, not 50 -- a deliberate portrait framing default.

    `entities.md` names this the single most transcription-error-prone default in the
    schema. It is asserted three ways: the schema's own default, the seed's value, and
    the value the running source served.
    """
    document = drop_at(wire_seed(), ("photoFocalY",))
    assert ContentDocument.model_validate(document).photo_focal_y == 35
    assert seed_document().photo_focal_y == 35
    assert recorded_document()["photoFocalY"] == 35
    assert seed_document().photo_focal_x == 50


# --------------------------------------------------------------------------------- #
# Every cap, at both sides of its boundary
# --------------------------------------------------------------------------------- #

STRING_CAPS: tuple[tuple[str, tuple[Any, ...], int, Any], ...] = (
    ("name", ("name",), 100, plain),
    ("role", ("role",), 200, plain),
    ("affiliation", ("affiliation",), 200, plain),
    ("location", ("location",), 200, plain),
    ("headline", ("headline",), 240, plain),
    ("intro (text)", ("intro",), 10000, plain),
    ("bio (text)", ("bio",), 10000, plain),
    ("email", ("email",), 200, an_email),
    ("photo (url)", ("photo",), 2000, a_url),
    ("photoAlt (text)", ("photoAlt",), 10000, plain),
    ("cv (url)", ("cv",), 2000, a_url),
    ("notice (text)", ("notice",), 10000, plain),
    ("scholarHighlights.citations", ("scholarHighlights", "citations"), 20, plain),
    ("scholarHighlights.hIndex", ("scholarHighlights", "hIndex"), 20, plain),
    ("scholarHighlights.i10Index", ("scholarHighlights", "i10Index"), 20, plain),
    ("scholarHighlights.asOf", ("scholarHighlights", "asOf"), 100, plain),
    ("scholarHighlights.affiliation", ("scholarHighlights", "affiliation"), 200, plain),
    ("scholarHighlights.interests", ("scholarHighlights", "interests"), 1000, plain),
    ("sceneStory.title", ("scene", "delivery", "title"), 150, plain),
    ("sceneStory.description", ("scene", "delivery", "description"), 600, plain),
    ("sceneStory.link (url)", ("scene", "delivery", "link"), 2000, a_url),
    ("copy label", ("copy", "hero", "researchAction"), 80, plain),
    ("copy hero.topics", ("copy", "hero", "topics"), 200, plain),
    ("copy section title", ("copy", "research", "title"), 200, plain),
    ("copy section description", ("copy", "research", "description"), 1000, plain),
    ("copy section navigation (label)", ("copy", "research", "navigation"), 80, plain),
    ("copy scholar.title", ("copy", "scholar", "title"), 200, plain),
    ("copy footer.tagline", ("copy", "footer", "tagline"), 200, plain),
    ("item.id", ("research", 0, "id"), 100, plain),
    ("item.title", ("research", 0, "title"), 1000, plain),
    ("item.subtitle (text)", ("research", 0, "subtitle"), 10000, plain),
    ("item.year", ("research", 0, "year"), 40, plain),
    ("item.image (url)", ("research", 0, "image"), 2000, a_url),
    ("item.transcript", ("research", 0, "transcript"), 60000, plain),
    ("item.citations (citationCount)", ("research", 0, "citations"), 9, digits),
    ("item.contribution (text)", ("research", 0, "contribution"), 10000, plain),
)


@pytest.mark.parametrize(("label", "path", "maximum", "filler"), STRING_CAPS, ids=lambda v: str(v))
def test_string_cap_accepts_the_maximum(
    label: str, path: tuple[Any, ...], maximum: int, filler: Any
) -> None:
    assert parses(set_at(wire_seed(), path, filler(maximum))), label


@pytest.mark.parametrize(("label", "path", "maximum", "filler"), STRING_CAPS, ids=lambda v: str(v))
def test_string_cap_rejects_one_over_the_maximum(
    label: str, path: tuple[Any, ...], maximum: int, filler: Any
) -> None:
    assert not parses(set_at(wire_seed(), path, filler(maximum + 1))), label


def test_citation_date_cap_is_ten_characters() -> None:
    """Ten is exactly one ISO date; eleven is not a date at all."""
    assert parses(set_at(wire_seed(), ("research", 0, "citationsAsOf"), "2026-01-01"))
    assert not parses(set_at(wire_seed(), ("research", 0, "citationsAsOf"), "12026-01-01"))


def test_research_id_element_cap_is_one_hundred_characters() -> None:
    assert parses(set_at(wire_seed(), ("research", 0, "researchIds"), ["a" * 100]))
    assert not parses(set_at(wire_seed(), ("research", 0, "researchIds"), ["a" * 101]))


LIST_CAPS: tuple[tuple[str, tuple[Any, ...], int, Any], ...] = (
    ("photoSources", ("photoSources",), 4, lambda n: [{"src": "", "width": 1, "height": 1}] * n),
    (
        "item.imageSources",
        ("research", 0, "imageSources"),
        4,
        lambda n: [{"src": "", "width": 1, "height": 1}] * n,
    ),
    ("item.researchIds", ("research", 0, "researchIds"), 100, lambda n: ["a"] * n),
    ("achievements", ("achievements",), 60, lambda n: [blank_item() for _ in range(n)]),
    ("research", ("research",), 100, lambda n: [blank_item() for _ in range(n)]),
    ("publications", ("publications",), 500, lambda n: [blank_item() for _ in range(n)]),
    ("journey", ("journey",), 100, lambda n: [blank_item() for _ in range(n)]),
    ("news", ("news",), 100, lambda n: [blank_item() for _ in range(n)]),
)


@pytest.mark.parametrize(("label", "path", "maximum", "filler"), LIST_CAPS, ids=lambda v: str(v))
def test_list_cap_accepts_the_maximum(
    label: str, path: tuple[Any, ...], maximum: int, filler: Any
) -> None:
    assert parses(set_at(wire_seed(), path, filler(maximum))), label


@pytest.mark.parametrize(("label", "path", "maximum", "filler"), LIST_CAPS, ids=lambda v: str(v))
def test_list_cap_rejects_one_over_the_maximum(
    label: str, path: tuple[Any, ...], maximum: int, filler: Any
) -> None:
    assert not parses(set_at(wire_seed(), path, filler(maximum + 1))), label


def test_the_four_collection_maxima_are_all_different() -> None:
    """Only one of them is 100, and `publications` is 500. A uniform port is wrong."""
    caps = {label: maximum for label, _, maximum, _ in LIST_CAPS}
    assert caps["achievements"] == 60
    assert caps["research"] == 100
    assert caps["publications"] == 500
    assert caps["journey"] == 100
    assert caps["news"] == 100


PERCENTAGE_PATHS = (
    ("photoFocalX",),
    ("photoFocalY",),
    ("research", 0, "focalX"),
    ("research", 0, "focalY"),
)


@pytest.mark.parametrize("path", PERCENTAGE_PATHS, ids=lambda v: str(v))
def test_focal_percentage_is_a_numeric_bound_not_a_length(path: tuple[Any, ...]) -> None:
    """`max(100)` here bounds the VALUE. A port that read it as a length caps at 100 chars."""
    assert parses(set_at(wire_seed(), path, 0))
    assert parses(set_at(wire_seed(), path, 100))
    assert parses(set_at(wire_seed(), path, 33.75)), "not constrained to an integer"
    assert not parses(set_at(wire_seed(), path, -1))
    assert not parses(set_at(wire_seed(), path, 101))


def test_image_source_dimensions_are_integers_between_one_and_sixteen_thousand() -> None:
    def sized(width: Any, height: Any) -> list[dict[str, Any]]:
        return [{"src": "", "width": width, "height": height}]

    assert parses(set_at(wire_seed(), ("photoSources",), sized(1, 1)))
    assert parses(set_at(wire_seed(), ("photoSources",), sized(16000, 16000)))
    assert not parses(set_at(wire_seed(), ("photoSources",), sized(0, 1)))
    assert not parses(set_at(wire_seed(), ("photoSources",), sized(1, 16001)))
    assert not parses(set_at(wire_seed(), ("photoSources",), sized(1.5, 1)))
    # `1200.0` is an integer in JavaScript and `z.number().int()` accepts it.
    assert parses(set_at(wire_seed(), ("photoSources",), sized(1200.0, 800.0)))


# --------------------------------------------------------------------------------- #
# The asymmetries -- reproduced, not tidied
# --------------------------------------------------------------------------------- #


def test_only_achievements_has_a_collection_default() -> None:
    """A model that defaulted all five would accept documents the source rejects."""
    assert parses(drop_at(wire_seed(), ("achievements",)))
    for collection in ("research", "publications", "journey", "news"):
        assert not parses(drop_at(wire_seed(), (collection,))), collection


def test_sections_defaulting_is_asymmetric_and_the_object_itself_is_required() -> None:
    assert parses(drop_at(wire_seed(), ("sections", "achievements")))
    assert (
        ContentDocument.model_validate(
            drop_at(wire_seed(), ("sections", "achievements"))
        ).sections.achievements
        is True
    )
    for member in ("research", "publications", "journey", "news", "contact"):
        assert not parses(drop_at(wire_seed(), ("sections", member))), member
    assert not parses(drop_at(wire_seed(), ("sections",)))


def test_accent_is_required_and_has_no_default() -> None:
    assert not parses(drop_at(wire_seed(), ("accent",)))
    assert not parses(set_at(wire_seed(), ("accent",), "teal"))
    assert parses(set_at(wire_seed(), ("accent",), "burgundy"))


def test_show_notice_is_required_while_motion_and_offer_tour_default_true() -> None:
    assert not parses(drop_at(wire_seed(), ("showNotice",)))
    assert ContentDocument.model_validate(drop_at(wire_seed(), ("motion",))).motion is True
    without_tour = ContentDocument.model_validate(drop_at(wire_seed(), ("scene", "offerTour")))
    assert without_tour.scene.offer_tour is True


def test_retired_auto_tour_is_not_accepted_as_an_alias() -> None:
    """A legacy `autoTour` was deliberately retired; an unknown key is dropped, not honoured."""
    document = set_at(wire_seed(), ("scene", "autoTour"), False)
    assert ContentDocument.model_validate(document).scene.offer_tour is True
    assert (
        "autoTour"
        not in ContentDocument.model_validate(document).model_dump(by_alias=True)["scene"]
    )


# --------------------------------------------------------------------------------- #
# `copy` -- defaulting at three nesting levels, each independently
# --------------------------------------------------------------------------------- #


def test_copy_defaults_at_the_whole_object_level() -> None:
    parsed = ContentDocument.model_validate(drop_at(wire_seed(), ("copy",)))
    assert parsed.copy_ == SiteCopy()
    assert parsed.copy_.research.title == "Small scale.\nWide possibilities."


def test_copy_defaults_at_the_group_level() -> None:
    document = drop_at(wire_seed(), ("copy", "research"))
    set_at(document, ("copy", "news", "title"), "Kept")
    parsed = ContentDocument.model_validate(document)
    assert parsed.copy_.research.navigation == "Research"
    assert parsed.copy_.news.title == "Kept"


def test_copy_defaults_at_the_leaf_level() -> None:
    document = drop_at(wire_seed(), ("copy", "research", "title"))
    set_at(document, ("copy", "research", "navigation"), "Kept")
    parsed = ContentDocument.model_validate(document)
    assert parsed.copy_.research.title == "Small scale.\nWide possibilities."
    assert parsed.copy_.research.navigation == "Kept"


def test_the_twenty_five_leaf_defaults_are_carried_verbatim() -> None:
    """23 non-empty and 2 empty, with the newlines and the MIDDLE DOTs intact."""
    copy = SiteCopy()
    dot = "\N{MIDDLE DOT}"
    assert copy.hero.topics == f"Drug delivery {dot} Photoacoustics {dot} Ultrasound"
    assert copy.achievements.title == "The work.\nThe moments behind it."
    assert copy.research.description == (
        "Responsive carriers. Optical contrast.\nInformation carried by sound."
    )
    assert copy.contact.description == "Research, collaboration,\nor a shared curiosity."
    assert copy.scholar.title == "A snapshot of\nthe research."
    assert copy.footer.tagline == "Materials. Delivery. Light & sound."
    # The two that are the EMPTY STRING rather than absent.
    assert copy.journey.description == ""
    assert copy.news.description == ""
    leaves = [value for group in copy.model_dump().values() for value in group.values()]
    assert len(leaves) == 25
    assert sum(1 for leaf in leaves if leaf != "") == 23


# --------------------------------------------------------------------------------- #
# The refinements, and their verbatim messages
# --------------------------------------------------------------------------------- #


def test_url_accepts_empty_http_case_insensitively_and_media_case_sensitively() -> None:
    for accepted in ("", "https://x.test/a", "HTTP://X.TEST/A", "/api/media/a-1.webp"):
        assert parses(set_at(wire_seed(), ("photo",), accepted)), accepted
    for refused in ("ftp://x.test", "/API/MEDIA/a.webp", "not a url", "https://has space"):
        assert not parses(set_at(wire_seed(), ("photo",), refused)), refused


def test_url_media_form_is_more_permissive_than_the_media_route_key_pattern() -> None:
    """A document may legally hold a media URL the media route will 404. Preserved, not fixed."""
    assert parses(set_at(wire_seed(), ("photo",), "/api/media/whatever.tar.gz"))


def test_citation_count_is_trimmed_and_citation_date_is_not() -> None:
    """They look symmetrical and are not: only `citations` carries `.trim()`."""
    trimmed = ContentDocument.model_validate(
        set_at(wire_seed(), ("research", 0, "citations"), "  104  ")
    )
    assert trimmed.research[0].citations == "104", "trimmed value is what is stored"
    assert not parses(set_at(wire_seed(), ("research", 0, "citationsAsOf"), " 2026-01-01"))


def test_citation_count_accepts_only_ascii_digits_or_empty() -> None:
    assert parses(set_at(wire_seed(), ("research", 0, "citations"), ""))
    assert parses(set_at(wire_seed(), ("research", 0, "citations"), "0"))
    assert not parses(set_at(wire_seed(), ("research", 0, "citations"), "-1"))
    assert not parses(set_at(wire_seed(), ("research", 0, "citations"), "1.5"))
    # JavaScript's `\d` is ASCII-only; Python's is not, and a Unicode-digit port would
    # accept what the source refused.
    assert not parses(set_at(wire_seed(), ("research", 0, "citations"), "\N{DEVANAGARI DIGIT ONE}"))


def test_citation_date_rejects_an_impossible_day_and_never_normalises_a_valid_one() -> None:
    """`Date.parse('2026-02-30')` succeeds in JavaScript and silently becomes March 2.

    The regex alone accepts it; the round-trip equality is what catches it.
    """
    assert not parses(set_at(wire_seed(), ("research", 0, "citationsAsOf"), "2026-02-30"))
    assert not parses(set_at(wire_seed(), ("research", 0, "citationsAsOf"), "2026-1-01"))
    kept = ContentDocument.model_validate(
        set_at(wire_seed(), ("research", 0, "citationsAsOf"), "2024-02-29")
    )
    assert kept.research[0].citations_as_of == "2024-02-29"


def test_scholar_highlights_citations_has_no_digits_refinement() -> None:
    """Two fields named `citations` with different rules -- this one is a plain max-20 string."""
    assert parses(set_at(wire_seed(), ("scholarHighlights", "citations"), "about 104"))
    assert not parses(set_at(wire_seed(), ("research", 0, "citations"), "about 104"))


VERBATIM_MESSAGES: tuple[tuple[tuple[Any, ...], Any, str], ...] = (
    (("photo",), "nope", "Use a full https:// link."),
    (("email",), "nope", "Enter a valid email."),
    (
        ("research", 0, "citations"),
        "x",
        "Use a whole, non-negative citation count, or leave it blank.",
    ),
    (("research", 0, "citationsAsOf"), "2026-02-30", "Use a valid snapshot date."),
    (("research", 0, "title"), "   ", "Add a title before saving."),
    (("copy", "hero", "discover"), "  ", "Add a label."),
    (("copy", "research", "title"), " ", "Add a heading."),
)


@pytest.mark.parametrize(("path", "value", "message"), VERBATIM_MESSAGES, ids=lambda v: str(v))
def test_refinement_message_is_the_source_copy_verbatim(
    path: tuple[Any, ...], value: Any, message: str
) -> None:
    """These sentences are product copy: the owner reads them in the editor's highlighting."""
    reported = [issue["msg"] for issue in errors_for(set_at(wire_seed(), path, value))]
    assert message in reported


def test_trim_runs_before_the_length_checks() -> None:
    """`.trim()` is a transform, not a check: the trimmed value is validated AND stored."""
    parsed = ContentDocument.model_validate(set_at(wire_seed(), ("name",), "  Madhavi  "))
    assert parsed.name == "Madhavi"
    assert not parses(set_at(wire_seed(), ("name",), "   ")), "all-whitespace fails min(1)"
    assert parses(set_at(wire_seed(), ("name",), "  " + "a" * 100 + "  "))


def test_scholar_copy_title_min_length_carries_no_custom_message() -> None:
    """Unlike `section(...)`'s `Add a heading.` -- an asymmetry reproduced, not tidied."""
    reported = [
        issue["msg"] for issue in errors_for(set_at(wire_seed(), ("copy", "scholar", "title"), " "))
    ]
    assert "Add a heading." not in reported
    assert any("at least 1 character" in message for message in reported)


# --------------------------------------------------------------------------------- #
# The wire format
# --------------------------------------------------------------------------------- #


def test_conversion_happens_in_exactly_one_place() -> None:
    """`wire_name` is the whole of it: no `camelCase` in Python, no `snake_case` on the wire."""
    assert wire_name("photo_focal_y") == "photoFocalY"
    assert wire_name("i10_index") == "i10Index"
    assert wire_name("citations_as_of") == "citationsAsOf"
    # A trailing underscore escapes a name Pydantic has already taken.
    assert wire_name("copy_") == "copy"

    dumped = wire_seed()
    assert all("_" not in key for key in dumped)
    assert "copy" in dumped and "copy_" not in dumped
    assert all("_" not in key for key in dumped["scholarHighlights"])
    assert all("_" not in key for key in dumped["research"][0])


def test_python_names_are_snake_case_and_accepted_by_name() -> None:
    item = ContentItem(
        id="x",
        title="t",
        subtitle="",
        description="",
        year="",
        image="",
        image_alt="",
        link="",
        code="",
        dataset="",
        video="",
        featured=False,
        research_topic="general",
        research_ids=[],
    )
    assert item.image_alt == ""
    assert item.model_dump(by_alias=True)["imageAlt"] == ""


def test_serialisation_keeps_an_integer_an_integer() -> None:
    """`float` would put `50.0` on the wire -- and the persisted content IS this JSON."""
    text = serialise(seed_document())
    assert '"photoFocalY":35' in text
    assert '"focalX":50,' in text
    assert "50.0" not in text
    # Compact separators, as `JSON.stringify` produces. Asserted on a known key rather
    # than on the absence of `": "`, which occurs inside a publication title.
    assert text.startswith('{"name":"Madhavi Tripathi","role":"Translational scientist",')


def test_unknown_keys_are_dropped_rather_than_rejected() -> None:
    """`z.object()` strips by default; a model that rejected extras would fail real documents."""
    document = set_at(wire_seed(), ("legacyField",), "whatever")
    parsed = ContentDocument.model_validate(document)
    assert "legacyField" not in parsed.model_dump(by_alias=True)


STRICT_COERCIONS: tuple[tuple[tuple[Any, ...], Any], ...] = (
    (("photoFocalX",), "50"),
    (("photoFocalX",), True),
    (("motion",), 1),
    (("motion",), "true"),
    (("name",), 5),
    (("research",), {}),
    (("scholarHighlights",), []),
)


@pytest.mark.parametrize(("path", "value"), STRICT_COERCIONS, ids=lambda v: str(v))
def test_no_value_is_coerced_across_a_type(path: tuple[Any, ...], value: Any) -> None:
    """zod coerces nothing. A lax port is MORE permissive than the system it preserves."""
    assert not parses(set_at(wire_seed(), path, value))


def test_instant_wire_format_matches_the_recorded_timestamps() -> None:
    """Three fractional digits and a literal `Z` -- `Date.toISOString()`, not `isoformat()`."""
    from datetime import UTC, datetime, timedelta, timezone

    recorded = json.loads(body("F3-content-owner"))["updatedAt"]
    assert recorded == "2026-09-25T03:12:29.956Z"
    moment = datetime(2026, 9, 25, 3, 12, 29, 956_000, tzinfo=UTC)
    assert instant_to_wire(moment) == recorded
    offset = moment.astimezone(timezone(timedelta(hours=5, minutes=30)))
    assert instant_to_wire(offset) == recorded, "an offset is normalised to Z, not carried"
