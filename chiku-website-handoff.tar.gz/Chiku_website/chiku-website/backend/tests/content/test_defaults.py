"""HAZARD -- the content-carrying defaults (FR9.2, BR9.1-BR9.3), branch by branch.

**A Pydantic model declaring `research_topic: Topic | None = None` is type-correct and
behaviourally wrong.** It produces `None` where the original produces a real topic, and
`[]` where the original produces the seeded editorial links. Nothing errors, nothing logs,
and a port that gets this wrong passes `ruff`, `mypy --strict` and the end-to-end flow
while rendering three identical slate research cards, a publications filter that returns
nothing for every theme, and zero related papers on every card.

The oracle is the recorded `F3-content-owner` document, which is the serialised shape
**with these defaults already resolved** -- so the expected values below are read off the
running source rather than chosen here.

**The branch this file exists for is `test_an_explicitly_emptied_list_stays_empty`.** The
operator is `??`, not `||`: absence triggers the map, a present-but-empty list does not.
A falsy-test port resurrects links the owner deliberately deleted, and does so on **every
read**, so the owner cannot clear them at all.
"""

from __future__ import annotations

from typing import Any

import pytest
from pydantic import ValidationError

from app.content import defaults
from app.content.schema import ContentDocument, ContentItem, serialise
from app.content.seed import seed_document
from app.content.store import ContentState, ContentStore
from content.conftest import EXPECTED_RETENTION, at, blank_item, recorded_document, wire_seed

pytestmark = pytest.mark.anyio

# Read off the recording, not chosen here: these are the values the running source served.
RECORDED_TOPICS = {item["id"]: item["researchTopic"] for item in recorded_document()["research"]}
RECORDED_LINKS = {item["id"]: item["researchIds"] for item in recorded_document()["publications"]}


def without_identity(item_id: str) -> dict[str, Any]:
    """An item as a stored document actually holds it: no topic, no links.

    `researchTopic` and `researchIds` were both added **after** the original cards and
    publications were published, which is why a stored document has neither and why the
    maps exist at all.
    """
    row = blank_item(item_id)
    del row["researchTopic"]
    del row["researchIds"]
    return row


def parse_item(row: dict[str, Any]) -> ContentItem:
    return ContentItem.model_validate(row)


# --------------------------------------------------------------------------------- #
# BR9.1 -- `researchTopic` resolves through the id map, and otherwise to `general`
# --------------------------------------------------------------------------------- #


@pytest.mark.parametrize(
    ("item_id", "topic"),
    [
        ("nano-materials", "materials"),
        ("ultrasound-imaging", "ultrasound"),
        ("photoacoustics", "photoacoustic"),
    ],
)
async def test_an_absent_research_topic_resolves_through_the_id_map(
    item_id: str, topic: str
) -> None:
    """Each of the three legacy cards acquires its own identity, not a shared fallback."""
    assert RECORDED_TOPICS[item_id] == topic, "the recording is the oracle"
    assert parse_item(without_identity(item_id)).research_topic == topic


async def test_an_absent_research_topic_not_in_the_map_resolves_to_general() -> None:
    """`general` is the FLOOR, reached only after the map misses."""
    assert parse_item(without_identity("something-the-owner-added")).research_topic == "general"


async def test_an_explicit_research_topic_wins_over_the_map() -> None:
    """The operator is `??`, not `||`: a stored explicit value wins. Test ABSENCE, never truth."""
    row = blank_item("nano-materials")
    row["researchTopic"] = "general"
    assert parse_item(row).research_topic == "general"


async def test_the_id_to_topic_map_holds_exactly_the_three_recorded_entries() -> None:
    assert dict(defaults.ORIGINAL_TOPICS) == {
        "nano-materials": "materials",
        "ultrasound-imaging": "ultrasound",
        "photoacoustics": "photoacoustic",
    }
    assert dict(defaults.ORIGINAL_TOPICS) == RECORDED_TOPICS
    assert defaults.FALLBACK_TOPIC == "general"


async def test_topic_resolution_tolerates_an_absent_or_non_string_id() -> None:
    """A document whose item has no usable `id` still resolves to the floor, never raises."""
    assert defaults.topic_for_id(None) == "general"
    assert defaults.topic_for_id(5) == "general"
    assert defaults.topic_for_id("nano-materials") == "materials"


# --------------------------------------------------------------------------------- #
# BR9.1 / BR9.3 -- `researchIds` resolves through the seeded map, and an emptied list stays
# --------------------------------------------------------------------------------- #


@pytest.mark.parametrize(
    ("item_id", "links"),
    [
        ("breast-imaging-2026", ["photoacoustics"]),
        ("ultrasound-coherence-2025", ["ultrasound-imaging"]),
        ("mucin-cus-2025", ["nano-materials", "photoacoustics"]),
        ("nanoflakes-2024", ["nano-materials"]),
        ("nanohybrids-2023", ["nano-materials", "photoacoustics"]),
    ],
)
async def test_absent_research_links_resolve_through_the_seeded_map(
    item_id: str, links: list[str]
) -> None:
    """The values are research-CARD ids, not topic enum values. Two vocabularies."""
    assert RECORDED_LINKS[item_id] == links, "the recording is the oracle"
    assert parse_item(without_identity(item_id)).research_ids == links


async def test_absent_research_links_not_in_the_map_resolve_to_the_empty_list() -> None:
    assert parse_item(without_identity("something-the-owner-added")).research_ids == []


async def test_an_explicitly_emptied_list_stays_empty() -> None:
    """**The branch a naive "fill if falsy" default breaks.**

    This is not a missing default; it is a silent overwrite of the owner's own deletion,
    re-applied on every read, so the owner cannot make the clearing stick and there is no
    error to report.
    """
    row = blank_item("mucin-cus-2025")
    row["researchIds"] = []
    assert parse_item(row).research_ids == []


async def test_an_explicitly_shortened_list_is_not_topped_up_from_the_map() -> None:
    row = blank_item("mucin-cus-2025")
    row["researchIds"] = ["nano-materials"]
    assert parse_item(row).research_ids == ["nano-materials"]


async def test_the_seeded_link_map_holds_exactly_the_five_recorded_entries() -> None:
    assert {key: list(value) for key, value in defaults.INITIAL_RESEARCH_LINKS.items()} == {
        "breast-imaging-2026": ["photoacoustics"],
        "ultrasound-coherence-2025": ["ultrasound-imaging"],
        "mucin-cus-2025": ["nano-materials", "photoacoustics"],
        "nanoflakes-2024": ["nano-materials"],
        "nanohybrids-2023": ["nano-materials", "photoacoustics"],
    }
    assert {key: list(value) for key, value in defaults.INITIAL_RESEARCH_LINKS.items()} == {
        key: value for key, value in RECORDED_LINKS.items() if value
    }


async def test_link_resolution_returns_a_fresh_list_and_tolerates_a_non_string_id() -> None:
    """A shared list would let one item's edit reach another's links."""
    assert defaults.links_for_id(None) == []
    assert defaults.links_for_id(7) == []
    first = defaults.links_for_id("mucin-cus-2025")
    second = defaults.links_for_id("mucin-cus-2025")
    assert first == second
    first.append("intruder")
    assert defaults.links_for_id("mucin-cus-2025") == second


# --------------------------------------------------------------------------------- #
# BR9.2 -- this is LOGIC, and it runs on EVERY PARSE, which includes every read
# --------------------------------------------------------------------------------- #


async def test_the_transform_is_applied_by_the_raw_row_helper() -> None:
    """The helper works on the raw row, before field validation, so absence is visible."""
    resolved = defaults.apply_content_carrying_defaults(without_identity("nano-materials"))
    assert resolved["researchTopic"] == "materials"
    assert resolved["researchIds"] == []
    assert "researchTopic" not in without_identity("nano-materials")


async def test_the_helper_accepts_the_python_spelling_as_well_as_the_wire_spelling() -> None:
    """A model may be built from Python names, and absence must still be visible there."""
    row = without_identity("mucin-cus-2025")
    row["research_topic"] = "ultrasound"
    row["research_ids"] = []
    resolved = defaults.apply_content_carrying_defaults(row)
    assert resolved["research_topic"] == "ultrasound"
    assert resolved["research_ids"] == []
    assert "researchTopic" not in resolved
    assert "researchIds" not in resolved


async def test_the_helper_does_not_mutate_the_row_it_was_given() -> None:
    row = without_identity("nano-materials")
    defaults.apply_content_carrying_defaults(row)
    assert "researchTopic" not in row


async def test_the_defaults_run_on_the_read_path_every_time_and_change_nothing_stored(
    store_factory: Any,
) -> None:
    """The stored document keeps neither field; every read resolves them afresh.

    A port that materialised the transform on the **write** path instead would leave every
    pre-existing stored document rendering wrong forever -- and this assertion, which reads
    the same stored bytes twice and then checks the bytes, is what separates the two.
    """
    store: ContentStore = store_factory()
    legacy = wire_seed()
    legacy["research"] = [without_identity("nano-materials")]
    legacy["publications"] = [without_identity("mucin-cus-2025")]
    # Stored as a raw payload: the store validates nothing and defaults nothing.
    import json

    payload = json.dumps(legacy, ensure_ascii=False, separators=(",", ":"))
    # Routed through a named local: a string literal at a keyword whose name contains
    # `token` is what the hardcoded-credential rule looks for, and the conformance suite
    # already takes this route rather than suppressing it per call site.
    marker = "legacy-write"
    committed = await store.commit(
        content=payload,
        base_revision=0,
        action="draft",
        mutation_token=marker,
        retention=EXPECTED_RETENTION,
        now=at(1),
    )
    assert isinstance(committed, ContentState)

    for _ in range(2):
        state = await store.read_state()
        parsed = ContentDocument.model_validate(json.loads(state.draft))
        assert parsed.research[0].research_topic == "materials"
        assert parsed.publications[0].research_ids == ["nano-materials", "photoacoustics"]
        assert "researchTopic" not in json.loads(state.draft)["research"][0]

    final = await store.read_state()
    assert final.draft == payload, "a read writes nothing and transforms nothing in storage"


# --------------------------------------------------------------------------------- #
# The seed is exactly the case that needs the shims
# --------------------------------------------------------------------------------- #


async def test_the_seeds_materialised_identities_agree_with_the_maps() -> None:
    """The source materialises these at construction; the maps must say the same thing.

    Two transcriptions of one fact -- the seed's literal values and the two maps -- and
    this is the assertion that keeps them from drifting apart.
    """
    document = seed_document()
    for item in (*document.research, *document.publications, *document.achievements):
        assert item.research_topic == defaults.topic_for_id(item.id), item.id
        assert item.research_ids == defaults.links_for_id(item.id), item.id


async def test_a_seed_stripped_of_its_identities_reparses_to_the_same_document() -> None:
    """A fresh install depends entirely on the maps, which is W-1 and W-2's closing note."""
    stripped = wire_seed()
    for collection in ("achievements", "research", "publications", "journey", "news"):
        for row in stripped[collection]:
            del row["researchTopic"]
            del row["researchIds"]
    assert ContentDocument.model_validate(stripped) == seed_document()
    assert serialise(ContentDocument.model_validate(stripped)) == serialise(seed_document())


async def test_a_present_but_invalid_topic_still_fails_validation() -> None:
    """The transform supplies an absent value; it never repairs a wrong one."""
    row = blank_item("nano-materials")
    row["researchTopic"] = "bogus"
    with pytest.raises(ValidationError) as raised:
        parse_item(row)
    assert raised.value.errors()[0]["type"] == "literal_error"
