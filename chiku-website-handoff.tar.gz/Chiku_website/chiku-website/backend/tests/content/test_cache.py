"""The published-document cache, tested as the SECURITY parameter it is (BR7.1, BR7.2, BR24.x).

**A stale entry is an authorization defect, not a slow page.** The cache feeds the
asset-visibility test -- an asset is public **iff its literal media URL appears anywhere in
the serialised published document** -- so a stale entry means an asset the owner has just
unreferenced **stays public** for the remaining lifetime of the entry. It is not a stale
render and not an inconsistency a refresh fixes: it is content the owner believes they have
made private, being served to anyone holding the URL.

ADR-002 records that the invalidation path needs **its own test**, and the reason is worth
repeating: **a test that measures cache hits passes whether or not the invalidation
exists.** So the assertions below are about the authorization consequence, not about hit
rates.

The public read **does not exist in the source** -- verified by execution, it returns 404
there -- so it has **no parity fixture**, and BR24.3's prohibition on draft content in a
public response has to be checked against itself rather than against a recording.
"""

from __future__ import annotations

import json
from collections.abc import Callable
from datetime import datetime
from typing import Any

import pytest

from app.content.authority import ContentAuthority
from app.content.cache import MAX_CACHE_INTERVAL_SECONDS, PublishedDocumentCache
from app.content.store import (
    Action,
    AssetMetadataRecord,
    CommitResult,
    ContentState,
    ContentStore,
    RetentionPolicy,
    RevisionEntry,
    RevisionSummary,
)
from content.conftest import EXPECTED_RETENTION, at, wire_seed

pytestmark = pytest.mark.anyio

MEDIA_URL = "/api/media/558fe673-2562-492b-b383-235dc74058c3.webp"


class CountingStore:
    """A real `ContentStore` with a read counter in front of it.

    **Not a mock.** Every call is delegated to a real implementation and every answer is
    the store's own; the counter observes a boundary that is invisible from the returned
    value, exactly as the conformance suite's transfer spy does. "Which requests hit
    storage" is the property BR7.2 is about, and it cannot be asserted any other way.
    """

    def __init__(self, inner: ContentStore) -> None:
        self._inner = inner
        self.reads = 0

    async def read_state(self) -> ContentState:
        self.reads += 1
        return await self._inner.read_state()

    async def commit(
        self,
        *,
        content: str,
        base_revision: int,
        action: Action,
        mutation_token: str,
        retention: RetentionPolicy,
        now: datetime,
    ) -> CommitResult:
        return await self._inner.commit(
            content=content,
            base_revision=base_revision,
            action=action,
            mutation_token=mutation_token,
            retention=retention,
            now=now,
        )

    async def list_revisions(self) -> list[RevisionSummary]:
        return await self._inner.list_revisions()

    async def read_revision(self, revision_id: str) -> RevisionEntry | None:
        return await self._inner.read_revision(revision_id)

    async def asset_metadata_register(self, record: AssetMetadataRecord) -> None:
        await self._inner.asset_metadata_register(record)

    async def asset_metadata_read(self, key: str) -> AssetMetadataRecord | None:
        return await self._inner.asset_metadata_read(key)

    async def asset_metadata_remove(self, key: str) -> None:
        await self._inner.asset_metadata_remove(key)


def save_body(document: dict[str, Any], revision: int, action: str) -> str:
    payload = {"content": document, "revision": revision, "action": action}
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


def referencing(url: str) -> dict[str, Any]:
    document = wire_seed()
    document["photoSources"] = [{"src": url, "width": 1536, "height": 1024}]
    return document


# --------------------------------------------------------------------------------- #
# BR24.1 -- the interval is a stated MAXIMUM, not a default
# --------------------------------------------------------------------------------- #


def test_the_interval_maximum_is_five_seconds() -> None:
    """Bounded above by exposure and below by the hard zero-recurring-cost target.

    Above: the cache is in-process, so a publish invalidates **only the instance that
    served it**; every other warm instance keeps serving its own document until its entry
    expires, which makes the interval the real exposure window rather than a backstop.
    Below: one read per interval per warm instance is `86,400 / interval` reads per
    instance-day -- 17,280 at five seconds, which leaves room for two warm instances
    inside the 50,000/day free tier, against 86,400 at one second.
    """
    assert MAX_CACHE_INTERVAL_SECONDS == 5.0
    assert PublishedDocumentCache().interval_seconds == MAX_CACHE_INTERVAL_SECONDS


@pytest.mark.parametrize("interval", [5.001, 6, 30, 3600])
def test_an_interval_above_the_maximum_is_refused(interval: float) -> None:
    """A deployment may choose lower, **never higher**, and the refusal is at construction.

    Fail at boot, not at first request: a value that was accepted and then quietly clamped
    would leave the operator believing a number that is not in force.
    """
    with pytest.raises(ValueError, match="5"):
        PublishedDocumentCache(interval_seconds=interval)


@pytest.mark.parametrize("interval", [0, 0.5, 1, 5])
def test_an_interval_at_or_below_the_maximum_is_accepted(interval: float) -> None:
    assert PublishedDocumentCache(interval_seconds=interval).interval_seconds == interval


def test_a_negative_interval_is_refused() -> None:
    with pytest.raises(ValueError, match="negative"):
        PublishedDocumentCache(interval_seconds=-1)


# --------------------------------------------------------------------------------- #
# The cache itself -- exactly one entry, no key
# --------------------------------------------------------------------------------- #


def test_the_cache_holds_exactly_one_entry_and_is_not_keyed() -> None:
    """One entry is what makes BR24.2's invalidation unconditional and needs no key."""
    cache = PublishedDocumentCache()
    assert cache.read(at(0)) is None
    cache.store("first", at(0))
    assert cache.read(at(0)) == "first"
    cache.store("second", at(0))
    assert cache.read(at(0)) == "second", "a second document replaces the first"
    cache.invalidate()
    assert cache.read(at(0)) is None
    # Invalidating an empty cache is a success, not an error: the obligation is that
    # nothing stale survives, and there is nothing to report if nothing was there.
    cache.invalidate()
    assert cache.read(at(0)) is None


def test_an_entry_expires_when_the_interval_has_elapsed() -> None:
    """Time is injected; the interval is exercised without sleeping."""
    cache = PublishedDocumentCache(interval_seconds=5)
    cache.store("payload", at(0))
    assert cache.read(at(4)) == "payload"
    assert cache.read(at(5)) is None, "the interval is exclusive at its own boundary"
    assert cache.read(at(6)) is None


def test_a_zero_interval_caches_nothing() -> None:
    cache = PublishedDocumentCache(interval_seconds=0)
    cache.store("payload", at(0))
    assert cache.read(at(0)) is None


# --------------------------------------------------------------------------------- #
# BR7.2 -- the cache changes WHICH REQUESTS HIT STORAGE, never WHICH ASSETS ARE PUBLIC
# --------------------------------------------------------------------------------- #


async def test_a_cached_read_reaches_storage_once_per_interval_and_answers_identically(
    store_factory: Callable[[], ContentStore],
) -> None:
    counting = CountingStore(store_factory())
    authority = ContentAuthority(counting, retention=EXPECTED_RETENTION)

    first = await authority.published_payload(now=at(0))
    second = await authority.published_payload(now=at(4))
    assert counting.reads == 1
    assert second == first, "the cache may change which requests reach storage, never the answer"

    third = await authority.published_payload(now=at(5))
    assert counting.reads == 2
    assert third == first


# --------------------------------------------------------------------------------- #
# BR24.2 -- a successful publish invalidates SYNCHRONOUSLY, before the operation returns
# --------------------------------------------------------------------------------- #


async def test_an_asset_the_owner_unreferences_stops_being_public_on_the_next_request(
    store_factory: Callable[[], ContentStore],
) -> None:
    """**The authorization consequence, which is what this test has to assert.**

    A test that measured cache hits would pass with the invalidation missing. This one
    fails: without it the publishing instance itself keeps serving the previous document
    for the whole interval, which turns BR24.1's bound from a residual exposure into the
    normal one.
    """
    authority = ContentAuthority(store_factory(), retention=EXPECTED_RETENTION)
    await authority.save(body=save_body(referencing(MEDIA_URL), 0, "publish"), now=at(0))

    public = await authority.published_payload(now=at(0))
    assert MEDIA_URL in public, "the asset is public while the published document names it"

    without = wire_seed()
    without["photoSources"] = []
    await authority.save(body=save_body(without, 1, "publish"), now=at(1))

    # Same instant: still well inside the interval, so only a synchronous invalidation
    # can have produced the new document.
    assert MEDIA_URL not in await authority.published_payload(now=at(1))


async def test_a_draft_save_does_not_invalidate_the_cache(
    store_factory: Callable[[], ContentStore],
) -> None:
    """Only a *publish* changes the published document, so only a publish invalidates."""
    counting = CountingStore(store_factory())
    authority = ContentAuthority(counting, retention=EXPECTED_RETENTION)
    await authority.save(body=save_body(referencing(MEDIA_URL), 0, "publish"), now=at(0))
    await authority.published_payload(now=at(0))
    reads = counting.reads

    edited = wire_seed()
    edited["name"] = "Draft only"
    await authority.save(body=save_body(edited, 1, "draft"), now=at(1))

    assert MEDIA_URL in await authority.published_payload(now=at(1))
    assert counting.reads == reads, "the entry was still valid, and a draft did not clear it"


async def test_a_conflicting_publish_does_not_invalidate_the_cache(
    store_factory: Callable[[], ContentStore],
) -> None:
    """Invalidation belongs to a **successful** publish, inside the operation that succeeded."""
    from app import errors

    counting = CountingStore(store_factory())
    authority = ContentAuthority(counting, retention=EXPECTED_RETENTION)
    await authority.save(body=save_body(referencing(MEDIA_URL), 0, "publish"), now=at(0))
    await authority.published_payload(now=at(0))
    reads = counting.reads

    without = wire_seed()
    without["photoSources"] = []
    with pytest.raises(errors.Conflict):
        await authority.save(body=save_body(without, 0, "publish"), now=at(1))

    assert MEDIA_URL in await authority.published_payload(now=at(1))
    # The conflict path reads the current state to report it; the cached entry is intact.
    assert counting.reads == reads + 1


# --------------------------------------------------------------------------------- #
# BR24.3 -- no draft content in any public response, in any field, at any time (NFR11)
# --------------------------------------------------------------------------------- #


async def test_no_draft_content_appears_in_a_public_response_in_any_field(
    store_factory: Callable[[], ContentStore],
) -> None:
    """Checked by its own test: the public route 404s in the source, so no fixture can.

    The draft below differs from the published document in a top-level string, a nested
    copy leaf, an item and a media reference, so a leak through any of those surfaces here
    rather than in production.
    """
    authority = ContentAuthority(store_factory(), retention=EXPECTED_RETENTION)
    published = referencing(MEDIA_URL)
    published["name"] = "Published name"
    await authority.save(body=save_body(published, 0, "publish"), now=at(0))

    draft = wire_seed()
    draft["name"] = "UNPUBLISHED-NAME"
    draft["notice"] = "UNPUBLISHED-NOTICE"
    draft["copy"]["hero"]["discover"] = "UNPUBLISHED-COPY"
    draft["research"][0]["title"] = "UNPUBLISHED-TITLE"
    draft["photoSources"] = [{"src": "/api/media/unpublished-asset.webp", "width": 1, "height": 1}]
    await authority.save(body=save_body(draft, 1, "draft"), now=at(1))

    payload = await authority.published_payload(now=at(2))
    for secret in (
        "UNPUBLISHED-NAME",
        "UNPUBLISHED-NOTICE",
        "UNPUBLISHED-COPY",
        "UNPUBLISHED-TITLE",
        "unpublished-asset",
    ):
        assert secret not in payload, secret
    assert "Published name" in payload


async def test_a_public_response_carries_the_document_and_no_owner_metadata(
    store_factory: Callable[[], ContentStore],
) -> None:
    """The draft form, the revision history and the change flag are owner-only."""
    authority = ContentAuthority(store_factory(), retention=EXPECTED_RETENTION)
    await authority.save(body=save_body(wire_seed(), 0, "publish"), now=at(0))

    payload = json.loads(await authority.published_payload(now=at(0)))
    assert len(payload) == 31
    for owner_only in ("draft", "published", "revision", "updatedAt", "hasUnpublishedChanges"):
        assert owner_only not in payload, owner_only

    document = await authority.read_published(now=at(0))
    assert not hasattr(document, "revision")
    assert not hasattr(document, "has_unpublished_changes")


async def test_the_public_read_resolves_the_content_carrying_defaults(
    store_factory: Callable[[], ContentStore],
) -> None:
    """BR9.2 reaches the public path too: the transform runs on every parse, not on writes."""
    authority = ContentAuthority(store_factory(), retention=EXPECTED_RETENTION)
    document = wire_seed()
    del document["research"][0]["researchTopic"]
    del document["publications"][0]["researchIds"]
    await authority.save(body=save_body(document, 0, "publish"), now=at(0))

    public = await authority.read_published(now=at(0))
    assert public.research[0].research_topic == "materials"
    assert public.publications[0].research_ids == ["photoacoustics"]


async def test_a_public_read_on_a_fresh_install_serves_the_seed_and_writes_nothing(
    store_factory: Callable[[], ContentStore],
) -> None:
    """BR4.1 holds on the public path as well: a read never bootstraps."""
    store = store_factory()
    authority = ContentAuthority(store, retention=EXPECTED_RETENTION)
    public = await authority.read_published(now=at(0))
    assert public.name == "Madhavi Tripathi"
    state = await store.read_state()
    assert state.revision == 0
    assert state.updated_at is None
