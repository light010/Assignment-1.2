"""`tests/content` is a package.

Without this marker pytest's prepend import mode gives this directory's `conftest` the
same top-level module name as `tests/conftest.py`, and the pre-existing suites'
`from conftest import meta` then resolves to the wrong file. `tests/conformance` and
`tests/cloud` carry one for the same reason.
"""
