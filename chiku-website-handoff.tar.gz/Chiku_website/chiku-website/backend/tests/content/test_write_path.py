"""HAZARD -- the combined write and its ABA side-effect guard (FR4.5, BR4.8-BR4.19).

The single highest-risk behaviour in the system. **Nothing here errors when it is wrong.**
The history list grows a row the owner never saved, or loses a row it should have kept;
it is invisible to single-user testing, invisible to a coverage percentage, and only
reproducible by two writers holding the same base revision.

So the concurrent cases below are **genuinely concurrent** -- two tasks, one storage --
and never a simulated interleaving. Both real `ContentStore` implementations are exercised;
neither is mocked.

The 409 envelope and the four `400` shapes are asserted against the recorded fixtures
`F5-conflict-stale-revision` and `F12-*`, which are what the ported editor branches on.
"""

from __future__ import annotations

import contextlib
import json
from collections.abc import Callable
from typing import Any

import anyio
import pytest
from conftest import body as recorded_body
from pydantic import ValidationError

from app import errors
from app.content.authority import ContentAuthority
from app.content.limits import MAX_BODY_UTF16_UNITS
from app.content.schema import ContentDocument, serialise
from app.content.statements import CombinedWrite, combined_write, mint_mutation_token
from app.content.store import (
    BASELINE_DRAFT_ID,
    BASELINE_PUBLISHED_ID,
    ContentState,
    ContentStore,
    RetentionPolicy,
)
from content.conftest import EXPECTED_RETENTION, at, wire_seed

pytestmark = pytest.mark.anyio

MAX_SAFE_INTEGER = 9_007_199_254_740_991


def save_body(document: Any, revision: Any, action: str, **extra: Any) -> str:
    payload = {"content": document, "revision": revision, "action": action, **extra}
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


def authority(store: ContentStore, *, retention: RetentionPolicy = EXPECTED_RETENTION) -> Any:
    return ContentAuthority(store, retention=retention)


def tighter(*, drafts: int, publishes: int) -> RetentionPolicy:
    """The same policy with smaller counts. Retention is an argument, never a constant."""
    return RetentionPolicy(
        draft_keep=drafts, publish_keep=publishes, permanent_ids=EXPECTED_RETENTION.permanent_ids
    )


# --------------------------------------------------------------------------------- #
# The check order -- BR10.10, BR10.11, and BR4.22's position for the size cap
# --------------------------------------------------------------------------------- #


async def test_a_body_that_is_both_too_large_and_malformed_is_too_large(
    store_factory: Callable[[], ContentStore],
) -> None:
    """The cap runs AFTER the body is read and BEFORE the parse (BR4.22).

    Moving it after the parse changes which status a too-large malformed body receives --
    a case the owner can reach by pasting.
    """
    oversized = "{" + "a" * MAX_BODY_UTF16_UNITS
    with pytest.raises(errors.TooLarge) as raised:
        await authority(store_factory()).save(body=oversized, now=at(1))
    assert raised.value.message == errors.TOO_LARGE


async def test_the_cap_counts_utf16_units_so_an_astral_body_is_refused_below_its_byte_size(
    store_factory: Callable[[], ContentStore],
) -> None:
    """One astral codepoint is TWO units. The recorded `F6` boundary is in units, not bytes."""
    unit = "\N{GRINNING FACE}"
    at_limit = unit * (MAX_BODY_UTF16_UNITS // 2)
    over_limit = at_limit + unit
    assert len(over_limit) * 2 == MAX_BODY_UTF16_UNITS + 2
    with pytest.raises(errors.TooLarge):
        await authority(store_factory()).save(body=over_limit, now=at(1))
    # At the limit the cap does not fire, so the JSON parse is what refuses it.
    with pytest.raises(errors.Invalid) as raised:
        await authority(store_factory()).save(body=at_limit, now=at(1))
    assert raised.value.message == errors.UNREADABLE_UPDATE


async def test_content_validation_runs_before_envelope_validation(
    store_factory: Callable[[], ContentStore],
) -> None:
    """BR10.11. A doubly-invalid request returns the CONTENT error, the one that highlights.

    Reordering these two silently changes what the editor shows: field highlighting on one,
    a bare sentence on the other.
    """
    broken = wire_seed()
    broken["accent"] = "teal"
    with pytest.raises(errors.Invalid) as raised:
        await authority(store_factory()).save(body=save_body(broken, -1, "draft"), now=at(1))
    assert raised.value.message == errors.CHECK_FIELDS
    assert raised.value.extra["issues"], "the content error carries per-field issues"


async def test_a_validation_failure_carries_path_and_message_not_loc_and_msg(
    store_factory: Callable[[], ContentStore],
) -> None:
    """BR10.2, and the shape `F12-schema-invalid` records. `loc`/`msg` break highlighting."""
    broken = wire_seed()
    broken["research"][0]["title"] = "   "
    with pytest.raises(errors.Invalid) as raised:
        await authority(store_factory()).save(body=save_body(broken, 0, "draft"), now=at(1))
    issues = raised.value.extra["issues"]
    assert issues == [{"path": ["research", 0, "title"], "message": "Add a title before saving."}]

    recorded = json.loads(recorded_body("F12-schema-invalid"))
    assert set(recorded["issues"][0]) == {"path", "message"}
    assert recorded["error"] == errors.CHECK_FIELDS


ENVELOPE_REJECTIONS: tuple[tuple[str, Any, str, dict[str, Any]], ...] = (
    ("negative revision", -1, "draft", {}),
    ("non-integer revision", 1.5, "draft", {}),
    ("boolean revision", True, "draft", {}),
    ("string revision", "0", "draft", {}),
    ("revision at MAX_SAFE_INTEGER", MAX_SAFE_INTEGER, "draft", {}),
    ("unknown action", 0, "archive", {}),
    ("non-boolean autosave", 0, "draft", {"autosave": "yes"}),
    ("autosave on a publish", 0, "publish", {"autosave": True}),
)


@pytest.mark.parametrize(
    ("label", "revision", "action", "extra"), ENVELOPE_REJECTIONS, ids=lambda v: str(v)
)
async def test_envelope_validation_is_one_predicate(
    store_factory: Callable[[], ContentStore],
    label: str,
    revision: Any,
    action: str,
    extra: dict[str, Any],
) -> None:
    """BR10.12, including autosave being legal only with a draft action."""
    request = save_body(wire_seed(), revision, action, **extra)
    with pytest.raises(errors.Invalid) as raised:
        await authority(store_factory()).save(body=request, now=at(1))
    assert raised.value.message == errors.INVALID_SAVE, label
    assert "issues" not in raised.value.extra, "the envelope 400 carries no issues"


async def test_an_integral_float_revision_is_accepted_as_javascript_accepts_it(
    store_factory: Callable[[], ContentStore],
) -> None:
    """`Number.isSafeInteger(0.0)` is true: `0.0` and `0` are one value in the source."""
    outcome = await authority(store_factory()).save(
        body=save_body(wire_seed(), 0.0, "draft"), now=at(1)
    )
    assert outcome.revision == 1


async def test_autosave_is_legal_with_a_draft_action(
    store_factory: Callable[[], ContentStore],
) -> None:
    outcome = await authority(store_factory()).save(
        body=save_body(wire_seed(), 0, "draft", autosave=True), now=at(1)
    )
    assert outcome.revision == 1


PARSE_REJECTIONS: tuple[tuple[str, str, str], ...] = (
    ("unparseable JSON", "{not json", errors.UNREADABLE_UPDATE),
    ("an array body", "[]", errors.INVALID_SAVE),
    ("a null body", "null", errors.INVALID_SAVE),
    ("a string body", '"hello"', errors.INVALID_SAVE),
    ("a numeric body", "0", errors.INVALID_SAVE),
)


@pytest.mark.parametrize(("label", "raw", "message"), PARSE_REJECTIONS, ids=lambda v: str(v))
async def test_a_parse_failure_is_distinct_from_a_shape_failure(
    store_factory: Callable[[], ContentStore], label: str, raw: str, message: str
) -> None:
    with pytest.raises(errors.Invalid) as raised:
        await authority(store_factory()).save(body=raw, now=at(1))
    assert raised.value.message == message, label

    assert json.loads(recorded_body("F12-bad-json"))["error"] == errors.UNREADABLE_UPDATE
    assert json.loads(recorded_body("F12-array-body"))["error"] == errors.INVALID_SAVE


# --------------------------------------------------------------------------------- #
# The six effects -- BR4.8-BR4.12, BR4.16
# --------------------------------------------------------------------------------- #


async def test_a_first_write_bootstraps_the_document_and_captures_both_baselines(
    store_factory: Callable[[], ContentStore],
) -> None:
    """BR4.8 and BR4.9: the baselines capture the state BEFORE this write, once ever."""
    store = store_factory()
    edited = wire_seed()
    edited["name"] = "Edited"
    await authority(store).save(body=save_body(edited, 0, "draft"), now=at(1))

    entries = {entry.id: entry for entry in await store.list_revisions()}
    assert BASELINE_PUBLISHED_ID in entries
    assert BASELINE_DRAFT_ID in entries
    assert entries[BASELINE_PUBLISHED_ID].baseline is True
    assert entries[BASELINE_PUBLISHED_ID].revision == 0
    assert entries[BASELINE_PUBLISHED_ID].action == "publish"
    assert entries[BASELINE_DRAFT_ID].action == "draft"

    captured = await store.read_revision(BASELINE_DRAFT_ID)
    assert captured is not None
    assert json.loads(captured.content)["name"] == "Madhavi Tripathi", "the PRE-EXISTING content"
    assert captured.created_at == at(1), "the time of CAPTURE, not a guessed publication date"

    # Once ever: a second write does not recapture.
    await authority(store).save(body=save_body(edited, 1, "draft"), now=at(2))
    again = await store.read_revision(BASELINE_DRAFT_ID)
    assert again is not None
    assert again.created_at == at(1)


async def test_publish_moves_published_and_published_at_while_a_draft_save_moves_neither(
    store_factory: Callable[[], ContentStore],
) -> None:
    """BR4.3, BR4.4, BR4.5: `draft` ALWAYS moves, `published` only on a publish."""
    store = store_factory()
    edited = wire_seed()
    edited["name"] = "Draft only"

    saved = await authority(store).save(body=save_body(edited, 0, "draft"), now=at(1))
    assert saved.revision == 1
    assert saved.published is False
    assert saved.published_at is None, "the seeded document is not published"
    assert saved.has_unpublished_changes is True
    state = await store.read_state()
    assert json.loads(state.draft)["name"] == "Draft only"
    assert json.loads(state.published)["name"] == "Madhavi Tripathi"

    published = await authority(store).save(body=save_body(edited, 1, "publish"), now=at(2))
    assert published.revision == 2, "every accepted write increments, drafts as well"
    assert published.published is True
    assert published.published_at is not None
    assert published.has_unpublished_changes is False
    after = await store.read_state()
    assert json.loads(after.published)["name"] == "Draft only"
    assert json.loads(after.draft)["name"] == "Draft only"


async def test_the_history_entry_content_is_read_back_from_the_stored_draft(
    store_factory: Callable[[], ContentStore],
) -> None:
    """BR4.11. The entry is byte-identical to what the CAS wrote, not to what was sent.

    The payload below is one the schema **transforms**: a padded citation count is trimmed
    and an absent `copy` block is filled from 25 leaf defaults, so the request and the
    stored document genuinely differ -- which, given the item transform, is most of the time.
    """
    store = store_factory()
    sent = wire_seed()
    sent["research"][0]["citations"] = "  104  "
    del sent["copy"]
    del sent["research"][0]["researchTopic"]
    request = save_body(sent, 0, "draft")

    await authority(store).save(body=request, now=at(1))

    state = await store.read_state()
    entry = next(e for e in await store.list_revisions() if not e.baseline)
    stored = await store.read_revision(entry.id)
    assert stored is not None
    assert stored.content == state.draft
    assert json.loads(stored.content)["research"][0]["citations"] == "104"
    assert json.loads(stored.content)["research"][0]["researchTopic"] == "materials"
    assert json.loads(stored.content) != json.loads(request)["content"]
    assert stored.created_at == state.updated_at, "read back from the document's updatedAt"
    assert stored.revision == state.revision
    assert stored.baseline is False


async def test_the_compare_and_set_outcome_is_read_by_name(
    store_factory: Callable[[], ContentStore],
) -> None:
    """BR4.17. A positional read that drifts returns nothing, which reads as a CONFLICT.

    The failure looks like contention, not like a bug -- so the assertion is that a write
    at the correct base revision returns each named column's value, never a conflict.
    """
    store = store_factory()
    edited = wire_seed()
    edited["name"] = "By name"
    outcome = await authority(store).save(body=save_body(edited, 0, "publish"), now=at(5))
    assert outcome.revision == 1
    assert outcome.updated_at == "2026-09-25T12:00:05.000Z"
    assert outcome.published_at == "2026-09-25T12:00:05.000Z"

    # Routed through a named local, as the conformance suite does: a string literal at a
    # keyword whose name contains `token` is what the hardcoded-credential rule looks for.
    marker = "second-write"
    raw = await store.commit(
        content=serialise(ContentDocument.model_validate(edited)),
        base_revision=1,
        action="draft",
        mutation_token=marker,
        retention=EXPECTED_RETENTION,
        now=at(6),
    )
    assert isinstance(raw, ContentState), "a matching base revision is never a conflict"
    assert raw.revision == 2
    assert raw.updated_at == at(6)
    assert raw.published_at == at(5), "published_at is its own column and did not move"


async def test_a_stale_base_revision_raises_conflict_carrying_the_current_state(
    store_factory: Callable[[], ContentStore],
) -> None:
    """BR4.7, asserted against the recorded 409 the editor branches on."""
    store = store_factory()
    edited = wire_seed()
    edited["name"] = "First"
    await authority(store).save(body=save_body(edited, 0, "draft"), now=at(1))

    stale = wire_seed()
    stale["name"] = "Second"
    with pytest.raises(errors.Conflict) as raised:
        await authority(store).save(body=save_body(stale, 0, "draft"), now=at(2))

    recorded = json.loads(recorded_body("F5-conflict-stale-revision"))
    assert raised.value.message == recorded["error"]
    assert set(raised.value.extra) == set(recorded) - {"error"}
    assert raised.value.extra["revision"] == 1
    assert raised.value.extra["hasUnpublishedChanges"] is True

    state = await store.read_state()
    assert json.loads(state.draft)["name"] == "First", "the loser changed nothing"


async def test_a_conflicting_write_performs_no_side_effect(
    store_factory: Callable[[], ContentStore],
) -> None:
    """BR4.16: all six effects commit together or none does. A conflict leaves nothing."""
    store = store_factory()
    edited = wire_seed()
    edited["name"] = "First"
    await authority(store).save(body=save_body(edited, 0, "draft"), now=at(1))
    before = await store.read_state()
    ids_before = {entry.id for entry in await store.list_revisions()}

    with pytest.raises(errors.Conflict):
        await authority(store).save(body=save_body(edited, 0, "publish"), now=at(2))

    after = await store.read_state()
    assert after == before, "no content, no revision and no timestamp moved"
    assert {entry.id for entry in await store.list_revisions()} == ids_before


# --------------------------------------------------------------------------------- #
# The ABA defence -- BR4.13-BR4.15, only reproducible by two concurrent writers
# --------------------------------------------------------------------------------- #


async def test_two_concurrent_writers_leave_exactly_one_history_entry(
    store_factory: Callable[[], ContentStore],
) -> None:
    """The loser's `next_revision` COLLIDES with the winner's `revision`.

    That collision is asserted rather than assumed: without it the scenario this test
    exists for has not been reproduced, and the test would pass against a port with no
    defence at all.
    """
    store = store_factory()
    seeded = wire_seed()
    await authority(store).save(body=save_body(seeded, 0, "draft"), now=at(1))
    base = (await store.read_state()).revision
    entries_before = {entry.id for entry in await store.list_revisions()}

    outcomes: list[str] = []

    async def writer(name: str) -> None:
        document = wire_seed()
        document["name"] = name
        try:
            await authority(store_factory()).save(
                body=save_body(document, base, "draft"), now=at(2)
            )
            outcomes.append(f"{name}:won")
        except errors.Conflict:
            outcomes.append(f"{name}:lost")

    async with anyio.create_task_group() as writers:
        writers.start_soon(writer, "A")
        writers.start_soon(writer, "B")

    assert sorted(outcome.split(":")[1] for outcome in outcomes) == ["lost", "won"]
    state = await store.read_state()
    assert state.revision == base + 1, "the loser's next_revision equals the winner's revision"

    added = {entry.id for entry in await store.list_revisions()} - entries_before
    assert len(added) == 1, "no phantom revision keyed by the loser's token"
    entry = await store.read_revision(next(iter(added)))
    assert entry is not None
    assert entry.content == state.draft, "the one entry carries the winner's own content"


async def test_a_losing_writer_runs_no_retention_prune(
    store_factory: Callable[[], ContentStore],
) -> None:
    """BR4.12, BR4.13: ungated, the loser prunes history off the back of the winner's write.

    The retention counts are tightened so that a second prune would be VISIBLE -- with a
    keep of two, an extra pass would leave one entry rather than two.
    """
    store = store_factory()
    policy = tighter(drafts=2, publishes=20)
    document = wire_seed()
    for revision in range(2):
        document["name"] = f"Draft {revision}"
        await authority(store, retention=policy).save(
            body=save_body(document, revision, "draft"), now=at(revision + 1)
        )

    base = (await store.read_state()).revision
    assert base == 2

    async def writer(name: str) -> None:
        payload = wire_seed()
        payload["name"] = name
        with contextlib.suppress(errors.Conflict):
            await authority(store_factory(), retention=policy).save(
                body=save_body(payload, base, "draft"), now=at(9)
            )

    async with anyio.create_task_group() as writers:
        writers.start_soon(writer, "A")
        writers.start_soon(writer, "B")

    drafts = [e for e in await store.list_revisions() if e.action == "draft" and not e.baseline]
    assert len(drafts) == 2, "the winner pruned once; the loser pruned not at all"
    baselines = [e for e in await store.list_revisions() if e.baseline]
    assert len(baselines) == 2, "baselines are excluded by the predicate, never pruned"


# --------------------------------------------------------------------------------- #
# The pure statement builder -- what makes the batch inspectable
# --------------------------------------------------------------------------------- #


def a_write(*, marker: str = "first-write", **overrides: Any) -> CombinedWrite:
    """Build a plan. The token travels as `marker` for the reason the helper above gives."""
    arguments: dict[str, Any] = {
        "content": '{"a":1}',
        "base_revision": 5,
        "action": "draft",
        "mutation_token": marker,
        "retention": EXPECTED_RETENTION,
        "now": at(1),
    }
    arguments.update(overrides)
    return combined_write(**arguments)


async def test_the_write_carries_seven_statements_in_the_sources_order() -> None:
    """Bootstrap, two baseline captures, the compare-and-set, the history insert, two prunes."""
    plan = a_write()
    assert [effect.name for effect in plan.effects] == [
        "bootstrap",
        "capture-published-baseline",
        "capture-draft-baseline",
        "compare-and-set",
        "record-revision",
        "prune-drafts",
        "prune-publishes",
    ]


async def test_the_next_revision_is_the_base_plus_one() -> None:
    assert a_write(base_revision=5).next_revision == 6
    assert a_write(base_revision=0).next_revision == 1


async def test_the_bootstrap_fires_only_when_the_caller_claims_revision_zero() -> None:
    """Without the guard, a client at revision 5 resurrects a deleted document."""
    bootstrap = a_write(base_revision=5).effects[0]
    assert bootstrap.guard.claimed_revision == 0
    assert bootstrap.guard.idempotent is True, "a concurrent bootstrap is harmless"


async def test_the_baseline_captures_are_gated_on_the_stored_revision_and_are_idempotent() -> None:
    """Fixed ids plus insert-if-absent are what make each succeed at most once, ever."""
    plan = a_write(base_revision=5)
    for effect in plan.effects[1:3]:
        assert effect.guard.stored_revision == 5, "a stale writer captures nothing"
        assert effect.guard.idempotent is True
        assert effect.guard.mutation_token is None
    assert plan.effects[1].entry_id == BASELINE_PUBLISHED_ID
    assert plan.effects[2].entry_id == BASELINE_DRAFT_ID


async def test_the_compare_and_set_tests_position_and_the_side_effects_test_identity() -> None:
    """**This is the whole hazard.**

    Statements 4-6 are guarded on `revision = next_revision`, a value that is NOT unique
    to this writer: a losing writer's `next_revision` collides with the winner's
    `revision`, and the winner's write satisfies exactly that condition. The token is what
    makes those three guards test identity rather than position.
    """
    mine, theirs = "mine", "theirs"
    plan = a_write(base_revision=5, marker=mine)
    compare_and_set = plan.effects[3]
    assert compare_and_set.guard.stored_revision == 5
    assert compare_and_set.guard.mutation_token is None

    for effect in plan.effects[4:]:
        assert effect.guard.stored_revision == 6
        assert effect.guard.mutation_token == mine, "identity, not position"

    winner = a_write(base_revision=5, marker=theirs)
    assert winner.next_revision == plan.next_revision, "the revisions collide"
    assert winner.effects[4].guard.mutation_token != plan.effects[4].guard.mutation_token


async def test_the_history_entry_is_keyed_by_the_mutation_token() -> None:
    mine = "mine"
    assert a_write(marker=mine).effects[4].entry_id == mine


async def test_the_retention_counts_are_arguments_never_constants() -> None:
    """BR5.9: an adapter that hard-coded 30 and 20 has taken ownership of a policy it owns not."""
    policy = tighter(drafts=3, publishes=1)
    plan = a_write(retention=policy)
    assert plan.effects[5].keep == 3
    assert plan.effects[6].keep == 1
    assert plan.effects[5].action == "draft"
    assert plan.effects[6].action == "publish"
    assert plan.retention is policy


async def test_the_publish_flag_is_how_publishing_is_expressed() -> None:
    """Collapsing the two conditional expressions publishes on every save."""
    assert a_write(action="publish").publishing is True
    assert a_write(action="draft").publishing is False


async def test_the_arguments_are_exactly_what_the_port_operation_takes() -> None:
    plan = a_write()
    assert plan.arguments() == {
        "content": '{"a":1}',
        "base_revision": 5,
        "action": "draft",
        "mutation_token": "first-write",
        "retention": EXPECTED_RETENTION,
        "now": at(1),
    }


async def test_a_mutation_token_is_freshly_generated_per_call() -> None:
    """A reused token would let a second write satisfy the first's identity guard."""
    minted = {mint_mutation_token() for _ in range(64)}
    assert len(minted) == 64


async def test_a_save_that_fails_validation_never_reaches_the_store(
    store_factory: Callable[[], ContentStore],
) -> None:
    """BR4.6: authoritative, in the backend, BEFORE anything is persisted."""
    store = store_factory()
    broken = wire_seed()
    broken["research"][0]["link"] = "not a link"
    with pytest.raises(errors.Invalid):
        await authority(store).save(body=save_body(broken, 0, "draft"), now=at(1))
    assert await store.list_revisions() == []
    state = await store.read_state()
    assert state.revision == 0
    assert state.updated_at is None, "no record was created"


async def test_the_stored_document_is_the_validated_and_transformed_one(
    store_factory: Callable[[], ContentStore],
) -> None:
    """The editor sends `validation.data` back, so derived values are materialised on save."""
    store = store_factory()
    sent = wire_seed()
    del sent["publications"][0]["researchIds"]
    await authority(store).save(body=save_body(sent, 0, "draft"), now=at(1))
    stored = json.loads((await store.read_state()).draft)
    assert stored["publications"][0]["researchIds"] == ["photoacoustics"]
    with pytest.raises(ValidationError):
        ContentDocument.model_validate({"name": "x"})
