"""The owner read -- BR4.1, BR4.2, and the shape confirmed against the running source.

A seventh file rather than a seventh section: the plan names six test files and assigns
each to one behaviour, and the owner read belongs to none of them. Putting it in the
write-path file would have diluted a hazard suite, and putting it in the ledger file would
have put a content operation behind a name that means revisions.

The oracle for the read shape is `F3-content-owner`: `draft`, `published`, `revision`,
`updatedAt`, `publishedAt`, `hasUnpublishedChanges`, and nothing else.
"""

from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any

import pytest
from conftest import body as recorded_body

from app.content.authority import ContentAuthority
from app.content.schema import ContentDocument
from app.content.store import ContentStore
from content.conftest import EXPECTED_RETENTION, at, recorded_document, wire_seed

pytestmark = pytest.mark.anyio


def save_body(document: dict[str, Any], revision: int, action: str) -> str:
    payload = {"content": document, "revision": revision, "action": action}
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


def authority(store: ContentStore) -> ContentAuthority:
    return ContentAuthority(store, retention=EXPECTED_RETENTION)


async def test_the_read_shape_is_the_one_the_running_source_returned(
    store_factory: Callable[[], ContentStore],
) -> None:
    recorded = json.loads(recorded_body("F3-content-owner"))
    view = await authority(store_factory()).read_state()
    assert set(view.model_dump(by_alias=True)) == set(recorded)
    assert set(recorded) == {
        "draft",
        "published",
        "revision",
        "updatedAt",
        "publishedAt",
        "hasUnpublishedChanges",
    }


async def test_a_fresh_install_reads_the_seed_and_writes_nothing(
    store_factory: Callable[[], ContentStore],
) -> None:
    """BR4.1. A read that created the document would defeat the bootstrap's revision-0
    guard and let a client at revision 5 resurrect a deleted one.

    `updatedAt` staying null is the observable that distinguishes "wrote nothing" from
    "lazily created the record": the column is NOT NULL, so a lazy create has to invent a
    value.
    """
    store = store_factory()
    view = await authority(store).read_state()

    assert view.revision == 0
    assert view.updated_at is None
    assert view.published_at is None, "the seeded document is not published"
    assert view.has_unpublished_changes is False
    assert view.draft == view.published
    assert view.draft.name == "Madhavi Tripathi"

    after = await store.read_state()
    assert after.revision == 0
    assert after.updated_at is None
    assert await store.list_revisions() == [], "no bootstrap, no baseline capture"

    again = await authority(store).read_state()
    assert again.model_dump(by_alias=True) == view.model_dump(by_alias=True)


async def test_has_unpublished_changes_is_computed_on_every_read_not_stored(
    store_factory: Callable[[], ContentStore],
) -> None:
    """BR4.2: a full comparison of `draft` against `published`, with no column and no flag.

    A maintained flag drifts from the documents it describes, and nothing in the write path
    would reveal the drift -- so the value is recomputed here and never read from storage.
    """
    store = store_factory()
    edited = wire_seed()
    edited["name"] = "Edited"

    await authority(store).save(body=save_body(edited, 0, "draft"), now=at(1))
    assert (await authority(store).read_state()).has_unpublished_changes is True

    await authority(store).save(body=save_body(edited, 1, "publish"), now=at(2))
    assert (await authority(store).read_state()).has_unpublished_changes is False

    # Re-saving the identical document as a draft still increments the revision, and the
    # flag follows the comparison rather than the action.
    await authority(store).save(body=save_body(edited, 2, "draft"), now=at(3))
    view = await authority(store).read_state()
    assert view.revision == 3
    assert view.has_unpublished_changes is False


async def test_the_change_flag_ignores_key_order_because_both_sides_are_reserialised(
    store_factory: Callable[[], ContentStore],
) -> None:
    """The source compared serialised JSON, which is key-order sensitive.

    Comparing by value is equivalent here only because both sides pass through the same
    schema, so this asserts the premise rather than assuming it: a stored document whose
    keys are in a different order must not read as an unpublished change.
    """
    store = store_factory()
    document = wire_seed()
    reordered = dict(reversed(list(document.items())))
    assert list(reordered) != list(document)

    marker = "reordered-write"
    await store.commit(
        content=json.dumps(reordered, ensure_ascii=False, separators=(",", ":")),
        base_revision=0,
        action="draft",
        mutation_token=marker,
        retention=EXPECTED_RETENTION,
        now=at(1),
    )
    view = await authority(store).read_state()
    assert view.has_unpublished_changes is False


async def test_the_read_applies_the_content_carrying_defaults_without_storing_them(
    store_factory: Callable[[], ContentStore],
) -> None:
    """BR9.2 on the owner path: every read re-validates and re-transforms."""
    store = store_factory()
    legacy = wire_seed()
    del legacy["research"][0]["researchTopic"]
    del legacy["publications"][0]["researchIds"]
    payload = json.dumps(legacy, ensure_ascii=False, separators=(",", ":"))
    marker = "legacy-read"
    await store.commit(
        content=payload,
        base_revision=0,
        action="draft",
        mutation_token=marker,
        retention=EXPECTED_RETENTION,
        now=at(1),
    )

    view = await authority(store).read_state()
    assert view.draft.research[0].research_topic == "materials"
    assert view.draft.publications[0].research_ids == ["photoacoustics"]
    assert (await store.read_state()).draft == payload, "the read changed nothing stored"


async def test_the_read_reports_both_timestamps_in_the_recorded_wire_form(
    store_factory: Callable[[], ContentStore],
) -> None:
    store = store_factory()
    await authority(store).save(body=save_body(wire_seed(), 0, "publish"), now=at(7))
    view = await authority(store).read_state()
    assert view.updated_at == "2026-09-25T12:00:07.000Z"
    assert view.published_at == "2026-09-25T12:00:07.000Z"
    assert json.loads(recorded_body("F3-content-owner"))["updatedAt"].endswith("Z")


async def test_the_seed_the_read_serves_is_the_recorded_document(
    store_factory: Callable[[], ContentStore],
) -> None:
    """The one place the read path and the recorded oracle meet end to end."""
    view = await authority(store_factory()).read_state()
    served = view.draft.model_dump(by_alias=True)
    recorded = recorded_document()
    served["photoSources"] = recorded["photoSources"]
    assert served == recorded


async def test_a_stored_document_that_no_longer_validates_surfaces_rather_than_silently_repairing(
    store_factory: Callable[[], ContentStore],
) -> None:
    """A read never repairs. The recovery path is the only one that does, and it is opt-in.

    Silently substituting a default for a stored value the schema rejects would change the
    owner's content without telling them; letting it surface puts it in the 503 branch with
    a traceback, which is where an unexpected failure belongs.
    """
    from pydantic import ValidationError

    store = store_factory()
    corrupt = wire_seed()
    corrupt["accent"] = "teal"
    marker = "corrupt-write"
    await store.commit(
        content=json.dumps(corrupt, ensure_ascii=False, separators=(",", ":")),
        base_revision=0,
        action="draft",
        mutation_token=marker,
        retention=EXPECTED_RETENTION,
        now=at(1),
    )
    with pytest.raises(ValidationError):
        await authority(store).read_state()
    assert ContentDocument.model_validate(wire_seed()).accent == "blue"
