"""HAZARD -- recoverable versus corrupting (FR8.3, BR8.1-BR8.5), branch by branch.

**The port implements the rule as written, not as the source behaves** (D9). The source
allowlists four zod issue codes -- `too_small`, `too_big`, `custom`, `invalid_format` --
and discards the draft if any issue falls outside that list. Two defects compound:
`invalid_format` is a zod v4 code while the installed package resolves to the v3 API, so
that entry **can never match**; and `invalid_enum_value`, which v3 does emit, is
**absent**. Net effect: one bad enum discards the owner's entire recovered draft, along
with every other unsaved edit in that record, while the source's own comment states the
opposite intent.

**The enumerated-set row is the whole hazard in one line.** Every other row in BR8.3's
table would be classified the same way by anyone reasoning from first principles. The
enum row is the one a reasonable implementer puts on the *other* side -- "a value that is
not a member of the enum is not a valid value of that type, so the record is malformed" --
and that reasoning is exactly the source's bug.

Each case below therefore pins **two** things: the error type Pydantic actually reports
for that input, and the class BR8.3 puts it in. A test that only asserted the class would
pass against a classification keyed on a type the schema never emits, which is the first
half of the source's defect.
"""

from __future__ import annotations

import json
from collections.abc import Callable
from pathlib import Path
from typing import Any, get_args

import pytest
from pydantic_core.core_schema import ErrorType

from app.content import recovery
from app.content.authority import ContentAuthority
from app.content.recovery import CorruptedRecord, RecoverableDraft, inspect_draft
from app.content.store import ContentStore
from content.conftest import EXPECTED_RETENTION, blank_item, wire_seed

pytestmark = pytest.mark.anyio


def record(content: Any, *, revision: int = 3, saved_at: str = "2026-09-25T03:12:29.956Z") -> str:
    """A recovery record as the editor holds it: the draft plus where it came from."""
    return json.dumps(
        {"content": content, "revision": revision, "savedAt": saved_at}, ensure_ascii=False
    )


def broken(path: tuple[Any, ...], value: Any) -> dict[str, Any]:
    document = wire_seed()
    node: Any = document
    for key in path[:-1]:
        node = node[key]
    node[path[-1]] = value
    return document


def without(path: tuple[Any, ...]) -> dict[str, Any]:
    document = wire_seed()
    node: Any = document
    for key in path[:-1]:
        node = node[key]
    del node[path[-1]]
    return document


# --------------------------------------------------------------------------------- #
# BR8.1 / BR8.3 -- RECOVERABLE: present, correctly typed, outside its set or range
# --------------------------------------------------------------------------------- #

RECOVERABLE_CASES: tuple[tuple[str, dict[str, Any], str], ...] = (
    ("below a minimum", broken(("research", 0, "title"), "   "), "string_too_short"),
    ("above a maximum", broken(("name",), "a" * 101), "string_too_long"),
    ("a number below its range", broken(("photoFocalX",), -1), "greater_than_equal"),
    ("a number above its range", broken(("photoFocalY",), 101), "less_than_equal"),
    (
        "a list above its maximum",
        broken(("photoSources",), [{"src": "", "width": 1, "height": 1}] * 5),
        "too_long",
    ),
    ("a failed format check", broken(("email",), "not-an-email"), "value_error"),
    ("a failed custom check", broken(("research", 0, "citations"), "many"), "value_error"),
    (
        "an impossible citation date",
        broken(("research", 0, "citationsAsOf"), "2026-02-30"),
        "value_error",
    ),
    ("a bad URL", broken(("photo",), "ftp://x.test"), "value_error"),
    ("a value outside an enumerated set", broken(("accent",), "teal"), "literal_error"),
    ("a bad research topic", broken(("research", 0, "researchTopic"), "bogus"), "literal_error"),
    ("a bad scene view", broken(("scene", "initialView"), "sideways"), "literal_error"),
)


@pytest.mark.parametrize(
    ("label", "document", "error_type"), RECOVERABLE_CASES, ids=lambda v: str(v)
)
async def test_a_typed_value_outside_its_set_or_range_is_recoverable(
    label: str, document: dict[str, Any], error_type: str
) -> None:
    """These are exactly the states an owner produces BY TYPING, so the draft is kept."""
    assert recovery.classify_error_type(error_type) == "recoverable", label
    verdict = inspect_draft(record(document))
    assert isinstance(verdict, RecoverableDraft), label
    assert error_type in {issue.error_type for issue in verdict.issues}, label
    assert all(issue.classification == "recoverable" for issue in verdict.issues), label


async def test_the_bad_enum_case_the_source_gets_wrong_is_recoverable_here() -> None:
    """**The test that would fail if the source's allowlist were copied across.**

    `accent` is edited through a radio control, so this bites on a draft written by an
    older schema version or through the browser-tool path -- which is exactly the case
    recovery exists for.
    """
    verdict = inspect_draft(record(broken(("accent",), "teal")))
    assert isinstance(verdict, RecoverableDraft)
    assert verdict.content["accent"] == "teal", "the invalid value stays editable"
    assert [issue.path for issue in verdict.issues] == [["accent"]]


async def test_a_bad_enum_beside_other_recoverable_edits_keeps_the_whole_draft() -> None:
    """One bad enum must not discard every other unsaved edit in that record."""
    document = broken(("accent",), "teal")
    document["name"] = "Work in progress"
    document["research"][0]["title"] = "  "
    verdict = inspect_draft(record(document))
    assert isinstance(verdict, RecoverableDraft)
    assert verdict.content["name"] == "Work in progress"
    assert len(verdict.issues) == 2


# --------------------------------------------------------------------------------- #
# BR8.2 / BR8.3 -- CORRUPTING: a malformed record
# --------------------------------------------------------------------------------- #

CORRUPTING_CASES: tuple[tuple[str, dict[str, Any], str], ...] = (
    ("wrong type for the declared field", broken(("name",), 5), "string_type"),
    ("a required key missing", without(("role",)), "missing"),
    ("not an object where one is required", broken(("scholarHighlights",), []), "model_type"),
    ("not an array where one is required", broken(("research",), {}), "list_type"),
    ("a boolean where a string belongs", broken(("notice",), True), "string_type"),
    ("a string where a number belongs", broken(("photoFocalX",), "50"), "int_type"),
    # An item that is not an object at all: the content-carrying transform hands a
    # non-mapping straight back rather than raising, so the failure is reported as the
    # corrupting `model_type` it is instead of escaping as an internal error.
    ("an item that is not an object", broken(("news",), [5]), "model_type"),
)


@pytest.mark.parametrize(
    ("label", "document", "error_type"), CORRUPTING_CASES, ids=lambda v: str(v)
)
async def test_a_malformed_record_is_corrupting(
    label: str, document: dict[str, Any], error_type: str
) -> None:
    assert recovery.classify_error_type(error_type) == "corrupting", label
    verdict = inspect_draft(record(document))
    assert isinstance(verdict, CorruptedRecord), label
    assert error_type in {issue.error_type for issue in verdict.issues}, label


async def test_a_payload_that_is_not_parseable_at_all_is_corrupting() -> None:
    verdict = inspect_draft("{not json")
    assert isinstance(verdict, CorruptedRecord)
    assert verdict.issues[0].error_type == "json_invalid"


async def test_one_corrupting_issue_condemns_an_otherwise_recoverable_record() -> None:
    """The draft is discarded only if AT LEAST ONE issue is corrupting."""
    document = broken(("accent",), "teal")
    document["name"] = 5
    verdict = inspect_draft(record(document))
    assert isinstance(verdict, CorruptedRecord)
    assert {issue.classification for issue in verdict.issues} == {"recoverable", "corrupting"}


async def test_an_unrecognised_error_type_is_corrupting() -> None:
    """The recoverable set is enumerated from BR8.3; anything else is a malformed record."""
    assert recovery.classify_error_type("something_the_validator_grew_later") == "corrupting"


async def test_no_entry_in_the_recoverable_set_is_one_the_validator_can_never_report() -> None:
    """**The guard against the source's FIRST defect**, which is not the enum one.

    `invalid_format` is a zod v4 code and the installed package resolves to v3, so that
    entry could never match: a quarter of the allowlist was dead, and nothing anywhere
    said so. `pydantic_core.ErrorType` enumerates every type this validator can emit, so
    a dead entry here fails a test instead of silently narrowing the class.
    """
    known = set(get_args(ErrorType))
    assert len(known) > 100, "the enumeration is the whole point of this assertion"
    assert known >= recovery.RECOVERABLE_ERROR_TYPES


async def test_every_enumerated_case_reports_the_type_it_was_classified_on() -> None:
    """A verdict alone cannot show WHICH outcome was classified, so the type is asserted too."""
    observed: set[str] = set()
    for _, document, _ in (*RECOVERABLE_CASES, *CORRUPTING_CASES):
        verdict = inspect_draft(record(document))
        observed.update(issue.error_type for issue in verdict.issues)
    assert observed >= {
        "string_too_short",
        "string_too_long",
        "greater_than_equal",
        "less_than_equal",
        "too_long",
        "value_error",
        "literal_error",
        "string_type",
        "missing",
        "model_type",
        "list_type",
        "int_type",
    }
    recoverable = {
        error_type
        for error_type in observed
        if recovery.classify_error_type(error_type) == "recoverable"
    }
    assert recoverable <= recovery.RECOVERABLE_ERROR_TYPES


def test_no_zod_issue_code_string_appears_in_the_classification() -> None:
    """BR8.5: re-express in the new validator's taxonomy, NEVER by copying code strings.

    Copying the four across would carry the inherited bug forward and add a second one,
    in the code path whose whole job is not to lose work.
    """
    source = Path(recovery.__file__).read_text()
    for name in ("too_small", "too_big", "invalid_enum_value", "invalid_format"):
        assert f"'{name}'" not in source, name
        assert f'"{name}"' not in source, name


# --------------------------------------------------------------------------------- #
# BR8.3 clauses 3 and 4 -- what each verdict carries
# --------------------------------------------------------------------------------- #


async def test_a_valid_draft_is_recoverable_with_no_issues() -> None:
    verdict = inspect_draft(record(wire_seed()))
    assert isinstance(verdict, RecoverableDraft)
    assert verdict.issues == ()
    assert verdict.content == wire_seed()
    assert verdict.revision == 3
    assert verdict.saved_at == "2026-09-25T03:12:29.956Z"


async def test_a_recoverable_draft_is_repaired_against_schema_defaults() -> None:
    """Validation errors must not discard freshly added schema defaults.

    The invalid text stays editable; a legacy record simply receives the new fields.
    """
    document = broken(("accent",), "teal")
    del document["copy"]
    del document["scene"]
    legacy = blank_item("legacy")
    for optional in ("researchTopic", "researchIds"):
        del legacy[optional]
    document["news"] = [legacy]

    verdict = inspect_draft(record(document))
    assert isinstance(verdict, RecoverableDraft)
    assert verdict.content["accent"] == "teal"
    assert verdict.content["copy"]["research"]["navigation"] == "Research"
    assert verdict.content["scene"]["initialView"] == "delivery"
    repaired = verdict.content["news"][0]
    assert repaired["id"] == "legacy"
    assert repaired["imageSources"] == []
    assert repaired["focalY"] == 50
    assert repaired["researchTopic"] == "general"
    assert repaired["researchIds"] == []


async def test_an_item_missing_its_id_is_corrupting_and_never_reaches_the_repair() -> None:
    """`id` is required and carries no default, so its absence is a missing required key.

    Worth pinning because the repair merges each item over a **fresh blank record** that
    does carry an identity, which makes it look as though a missing id could be filled in.
    It cannot: the classification runs first and `missing` is corrupting, so an item with
    no id condemns the record rather than acquiring a new identity -- and two such items
    could not be told apart afterwards anyway.
    """
    document = broken(("accent",), "teal")
    first, second = blank_item("a"), blank_item("b")
    del first["id"]
    del second["id"]
    document["news"] = [first, second]
    verdict = inspect_draft(record(document))
    assert isinstance(verdict, CorruptedRecord)
    assert {issue.error_type for issue in verdict.issues} == {"literal_error", "missing"}


# --------------------------------------------------------------------------------- #
# The record envelope, and the ceiling that is NOT the save cap
# --------------------------------------------------------------------------------- #

ENVELOPE_REJECTIONS: tuple[tuple[str, str], ...] = (
    ("a non-integer revision", json.dumps({"content": {}, "revision": 1.5, "savedAt": "x"})),
    # `Number.isInteger(true)` is false: a boolean is not a number in the source either.
    ("a boolean revision", json.dumps({"content": {}, "revision": True, "savedAt": "x"})),
    ("an absent revision", json.dumps({"content": {}, "savedAt": "2026-01-01T00:00:00.000Z"})),
    ("a non-string savedAt", json.dumps({"content": {}, "revision": 1, "savedAt": 5})),
    ("an unparseable savedAt", json.dumps({"content": {}, "revision": 1, "savedAt": "soon"})),
    ("a null record", "null"),
    ("an array record", "[]"),
)


@pytest.mark.parametrize(("label", "raw"), ENVELOPE_REJECTIONS, ids=lambda v: str(v))
async def test_a_malformed_recovery_envelope_is_corrupting(label: str, raw: str) -> None:
    assert isinstance(inspect_draft(raw), CorruptedRecord), label


async def test_the_recovery_ceiling_is_six_million_units_and_is_not_the_save_cap() -> None:
    """**A recorded open question, preserved rather than silently closed.**

    The recovery path accepts a stored draft up to 6,000,000 characters; the save path
    rejects anything over 1,500,000. A draft between those bounds is restorable into the
    editor and unsavable from it -- every save attempt fails as too-large, including every
    autosave. The two limits were chosen independently in the source, and aligning them
    would change observable behaviour under an otherwise absolute parity rule. The port
    preserves both and this test records the window.
    """
    from app.content.limits import MAX_BODY_UTF16_UNITS

    assert recovery.MAX_RECOVERY_UTF16_UNITS == 6_000_000
    assert recovery.MAX_RECOVERY_UTF16_UNITS > MAX_BODY_UTF16_UNITS
    assert isinstance(inspect_draft("x" * (recovery.MAX_RECOVERY_UTF16_UNITS + 1)), CorruptedRecord)
    assert isinstance(inspect_draft(""), CorruptedRecord)


# --------------------------------------------------------------------------------- #
# BR8.7 -- a failed inspect is a THIRD state, not "discard it"
# --------------------------------------------------------------------------------- #


async def test_the_authority_exposes_inspect_as_an_operation_and_writes_nothing(
    store_factory: Callable[[], ContentStore],
) -> None:
    """The inspect operation reaches the classification through `ContentAuthority`.

    It touches no storage: the candidate draft lives in the editor, not in this system,
    which is why the operation is a thin delegate over a pure function.
    """
    store = store_factory()
    authority = ContentAuthority(store, retention=EXPECTED_RETENTION)
    verdict = await authority.inspect_recovered_draft(record(broken(("accent",), "teal")))
    assert isinstance(verdict, RecoverableDraft)
    assert verdict.content["accent"] == "teal"

    unusable = await authority.inspect_recovered_draft(record(broken(("name",), 5)))
    assert isinstance(unusable, CorruptedRecord)

    state = await store.read_state()
    assert state.revision == 0
    assert state.updated_at is None
    assert await store.list_revisions() == []


async def test_a_failure_inside_inspect_is_distinguishable_from_a_corrupting_verdict(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The editor HOLDS the draft when inspect is unreachable (BR8.7, owned by U9).

    So this unit's failure must never be dressed as a verdict: a corrupting verdict is a
    RETURN VALUE and a failure is a RAISED exception, and an over-broad `except` here
    would turn "we could not check" into "throw your work away".
    """

    def boom(error_type: str) -> str:
        raise RuntimeError("classification unavailable")

    monkeypatch.setattr(recovery, "classify_error_type", boom)
    with pytest.raises(RuntimeError):
        inspect_draft(record(broken(("accent",), "teal")))

    assert not issubclass(RuntimeError, CorruptedRecord)
    assert not issubclass(CorruptedRecord, Exception), "a verdict is data, never an exception"
