"""Fixtures for U4 `content-core`.

**Nothing here mocks the store.** Both `ContentStore` implementations used below are real
implementations already under their own conformance suite; mocking one would assert this
unit's belief about the store rather than the store.

Time is a caller argument throughout, never a module-level clock: `commit` takes `now`,
and the cache's interval has to be advanced without sleeping.
"""

from __future__ import annotations

import json
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

import pytest
from conftest import body

from app.content.seed import seed_document, seed_payload
from app.content.store import (
    BASELINE_DRAFT_ID,
    BASELINE_PUBLISHED_ID,
    ContentStore,
    RetentionPolicy,
    listing_cap_for,
)
from app.content.store_memory import InMemoryContentStore, MemoryContentStorage
from app.content.store_sqlite import SqliteContentStore
from app.sqlite import SqliteDatabase

_EPOCH = datetime(2026, 9, 25, 12, 0, 0, tzinfo=UTC)

# The policy the stores in this directory are opened with. Written out here rather than
# imported from `RevisionLedger` on purpose: `test_ledger.py` asserts that the ledger
# supplies exactly this, and a fixture that took its expectation from the thing under
# test could not. `listing_cap_for` is BR5.3's construction and is never restated as 52.
EXPECTED_RETENTION = RetentionPolicy(
    draft_keep=30,
    publish_keep=20,
    permanent_ids=(BASELINE_PUBLISHED_ID, BASELINE_DRAFT_ID),
)
EXPECTED_LISTING_CAP = listing_cap_for(EXPECTED_RETENTION)


@pytest.fixture
def anyio_backend() -> str:
    """Pinned to asyncio alone; the production runtime is asyncio."""
    return "asyncio"


def at(seconds: int) -> datetime:
    """A distinct, ordered instant. Nothing in this unit reads a clock."""
    return _EPOCH + timedelta(seconds=seconds)


def wire_seed() -> dict[str, Any]:
    """The seeded document in its frozen `camelCase` wire shape."""
    dumped: dict[str, Any] = seed_document().model_dump(by_alias=True)
    return dumped


def recorded_document() -> dict[str, Any]:
    """The content document the running source served, from `F3-content-owner`.

    This is the oracle for the seed and for the content-carrying defaults: it is the
    serialised shape **with the defaults already resolved**.
    """
    draft: dict[str, Any] = json.loads(body("F3-content-owner"))["draft"]
    return draft


def blank_item(item_id: str = "x") -> dict[str, Any]:
    """The smallest item the schema accepts, in wire shape."""
    return {
        "id": item_id,
        "title": "t",
        "subtitle": "",
        "description": "",
        "year": "",
        "image": "",
        "imageAlt": "",
        "link": "",
        "code": "",
        "dataset": "",
        "video": "",
        "featured": False,
        "researchTopic": "general",
        "researchIds": [],
    }


def set_at(document: dict[str, Any], path: tuple[Any, ...], value: Any) -> dict[str, Any]:
    """Replace one value in a wire document, addressed by its path. Returns the document."""
    node: Any = document
    for key in path[:-1]:
        node = node[key]
    node[path[-1]] = value
    return document


def drop_at(document: dict[str, Any], path: tuple[Any, ...]) -> dict[str, Any]:
    """Remove one key from a wire document, addressed by its path. Returns the document."""
    node: Any = document
    for key in path[:-1]:
        node = node[key]
    del node[path[-1]]
    return document


@pytest.fixture(params=["memory", "sqlite"])
async def store_factory(
    request: pytest.FixtureRequest, tmp_path: Path
) -> Callable[[], ContentStore]:
    """Both real implementations, so no assertion here is an accident of one of them.

    A **factory** rather than a store, because the concurrent-writer cases need two
    independent handles over the same storage -- which is the only way the ABA defence of
    BR4.13 can be demonstrated at all.
    """
    if request.param == "memory":
        storage = MemoryContentStorage()

        def open_memory() -> ContentStore:
            return InMemoryContentStore(
                storage, seed=seed_payload(), listing_cap=EXPECTED_LISTING_CAP
            )

        return open_memory

    # A real file, not `:memory:`: `:memory:` gives each connection its own private
    # database, which would remove the contention the concurrent cases exist to produce.
    path = tmp_path / "content.sqlite3"
    await SqliteDatabase(path).initialize()

    def open_sqlite() -> ContentStore:
        return SqliteContentStore(
            SqliteDatabase(path), seed=seed_payload(), listing_cap=EXPECTED_LISTING_CAP
        )

    return open_sqlite
