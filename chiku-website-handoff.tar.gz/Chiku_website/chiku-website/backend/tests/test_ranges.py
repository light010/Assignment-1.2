"""Every recorded F11 range fixture, asserted against the port.

The expected value for each case is derived from what the source actually returned --
the status line and the ``Content-Range`` header -- not from a reading of the parser.
"""

from __future__ import annotations

import re

import pytest
from conftest import meta, names, response_header

from app.assets.ranges import (
    ByteRange,
    RangeOutcome,
    effective_range_header,
    parse_byte_range,
)

# The object every F11 fixture was recorded against.
OBJECT_SIZE = 188_618

RANGE_FIXTURES = names("F11-")


def expected_from_recording(name: str) -> ByteRange | RangeOutcome | None:
    """Translate a recorded response back into the parser outcome that produced it."""
    status = meta(name)["response"]["status"]
    if status == 416:
        assert response_header(name, "content-range") == f"bytes */{OBJECT_SIZE}"
        return RangeOutcome.INVALID
    if status == 200:
        # The range was suppressed before it reached the parser (If-Range mismatch).
        return None
    assert status == 206, f"{name}: unexpected recorded status {status}"
    content_range = response_header(name, "content-range")
    assert content_range is not None, f"{name}: 206 with no Content-Range"
    match = re.fullmatch(r"bytes (\d+)-(\d+)/(\d+)", content_range)
    assert match, f"{name}: unparseable Content-Range {content_range!r}"
    start, end, total = (int(g) for g in match.groups())
    assert total == OBJECT_SIZE
    return ByteRange(offset=start, length=end - start + 1)


@pytest.mark.parametrize("name", RANGE_FIXTURES)
def test_range_matches_recorded_source_behaviour(name: str) -> None:
    request_headers = meta(name)["request"]["headers"]
    etag = response_header(name, "etag")
    header = effective_range_header(
        request_headers.get("Range"), request_headers.get("If-Range"), etag
    )
    assert parse_byte_range(header, OBJECT_SIZE) == expected_from_recording(name)


def test_every_range_fixture_is_exercised() -> None:
    """Guard against the suite silently shrinking if fixtures are renamed."""
    assert len(RANGE_FIXTURES) >= 15, RANGE_FIXTURES


def test_absent_header_is_not_invalid() -> None:
    """`None` (serve everything, 200) and INVALID (416) must never collapse together."""
    assert parse_byte_range(None, OBJECT_SIZE) is None
    assert parse_byte_range("", OBJECT_SIZE) is None
    assert parse_byte_range("bytes=-", OBJECT_SIZE) is RangeOutcome.INVALID


def test_oversized_suffix_is_preserved_as_206_not_416() -> None:
    """The deliberate defect. A port that "fixes" this disagrees with the source."""
    result = parse_byte_range(f"bytes=-{OBJECT_SIZE + 999}", OBJECT_SIZE)
    assert result == ByteRange(offset=0, length=OBJECT_SIZE)


def test_safe_integer_ceiling_is_enforced() -> None:
    """Python ints are unbounded; JavaScript's guard is Number.isSafeInteger."""
    assert parse_byte_range(f"bytes={2**53}-", OBJECT_SIZE) is RangeOutcome.INVALID
    assert parse_byte_range(f"bytes=-{2**53}", OBJECT_SIZE) is RangeOutcome.INVALID


def test_non_ascii_digits_are_rejected() -> None:
    """Python's `\\d` matches Unicode digits; JavaScript's does not."""
    assert parse_byte_range("bytes=\u0660-\u0669", OBJECT_SIZE) is RangeOutcome.INVALID


def test_empty_object_is_invalid_for_any_range() -> None:
    assert parse_byte_range("bytes=0-0", 0) is RangeOutcome.INVALID
