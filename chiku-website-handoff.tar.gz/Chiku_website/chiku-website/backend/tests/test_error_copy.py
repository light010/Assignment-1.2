"""Error copy is product copy, so it is asserted byte-for-byte against the recording.

Under the parity rule a rewritten error sentence has changed what the site owner sees.
These assertions compare against the raw recorded bytes rather than a decoded string, so
a lost curly apostrophe or a normalised Unicode form fails here rather than in the UI.
"""

from __future__ import annotations

import json

import pytest
from conftest import body, meta

from app import errors

# fixture name -> the constant the port must reproduce
COPY = {
    "F3-content-anon": errors.NOT_SIGNED_IN,
    "F5-put-anon": errors.NOT_SIGNED_IN,
    "F5-put-no-origin": errors.UNVERIFIED_REQUEST,
    "F6-size-over-limit": errors.TOO_LARGE,
    "F12-bad-json": errors.UNREADABLE_UPDATE,
    "F12-array-body": errors.INVALID_SAVE,
    "F12-bad-action": errors.INVALID_SAVE,
    "F12-autosave-on-publish": errors.INVALID_SAVE,
    "F12-negative-revision": errors.INVALID_SAVE,
    "F12-schema-invalid": errors.CHECK_FIELDS,
    "F5-conflict-stale-revision": errors.CONFLICT,
}


@pytest.mark.parametrize(("name", "expected"), sorted(COPY.items()))
def test_error_sentence_matches_recording(name: str, expected: str) -> None:
    recorded = json.loads(body(name))["error"]
    assert recorded == expected


def test_curly_apostrophe_survives_as_bytes() -> None:
    """U+2019, not U+0027. The straight quote is a different sentence on the wire."""
    raw = body("F3-content-anon")
    assert b"\xe2\x80\x99" in raw
    assert b"owner's" not in raw
    assert errors.NOT_SIGNED_IN.encode() in raw


def test_conflict_carries_metadata_at_the_top_level() -> None:
    """`editor-workflow.ts` reads these as siblings of `error`, not nested."""
    recorded = json.loads(body("F5-conflict-stale-revision"))
    assert meta("F5-conflict-stale-revision")["response"]["status"] == 409
    assert set(recorded) == {
        "error",
        "revision",
        "updatedAt",
        "publishedAt",
        "hasUnpublishedChanges",
    }
    rendered = errors.envelope(
        errors.Conflict(
            revision=recorded["revision"],
            updatedAt=recorded["updatedAt"],
            publishedAt=recorded["publishedAt"],
            hasUnpublishedChanges=recorded["hasUnpublishedChanges"],
        )
    )
    assert rendered == recorded


def test_validation_issues_use_path_and_message_not_loc_and_msg() -> None:
    """FastAPI's default shape would break field highlighting while looking fine."""
    recorded = json.loads(body("F12-schema-invalid"))
    assert recorded["error"] == errors.CHECK_FIELDS
    assert recorded["issues"], "expected a non-empty issues list"
    for issue in recorded["issues"]:
        assert set(issue) == {"path", "message"}
        assert isinstance(issue["path"], list)
    rendered = errors.envelope(errors.Invalid(errors.CHECK_FIELDS, issues=recorded["issues"]))
    assert rendered == recorded


def test_empty_issues_list_is_omitted_entirely() -> None:
    """The frontend tests `issues?.length`; an empty array is not the same as absent."""
    assert "issues" not in errors.envelope(errors.Invalid(issues=[]))
    assert "issues" not in errors.envelope(errors.Invalid())


def test_media_route_answers_in_plain_text_not_json() -> None:
    assert body("F7-draftonly-anon") == errors.MEDIA_NOT_FOUND.encode()
    assert body("F9-missing-owner") == errors.MEDIA_NOT_FOUND.encode()
    assert body("F10-malformed-once") == errors.MEDIA_NOT_FOUND.encode()


def test_taxonomy_statuses_match_the_source() -> None:
    assert errors.NotAuthorized().status == 403
    assert errors.Conflict().status == 409
    assert errors.TooLarge().status == 413
    assert errors.Invalid().status == 400
    assert errors.Cancelled().status == 499
    assert errors.AppError().status == 503  # 503, not 500: every source catch answers 503
