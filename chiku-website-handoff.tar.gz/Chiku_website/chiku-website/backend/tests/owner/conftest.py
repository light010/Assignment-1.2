"""Fixtures for U3's owner-provisioning tests.

The fixtures are `tests/auth/conftest.py`'s, imported rather than restated. Provisioning
and sign-in are two halves of one component and they need the same real stores, the same
low-cost hasher and the same injected clock; a second copy of that wiring would be a
second thing to keep in step, and the copy that drifted would be the one still asserting
that a restart cannot reopen the gate.
"""

from __future__ import annotations

from auth.conftest import (
    anyio_backend,
    identity_store_factory,
    low_cost_hashing,
    recording_hashing,
    signer,
)

__all__ = [
    "anyio_backend",
    "identity_store_factory",
    "low_cost_hashing",
    "recording_hashing",
    "signer",
]
