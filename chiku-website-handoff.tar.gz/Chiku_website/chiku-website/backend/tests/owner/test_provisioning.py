"""HAZARD -- one-shot provisioning, and the acceptance test for the no-credential rule.

**There is no oracle for this file.** The source had no identity table, no account row and
no credential; every expectation is read off `functional-spec.md` § *Provision the initial
owner* and `rules.md` BR3.7-BR3.10 and BR22.13.

**This is the one operation in the system that can never be re-run once it has
succeeded.** A lost provisioning on a container with no interactive shell leaves a system
nobody can sign in to and no route that will let them, which is why the concurrent case
below is run with two genuinely concurrent tasks over one storage handle rather than
sequentially. A sequential test passes against a read-then-write implementation that is
wrong, and the failure it misses is unrecoverable.

**The gate is the record's existence.** Not a consumed flag, not a marker file, not an
environment variable -- every other formulation has a state that can be reset from
outside the data. `test_a_restart_cannot_reopen_the_gate` constructs a fresh service over
the same storage, which is the state a flag-based implementation gets wrong.

**BR3.10's acceptance test is stated exactly as the specification states it** and asserted
directly rather than inferred from the absence of a seed:
`test_a_fresh_start_against_empty_storage_has_no_account_anyone_can_sign_in_to`.
"""

from __future__ import annotations

import base64
import hashlib
import logging
from collections.abc import Callable

import anyio
import pytest

from app import errors
from app.auth.hashing import PasswordHashing
from app.auth.store import IdentityStore
from app.auth.store_memory import InMemoryIdentityStore, MemoryIdentityStorage
from app.auth.tokens import CookieSigner
from app.owner.identity import EMAIL_MAX_LENGTH, OwnerIdentity
from app.owner.provision import provision_from_command_line
from auth.conftest import (
    RecordingHashing,
    a_bootstrap_secret,
    a_password,
    an_address,
    an_email,
    at,
    build_identity,
)

pytestmark = pytest.mark.anyio


# --- BR3.10, stated exactly ------------------------------------------------------------ #


async def test_a_fresh_start_against_empty_storage_has_no_account_anyone_can_sign_in_to(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    """The acceptance test for FR3.7, asserted rather than inferred.

    "No seed exists" is a claim about the source tree; this is a claim about the running
    system, and it is the one the rule makes.
    """
    store = identity_store_factory()
    identity = build_identity(store, low_cost_hashing, signer)

    assert await store.owner_record_read() is None

    for attempt in range(5):
        with pytest.raises(errors.NotAuthorized):
            await identity.sign_in(
                email=an_email(f"guess-{attempt}"),
                password=a_password(),
                source_address=an_address(),
                now=at(attempt),
            )

    # The refused attempts created nothing. An implementation that provisioned on first
    # sign-in would pass every assertion above and fail this one.
    assert await store.owner_record_read() is None


async def test_no_configuration_causes_an_owner_to_be_seeded(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    """With the bootstrap secret set and with it unset, storage stays empty until asked."""
    for secret in (None, a_bootstrap_secret()):
        store = identity_store_factory()
        identity = build_identity(store, low_cost_hashing, signer, bootstrap_secret=secret)
        assert await identity.provisioning_offered() is (secret is not None)
        assert await store.owner_record_read() is None


# --- the gate is the record's existence (BR3.7) ---------------------------------------- #


async def test_once_an_owner_exists_both_paths_refuse(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    store = identity_store_factory()
    secret = a_bootstrap_secret()
    identity = build_identity(store, low_cost_hashing, signer, bootstrap_secret=secret)

    assert await identity.provision(email=an_email(), password=a_password(), now=at(0)) is True

    # The command-line path.
    assert await identity.provision(email=an_email(), password=a_password(), now=at(1)) is False
    # The one-shot route, with the correct secret.
    assert await identity.provisioning_offered() is False
    with pytest.raises(errors.NotAuthorized):
        await identity.provision_with_secret(
            secret=secret, email=an_email(), password=a_password(), now=at(2)
        )


async def test_a_restart_cannot_reopen_the_gate(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    """A fresh service over the same storage, which is what a container restart produces.

    A consumed flag held in the process, a marker file, or an environment variable each
    pass every test above and fail this one -- and each fails it by re-opening a
    provisioning route on a live system.
    """
    secret = a_bootstrap_secret()
    first = build_identity(
        identity_store_factory(), low_cost_hashing, signer, bootstrap_secret=secret
    )
    assert await first.provision(email=an_email(), password=a_password(), now=at(0)) is True

    restarted = build_identity(
        identity_store_factory(), low_cost_hashing, signer, bootstrap_secret=secret
    )
    assert await restarted.provisioning_offered() is False
    assert await restarted.provision(email=an_email(), password=a_password(), now=at(1)) is False


async def test_two_concurrent_provisionings_yield_one_record_and_one_refusal(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    """BR22.13, run genuinely concurrently over one storage handle.

    A sequential version of this test passes against a read-then-write implementation,
    which under a real race produces either two records or one lost provisioning. On the
    one operation that can never be re-run, a lost provisioning is unrecoverable.
    """
    store = identity_store_factory()
    identity = build_identity(store, low_cost_hashing, signer)
    candidates = [(an_email("first"), a_password()), (an_email("second"), a_password())]
    outcomes: list[bool] = []

    async def attempt(email: str, password: str) -> None:
        outcomes.append(await identity.provision(email=email, password=password, now=at(0)))

    async with anyio.create_task_group() as tasks:
        for email, password in candidates:
            tasks.start_soon(attempt, email, password)

    assert sorted(outcomes) == [False, True]

    owner = await store.owner_record_read()
    assert owner is not None
    assert owner.email in {email for email, _ in candidates}

    # And the one that won is the one that can sign in; the loser's password is not a
    # second credential lying around.
    winner = next(password for email, password in candidates if email == owner.email)
    loser = next(password for email, password in candidates if email != owner.email)
    signed_in = await identity.sign_in(
        email=owner.email, password=winner, source_address=an_address(), now=at(1)
    )
    assert signed_in.owner_id == owner.owner_id
    with pytest.raises(errors.NotAuthorized):
        await identity.sign_in(
            email=owner.email, password=loser, source_address=an_address(2), now=at(2)
        )


# --- the one-shot route: enabled only while BOTH hold (BR3.8) --------------------------- #


async def test_the_one_shot_route_is_enabled_only_while_both_conditions_hold(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    secret = a_bootstrap_secret()
    # One storage throughout -- the factory hands out repeated handles onto the same
    # storage on purpose -- so the third case observes the owner the second one created.
    store = identity_store_factory()

    with_secret = build_identity(store, low_cost_hashing, signer, bootstrap_secret=secret)
    without_secret = build_identity(store, low_cost_hashing, signer, bootstrap_secret=None)

    # Secret configured, no owner: the only state in which the route exists.
    assert await with_secret.provisioning_offered() is True
    # No secret, no owner: one condition short.
    assert await without_secret.provisioning_offered() is False

    await with_secret.provision(email=an_email(), password=a_password(), now=at(0))

    # Secret still configured, owner now present: the other condition short.
    assert await with_secret.provisioning_offered() is False
    assert await without_secret.provisioning_offered() is False


async def test_the_one_shot_route_requires_the_configured_secret(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    store = identity_store_factory()
    secret = a_bootstrap_secret()
    identity = build_identity(store, low_cost_hashing, signer, bootstrap_secret=secret)

    for wrong in ("", a_bootstrap_secret(), secret[:-1], secret + "x"):
        with pytest.raises(errors.NotAuthorized):
            await identity.provision_with_secret(
                secret=wrong, email=an_email(), password=a_password(), now=at(0)
            )
        assert await store.owner_record_read() is None

    await identity.provision_with_secret(
        secret=secret, email=an_email(), password=a_password(), now=at(1)
    )
    assert await store.owner_record_read() is not None


async def test_the_one_shot_route_refuses_when_no_secret_is_configured(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    """With no secret the route does not exist at all, whatever a caller sends."""
    store = identity_store_factory()
    identity = build_identity(store, low_cost_hashing, signer, bootstrap_secret=None)

    with pytest.raises(errors.NotAuthorized):
        await identity.provision_with_secret(
            secret=a_bootstrap_secret(), email=an_email(), password=a_password(), now=at(0)
        )
    assert await store.owner_record_read() is None


# --- BR3.9: no secret and no owner is a legitimate state -------------------------------- #


async def test_with_no_secret_and_no_owner_the_service_runs_and_refuses_every_sign_in(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    """It does not create an account, and it does not fail to start.

    Auto-creating an account to "make it work" is exactly the default credential FR3.7
    forbids; refusing to start turns a recoverable configuration state into an outage.
    """
    store = identity_store_factory()
    identity = build_identity(store, low_cost_hashing, signer, bootstrap_secret=None)

    assert isinstance(identity, OwnerIdentity)
    for attempt in range(3):
        with pytest.raises(errors.NotAuthorized):
            await identity.sign_in(
                email=an_email(),
                password=a_password(),
                source_address=an_address(),
                now=at(attempt),
            )
    assert await store.owner_record_read() is None


# --- only the hash is stored (BR3.6) ---------------------------------------------------- #


async def test_only_the_argon2id_hash_is_stored_and_the_plaintext_reaches_no_log(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
    caplog: pytest.LogCaptureFixture,
) -> None:
    store = identity_store_factory()
    identity = build_identity(store, low_cost_hashing, signer)
    email = an_email()
    password = a_password()

    with caplog.at_level(logging.DEBUG):
        assert await identity.provision(email=email, password=password, now=at(0)) is True
        with pytest.raises(errors.NotAuthorized) as refusal:
            await identity.provision_with_secret(
                secret=a_bootstrap_secret(), email=email, password=password, now=at(1)
            )

    owner = await store.owner_record_read()
    assert owner is not None
    assert owner.password_hash.startswith("$argon2id$")
    assert password not in owner.password_hash
    assert password not in repr(owner)
    assert password not in caplog.text
    assert password not in str(refusal.value)
    assert owner.password_hash not in caplog.text


async def test_the_owner_id_is_opaque_and_never_derived_from_the_email(
    low_cost_hashing: PasswordHashing, signer: CookieSigner
) -> None:
    """A derivable identifier is a client-assertable identity.

    Not parameterised over the adapters, and deliberately: the identifier is minted by
    this unit **before** any store sees the record, so running this against two
    implementations would assert the same code twice. What it does need is two genuinely
    separate storages, which is why they are constructed here rather than taken from the
    shared factory -- that factory hands out repeated handles onto **one** storage, which
    is exactly what the restart assertions above require of it.

    The realistic wrong implementations are `owner_id = email` and
    `owner_id = digest(email)`; both are checked, because "opaque" is not a property an
    eyeball confirms.
    """
    email = an_email()
    identifiers: set[str] = set()

    for _ in range(3):
        store = InMemoryIdentityStore(MemoryIdentityStorage())
        identity = build_identity(store, low_cost_hashing, signer)
        await identity.provision(email=email, password=a_password(), now=at(0))
        owner = await store.owner_record_read()
        assert owner is not None
        assert owner.owner_id != email
        assert email not in owner.owner_id
        assert email.split("@")[0] not in owner.owner_id
        for digest in _digests_of(email):
            assert digest not in owner.owner_id
        identifiers.add(owner.owner_id)

    # Same address, three provisionings, three different identifiers: nothing about the
    # address is an input to the identifier.
    assert len(identifiers) == 3


def _digests_of(value: str) -> list[str]:
    """The encodings a derived identifier would most plausibly be spelled in."""
    raw = value.encode("utf-8")
    return [
        hashlib.sha256(raw).hexdigest(),
        hashlib.sha1(raw, usedforsecurity=False).hexdigest(),
        hashlib.md5(raw, usedforsecurity=False).hexdigest(),
        base64.urlsafe_b64encode(raw).decode("ascii").rstrip("="),
    ]


async def test_the_hash_is_produced_once_per_provisioning_and_never_re_derived(
    identity_store_factory: Callable[[], IdentityStore],
    recording_hashing: RecordingHashing,
    signer: CookieSigner,
) -> None:
    """The stored string goes to the verifier and nowhere else: it is never re-hashed."""
    store = identity_store_factory()
    identity = build_identity(store, recording_hashing, signer)

    await identity.provision(email=an_email(), password=a_password(), now=at(0))
    assert recording_hashing.hashed == 1
    assert recording_hashing.verified == []


# --- the email constraint ENT-1 declares ------------------------------------------------ #


@pytest.mark.parametrize(
    "unacceptable",
    [
        "no-at-sign",
        "no@domain",
        "spaces in@example.test",
        "@example.test",
        "owner@",
        "",
    ],
)
async def test_provisioning_refuses_an_address_the_entity_model_does_not_admit(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
    unacceptable: str,
) -> None:
    store = identity_store_factory()
    identity = build_identity(store, low_cost_hashing, signer)

    with pytest.raises(errors.Invalid):
        await identity.provision(email=unacceptable, password=a_password(), now=at(0))
    assert await store.owner_record_read() is None


async def test_provisioning_refuses_an_address_over_the_declared_bound(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    store = identity_store_factory()
    identity = build_identity(store, low_cost_hashing, signer)
    over = ("a" * EMAIL_MAX_LENGTH) + "@example.test"
    assert len(over) > EMAIL_MAX_LENGTH

    with pytest.raises(errors.Invalid):
        await identity.provision(email=over, password=a_password(), now=at(0))
    assert await store.owner_record_read() is None


async def test_provisioning_refuses_an_empty_password(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    """An empty password hashes perfectly well and is a credential anyone can supply."""
    store = identity_store_factory()
    identity = build_identity(store, low_cost_hashing, signer)

    with pytest.raises(errors.Invalid):
        await identity.provision(email=an_email(), password="", now=at(0))
    assert await store.owner_record_read() is None


# --- the command-line path -------------------------------------------------------------- #


async def test_the_command_line_path_creates_the_owner_and_reports_success(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    store = identity_store_factory()
    identity = build_identity(store, low_cost_hashing, signer)
    email = an_email()
    password = a_password()

    outcome = await provision_from_command_line(
        identity, email=email, password=password, confirmation=password, now=at(0)
    )

    assert outcome.created is True
    assert outcome.exit_code == 0
    assert password not in outcome.message
    assert await store.owner_record_read() is not None


async def test_the_command_line_path_refuses_when_the_confirmation_differs(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    store = identity_store_factory()
    identity = build_identity(store, low_cost_hashing, signer)
    password = a_password()

    outcome = await provision_from_command_line(
        identity, email=an_email(), password=password, confirmation=a_password(), now=at(0)
    )

    assert outcome.created is False
    assert outcome.exit_code != 0
    assert password not in outcome.message
    assert await store.owner_record_read() is None


async def test_the_command_line_path_reports_an_existing_owner_without_replacing_it(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    store = identity_store_factory()
    identity = build_identity(store, low_cost_hashing, signer)
    original_email = an_email("original")
    original_password = a_password()
    await identity.provision(email=original_email, password=original_password, now=at(0))
    original = await store.owner_record_read()
    assert original is not None

    replacement = a_password()
    outcome = await provision_from_command_line(
        identity,
        email=an_email("replacement"),
        password=replacement,
        confirmation=replacement,
        now=at(1),
    )

    assert outcome.created is False
    assert outcome.exit_code != 0
    unchanged = await store.owner_record_read()
    assert unchanged == original


async def test_the_command_line_path_reports_an_unacceptable_address_without_crashing(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    """The operator gets a message and a non-zero status, not a traceback."""
    store = identity_store_factory()
    identity = build_identity(store, low_cost_hashing, signer)
    password = a_password()

    outcome = await provision_from_command_line(
        identity, email="not-an-address", password=password, confirmation=password, now=at(0)
    )

    assert outcome.created is False
    assert outcome.exit_code != 0
    assert outcome.message
    assert await store.owner_record_read() is None
