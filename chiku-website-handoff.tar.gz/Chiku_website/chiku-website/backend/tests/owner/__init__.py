"""Package marker for U3 `identity-and-session`'s owner-provisioning tests.

Present for the same reason `tests/auth/` carries one: without it pytest's prepend import
mode gives two `conftest` modules the same top-level name and the pre-existing suites
break.
"""
