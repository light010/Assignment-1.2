"""The `AssetStore` contract, in executable form.

Every test here runs against **both** registered implementations.

One assertion in this file is deliberately not about returned bytes. BR22.11 is an
obligation about **transfer volume**: an adapter that reads the whole object and returns
a slice satisfies the signature, returns byte-identical results, and passes every
correctness assertion here -- while making a 50 MB video cost 50 MB of transfer for every
seek. On a metered object store the failure mode is cost and latency, not incorrectness,
so no correctness test catches it. The harness's transfer spy observes what the adapter
asked its underlying store for, which is the only place the difference exists.
"""

from __future__ import annotations

import pytest

from app.assets.store import ObjectNotFound, RangeNotAvailable
from app.content.store import AssetMetadataRecord
from conformance.conftest import AssetHarness, ContentHarness, at

pytestmark = pytest.mark.anyio

# 64 KiB that is not valid UTF-8 and is not compressible into a shape a "helpful" store
# might normalise. Large enough that a whole-object read is a different quantity from a
# window.
OBJECT = bytes(range(256)) * 256


async def test_get_range_returns_exactly_the_requested_window(
    assets: AssetHarness, monkeypatch: pytest.MonkeyPatch
) -> None:
    """BR22.11, BR7.17. A whole-object slice returns the same bytes and passes every other case.

    Offset 0 is included because an off-by-one that only shows at a non-zero offset is
    the easy bug; the final byte is included because a clamp the adapter is forbidden to
    apply would show there first.

    The last two cases are the caller-defect reports. The adapter clamps nothing,
    re-interprets nothing and validates nothing -- every range branch is decided above
    this port -- so a window that does not exist is reported rather than served short,
    because short bytes surface far away as a truncated video with nothing in the logs.
    """
    store = await assets.open_store()
    await store.put("clip.mp4", OBJECT, "video/mp4")

    transferred = assets.install_transfer_spy(monkeypatch)

    assert await store.get_range("clip.mp4", 0, 16) == OBJECT[0:16]
    assert await store.get_range("clip.mp4", 40_000, 4_096) == OBJECT[40_000:44_096]
    assert await store.get_range("clip.mp4", len(OBJECT) - 1, 1) == OBJECT[-1:]

    assert transferred == [16, 4_096, 1]

    with pytest.raises(RangeNotAvailable):
        await store.get_range("clip.mp4", len(OBJECT) - 4, 8)
    with pytest.raises(ObjectNotFound):
        await store.get_range("a-key-that-was-never-written.mp4", 0, 1)


async def test_the_entity_tag_is_stable_for_unchanged_bytes_and_changes_with_them(
    assets: AssetHarness,
) -> None:
    """A per-read tag is visible only to the conditional path, where it is a coin flip.

    `app/assets/ranges.effective_range_header` compares ``If-Range`` against this value by
    exact string equality, so an unstable tag silently suppresses every ranged read and
    re-sends whole videos.

    **Repeated reads are the weak half of this test and are not what it turns on.** Any
    tag computed once at write time and stored beside the object -- including one read off
    a clock, an mtime or an inode -- is stable across reads and across handles. What
    separates a content-derived tag from those is what happens when the **same bytes are
    written again**: a clock or an mtime moves, an inode moves when the file is recreated,
    and a hash of the bytes does not. The re-put and the delete-then-put below are the
    container rebuild and the volume restore, reduced to the two events that reproduce
    them.
    """
    store = await assets.open_store()
    await store.put("cover.png", OBJECT, "image/png")

    first = await store.head("cover.png")
    second = await store.head("cover.png")
    assert first is not None
    assert second is not None
    assert first.etag == second.etag
    assert first.size == len(OBJECT)
    assert first.media_type == "image/png"

    elsewhere = await assets.open_store()
    across_handles = await elsewhere.head("cover.png")
    assert across_handles is not None
    assert across_handles.etag == first.etag

    # Written again, byte-identically: a tag derived from anything but the bytes moves.
    await store.put("cover.png", OBJECT, "image/png")
    rewritten = await elsewhere.head("cover.png")
    assert rewritten is not None
    assert rewritten.etag == first.etag

    # Removed and written again: the object is a different file on disk now, with a
    # different inode and a later mtime, and the same bytes.
    await store.delete("cover.png")
    await store.put("cover.png", OBJECT, "image/png")
    restored = await elsewhere.head("cover.png")
    assert restored is not None
    assert restored.etag == first.etag

    await store.put("cover.png", OBJECT + b"\x00", "image/png")
    changed = await elsewhere.head("cover.png")
    assert changed is not None
    assert changed.etag != first.etag
    assert changed.size == len(OBJECT) + 1

    assert await store.head("a-key-that-was-never-written.png") is None


async def test_delete_is_idempotent_and_deleting_an_absent_key_succeeds(
    assets: AssetHarness,
) -> None:
    """BR22.10, BR6.24. Cleanup paths rarely hit the absent case in a test.

    The cleanup path cannot know how far a failed upload got, so it deletes every key it
    might have written. A delete that raised on an absent key would turn best-effort
    cleanup into a second failure that masks the original error.
    """
    store = await assets.open_store()
    await store.put("scratch.bin", b"x" * 10, "application/pdf")
    assert await store.get("scratch.bin") == b"x" * 10

    await store.delete("scratch.bin")
    assert await store.get("scratch.bin") is None
    assert await store.head("scratch.bin") is None

    await store.delete("scratch.bin")
    await store.delete("a-key-that-was-never-written.bin")


async def test_put_stores_bytes_unchanged_including_bytes_that_are_not_valid_utf8(
    assets: AssetHarness,
) -> None:
    """BR22.6. The store performs no transcoding, re-encoding, normalisation or inspection.

    The five bytes ``%PDF-`` appear in the middle rather than at the start on purpose: the
    store never inspects a byte it is given, and an adapter that sniffed a type from the
    content would be taking a decision the consumer already took.
    """
    store = await assets.open_store()
    awkward = b"\xff\xfe\x00 %PDF- \x80\x81\r\n\x1a" + bytes(range(256))
    await store.put("odd.pdf", awkward, "application/pdf")

    elsewhere = await assets.open_store()
    assert await elsewhere.get("odd.pdf") == awkward
    head = await elsewhere.head("odd.pdf")
    assert head is not None
    assert head.size == len(awkward)
    assert head.media_type == "application/pdf"

    assert await store.get("a-key-that-was-never-written.pdf") is None

    # A zero-byte object is an object, and `head` reports absence differently from size 0.
    await store.put("empty.vtt", b"", "text/vtt")
    assert await elsewhere.get("empty.vtt") == b""
    empty = await elsewhere.head("empty.vtt")
    assert empty is not None
    assert empty.size == 0


async def test_the_object_and_the_metadata_row_hold_the_media_type_independently(
    assets: AssetHarness, content: ContentHarness
) -> None:
    """BR7.18, BR22.12. Reconciling them in an adapter hides the divergence they warn about.

    The serving response's ``Content-Type`` comes from the **metadata row**, while the
    entity tag and size come from the **object**. The two stores hold the media type
    independently and agree only because both were written from the same value at upload
    time -- so anything that syncs only one serves a mismatched type, and an adapter that
    made one read the other would make that condition untestable.
    """
    object_store = await assets.open_store()
    rows = await content.open_store()

    await object_store.put("asset.bin", b"payload", "application/octet-stream")
    await rows.asset_metadata_register(
        AssetMetadataRecord(
            key="asset.bin",
            filename="Poster.webp",
            media_type="image/webp",
            byte_size=7,
            width=1280,
            height=720,
            created_at=at(1),
            derived_from=None,
        )
    )

    head = await object_store.head("asset.bin")
    row = await rows.asset_metadata_read("asset.bin")
    assert head is not None
    assert row is not None
    assert head.media_type == "application/octet-stream"
    assert row.media_type == "image/webp"
    assert head.media_type != row.media_type
