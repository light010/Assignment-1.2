"""The `IdentityStore` contract, in executable form.

Every test here runs against **both** registered implementations.

**Nothing in this file creates a seeded, sample or default credential.** The hash below
is a syntactically shaped argon2id PHC string used as an opaque blob -- it is never
verified against a password, no password exists anywhere in this suite, and the store
never parses, compares or logs it (BR3.6). The acceptance test for the
no-default-credential rule is the first assertion of the provisioning test: a fresh start
against empty storage has no owner record at all.
"""

from __future__ import annotations

from datetime import datetime, timedelta

import anyio
import pytest

from app.auth.store import AttemptScope, IdentityStore, OwnerRecord, SessionRecord
from conformance.conftest import IdentityHarness, at

pytestmark = pytest.mark.anyio

# An opaque blob shaped like an argon2id PHC string. Not a credential: no password
# produces it and nothing in this unit verifies it.
OWNER_HASH = "$argon2id$v=19$m=65536,t=3,p=4$Y29uZm9ybWFuY2U$bm90LWEtcmVhbC1kaWdlc3Q"

SEVEN_DAYS = timedelta(days=7)
FIFTEEN_MINUTES = timedelta(minutes=15)


async def record_failure(
    store: IdentityStore, scope: AttemptScope, key: str, when: datetime
) -> None:
    """`record_failure` at the suite's fixed window length, for readability at the call site."""
    await store.login_attempts_record_failure(scope, key, when, FIFTEEN_MINUTES)


async def count(store: IdentityStore, scope: AttemptScope, key: str, when: datetime) -> int:
    """`count_in_window` at the suite's fixed window length."""
    return await store.login_attempts_count_in_window(scope, key, when, FIFTEEN_MINUTES)


def an_owner(
    owner_id: str, email: str, when: datetime, stored_hash: str = OWNER_HASH
) -> OwnerRecord:
    return OwnerRecord(
        owner_id=owner_id,
        email=email,
        password_hash=stored_hash,
        created_at=when,
        password_updated_at=None,
    )


def a_session(
    session_id: str,
    *,
    issued: datetime,
    last_seen: datetime,
    absolute: datetime,
    pairing: str,
    revoked: datetime | None = None,
) -> SessionRecord:
    return SessionRecord(
        session_id=session_id,
        owner_id="owner-a",
        issued_at=issued,
        last_seen_at=last_seen,
        absolute_expires_at=absolute,
        revoked_at=revoked,
        csrf_token=pairing,
    )


async def test_touch_advances_the_idle_timestamp_and_leaves_the_absolute_bound_alone(
    identity: IdentityHarness,
) -> None:
    """Every idle-expiry test passes whether or not `touch` also refreshed the absolute bound.

    Only this one catches the adapter that "helpfully" refreshes both and destroys the
    seven-day ceiling -- silently, because the session keeps working, which is precisely
    what makes it invisible.
    """
    store = await identity.open_store()
    assert await store.session_read("a-session-that-was-never-issued") is None

    record = a_session(
        "s1", issued=at(0), last_seen=at(0), absolute=at(0) + SEVEN_DAYS, pairing="pair-1"
    )
    await store.session_create(record)
    await store.session_touch("s1", at(600))

    elsewhere = await identity.open_store()
    reread = await elsewhere.session_read("s1")
    assert reread is not None
    assert reread.last_seen_at == at(600)
    assert reread.absolute_expires_at == at(0) + SEVEN_DAYS
    assert reread.issued_at == at(0)
    assert reread.revoked_at is None
    assert reread.csrf_token == record.csrf_token
    assert reread.owner_id == record.owner_id

    # Touching a session that is not there is a no-op; absence is reported by `read`.
    await store.session_touch("a-session-that-was-never-issued", at(700))


async def test_two_concurrent_create_if_absent_calls_yield_one_record_and_one_refusal(
    identity: IdentityHarness,
) -> None:
    """BR3.7, BR22.13. A sequential test never sees this, and a read-then-write passes one.

    The two calls are genuinely concurrent -- two tasks against one store handle, not a
    simulated interleaving. Exactly one must report that it created the record.

    This matters more here than almost anywhere else in the system: the operation can
    never be re-run once it has succeeded, so a lost provisioning on a container with no
    interactive shell leaves a system nobody can sign in to and no route that will let
    them.
    """
    store = await identity.open_store()
    assert await store.owner_record_read() is None  # the store ships no owner, ever

    outcomes: dict[str, bool] = {}
    contenders = [f"owner-{letter}" for letter in "abcdefgh"]

    async def provision(owner_id: str) -> None:
        outcomes[owner_id] = await store.owner_record_create_if_absent(
            an_owner(owner_id, f"{owner_id}@example.test", at(1))
        )

    async with anyio.create_task_group() as tasks:
        for owner_id in contenders:
            tasks.start_soon(provision, owner_id)

    # Exactly one creation and seven refusals, every time. A correct implementation
    # cannot fail this assertion at any interleaving -- the guarantee comes from the
    # statement, not from the schedule.
    #
    # Eight contenders rather than two because the reverse is not true: a read-then-write
    # implementation is only caught when two of them actually overlap, and with two tasks
    # against a store whose reads take microseconds, the first can finish writing before
    # the second finishes reading often enough that the defect slips through. Eight makes
    # a clean serialisation of every pair vanishingly unlikely without making a correct
    # implementation any more likely to fail.
    assert sorted(outcomes.values()) == [False] * 7 + [True], outcomes

    stored = await store.owner_record_read()
    assert stored is not None
    winner = next(owner_id for owner_id, created in outcomes.items() if created)
    assert stored.owner_id == winner
    assert stored.password_hash == OWNER_HASH  # stored verbatim, never parsed
    assert stored.password_updated_at is None

    # One record, not two: repeated reads through independent handles agree on which.
    seen = set()
    for _ in range(4):
        handle = await identity.open_store()
        row = await handle.owner_record_read()
        assert row is not None
        seen.add(row.owner_id)
    assert seen == {stored.owner_id}

    # The gate is the record's EXISTENCE, so a later attempt is refused too -- and would
    # still be refused after a restart, which is why it is not a consumed flag.
    refused = await store.owner_record_create_if_absent(
        an_owner("owner-c", "owner-c@example.test", at(2))
    )
    assert refused is False
    again = await store.owner_record_read()
    assert again is not None
    assert again.owner_id == stored.owner_id


async def test_a_revoked_session_is_revoked_on_the_very_next_read(
    identity: IdentityHarness,
) -> None:
    """BR3.17. A cookie-clearing implementation looks identical from the browser.

    Revocation is a **stored state change**, so a stolen cookie stops working rather than
    merely disappearing from one browser. The store still evaluates nothing: it reports
    `revoked_at` and the consumer is what refuses the session.
    """
    store = await identity.open_store()
    await store.session_create(
        a_session(
            "s1",
            issued=at(0),
            last_seen=at(0),
            absolute=at(0) + SEVEN_DAYS,
            pairing="pair-1",
        )
    )
    live = await store.session_read("s1")
    assert live is not None
    assert live.revoked_at is None

    await store.session_revoke("s1", at(30))

    immediately = await store.session_read("s1")
    assert immediately is not None
    assert immediately.revoked_at == at(30)

    elsewhere = await identity.open_store()
    across_handles = await elsewhere.session_read("s1")
    assert across_handles is not None
    assert across_handles.revoked_at == at(30)
    assert across_handles.last_seen_at == at(0)  # revoking is not touching

    await store.session_revoke("a-session-that-was-never-issued", at(31))


async def test_session_read_evaluates_no_expiry_and_returns_the_record_as_stored(
    identity: IdentityHarness,
) -> None:
    """BR22.14. A store that filtered expired sessions would enforce a rule it does not own.

    The two evaluations -- the store's filter and the consumer's check -- would then drift
    into two different expiry policies with no test that compares them.
    """
    store = await identity.open_store()
    long_expired = a_session(
        "expired",
        issued=at(0),
        last_seen=at(0),
        absolute=at(1),
        pairing="pair-expired",
    )
    await store.session_create(long_expired)

    assert await store.session_read("expired") == long_expired

    # Past both bounds AND revoked, and still returned exactly as stored.
    await store.session_revoke("expired", at(2))
    still_returned = await store.session_read("expired")
    assert still_returned is not None
    assert still_returned.absolute_expires_at == at(1)
    assert still_returned.last_seen_at == at(0)
    assert still_returned.revoked_at == at(2)

    # A record that ARRIVES already revoked is stored as given. The store generates
    # nothing and decides nothing: `revoked_at` is a value the consumer supplies like any
    # other, and an implementation that only ever wrote it through `revoke` would reject
    # or silently drop a record it is required to hold.
    arrives_revoked = a_session(
        "handed-over-revoked",
        issued=at(0),
        last_seen=at(5),
        absolute=at(0) + SEVEN_DAYS,
        pairing="pair-handed-over",
        revoked=at(6),
    )
    await store.session_create(arrives_revoked)
    assert await store.session_read("handed-over-revoked") == arrives_revoked


async def test_the_two_attempt_scopes_count_independently(identity: IdentityHarness) -> None:
    """BR3.22. A one-scope fixture passes whether they are two records or one with two counters.

    The same ``window_key`` is used in both scopes on purpose: an implementation that
    keyed on the subject alone would merge the two counts and still look right in any
    fixture that used different keys.
    """
    store = await identity.open_store()
    subject = "owner@example.test"

    await record_failure(store, "account", subject, at(0))
    await record_failure(store, "account", subject, at(1))
    await record_failure(store, "ip", subject, at(2))

    assert await count(store, "account", subject, at(3)) == 2
    assert await count(store, "ip", subject, at(3)) == 1

    # Clearing the account scope on a successful sign-in leaves the address scope alone.
    await store.login_attempts_clear("account", subject)
    assert await count(store, "account", subject, at(3)) == 0
    assert await count(store, "ip", subject, at(3)) == 1

    # A key that was never counted, and clearing a counter that is not there.
    assert await count(store, "ip", "198.51.100.1", at(3)) == 0
    await store.login_attempts_clear("ip", "198.51.100.1")


async def test_the_counter_compares_against_no_threshold_and_survives_a_new_store_instance(
    identity: IdentityHarness,
) -> None:
    """BR3.22. An in-memory counter is not an acceptable implementation of the real adapter.

    Seven failures is past the consumer's account threshold of five, and the store
    returns a count rather than a verdict: 5 and 20 are the consumer's numbers and a
    store that knew them would be enforcing a rule it does not own.

    The rollover half is the other branch of the same pair: once the window has elapsed
    the count is zero, and the next recorded failure starts a fresh window rather than
    resuming the old total.
    """
    store = await identity.open_store()
    subject = "owner@example.test"
    for n in range(7):
        await record_failure(store, "account", subject, at(n))

    assert await count(store, "account", subject, at(8)) == 7

    later = await identity.open_store()
    assert await count(later, "account", subject, at(8)) == 7

    rolled = at(0) + timedelta(minutes=20)
    assert await count(later, "account", subject, rolled) == 0

    await record_failure(later, "account", subject, rolled)
    assert await count(later, "account", subject, rolled + timedelta(minutes=1)) == 1
