"""Package marker for the conformance suite.

It is here for one mechanical reason, not for style. Without it, pytest's prepend import
mode names both `tests/conftest.py` and `tests/conformance/conftest.py` the top-level
module ``conftest``; whichever loads first wins ``sys.modules["conftest"]``, and the four
pre-existing test modules' ``from conftest import meta`` then resolves to the wrong file
and every one of them fails to collect. With this marker the conformance conftest becomes
``conformance.conftest`` and the collision cannot happen.
"""
