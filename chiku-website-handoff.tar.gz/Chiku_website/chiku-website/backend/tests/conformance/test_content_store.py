"""The `ContentStore` contract, in executable form.

Every test here runs against **both** registered implementations. Where this file and an
adapter disagree, this file arbitrates; where an adapter cannot pass it, the port is
wrong and changes at its owner, not the suite at the adapter (BR22.4).

Each case below was chosen because a **looser** version of it passes while the code is
wrong. That is stated per test rather than assumed, because a test whose failure mode is
not understood is a test that gets relaxed the first time it goes red.

The oracle is `functional-spec.md` § *The conformance suite* and the rules it cites --
not the recorded HTTP fixtures in `chiku-website/fixtures/`, which record behaviour of a
surface this unit does not have.
"""

from __future__ import annotations

from datetime import datetime

import anyio
import pytest

from app.content.store import (
    BASELINE_DRAFT_ID,
    BASELINE_PUBLISHED_ID,
    Action,
    AssetMetadataRecord,
    CommitConflict,
    CommitResult,
    ContentState,
    ContentStore,
    RetentionPolicy,
    listing_cap_for,
)
from conformance.conftest import PRODUCTION_RETENTION, ContentHarness, at

pytestmark = pytest.mark.anyio

# FR4.6's ceiling, in the unit the consumer counts. Astral-plane codepoints and a U+2019
# are in the payload on purpose: a store that re-encoded, normalised or round-tripped
# through a lossy column returns an *equal-looking* document and passes any looser test.
PAYLOAD_CHARS = 1_500_000
_UNIT = "\U0001f600\U00020bb7\u00e9 \u2019 a"


def large_payload() -> str:
    return (_UNIT * (PAYLOAD_CHARS // len(_UNIT) + 1))[:PAYLOAD_CHARS]


def tighter_than(retention: RetentionPolicy, *, drafts: int, publishes: int) -> RetentionPolicy:
    """The same policy with smaller counts. Retention is an argument, never a constant."""
    return RetentionPolicy(
        draft_keep=drafts, publish_keep=publishes, permanent_ids=retention.permanent_ids
    )


async def write(
    store: ContentStore,
    *,
    content: str,
    base_revision: int,
    action: Action,
    marker: str,
    retention: RetentionPolicy,
    now: datetime,
) -> CommitResult:
    """Call `commit`, routing the mutation token through a named local.

    A string literal sitting at a keyword whose name contains `token` is what the
    hardcoded-credential lint rule looks for. Routing the value through a name is
    cheaper and more honest than suppressing that rule at twenty call sites.
    """
    return await store.commit(
        content=content,
        base_revision=base_revision,
        action=action,
        mutation_token=marker,
        retention=retention,
        now=now,
    )


def accepted(result: CommitResult) -> ContentState:
    assert isinstance(result, ContentState), f"expected an accepted write, got {result!r}"
    return result


async def test_read_state_on_empty_storage_returns_the_seed_and_writes_nothing(
    content: ContentHarness,
) -> None:
    """BR4.1. A lazily creating store returns exactly the right values from the first read.

    The one port-level observable that separates the two is the **null `updated_at`** of
    the synthesised seed: the record's column is NOT NULL, so a store that created the
    row on read had to invent an instant, and a second independent handle reads that
    invention back instead of the null. An empty listing is the second half -- a
    bootstrap that ran would have captured the two baselines.
    """
    store = await content.open_store()
    state = await store.read_state()

    assert state.draft == content.seed
    assert state.published == content.seed
    assert state.revision == 0
    assert state.updated_at is None
    assert state.published_at is None

    second = await content.open_store()
    again = await second.read_state()
    assert again.updated_at is None
    assert again.published_at is None
    assert again.revision == 0
    assert again.draft == content.seed
    assert await second.list_revisions() == []


async def test_a_content_payload_round_trips_byte_identically(content: ContentHarness) -> None:
    """BR22.5, BR4.11. A normalising store returns an *equal* document and passes a looser test.

    The revision entry is the second half: BR4.11 requires its content to be read back
    from the record's stored `draft` column and its `created_at` from the record's
    `updated_at`, so the entry is byte-identical to what the write just stored rather
    than to what the caller sent.
    """
    store = await content.open_store()
    payload = large_payload()
    assert len(payload) == PAYLOAD_CHARS

    marker = "write-1"
    state = accepted(
        await write(
            store,
            content=payload,
            base_revision=0,
            action="draft",
            marker=marker,
            retention=PRODUCTION_RETENTION,
            now=at(1),
        )
    )
    assert state.draft == payload
    assert state.published == content.seed  # a draft write does not move `published`
    assert state.published_at is None  # ... nor the publish instant
    assert state.revision == 1

    fresh = await content.open_store()
    reread = await fresh.read_state()
    assert reread.draft.encode("utf-8") == payload.encode("utf-8")
    assert reread.published.encode("utf-8") == content.seed.encode("utf-8")
    assert reread.updated_at == at(1)

    entry = await fresh.read_revision(marker)
    assert entry is not None
    assert entry.content.encode("utf-8") == payload.encode("utf-8")
    assert entry.created_at == state.updated_at
    assert entry.revision == 1
    assert entry.action == "draft"
    assert entry.baseline is False

    # The baselines captured the state BEFORE this write, which on a bootstrap is the seed.
    starting_draft = await fresh.read_revision(BASELINE_DRAFT_ID)
    assert starting_draft is not None
    assert starting_draft.content == content.seed
    assert starting_draft.revision == 0
    assert starting_draft.baseline is True
    assert starting_draft.created_at == at(1)  # the time of CAPTURE, never a guessed date

    assert await fresh.read_revision("a-well-formed-id-that-names-nothing") is None


async def test_a_stale_commit_returns_the_conflict_signal_and_performs_no_side_effect(
    content: ContentHarness,
) -> None:
    """BR4.10, BR4.16. The compare-and-set alone already fails correctly.

    What only this test catches is the **side effects**: a conflicting write that still
    inserted a history entry, still ran a prune, or still moved a timestamp.
    """
    store = await content.open_store()
    first = accepted(
        await write(
            store,
            content='{"v":1}',
            base_revision=0,
            action="draft",
            marker="w1",
            retention=PRODUCTION_RETENTION,
            now=at(1),
        )
    )
    assert first.revision == 1
    state_before = await store.read_state()
    listing_before = await store.list_revisions()

    stale = await write(
        store,
        content='{"v":2}',
        base_revision=0,
        action="publish",
        marker="w2",
        retention=PRODUCTION_RETENTION,
        now=at(2),
    )

    # A return value, not an exception: losing an optimistic race is an ordinary outcome.
    assert isinstance(stale, CommitConflict)
    assert await store.read_state() == state_before
    assert await store.list_revisions() == listing_before
    assert await store.read_revision("w2") is None


async def test_a_stale_writer_whose_next_revision_collides_inserts_nothing_and_prunes_nothing(
    content: ContentHarness,
) -> None:
    """BR4.13 -- the ABA defence, and the one behaviour never reproduced single-user.

    Statements 4 to 6 are guarded on ``revision = base_revision + 1``, **a value that is
    not unique to the writer**: when the winner advances the document to that very
    number, a loser's guard is satisfied by the winner's write. Without the mutation
    token the loser would insert a history entry carrying the winner's content under the
    loser's own action, and would run a retention pass it was never entitled to run.

    Nothing errors and nothing logs when this is wrong. The history list grows a row the
    owner never saved, or loses one it should have kept.

    Two halves. The first races two writers at one base revision, genuinely concurrently,
    and asserts the invariant that holds whichever wins. The second issues a further
    stale write whose ``next_revision`` collides with the document's current revision and
    whose retention policy is tight enough that a prune running off the back of the
    winner's write would be unmistakable.
    """
    store = await content.open_store()
    for n in range(1, 5):
        accepted(
            await write(
                store,
                content=f'{{"v":{n}}}',
                base_revision=n - 1,
                action="draft",
                marker=f"w{n}",
                retention=PRODUCTION_RETENTION,
                now=at(n),
            )
        )
    before = [summary.id for summary in await store.list_revisions()]
    assert len(before) == 6  # four entries plus the two baselines

    results: dict[str, CommitResult] = {}

    async def racer(marker: str, when: int) -> None:
        results[marker] = await write(
            store,
            content=f'{{"racer":"{marker}"}}',
            base_revision=4,
            action="draft",
            marker=marker,
            retention=PRODUCTION_RETENTION,
            now=at(when),
        )

    async with anyio.create_task_group() as tasks:
        tasks.start_soon(racer, "race-a", 10)
        tasks.start_soon(racer, "race-b", 11)

    winners = [marker for marker, r in results.items() if isinstance(r, ContentState)]
    losers = [marker for marker, r in results.items() if isinstance(r, CommitConflict)]
    assert len(winners) == 1, results
    assert len(losers) == 1, results

    after = [summary.id for summary in await store.list_revisions()]
    assert set(after) == set(before) | {winners[0]}
    assert await store.read_revision(losers[0]) is None

    listing_before_stale = await store.list_revisions()
    late = await write(
        store,
        content='{"v":"late"}',
        base_revision=4,
        action="draft",
        marker="late",
        retention=tighter_than(PRODUCTION_RETENTION, drafts=1, publishes=1),
        now=at(12),
    )
    assert isinstance(late, CommitConflict)
    assert await store.read_revision("late") is None
    assert await store.list_revisions() == listing_before_stale


async def test_the_listing_returns_the_full_three_part_order_including_a_tied_revision(
    content: ContentHarness,
) -> None:
    """BR5.1, BR5.2, BR5.3, BR22.2, BR22.3.

    The two baselines are the tie: both sit at the revision the document held when they
    were captured, and both are baselines, so only the third sort part separates them --
    ``action`` DESC, which puts `publish` before `draft`. A single-key sort is identical
    to the correct one until exactly that point, and a fake that returned its container's
    insertion order would put the baselines first and the tie the wrong way round.

    The cap is the second half. 52 is ``30 + 20 + 2`` *by construction* (BR5.3), which is
    what `listing_cap_for` asserts; and the listing is a single capped result, never a
    page -- a cursor over an order with ties can repeat or skip an entry at a boundary.
    """
    store = await content.open_store()
    plan: tuple[tuple[str, int, Action], ...] = (
        ("e1", 0, "publish"),
        ("e2", 1, "draft"),
        ("e3", 2, "publish"),
    )
    for marker, base, action in plan:
        accepted(
            await write(
                store,
                content=f'{{"id":"{marker}"}}',
                base_revision=base,
                action=action,
                marker=marker,
                retention=PRODUCTION_RETENTION,
                now=at(base + 1),
            )
        )

    listing = await store.list_revisions()
    assert [summary.id for summary in listing] == [
        "e3",
        "e2",
        "e1",
        BASELINE_PUBLISHED_ID,
        BASELINE_DRAFT_ID,
    ]
    assert [summary.revision for summary in listing] == [3, 2, 1, 0, 0]

    tied = [summary for summary in listing if summary.revision == 0]
    assert [summary.action for summary in tied] == ["publish", "draft"]
    assert [summary.baseline for summary in tied] == [True, True]
    assert [summary.baseline for summary in listing[:3]] == [False, False, False]

    assert listing_cap_for(PRODUCTION_RETENTION) == 52
    capped = await content.open_store_with_cap(3)
    assert [summary.id for summary in await capped.list_revisions()] == ["e3", "e2", "e1"]


async def test_the_two_retention_counts_are_independent(content: ContentHarness) -> None:
    """BR5.7, BR22.1. A combined cap looks correct until the mix is uneven.

    One publish followed by five drafts under ``keep 3 drafts, keep 2 publishes``. With
    the counts applied independently the publish survives. With a single combined cap of
    five -- the same two numbers added together -- the publish holds the lowest revision
    of the six and is the first thing evicted.
    """
    store = await content.open_store()
    retention = tighter_than(PRODUCTION_RETENTION, drafts=3, publishes=2)
    accepted(
        await write(
            store,
            content='{"p":1}',
            base_revision=0,
            action="publish",
            marker="p1",
            retention=retention,
            now=at(1),
        )
    )
    for n in range(1, 6):
        accepted(
            await write(
                store,
                content=f'{{"d":{n}}}',
                base_revision=n,
                action="draft",
                marker=f"d{n}",
                retention=retention,
                now=at(10 + n),
            )
        )

    listing = await store.list_revisions()
    drafts = [s.id for s in listing if s.action == "draft" and not s.baseline]
    publishes = [s.id for s in listing if s.action == "publish" and not s.baseline]
    assert publishes == ["p1"]
    assert drafts == ["d5", "d4", "d3"]


async def test_both_baselines_survive_a_prune_that_ordering_alone_would_not_have_spared(
    content: ContentHarness,
) -> None:
    """BR5.8, BR22.1. Baselines are excluded by the delete **predicate**, not by sorting high.

    The two baselines carry the **lowest** revision in the store -- the revision the
    document held before the first write -- so ordering never spares them: it is what
    would reach them first. Under ``keep 1`` of each action, an implementation that
    selected survivors without the non-baseline predicate deletes both, and the capture
    is once-ever, so nothing can recreate them.
    """
    store = await content.open_store()
    retention = tighter_than(PRODUCTION_RETENTION, drafts=1, publishes=1)
    plan: tuple[tuple[str, int, Action], ...] = (
        ("p1", 0, "publish"),
        ("d1", 1, "draft"),
        ("p2", 2, "publish"),
        ("d2", 3, "draft"),
    )
    for marker, base, action in plan:
        accepted(
            await write(
                store,
                content=f'{{"id":"{marker}"}}',
                base_revision=base,
                action=action,
                marker=marker,
                retention=retention,
                now=at(base + 1),
            )
        )

    listing = await store.list_revisions()
    assert [summary.id for summary in listing] == [
        "d2",
        "p2",
        BASELINE_PUBLISHED_ID,
        BASELINE_DRAFT_ID,
    ]
    starting_published = await store.read_revision(BASELINE_PUBLISHED_ID)
    starting_draft = await store.read_revision(BASELINE_DRAFT_ID)
    assert starting_published is not None
    assert starting_draft is not None
    assert starting_published.content == content.seed
    assert starting_draft.content == content.seed
    assert starting_published.baseline is True
    assert starting_draft.baseline is True


async def test_asset_metadata_registers_reads_and_removes_idempotently(
    content: ContentHarness,
) -> None:
    """BR22.10, BR22.6. Cleanup paths rarely hit the absent case in a test.

    `asset_metadata.remove` exists for the best-effort cleanup of a failed or cancelled
    upload and for no other purpose, and the cleanup path cannot know how far the failed
    write got. A remove that raised on an absent key would turn that cleanup into a
    second failure masking the first.
    """
    store = await content.open_store()
    original = AssetMetadataRecord(
        key="1f3b9c2e-0d4a-4c5b-9a7e-2b6d8c1f0a35.mp4",
        filename="Keynote recording.mp4",
        media_type="video/mp4",
        byte_size=188_618,
        width=None,
        height=None,
        created_at=at(1),
        derived_from=None,
    )
    variant = AssetMetadataRecord(
        key="9c0e4a11-77bd-4f2a-8d31-5e6f0a2b7c84.webp",
        filename="Keynote poster.webp",
        media_type="image/webp",
        byte_size=20_480,
        width=1280,
        height=720,
        created_at=at(2),
        derived_from=original.key,
    )

    assert await store.asset_metadata_read(original.key) is None
    await store.asset_metadata_register(original)
    await store.asset_metadata_register(variant)

    elsewhere = await content.open_store()
    assert await elsewhere.asset_metadata_read(original.key) == original
    assert await elsewhere.asset_metadata_read(variant.key) == variant

    await store.asset_metadata_remove("a-key-that-was-never-stored.bin")
    await store.asset_metadata_remove(original.key)
    await store.asset_metadata_remove(original.key)

    assert await elsewhere.asset_metadata_read(original.key) is None
    assert await elsewhere.asset_metadata_read(variant.key) == variant
