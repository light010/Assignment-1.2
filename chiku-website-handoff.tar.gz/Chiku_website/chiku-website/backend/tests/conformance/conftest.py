"""The adapter parameterisation: the one place a new adapter is registered.

One suite per port, run against **three implementations** -- the locally verified adapter,
an in-memory fake, and the Google Cloud adapter. Two was the minimum that proves the suite
tests the **port** rather than the storage engine, and that is the whole argument for
having a port (BR22.4); the third is U11 `cloud-adapters`, and registering it here is the
whole of that unit's executable evidence.

**The cloud adapters are UNVERIFIED against the real services.** Passing this suite proves
they satisfy the port's contract as this file expresses it, against an in-process fake. It
does not prove they work against Firestore or Cloud Storage: nothing in this workflow
executes them against either service (BR31.5).

Registering a new adapter is a one-line change to the ``params`` list of the fixture for
its port, and that immediately subjects it to the whole contract. A test written against
a single implementation is outside this suite's purpose and does not belong here.

**The in-memory fake is not a mock.** It is a second real implementation of the port and
it is under test exactly as the verified adapter is. Nothing in this suite mocks a store:
mocking a store in its own conformance suite would assert the test's belief about the
store rather than the store.

Each harness hands out a *factory* rather than a store, because several of the assertions
that matter need **a second, independent handle over the same storage** -- that a read
wrote nothing, that a counter is durable rather than held in a process. A fixture that
yielded one store object could not express either.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest

from app.assets import store_memory as asset_memory
from app.assets import store_volume
from app.assets.store import AssetStore
from app.assets.store_memory import InMemoryAssetStore, MemoryAssetStorage
from app.assets.store_volume import VolumeAssetStore
from app.auth.store import IdentityStore
from app.auth.store_memory import InMemoryIdentityStore, MemoryIdentityStorage
from app.auth.store_sqlite import SqliteIdentityStore
from app.content.store import (
    BASELINE_DRAFT_ID,
    BASELINE_PUBLISHED_ID,
    ContentStore,
    RetentionPolicy,
    listing_cap_for,
)
from app.content.store_memory import InMemoryContentStore, MemoryContentStorage
from app.content.store_sqlite import SqliteContentStore
from app.sqlite import SqliteDatabase
from cloud import fake_gcs
from cloud.harness import CloudHarness

# The seed carries a U+2019 curly apostrophe and an astral-plane codepoint on purpose:
# every test that touches the seed then also exercises the byte-identity obligation of
# BR22.5, and a store that re-encoded on the way through would fail far more than one
# test.
SEED = '{"hero":{"title":"Chiku"},"note":"seed \u2019 \U0001f600"}'

# The production policy. 52 is `30 + 20 + 2` BY CONSTRUCTION (BR5.3) -- `listing_cap_for`
# is that construction, which is why the cap is derived here rather than written down.
PRODUCTION_RETENTION = RetentionPolicy(
    draft_keep=30,
    publish_keep=20,
    permanent_ids=(BASELINE_PUBLISHED_ID, BASELINE_DRAFT_ID),
)
DEFAULT_LISTING_CAP = listing_cap_for(PRODUCTION_RETENTION)

_EPOCH = datetime(2026, 9, 24, 12, 0, 0, tzinfo=UTC)


def at(seconds: int) -> datetime:
    """A distinct, ordered instant. `commit` takes ``now`` from its caller, never a clock."""
    return _EPOCH + timedelta(seconds=seconds)


@pytest.fixture
def anyio_backend() -> str:
    """Pinned to asyncio alone.

    The production runtime is asyncio, and running the whole suite a second time under
    trio would double its cost for no new evidence about the ports.
    """
    return "asyncio"


@dataclass(frozen=True)
class ContentHarness:
    """One registered `ContentStore` implementation and the storage it is backed by."""

    name: str
    seed: str
    open_store: Callable[[], Awaitable[ContentStore]]
    open_store_with_cap: Callable[[int], Awaitable[ContentStore]]


@dataclass(frozen=True)
class IdentityHarness:
    """One registered `IdentityStore` implementation and the storage it is backed by."""

    name: str
    open_store: Callable[[], Awaitable[IdentityStore]]


@dataclass(frozen=True)
class AssetHarness:
    """One registered `AssetStore` implementation and the storage it is backed by.

    ``install_transfer_spy`` is the seam that makes BR22.11 assertable. That obligation is
    about **transfer volume**, and transfer volume is invisible to an assertion on the
    returned bytes: a whole-object read followed by a slice returns byte-identical
    results and passes every correctness test in this file. The spy records what the
    adapter asked its underlying store for, which is the only place the difference exists.
    It observes a boundary; it does not stand in for the store under test.
    """

    name: str
    open_store: Callable[[], Awaitable[AssetStore]]
    install_transfer_spy: Callable[[pytest.MonkeyPatch], list[int]]


@pytest.fixture(params=["sqlite", "memory", "firestore"])
async def content(request: pytest.FixtureRequest, tmp_path: Path) -> ContentHarness:
    """Register a `ContentStore` implementation here to subject it to the whole contract."""
    adapter = str(request.param)

    if adapter == "firestore":
        cloud = CloudHarness()

        async def open_firestore_with_cap(cap: int) -> ContentStore:
            return cloud.content_store(seed=SEED, listing_cap=cap)

        async def open_firestore() -> ContentStore:
            return await open_firestore_with_cap(DEFAULT_LISTING_CAP)

        return ContentHarness(adapter, SEED, open_firestore, open_firestore_with_cap)

    if adapter == "sqlite":
        # A real file, not `:memory:`. `:memory:` gives each connection its own private
        # database, which would hide exactly the cross-handle behaviour the "writes
        # nothing" and durability assertions depend on.
        path = tmp_path / "content.sqlite3"
        await SqliteDatabase(path).initialize()

        async def open_sqlite_with_cap(cap: int) -> ContentStore:
            return SqliteContentStore(SqliteDatabase(path), seed=SEED, listing_cap=cap)

        async def open_sqlite() -> ContentStore:
            return await open_sqlite_with_cap(DEFAULT_LISTING_CAP)

        return ContentHarness(adapter, SEED, open_sqlite, open_sqlite_with_cap)

    storage = MemoryContentStorage()

    async def open_memory_with_cap(cap: int) -> ContentStore:
        return InMemoryContentStore(storage, seed=SEED, listing_cap=cap)

    async def open_memory() -> ContentStore:
        return await open_memory_with_cap(DEFAULT_LISTING_CAP)

    return ContentHarness(adapter, SEED, open_memory, open_memory_with_cap)


@pytest.fixture(params=["sqlite", "memory", "firestore"])
async def identity(request: pytest.FixtureRequest, tmp_path: Path) -> IdentityHarness:
    """Register an `IdentityStore` implementation here.

    No fixture in this suite creates an owner record, a seed credential or a sample
    password. The acceptance test for the no-default-credential rule is exactly that a
    fresh start against empty storage has no account anyone can sign in to.
    """
    adapter = str(request.param)

    if adapter == "firestore":
        cloud = CloudHarness()

        async def open_firestore() -> IdentityStore:
            return cloud.identity_store()

        return IdentityHarness(adapter, open_firestore)

    if adapter == "sqlite":
        path = tmp_path / "identity.sqlite3"
        await SqliteDatabase(path).initialize()

        async def open_sqlite() -> IdentityStore:
            return SqliteIdentityStore(SqliteDatabase(path))

        return IdentityHarness(adapter, open_sqlite)

    storage = MemoryIdentityStorage()

    async def open_memory() -> IdentityStore:
        return InMemoryIdentityStore(storage)

    return IdentityHarness(adapter, open_memory)


def _spy_on_volume_reads(monkeypatch: pytest.MonkeyPatch) -> list[int]:
    lengths: list[int] = []
    real = store_volume.read_window

    def recording(path: Path, offset: int, length: int) -> bytes:
        lengths.append(length)
        return real(path, offset, length)

    monkeypatch.setattr(store_volume, "read_window", recording)
    return lengths


def _spy_on_memory_reads(monkeypatch: pytest.MonkeyPatch) -> list[int]:
    lengths: list[int] = []
    real = MemoryAssetStorage.read_window

    def recording(this: MemoryAssetStorage, key: str, offset: int, length: int) -> bytes:
        lengths.append(length)
        return real(this, key, offset, length)

    monkeypatch.setattr(asset_memory.MemoryAssetStorage, "read_window", recording)
    return lengths


def _spy_on_gcs_reads(monkeypatch: pytest.MonkeyPatch) -> list[int]:
    """Record how many bytes each download actually handed back.

    The length of the RETURNED bytes rather than of the requested window, because that is
    the quantity BR22.11 is about: an adapter that downloads the whole object and slices
    it returns byte-identical results and passes every correctness assertion here, and the
    only place the difference exists is in what crossed the boundary.
    """
    lengths: list[int] = []
    real = fake_gcs.FakeBlob.download_as_bytes

    def recording(
        this: fake_gcs.FakeBlob, start: int | None = None, end: int | None = None
    ) -> bytes:
        data = real(this, start, end)
        lengths.append(len(data))
        return data

    monkeypatch.setattr(fake_gcs.FakeBlob, "download_as_bytes", recording)
    return lengths


@pytest.fixture(params=["volume", "memory", "gcs"])
async def assets(request: pytest.FixtureRequest, tmp_path: Path) -> AssetHarness:
    """Register an `AssetStore` implementation here."""
    adapter = str(request.param)

    if adapter == "gcs":
        cloud = CloudHarness()

        async def open_gcs() -> AssetStore:
            return cloud.asset_store()

        return AssetHarness(adapter, open_gcs, _spy_on_gcs_reads)

    if adapter == "volume":
        root = tmp_path / "objects"

        async def open_volume() -> AssetStore:
            return VolumeAssetStore(root)

        return AssetHarness(adapter, open_volume, _spy_on_volume_reads)

    storage = MemoryAssetStorage()

    async def open_memory() -> AssetStore:
        return InMemoryAssetStore(storage)

    return AssetHarness(adapter, open_memory, _spy_on_memory_reads)
