"""Fixtures for U3 `identity-and-session`.

**Nothing here mocks `IdentityStore`.** Both implementations below are real
implementations already under their own conformance suite; mocking one would assert this
unit's belief about the store rather than the store, and the two assertions that matter
most -- that a counter survives a new handle, and that a restart cannot reopen the
provisioning gate -- are exactly the ones a mock would answer from the test's own
expectations.

`RecordingIdentityStore` and `RecordingHashing` are **observation seams, not stand-ins**.
Each delegates every call to a real collaborator and records that it happened; neither
answers anything itself. They exist because two of this unit's rules are about the
**order and the presence of operations** rather than about a returned value: BR23.1's
"a verification always runs" and *Sign in* step 1's "both windows are read before the
owner lookup". Both are invisible to any assertion on the result -- a sign-in that skips
the hash for an unknown account returns the identical refusal.

A **factory** is handed out rather than a store, because several assertions need a
second, independent handle over the same storage. A fixture yielding one store object
could not express "a restart does not reset this".

**Time is a caller argument throughout**, never a module-level clock. `at()` produces
ordered instants and the expiry tests advance it rather than sleeping; nothing in this
unit reads a clock and nothing in this directory asserts on wall-clock duration.

**argon2 is deliberately slow, and the production cost is a security setting rather than
a test knob.** `low_cost_hashing` builds a `PasswordHashing` over a deliberately weak
`PasswordHasher`; `app.auth.hashing.production_hashing()` is untouched by it. Weakening
the production parameters to make the suite fast would weaken the product.

**No password in this directory is a constant.** `a_password()` generates one per call,
so nothing here can be mistaken for -- or promoted into -- a default credential.
"""

from __future__ import annotations

import secrets
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest
from argon2 import PasswordHasher

from app.auth.guard import WINDOW_LENGTH, LoginGuard
from app.auth.hashing import PasswordHashing, low_cost_hasher
from app.auth.sessions import SessionAuthority
from app.auth.store import (
    AttemptScope,
    IdentityStore,
    OwnerRecord,
    SessionRecord,
)
from app.auth.store_memory import InMemoryIdentityStore, MemoryIdentityStorage
from app.auth.store_sqlite import SqliteIdentityStore
from app.auth.tokens import CookieSigner
from app.owner.identity import OwnerIdentity
from app.sqlite import SqliteDatabase

_EPOCH = datetime(2026, 9, 25, 9, 0, 0, tzinfo=UTC)


@pytest.fixture
def anyio_backend() -> str:
    """Pinned to asyncio alone; the production runtime is asyncio."""
    return "asyncio"


def at(seconds: float) -> datetime:
    """A distinct, ordered instant. Every operation in this unit takes ``now``."""
    return _EPOCH + timedelta(seconds=seconds)


def hours(count: float) -> float:
    """Seconds, spelled in hours, for the idle-bound arithmetic."""
    return count * 3600.0


def days(count: float) -> float:
    """Seconds, spelled in days, for the absolute-bound arithmetic."""
    return count * 86400.0


def a_password() -> str:
    """A fresh password, generated per call.

    Never a literal and never shared: a committed constant in a test is one careless
    copy away from becoming the default credential BR3.10 forbids.
    """
    return secrets.token_urlsafe(18)


def a_signing_key() -> str:
    """A signing key of the shape the deployment rules require -- generated, never chosen."""
    return secrets.token_urlsafe(64)


def a_bootstrap_secret() -> str:
    """A bootstrap secret, generated per call for the same reason as `a_password`."""
    return secrets.token_urlsafe(24)


def an_email(local: str = "owner") -> str:
    """An address that satisfies ENT-1's pattern without naming a real person."""
    return f"{local}-{secrets.token_hex(4)}@example.test"


def an_address(last: int = 7) -> str:
    """A source address. Distinct per test so no window is shared by accident."""
    return f"198.51.100.{last}"


@pytest.fixture
def signer() -> CookieSigner:
    """A signer over a freshly generated key, as production builds one."""
    return CookieSigner(a_signing_key())


@pytest.fixture
def low_cost_hashing() -> PasswordHashing:
    """argon2id at parameters chosen for the suite's clock, not for production.

    The dummy hash is produced by *this* hasher, so BR23.1's equal-cost property holds
    inside the test at the test's cost -- which is the property under test. The absolute
    number of milliseconds is asserted nowhere.
    """
    return PasswordHashing(low_cost_hasher())


class RecordingHashing(PasswordHashing):
    """A `PasswordHashing` that also remembers which stored hash it was asked to verify.

    This is the only way to observe BR23.1. "A verification always runs" has no effect on
    any return value: the refusal is byte-identical either way, and the difference is a
    measurable duration that no honest test asserts on. What can be asserted is the code
    path, which is what this records.
    """

    def __init__(self, hasher: PasswordHasher) -> None:
        super().__init__(hasher)
        self.verified: list[str] = []
        self.hashed: int = 0

    async def hash_password(self, password: str) -> str:
        self.hashed += 1
        return await super().hash_password(password)

    async def verify_password(self, stored_hash: str, password: str) -> bool:
        self.verified.append(stored_hash)
        return await super().verify_password(stored_hash, password)


@pytest.fixture
def recording_hashing() -> RecordingHashing:
    return RecordingHashing(low_cost_hasher())


@dataclass(frozen=True, slots=True)
class StoreCall:
    """One operation that reached the store, and the key it reached it with."""

    operation: str
    scope: AttemptScope | None = None
    key: str | None = None


class RecordingIdentityStore:
    """An observation seam over a **real** `IdentityStore`. Not a mock.

    Every call is delegated and its result returned unchanged; the only addition is an
    ordered record of what was asked for. *Sign in* step 1's ordering rule -- both
    windows read **before** the owner lookup, keyed on the normalised submitted email --
    is a statement about that sequence and about nothing the caller can see, so the
    sequence is what a test has to reach.
    """

    def __init__(self, inner: IdentityStore) -> None:
        self._inner = inner
        self.calls: list[StoreCall] = []

    @property
    def operations(self) -> list[str]:
        return [call.operation for call in self.calls]

    async def owner_record_read(self) -> OwnerRecord | None:
        self.calls.append(StoreCall("owner_record_read"))
        return await self._inner.owner_record_read()

    async def owner_record_create_if_absent(self, record: OwnerRecord) -> bool:
        self.calls.append(StoreCall("owner_record_create_if_absent"))
        return await self._inner.owner_record_create_if_absent(record)

    async def session_create(self, record: SessionRecord) -> None:
        self.calls.append(StoreCall("session_create"))
        await self._inner.session_create(record)

    async def session_read(self, session_id: str) -> SessionRecord | None:
        self.calls.append(StoreCall("session_read"))
        return await self._inner.session_read(session_id)

    async def session_touch(self, session_id: str, now: datetime) -> None:
        self.calls.append(StoreCall("session_touch"))
        await self._inner.session_touch(session_id, now)

    async def session_revoke(self, session_id: str, now: datetime) -> None:
        self.calls.append(StoreCall("session_revoke"))
        await self._inner.session_revoke(session_id, now)

    async def login_attempts_record_failure(
        self,
        scope: AttemptScope,
        window_key: str,
        now: datetime,
        window_length: timedelta,
    ) -> None:
        self.calls.append(StoreCall("login_attempts_record_failure", scope, window_key))
        await self._inner.login_attempts_record_failure(scope, window_key, now, window_length)

    async def login_attempts_count_in_window(
        self,
        scope: AttemptScope,
        window_key: str,
        now: datetime,
        window_length: timedelta,
    ) -> int:
        self.calls.append(StoreCall("login_attempts_count_in_window", scope, window_key))
        return await self._inner.login_attempts_count_in_window(
            scope, window_key, now, window_length
        )

    async def login_attempts_clear(self, scope: AttemptScope, window_key: str) -> None:
        self.calls.append(StoreCall("login_attempts_clear", scope, window_key))
        await self._inner.login_attempts_clear(scope, window_key)


async def count_failures(store: IdentityStore, scope: AttemptScope, key: str, now: datetime) -> int:
    """The raw count the store holds, at this unit's window length.

    The store returns a **count**, never a verdict: the thresholds live in `LoginGuard`
    and this helper is what lets a test see the difference.
    """
    return await store.login_attempts_count_in_window(scope, key, now, WINDOW_LENGTH)


def build_identity(
    store: IdentityStore,
    hashing: PasswordHashing,
    signer: CookieSigner,
    *,
    bootstrap_secret: str | None = None,
) -> OwnerIdentity:
    """`OwnerIdentity` wired the way production wires it, over a real store."""
    return OwnerIdentity(
        store=store,
        hashing=hashing,
        sessions=SessionAuthority(store, signer),
        guard=LoginGuard(store),
        bootstrap_secret=bootstrap_secret,
    )


@pytest.fixture(params=["memory", "sqlite"])
async def identity_store_factory(
    request: pytest.FixtureRequest, tmp_path: Path
) -> Callable[[], IdentityStore]:
    """Both real implementations, so no assertion here is an accident of one of them.

    A **factory**, because "a restart does not reset this" and "a restart cannot reopen
    the gate" are only expressible with a second handle over the same storage.
    """
    if request.param == "memory":
        storage = MemoryIdentityStorage()

        def open_memory() -> IdentityStore:
            return InMemoryIdentityStore(storage)

        return open_memory

    # A real file, not `:memory:`: `:memory:` gives each connection its own private
    # database, which would remove both the durability and the contention these tests
    # exist to produce.
    path = tmp_path / "identity.sqlite3"
    await SqliteDatabase(path).initialize()

    def open_sqlite() -> IdentityStore:
        return SqliteIdentityStore(SqliteDatabase(path))

    return open_sqlite
