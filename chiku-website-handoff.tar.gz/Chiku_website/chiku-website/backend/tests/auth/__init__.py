"""Package marker for U3 `identity-and-session`'s auth tests.

Present for the same reason `tests/conformance/`, `tests/cloud/` and `tests/content/`
carry one: under pytest's prepend import mode a directory without it contributes its
`conftest` under the bare top-level name `conftest`, which collides with the root
`tests/conftest.py` and breaks every suite that already imports it.
"""
