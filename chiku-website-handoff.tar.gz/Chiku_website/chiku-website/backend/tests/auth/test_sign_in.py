"""HAZARD -- sign-in, its step order, and the timing equality that holds it up.

**There is no oracle for this file.** The source authenticated through a vendored
dev-server middleware that injected a fixed identity as request headers, and no fixture of
that behaviour exists or can be made. Every expectation below is read off
`functional-spec.md` § *Sign in* and `rules.md` BR3.6, BR3.18-BR3.22 and BR23.1, and each
asserts the **property** rather than whatever implementation is in front of it.

**Two of the properties here are invisible to the obvious test, and both get one designed
to fail if the behaviour is done the easy way.**

* **BR23.1 -- a verification always runs.** A sign-in against a non-existent account that
  returns without hashing anything produces a byte-identical refusal and returns
  measurably faster; argon2id is *deliberately* slow, so the gap is large rather than
  marginal, and an attacker who can time two requests learns which email is the owner's
  without a single byte of the response differing. The assertion here is on the **code
  path** -- which stored hash the verifier was handed -- because a wall-clock assertion
  would be flaky and would prove less.
* **Step 1 reads both windows before the owner lookup, and does not return early.** An
  early return on an exhausted window skips the hash and restores exactly the timing
  difference BR23.1 removes, while leaving every response-shape test green. The assertion
  is on the **ordered sequence of store operations**, for the same reason.

**The three refusals are one refusal.** Unknown account, wrong password and
limit-already-reached raise the same member with the same message and the same extras.
There is no `Retry-After`, no "too many attempts" and no remaining-attempts count --
with exactly one account in the system, any of the three tells an attacker the email they
submitted is the owner's, which is the single fact the whole enumeration defence exists to
withhold.
"""

from __future__ import annotations

import logging
from collections.abc import Callable

import pytest

from app import errors
from app.auth.guard import ACCOUNT_FAILURE_LIMIT, ADDRESS_FAILURE_LIMIT, WINDOW_LENGTH
from app.auth.hashing import (
    PasswordHashing,
    low_cost_hasher,
    production_hasher,
    production_hashing,
)
from app.auth.store import IdentityStore
from app.auth.tokens import CookieSigner
from app.owner.identity import OwnerIdentity
from auth.conftest import (
    RecordingHashing,
    RecordingIdentityStore,
    a_password,
    an_address,
    an_email,
    at,
    build_identity,
    count_failures,
)

pytestmark = pytest.mark.anyio


async def provisioned(
    store: IdentityStore,
    hashing: PasswordHashing,
    signer: CookieSigner,
    *,
    email: str,
    password: str,
) -> OwnerIdentity:
    """An `OwnerIdentity` with exactly one owner, created through the real gate."""
    identity = build_identity(store, hashing, signer)
    created = await identity.provision(email=email, password=password, now=at(0))
    assert created
    return identity


async def exhaust_account_window(store: IdentityStore, account_key: str, start: float = 0) -> None:
    """Fill the account-scoped window to its limit, through the real store.

    `start` exists so a caller that has already recorded failures can keep every
    instant inside one rolling window and in order, rather than reaching backwards.
    """
    for index in range(ACCOUNT_FAILURE_LIMIT):
        await store.login_attempts_record_failure(
            "account", account_key, at(start + index), WINDOW_LENGTH
        )


# --- the three refusals are one refusal (BR3.20, BR3.6) ------------------------------- #


async def test_the_three_refusals_are_indistinguishable(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    """Unknown account, wrong password, limit reached: same member, same body, no hints.

    The three cases are staged on **one live system**, in sequence, rather than on three
    separately-constructed ones: the point is that an attacker walking a single service
    through all three states cannot tell the states apart, and three isolated fixtures
    would compare three refusals that never coexisted.

    The limit case deliberately supplies the **correct** password, so what is being
    compared is the refusal itself rather than a second credential failure.
    """
    store = identity_store_factory()
    identity = build_identity(store, low_cost_hashing, signer)
    address = an_address()
    email = an_email()
    password = a_password()

    # (a) no owner record at all.
    with pytest.raises(errors.NotAuthorized) as unknown_refusal:
        await identity.sign_in(email=email, password=password, source_address=address, now=at(10))

    # (b) the owner now exists; the password is wrong.
    assert await identity.provision(email=email, password=password, now=at(11)) is True
    with pytest.raises(errors.NotAuthorized) as wrong_refusal:
        await identity.sign_in(
            email=email, password=a_password(), source_address=address, now=at(12)
        )

    # (c) the owner exists, the password is right, and the window is already full.
    await exhaust_account_window(store, email.strip().lower(), start=13)
    with pytest.raises(errors.NotAuthorized) as limited_refusal:
        await identity.sign_in(email=email, password=password, source_address=address, now=at(18))

    raised = [unknown_refusal.value, wrong_refusal.value, limited_refusal.value]
    bodies = [errors.envelope(refusal) for refusal in raised]

    assert {type(refusal) for refusal in raised} == {errors.NotAuthorized}
    assert {refusal.message for refusal in raised} == {errors.NOT_SIGNED_IN}
    assert bodies[0] == bodies[1] == bodies[2]
    # Exactly one key. `retryAfter`, `remainingAttempts` and a "too many attempts"
    # sentence would each land here, and each one enumerates.
    assert list(bodies[0]) == ["error"]
    assert all(refusal.extra == {} for refusal in raised)
    assert {refusal.status for refusal in raised} == {403}


async def test_no_refusal_mentions_a_limit_or_a_retry_interval(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    """BR3.20, stated as the words that must not appear."""
    store = identity_store_factory()
    email = an_email()
    password = a_password()
    identity = await provisioned(store, low_cost_hashing, signer, email=email, password=password)
    await exhaust_account_window(store, email.strip().lower())

    with pytest.raises(errors.NotAuthorized) as refusal:
        await identity.sign_in(
            email=email, password=password, source_address=an_address(), now=at(10)
        )

    rendered = repr(errors.envelope(refusal.value)).lower()
    for forbidden in ("retry", "too many", "attempt", "rate", "lock", "wait"):
        assert forbidden not in rendered


# --- BR23.1: a verification always runs ----------------------------------------------- #


async def test_a_verification_always_runs_with_no_owner_record(
    identity_store_factory: Callable[[], IdentityStore],
    recording_hashing: RecordingHashing,
    signer: CookieSigner,
) -> None:
    """The dummy hash is verified and its result discarded.

    Asserted by the code path, never by the clock. A test that measured duration would
    be flaky on a loaded machine and would still not prove which branch ran.
    """
    store = identity_store_factory()
    identity = build_identity(store, recording_hashing, signer)

    with pytest.raises(errors.NotAuthorized):
        await identity.sign_in(
            email=an_email(), password=a_password(), source_address=an_address(), now=at(10)
        )

    assert recording_hashing.verified == [recording_hashing.dummy_hash]


async def test_a_verification_against_an_existing_owner_uses_the_stored_hash(
    identity_store_factory: Callable[[], IdentityStore],
    recording_hashing: RecordingHashing,
    signer: CookieSigner,
) -> None:
    """The counterpart: exactly one verification either way, against a real argon2id hash."""
    store = identity_store_factory()
    email = an_email()
    identity = await provisioned(
        store, recording_hashing, signer, email=email, password=a_password()
    )
    recording_hashing.verified.clear()

    with pytest.raises(errors.NotAuthorized):
        await identity.sign_in(
            email=email, password=a_password(), source_address=an_address(), now=at(10)
        )

    owner = await store.owner_record_read()
    assert owner is not None
    assert recording_hashing.verified == [owner.password_hash]


async def test_the_dummy_hash_is_a_real_argon2id_hash_and_not_a_committed_constant(
    low_cost_hashing: PasswordHashing,
) -> None:
    """It must cost what a real verification costs, and it must exist nowhere on disk.

    A malformed placeholder would be rejected by argon2 before any work happened, which
    silently un-does BR23.1 while every assertion about the refusal body still passes.
    A hard-coded PHC string would also freeze the parameters, so a later change to the
    production cost would re-open the timing gap it was written to close -- and it would
    put an argon2id digest in the source tree, which is what BR3.10 forbids the shape of.
    """
    assert low_cost_hashing.dummy_hash.startswith("$argon2id$")
    # Generated per instance from the same hasher as production, so it is never a
    # literal anyone can read out of a file.
    assert PasswordHashing(low_cost_hasher()).dummy_hash != low_cost_hashing.dummy_hash
    # It verifies -- it does not raise, and it does not match.
    against_dummy = await low_cost_hashing.verify_password(
        low_cost_hashing.dummy_hash, a_password()
    )
    assert against_dummy is False


async def test_a_malformed_stored_hash_is_a_no_rather_than_an_error(
    low_cost_hashing: PasswordHashing,
) -> None:
    """BR3.6: verification answers only matched or not matched. Never why."""
    assert await low_cost_hashing.verify_password("not-a-phc-string", a_password()) is False


async def test_the_production_cost_is_the_library_recommendation_and_not_the_test_one() -> None:
    """The one place the production parameters are exercised, at their real cost.

    Asserted as "strictly stronger than the suite's deliberately weak hasher" rather than
    as literal numbers, so an upstream parameter increase is picked up by a dependency
    bump instead of failing a test that pinned yesterday's recommendation.
    """
    weak = low_cost_hasher()
    strong = production_hasher()

    assert strong.time_cost >= weak.time_cost
    assert strong.memory_cost > weak.memory_cost
    assert strong.parallelism >= weak.parallelism

    hashing = production_hashing()
    assert hashing.dummy_hash.startswith("$argon2id$")


async def test_a_correct_password_verifies_against_its_own_hash(
    low_cost_hashing: PasswordHashing,
) -> None:
    password = a_password()
    stored = await low_cost_hashing.hash_password(password)
    assert await low_cost_hashing.verify_password(stored, password) is True
    assert await low_cost_hashing.verify_password(stored, a_password()) is False


# --- step order: both windows first, keyed on the normalised email -------------------- #


async def test_both_windows_are_read_before_the_owner_lookup(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    """Step 1 precedes step 2, and the key is the normalised submitted email.

    `owner_id` does not exist yet at step 1, which is why the account window can only be
    keyed on the email -- and keying it there is what stops the lookup outcome from
    deciding whether the counter read happens at all.
    """
    recorder = RecordingIdentityStore(identity_store_factory())
    identity = build_identity(recorder, low_cost_hashing, signer)
    address = an_address()

    with pytest.raises(errors.NotAuthorized):
        await identity.sign_in(
            email="   Owner@EXAMPLE.Test  ",
            password=a_password(),
            source_address=address,
            now=at(10),
        )

    counts = [call for call in recorder.calls if call.operation == "login_attempts_count_in_window"]
    assert len(counts) == 2
    assert {(call.scope, call.key) for call in counts} == {
        ("account", "owner@example.test"),
        ("ip", address),
    }

    first_owner_read = recorder.operations.index("owner_record_read")
    assert recorder.operations.index("login_attempts_count_in_window") < first_owner_read
    assert recorder.operations[:2] == [
        "login_attempts_count_in_window",
        "login_attempts_count_in_window",
    ]


async def test_an_exhausted_window_does_not_short_circuit_the_verification(
    identity_store_factory: Callable[[], IdentityStore],
    recording_hashing: RecordingHashing,
    signer: CookieSigner,
) -> None:
    """No early return. An early return is the timing channel BR23.1 exists to close.

    This is the test that fails against the natural implementation -- check the limit,
    refuse, return -- which passes every assertion about the refusal body.
    """
    store = identity_store_factory()
    email = an_email()
    password = a_password()
    identity = await provisioned(store, recording_hashing, signer, email=email, password=password)
    await exhaust_account_window(store, email.strip().lower())
    recording_hashing.verified.clear()

    with pytest.raises(errors.NotAuthorized):
        await identity.sign_in(
            email=email, password=password, source_address=an_address(), now=at(10)
        )

    owner = await store.owner_record_read()
    assert owner is not None
    assert recording_hashing.verified == [owner.password_hash]


async def test_the_owner_lookup_happens_even_when_the_window_is_exhausted(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    """The shape of the storage work is the same on every attempt, refused or not."""
    email = an_email()
    password = a_password()
    inner = identity_store_factory()
    await provisioned(inner, low_cost_hashing, signer, email=email, password=password)
    await exhaust_account_window(inner, email.strip().lower())

    recorder = RecordingIdentityStore(inner)
    limited = build_identity(recorder, low_cost_hashing, signer)
    with pytest.raises(errors.NotAuthorized):
        await limited.sign_in(
            email=email, password=password, source_address=an_address(), now=at(10)
        )

    assert "owner_record_read" in recorder.operations


# --- what a refusal and a success do to the counters (BR3.18, BR3.19, BR3.21) ---------- #


@pytest.mark.parametrize("owner_exists", [False, True])
async def test_any_refusal_records_a_failure_against_both_windows(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
    owner_exists: bool,
) -> None:
    store = identity_store_factory()
    email = an_email()
    address = an_address()
    account_key = email.strip().lower()

    if owner_exists:
        identity = await provisioned(
            store, low_cost_hashing, signer, email=email, password=a_password()
        )
    else:
        identity = build_identity(store, low_cost_hashing, signer)

    assert await count_failures(store, "account", account_key, at(10)) == 0
    assert await count_failures(store, "ip", address, at(10)) == 0

    with pytest.raises(errors.NotAuthorized):
        await identity.sign_in(
            email=email, password=a_password(), source_address=address, now=at(10)
        )

    assert await count_failures(store, "account", account_key, at(11)) == 1
    assert await count_failures(store, "ip", address, at(11)) == 1


async def test_a_refusal_at_the_limit_still_records_against_both_windows(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    """ "On **any** refusal" includes the one the limit itself produced."""
    store = identity_store_factory()
    email = an_email()
    address = an_address()
    account_key = email.strip().lower()
    identity = await provisioned(
        store, low_cost_hashing, signer, email=email, password=a_password()
    )
    await exhaust_account_window(store, account_key)

    with pytest.raises(errors.NotAuthorized):
        await identity.sign_in(
            email=email, password=a_password(), source_address=address, now=at(10)
        )

    assert await count_failures(store, "account", account_key, at(11)) == ACCOUNT_FAILURE_LIMIT + 1
    assert await count_failures(store, "ip", address, at(11)) == 1


async def test_success_clears_the_account_counter_and_leaves_the_address_counter(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    """BR3.21 clears **that account's** counter. The address counter is not that counter.

    Clearing both would let one address reset its own flood limit by signing in once,
    which is the attack BR3.19 exists to bound.
    """
    store = identity_store_factory()
    email = an_email()
    password = a_password()
    address = an_address()
    account_key = email.strip().lower()
    identity = await provisioned(store, low_cost_hashing, signer, email=email, password=password)

    for attempt in range(2):
        with pytest.raises(errors.NotAuthorized):
            await identity.sign_in(
                email=email, password=a_password(), source_address=address, now=at(10 + attempt)
            )
    assert await count_failures(store, "account", account_key, at(20)) == 2
    assert await count_failures(store, "ip", address, at(20)) == 2

    await identity.sign_in(email=email, password=password, source_address=address, now=at(20))

    assert await count_failures(store, "account", account_key, at(21)) == 0
    assert await count_failures(store, "ip", address, at(21)) == 2


async def test_the_address_limit_refuses_on_its_own(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    """The account window is empty and the correct password is supplied; it is still refused."""
    store = identity_store_factory()
    email = an_email()
    password = a_password()
    address = an_address()
    identity = await provisioned(store, low_cost_hashing, signer, email=email, password=password)

    for index in range(ADDRESS_FAILURE_LIMIT):
        await store.login_attempts_record_failure("ip", address, at(index), WINDOW_LENGTH)
    assert await count_failures(store, "account", email.strip().lower(), at(30)) == 0

    with pytest.raises(errors.NotAuthorized):
        await identity.sign_in(email=email, password=password, source_address=address, now=at(30))


# --- the successful path -------------------------------------------------------------- #


async def test_a_successful_sign_in_issues_a_session_and_returns_the_csrf_token(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    store = identity_store_factory()
    email = an_email()
    password = a_password()
    identity = await provisioned(store, low_cost_hashing, signer, email=email, password=password)

    signed_in = await identity.sign_in(
        email=email, password=password, source_address=an_address(), now=at(10)
    )

    owner = await store.owner_record_read()
    assert owner is not None
    assert signed_in.owner_id == owner.owner_id
    assert signed_in.session.csrf_token
    # The token is returned here, in the body this value becomes. It is never the cookie.
    assert signed_in.session.csrf_token not in signed_in.session.cookie.value

    stored = await store.session_read(signed_in.session.session_id)
    assert stored is not None
    assert stored.owner_id == owner.owner_id
    assert stored.csrf_token == signed_in.session.csrf_token


async def test_the_submitted_email_is_matched_case_insensitively_after_trimming(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    """The stored address is kept verbatim; the comparison normalises both sides.

    ENT-1 says the stored email is *not trimmed*, and ENT-3 keys the account window on
    the normalised form. Matching on the normalised form is what keeps those two
    consistent -- otherwise an owner whose address was provisioned with a capital letter
    is counted under one key and refused under another.
    """
    store = identity_store_factory()
    email = an_email()
    password = a_password()
    identity = await provisioned(
        store, low_cost_hashing, signer, email=email.upper(), password=password
    )

    stored_owner = await store.owner_record_read()
    assert stored_owner is not None
    assert stored_owner.email == email.upper()

    signed_in = await identity.sign_in(
        email=f"  {email}  ", password=password, source_address=an_address(), now=at(10)
    )
    assert signed_in.owner_id == stored_owner.owner_id


async def test_a_different_email_with_the_right_password_is_refused(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
) -> None:
    """Exactly one account exists; submitting someone else's address is not that account."""
    store = identity_store_factory()
    password = a_password()
    identity = await provisioned(
        store, low_cost_hashing, signer, email=an_email(), password=password
    )

    with pytest.raises(errors.NotAuthorized):
        await identity.sign_in(
            email=an_email("someone-else"),
            password=password,
            source_address=an_address(),
            now=at(10),
        )


# --- the plaintext goes nowhere (BR3.6) ------------------------------------------------ #


async def test_the_plaintext_password_reaches_no_record_no_log_and_no_raised_error(
    identity_store_factory: Callable[[], IdentityStore],
    low_cost_hashing: PasswordHashing,
    signer: CookieSigner,
    caplog: pytest.LogCaptureFixture,
) -> None:
    store = identity_store_factory()
    email = an_email()
    password = a_password()

    with caplog.at_level(logging.DEBUG):
        identity = await provisioned(
            store, low_cost_hashing, signer, email=email, password=password
        )
        await identity.sign_in(
            email=email, password=password, source_address=an_address(), now=at(10)
        )
        with pytest.raises(errors.NotAuthorized) as refusal:
            await identity.sign_in(
                email=email, password=a_password(), source_address=an_address(), now=at(11)
            )

    owner = await store.owner_record_read()
    assert owner is not None
    assert password not in owner.password_hash
    assert owner.password_hash.startswith("$argon2id$")
    assert password not in caplog.text
    assert password not in str(refusal.value)
    assert owner.password_hash not in caplog.text
