"""BR3.13 and BR3.9 -- the startup precondition, and the asymmetry beside it.

**There is no oracle for this unit.** The source authenticated through a platform header
and had no configuration of its own, so nothing below was recorded from a running system:
every expectation is read off `functional-spec.md` § *Startup* and `rules.md` BR3.13 and
BR3.9. What these tests assert is therefore the **property** -- three conditions checked
separately, a process that stops, a variable that is named, and a second secret whose
absence is legitimate -- rather than whatever `app/settings.py` happens to do.

**Two of these run the interpreter in a subprocess**, because "exits non-zero" is not a
property an in-process `pytest.raises` can observe. A raise that some caller swallows
still passes an in-process test and still leaves the container running with a worthless
signing key, which is precisely the failure BR3.13 exists to prevent.
"""

from __future__ import annotations

import os
import pathlib
import subprocess
import sys
from collections.abc import Callable

import pytest

from app.auth.store import IdentityStore
from app.settings import (
    ADMIN_BOOTSTRAP_VARIABLE,
    MINIMUM_SIGNING_KEY_BYTES,
    SESSION_SIGNING_KEY_VARIABLE,
    Settings,
    StartupConfigurationError,
    load_settings,
)
from auth.conftest import a_signing_key

pytestmark = pytest.mark.anyio

BACKEND_ROOT = pathlib.Path(__file__).resolve().parents[2]

# The smallest program that performs this unit's startup step and nothing else.
_STARTUP = "import os; import app.settings; app.settings.load_settings(os.environ)"


def start_process(environ: dict[str, str]) -> subprocess.CompletedProcess[str]:
    """Run the startup step in a fresh interpreter and report how it ended.

    The environment is built from scratch rather than inherited, so a signing key that
    happens to be exported in the developer's shell cannot make the unset case pass.
    """
    return subprocess.run(  # noqa: S603 - fixed argv, no shell, nothing caller-supplied
        [sys.executable, "-c", _STARTUP],
        cwd=BACKEND_ROOT,
        env={"PATH": os.environ.get("PATH", "")} | environ,
        capture_output=True,
        text=True,
        check=False,
    )


def short_key() -> str:
    """A key one byte under the floor -- the case a naive falsy check lets straight through."""
    return "k" * (MINIMUM_SIGNING_KEY_BYTES - 1)


# --- the three signing-key conditions, each on its own ------------------------------- #


def test_an_unset_signing_key_raises_and_names_the_variable() -> None:
    with pytest.raises(StartupConfigurationError) as raised:
        load_settings({})
    assert SESSION_SIGNING_KEY_VARIABLE in str(raised.value)


def test_an_empty_signing_key_raises_on_its_own_condition() -> None:
    """Checked separately from "unset", not folded into one falsy test."""
    with pytest.raises(StartupConfigurationError) as raised:
        load_settings({SESSION_SIGNING_KEY_VARIABLE: ""})
    assert SESSION_SIGNING_KEY_VARIABLE in str(raised.value)
    assert "empty" in str(raised.value)


def test_a_short_signing_key_raises_although_it_is_present_and_non_empty() -> None:
    """The one a naive check misses, and the one a human is most likely to type by hand."""
    key = short_key()
    assert key != ""
    assert len(key.encode("utf-8")) < MINIMUM_SIGNING_KEY_BYTES

    with pytest.raises(StartupConfigurationError) as raised:
        load_settings({SESSION_SIGNING_KEY_VARIABLE: key})
    assert SESSION_SIGNING_KEY_VARIABLE in str(raised.value)
    assert str(MINIMUM_SIGNING_KEY_BYTES) in str(raised.value)


def test_the_floor_is_bytes_not_characters() -> None:
    """31 non-ASCII characters are over the byte floor; 31 ASCII ones are under it.

    Nothing recorded this: it follows from the strength that matters being the byte
    length of the HMAC key. Stated as a test so the unit is measured in one of them
    rather than in whichever the reader assumed.
    """
    thirty_one_multibyte = "é" * (MINIMUM_SIGNING_KEY_BYTES - 1)
    assert len(thirty_one_multibyte) < MINIMUM_SIGNING_KEY_BYTES
    assert len(thirty_one_multibyte.encode("utf-8")) >= MINIMUM_SIGNING_KEY_BYTES

    accepted = load_settings({SESSION_SIGNING_KEY_VARIABLE: thirty_one_multibyte})
    assert accepted.session_signing_key == thirty_one_multibyte


@pytest.mark.parametrize(
    ("label", "environ"),
    [
        ("unset", {}),
        ("empty", {SESSION_SIGNING_KEY_VARIABLE: ""}),
        ("short", {SESSION_SIGNING_KEY_VARIABLE: short_key()}),
    ],
)
def test_each_signing_key_condition_exits_the_process_non_zero(
    label: str, environ: dict[str, str]
) -> None:
    """The half a `pytest.raises` cannot see.

    An in-process raise that some future caller catches would still pass every test
    above while leaving a container running on a worthless key. This asserts the
    process-level outcome the rule actually specifies.
    """
    finished = start_process(environ)
    assert finished.returncode != 0, f"{label}: expected a non-zero exit"
    assert SESSION_SIGNING_KEY_VARIABLE in finished.stderr, f"{label}: variable not named"


def test_a_valid_key_starts_the_process_cleanly() -> None:
    finished = start_process({SESSION_SIGNING_KEY_VARIABLE: a_signing_key()})
    assert finished.returncode == 0, finished.stderr


# --- no key is ever invented ---------------------------------------------------------- #


def test_no_signing_key_is_ever_auto_generated() -> None:
    """Two startups with the same configured key read the same key back.

    An auto-generated per-process key is the worse failure *because it looks like it
    works*: the service starts, sign-in succeeds, and every session silently dies at the
    next restart. Asserted as "the value out is the value in, twice", which a generated
    key cannot satisfy.
    """
    key = a_signing_key()
    first = load_settings({SESSION_SIGNING_KEY_VARIABLE: key})
    second = load_settings({SESSION_SIGNING_KEY_VARIABLE: key})

    assert first.session_signing_key == key
    assert second.session_signing_key == first.session_signing_key

    other = load_settings({SESSION_SIGNING_KEY_VARIABLE: a_signing_key()})
    assert other.session_signing_key != key


# --- the bootstrap secret is the asymmetric one --------------------------------------- #


def test_a_missing_bootstrap_secret_does_not_fail_startup() -> None:
    """BR3.9. The asymmetry with BR3.13 is asserted, not assumed."""
    settings = load_settings({SESSION_SIGNING_KEY_VARIABLE: a_signing_key()})
    assert isinstance(settings, Settings)
    assert settings.admin_bootstrap_secret is None


def test_an_empty_bootstrap_secret_is_absence_rather_than_a_secret() -> None:
    """Honouring the empty string would open the one-shot route to an empty header."""
    settings = load_settings(
        {SESSION_SIGNING_KEY_VARIABLE: a_signing_key(), ADMIN_BOOTSTRAP_VARIABLE: ""}
    )
    assert settings.admin_bootstrap_secret is None


def test_a_configured_bootstrap_secret_is_read_verbatim() -> None:
    configured = a_signing_key()
    settings = load_settings(
        {SESSION_SIGNING_KEY_VARIABLE: a_signing_key(), ADMIN_BOOTSTRAP_VARIABLE: configured}
    )
    assert settings.admin_bootstrap_secret == configured


# --- startup seeds nothing ------------------------------------------------------------ #


@pytest.mark.parametrize("with_bootstrap", [False, True])
async def test_startup_seeds_no_owner_under_any_configuration(
    identity_store_factory: Callable[[], IdentityStore], with_bootstrap: bool
) -> None:
    """BR3.10, at the startup step. Loading configuration creates no account."""
    environ = {SESSION_SIGNING_KEY_VARIABLE: a_signing_key()}
    if with_bootstrap:
        environ[ADMIN_BOOTSTRAP_VARIABLE] = a_signing_key()

    load_settings(environ)

    store = identity_store_factory()
    assert await store.owner_record_read() is None
