"""HAZARD -- the session state machine, both bounds, and the cookie that carries nothing.

**There is no oracle for this file either.** Every expectation is read off
`functional-spec.md` § *The session state machine* and `rules.md` BR3.11-BR3.17 and
BR23.2.

**The single most consequential line in this unit is `touch` advancing `last_seen_at` and
nothing else.** The tempting simplification -- one expiry timestamp, refreshed on use --
satisfies BR3.14 exactly and destroys BR3.15 completely, and **every test written against
idle expiry still passes**, because a session used every hour never reaches the idle bound
in either design. The only test that separates the two runs for more than seven days of
simulated time, and it is
`test_a_session_used_every_hour_for_eight_days_still_expires_absolutely`.

**What is preserved here is not the source's mechanism.** The source's identity came from
a dev-server middleware that stripped every client-supplied identity header before
injecting its own -- sending those headers directly still returned 403. The trust boundary
was the middleware, not the header, so the property that must survive the port is **"a
client cannot assert its own identity"**. It is carried by a cookie holding only an opaque
identifier, signed, plus a server-side record read on every request:
`test_the_cookie_carries_only_the_session_identifier` and
`test_a_tampered_cookie_is_anonymous` are that property in executable form.
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import timedelta

import pytest
from itsdangerous import URLSafeSerializer

from app import errors
from app.auth.sessions import ABSOLUTE_LIFETIME, IDLE_LIMIT, SessionAuthority
from app.auth.store import IdentityStore
from app.auth.tokens import (
    CSRF_HEADER_NAME,
    SAME_SITE_LAX,
    SESSION_COOKIE_NAME,
    SESSION_COOKIE_SALT,
    CookieSigner,
    new_opaque_id,
)
from auth.conftest import a_signing_key, at, days, hours

pytestmark = pytest.mark.anyio

OWNER_ID = "owner-under-test"


def authority(store: IdentityStore, signer: CookieSigner) -> SessionAuthority:
    return SessionAuthority(store, signer)


# --- the bounds are what the design says they are ------------------------------------- #


def test_the_two_bounds_are_eight_hours_idle_and_seven_days_absolute() -> None:
    """D2, stated once so nothing downstream restates it as a number."""
    assert timedelta(hours=8) == IDLE_LIMIT
    assert timedelta(days=7) == ABSOLUTE_LIFETIME


async def test_issue_computes_the_absolute_bound_once_from_the_issue_instant(
    identity_store_factory: Callable[[], IdentityStore], signer: CookieSigner
) -> None:
    store = identity_store_factory()
    issued = await authority(store, signer).issue(OWNER_ID, at(0))

    stored = await store.session_read(issued.session_id)
    assert stored is not None
    assert stored.issued_at == at(0)
    assert stored.last_seen_at == at(0)
    assert stored.absolute_expires_at == at(0) + ABSOLUTE_LIFETIME
    assert stored.revoked_at is None


# --- THE hazard: touch advances one timestamp and not the other (BR3.14, BR3.15) ------- #


async def test_touch_advances_last_seen_at_and_leaves_the_absolute_bound_untouched(
    identity_store_factory: Callable[[], IdentityStore], signer: CookieSigner
) -> None:
    """The defect this catches passes every idle-expiry test in this file.

    Refreshing both timestamps satisfies the 8-hour rule perfectly and silently removes
    the 7-day bound. Nothing errors, nothing logs, and the only observable difference is
    a session that outlives a week.
    """
    store = identity_store_factory()
    sessions = authority(store, signer)
    issued = await sessions.issue(OWNER_ID, at(0))
    original_bound = at(0) + ABSOLUTE_LIFETIME

    verified = await sessions.verify(issued.cookie.value, at(hours(1)))
    assert verified is not None

    stored = await store.session_read(issued.session_id)
    assert stored is not None
    assert stored.last_seen_at == at(hours(1))
    assert stored.absolute_expires_at == original_bound
    assert stored.issued_at == at(0)


async def test_a_session_used_every_hour_for_eight_days_still_expires_absolutely(
    identity_store_factory: Callable[[], IdentityStore], signer: CookieSigner
) -> None:
    """The only test that separates the two designs. It runs eight days of simulated time.

    The idle bound is never reached -- the session is used hourly throughout -- so the
    collapsed single-timestamp design keeps answering. The absolute bound is what ends
    it, and it ends it at exactly seven days after issue.
    """
    store = identity_store_factory()
    sessions = authority(store, signer)
    issued = await sessions.issue(OWNER_ID, at(0))

    last_accepted_hour = 0
    first_refused_hour: int | None = None
    for hour in range(1, 8 * 24 + 1):
        verified = await sessions.verify(issued.cookie.value, at(hours(hour)))
        if verified is None:
            first_refused_hour = hour
            break
        last_accepted_hour = hour

    assert first_refused_hour is not None, "the absolute bound never fired in eight days"
    assert at(hours(last_accepted_hour)) <= at(0) + ABSOLUTE_LIFETIME
    assert at(hours(first_refused_hour)) > at(0) + ABSOLUTE_LIFETIME
    assert first_refused_hour == 7 * 24 + 1


async def test_a_session_left_alone_expires_after_the_idle_bound(
    identity_store_factory: Callable[[], IdentityStore], signer: CookieSigner
) -> None:
    store = identity_store_factory()
    sessions = authority(store, signer)
    issued = await sessions.issue(OWNER_ID, at(0))

    assert await sessions.verify(issued.cookie.value, at(hours(7.5))) is not None
    # Advanced by the verification above, so the bound now runs from 7.5 hours.
    assert await sessions.verify(issued.cookie.value, at(hours(15.4))) is not None
    assert await sessions.verify(issued.cookie.value, at(hours(23.5))) is None


async def test_the_idle_window_slides_on_each_verified_request(
    identity_store_factory: Callable[[], IdentityStore], signer: CookieSigner
) -> None:
    store = identity_store_factory()
    sessions = authority(store, signer)
    issued = await sessions.issue(OWNER_ID, at(0))

    for step in range(1, 6):
        assert await sessions.verify(issued.cookie.value, at(hours(7 * step))) is not None

    # 35 hours in, well past a fixed 8-hour window from issue, still alive.
    stored = await store.session_read(issued.session_id)
    assert stored is not None
    assert stored.last_seen_at == at(hours(35))


async def test_the_bound_reached_first_is_the_one_that_ends_the_session(
    identity_store_factory: Callable[[], IdentityStore], signer: CookieSigner
) -> None:
    """Two independent transitions; neither is a maximum of the other."""
    store = identity_store_factory()
    sessions = authority(store, signer)

    idle_first = await sessions.issue(OWNER_ID, at(0))
    assert await sessions.verify(idle_first.cookie.value, at(hours(9))) is None

    absolute_first = await sessions.issue(OWNER_ID, at(0))
    for hour in range(4, 8 * 24, 4):
        if await sessions.verify(absolute_first.cookie.value, at(hours(hour))) is None:
            assert at(hours(hour)) > at(0) + ABSOLUTE_LIFETIME
            break
    else:  # pragma: no cover - a session alive after eight days is the defect itself
        pytest.fail("the absolute bound never fired")


# --- identity or nothing, never a third answer (BR3.16) -------------------------------- #


async def test_every_rejection_is_the_same_nothing(
    identity_store_factory: Callable[[], IdentityStore], signer: CookieSigner
) -> None:
    """Revoked, idle-expired, absolutely expired and absent are one outcome.

    A three-valued result invites a caller to treat "expired" differently from "absent" --
    a distinction no caller needs and an attacker can use.
    """
    store = identity_store_factory()
    sessions = authority(store, signer)

    revoked = await sessions.issue(OWNER_ID, at(0))
    await sessions.sign_out(revoked.cookie.value, at(1))

    idle = await sessions.issue(OWNER_ID, at(0))
    absolute = await sessions.issue(OWNER_ID, at(0))
    absent = signer.sign(new_opaque_id())

    outcomes = [
        await sessions.verify(revoked.cookie.value, at(2)),
        await sessions.verify(idle.cookie.value, at(hours(9))),
        await sessions.verify(absolute.cookie.value, at(days(8))),
        await sessions.verify(absent, at(2)),
        await sessions.verify(None, at(2)),
        await sessions.verify("not-a-signed-value", at(2)),
    ]
    assert outcomes == [None, None, None, None, None, None]


async def test_a_verified_session_returns_the_owner_identity(
    identity_store_factory: Callable[[], IdentityStore], signer: CookieSigner
) -> None:
    store = identity_store_factory()
    sessions = authority(store, signer)
    issued = await sessions.issue(OWNER_ID, at(0))

    verified = await sessions.verify(issued.cookie.value, at(hours(1)))
    assert verified is not None
    assert verified.owner_id == OWNER_ID
    assert verified.session_id == issued.session_id
    assert verified.csrf_token == issued.csrf_token


# --- revocation is server-side and the record is retained (BR3.17, BR23.2) ------------- #


async def test_a_revoked_session_fails_the_very_next_verification(
    identity_store_factory: Callable[[], IdentityStore], signer: CookieSigner
) -> None:
    """Clearing the cookie alone does not satisfy BR3.17: the stored write is the rule."""
    store = identity_store_factory()
    sessions = authority(store, signer)
    issued = await sessions.issue(OWNER_ID, at(0))
    assert await sessions.verify(issued.cookie.value, at(1)) is not None

    await sessions.sign_out(issued.cookie.value, at(2))

    assert await sessions.verify(issued.cookie.value, at(3)) is None


async def test_a_revoked_record_is_retained_rather_than_deleted(
    identity_store_factory: Callable[[], IdentityStore], signer: CookieSigner
) -> None:
    """Its whole purpose is to keep failing.

    Deleting it would make a revoked session indistinguishable from an unknown one at the
    storage layer, and the retention is what makes revocation auditable at all.
    """
    store = identity_store_factory()
    sessions = authority(store, signer)
    issued = await sessions.issue(OWNER_ID, at(0))
    await sessions.sign_out(issued.cookie.value, at(2))

    stored = await store.session_read(issued.session_id)
    assert stored is not None
    assert stored.revoked_at == at(2)


async def test_sign_out_returns_a_cookie_that_clears_the_browser_copy(
    identity_store_factory: Callable[[], IdentityStore], signer: CookieSigner
) -> None:
    """The cookie clear is the courtesy; the stored revocation above is the rule."""
    store = identity_store_factory()
    sessions = authority(store, signer)
    issued = await sessions.issue(OWNER_ID, at(0))

    clearing = await sessions.sign_out(issued.cookie.value, at(2))
    assert clearing.name == SESSION_COOKIE_NAME
    assert clearing.value == ""
    assert clearing.max_age == 0
    assert clearing.http_only is True


async def test_signing_out_an_unknown_or_unsigned_cookie_is_a_no_op(
    identity_store_factory: Callable[[], IdentityStore], signer: CookieSigner
) -> None:
    """Sign-out reveals nothing either: it clears the cookie and says no more."""
    store = identity_store_factory()
    sessions = authority(store, signer)

    assert (await sessions.sign_out(None, at(2))).value == ""
    assert (await sessions.sign_out("garbage", at(2))).value == ""
    assert (await sessions.sign_out(signer.sign(new_opaque_id()), at(2))).value == ""


async def test_an_expired_record_is_rejected_and_the_rejection_is_stable(
    identity_store_factory: Callable[[], IdentityStore], signer: CookieSigner
) -> None:
    """BR23.2's outcome half: the housekeeping never changes the verification outcome.

    **BR23.2's reclamation half cannot be executed through `IdentityStore` as it stands.**
    The port exposes `session` create / read / touch / revoke and no delete, so this unit
    has no operation with which to delete a record it has just rejected. That is surfaced
    in `code-summary.md` § *Gaps surfaced, not closed* with a named owner rather than
    closed here by widening another unit's contract. What is asserted below is everything
    the rule specifies that is reachable: the record is rejected, and a second
    verification of the same cookie is rejected identically -- which is exactly the
    invariant a failed or absent delete must not break.
    """
    store = identity_store_factory()
    sessions = authority(store, signer)
    issued = await sessions.issue(OWNER_ID, at(0))

    assert await sessions.verify(issued.cookie.value, at(hours(9))) is None
    assert await sessions.verify(issued.cookie.value, at(hours(10))) is None
    assert await sessions.verify(issued.cookie.value, at(days(30))) is None


# --- there is no renewal path (BR3.15) ------------------------------------------------- #


async def test_nothing_extends_a_session_and_a_new_sign_in_issues_a_new_one(
    identity_store_factory: Callable[[], IdentityStore], signer: CookieSigner
) -> None:
    """There is no Renewed state. The owner signs in again; that is the whole mechanism."""
    store = identity_store_factory()
    sessions = authority(store, signer)

    first = await sessions.issue(OWNER_ID, at(0))
    for hour in range(1, 24):
        assert await sessions.verify(first.cookie.value, at(hours(hour))) is not None

    stored_first = await store.session_read(first.session_id)
    assert stored_first is not None
    assert stored_first.absolute_expires_at == at(0) + ABSOLUTE_LIFETIME

    second = await sessions.issue(OWNER_ID, at(hours(24)))
    stored_second = await store.session_read(second.session_id)
    assert stored_second is not None

    assert second.session_id != first.session_id
    assert second.csrf_token != first.csrf_token
    assert stored_second.absolute_expires_at == at(hours(24)) + ABSOLUTE_LIFETIME


# --- the cookie (BR3.11) and the CSRF token (BR3.12) ----------------------------------- #


async def test_the_session_cookie_is_signed_httponly_secure_and_samesite_lax(
    identity_store_factory: Callable[[], IdentityStore], signer: CookieSigner
) -> None:
    store = identity_store_factory()
    issued = await authority(store, signer).issue(OWNER_ID, at(0))

    cookie = issued.cookie
    assert cookie.name == SESSION_COOKIE_NAME
    assert cookie.http_only is True
    assert cookie.secure is True
    assert cookie.same_site == SAME_SITE_LAX
    assert cookie.path == "/"
    # Signed: the raw identifier is not the cookie value, and the signature recovers it.
    assert cookie.value != issued.session_id
    assert signer.unsign(cookie.value) == issued.session_id


async def test_the_cookie_carries_only_the_session_identifier(
    identity_store_factory: Callable[[], IdentityStore], signer: CookieSigner
) -> None:
    """No field of the session is encoded into it and no claim in it is trusted.

    This is the ported property: a client cannot assert its own identity. A cookie
    carrying an owner id, an expiry or a role would be exactly the client-authored
    identity claim the source's middleware existed to prevent.
    """
    store = identity_store_factory()
    issued = await authority(store, signer).issue(OWNER_ID, at(0))
    stored = await store.session_read(issued.session_id)
    assert stored is not None

    assert signer.unsign(issued.cookie.value) == issued.session_id
    for leaked in (OWNER_ID, issued.csrf_token, stored.absolute_expires_at.isoformat()):
        assert leaked not in issued.cookie.value


async def test_a_tampered_cookie_is_anonymous(
    identity_store_factory: Callable[[], IdentityStore], signer: CookieSigner
) -> None:
    """No error and no distinct response: an unsigned or tampered cookie is not a session."""
    store = identity_store_factory()
    sessions = authority(store, signer)
    issued = await sessions.issue(OWNER_ID, at(0))

    tampered = issued.cookie.value[:-1] + ("A" if issued.cookie.value[-1] != "A" else "B")
    assert await sessions.verify(tampered, at(1)) is None
    assert signer.unsign(tampered) is None


async def test_a_cookie_signed_with_another_key_is_anonymous(
    identity_store_factory: Callable[[], IdentityStore], signer: CookieSigner
) -> None:
    """The signature is what makes the identifier unforgeable; another key is another signer."""
    store = identity_store_factory()
    sessions = authority(store, signer)
    issued = await sessions.issue(OWNER_ID, at(0))

    foreign = CookieSigner(a_signing_key())
    assert await sessions.verify(foreign.sign(issued.session_id), at(1)) is None


def test_unsigning_a_payload_that_is_not_a_string_yields_nothing() -> None:
    """A correctly signed value of the wrong shape is still not a session identifier.

    Built with the module's own serialiser rather than through a production method added
    for the test: `CookieSigner` signs session identifiers and nothing else, and a
    `sign_anything` on it would be a hole opened to make an assertion convenient.
    """
    key = a_signing_key()
    signer_under_test = CookieSigner(key)
    wrong_shape = URLSafeSerializer(key, salt=SESSION_COOKIE_SALT).dumps(["not", "a", "string"])

    assert signer_under_test.unsign(wrong_shape) is None
    assert signer_under_test.unsign(None) is None
    assert signer_under_test.unsign("") is None


def test_opaque_identifiers_are_unguessable_and_unique() -> None:
    """A-3: at or above the strength of a 32-byte URL-safe random token."""
    minted = {new_opaque_id() for _ in range(256)}
    assert len(minted) == 256
    # 32 random bytes in URL-safe base64 is 43 characters.
    assert all(len(value) >= 43 for value in minted)


async def test_the_csrf_token_is_paired_one_to_one_with_the_session(
    identity_store_factory: Callable[[], IdentityStore], signer: CookieSigner
) -> None:
    store = identity_store_factory()
    sessions = authority(store, signer)

    first = await sessions.issue(OWNER_ID, at(0))
    second = await sessions.issue(OWNER_ID, at(1))

    assert first.csrf_token != second.csrf_token
    stored_first = await store.session_read(first.session_id)
    stored_second = await store.session_read(second.session_id)
    assert stored_first is not None
    assert stored_second is not None
    assert stored_first.csrf_token == first.csrf_token
    assert stored_second.csrf_token == second.csrf_token


async def test_a_mutation_with_a_wrong_or_missing_csrf_header_is_refused(
    identity_store_factory: Callable[[], IdentityStore], signer: CookieSigner
) -> None:
    """Checked as a request header, against the session's stored token.

    This does **not** replace the same-origin check, which is U6's and applies to the same
    mutations. Two defences, both required.
    """
    store = identity_store_factory()
    sessions = authority(store, signer)
    issued = await sessions.issue(OWNER_ID, at(0))
    verified = await sessions.verify(issued.cookie.value, at(1))
    assert verified is not None

    sessions.require_csrf(verified, issued.csrf_token)

    for supplied in (None, "", new_opaque_id(), issued.csrf_token[:-1]):
        with pytest.raises(errors.NotAuthorized) as refusal:
            sessions.require_csrf(verified, supplied)
        assert refusal.value.message == errors.NOT_SIGNED_IN


def test_the_csrf_token_is_never_carried_in_a_cookie() -> None:
    """A token the browser attaches automatically defends nothing.

    Stated as a property of the module's own surface: the only cookie this unit names is
    the session one, and the header the token travels back in is a request header.
    """
    assert CSRF_HEADER_NAME.lower().startswith("x-")
    assert "cookie" not in CSRF_HEADER_NAME.lower()
    assert SESSION_COOKIE_NAME != CSRF_HEADER_NAME
