"""`LoginGuard` -- the two windows, the thresholds, and where the thresholds live.

**There is no oracle for this file.** D3 and FR3.5 fix the numbers and `rules.md`
BR3.18-BR3.22 fix the behaviour; nothing here was recorded from a running system.

**The two counters bound different attacks and neither substitutes for the other.** The
account limit bounds guessing against the one account that matters, however many addresses
it comes from; the address limit bounds a flood from one source, whatever it is aimed at.
`test_the_address_window_is_counted_independently_of_every_account_window` is built so
that a single merged counter would pass every other assertion in this file and fail that
one: five accounts at four failures each is twenty from one address, and no account is
anywhere near its own limit.

**The numbers live in this unit.** `count_in_window` returns a count and never a verdict,
which `test_the_store_returns_a_count_and_never_a_verdict` asserts by driving the count
past the threshold and reading it back unclamped. A store that knew the thresholds would
enforce a rule it does not own -- across three adapters.
"""

from __future__ import annotations

from collections.abc import Callable

import pytest

from app.auth.guard import (
    ACCOUNT_FAILURE_LIMIT,
    ADDRESS_FAILURE_LIMIT,
    WINDOW_LENGTH,
    LoginGuard,
    account_window_key,
)
from app.auth.store import IdentityStore
from auth.conftest import RecordingIdentityStore, an_address, an_email, at, count_failures

pytestmark = pytest.mark.anyio

FIFTEEN_MINUTES_IN_SECONDS = 15 * 60


def test_the_thresholds_and_the_window_are_what_the_decision_fixed() -> None:
    """D3, stated once here so nothing downstream restates a number."""
    assert ACCOUNT_FAILURE_LIMIT == 5
    assert ADDRESS_FAILURE_LIMIT == 20
    assert WINDOW_LENGTH.total_seconds() == FIFTEEN_MINUTES_IN_SECONDS


def test_the_account_key_is_the_trimmed_lower_cased_submitted_email() -> None:
    """Always the email, matching account or not: `owner_id` does not exist at step 1."""
    assert account_window_key("  Owner@EXAMPLE.Test  ") == "owner@example.test"
    assert account_window_key("owner@example.test") == "owner@example.test"


# --- the account window (BR3.18) ------------------------------------------------------- #


async def test_five_account_failures_are_permitted_and_the_sixth_attempt_is_refused(
    identity_store_factory: Callable[[], IdentityStore],
) -> None:
    store = identity_store_factory()
    guard = LoginGuard(store)
    account_key = account_window_key(an_email())
    address = an_address()

    for index in range(ACCOUNT_FAILURE_LIMIT):
        assert (
            await guard.is_exhausted(account_key=account_key, source_address=address, now=at(index))
            is False
        ), f"attempt {index + 1} should still be permitted"
        await guard.record_failure(account_key=account_key, source_address=address, now=at(index))

    assert (
        await guard.is_exhausted(
            account_key=account_key, source_address=address, now=at(ACCOUNT_FAILURE_LIMIT)
        )
        is True
    )


async def test_one_account_window_does_not_bound_another(
    identity_store_factory: Callable[[], IdentityStore],
) -> None:
    """Separate records keyed by `(scope, window_key)`, not one counter per scope."""
    store = identity_store_factory()
    guard = LoginGuard(store)
    exhausted_key = account_window_key(an_email("targeted"))
    untouched_key = account_window_key(an_email("untouched"))
    address = an_address()

    for index in range(ACCOUNT_FAILURE_LIMIT):
        await store.login_attempts_record_failure(
            "account", exhausted_key, at(index), WINDOW_LENGTH
        )

    assert (
        await guard.is_exhausted(account_key=exhausted_key, source_address=address, now=at(10))
        is True
    )
    assert (
        await guard.is_exhausted(account_key=untouched_key, source_address=address, now=at(10))
        is False
    )


# --- the address window (BR3.19) ------------------------------------------------------- #


async def test_the_address_window_is_counted_independently_of_every_account_window(
    identity_store_factory: Callable[[], IdentityStore],
) -> None:
    """Five accounts at four failures each: twenty from one address, none near its limit.

    A single merged counter passes every other assertion in this file and fails this one.
    So does a design with only the account limit, which is defeated by exactly this
    spread.
    """
    store = identity_store_factory()
    guard = LoginGuard(store)
    address = an_address()
    account_keys = [account_window_key(an_email(f"target-{index}")) for index in range(5)]

    moment = 0
    for account_key in account_keys:
        for _ in range(4):
            await guard.record_failure(
                account_key=account_key, source_address=address, now=at(moment)
            )
            moment += 1

    for account_key in account_keys:
        assert await count_failures(store, "account", account_key, at(moment)) == 4
        assert ACCOUNT_FAILURE_LIMIT > 4
    assert await count_failures(store, "ip", address, at(moment)) == ADDRESS_FAILURE_LIMIT

    # Every account counter is under its own limit; the address counter alone refuses.
    assert (
        await guard.is_exhausted(
            account_key=account_window_key(an_email("fresh")),
            source_address=address,
            now=at(moment),
        )
        is True
    )


async def test_the_two_scopes_are_separate_records_even_under_the_same_key(
    identity_store_factory: Callable[[], IdentityStore],
) -> None:
    """Identity is the pair `(scope, window_key)`.

    A store keyed on the subject alone would merge these two and still look right in any
    fixture that happened to use a different value for each.
    """
    store = identity_store_factory()
    shared_key = "198.51.100.9"

    await store.login_attempts_record_failure("account", shared_key, at(0), WINDOW_LENGTH)
    await store.login_attempts_record_failure("account", shared_key, at(1), WINDOW_LENGTH)
    await store.login_attempts_record_failure("ip", shared_key, at(2), WINDOW_LENGTH)

    assert await count_failures(store, "account", shared_key, at(3)) == 2
    assert await count_failures(store, "ip", shared_key, at(3)) == 1


# --- the window rolls over -------------------------------------------------------------- #


async def test_a_window_rolls_over_after_fifteen_minutes(
    identity_store_factory: Callable[[], IdentityStore],
) -> None:
    """The observable boundary behaviour of a start-instant-plus-count window.

    A sixth failure just after a rollover is permitted, where a true sliding count over a
    log of instants would still refuse it. `entities.md` records that difference as an
    accepted consequence of the chosen shape rather than as an accident.
    """
    store = identity_store_factory()
    guard = LoginGuard(store)
    account_key = account_window_key(an_email())
    address = an_address()

    for index in range(ACCOUNT_FAILURE_LIMIT):
        await guard.record_failure(account_key=account_key, source_address=address, now=at(index))

    just_inside = at(FIFTEEN_MINUTES_IN_SECONDS - 1)
    just_outside = at(FIFTEEN_MINUTES_IN_SECONDS)

    assert (
        await guard.is_exhausted(account_key=account_key, source_address=address, now=just_inside)
        is True
    )
    assert (
        await guard.is_exhausted(account_key=account_key, source_address=address, now=just_outside)
        is False
    )


# --- persistence (BR3.22) ---------------------------------------------------------------- #


async def test_counters_survive_a_new_store_instance_over_the_same_storage(
    identity_store_factory: Callable[[], IdentityStore],
) -> None:
    """An in-memory counter is not an acceptable real adapter.

    An attacker who can cause a restart would otherwise reset the limit at will, and the
    rate limit becomes decorative. Asserted with a second, independent handle over the
    same storage, which is what a restart produces.
    """
    account_key = account_window_key(an_email())
    address = an_address()

    before = LoginGuard(identity_store_factory())
    for index in range(ACCOUNT_FAILURE_LIMIT):
        await before.record_failure(account_key=account_key, source_address=address, now=at(index))

    after = LoginGuard(identity_store_factory())
    assert (
        await after.is_exhausted(account_key=account_key, source_address=address, now=at(10))
        is True
    )


# --- clearing (BR3.21) ------------------------------------------------------------------- #


async def test_clearing_an_account_counter_leaves_the_address_counter_alone(
    identity_store_factory: Callable[[], IdentityStore],
) -> None:
    """Clearing both would let one address reset its own flood limit by signing in once."""
    store = identity_store_factory()
    guard = LoginGuard(store)
    account_key = account_window_key(an_email())
    address = an_address()

    for index in range(3):
        await guard.record_failure(account_key=account_key, source_address=address, now=at(index))

    await guard.clear_account(account_key)

    assert await count_failures(store, "account", account_key, at(10)) == 0
    assert await count_failures(store, "ip", address, at(10)) == 3


async def test_clearing_a_counter_that_is_not_there_is_a_success(
    identity_store_factory: Callable[[], IdentityStore],
) -> None:
    guard = LoginGuard(identity_store_factory())
    await guard.clear_account(account_window_key(an_email()))


# --- the thresholds are this unit's, not the store's -------------------------------------- #


async def test_the_store_returns_a_count_and_never_a_verdict(
    identity_store_factory: Callable[[], IdentityStore],
) -> None:
    """Driven past the threshold, the count keeps counting.

    A store that clamped at the limit, or answered a boolean, would be enforcing a rule
    it does not own -- and the three adapters would each have to be kept in step with a
    number that belongs to one component.
    """
    store = identity_store_factory()
    account_key = account_window_key(an_email())
    over = ACCOUNT_FAILURE_LIMIT + 3

    for index in range(over):
        await store.login_attempts_record_failure("account", account_key, at(index), WINDOW_LENGTH)

    counted = await count_failures(store, "account", account_key, at(over))
    assert counted == over
    assert counted > ACCOUNT_FAILURE_LIMIT
    assert not isinstance(counted, bool)


async def test_the_guard_reads_the_thresholds_it_was_constructed_with(
    identity_store_factory: Callable[[], IdentityStore],
) -> None:
    """The limits are the component's, injectable, and not read from the store.

    Asserted with limits that are not the production ones, so a guard that ignored its
    arguments and reached for the module constants would fail here.
    """
    store = identity_store_factory()
    guard = LoginGuard(store, account_limit=2, address_limit=3)
    account_key = account_window_key(an_email())
    address = an_address()

    await guard.record_failure(account_key=account_key, source_address=address, now=at(0))
    assert (
        await guard.is_exhausted(account_key=account_key, source_address=address, now=at(1))
        is False
    )

    await guard.record_failure(account_key=account_key, source_address=address, now=at(1))
    assert (
        await guard.is_exhausted(account_key=account_key, source_address=address, now=at(2)) is True
    )


async def test_both_windows_are_read_even_when_the_first_already_refuses(
    identity_store_factory: Callable[[], IdentityStore],
) -> None:
    """No short-circuit: the number of storage operations does not depend on the counts.

    Short-circuiting the second read would make the work done observable from the first
    counter's state, which is the same channel BR23.1 closes in a different place.
    """
    recorder = RecordingIdentityStore(identity_store_factory())
    guard = LoginGuard(recorder)
    account_key = account_window_key(an_email())
    address = an_address()

    for index in range(ACCOUNT_FAILURE_LIMIT):
        await recorder.login_attempts_record_failure(
            "account", account_key, at(index), WINDOW_LENGTH
        )
    recorder.calls.clear()

    assert (
        await guard.is_exhausted(account_key=account_key, source_address=address, now=at(10))
        is True
    )

    counted = [
        call for call in recorder.calls if call.operation == "login_attempts_count_in_window"
    ]
    assert [call.scope for call in counted] == ["account", "ip"]


async def test_a_failed_password_and_a_failed_address_share_no_counter(
    identity_store_factory: Callable[[], IdentityStore],
) -> None:
    """Two addresses guessing one account both count against that account.

    The account limit bounds guessing against the one account that matters **however
    many addresses it comes from** -- which is the half a per-address-only design loses.
    """
    store = identity_store_factory()
    guard = LoginGuard(store)
    account_key = account_window_key(an_email())

    for index in range(ACCOUNT_FAILURE_LIMIT):
        await guard.record_failure(
            account_key=account_key, source_address=an_address(index), now=at(index)
        )

    assert (
        await guard.is_exhausted(account_key=account_key, source_address=an_address(99), now=at(10))
        is True
    )
    assert await count_failures(store, "ip", an_address(99), at(10)) == 0


async def test_an_unrelated_password_attempt_is_unaffected_by_another_addresss_flood(
    identity_store_factory: Callable[[], IdentityStore],
) -> None:
    """The address limit bounds one source, not the account it was aimed at."""
    store = identity_store_factory()
    guard = LoginGuard(store)
    account_key = account_window_key(an_email())
    flooding = an_address(1)
    innocent = an_address(2)

    for index in range(ADDRESS_FAILURE_LIMIT):
        await store.login_attempts_record_failure("ip", flooding, at(index), WINDOW_LENGTH)

    assert (
        await guard.is_exhausted(account_key=account_key, source_address=flooding, now=at(30))
        is True
    )
    assert (
        await guard.is_exhausted(account_key=account_key, source_address=innocent, now=at(30))
        is False
    )
