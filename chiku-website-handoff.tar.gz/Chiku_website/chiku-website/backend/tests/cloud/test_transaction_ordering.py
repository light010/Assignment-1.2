"""The R-05 regression: every read precedes every write, and the blob writes precede both.

`UNITS.md` records that `cloud-adapters` ended functional-design **terminal NOT-READY** on
a real Firestore transaction-ordering finding: the algorithm read the retention prune's
survivors *after* writing the content document and the revision entry, and a Firestore
transaction rejects a read issued after a write. By this design's own pruning invariant
the prune fires on **every** combined write once the retention cap is reached, so that
transaction would have failed at runtime on essentially every save.

The finding was answered in the design, by resequencing to **read-content, read-survivors,
write-content, write-revision, delete-pruned, commit**. This file is what makes the answer
hold: `cloud.fake_firestore` refuses a read after a write, so an adapter that ever
un-does the resequencing fails the build rather than the deployment.

Each test below is written so that a **looser** version of it passes while the code is
wrong, and that is stated per test. A happy-path assertion cannot tell a correct ordering
from a fake that permits anything, which is why the second test exists.
"""

from __future__ import annotations

import pytest

from app.cloud.blobs import LARGE_PAYLOAD_THRESHOLD_BYTES
from app.cloud.clients import DESCENDING, TransactionLike
from app.cloud.content_firestore import (
    CONTENT_COLLECTION,
    REVISIONS_COLLECTION,
    CombinedWrite,
    FirestoreContentStore,
)
from app.content.store import (
    BASELINE_DRAFT_ID,
    BASELINE_PUBLISHED_ID,
    Action,
    ContentState,
    ContentStore,
    RetentionPolicy,
)
from cloud.fake_firestore import MissingCompositeIndexError, ReadAfterWriteError
from cloud.harness import CloudHarness, accepted, save, transaction_segments
from conformance.conftest import DEFAULT_LISTING_CAP, PRODUCTION_RETENTION, SEED, at

pytestmark = pytest.mark.anyio

READS = ("read-document", "read-query")
WRITES = ("write", "delete")

# Tight enough that the prune bites on every save after the first. The counts arrive as an
# ARGUMENT, never as a constant in an adapter (BR5.9).
TIGHT = RetentionPolicy(
    draft_keep=1, publish_keep=1, permanent_ids=(BASELINE_PUBLISHED_ID, BASELINE_DRAFT_ID)
)


class ReadsSurvivorsAfterWriting(FirestoreContentStore):
    """The pre-R-05 step order, restored on purpose.

    It calls the adapter's own phase helpers -- this is not a hand-written imitation of the
    defect, it is the defect, assembled from the same parts in the order the design used
    to specify. The third call is the survivor read, and it is issued after a write.
    """

    async def _run_combined_write(self, transaction: TransactionLike, write: CombinedWrite) -> None:
        await self._read_content(transaction)
        self._write_content(transaction, write.content_fields)
        await self._read_revisions(transaction)
        raise AssertionError("unreachable: the fake refuses a read issued after a write")


async def fill(store: ContentStore, *, count: int, retention: RetentionPolicy) -> None:
    """Alternating drafts and publishes, so both retention counts are exercised."""
    for revision in range(count):
        action: Action = "publish" if revision % 2 else "draft"
        accepted(
            await save(
                store,
                content=f'{{"v":{revision}}}',
                base_revision=revision,
                action=action,
                marker=f"w{revision}",
                retention=retention,
                now=at(revision + 1),
            )
        )


async def test_every_read_precedes_every_write_including_a_save_that_prunes(
    cloud: CloudHarness,
) -> None:
    """BR31.3. The happy path alone proves nothing -- see the next test for why.

    What this one adds is **the saves that prune**. The prune is the operation whose read
    the pre-fix algorithm placed after two writes, and under `TIGHT` it fires on every
    save from the second onwards, so every segment below is a segment the defect would
    have failed. A run under the production retention counts would never prune at all and
    would pass while the adapter was wrong.
    """
    store = cloud.content_store(seed=SEED, listing_cap=DEFAULT_LISTING_CAP)
    await fill(store, count=6, retention=TIGHT)

    segments = transaction_segments(cloud.journal)
    assert len(segments) == 6

    pruning = 0
    for position, segment in enumerate(segments):
        kinds = [operation.kind for operation in segment]
        reads = [index for index, kind in enumerate(kinds) if kind in READS]
        writes = [index for index, kind in enumerate(kinds) if kind in WRITES]
        assert reads, f"segment {position} issued no read: {kinds}"
        assert writes, f"segment {position} issued no write: {kinds}"
        assert max(reads) < min(writes), f"segment {position} read after writing: {kinds}"
        assert kinds[-1] == "commit"
        if "delete" in kinds:
            pruning += 1

    assert pruning >= 4, "the retention counts were not tight enough to exercise the prune"


async def test_an_adapter_that_reads_survivors_after_writing_is_refused(
    cloud: CloudHarness,
) -> None:
    """The fake **bites**. Without this, the test above is satisfied by a permissive fake.

    A test that only checks the happy path cannot distinguish a correct ordering from a
    double that would have accepted the wrong one, and a fake that accepted the wrong one
    would have made the whole R-05 finding invisible while the suite stayed green.

    The abort must also leave nothing behind: the transaction rolled back, so the content
    document the variant wrote is not there.
    """
    store = ReadsSurvivorsAfterWriting(
        cloud.client(), cloud.bucket(), seed=SEED, listing_cap=DEFAULT_LISTING_CAP
    )

    with pytest.raises(ReadAfterWriteError):
        await save(
            store,
            content='{"v":1}',
            base_revision=0,
            action="draft",
            marker="w1",
            retention=PRODUCTION_RETENTION,
            now=at(1),
        )

    assert cloud.documents.collections.get(CONTENT_COLLECTION, {}) == {}
    assert transaction_segments(cloud.journal)[-1][-1].kind == "rollback"


async def test_the_blob_writes_land_before_the_transaction_opens(cloud: CloudHarness) -> None:
    """BR31.2. Ordering across two services, which neither service can witness alone.

    A failed transaction must leave an **orphaned blob** -- reclaimable garbage, and
    reclaimable precisely because the key is a content hash, so a retry collides
    harmlessly. The reverse order leaves a document referencing a blob that never landed,
    which is corruption. Asserting that the save succeeded would not distinguish them:
    both orderings succeed when nothing fails.
    """
    store = cloud.content_store(seed=SEED, listing_cap=DEFAULT_LISTING_CAP)
    payload = "z" * (LARGE_PAYLOAD_THRESHOLD_BYTES + 1)

    accepted(
        await save(
            store,
            content=payload,
            base_revision=0,
            action="draft",
            marker="w1",
            retention=PRODUCTION_RETENTION,
            now=at(1),
        )
    )

    uploads = [
        index
        for index, operation in enumerate(cloud.journal.operations)
        if operation.kind == "upload"
    ]
    first_transaction = cloud.journal.first_index("begin")
    assert uploads, "an oversized payload was stored without writing a blob"
    assert max(uploads) < first_transaction
    # And nothing was uploaded once the transaction was open.
    assert all(
        operation.kind != "upload"
        for segment in transaction_segments(cloud.journal)
        for operation in segment
    )


async def test_the_survivor_read_is_one_unfiltered_revision_descending_read(
    cloud: CloudHarness,
) -> None:
    """BR31.4. The result is identical either way; only the SHAPE differs.

    A filtered read -- equality on `action` plus `orderBy revision DESC`, one per action --
    returns exactly the same survivors and would pass any assertion about what ends up
    stored. What it would also do is require a composite index on `(action, revision DESC)`
    that no deployment artifact declares, and an undeclared composite index fails at
    runtime. So this asserts the shape: **one** read, no filter, one ordering clause, no
    limit, over the whole bounded set.
    """
    store = cloud.content_store(seed=SEED, listing_cap=DEFAULT_LISTING_CAP)
    await fill(store, count=4, retention=TIGHT)

    for segment in transaction_segments(cloud.journal):
        queries = [
            operation
            for operation in segment
            if operation.kind == "read-query" and operation.target == REVISIONS_COLLECTION
        ]
        assert len(queries) == 1, f"expected one survivor read, got {len(queries)}"
        assert queries[0].filters == ()
        assert queries[0].order_by == (("revision", DESCENDING),)
        assert queries[0].limit is None


async def test_a_filtered_survivor_read_is_refused_for_want_of_a_declared_index(
    cloud: CloudHarness,
) -> None:
    """BR31.4, demonstrated rather than asserted.

    The adapters cannot issue this query -- `app.cloud.clients.QueryLike` carries no
    `where`, so the filtered shape is unwritable against the surface they are compiled
    against. This test reaches past that, straight at the fake, to show what would happen
    if someone widened the Protocol: the refusal is real, and it is the runtime failure
    BR31.4 exists to keep out of a deployment.
    """
    filtered = (
        cloud.client()
        .collection(REVISIONS_COLLECTION)
        .where("action", "==", "draft")
        .order_by("revision", DESCENDING)
    )
    with pytest.raises(MissingCompositeIndexError):
        filtered.stream()


async def test_the_listing_depends_on_the_one_declared_composite_index(
    cloud: CloudHarness,
) -> None:
    """BR31.4, the other half: the index is a **deliverable**, not a runtime detail.

    The three-part listing order is the only thing in this unit that needs a composite
    index. Asserting that the listing comes back in order proves the adapter asks for the
    right order; it does not prove the definition has to exist. The second harness, built
    with nothing declared, is what proves that -- and it is the failure a deployer gets if
    `app/cloud/INDEXES.md` does not travel with the deployment artifacts.
    """
    store = cloud.content_store(seed=SEED, listing_cap=DEFAULT_LISTING_CAP)
    await fill(store, count=3, retention=PRODUCTION_RETENTION)

    listing = await store.list_revisions()
    assert [summary.id for summary in listing] == [
        "w2",
        "w1",
        "w0",
        BASELINE_PUBLISHED_ID,
        BASELINE_DRAFT_ID,
    ]

    undeclared = CloudHarness(indexes=())
    bare = undeclared.content_store(seed=SEED, listing_cap=DEFAULT_LISTING_CAP)
    await fill(bare, count=1, retention=PRODUCTION_RETENTION)
    with pytest.raises(MissingCompositeIndexError):
        await bare.list_revisions()


async def test_a_commit_against_an_absent_document_at_a_non_zero_base_revision_conflicts(
    cloud: CloudHarness,
) -> None:
    """BR4.8's first guard, which only the cloud path reaches through an absent document.

    Bootstrap fires on ``base_revision = 0`` **and** no document. A client at revision 5
    claiming to write into empty storage must not resurrect a deleted document, and the
    conflict has to be decided in the read phase so that nothing is written at all -- not
    a bootstrap, not a baseline, not a revision entry.
    """
    store = cloud.content_store(seed=SEED, listing_cap=DEFAULT_LISTING_CAP)

    result = await save(
        store,
        content='{"v":1}',
        base_revision=5,
        action="draft",
        marker="w1",
        retention=PRODUCTION_RETENTION,
        now=at(1),
    )

    assert not isinstance(result, ContentState)
    assert cloud.documents.collections.get(CONTENT_COLLECTION, {}) == {}
    assert cloud.documents.collections.get(REVISIONS_COLLECTION, {}) == {}
    assert await store.read_revision("w1") is None
