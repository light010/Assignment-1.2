"""A Cloud Storage bucket that transfers only what it was asked for.

Synchronous, like the published client: there is no async Cloud Storage client, which is
why `app.cloud.assets_gcs` moves every call off the event loop through
``anyio.to_thread.run_sync`` (BR22.7).

**The ranged read is the one thing here that is not a convenience.** BR22.11 is an
obligation about **transfer volume**, and transfer volume is invisible to an assertion on
the returned bytes: an adapter that downloads the whole object and slices it returns
byte-identical results and passes every correctness assertion in the conformance suite --
while making a 50 MB video cost 50 MB of transfer per seek. On a metered object store the
failure mode is cost and latency, not incorrectness, so no correctness test catches it.
`download_as_bytes` returns exactly the requested window, and the conformance harness's
transfer spy records how many bytes each call handed back.

**Unverified**, like everything else in this unit: this models Cloud Storage as the design
understands it from published documentation, and nothing here has ever spoken to the
service.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from app.cloud.clients import NOT_FOUND_STATUS
from cloud.journal import STORAGE, Journal, Operation


class FakeNotFound(Exception):
    """Models ``google.api_core.exceptions.NotFound``.

    It carries ``code = 404`` because that attribute, not the class, is what
    `app.cloud.clients.tolerate` matches on -- and matching on the status is the only way
    this package can recognise the client's errors without importing the client.
    """

    code = NOT_FOUND_STATUS


@dataclass
class StoredObject:
    """One object: its bytes, its stored media type and its custom metadata."""

    data: bytes
    content_type: str
    metadata: dict[str, str]


@dataclass
class FakeStorage:
    """The objects every handle opened over this bucket shares."""

    journal: Journal
    objects: dict[str, StoredObject] = field(default_factory=dict)


class FakeBlob:
    """Models ``google.cloud.storage.Blob``.

    ``size`` and ``content_type`` start as ``None`` and are populated by `reload`, which
    is the published behaviour: a blob handle is a name, not a fetch.
    """

    def __init__(self, storage: FakeStorage, name: str) -> None:
        self._storage = storage
        self._name = name
        self.metadata: dict[str, str] | None = None
        self.size: int | None = None
        self.content_type: str | None = None

    def _record(self, kind: str) -> None:
        self._storage.journal.record(Operation(service=STORAGE, kind=kind, target=self._name))

    def exists(self) -> bool:
        self._record("exists")
        return self._name in self._storage.objects

    def reload(self) -> object:
        self._record("reload")
        stored = self._storage.objects.get(self._name)
        if stored is None:
            raise FakeNotFound(self._name)
        self.size = len(stored.data)
        self.content_type = stored.content_type
        self.metadata = dict(stored.metadata)
        return None

    def upload_from_string(self, data: bytes, content_type: str) -> object:
        self._record("upload")
        # Stored unchanged: no transcoding, no re-encoding, no normalisation, no
        # inspection. `metadata` is sent with the upload, which is how the content-derived
        # entity tag reaches the object (BR22.6).
        self._storage.objects[self._name] = StoredObject(
            data=data, content_type=content_type, metadata=dict(self.metadata or {})
        )
        return None

    def download_as_bytes(self, start: int | None = None, end: int | None = None) -> bytes:
        stored = self._storage.objects.get(self._name)
        if stored is None:
            self._record("download")
            raise FakeNotFound(self._name)
        if start is None and end is None:
            self._record("download")
            return stored.data
        self._record("download-range")
        # `start` and `end` are an INCLUSIVE range, which is the published spelling.
        first = start or 0
        last = len(stored.data) - 1 if end is None else end
        return stored.data[first : last + 1]

    def delete(self) -> object:
        self._record("delete")
        if self._name not in self._storage.objects:
            raise FakeNotFound(self._name)
        del self._storage.objects[self._name]
        return None


class FakeBucket:
    """Models ``google.cloud.storage.Bucket``."""

    def __init__(self, storage: FakeStorage) -> None:
        self._storage = storage

    def blob(self, blob_name: str) -> FakeBlob:
        # A handle, which does not itself touch the service -- so it is not recorded.
        return FakeBlob(self._storage, blob_name)
