"""Package marker for the cloud-adapter suite.

Here for the same mechanical reason as `tests/conformance/__init__.py`, not for style.
Without it, pytest's prepend import mode names both `tests/conftest.py` and
`tests/cloud/conftest.py` the top-level module ``conftest``; whichever loads first wins
``sys.modules["conftest"]``, and the four pre-existing test modules' ``from conftest
import meta`` then resolves to the wrong file and every one of them fails to collect.

With this marker the fakes are importable as ``cloud.fake_firestore`` and
``cloud.fake_gcs``, which is how `tests/conformance/conftest.py` reaches them to register
the cloud adapters into the shared adapter parameterisation.
"""
