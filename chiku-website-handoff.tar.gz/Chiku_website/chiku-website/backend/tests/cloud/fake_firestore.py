"""A Firestore that **enforces** three documented constraints rather than permitting them.

**This is the unit's real evidence, and it is not a mock.** A mock records calls and
returns what it was told to. This fake refuses three things the service refuses, and each
refusal is the only thing standing between a Critical review finding and a suite that is
green while the adapter is wrong:

* **A read issued after a write inside a transaction raises** `ReadAfterWriteError`. A
  Firestore transaction is a sequence of reads followed by a sequence of writes. This is
  what the R-05 finding was about: the pre-fix algorithm read the prune's survivors
  *after* two writes, and by this design's own pruning invariant that fires on **every**
  save once the retention cap is reached. A fake that permitted read-after-write would
  make the corrected ordering untestable and the regression invisible.
* **A document over 1,048,576 bytes raises** `DocumentTooLargeError`. This is what forces
  the blob substitution, and it is what the R-01 finding was about: the **revision entry**,
  not the content document, is the shape that cannot fit.
* **A query needing an undeclared composite index raises** `MissingCompositeIndexError`.
  An undeclared composite index fails at runtime, which is exactly the failure BR31.4
  exists to prevent -- and it is what would happen if the survivor read were ever
  reshaped into the filtered form. `where` exists on `FakeQuery` and deliberately **not**
  on `app.cloud.clients.QueryLike`, so that refusal is demonstrable here while a filtered
  read stays unwritable in the adapters.

**What this fake cannot prove.** It models Firestore as this design understands it from
published documentation; nothing here has ever spoken to the service. It enforces the
document-size limit using the very size function the adapter budgets against
(`app.cloud.clients.estimate_document_bytes`), so what it catches is a **missing or
mis-ordered substitution**, not a mis-measured one. Two independently written size
functions would have caught that third case and would have disagreed constantly about
where the boundary is; sharing one is the honest trade and this sentence is the disclosure.

**Serialisation.** Transactions are serialised with a lock. Firestore reaches the same
observable outcome -- serializable isolation -- by optimistic concurrency with automatic
retry. The lock models the *result*, which is all the adapters can depend on: every
conflict decision is taken inside the transaction from a read issued in its read phase, so
it is correct under either mechanism.
"""

from __future__ import annotations

from collections.abc import AsyncIterator, Sequence
from dataclasses import dataclass, field
from operator import itemgetter
from types import TracebackType
from typing import Any

import anyio

from app.cloud.clients import (
    ASCENDING,
    DESCENDING,
    FIRESTORE_DOCUMENT_LIMIT_BYTES,
    DocumentData,
    DocumentReferenceLike,
    QueryLike,
    estimate_document_bytes,
)
from cloud.journal import FIRESTORE, Journal, Operation


class FakeFirestoreError(Exception):
    """A refusal this fake makes on the service's behalf.

    Deliberately **without** a ``code`` attribute, so `app.cloud.clients.tolerate` cannot
    mistake one of these for an ordinary not-found and swallow it. A constraint violation
    must reach the test.
    """


class ReadAfterWriteError(FakeFirestoreError):
    """A read was issued after a write inside the same transaction (BR31.3)."""


class DocumentTooLargeError(FakeFirestoreError):
    """A document exceeded the per-document size limit (BR31.2)."""


class MissingCompositeIndexError(FakeFirestoreError):
    """A query needed a composite index that no deployment artifact declares (BR31.4)."""


@dataclass(frozen=True, slots=True)
class IndexDefinition:
    """One declared composite index, spelled exactly as the deployment artifact spells it."""

    collection: str
    fields: tuple[tuple[str, str], ...]


@dataclass
class FirestoreStorage:
    """The documents every handle opened over this fake shares.

    Separate from the client for the same reason `MemoryContentStorage` is separate from
    its store: several conformance assertions need a **second, independent handle over the
    same storage**, and a client that owned its own dictionaries could not offer one.
    """

    collections: dict[str, dict[str, dict[str, Any]]] = field(default_factory=dict)

    def documents(self, collection: str) -> dict[str, dict[str, Any]]:
        return self.collections.setdefault(collection, {})


class FakeSnapshot:
    """Models ``DocumentSnapshot``. Absence is a snapshot that does not exist, not an error."""

    def __init__(self, data: dict[str, Any] | None) -> None:
        self._data = data

    @property
    def exists(self) -> bool:
        return self._data is not None

    def to_dict(self) -> dict[str, Any] | None:
        if self._data is None:
            return None
        return dict(self._data)


async def _stream(snapshots: Sequence[FakeSnapshot]) -> AsyncIterator[FakeSnapshot]:
    for snapshot in snapshots:
        yield snapshot


def _sorted_rows(
    rows: list[dict[str, Any]], orders: tuple[tuple[str, str], ...]
) -> list[dict[str, Any]]:
    """Apply the order-by clauses, computed rather than inherited.

    Successive **stable** sorts applied in reverse clause order, which is how a multi-key
    sort whose parts run in different directions is expressed without hard-coding a rank
    for any known value. A fake that returned its dictionary's insertion order would pass
    every ordering assertion the suite makes while the real adapter failed them -- the
    exact inversion the two-implementation rule exists to catch (BR22.3).
    """
    ordered = list(rows)
    for field_path, direction in reversed(orders):
        # `itemgetter` rather than a lambda: a lambda closing over the loop variable is
        # correct here only because it is called before the next iteration, and that is
        # exactly the reasoning a reader should not have to reconstruct.
        ordered.sort(key=itemgetter(field_path), reverse=direction == DESCENDING)
    return ordered


class FakeQuery:
    """Models ``AsyncQuery``, and refuses a query no declared index can serve."""

    def __init__(
        self,
        client: FakeFirestore,
        collection: str,
        *,
        orders: tuple[tuple[str, str], ...] = (),
        limit_count: int | None = None,
        filters: tuple[tuple[str, str, str], ...] = (),
    ) -> None:
        self._client = client
        self._collection = collection
        self._orders = orders
        self._limit = limit_count
        self._filters = filters

    def order_by(self, field_path: str, direction: str) -> FakeQuery:
        return FakeQuery(
            self._client,
            self._collection,
            orders=(*self._orders, (field_path, direction)),
            limit_count=self._limit,
            filters=self._filters,
        )

    def limit(self, count: int) -> FakeQuery:
        return FakeQuery(
            self._client,
            self._collection,
            orders=self._orders,
            limit_count=count,
            filters=self._filters,
        )

    def where(self, field_path: str, op_string: str, value: str) -> FakeQuery:
        """An equality filter. **Not on `QueryLike`, and that is the point.**

        It exists so the "a filtered survivor read is refused for want of a declared
        index" demonstration is executable. The adapters cannot reach it, because the
        Protocol they are written against does not carry it.
        """
        return FakeQuery(
            self._client,
            self._collection,
            orders=self._orders,
            limit_count=self._limit,
            filters=(*self._filters, (field_path, op_string, value)),
        )

    def _require_index(self) -> None:
        """Firestore's index rule, as documented.

        A query with no filter and at most one order-by clause is served by the automatic
        single-field indexes. Anything else needs an explicitly declared composite index,
        and without one the query fails **at runtime** -- which is the loud failure BR31.4
        prefers, but only if the definition travels with the deployment artifacts.
        """
        if not self._filters and len(self._orders) <= 1:
            return
        required = tuple((path, ASCENDING) for path, _, _ in self._filters) + self._orders
        for declared in self._client.composite_indexes:
            if declared.collection == self._collection and declared.fields == required:
                return
        raise MissingCompositeIndexError(
            f"no declared composite index on {self._collection} for {required}"
        )

    def _rows(self) -> list[dict[str, Any]]:
        self._require_index()
        rows = [
            dict(document)
            for document in self._client.storage.documents(self._collection).values()
            # Firestore excludes a document that is missing an ordered field.
            if all(path in document for path, _ in self._orders)
            and all(document.get(path) == value for path, _, value in self._filters)
        ]
        ordered = _sorted_rows(rows, self._orders)
        if self._limit is None:
            return ordered
        return ordered[: self._limit]

    def snapshots(self) -> list[FakeSnapshot]:
        return [FakeSnapshot(row) for row in self._rows()]

    def operation(self, *, in_transaction: bool) -> Operation:
        return Operation(
            service=FIRESTORE,
            kind="read-query",
            target=self._collection,
            in_transaction=in_transaction,
            order_by=self._orders,
            limit=self._limit,
            filters=self._filters,
        )

    def stream(self) -> AsyncIterator[FakeSnapshot]:
        snapshots = self.snapshots()
        self._client.journal.record(self.operation(in_transaction=False))
        return _stream(snapshots)


class FakeCollection(FakeQuery):
    """Models ``AsyncCollectionReference``, which is a query that can also name a document."""

    def document(self, document_id: str) -> FakeDocumentReference:
        return FakeDocumentReference(self._client, self._collection, document_id)


class FakeDocumentReference:
    """Models ``AsyncDocumentReference``."""

    def __init__(self, client: FakeFirestore, collection: str, document_id: str) -> None:
        self._client = client
        self.collection = collection
        self.document_id = document_id

    @property
    def target(self) -> str:
        return f"{self.collection}/{self.document_id}"

    def snapshot(self) -> FakeSnapshot:
        return FakeSnapshot(self._client.storage.documents(self.collection).get(self.document_id))

    async def get(self) -> FakeSnapshot:
        taken = self.snapshot()
        self._client.journal.record(
            Operation(service=FIRESTORE, kind="read-document", target=self.target)
        )
        return taken

    async def set(self, document_data: DocumentData) -> object:
        self._client.enforce_document_size(self.target, document_data)
        self._client.storage.documents(self.collection)[self.document_id] = dict(document_data)
        self._client.journal.record(Operation(service=FIRESTORE, kind="write", target=self.target))
        return None

    async def delete(self) -> object:
        # Deleting a document that is not there succeeds, as the service documents.
        self._client.storage.documents(self.collection).pop(self.document_id, None)
        self._client.journal.record(Operation(service=FIRESTORE, kind="delete", target=self.target))
        return None


class FakeTransaction:
    """Models ``AsyncTransaction``: a read phase, then a write phase, then a commit.

    The read/write split is enforced by `_written`, and that single flag is the whole of
    this fake's R-05 value. Every write is buffered and applied on a clean exit, so an
    aborted transaction leaves nothing behind -- which is what makes "a conflicting commit
    performs no side effect" true by construction rather than by argument.
    """

    def __init__(self, client: FakeFirestore) -> None:
        self._client = client
        self._written = False
        self._pending: list[tuple[str, str, dict[str, Any] | None]] = []

    async def __aenter__(self) -> FakeTransaction:
        await self._client.transaction_lock.acquire()
        self._written = False
        self._pending = []
        self._client.journal.record(
            Operation(service=FIRESTORE, kind="begin", target="", in_transaction=True)
        )
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        traceback: TracebackType | None,
    ) -> bool:
        try:
            if exc is None:
                for collection, document_id, data in self._pending:
                    documents = self._client.storage.documents(collection)
                    if data is None:
                        documents.pop(document_id, None)
                    else:
                        documents[document_id] = data
            self._client.journal.record(
                Operation(
                    service=FIRESTORE,
                    kind="commit" if exc is None else "rollback",
                    target="",
                    in_transaction=True,
                )
            )
        finally:
            self._client.transaction_lock.release()
        # Never swallow: the adapter's stale-write signal travels out this way.
        return False

    def get(self, target: DocumentReferenceLike | QueryLike) -> AsyncIterator[FakeSnapshot]:
        if self._written:
            raise ReadAfterWriteError(
                "a Firestore transaction rejects a read issued after a write (BR31.3)"
            )
        if isinstance(target, FakeQuery):
            snapshots = target.snapshots()
            self._client.journal.record(target.operation(in_transaction=True))
            return _stream(snapshots)
        reference = _as_fake_reference(target)
        taken = reference.snapshot()
        self._client.journal.record(
            Operation(
                service=FIRESTORE,
                kind="read-document",
                target=reference.target,
                in_transaction=True,
            )
        )
        return _stream([taken])

    def set(self, reference: DocumentReferenceLike, document_data: DocumentData) -> object:
        target = _as_fake_reference(reference)
        self._client.enforce_document_size(target.target, document_data)
        self._written = True
        self._pending.append((target.collection, target.document_id, dict(document_data)))
        self._client.journal.record(
            Operation(service=FIRESTORE, kind="write", target=target.target, in_transaction=True)
        )
        return None

    def delete(self, reference: DocumentReferenceLike) -> object:
        target = _as_fake_reference(reference)
        self._written = True
        self._pending.append((target.collection, target.document_id, None))
        self._client.journal.record(
            Operation(service=FIRESTORE, kind="delete", target=target.target, in_transaction=True)
        )
        return None


def _as_fake_reference(reference: object) -> FakeDocumentReference:
    if not isinstance(reference, FakeDocumentReference):
        raise TypeError(f"not a document reference from this fake: {reference!r}")
    return reference


class FakeFirestore:
    """Models ``AsyncClient``, with the service's constraints enforced rather than assumed."""

    def __init__(
        self,
        storage: FirestoreStorage,
        *,
        journal: Journal,
        composite_indexes: Sequence[IndexDefinition],
        transaction_lock: anyio.Lock,
        document_limit_bytes: int = FIRESTORE_DOCUMENT_LIMIT_BYTES,
    ) -> None:
        self.storage = storage
        self.journal = journal
        self.composite_indexes = tuple(composite_indexes)
        self.transaction_lock = transaction_lock
        self.document_limit_bytes = document_limit_bytes

    def enforce_document_size(self, target: str, document_data: DocumentData) -> None:
        """Refuse a document over the limit, which is what forces the blob substitution.

        Raised where the write is *issued* rather than at commit, so the failing call site
        is the one a test reads in the traceback. The service reports it at commit; the
        distinction does not change which writes are legal.
        """
        size = estimate_document_bytes(document_data)
        if size > self.document_limit_bytes:
            raise DocumentTooLargeError(
                f"{target}: {size} bytes exceeds the {self.document_limit_bytes}-byte limit"
            )

    def collection(self, collection_id: str) -> FakeCollection:
        return FakeCollection(self, collection_id)

    def transaction(self) -> FakeTransaction:
        return FakeTransaction(self)
