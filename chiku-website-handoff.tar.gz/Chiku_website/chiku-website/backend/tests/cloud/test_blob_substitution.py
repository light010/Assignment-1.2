"""The R-01 regression: substitution is per stored field, and the revision entry is a field.

FR4.6 requires the `ContentStore` port to accept a content document of up to 1,500,000
decoded characters, which in UTF-8 can exceed 4 MB. Firestore's per-document limit is
1,048,576 bytes, **and a revision entry stores the full content** -- so a save this port
must accept cannot fit in one Firestore document.

An earlier version of the algorithm substituted the **content document** and wrote the
revision entry inline. That resolved the size conflict for the wrong object, and a
developer following those steps would have shipped code that fails at runtime on exactly
the large save the design claimed to have resolved.

Every assertion below is about **which blobs exist**, not merely that the save succeeded.
A branch whose outcome is unspecified cannot be asserted by the test a 100% branch floor
requires, which is why the largest-first order and its `draft`-before-`published`
tie-break were fixed at design time rather than left to the implementation.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence

import pytest

from app.cloud import content_firestore
from app.cloud.blobs import (
    LARGE_PAYLOAD_THRESHOLD_BYTES,
    blob_field,
    blob_key_for,
    plan_substitution,
)
from app.cloud.clients import (
    FIRESTORE_DOCUMENT_LIMIT_BYTES,
    DocumentData,
    document_id_for,
    estimate_document_bytes,
)
from app.cloud.content_firestore import (
    CONTENT_COLLECTION,
    CONTENT_FIELD,
    DRAFT_FIELD,
    PUBLISHED_FIELD,
    REVISIONS_COLLECTION,
)
from app.content.store import CONTENT_DOCUMENT_ID
from cloud.fake_firestore import DocumentTooLargeError
from cloud.harness import CloudHarness, accepted, save
from conformance.conftest import DEFAULT_LISTING_CAP, PRODUCTION_RETENTION, SEED, at

pytestmark = pytest.mark.anyio

# --- the planner, at a scale a reader can check by hand ------------------------------ #
#
# The real threshold and limit are hundreds of kilobytes, which makes the ORDERING rules
# -- the only thing these four cases are about -- unreadable. `ROOM` is measured from the
# empty document rather than written as a literal, so the cases stay true if the
# document-name allowance ever changes.

ROOM = 1_800
SMALL_THRESHOLD = 1_000
SMALL_LIMIT = estimate_document_bytes({}) + ROOM
ORDER = (DRAFT_FIELD, PUBLISHED_FIELD)


def plan(**inline: str) -> tuple[str, ...]:
    return plan_substitution(
        inline,
        order=ORDER,
        other_fields={},
        threshold=SMALL_THRESHOLD,
        limit=SMALL_LIMIT,
    )


def stored_content_document(cloud: CloudHarness) -> dict[str, object]:
    return cloud.documents.collections[CONTENT_COLLECTION][CONTENT_DOCUMENT_ID]


def stored_revision(cloud: CloudHarness, revision_id: str) -> dict[str, object]:
    return cloud.documents.collections[REVISIONS_COLLECTION][document_id_for(revision_id)]


def test_a_field_over_the_threshold_is_substituted_and_one_that_fits_is_left_alone() -> None:
    """Step 1 of the rule, in both directions.

    The negative half matters as much as the positive one: an implementation that
    substituted everything would pass every "the large payload round-trips" assertion in
    the conformance suite while turning every small save into a Cloud Storage write, and
    reads would still be transparent, so nothing else would notice.
    """
    assert plan(draft="d" * 10, published="p" * 10) == ()
    assert plan(draft="d" * (SMALL_THRESHOLD + 1), published="p" * 10) == (DRAFT_FIELD,)
    assert plan(draft="d" * 10, published="p" * (SMALL_THRESHOLD + 1)) == (PUBLISHED_FIELD,)


def test_a_field_that_fits_alone_is_substituted_when_the_document_still_does_not_fit() -> None:
    """Step 2, and it is reachable only for `ContentDocument`.

    `ContentDocument` carries **both** full-content fields on one document, so each can sit
    under the threshold while their sum exceeds the limit. `ContentRevision` carries one,
    so step 1 settles it. A per-field check alone -- the obvious reading of "substitute any
    field over the threshold" -- writes a document the service rejects.
    """
    assert plan(draft="d" * 900, published="p" * 950) == (PUBLISHED_FIELD,)


def test_the_remaining_fields_are_substituted_largest_first() -> None:
    """The order is **deterministic**, and `published` here is chosen over `draft`.

    Either choice yields a document that fits, and reads reverse substitution either way,
    so no functional assertion can tell them apart. What the fixed order buys is a
    **single** predictable stored state, which is the only thing that makes "assert which
    blobs exist" a sentence with a meaning.
    """
    assert plan(draft="d" * 940, published="p" * 950) == (PUBLISHED_FIELD,)
    assert plan(draft="d" * 950, published="p" * 940) == (DRAFT_FIELD,)


def test_a_tie_is_broken_with_draft_before_published() -> None:
    """The last unspecified branch in the rule, closed at the R-05 fix.

    Two equal fields have no largest, and "whatever else is needed" does not say which.
    A module carrying a 100% branch-coverage floor cannot hold a branch whose outcome is
    unspecified, so the tie is settled by a fixed field order rather than by whatever the
    sort happened to do.
    """
    assert plan(draft="x" * 925, published="x" * 925) == (DRAFT_FIELD,)


# --- the adapter, at the real threshold ---------------------------------------------- #


async def test_a_revision_entry_over_the_threshold_is_substituted(cloud: CloudHarness) -> None:
    """R-01. The revision entry is the shape the size conflict is really about.

    `contract-summary.md` C2 `payload_size` says it outright: *a revision entry stores the
    full content*. The assertion is on the stored field -- `content_blob` present and
    `content` absent -- because a save that merely succeeded would look identical if the
    entry had been small enough to fit inline by luck.
    """
    store = cloud.content_store(seed=SEED, listing_cap=DEFAULT_LISTING_CAP)
    payload = "q" * (FIRESTORE_DOCUMENT_LIMIT_BYTES + 1)
    marker = "w1"

    accepted(
        await save(
            store,
            content=payload,
            base_revision=0,
            action="draft",
            marker=marker,
            retention=PRODUCTION_RETENTION,
            now=at(1),
        )
    )

    entry = stored_revision(cloud, marker)
    assert blob_field(CONTENT_FIELD) in entry
    assert CONTENT_FIELD not in entry
    assert entry[blob_field(CONTENT_FIELD)] == blob_key_for(payload)

    # ... and the caller cannot tell: the port returns content, never a key.
    read_back = await store.read_revision(marker)
    assert read_back is not None
    assert read_back.content == payload


async def test_writing_the_revision_entry_inline_is_refused(
    cloud: CloudHarness, monkeypatch: pytest.MonkeyPatch
) -> None:
    """The fake **bites**, and it bites on exactly the pre-fix algorithm.

    The mutation below substitutes the content document and leaves the revision entry
    inline, which is precisely what the earlier design specified. Every other assertion in
    this file would still pass under it -- the document fits, the save is accepted, reads
    are transparent -- so without a fake that enforces the per-document limit the R-01
    regression would be invisible while the suite stayed green.
    """
    real = plan_substitution

    def substituting_only_the_document(
        inline_fields: Mapping[str, str],
        *,
        order: Sequence[str],
        other_fields: DocumentData,
        threshold: int,
        limit: int,
    ) -> tuple[str, ...]:
        if tuple(order) == (CONTENT_FIELD,):
            return ()
        return real(
            inline_fields,
            order=order,
            other_fields=other_fields,
            threshold=threshold,
            limit=limit,
        )

    monkeypatch.setattr(content_firestore, "plan_substitution", substituting_only_the_document)

    store = cloud.content_store(seed=SEED, listing_cap=DEFAULT_LISTING_CAP)
    payload = "q" * (FIRESTORE_DOCUMENT_LIMIT_BYTES + 1)

    with pytest.raises(DocumentTooLargeError) as refusal:
        await save(
            store,
            content=payload,
            base_revision=0,
            action="draft",
            marker="w1",
            retention=PRODUCTION_RETENTION,
            now=at(1),
        )

    assert REVISIONS_COLLECTION in str(refusal.value)


async def test_two_fields_that_each_fit_are_substituted_when_they_do_not_fit_together(
    cloud: CloudHarness,
) -> None:
    """Step 2 and the tie-break, through the adapter rather than through the planner.

    A publish puts the same payload in `draft` and in `published`, on one document. At
    exactly the threshold neither field triggers step 1, and their sum exceeds the limit --
    so this is the case a per-field-only implementation gets wrong, and the tie decides
    `draft`.
    """
    store = cloud.content_store(seed=SEED, listing_cap=DEFAULT_LISTING_CAP)
    payload = "a" * LARGE_PAYLOAD_THRESHOLD_BYTES

    accepted(
        await save(
            store,
            content=payload,
            base_revision=0,
            action="publish",
            marker="w1",
            retention=PRODUCTION_RETENTION,
            now=at(1),
        )
    )

    document = stored_content_document(cloud)
    assert blob_field(DRAFT_FIELD) in document
    assert DRAFT_FIELD not in document
    assert PUBLISHED_FIELD in document
    assert blob_field(PUBLISHED_FIELD) not in document

    state = await store.read_state()
    assert state.draft == payload
    assert state.published == payload


async def test_reads_reverse_substitution_transparently(cloud: CloudHarness) -> None:
    """Both paths, on one document, read back through one port operation.

    After a draft write of an oversized payload the document holds a substituted `draft`
    and an inline `published` -- so a single `read_state` exercises the substituted and the
    inline branch at once, which is what makes the substitution invisible rather than
    merely intended.
    """
    store = cloud.content_store(seed=SEED, listing_cap=DEFAULT_LISTING_CAP)
    payload = "\U0001f600" * (LARGE_PAYLOAD_THRESHOLD_BYTES // 2)

    accepted(
        await save(
            store,
            content=payload,
            base_revision=0,
            action="draft",
            marker="w1",
            retention=PRODUCTION_RETENTION,
            now=at(1),
        )
    )

    document = stored_content_document(cloud)
    assert blob_field(DRAFT_FIELD) in document
    assert PUBLISHED_FIELD in document

    elsewhere = cloud.content_store(seed=SEED, listing_cap=DEFAULT_LISTING_CAP)
    state = await elsewhere.read_state()
    # Compared as BYTES: a store that re-encoded on the way through a blob returns an
    # equal-LOOKING document and passes any looser assertion (BR22.5).
    assert state.draft.encode("utf-8") == payload.encode("utf-8")
    assert state.published.encode("utf-8") == SEED.encode("utf-8")


async def test_an_existing_published_blob_is_carried_forward_rather_than_rewritten(
    cloud: CloudHarness,
) -> None:
    """A draft write must not download, rehash and re-upload a `published` it never touched.

    The key is a hash of the content, so a rewrite would be harmless and invisible -- which
    is exactly why nothing else would catch it. What it would cost is a full download and
    a full upload of a multi-megabyte payload on every draft save, and the failure mode on
    a metered object store is cost and latency, not incorrectness.
    """
    store = cloud.content_store(seed=SEED, listing_cap=DEFAULT_LISTING_CAP)
    published = "p" * (LARGE_PAYLOAD_THRESHOLD_BYTES + 1)
    accepted(
        await save(
            store,
            content=published,
            base_revision=0,
            action="publish",
            marker="w1",
            retention=PRODUCTION_RETENTION,
            now=at(1),
        )
    )
    carried = stored_content_document(cloud)[blob_field(PUBLISHED_FIELD)]
    assert carried == blob_key_for(published)

    cloud.journal.clear()
    accepted(
        await save(
            store,
            content='{"v":2}',
            base_revision=1,
            action="draft",
            marker="w2",
            retention=PRODUCTION_RETENTION,
            now=at(2),
        )
    )

    # Nothing re-uploaded: the key was carried, not recomputed.
    assert cloud.journal.of_kind("upload") == []
    # Exactly ONE download, and it is the one the PORT forces rather than one the storage
    # decision does: `commit` returns the new `ContentState`, whose `published` is the
    # document's text and not its storage representation, so a draft save whose published
    # document is oversized has to read it back. Asserting the count rather than omitting
    # the check is what keeps that cost visible.
    assert [operation.target for operation in cloud.journal.of_kind("download")] == [carried]
    document = stored_content_document(cloud)
    assert document[blob_field(PUBLISHED_FIELD)] == carried
    assert document[DRAFT_FIELD] == '{"v":2}'

    state = await store.read_state()
    assert state.draft == '{"v":2}'
    assert state.published == published
