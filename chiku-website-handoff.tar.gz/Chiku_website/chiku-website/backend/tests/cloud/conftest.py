"""Fixtures for what is specific to U11, on top of the shared conformance contract.

**The conformance suite is where most of this unit's evidence is**, because registering
the three cloud adapters into `tests/conformance/conftest.py` runs the entire existing
contract against them with no new assertions written. Nothing in this directory repeats
one of those assertions. What is here is the two things the shared contract cannot see:
the transaction's read/write split, and the blob substitution that makes an oversized save
storable at all.
"""

from __future__ import annotations

import pytest

from cloud.harness import CloudHarness

# The seed, the production retention policy and the listing cap are taken from
# `conformance.conftest` by the tests that need them, rather than restated here. A second
# copy of a seed carrying a U+2019 and an astral-plane codepoint would be a second thing
# to keep in step, and the byte-identity obligation it exercises is the suite's, not this
# directory's.


@pytest.fixture
def anyio_backend() -> str:
    """Pinned to asyncio alone; the production runtime is asyncio."""
    return "asyncio"


@pytest.fixture
def cloud() -> CloudHarness:
    """A fresh Firestore and bucket, sharing one recorded timeline."""
    return CloudHarness()
