"""One cloud harness, built from the two fakes, shared by both suites that need it.

`tests/conformance/conftest.py` registers the three adapters into the shared parameterised
fixtures from here, and `tests/cloud/conftest.py` builds the same harness for this unit's
own tests. A `conftest.py` is a pytest hook file rather than an importable API, so the
builders live in a module of their own instead of being imported out of one conftest by
another. This file is not in the plan's file list, for that reason.

**The declared composite index is spelled here, literally, as `app/cloud/INDEXES.md`
spells it** -- and deliberately not imported from the adapter. An index the adapter
declares to itself proves nothing: what BR31.4 is about is whether the query the adapter
issues is served by the definition that travels with the **deployment artifacts**. Writing
it out independently is what makes the fake's refusal a real check rather than a tautology.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

import anyio

from app.cloud.assets_gcs import GcsAssetStore
from app.cloud.content_firestore import FirestoreContentStore
from app.cloud.identity_firestore import FirestoreIdentityStore
from app.content.store import (
    Action,
    CommitResult,
    ContentState,
    ContentStore,
    RetentionPolicy,
)
from cloud.fake_firestore import FakeFirestore, FirestoreStorage, IndexDefinition
from cloud.fake_gcs import FakeBucket, FakeStorage
from cloud.journal import Journal, Operation

# The one composite index this unit requires, as `app/cloud/INDEXES.md` declares it.
# EXACTLY ONE, on purpose (BR31.4): the retention prune's survivor read is shaped to need
# no index of its own, so if a second definition ever has to appear here, a query has been
# reshaped into something the deployment plan does not cover.
DECLARED_INDEXES: tuple[IndexDefinition, ...] = (
    IndexDefinition(
        collection="revisions",
        fields=(
            ("revision", "DESCENDING"),
            ("baseline", "ASCENDING"),
            ("action", "DESCENDING"),
        ),
    ),
)


@dataclass
class CloudHarness:
    """The storage behind a set of adapter handles, plus the timeline they both write to.

    Every ``*_store`` call builds a **new client over the same storage**, because several
    conformance assertions need a second, independent handle -- that a read wrote nothing,
    that a counter outlives the object that wrote it. The transaction lock is held here
    rather than on a client for the same reason: two handles must contend with each other,
    not each with itself.
    """

    journal: Journal = field(default_factory=Journal)
    documents: FirestoreStorage = field(default_factory=FirestoreStorage)
    indexes: tuple[IndexDefinition, ...] = DECLARED_INDEXES
    _lock: anyio.Lock = field(default_factory=anyio.Lock)
    _objects: FakeStorage | None = None

    @property
    def objects(self) -> FakeStorage:
        if self._objects is None:
            self._objects = FakeStorage(journal=self.journal)
        return self._objects

    def client(self) -> FakeFirestore:
        return FakeFirestore(
            self.documents,
            journal=self.journal,
            composite_indexes=self.indexes,
            transaction_lock=self._lock,
        )

    def bucket(self) -> FakeBucket:
        return FakeBucket(self.objects)

    def content_store(self, *, seed: str, listing_cap: int) -> FirestoreContentStore:
        return FirestoreContentStore(
            self.client(), self.bucket(), seed=seed, listing_cap=listing_cap
        )

    def identity_store(self) -> FirestoreIdentityStore:
        return FirestoreIdentityStore(self.client())

    def asset_store(self) -> GcsAssetStore:
        return GcsAssetStore(self.bucket())


async def save(
    store: ContentStore,
    *,
    content: str,
    base_revision: int,
    action: Action,
    marker: str,
    retention: RetentionPolicy,
    now: datetime,
) -> CommitResult:
    """Call `commit`, routing the mutation token through a named local.

    A string literal sitting at a keyword whose name contains `token` is what the
    hardcoded-credential lint rule looks for. Routing the value through a name is cheaper
    and more honest than suppressing that rule at every call site -- the same move
    `tests/conformance/test_content_store.py` makes, for the same reason.
    """
    return await store.commit(
        content=content,
        base_revision=base_revision,
        action=action,
        mutation_token=marker,
        retention=retention,
        now=now,
    )


def accepted(result: CommitResult) -> ContentState:
    assert isinstance(result, ContentState), f"expected an accepted write, got {result!r}"
    return result


def transaction_segments(journal: Journal) -> list[list[Operation]]:
    """The recorded timeline, split into one list per transaction.

    Positions within a segment are what the read/write split is asserted on, and the
    positions of the segments themselves are what BR31.2's blob-before-transaction
    ordering is asserted on.
    """
    segments: list[list[Operation]] = []
    current: list[Operation] | None = None
    for operation in journal.operations:
        if operation.kind == "begin":
            current = []
            segments.append(current)
        elif current is not None:
            current.append(operation)
            if operation.kind in {"commit", "rollback"}:
                current = None
    return segments
