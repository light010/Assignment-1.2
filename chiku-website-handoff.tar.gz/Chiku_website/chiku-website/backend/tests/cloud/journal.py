"""One timeline across both fake services.

BR31.2 is an obligation about **ordering across two services**: every blob write lands in
Cloud Storage *before* the Firestore transaction opens. Neither service can witness that
on its own -- a per-service log shows two orderings that cannot be compared -- so both
fakes append to one shared `Journal` and the assertion is about positions in it.

This module is not in the plan's file list. It is here because the alternative was to put
`Journal` inside one fake and have the other import it, which would have made the object
store depend on the document store for a reason that has nothing to do with either.
"""

from __future__ import annotations

from dataclasses import dataclass, field

FIRESTORE = "firestore"
STORAGE = "storage"


@dataclass(frozen=True, slots=True)
class Operation:
    """One thing a fake was asked to do.

    ``order_by`` and ``limit`` are recorded because the retention prune's survivor read is
    specified by its **shape**, not only by its result: a single unfiltered ``revision``
    DESC read of the bounded set (BR31.4). A filtered read returns the same survivors and
    would pass any assertion about the stored outcome.
    """

    service: str
    kind: str
    target: str
    in_transaction: bool = False
    order_by: tuple[tuple[str, str], ...] = ()
    limit: int | None = None
    filters: tuple[tuple[str, str, str], ...] = ()


@dataclass
class Journal:
    """The recorded timeline. Shared by a `FakeFirestore` and a `FakeStorage`."""

    operations: list[Operation] = field(default_factory=list)

    def record(self, operation: Operation) -> None:
        self.operations.append(operation)

    def clear(self) -> None:
        self.operations.clear()

    def kinds(self) -> list[str]:
        return [operation.kind for operation in self.operations]

    def first_index(self, *kinds: str) -> int:
        """The position of the first operation of any of ``kinds``, or ``-1``."""
        for position, operation in enumerate(self.operations):
            if operation.kind in kinds:
                return position
        return -1

    def last_index(self, *kinds: str) -> int:
        """The position of the last operation of any of ``kinds``, or ``-1``."""
        found = -1
        for position, operation in enumerate(self.operations):
            if operation.kind in kinds:
                found = position
        return found

    def of_kind(self, *kinds: str) -> list[Operation]:
        return [operation for operation in self.operations if operation.kind in kinds]
