"""The four claims `app/cloud/clients.py` makes that neither other module is about.

They are small, and three of them are the kind of claim that is only ever exercised on a
bad day: an error this package did not expect, a key the port is forbidden to validate, a
field type nothing should store. Leaving them unasserted would mean the module's most
load-bearing sentence -- *nothing but the named status is swallowed* -- was prose.

This module is not in the plan's file list. It is here because the claims are made in
production code and belong to neither the transaction ordering nor the blob substitution.
"""

from __future__ import annotations

import pytest

from app.cloud.clients import (
    ALREADY_EXISTS_STATUS,
    NOT_FOUND_STATUS,
    document_id_for,
    estimate_document_bytes,
    status_code_of,
    tolerate,
    value_bytes,
)


class ServiceError(Exception):
    """Shaped like ``google.api_core.exceptions.GoogleAPICallError``: a status on ``code``."""

    def __init__(self, code: int) -> None:
        super().__init__(f"status {code}")
        self.code = code


def failing(error: Exception) -> object:
    raise error


def test_only_the_named_status_is_tolerated() -> None:
    """The module's central claim, and the one whose failure is silent.

    `tolerate` exists so an absent object can be deleted without error (BR22.10). What it
    must **not** do is turn a permissions failure, a quota refusal or an outage into a
    successful no-op: the consumer maps an unanswerable store to a 503, and a swallowed
    error would make a broken deployment look like an empty bucket.
    """
    assert tolerate(NOT_FOUND_STATUS, lambda: "answered", fallback="fell back") == "answered"

    absent = ServiceError(NOT_FOUND_STATUS)
    assert tolerate(NOT_FOUND_STATUS, lambda: failing(absent), fallback=None) is None

    forbidden = ServiceError(403)
    with pytest.raises(ServiceError):
        tolerate(NOT_FOUND_STATUS, lambda: failing(forbidden), fallback=None)

    # A status this call was not told to tolerate, even though the package knows the
    # constant, is still re-raised: `tolerate` matches one status, not a set.
    conflict = ServiceError(ALREADY_EXISTS_STATUS)
    with pytest.raises(ServiceError):
        tolerate(NOT_FOUND_STATUS, lambda: failing(conflict), fallback=None)

    ordinary = ValueError("nothing to do with the service")
    with pytest.raises(ValueError, match="nothing to do with the service"):
        tolerate(NOT_FOUND_STATUS, lambda: failing(ordinary), fallback=None)


def test_an_error_carrying_no_integer_status_is_not_mistaken_for_one() -> None:
    """`code` is matched on because the error CLASS is not importable without the SDK.

    That is a duck-typed match, so the reverse risk is real: an unrelated exception that
    happens to carry a `code` attribute must not be read as a service status. Only an
    integer counts, and anything else is reported as "no status" so `tolerate` re-raises.
    """
    assert status_code_of(ServiceError(NOT_FOUND_STATUS)) == NOT_FOUND_STATUS
    assert status_code_of(ValueError("no code at all")) is None

    class Decoy(Exception):
        code = "not-a-status"

    assert status_code_of(Decoy()) is None
    with pytest.raises(Decoy):
        tolerate(NOT_FOUND_STATUS, lambda: failing(Decoy()), fallback=None)


def test_a_field_type_with_no_documented_size_is_refused_rather_than_guessed() -> None:
    """The size model is a reproduction of a published table, not an approximation.

    The substitution planner budgets against it and the test fake enforces the limit with
    it, so a type it cannot measure has to stop the write: guessing would make a document
    that fits by the adapter's arithmetic and not by the service's.
    """
    assert value_bytes("abc") == 4  # UTF-8 bytes plus one
    assert value_bytes("\U0001f600") == 5  # four UTF-8 bytes plus one
    assert value_bytes(7) == 8
    assert value_bytes(True) == 1  # a boolean costs 1, not 8, although `bool` IS an `int`
    assert value_bytes(None) == 1

    with pytest.raises(TypeError, match="no documented Firestore size"):
        value_bytes(1.5)

    # A field's own name costs its UTF-8 length plus one, and a document carries a fixed
    # allowance for its name.
    empty = estimate_document_bytes({})
    assert estimate_document_bytes({"ab": 7}) == empty + 3 + 8


def test_a_document_name_cannot_be_illegal_however_the_key_was_spelled() -> None:
    """The ports validate nothing, so an adapter must not be breakable by a key.

    A Firestore document name may not contain ``/``, may not be ``.`` or ``..`` and may
    not match ``__.*__``; a Cloud Storage object name may not contain a line break. The
    encoding makes all of that structurally impossible instead of checked -- and it is
    lossless, which is what keeps it the representation conversion BR22.6 permits rather
    than a value the store changed.
    """
    import base64

    awkward = [
        "../../etc/passwd",
        "a/b/c",
        "..",
        ".",
        "__reserved__",
        "with a \r\n line break",
        "\U0001f600 \u2019 unicode",
        "",
    ]
    for key in awkward:
        name = document_id_for(key)
        assert "/" not in name
        assert name not in {".", ".."}
        assert not (name.startswith("__") and name.endswith("__") and len(name) >= 4)
        assert "\r" not in name
        assert "\n" not in name
        # Lossless: the key is recoverable, so nothing about it was discarded.
        padded = name + "=" * (-len(name) % 4)
        assert base64.urlsafe_b64decode(padded).decode("utf-8") == key

    # Distinct keys never collide on one document.
    assert len({document_id_for(key) for key in awkward}) == len(awkward)
