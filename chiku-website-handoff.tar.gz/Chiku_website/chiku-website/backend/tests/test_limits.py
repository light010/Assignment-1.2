"""The size cap, asserted against the recorded 413 boundary.

Each F6 fixture's metadata carries the body measured three ways -- UTF-16 code units,
codepoints, UTF-8 bytes -- beside the status the source actually returned. The test
asserts the port agrees with the status, and then asserts that the two *wrong* units of
measurement would have disagreed. The second half is the part that matters: a cap in
bytes and a cap in characters both pass a suite that only ever feeds it ASCII.
"""

from __future__ import annotations

import pytest
from conftest import meta, names

from app.content.limits import MAX_BODY_UTF16_UNITS, exceeds_body_limit, utf16_length

SIZE_FIXTURES = names("F6-size-")


@pytest.mark.parametrize("name", SIZE_FIXTURES)
def test_cap_agrees_with_recorded_status(name: str) -> None:
    request = meta(name)["request"]
    status = meta(name)["response"]["status"]
    over = request["bodyUnits_utf16"] > MAX_BODY_UTF16_UNITS
    assert over == (status == 413), (
        f"{name}: {request['bodyUnits_utf16']} UTF-16 units, source answered {status}"
    )


def test_utf16_length_counts_code_units_not_codepoints() -> None:
    assert utf16_length("a") == 1
    assert utf16_length("é") == 1  # BMP: one unit
    assert utf16_length("\U0001f600") == 2  # astral: a surrogate pair
    assert len("\U0001f600") == 1  # ...but one Python codepoint
    assert len("\U0001f600".encode()) == 4  # ...and four UTF-8 bytes


def test_boundary_is_strictly_greater_than() -> None:
    assert not exceeds_body_limit("a" * MAX_BODY_UTF16_UNITS)
    assert exceeds_body_limit("a" * (MAX_BODY_UTF16_UNITS + 1))


def test_a_byte_cap_would_wrongly_reject_a_body_the_source_accepts() -> None:
    """Fixture F6-size-astral-under-in-units: 1.4M units, ~2.8M bytes, source said 200."""
    body = "\U0001f600" * (MAX_BODY_UTF16_UNITS // 2 - 1)
    assert not exceeds_body_limit(body)
    assert len(body.encode()) > MAX_BODY_UTF16_UNITS  # a byte cap rejects it


def test_a_character_cap_would_wrongly_accept_a_body_the_source_rejects() -> None:
    """Fixture F6-size-astral-over-in-units: 1.6M units, ~800k codepoints, source said 413."""
    body = "\U0001f600" * (MAX_BODY_UTF16_UNITS // 2 + 1)
    assert exceeds_body_limit(body)
    assert len(body) < MAX_BODY_UTF16_UNITS  # a character cap accepts it


def test_both_astral_fixtures_were_actually_recorded() -> None:
    """The first recording attempt escaped every emoji to ASCII and proved nothing."""
    assert "F6-size-astral-under-in-units" in SIZE_FIXTURES
    assert "F6-size-astral-over-in-units" in SIZE_FIXTURES
    under = meta("F6-size-astral-under-in-units")
    assert under["response"]["status"] == 200
    assert under["request"]["bodyBytes_utf8"] > under["request"]["bodyUnits_utf16"]
