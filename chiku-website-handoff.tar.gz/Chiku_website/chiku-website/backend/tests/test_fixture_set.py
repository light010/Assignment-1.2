"""The recorded fixture set, asserted as a set.

U1 records; it asserts nothing about the source. Its own tests therefore characterize
the *recording* rather than the system: that every fixture the manifest names is on
disk, that every one carries the provenance which makes it evidence rather than a guess
somebody wrote down, that the manifest agrees with the bytes beside it, and that the
three annotations every downstream unit depends on -- deliberate defect, recorder
caveat, identity -- say what a later reader needs them to say.

Nothing here makes a network call. Re-recording requires the source app to be running
and is a deliberate operator action (see ``chiku-website/fixtures/README.md``); a test
that regenerated its own oracle would pass whatever the source did.

Three facts are pinned here from the recorded bytes because each was stated WRONGLY or
not at all in the design corpus, and a later reader meets the documents before the
fixtures:

* the 1,500,000 request-body cap counts **UTF-16 code units** -- not bytes, not
  codepoints (``test_size_cap_family_settles_the_units_question``);
* the draft-only media key **diverges by identity**, 404 anonymous against 200 owner,
  while a **published** key is served 200 to both -- publication decides access, not
  identity (``test_media_key_cases_record_branches_not_statuses``);
* the four distinct conditions on the upload route's prepared-variant check all return
  **one identical message**, so a port implementing any one of them passes a test
  written against any single fixture (``test_upload_variant_conditions_share_one_reply``).
"""

from __future__ import annotations

import datetime as dt
import hashlib
import json
import pathlib
from typing import Any

import pytest
from conftest import FIXTURES, body, manifest, meta, response_header

MANIFEST = manifest()
ROWS: list[dict[str, Any]] = MANIFEST["fixtures"]
HTTP_ROWS = [row for row in ROWS if row["kind"] == "http"]
DB_ROWS = [row for row in ROWS if row["kind"] == "db"]
ROW_BY_NAME = {row["name"]: row for row in ROWS}

EVERY_FIXTURE = [(row["kind"], row["name"]) for row in ROWS]
HTTP_NAMES = [row["name"] for row in HTTP_ROWS]

# route.ts line 11. The number is the cap; which unit it counts is what F6 settles.
CAP_UTF16_UNITS = 1_500_000

# The draft-only object every media fixture was recorded against.
DRAFT_ONLY_BYTES = 188_618
MEDIA_NOT_FOUND = b"Not found"


def record_for(kind: str, name: str) -> dict[str, Any]:
    """The metadata record for a fixture of either kind."""
    if kind == "http":
        return meta(name)
    data: dict[str, Any] = json.loads((FIXTURES / "db" / f"{name}.json").read_text())
    return data


@pytest.mark.parametrize(("kind", "name"), EVERY_FIXTURE)
def test_every_manifest_fixture_has_its_files_on_disk(kind: str, name: str) -> None:
    """An indexed fixture with no bytes behind it is a claim, not evidence."""
    if kind == "http":
        assert (FIXTURES / "http" / f"{name}.meta.json").is_file()
        assert (FIXTURES / "http" / f"{name}.body").is_file()
    else:
        assert (FIXTURES / "db" / f"{name}.json").is_file()


@pytest.mark.parametrize(("kind", "name"), EVERY_FIXTURE)
def test_every_fixture_carries_provenance(kind: str, name: str) -> None:
    """BR21.2 -- without the commit and the recording time it must not be used as an oracle."""
    provenance = record_for(kind, name)["provenance"]

    commit = provenance["sourceCommit"]
    assert len(commit) == 40, f"{name}: {commit!r} is not a full commit sha"
    assert all(character in "0123456789abcdef" for character in commit)
    assert commit == MANIFEST["provenance"]["sourceCommit"], (
        f"{name}: recorded against a different commit than the rest of the set, "
        "so the fixtures are not mutually comparable"
    )

    recorded_at = provenance["recordedAt"]
    assert recorded_at.endswith("Z"), f"{name}: {recorded_at!r} is not stamped UTC"
    dt.datetime.strptime(recorded_at, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=dt.UTC)


def test_manifest_agrees_with_what_is_on_disk() -> None:
    """The index is the only view any consumer has of the set, so it has to be true."""
    counts = MANIFEST["counts"]
    on_disk_http = sorted(
        p.name.removesuffix(".meta.json") for p in (FIXTURES / "http").glob("*.meta.json")
    )
    on_disk_db = sorted(p.stem for p in (FIXTURES / "db").glob("*.json"))

    assert counts["http"] == len(HTTP_ROWS) == len(on_disk_http)
    assert counts["db"] == len(DB_ROWS) == len(on_disk_db)
    assert counts["total"] == counts["http"] + counts["db"] == len(ROWS)
    assert counts["deliberateDefects"] == sum(1 for row in HTTP_ROWS if row["deliberateDefect"])
    assert counts["recorderCaveats"] == sum(1 for row in HTTP_ROWS if row["recorderCaveat"])

    # Nothing on disk is unindexed. An unindexed fixture is invisible to every consumer
    # that walks the manifest, which is all of them.
    assert on_disk_http == sorted(HTTP_NAMES)
    assert on_disk_db == sorted(row["name"] for row in DB_ROWS)
    assert sorted(p.stem for p in (FIXTURES / "http").glob("*.body")) == sorted(HTTP_NAMES)

    # The recorder is committed. That property is what makes this set reproducible
    # evidence rather than an artifact somebody once made on their own machine.
    recorder = pathlib.Path(FIXTURES).parents[1] / MANIFEST["recorder"]
    assert recorder.is_file(), f"{MANIFEST['recorder']} is not in the repository"


@pytest.mark.parametrize("name", HTTP_NAMES)
def test_recorded_bytes_match_the_manifest_digest(name: str) -> None:
    """BR21.1 -- the bytes are the evidence, so an edited body must fail loudly here."""
    row = ROW_BY_NAME[name]
    raw = body(name)
    assert len(raw) == row["bodyBytes"]
    assert hashlib.sha256(raw).hexdigest() == row["bodySha256"]

    record = meta(name)
    assert record["response"]["bodySha256"] == row["bodySha256"]
    assert record["response"]["status"] == row["status"]
    # BR21.7 -- identity is required on every fixture, not only the media ones.
    assert record["identity"] == row["identity"]
    assert record["identity"] in {"anonymous", "owner"}


def test_deliberate_defects_are_recorded_and_annotated() -> None:
    """BR21.3 -- the three behaviours that look wrong and are preserved on purpose."""
    defects = {row["name"]: row["deliberateDefect"] for row in HTTP_ROWS if row["deliberateDefect"]}
    assert set(defects) == {
        "F8-head-with-range-owner",  # HEAD answers 200 with the full length, ignoring Range
        "F8-if-none-match-owner",  # an ETag is emitted but no 304 is ever returned
        "F11-range-oversized-suffix",  # an oversized suffix gives 206 for the whole object
    }
    for name, annotation in defects.items():
        assert "Preserved, not corrected." in annotation, (
            f"{name}: the annotation must say the preservation is deliberate, or a later "
            "reader will file it as a bug and 'fix' the port away from the source"
        )
        assert len(annotation.split()) >= 8, f"{name}: the annotation must name the behaviour"

    # Each annotation has to agree with what its fixture actually captured. An annotation
    # that describes a different response is worse than none: it reads as corroboration.
    head = meta("F8-head-with-range-owner")
    assert head["request"]["headers"]["Range"] == "bytes=0-99"
    assert head["response"]["status"] == 200
    assert response_header("F8-head-with-range-owner", "content-length") == str(DRAFT_ONLY_BYTES)

    conditional = meta("F8-if-none-match-owner")
    assert conditional["request"]["headers"]["If-None-Match"] == response_header(
        "F8-get-full-owner", "etag"
    )
    assert conditional["response"]["status"] == 200, "a 304 here would contradict the annotation"

    oversized = meta("F11-range-oversized-suffix")
    assert oversized["response"]["status"] == 206
    assert oversized["response"]["bodyBytes"] == DRAFT_ONLY_BYTES  # the WHOLE object, not a slice
    assert response_header("F11-range-oversized-suffix", "content-range") == (
        f"bytes 0-{DRAFT_ONLY_BYTES - 1}/{DRAFT_ONLY_BYTES}"
    )


def test_recorder_caveats_name_the_recording_environment() -> None:
    """A caveat marks a dev-server artifact, so no downstream test asserts it as behaviour."""
    caveats = {row["name"]: row["recorderCaveat"] for row in HTTP_ROWS if row["recorderCaveat"]}
    assert caveats, "the recording environment differed from production; that must be recorded"
    for name, annotation in caveats.items():
        assert "dev server" in annotation or "Framework-level" in annotation, (
            f"{name}: a caveat must attribute the observation to the recording environment, "
            "otherwise it cannot be told apart from source behaviour"
        )

    # The chunked-encoding substitution is SET-WIDE, not confined to the annotated
    # fixtures: every media response that carried a body was recorded without a
    # Content-Length. Asserting it here means the absence of a per-fixture caveat on the
    # others is not read as evidence that they were unaffected.
    served = [
        row["name"]
        for row in HTTP_ROWS
        if row["path"].startswith("/api/media/") and row["method"] == "GET" and row["bodyBytes"]
    ]
    assert len(served) > len(caveats)
    for name in served:
        assert response_header(name, "content-length") is None, (
            f"{name}: a Content-Length survived, so the substitution is not uniform and "
            "the per-fixture caveats no longer cover the set"
        )


def test_media_key_cases_record_branches_not_statuses() -> None:
    """BR21.7 -- the recording count follows distinct source branches, not distinct statuses."""

    def named(prefix: str) -> list[str]:
        return sorted(n for n in HTTP_NAMES if n.startswith(prefix))

    assert named("F7-draftonly-") == ["F7-draftonly-anon", "F7-draftonly-owner"]
    assert named("F7-published-") == ["F7-published-anon", "F7-published-owner"]
    assert named("F9-missing-") == ["F9-missing-anon", "F9-missing-owner"]
    assert named("F10-malformed") == ["F10-malformed-once"]

    # PUBLISHED is the other half of the same rule, and the half that was missing from
    # the first recording: with no asset referenced by the published document, isPublic
    # was false for every key and route.ts line 8's true branch -- the ORDINARY VISITOR's
    # read path -- had no oracle at all. A port could have refused every anonymous media
    # request and passed the whole suite. Both identities are served here, and the
    # anonymous 200 is the assertion that carries that weight.
    published_anon, published_owner = meta("F7-published-anon"), meta("F7-published-owner")
    assert published_anon["identity"] == "anonymous"
    assert published_anon["response"]["status"] == 200
    assert published_anon["response"]["bodyBytes"] == DRAFT_ONLY_BYTES
    assert published_owner["identity"] == "owner"
    assert published_owner["response"]["status"] == 200
    # Same object, same bytes, both ways: publication decides access, identity does not.
    assert body("F7-published-anon") == body("F7-published-owner")
    # And the pair is only meaningful against the draft-only pair, where it diverges.
    assert meta("F7-draftonly-anon")["response"]["status"] == 404

    # DRAFT-ONLY is the hazard, and the corrected fact: the statuses genuinely DIVERGE.
    # A recorder that left the owner cookie on would have captured 200 as the oracle for
    # the private case, and the port matching it would serve non-public assets to anyone.
    anonymous, owner = meta("F7-draftonly-anon"), meta("F7-draftonly-owner")
    assert anonymous["identity"] == "anonymous"
    assert anonymous["response"]["status"] == 404
    assert anonymous["response"]["bodyBytes"] == len(MEDIA_NOT_FOUND)
    assert body("F7-draftonly-anon") == MEDIA_NOT_FOUND  # plain text, not the JSON envelope
    assert owner["identity"] == "owner"
    assert owner["response"]["status"] == 200
    assert owner["response"]["bodyBytes"] == DRAFT_ONLY_BYTES
    # 404 and never 403: the refusal must not disclose that the key exists.
    assert anonymous["response"]["status"] != 403

    # MISSING: the same status under both identities, reached by different branches.
    # That is why it is recorded twice -- branch completeness, not divergent behaviour.
    assert {meta(n)["response"]["status"] for n in named("F9-missing-")} == {404}
    assert meta("F9-missing-anon")["sourceBranch"] != meta("F9-missing-owner")["sourceBranch"]

    # MALFORMED: one branch. The key regex returns before readContent() and before
    # editorAccess(), so a second recording would capture the same code path twice.
    malformed = meta("F10-malformed-once")
    assert malformed["identity"] == "anonymous"
    assert "regex" in malformed["sourceBranch"]
    assert body("F10-malformed-once") == MEDIA_NOT_FOUND


def test_size_cap_family_settles_the_units_question() -> None:
    """BR21.6 -- and the corrected fact: the cap counts UTF-16 code units."""
    size_names = sorted(n for n in HTTP_NAMES if n.startswith("F6-size-"))
    assert size_names == [
        "F6-size-astral-over-in-units",
        "F6-size-astral-under-in-units",
        "F6-size-at-limit",
        "F6-size-over-limit",
    ]
    for name in size_names:
        request = meta(name)["request"]
        for field in ("bodyUnits_utf16", "bodyChars_codepoints", "bodyBytes_utf8"):
            assert request[field] > 0, f"{name}: {field} is missing; BR21.6 needs all three"

    # The ASCII pair pins WHERE the boundary is: 1,500,000 passes, 1,500,001 does not.
    at_limit, over_limit = meta("F6-size-at-limit"), meta("F6-size-over-limit")
    assert at_limit["request"]["bodyUnits_utf16"] == CAP_UTF16_UNITS
    assert at_limit["response"]["status"] == 200
    assert over_limit["request"]["bodyUnits_utf16"] == CAP_UTF16_UNITS + 1
    assert over_limit["response"]["status"] == 413

    # The astral pair pins WHICH UNIT is counted, and it takes both to do it. With only
    # ASCII bodies all three measurements are equal and the question cannot be asked.
    under, over = (
        meta("F6-size-astral-under-in-units"),
        meta("F6-size-astral-over-in-units"),
    )
    # Accepted at ~1.4M UTF-16 units although it is ~2.8M UTF-8 bytes: a BYTE cap would
    # have rejected this body, and the source did not.
    assert under["response"]["status"] == 200
    assert (
        under["request"]["bodyUnits_utf16"] <= CAP_UTF16_UNITS < under["request"]["bodyBytes_utf8"]
    )
    # Rejected at ~1.6M units from only ~800k codepoints: a CHARACTER cap would have
    # accepted this body, and the source did not. Only UTF-16 code units survive both.
    assert over["response"]["status"] == 413
    assert (
        over["request"]["bodyChars_codepoints"]
        < CAP_UTF16_UNITS
        < over["request"]["bodyUnits_utf16"]
    )


# --------------------------------------------------------------------------- #
# The upload family (F13)
#
# Recorded as F13 rather than the functional spec's F11 because F11 was already taken
# on disk by the byte-range family; chiku-website/fixtures/README.md carries the full
# spec-to-disk mapping. Every hazard-register validator in the upload path -- the three
# hand-written image header parsers, the WebVTT validator and the five-byte %PDF- check
# -- has its oracle here and nowhere else.
# --------------------------------------------------------------------------- #

# route.ts `types`: the seven MIME types the upload route accepts.
ACCEPTED_UPLOAD_KINDS = ["jpeg", "mp4", "pdf", "png", "vtt", "webm", "webp"]

# One per hand-written parser in app/upload-validation.ts, plus the two inline checks
# in route.ts line 43 (the mp4 `ftyp` probe and the five-byte %PDF- probe).
HEADER_PARSER_REJECTS = [
    "F13-upload-jpeg-bad-header",
    "F13-upload-mp4-bad-header",
    "F13-upload-pdf-bad-header",
    "F13-upload-png-bad-header",
    "F13-upload-webm-bad-header",
    "F13-upload-webp-bad-header",
]

# app/upload-validation.ts validCaptions(), branch by branch.
VTT_REJECTS = [
    "F13-upload-vtt-backwards-cue",
    "F13-upload-vtt-markup",
    "F13-upload-vtt-no-cues",
    "F13-upload-vtt-no-magic",
    "F13-upload-vtt-not-utf8",
]

# route.ts line 28: four conditions, ONE message. Three are expressible over the wire.
SHARED_VARIANT_MESSAGE_FIXTURES = [
    "F13-upload-optimized-not-webp",
    "F13-upload-three-variants",
    "F13-upload-variants-without-optimized",
]


def test_upload_family_records_every_accepted_type() -> None:
    """FR6 evidence: one success per MIME type in route.ts `types`, none missing.

    Before this family existed, functional-design/traceability.json marked FR6 ``OK``
    against upload fixtures that were never recorded. An accepted type absent here is a
    validator with no oracle, so the list is asserted whole rather than sampled.
    """
    recorded = sorted(
        name.removeprefix("F13-upload-")
        for name in HTTP_NAMES
        if name.startswith("F13-upload-") and meta(name)["response"]["status"] == 200
    )
    assert recorded == ACCEPTED_UPLOAD_KINDS

    for kind in ACCEPTED_UPLOAD_KINDS:
        record = meta(f"F13-upload-{kind}")
        assert record["request"]["method"] == "POST"
        assert record["request"]["path"] == "/api/upload"
        assert record["identity"] == "owner"
        payload = json.loads(body(f"F13-upload-{kind}"))
        # The response contract the editor reads back: a media URL, the original
        # filename, and the prepared-size list (empty unless optimized=true).
        assert set(payload) == {"url", "filename", "sources"}
        assert payload["url"].startswith("/api/media/")
        assert payload["sources"] == []


def test_upload_rejects_cover_every_validator() -> None:
    """Each hand-written parser and each validCaptions() branch refuses, and says so."""
    for name in HEADER_PARSER_REJECTS:
        record = meta(name)
        assert record["response"]["status"] == 400, name
        # One shared message for a header that could not be verified -- the port must
        # not invent a per-format sentence here.
        assert json.loads(body(name)) == {
            "error": "The file format could not be verified. Please choose another file."
        }, name

    for name in VTT_REJECTS:
        record = meta(name)
        assert record["response"]["status"] == 400, name
        assert json.loads(body(name)) == {
            "error": (
                "Choose a UTF-8 .vtt file beginning with WEBVTT and containing valid "
                "timed captions."
            )
        }, name
        # A caption rejection must not be reported with the generic format message:
        # the editor shows this sentence to the owner verbatim.
        assert "WEBVTT" in json.loads(body(name))["error"], name

    # The empty / missing file branch, which precedes every type check.
    for name in ("F13-upload-no-file", "F13-upload-empty-file"):
        assert meta(name)["response"]["status"] == 400, name
        assert json.loads(body(name)) == {"error": "Choose a non-empty file."}, name

    # An unsupported MIME type names the accepted list rather than failing generically.
    unsupported = json.loads(body("F13-upload-unsupported-type"))
    assert meta("F13-upload-unsupported-type")["response"]["status"] == 400
    assert unsupported == {
        "error": "Please upload a JPG, PNG, WebP, PDF, MP4, WebM, or WebVTT caption file."
    }


def test_upload_refuses_before_it_reads_anything() -> None:
    """Authorization precedes parsing: no identity, no body inspection, one envelope."""
    for name in ("F13-upload-anon", "F13-upload-no-origin"):
        record = meta(name)
        assert record["response"]["status"] == 403, name
        # route.ts line 16 folds sameOrigin() and editorAccess() into ONE check, so both
        # the anonymous and the missing-Origin case return the same sentence. That is
        # source behaviour, not an oversight in the recording.
        assert json.loads(body(name)) == {
            "error": "Please sign in with the website owner\u2019s account."
        }, name

    # Cross-origin never reaches the route (FIX-3): the framework refuses first, so the
    # fixture carries a caveat and its body is NOT the route's envelope.
    cross = meta("F13-upload-cross-origin")
    assert cross["recorderCaveat"], "the framework-level rejection must stay flagged"
    assert body("F13-upload-cross-origin") == b"Forbidden"


def test_upload_variant_conditions_share_one_reply() -> None:
    """FIX-6 -- three distinct causes, one byte-identical response.

    route.ts line 28 is a single ``if`` with four OR'd conditions and one message. A
    port that implements only one of them passes any test written against a single one
    of these fixtures, which is exactly why all three are asserted together and by
    identity rather than by status.
    """
    bodies = {name: body(name) for name in SHARED_VARIANT_MESSAGE_FIXTURES}
    assert len(set(bodies.values())) == 1, bodies
    for name in SHARED_VARIANT_MESSAGE_FIXTURES:
        assert meta(name)["response"]["status"] == 400, name
        assert json.loads(bodies[name]) == {
            "error": (
                "The prepared image sizes could not be verified. Please choose the photo again."
            )
        }, name
        # Each reaches that one message through a different condition; the branch note
        # is the only place the distinction survives.
        assert meta(name)["sourceBranch"], name
    assert len({meta(name)["sourceBranch"] for name in SHARED_VARIANT_MESSAGE_FIXTURES}) == 3

    # The three later variant rules DO have messages of their own, and each is distinct.
    distinct = {
        "F13-upload-variant-not-webp": "Prepared photo sizes must use WebP.",
        "F13-upload-optimized-too-large": (
            "Prepared photo sizes must be no larger than 1600 pixels."
        ),
        "F13-upload-variant-larger-than-original": (
            "Prepared photo sizes must match the original framing."
        ),
    }
    for name, message in distinct.items():
        assert meta(name)["response"]["status"] == 400, name
        assert json.loads(body(name)) == {"error": message}, name


def test_upload_size_limit_is_recorded_as_unreachable_through_the_dev_server() -> None:
    """FIX-5 -- the status is source-accurate, the body is a dev-server artifact.

    The per-type limits at route.ts line 31 never run for this request: the framework
    rejects the body first. Recording it anyway, with the caveat attached, is what stops
    a later reader porting ``Payload Too Large`` as though it were product copy.
    """
    record = meta("F13-upload-vtt-over-limit")
    assert record["response"]["status"] == 413
    assert body("F13-upload-vtt-over-limit") == b"Payload Too Large"
    caveat = record["recorderCaveat"]
    assert caveat, "an unreachable branch recorded without its caveat is a trap"
    assert "dev-server artifact" in caveat
    # The sentence the route WOULD have produced is named in the caveat, so the porter
    # has it without going back to the source.
    assert "Choose files totaling less than" in caveat
