# Units

The functional-design stage produced 12 units. That decomposition was too fine for a
2,310-line app and is collapsed here into three chunks plus one finished item and two
deferrals. The 12-unit artifacts stay on disk under `aidlc/.../construction/` as
reference; nothing is deleted.

| Chunk | Absorbs | Delivers |
|---|---|---|
| **A — backend** | storage-ports, identity-and-session, content-core, media, http-api | `backend/` — FastAPI, the ContentStore/AssetStore/IdentityStore ports, SQLite adapter, sessions, the four routes |
| **B — frontend** | api-client, public-site, owner-editor | `frontend/` — the ported Next.js render layer and the generated API client |
| **C — containers** | containers | two Dockerfiles, `compose.yaml`, `.env.example`, the end-to-end flow |

**Done:** `source-fixtures` — **91 fixtures** recorded in `fixtures/` (85 HTTP, 6
stored-state). This was the only deliverable with an expiry (it needed the source app
running) and it is closed.

The first pass recorded 57 and reported two expiring gaps it could not close: the
published-key media pair, and the entire upload family. Both were closed on 2026-09-25
by uploading and publishing an asset through the app's own routes and re-recording in
full. What that bought: the `isPublic == true` branch of the media route — **the ordinary
visitor's read path** — now has an oracle, and the three hand-written image header
parsers, the WebVTT validator and the 5-byte `%PDF-` check each have one too. See
`fixtures/README.md` § *Known gaps* for what remains unrecordable over HTTP (upload
cancellation and its cleanup path).

**Deferred, not dropped:** `cloud-adapters` and `deployment-plan`. Both describe a
Google Cloud deployment that `project.md` forbids provisioning in this piece of work.
They are reopened if and when a deployment is authorised. `cloud-adapters` ended its
review NOT-READY on a real Firestore transaction-ordering finding (all reads must
precede any write in a transaction); that finding is preserved in its review receipt
and must be answered before any Firestore adapter is written.

## Open findings carried into the build

Four units ended functional-design at **terminal NOT-READY** with the review budget
exhausted: `storage-ports`, `content-core`, `owner-editor`, `cloud-adapters`. Three are
document-internal — a derived summary table contradicting its own YAML block, a prose
sentence contradicting the array beside it, and the Firestore finding above.

`owner-editor` is the exception: its 3 Critical and 9 Major findings describe real
behaviour of the editor state machine. They are extracted to `CARRIED-FINDINGS.json`
and owned by chunk B. The one most likely to be lost silently is **R-11** — the source's
`manualSave` runs a client-side pre-flight parse that blocks the save *before dispatch*
and raises `Check these fields before saving. Your edits are kept in this browser.`
Replacing it with the backend's `issues[]` response drops that sentence, and under the
parity rule a user-facing error string is product copy.

## What the recorded fixtures changed

Two things the design corpus asserted are now known to be wrong, measured against the
running source:

1. **The 1,500,000 request-body cap counts UTF-16 code units** — not characters and not
   UTF-8 bytes. `route.ts:11` tests `bodyText.length`, and JavaScript string length is
   UTF-16 code units. Proven by `F6-size-astral-under-in-units` (1.4M units / ~700k
   codepoints / ~2.8M UTF-8 bytes → **200**) and `F6-size-astral-over-in-units` (1.6M
   units from ~800k codepoints → **413**). A byte cap rejects the first; a character cap
   accepts the second. The port is `len(text.encode("utf-16-le")) // 2`.
2. **The media route diverges by publication, not identity.** `F7-draftonly-anon` → 404
   against `F7-draftonly-owner` → 200, while `F7-published-anon` and `F7-published-owner`
   are both 200 with byte-identical bodies. A port that refused every anonymous media
   request would have passed the first recording's whole suite.
3. **Four upload-route branches share one message.** The four conditions on `route.ts`
   line 28 all return *"The prepared image sizes could not be verified."* — so a port
   implementing one of them passes any test written against a single fixture. Recorded as
   `FIX-6` in `fixtures/MANIFEST.json`.
4. **The fixture recording preconditions were unstated and self-contradictory.** BR21.4
   mandates a disposable database; BR21.7 requires owner-identity recordings. On a fresh
   database `isEditor()` returns false for the local mock identity (`seedy@sites.test`
   is not `OWNER_EMAIL`), so every owner fixture would have recorded 404 — the inverse
   of the intended oracle. `fixtures/MANIFEST.json` records the required precondition.
