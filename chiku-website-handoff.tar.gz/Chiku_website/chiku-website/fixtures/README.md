# Recorded source-behaviour fixtures

These **91 fixtures** — 85 HTTP recordings and 6 stored-state snapshots — are the
**oracle** for the `madhavi-tripathi/` → `chiku-website/` migration. Every one was
captured over HTTP from the running source application by [`record.py`](record.py)
beside this file. Five other units test against them.

They exist because the alternative is worse. Without them, every parity claim in this
project rests on a human's reading of a dense source file; with them, it rests on what
the system actually did.

> ## This capability expires
>
> Once `madhavi-tripathi/` is retired these responses **cannot be recorded again**. A
> question this recording does not answer can never be asked. The known gaps at the
> bottom of this file are therefore permanent unless they are closed while the source
> app still boots.

## Layout

```
fixtures/
  MANIFEST.json          index, provenance, counts, and the six corrective findings
  record.py              the recorder that produced everything here
  http/<name>.meta.json  request, response status, full response headers, provenance
  http/<name>.body       the response body, raw and unnormalised
  db/<name>.json         stored-row state: site_content, content_revisions, assets
```

Bodies are stored **raw, byte for byte, in wire order** (BR21.1). Nothing is normalised
at record time: stripping volatile attributes, build hashes or whitespace bakes today's
idea of "irrelevant" into permanent evidence. Normalisation belongs at compare time, in
the consuming test.

Every record carries `provenance.sourceCommit` and `provenance.recordedAt` (BR21.2). A
fixture without both is not evidence and must not be used as an oracle.

Bodies are never inlined into the metadata: a content document is ~15 KB and the
size-boundary fixtures are ~1.5 M characters. The `db/` snapshots digest the two content
columns for the same reason — the point of a snapshot is revision and timestamp
movement, not the text.

## Re-recording

Re-recording is a **deliberate operator action**, never part of a test run. It needs the
source app running and it **overwrites this directory**. A test that regenerated its own
oracle would pass whatever the source did.

### 1. Boot the source app

From `madhavi-tripathi/`:

```
node scripts/run-framework.mjs dev
```

Not `pnpm dev`, and not `pnpm start`.

- `pnpm dev` does not work here: `package.json` pins `packageManager: pnpm@11.25.0`
  while the host has 10.30.3, so corepack wants to fetch 11.25.0 and pnpm then wants to
  purge `node_modules` (`ERR_PNPM_ABORTED_REMOVE_MODULES_DIR_NO_TTY`). The installed
  tree is complete and `madhavi-tripathi/` is the rollback baseline, so the install step
  is skipped and the framework script is invoked directly.
- `pnpm start` is worse than useless: it runs wrangler against `dist/`, where the
  mock-auth vite plugin (`configureServer`) never runs, so **no owner identity is
  obtainable at all** and every owner fixture would record the anonymous branch.

  > `MANIFEST.json → preconditions.server` still names this step `pnpm dev`. That string
  > was written before the invocation was corrected by execution; the command above is
  > the one that works. A re-record rewrites the manifest with the corrected text.

The server listens on `http://localhost:5173`.

### 2. Run the recorder

From `chiku-website/backend/` (which is where `httpx` is resolvable):

```
uv run python ../fixtures/record.py --check-only    # preconditions only, writes nothing
uv run python ../fixtures/record.py                 # the real recording
```

`--check-only` is safe to run at any time. The full run **writes to the source app's
local database**: the F4/F5/F6/F12 fixtures drive the real save and publish path, so
they move `site_content.revision` and append revision rows. `.wrangler/state` is copied
to a disposable backup in the system temp directory before the first write, and the run
aborts if that copy cannot be taken.

### 3. The three preconditions, and why they are enforced in code

Each one fails **silently** and produces a plausible-looking fixture set that is the
inverse of the truth. So `record.py` checks all three before recording anything, and
refuses rather than warns.

| # | Precondition | What goes wrong without it |
|---|---|---|
| 1 | The base URL host is literally `localhost` | The dev server binds `[::1]:5173` only. `127.0.0.1` is refused, and the connection error reads like "the server is not running". A non-loopback host would also violate BR21.4 |
| 2 | The `editors` table holds the local mock identity | `isEditor()` grants access on an existing `editors` row **or** an email equal to `OWNER_EMAIL`. The injected identity is `seedy@sites.test`, which is **not** the owner email — so against an empty database the owner cookie yields `editorAccess() == false` and **every owner fixture records 404**, the exact inverse of the draft-only oracle |
| 3 | One asset is in the database and absent from the published document | If that asset is ever published, the draft-only fixture silently becomes a second copy of the public case and the 404-not-403 behaviour goes unrecorded |

Precondition 2 is also checked *behaviourally*: `GET /api/content` with the owner cookie
must answer 200. The row check names the cause; the request names the effect. To satisfy
it on a fresh database:

```sql
INSERT INTO editors (user_id, email) VALUES ('local_seedy', 'seedy@sites.test');
```

The owner identity itself is the cookie `__sites_local_auth=1`. The vendored
`build/sites-vite-plugin.ts` injects `oai-authenticated-user-*` headers behind it and
**strips every client-supplied `oai-authenticated-user-*` header first** — the trust
boundary is the middleware, not the header, so sending those headers directly still
returns 403.

### 4. If a precondition cannot be met

`record.py` prints `BLOCKED:`, names the reason, writes nothing, and exits 2.

That is the required behaviour, not a convenience (BR21.5). **Blocked is reported;
it is never reported as skipped**, because a missing fixture set and a skipped one look
identical on disk while meaning opposite things: if the source cannot be booted, every
dependent unit's parity claim weakens to "checked against the written knowledge base"
and must say so in writing.

## Nothing hosted is touched

The recording runs against `http://localhost:5173` and the local miniflare SQLite file
under `madhavi-tripathi/.wrangler/state/`. No hosted database, no hosted object store,
no published content, no credential belonging to the live site (BR21.4). The identity is
a local mock injected by a dev-only vite plugin.

## Deliberate defects — do not "fix" these

Three recorded responses look wrong and are preserved on purpose (BR21.3). A recorder
that corrected a response while capturing it would produce an oracle that disagrees with
the system it came from, and the port matching that oracle would fail against reality.

| Fixture | Preserved behaviour |
|---|---|
| `F8-head-with-range-owner` | `HEAD` answers 200 with the **full** `Content-Length` and ignores `Range` |
| `F8-if-none-match-owner` | An `ETag` is emitted but **no 304 is ever returned**, even on an exact match |
| `F11-range-oversized-suffix` | An oversized suffix range answers **206 for the whole object** rather than 416 |

A fourth, the size cap counting UTF-16 code units, is recorded by the `F6` family rather
than flagged on a single fixture.

## Recorder caveats — do not assert on these

Nine fixtures carry a `recorderCaveat`: something the **recording environment** did,
not something the source decides. Three distinct artifacts:

- **Chunked transfer encoding.** The dev server replaces the route's explicit
  `Content-Length` (route.ts line 11) with `transfer-encoding: chunked`.
- **Framework-level cross-origin rejection.** `F5-put-cross-origin` and
  `F13-upload-cross-origin` are refused by the dev server with plain-text `Forbidden`
  **before the route runs**, so `sameOrigin()` at route.ts line 9 is not reachable that
  way. The reachable branch is a **missing** `Origin` header — `F5-put-no-origin` and
  `F13-upload-no-origin` — which does return the route's own JSON 403 envelope. Port
  `sameOrigin()` against those.
- **Framework-level request-body rejection (FIX-5).** `F13-upload-vtt-over-limit`
  returns plain-text `Payload Too Large`, not the upload route's own envelope. The
  framework refuses the ~1 MB body before route.ts line 31 runs, so the **status is
  source-accurate but the body is not**. The sentence the route would have produced is
  `{"error": "Choose files totaling less than 1 MB."}`. Port the per-type limit table
  (50 MB video / 10 MB image and PDF / 1 MB captions) and the 51 MB `content-length`
  pre-check from route.ts lines 18 and 31 by reading the source, not this body.

> **The chunked substitution is set-wide, not confined to the annotated fixtures.**
> Every media `GET` that carried a body was recorded without a `Content-Length` — 16
> fixtures, of which only 4 carry the caveat. The absence of a per-fixture caveat on the
> other 12 is **not** evidence that they were unaffected.
> `test_recorder_caveats_name_the_recording_environment` asserts the set-wide property
> so this cannot be missed.

## Traceability

The unit realises **NFR10** (parity evidence) and nothing else; it owns no functional
requirement. Every other requirement below is one this set carries **evidence** for,
realised by another unit. `functional-design/traceability.json` is the source of truth
and lists all seven `BR21.x` rules under `reverse` against NFR10.

| Family | On disk | What it pins | Rules | Evidence for |
|---|---|---|---|---|
| `F1` | 3 | Rendered HTML of `/`, `/robots.txt`, `/sitemap.xml` — the DOM-diff baseline | BR21.1, BR21.2 | FR1 (realised by U8) |
| `F2` | 3 | `/edit` and `/edit/preview` per identity, including the anonymous redirect | BR21.2, BR21.7 | FR8 (U9) |
| `F3` | 4 | `GET /api/content` and `/api/history` per identity; the 403 envelope, and the serialised shape where the content-carrying defaults are visible | BR21.1, BR21.2 | FR4, FR5, FR9.2 `[hazard]` (U4) |
| `F4` | 2 | Live state read, then a draft save on a matching revision | BR21.2 | FR4 (U4) |
| `F5` | 5 | Publish, the **409 conflict envelope** the editor branches on, and the authorization / CSRF refusals | BR21.1, BR21.3 | FR4 (U4) |
| `F6` | 4 | The 1,500,000 cap, measured in UTF-16 units **and** codepoints **and** UTF-8 bytes | **BR21.6**, BR21.3 | FR4.5 `[hazard]` (U4) |
| `F7` | 4 | Media keys under **both** identities: draft-only, where the statuses **diverge** 404/200, and published, where both get 200 — publication decides access, identity does not | **BR21.7** | FR7.2 `[hazard]` (U5) |
| `F8` | 4 | `HEAD`, the full `GET`, and the conditional-get that never 304s | BR21.3 | FR7 (U5) |
| `F9` | 2 | Missing key under both identities — same status, different branch | **BR21.7** | FR7 (U5) |
| `F10` | 1 | Malformed key, recorded **once**: one branch, reached before either identity check | **BR21.7** | FR7 (U5) |
| `F11` | 16 | Every `parseByteRange` outcome plus both `If-Range` paths | BR21.1, BR21.3 | FR7.4 `[hazard]` (U5) |
| `F12` | 6 | Malformed write bodies — the `400` + `issues[]` shape field highlighting depends on | BR21.1 | FR4 (U4) |
| `F13` | 31 | `POST /api/upload`: one success per accepted MIME type, then every reject branch — the three hand-written image header parsers, the WebVTT validator, the 5-byte `%PDF-` probe, the `ftyp`/EBML probes, authorization, and the prepared-variant rules | BR21.1, BR21.3 | FR6 (U5) |
| `S0`–`S5` | 6 | Stored-row state before/after each write and after the uploads: revision, both timestamps, revision ordering, retention, asset rows | BR21.2, **BR21.4** | FR4, FR5, FR6 (U4, U5) |

Recording counts follow the number of **distinct source branches**, not the number of
distinct statuses. `F9` is recorded twice although both identities get 404, because
anonymous is refused at the line-8 auth block and the owner at the line-9 asset-row miss.
`F10` is recorded once because the line-6 key regex returns before `readContent()` and
`editorAccess()` are ever called. Do not read "recorded twice" as "the behaviour differs"
— only `F7` carries that meaning.

### Fixture prefixes do not match the functional spec's manifest rows

From `F7` onward the on-disk prefixes and `functional-spec.md`'s `F1`–`F12` recording
manifest **number the same things differently**. Join the two documents by what a
fixture records, never by its prefix:

`traceability.json`'s `coverage[].target` strings cite the **spec's** row numbers, not
these prefixes: its "F11 (upload responses…)" against FR6 means the spec's F11, which is
recorded here as **`F13-upload-*`** because `F11` was already taken by the byte-range
family.

| On disk | `functional-spec.md` row |
|---|---|
| `F7-draftonly-*`, `F7-published-*` | F7 (media key cases) |
| `F8-head-*` | F8 (HEAD with Range) |
| `F8-if-none-match-owner` | F10 (conditional get, no 304) |
| `F9-missing-*` | F7 (media key cases) |
| `F10-malformed-once` | F7 (media key cases) |
| `F11-range-*`, `F11-ifrange-*` | F9 (range branches) |
| `F12-*` | *(no row — malformed write bodies)* |
| `F13-upload-*` | **F11 (upload responses per accepted type, plus rejects)** |

## Known gaps

These are recorded here rather than left to be discovered, because the capability to
close them expires with the source app.

> **Two gaps that were here have been closed**, and it is worth saying how, because both
> were of the kind that expires. The first recording had no published media key and no
> upload recordings at all. Closing them took an upload and a publish through the app's
> own routes — not a database edit — followed by a full re-record. The published pair is
> now `F7-published-anon` / `F7-published-owner` and the upload family is `F13-upload-*`.

1. **Upload cancellation cannot be recorded over HTTP.** The upload route carries two
   distinct cancellation literals — `Upload cancelled.` (the internal `DOMException`)
   and `Upload cancelled. Your previous file is unchanged.` (the 499 the client sees) —
   reached only by aborting the request mid-flight, which also triggers the best-effort
   cleanup of partially written keys. An HTTP recorder cannot produce that race
   deterministically, so **the 499 branch and the cleanup path have no fixture**. Port
   them by reading route.ts's `checkCancelled()` call sites; there are six, and a port
   that places fewer loses cleanup coverage for the keys written after the one it kept.
2. **The 51 MB `content-length` pre-check is unrecorded**, and the 1 MB caption limit is
   recorded only as a framework rejection (FIX-5 above). Both live on route.ts lines 18
   and 31. A 51 MB request was judged not worth a fixture; the limit table must be
   ported by reading the source.
3. **One of the four prepared-variant conditions is not expressible over the wire.**
   route.ts line 28 rejects an **empty or non-`File` variant**, which a multipart body
   cannot carry as a distinct case. The other three are recorded, and FIX-6 records that
   all four share **one identical message** — so a port implementing only one condition
   passes any test written against a single fixture. `test_upload_variant_conditions_share_one_reply`
   asserts all three together for exactly that reason.
4. **The recording mutates the local dev database, by design.** The write-path fixtures
   move the revision and the upload fixtures insert asset rows; the `S0`–`S5` snapshots
   exist to record that movement. `record.py` copies `.wrangler/state` to a temporary
   backup before the first write and prints the path. Nothing hosted is touched.

## Reading these from a test

`chiku-website/backend/tests/conftest.py` holds the accessors — `manifest()`,
`meta(name)`, `body(name)`, `names(prefix)`, `response_header(name, header)`. The
fixture set's own integrity is asserted by `tests/test_fixture_set.py`:

```
cd chiku-website/backend && uv run pytest tests/test_fixture_set.py -q
```
