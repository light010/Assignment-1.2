#!/usr/bin/env python3
"""Record the golden source-behaviour fixtures from the running ``madhavi-tripathi`` app.

This is the recorder that produced every file under ``chiku-website/fixtures/``. It is
committed so the fixture set is reproducible evidence rather than an artifact somebody
once made on their own machine. See ``README.md`` beside this file for the procedure.

The rules it implements, from
``construction/source-fixtures/functional-design/rules.md``:

BR21.1  Bodies and headers are stored RAW, byte for byte, in wire order. Normalisation
        belongs in the consuming test, at compare time, never here.
BR21.2  Every fixture carries ``sourceCommit`` and ``recordedAt``. Without both it is
        not evidence and must not be used as an oracle.
BR21.3  Deliberate source defects are recorded as they are and annotated. Never
        corrected: an oracle that disagrees with the system it came from is worse than
        no oracle.
BR21.4  The run touches the local dev server and the local miniflare database only.
        Nothing hosted, no published content, no credential belonging to the live site.
BR21.5  A precondition that cannot be met is reported BLOCKED and nothing is written.
        Never skipped, never partially recorded.
BR21.6  The size-cap fixtures record the request body in UTF-16 code units, codepoints
        and UTF-8 bytes -- all three, because any one alone cannot settle which unit the
        cap counts.
BR21.7  Every fixture records the identity it was made under. The media matrix depends
        on it: a draft-only asset answers 404 to anonymous and 200 to the owner.

THIS RUN WRITES TO THE SOURCE APP'S LOCAL DATABASE. The F4/F5/F6/F12 fixtures drive the
real write path, so they move ``site_content.revision`` and append revision rows. The
state directory is copied to a disposable backup before the first write and the run
aborts if that copy cannot be taken.

THE CAPABILITY EXPIRES. Once ``madhavi-tripathi/`` is retired these responses cannot be
recorded again. A question this recorder does not ask today can never be asked.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import pathlib
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import urllib.parse
from typing import Any

import httpx

REPO_ROOT = pathlib.Path(__file__).resolve().parents[2]
DEFAULT_SRC = REPO_ROOT / "madhavi-tripathi"
DEFAULT_OUT = pathlib.Path(__file__).resolve().parent
DEFAULT_BASE = "http://localhost:5173"

RECORDER_PATH = "chiku-website/fixtures/record.py"

# The mock identity the vendored sites-vite-plugin injects behind __sites_local_auth=1.
MOCK_USER_ID = "local_seedy"
MOCK_EMAIL = "seedy@sites.test"
# The remedy printed when the row is missing. A plain literal, not an interpolated
# query: it is copy-paste text for an operator, and this recorder never executes it.
EDITORS_ROW_SQL = "INSERT INTO editors (user_id, email) VALUES ('local_seedy', 'seedy@sites.test');"

ANON: dict[str, str] = {}
OWNER = {"Cookie": "__sites_local_auth=1"}

# A well-formed key with no asset row, and a key that fails the route's line-6 regex
# /^[a-f0-9-]+\.(jpg|png|webp|pdf|mp4|webm|vtt)$/ -- ".exe" is not an allowed extension.
MISSING_KEY = "00000000-0000-4000-8000-000000000000.webp"
MALFORMED_SUFFIX = ".exe"

CHUNKED_CAVEAT = (
    "The dev server replaces the route's explicit Content-Length (route.ts line 11) with "
    "`transfer-encoding: chunked`. Absence of Content-Length here is a DEV-SERVER artifact, "
    "not source behaviour. Do not assert on it."
)
CROSS_ORIGIN_CAVEAT = (
    "Framework-level rejection; production Cloudflare may differ. Verify before porting "
    "this status/body pair."
)
BODY_LIMIT_CAVEAT = (
    "The dev server rejects the request body before the route runs, returning plain-text "
    "'Payload Too Large' rather than the route's own JSON envelope from route.ts line 31 "
    "({'error': 'Choose files totaling less than N MB.'}). The STATUS is source-accurate; "
    "the BODY is a dev-server artifact. Port the per-type size limits against route.ts, "
    "not against this body, and re-verify on production Cloudflare."
)

# --------------------------------------------------------------------------- #
# Upload probe files
#
# Every byte below is constructed here rather than read from a sample file, because the
# point of the upload fixtures is the HEADER each validator inspects. A binary blob on
# disk hides which byte decides the branch; these show it. None is a decodable image --
# app/api/upload/route.ts never decodes pixel data, it reads the header and stores the
# bytes, so a header-valid file exercises exactly the branch under test.
#
# The parsers are in app/upload-validation.ts; line references are to that file.
# --------------------------------------------------------------------------- #


def _png(width: int, height: int) -> bytes:
    """8-byte signature + a 13-byte IHDR. `imageDimensions` line 9 needs >= 33 bytes."""
    header = b"\x89PNG\r\n\x1a\n"
    ihdr = (
        (13).to_bytes(4, "big")
        + b"IHDR"
        + width.to_bytes(4, "big")  # read at offset 16
        + height.to_bytes(4, "big")  # read at offset 20
        + bytes([8, 6, 0, 0, 0])  # depth, colour type, compression, filter, interlace
    )
    return header + ihdr + b"\x00\x00\x00\x00"  # a zeroed CRC; nothing checks it


def _jpeg(width: int, height: int) -> bytes:
    """SOI + SOF0. Line 37 reads height at offset 7 and width at offset 9."""
    return (
        b"\xff\xd8"  # SOI
        + b"\xff\xc0"  # SOF0 -- in the marker list on line 35
        + (17).to_bytes(2, "big")  # segment length; line 34 needs 4 + 17 <= len
        + bytes([8])  # sample precision
        + height.to_bytes(2, "big")
        + width.to_bytes(2, "big")
        + bytes([3])  # component count
        + bytes(9)  # three 3-byte component descriptors
    )


def _webp(width: int, height: int) -> bytes:
    """RIFF/WEBP/VP8L. Lines 17-19 read two 14-bit fields out of five packed bytes.

    The two fields are not byte-aligned and they overlap in one byte, which is the whole
    reason this is written out rather than borrowed from a sample file. Reading lines
    18-19 backwards, with ``w = width - 1`` and ``h = height - 1``::

        byte 21       = w bits 0-7
        byte 22 bits 0-5 = w bits 8-13      byte 22 bits 6-7 = h bits 0-1
        byte 23       = h bits 2-9
        byte 24 bits 0-3 = h bits 10-13

    An earlier version of this function packed ``h`` starting at byte 23 and spilled the
    remainder into bytes 24-25. It produced files the parser accepted, with the wrong
    height: ``_webp(128, 96)`` decoded as 128x7937, which silently sent three variant
    fixtures into the >1600-pixel branch instead of the branches they were written for.
    """
    w, h = width - 1, height - 1
    packed = bytearray(5)
    packed[0] = 0x2F  # the VP8L signature byte line 17 requires
    packed[1] = w & 0xFF
    packed[2] = ((w >> 8) & 0x3F) | ((h & 0x03) << 6)
    packed[3] = (h >> 2) & 0xFF
    packed[4] = (h >> 10) & 0x0F
    body = bytes(packed) + bytes(11)
    chunk = b"VP8L" + len(body).to_bytes(4, "little") + body
    # Line 12 requires >= 30 bytes and getUint32(4, true) + 8 <= len.
    return b"RIFF" + (len(chunk) + 4).to_bytes(4, "little") + b"WEBP" + chunk


VALID_VTT = b"WEBVTT\n\n00:00:00.000 --> 00:00:02.500\nA recorded caption line.\n"

# Header-valid probes, one per accepted MIME type in route.ts `types`.
UPLOAD_VALID: dict[str, tuple[str, str, bytes]] = {
    "png": ("probe.png", "image/png", _png(64, 48)),
    "jpeg": ("probe.jpg", "image/jpeg", _jpeg(64, 48)),
    "webp": ("probe.webp", "image/webp", _webp(64, 48)),
    # Only the first 32 bytes are read for these three (route.ts: `entry.slice(0, 32)`).
    "pdf": ("probe.pdf", "application/pdf", b"%PDF-1.7\n%\xe2\xe3\xcf\xd3\n" + bytes(16)),
    "mp4": ("probe.mp4", "video/mp4", bytes(4) + b"ftypisom" + bytes(20)),
    "webm": ("probe.webm", "video/webm", b"\x1a\x45\xdf\xa3" + bytes(28)),
    "vtt": ("probe.vtt", "text/vtt", VALID_VTT),
}


def multipart(
    fields: list[tuple[str, str]],
    files: list[tuple[str, str, str, bytes]],
    boundary: str = "----aidlcFixtureBoundary",
) -> tuple[bytes, str]:
    """Encode multipart/form-data by hand so the recorded request body is exact.

    httpx's own encoder picks a random boundary per call, which would make the recorded
    request bytes differ on every run for no behavioural reason. BR21.1 wants the bytes
    that were sent, and a fixture that changes when nothing changed is not evidence.
    """
    marker = f"--{boundary}".encode()
    parts: list[bytes] = []
    for name, value in fields:
        parts.append(
            marker
            + b"\r\n"
            + f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode()
            + value.encode()
            + b"\r\n"
        )
    for name, filename, mime, payload in files:
        disposition = f'Content-Disposition: form-data; name="{name}"; filename="{filename}"'
        parts.append(
            marker
            + b"\r\n"
            + disposition.encode()
            + b"\r\n"
            + f"Content-Type: {mime}\r\n\r\n".encode()
            + payload
            + b"\r\n"
        )
    body = b"".join(parts) + marker + b"--\r\n"
    return body, f"multipart/form-data; boundary={boundary}"


# Carried forward from the corrective pass. Each is a place where the first recording
# produced a fixture whose annotation disagreed with what it had actually captured.
FINDINGS: list[dict[str, str]] = [
    {
        "id": "FIX-1",
        "severity": "critical",
        "finding": (
            "isEditor() grants editor access only via an existing `editors` row or an email "
            "equal to OWNER_EMAIL ('madhavi.tri16@gmail.com'). The local mock identity is "
            "seedy@sites.test, which is NOT that email. On a genuinely fresh database the "
            "__sites_local_auth=1 cookie therefore yields editorAccess()==FALSE and every "
            "owner-identity fixture records 404."
        ),
        "impact": (
            "A re-record against a disposable empty DB would silently produce the inverse of "
            "the draft-only oracle: 404-for-owner instead of 200-for-owner."
        ),
        "required": "Insert editors(local_seedy, seedy@sites.test) before any owner recording.",
    },
    {
        "id": "FIX-2",
        "severity": "critical",
        "finding": (
            "The 1500000 cap at route.ts line 11 is `bodyText.length`, which in JavaScript is "
            "UTF-16 CODE UNITS -- neither characters/codepoints nor UTF-8 bytes."
        ),
        "evidence": (
            "F6-size-astral-under-in-units: 1.4M UTF-16 units / ~700k codepoints / ~2.8M UTF-8 "
            "bytes -> 200. F6-size-astral-over-in-units: 1.6M units / ~800k codepoints -> 413. "
            "Under a byte cap the first would be rejected; under a character cap the second "
            "would be accepted. Both are wrong."
        ),
        "required": (
            "Port as len(text.encode('utf-16-le')) // 2. Not len(text), not len(text.encode())."
        ),
    },
    {
        "id": "FIX-3",
        "severity": "major",
        "finding": (
            "A cross-origin Origin header is rejected by the dev server with plain-text "
            "'Forbidden' before the route executes, so route.ts line 9 sameOrigin() is not "
            "reachable that way. The reachable branch is a MISSING Origin header, which does "
            "return the route's own JSON 403 envelope."
        ),
        "required": (
            "Port sameOrigin() against F5-put-no-origin. Re-verify the cross-origin pair "
            "against production Cloudflare before trusting it."
        ),
    },
    {
        "id": "FIX-4",
        "severity": "minor",
        "finding": (
            "The dev server replaces the route's explicit Content-Length (line 11) with "
            "transfer-encoding: chunked on media responses."
        ),
        "required": (
            "Do not assert absence of Content-Length. Marked as recorderCaveat on the "
            "affected fixtures."
        ),
    },
    {
        "id": "FIX-5",
        "severity": "major",
        "finding": (
            "The per-type upload size limits at route.ts line 31 are NOT reachable through "
            "the dev server for the 1 MB caption limit: the framework rejects the request "
            "body first and returns plain-text 'Payload Too Large' instead of the route's "
            "JSON envelope. F13-upload-vtt-over-limit records the framework's response, not "
            "the route's."
        ),
        "evidence": (
            "F13-upload-vtt-over-limit: 413 with a 17-byte plain-text body, where route.ts "
            "line 31 would have produced {'error': 'Choose files totaling less than 1 MB.'}."
        ),
        "required": (
            "Port the limit table (50 MB video / 10 MB image+PDF / 1 MB captions) and the "
            "51 MB content-length pre-check from route.ts lines 18 and 31 by reading the "
            "source, not from this fixture's body. Re-verify against production Cloudflare "
            "before trusting either status/body pair."
        ),
    },
    {
        "id": "FIX-6",
        "severity": "major",
        "finding": (
            "The four conditions on route.ts line 28 -- more than two variants, an empty or "
            "non-File variant, variants sent without optimized=true, and optimized=true on a "
            "non-WebP main file -- all return ONE message, 'The prepared image sizes could "
            "not be verified. Please choose the photo again.'"
        ),
        "evidence": (
            "F13-upload-three-variants, F13-upload-variants-without-optimized and "
            "F13-upload-optimized-not-webp are byte-identical 90-byte responses reached "
            "through three different conditions."
        ),
        "required": (
            "A port that implements only one of the four conditions still passes any test "
            "written against a single one of these fixtures. Assert all three, and read line "
            "28 for the fourth (an empty variant File), which the multipart encoder here "
            "cannot express."
        ),
    },
]


class Blocked(RuntimeError):
    """A precondition could not be met.

    BR21.5: this unit reports blocked, names the reason, and writes nothing. It is never
    reported as skipped, because a missing fixture set and a skipped one look identical
    on disk while meaning opposite things about every downstream parity claim.
    """


# --------------------------------------------------------------------------- #
# Preconditions. These are enforced here, in code, rather than described in the
# README, because each of them fails SILENTLY and produces a plausible-looking
# fixture set that is the inverse of the truth.
# --------------------------------------------------------------------------- #


def require_loopback_base(base: str) -> None:
    """Precondition 1 -- the dev server is reachable only as ``localhost``.

    vinext binds ``[::1]:5173`` and nothing else: ``127.0.0.1`` is refused outright, and
    the resulting connection error is easy to misread as "the server is not running".
    Requiring the literal hostname also discharges half of BR21.4 -- a base URL that is
    not loopback is, by construction, not the local dev server.
    """
    host = urllib.parse.urlsplit(base).hostname
    if host != "localhost":
        raise Blocked(
            f"Base URL host is {host!r}, and it must be exactly 'localhost'.\n"
            "  The vinext dev server binds [::1]:5173 only. 127.0.0.1 is refused, and any\n"
            "  non-loopback host would violate BR21.4 (nothing hosted is touched)."
        )


def require_server_reachable(base: str) -> None:
    """The source app is actually up, and it is the dev server rather than the built one."""
    try:
        response = httpx.get(f"{base}/robots.txt", timeout=10.0)
    except httpx.HTTPError as exc:
        raise Blocked(
            f"No HTTP response from {base} ({exc}).\n"
            "  Start the source app with `node scripts/run-framework.mjs dev` from\n"
            "  madhavi-tripathi/. Do NOT use `pnpm start`: that runs wrangler against\n"
            "  dist/, where the mock-auth vite plugin never runs and no owner identity\n"
            "  is obtainable at all."
        ) from exc
    if response.status_code != 200:
        raise Blocked(
            f"GET {base}/robots.txt returned {response.status_code}, not 200. "
            "The server answering is not the source app."
        )


def locate_database(src: pathlib.Path) -> pathlib.Path:
    """Find the single miniflare D1 sqlite file. Its name is a content hash, so glob it."""
    directory = src / ".wrangler" / "state" / "v3" / "d1" / "miniflare-D1DatabaseObject"
    if not directory.is_dir():
        raise Blocked(
            f"No local database at {directory}.\n"
            "  The migrations have not been applied to this checkout's emulator state."
        )
    candidates = sorted(p for p in directory.glob("*.sqlite") if p.name != "metadata.sqlite")
    if len(candidates) != 1:
        raise Blocked(
            f"Expected exactly one D1 sqlite file under {directory}, found {len(candidates)}: "
            f"{[p.name for p in candidates]}"
        )
    return candidates[0]


def require_editor_row(database: pathlib.Path) -> None:
    """Precondition 2 -- the ``editors`` table already holds the local mock identity.

    This is the failure that matters most, and it is invisible from the responses.
    ``server.ts isEditor()`` grants access on an existing ``editors`` row OR on an email
    equal to ``OWNER_EMAIL``. The injected mock identity is ``seedy@sites.test``, which
    is NOT the owner email -- so against a genuinely empty database the owner cookie
    yields ``editorAccess() == false`` and every owner-identity fixture records 404.

    That is the exact inverse of the oracle BR21.7 exists to protect: the draft-only
    media case would record "404 for the owner" and every dependent test would agree
    with it. So the row is checked before anything is recorded, not after.
    """
    connection = sqlite3.connect(f"file:{database}?mode=ro", uri=True)
    try:
        rows = connection.execute("SELECT user_id, email FROM editors").fetchall()
    except sqlite3.DatabaseError as exc:
        raise Blocked(
            f"Could not read the `editors` table from {database} ({exc}).\n"
            "  Apply the migrations before recording."
        ) from exc
    finally:
        connection.close()

    if not any(user_id == MOCK_USER_ID or email == MOCK_EMAIL for user_id, email in rows):
        raise Blocked(
            "The `editors` table does not hold the local mock identity, so the owner cookie\n"
            "  grants NO editor access and every owner fixture would record 404 -- the exact\n"
            "  inverse of the draft-only oracle (BR21.7, evidence for FR7.2).\n"
            f"  Found: {rows}\n"
            "  Insert the row first:\n"
            f"    {EDITORS_ROW_SQL}"
        )


def require_owner_identity(base: str) -> dict[str, Any]:
    """Prove the cookie actually yields editor access, and return the live content state.

    The row check above names the cause; this names the effect. Both are kept because a
    schema that satisfies the first without satisfying the second is exactly the shape
    of a silent regression in the mock-auth plugin.
    """
    response = httpx.get(f"{base}/api/content", headers=OWNER, timeout=60.0)
    if response.status_code != 200:
        raise Blocked(
            f"GET /api/content with the owner cookie returned {response.status_code}, not 200.\n"
            "  editorAccess() is false for this session, so every owner fixture would record\n"
            "  the anonymous branch. Check the __sites_local_auth cookie and the editors row."
        )
    state: dict[str, Any] = response.json()
    return state


def resolve_media_keys(database: pathlib.Path, published: Any) -> tuple[str, str, str | None]:
    """Pick the draft-only key, the malformed key, and a published key if one exists.

    Not a formality. The whole F7/F9/F11/F12 matrix rests on one asset being present in
    the database and absent from what the public can see. If that asset is ever
    published, the draft-only fixture silently becomes a second copy of the public case,
    the 404-not-403 behaviour goes unrecorded, and nothing downstream can tell.

    ``isPublic`` is true when the literal media path appears anywhere in the serialised
    published document (FR7.2), so the public key is resolved the same way the route
    resolves it rather than from a structured field.
    """
    connection = sqlite3.connect(f"file:{database}?mode=ro", uri=True)
    try:
        assets = connection.execute("SELECT key, size FROM assets ORDER BY key").fetchall()
    finally:
        connection.close()
    if not assets:
        raise Blocked(
            "The `assets` table is empty. F7 through F12 all need one asset that is present\n"
            "  in the database and ABSENT from the published document. Upload one through the\n"
            "  editor and save it as a draft WITHOUT publishing, then re-run."
        )

    serialised = json.dumps(published)
    unpublished = [(key, size) for key, size in assets if f"/api/media/{key}" not in serialised]
    public = [key for key, _ in assets if f"/api/media/{key}" in serialised]
    if not unpublished:
        raise Blocked(
            "Every asset in the database appears in the published document, so there is no\n"
            "  draft-only key to record. Without it the private-media oracle (BR21.7 /\n"
            "  FR7.2) cannot be captured at all."
        )
    # Largest unpublished asset: the range fixtures want an object big enough that the
    # closed, open, suffix and clamped branches are all distinguishable.
    draft_only = max(unpublished, key=lambda item: item[1])[0]
    malformed = draft_only.rsplit(".", 1)[0] + MALFORMED_SUFFIX
    return draft_only, malformed, public[0] if public else None


def back_up_state(src: pathlib.Path) -> pathlib.Path:
    """Copy .wrangler/state somewhere disposable before the first write.

    The write fixtures drive the real save/publish path, so they mutate the source app's
    local database. The brief keeps madhavi-tripathi/ as the rollback baseline; this is
    what makes that survivable. The backup lands outside the repository so it is never
    committed, and a failure to take it aborts the run (BR21.5).
    """
    state = src / ".wrangler" / "state"
    if not state.is_dir():
        raise Blocked(f"No emulator state at {state}; nothing to back up and nothing to record.")
    stamp = dt.datetime.now(dt.UTC).strftime("%Y%m%dT%H%M%SZ")
    destination = pathlib.Path(tempfile.gettempdir()) / f"chiku-wrangler-state-{stamp}"
    try:
        shutil.copytree(state, destination)
    except OSError as exc:
        raise Blocked(f"Could not back up {state} to {destination} ({exc}).") from exc
    return destination


# --------------------------------------------------------------------------- #
# Recording primitives
# --------------------------------------------------------------------------- #


def provenance(src: pathlib.Path, base: str) -> dict[str, Any]:
    """BR21.2. A fixture without this is an assertion, not evidence."""

    def git(*args: str) -> str:
        completed = subprocess.run(  # noqa: S603 - fixed argv, no shell, no user input
            ["git", *args],  # noqa: S607 - `git` from PATH is the documented prerequisite
            cwd=src,
            capture_output=True,
            text=True,
            check=False,
        )
        return completed.stdout.strip()

    dirty = [line for line in git("status", "--porcelain").splitlines() if line]
    commit = git("rev-parse", "HEAD")
    if not commit:
        raise Blocked(
            f"Could not read the source commit from {src}. Provenance is required by BR21.2, "
            "so the run stops rather than writing fixtures of unknown origin."
        )
    return {
        "sourceCommit": commit,
        "sourceDirtyFiles": len(dirty),
        "recordedAt": dt.datetime.now(dt.UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "base": base,
    }


class Recorder:
    """Writes ``<name>.meta.json`` + ``<name>.body`` per request, and the db snapshots."""

    def __init__(self, base: str, out: pathlib.Path, database: pathlib.Path, prov: dict[str, Any]):
        self.base = base
        self.out = out
        self.database = database
        self.provenance = prov
        (out / "http").mkdir(parents=True, exist_ok=True)
        (out / "db").mkdir(parents=True, exist_ok=True)

    def record(
        self,
        name: str,
        method: str,
        path: str,
        *,
        headers: dict[str, str] | None = None,
        body: bytes | None = None,
        identity: str = "anonymous",
        branch: str | None = None,
        defect: str | None = None,
        caveat: str | None = None,
        note: str | None = None,
    ) -> httpx.Response:
        """One request in, one raw fixture out (BR21.1 -- nothing is normalised here)."""
        # Accept-Encoding: identity suppresses transparent gzip, so the bytes on disk are
        # the bytes the route produced rather than the bytes the transport chose.
        sent = {"Accept-Encoding": "identity", **(headers or {})}
        with httpx.Client(follow_redirects=False, timeout=180.0) as client:
            response = client.request(method, self.base + path, headers=sent, content=body)

        # A multipart upload body is binary and has no meaningful UTF-16 or codepoint
        # length; the two text measurements become null rather than a lie. The cap at
        # route.ts line 11 only ever sees a text body, so nothing downstream loses an
        # oracle. For every text body this is byte-identical to decoding outright.
        try:
            text: str | None = body.decode("utf-8") if body else ""
        except UnicodeDecodeError:
            text = None
        meta = {
            "name": name,
            "identity": identity,
            "request": {
                "method": method,
                "path": path,
                "headers": sent,
                # BR21.6: all three measurements, always. The cap counts the first of them
                # and no single number can prove which.
                "bodyUnits_utf16": None if text is None else len(text.encode("utf-16-le")) // 2,
                "bodyChars_codepoints": None if text is None else len(text),
                "bodyBytes_utf8": len(body) if body else 0,
            },
            "response": {
                "status": response.status_code,
                # Wire order, duplicates preserved: a list of pairs, not a dict.
                "headers": [[key, value] for key, value in response.headers.multi_items()],
                "bodyBytes": len(response.content),
                "bodySha256": hashlib.sha256(response.content).hexdigest(),
            },
            "sourceBranch": branch,
            "deliberateDefect": defect,
            "recorderCaveat": caveat,
            "note": note,
            "provenance": self.provenance,
        }
        directory = self.out / "http"
        (directory / f"{name}.body").write_bytes(response.content)
        (directory / f"{name}.meta.json").write_text(
            json.dumps(meta, indent=2, ensure_ascii=False) + "\n"
        )
        flag = "  [DEFECT]" if defect else ""
        print(f"  {name:<44} {method:<4} {response.status_code}  {len(response.content):>9}B{flag}")
        return response

    def snapshot(self, name: str, note: str) -> dict[str, Any]:
        """Stored-row state: retention, ordering and timestamp movement never reach a response."""
        connection = sqlite3.connect(f"file:{self.database}?mode=ro", uri=True)
        connection.row_factory = sqlite3.Row
        try:
            content_rows = [dict(row) for row in connection.execute("SELECT * FROM site_content")]
            revisions = [
                dict(row)
                for row in connection.execute(
                    "SELECT id, revision, action, created_at, baseline, "
                    "length(content) AS content_length "
                    "FROM content_revisions ORDER BY revision, action, id"
                )
            ]
            assets = [dict(row) for row in connection.execute("SELECT * FROM assets ORDER BY key")]
        finally:
            connection.close()

        snapshot: dict[str, Any] = {
            "name": name,
            "note": note,
            "provenance": self.provenance,
            # The two content columns are digested rather than inlined: each is ~15 KB and
            # the point of the snapshot is revision/timestamp movement, not the text.
            "site_content": [
                {
                    key: (
                        value
                        if key not in ("draft", "published")
                        else {
                            "length": len(value),
                            "sha256": hashlib.sha256(value.encode()).hexdigest(),
                        }
                    )
                    for key, value in row.items()
                }
                for row in content_rows
            ],
            "content_revisions": revisions,
            "assets": assets,
        }
        (self.out / "db" / f"{name}.json").write_text(
            json.dumps(snapshot, indent=2, ensure_ascii=False) + "\n"
        )
        current = content_rows[0] if content_rows else {}
        print(f"  {name:<44} DB   revision={current.get('revision')} revisions={len(revisions)}")
        return snapshot


# --------------------------------------------------------------------------- #
# The recording run
# --------------------------------------------------------------------------- #


def run(recorder: Recorder, draft_only: str, malformed: str, published: str | None) -> None:
    base = recorder.base
    origin = {**OWNER, "Origin": base, "Content-Type": "application/json"}

    def put(
        name: str,
        payload: dict[str, Any],
        *,
        headers: dict[str, str] | None = None,
        identity: str = "owner",
        **kwargs: Any,
    ) -> httpx.Response:
        return recorder.record(
            name,
            "PUT",
            "/api/content",
            headers=origin if headers is None else headers,
            body=json.dumps(payload).encode("utf-8"),
            identity=identity,
            **kwargs,
        )

    print("\n== F1  public routes (anonymous) ==")
    recorder.record("F1-home-anon", "GET", "/")
    recorder.record("F1-robots-anon", "GET", "/robots.txt")
    recorder.record("F1-sitemap-anon", "GET", "/sitemap.xml")

    print("\n== F2  editor routes, both identities ==")
    recorder.record("F2-edit-anon", "GET", "/edit", branch="requireChatGPTUser -> redirect")
    recorder.record(
        "F2-edit-owner",
        "GET",
        "/edit",
        headers=OWNER,
        identity="owner",
        branch=f"isEditor: editors row {MOCK_USER_ID}",
    )
    recorder.record("F2-preview-owner", "GET", "/edit/preview", headers=OWNER, identity="owner")

    print("\n== F3  content + history API, both identities ==")
    recorder.record("F3-content-anon", "GET", "/api/content", branch="editorAccess false -> 403")
    recorder.record("F3-content-owner", "GET", "/api/content", headers=OWNER, identity="owner")
    recorder.record("F3-history-anon", "GET", "/api/history")
    recorder.record("F3-history-owner", "GET", "/api/history", headers=OWNER, identity="owner")

    # The count per key case is the number of distinct SOURCE BRANCHES, not the number of
    # distinct statuses (BR21.7). Draft-only diverges in status; missing diverges in
    # branch at the same status; malformed returns at the regex before either identity
    # check runs, so a second recording would capture the same code path twice.
    print("\n== F7/F9/F10  media key cases x identity ==")
    if published is None:
        # BR21.5: an unrecordable case is REPORTED, never silently omitted. A missing
        # fixture and a skipped one look identical on disk and mean opposite things.
        print(
            "  !! NOT RECORDED: F7-published-anon / F7-published-owner.\n"
            "     No asset key appears in the serialised published document, so isPublic is\n"
            "     false for every asset and the `isPublic == true` branch of route.ts line 8\n"
            "     is unreachable. The public-read path -- the ordinary visitor's path -- has\n"
            "     NO recorded oracle. To close it, upload an asset through the editor,\n"
            "     reference it from published copy, publish, and re-run."
        )
    else:
        recorder.record(
            "F7-published-anon",
            "GET",
            f"/api/media/{published}",
            branch="line 8 isPublic true -> served without an identity check",
        )
        recorder.record(
            "F7-published-owner",
            "GET",
            f"/api/media/{published}",
            headers=OWNER,
            identity="owner",
            branch="line 8 isPublic true -> identical to anonymous",
        )
    recorder.record(
        "F7-draftonly-anon", "GET", f"/api/media/{draft_only}", branch="line 8 auth block"
    )
    recorder.record(
        "F7-draftonly-owner",
        "GET",
        f"/api/media/{draft_only}",
        headers=OWNER,
        identity="owner",
        branch="passes line 8, asset row hit",
    )
    recorder.record(
        "F9-missing-anon", "GET", f"/api/media/{MISSING_KEY}", branch="line 8 auth block"
    )
    recorder.record(
        "F9-missing-owner",
        "GET",
        f"/api/media/{MISSING_KEY}",
        headers=OWNER,
        identity="owner",
        branch="line 9 asset-row miss",
    )
    recorder.record(
        "F10-malformed-once",
        "GET",
        f"/api/media/{malformed}",
        branch="line 6 key regex, returns before readContent/editorAccess",
        note="Recorded ONCE: the regex returns before either identity check runs.",
    )

    print("\n== F8  HEAD, and two of the three deliberate defects (BR21.3) ==")
    recorder.record(
        "F8-head-owner",
        "HEAD",
        f"/api/media/{draft_only}",
        headers=OWNER,
        identity="owner",
        branch="line 12 HEAD short-circuit",
    )
    recorder.record(
        "F8-head-with-range-owner",
        "HEAD",
        f"/api/media/{draft_only}",
        headers={**OWNER, "Range": "bytes=0-99"},
        identity="owner",
        branch="line 12 returns before parseByteRange",
        defect=(
            "HEAD returns 200 with the FULL Content-Length and ignores Range. "
            "Preserved, not corrected."
        ),
    )
    full = recorder.record(
        "F8-get-full-owner",
        "GET",
        f"/api/media/{draft_only}",
        headers=OWNER,
        identity="owner",
        branch="no Range -> parseByteRange returns null -> 200",
    )
    etag = full.headers.get("etag", "")
    # The object size comes from the BODY WE JUST RECORDED, never from Content-Length.
    # The dev server strips that header (FIX-4), and the first recording read 0 from it --
    # which turned three boundary ranges into ordinary ranges and put a false [DEFECT]
    # flag on a fourth. This one line is the correction.
    size = len(full.content)
    recorder.record(
        "F8-if-none-match-owner",
        "GET",
        f"/api/media/{draft_only}",
        headers={**OWNER, "If-None-Match": etag},
        identity="owner",
        defect="ETag is emitted but no 304 is ever returned. Preserved, not corrected.",
    )

    print(f"\n== F11  byte-range branches (measured object size = {size}) ==")
    # (label, Range header, branch, defect, caveat). The six size-derived cases carry the
    # chunked caveat because they are the ones whose expected Content-Length the dev
    # server's transfer-encoding substitution would otherwise be read as source behaviour.
    ranges: list[tuple[str, str, str, str | None, str | None]] = [
        ("valid-closed", "bytes=0-99", "line 20 closed range", None, None),
        ("valid-open", "bytes=100-", "line 20 open end -> size-1", None, None),
        ("valid-suffix", "bytes=-100", "line 19 suffix", None, None),
        ("invalid-nomatch", "bytes=abc", "line 17 regex miss", None, None),
        ("invalid-bothempty", "bytes=-", "line 17 both groups empty", None, None),
        ("invalid-zerosuffix", "bytes=-0", "line 19 suffix <= 0", None, None),
        ("invalid-reversed", "bytes=100-50", "line 20 end < start", None, None),
        ("invalid-unit", "items=0-99", "line 17 regex miss (wrong unit)", None, None),
        (
            "clamped-end",
            f"bytes=0-{size + 999}",
            "line 20 end clamped: end=Math.min(end,size-1) -> whole object",
            None,
            CHUNKED_CAVEAT,
        ),
        (
            "last-byte",
            f"bytes={size - 1}-",
            "line 20 start == size-1, the last valid start",
            None,
            CHUNKED_CAVEAT,
        ),
        (
            "invalid-startpastend",
            f"bytes={size}-",
            "line 20 start >= size -> invalid -> 416",
            None,
            CHUNKED_CAVEAT,
        ),
        (
            "invalid-startwaypast",
            f"bytes={size + 999}-",
            "line 20 start >= size -> invalid -> 416",
            None,
            CHUNKED_CAVEAT,
        ),
        (
            "oversized-suffix",
            f"bytes=-{size + 999}",
            "line 19 start=Math.max(0,size-suffix) -> 0 -> whole object",
            "An oversized suffix range returns 206 Partial Content for the WHOLE object "
            "instead of 416. Preserved, not corrected.",
            CHUNKED_CAVEAT,
        ),
        (
            "exact-suffix",
            f"bytes=-{size}",
            "line 19 suffix == size -> start 0 -> whole object",
            None,
            CHUNKED_CAVEAT,
        ),
    ]
    for label, header, branch, defect, caveat in ranges:
        recorder.record(
            f"F11-range-{label}",
            "GET",
            f"/api/media/{draft_only}",
            headers={**OWNER, "Range": header},
            identity="owner",
            branch=branch,
            defect=defect,
            caveat=caveat,
        )

    recorder.record(
        "F11-ifrange-mismatch",
        "GET",
        f"/api/media/{draft_only}",
        headers={**OWNER, "Range": "bytes=0-99", "If-Range": '"not-the-etag"'},
        identity="owner",
        branch="line 14 If-Range mismatch -> range ignored -> 200 full body",
    )
    recorder.record(
        "F11-ifrange-match",
        "GET",
        f"/api/media/{draft_only}",
        headers={**OWNER, "Range": "bytes=0-99", "If-Range": etag},
        identity="owner",
        branch="line 14 If-Range matches -> range honoured -> 206",
    )

    print("\n== F4/F5  write path: save / conflict / publish, with stored-row snapshots ==")
    recorder.snapshot("S0-before-any-write", "Baseline before this recording run touched anything.")

    read = recorder.record(
        "F4-read-state-owner", "GET", "/api/content", headers=OWNER, identity="owner"
    ).json()
    revision = read["revision"]
    content = read["draft"]

    put(
        "F4-save-draft",
        {"content": content, "revision": revision, "action": "draft"},
        branch="writeContent batch, revision guard matches",
    )
    recorder.snapshot("S1-after-draft-save", f"After a draft save from revision {revision}.")

    put(
        "F5-conflict-stale-revision",
        {"content": content, "revision": revision, "action": "draft"},
        branch="line 18: batch returns null -> 409 with latest metadata",
        note=(
            "Replays the SAME revision that was just consumed. This is the 409 the editor "
            "branches on to enter conflict recovery."
        ),
    )
    recorder.snapshot(
        "S2-after-conflict", "After a rejected stale write: rows must be UNCHANGED from S1."
    )

    put(
        "F5-publish",
        {"content": content, "revision": revision + 1, "action": "publish"},
        branch="publish=1 -> published + published_at updated",
    )
    recorder.snapshot(
        "S3-after-publish", "After publish: published, published_at and revision all move."
    )

    print("\n== F5b  authorization + CSRF branches on the write path ==")
    put(
        "F5-put-anon",
        {"content": content, "revision": revision + 2, "action": "draft"},
        headers={"Origin": base, "Content-Type": "application/json"},
        identity="anonymous",
        branch="line 10 editorAccess false -> 403",
    )
    put(
        "F5-put-no-origin",
        {"content": content, "revision": revision + 2, "action": "draft"},
        headers={**OWNER, "Content-Type": "application/json"},
        branch="line 9 sameOrigin false -> 403 (checked BEFORE auth)",
    )
    # Corrected: this never reaches route.ts line 9. The dev server rejects the
    # cross-origin request itself, with plain text rather than the route's JSON envelope.
    put(
        "F5-put-cross-origin",
        {"content": content, "revision": revision + 2, "action": "draft"},
        headers={**OWNER, "Origin": "https://evil.example", "Content-Type": "application/json"},
        branch="NOT route.ts line 9. The dev server rejects the cross-origin request itself.",
        note=(
            "Plain-text 'Forbidden', not the route's JSON {error} envelope. route.ts line 9 "
            "sameOrigin() is unreachable for a cross-origin Origin header under this server. "
            "The reachable same-origin-failure branch is F5-put-no-origin (no Origin header), "
            "which DOES return the route's own 403 envelope."
        ),
        caveat=CROSS_ORIGIN_CAVEAT,
    )

    print("\n== F6  the 413 boundary, in UTF-16 units, codepoints AND UTF-8 bytes (BR21.6) ==")
    # route.ts line 11 tests `bodyText.length`. In JavaScript that is UTF-16 CODE UNITS:
    # not codepoints and not bytes. The ASCII pair pins the boundary; the astral pair is
    # what proves which unit is being counted, because U+1F600 is 2 units, 1 codepoint and
    # 4 UTF-8 bytes, so a byte cap and a character cap fail it in opposite directions.
    #
    # ensure_ascii=False is load-bearing. The first recording left json.dumps at its
    # default, every emoji became a 12-character ASCII escape, and the fixture tested
    # nothing about UTF-16 at all.
    revision = refresh_revision(base)

    def padded(units: int, filler: str) -> bytes:
        envelope = {"content": content, "revision": revision, "action": "draft", "pad": ""}
        shell = len(json.dumps(envelope, ensure_ascii=False).encode("utf-16-le")) // 2
        # Units per filler character: 1 for ASCII, 2 for an astral codepoint's surrogate
        # pair. Measuring the shell in the same unit as the cap is the whole trick.
        per_filler = len(filler.encode("utf-16-le")) // 2
        repeats = max(0, (units - shell) // per_filler)
        return json.dumps({**envelope, "pad": filler * repeats}, ensure_ascii=False).encode("utf-8")

    cases: list[tuple[str, int, str, int, str]] = [
        (
            "at-limit",
            1_500_000,
            "a",
            200,
            "line 11 boundary: length == 1500000, NOT > -> passes to JSON.parse",
        ),
        ("over-limit", 1_500_001, "a", 413, "line 11 boundary: length == 1500001, > -> 413"),
        (
            "astral-under-in-units",
            1_400_000,
            "\U0001f600",
            200,
            "1.4M UTF-16 units but ~2.8M UTF-8 bytes: PASSES. The cap is NOT bytes.",
        ),
        (
            "astral-over-in-units",
            1_600_000,
            "\U0001f600",
            413,
            "1.6M UTF-16 units from only ~800k CODEPOINTS: 413. The cap is NOT characters.",
        ),
    ]
    for label, units, filler, expected, branch in cases:
        payload = padded(units, filler)
        text = payload.decode("utf-8")
        response = recorder.record(
            f"F6-size-{label}",
            "PUT",
            "/api/content",
            headers=origin,
            body=payload,
            identity="owner",
            branch=branch,
            note=(
                f"utf16Units={len(text.encode('utf-16-le')) // 2} "
                f"codepoints={len(text)} utf8Bytes={len(payload)} expected={expected}"
            ),
        )
        if response.status_code != expected:
            print(f"    !! expected {expected}, got {response.status_code} -- check the padding")
        if response.status_code == 200:
            revision = response.json()["revision"]

    print("\n== F12  malformed / invalid write bodies (the 400 + issues envelope) ==")
    recorder.record(
        "F12-bad-json",
        "PUT",
        "/api/content",
        headers=origin,
        body=b"{not json",
        identity="owner",
        branch="line 12 JSON.parse throws -> 400",
    )
    recorder.record(
        "F12-array-body",
        "PUT",
        "/api/content",
        headers=origin,
        body=b"[]",
        identity="owner",
        branch="line 13 Array.isArray -> 400",
    )
    put(
        "F12-schema-invalid",
        {"content": {"nope": True}, "revision": revision, "action": "draft"},
        branch="line 15 contentSchema.safeParse fails -> 400 WITH issues[]",
        note=(
            "This is the envelope editor-workflow.ts reads to highlight fields. "
            "FastAPI's default loc/msg shape would break it silently."
        ),
    )
    put(
        "F12-bad-action",
        {"content": content, "revision": revision, "action": "sideways"},
        branch="line 16 action not in [draft,publish] -> 400",
    )
    put(
        "F12-autosave-on-publish",
        {"content": content, "revision": revision, "action": "publish", "autosave": True},
        branch="line 16 autosave=true with action!=draft -> 400",
    )
    put(
        "F12-negative-revision",
        {"content": content, "revision": -1, "action": "draft"},
        branch="line 16 revision < 0 -> 400",
    )

    recorder.snapshot("S4-final", "Final stored state at the end of the write-path recording.")

    # Uploads run last: the accepted-type recordings insert asset rows, and every fixture
    # above wants the asset table as it stood before they did.
    record_uploads(recorder)


def record_uploads(recorder: Recorder) -> None:
    """The F13 upload family: one recording per accepted type, then the reject branches.

    Named F13 rather than the functional spec's F11 because F11 was already taken on disk
    by the byte-range family. README.md carries the full spec-to-disk mapping.

    Every successful upload here writes a real asset row and a real R2 object. They are
    small header-only probes, deliberately far below the 188,618-byte draft-only asset, so
    `resolve_media_keys` keeps picking the same key on a re-record and the byte-range
    fixtures keep their object size.
    """
    base = recorder.base
    owner_origin = {**OWNER, "Origin": base}

    def post(
        name: str,
        *,
        fields: list[tuple[str, str]] | None = None,
        files: list[tuple[str, str, str, bytes]],
        headers: dict[str, str] | None = None,
        identity: str = "owner",
        branch: str,
        caveat: str | None = None,
    ) -> httpx.Response:
        body, content_type = multipart(fields or [], files)
        sent = {**(owner_origin if headers is None else headers), "Content-Type": content_type}
        return recorder.record(
            name,
            "POST",
            "/api/upload",
            headers=sent,
            body=body,
            identity=identity,
            branch=branch,
            caveat=caveat,
        )

    # --- Accepted types: one per entry in route.ts `types` ------------------ #
    for kind, (filename, mime, payload) in UPLOAD_VALID.items():
        fields = [("kind", "captions")] if kind == "vtt" else []
        post(
            f"F13-upload-{kind}",
            fields=fields,
            files=[("file", filename, mime, payload)],
            branch=f"accepted type {mime} -> 200 with url/filename/sources",
        )

    # --- Authorization and origin ------------------------------------------ #
    post(
        "F13-upload-anon",
        files=[("file", "probe.png", "image/png", _png(64, 48))],
        headers={"Origin": base},
        identity="anonymous",
        branch="line 16 editorAccess() false -> 403 envelope",
    )
    post(
        "F13-upload-no-origin",
        files=[("file", "probe.png", "image/png", _png(64, 48))],
        headers=dict(OWNER),
        branch="line 16 sameOrigin() false (Origin absent) -> 403 envelope",
    )
    post(
        "F13-upload-cross-origin",
        files=[("file", "probe.png", "image/png", _png(64, 48))],
        headers={**OWNER, "Origin": "https://evil.example"},
        branch="line 16 sameOrigin() -- but the dev server rejects first (FIX-3)",
        caveat=CROSS_ORIGIN_CAVEAT,
    )

    # --- The file field itself --------------------------------------------- #
    post(
        "F13-upload-no-file",
        files=[("other", "probe.png", "image/png", _png(64, 48))],
        branch="line 19 file not a File -> 400 'Choose a non-empty file.'",
    )
    post(
        "F13-upload-empty-file",
        files=[("file", "probe.png", "image/png", b"")],
        branch="line 19 file.size == 0 -> 400 'Choose a non-empty file.'",
    )
    post(
        "F13-upload-unsupported-type",
        files=[("file", "probe.txt", "text/plain", b"not an accepted type")],
        branch="line 22 types[mime] undefined -> 400 type-list message",
    )

    # --- Header validation, one per hand-written parser --------------------- #
    post(
        "F13-upload-png-bad-header",
        files=[("file", "probe.png", "image/png", b"\x89PNG\r\n\x1a\n" + bytes(40))],
        branch="upload-validation line 9 IHDR missing -> imageDimensions null -> 400",
    )
    post(
        "F13-upload-jpeg-bad-header",
        files=[("file", "probe.jpg", "image/jpeg", b"\xff\xd9" + bytes(30))],
        branch="upload-validation line 25 SOI missing -> imageDimensions null -> 400",
    )
    post(
        "F13-upload-webp-bad-header",
        files=[("file", "probe.webp", "image/webp", b"RIFF" + bytes(26) + b"NOPE")],
        branch="upload-validation line 12 WEBP tag missing -> imageDimensions null -> 400",
    )
    post(
        "F13-upload-pdf-bad-header",
        files=[("file", "probe.pdf", "application/pdf", b"NOT-A-PDF" + bytes(23))],
        branch="route line 43 head.startsWith('%PDF-') false -> 400",
    )
    post(
        "F13-upload-mp4-bad-header",
        files=[("file", "probe.mp4", "video/mp4", bytes(32))],
        branch="route line 43 head.slice(4,8) != 'ftyp' -> 400",
    )
    post(
        "F13-upload-webm-bad-header",
        files=[("file", "probe.webm", "video/webm", b"\x00\x45\xdf\xa3" + bytes(28))],
        branch="route line 43 EBML magic mismatch -> 400",
    )

    # --- The WebVTT validator, branch by branch ----------------------------- #
    post(
        "F13-upload-vtt-no-magic",
        fields=[("kind", "captions")],
        files=[("file", "probe.vtt", "text/vtt", b"NOTVTT\n\n00:00:00.000 --> 00:00:01.000\nx\n")],
        branch="validCaptions line 55 WEBVTT prefix missing -> 400 caption message",
    )
    post(
        "F13-upload-vtt-no-cues",
        fields=[("kind", "captions")],
        files=[("file", "probe.vtt", "text/vtt", b"WEBVTT\n\nNOTE only a note\n")],
        branch="validCaptions line 67 cues == 0 -> 400 caption message",
    )
    post(
        "F13-upload-vtt-markup",
        fields=[("kind", "captions")],
        files=[
            (
                "file",
                "probe.vtt",
                "text/vtt",
                b"WEBVTT\n\n00:00:00.000 --> 00:00:01.000\n<script>x</script>\n",
            )
        ],
        branch="validCaptions line 55 markup blocklist -> 400 caption message",
    )
    post(
        "F13-upload-vtt-backwards-cue",
        fields=[("kind", "captions")],
        files=[("file", "probe.vtt", "text/vtt", b"WEBVTT\n\n00:00:02.000 --> 00:00:01.000\nx\n")],
        branch="validCaptions line 64 end <= start -> 400 caption message",
    )
    post(
        "F13-upload-vtt-not-utf8",
        fields=[("kind", "captions")],
        files=[("file", "probe.vtt", "text/vtt", b"WEBVTT\n\n\xff\xfe\n00:00:00.000 --> x\n")],
        branch="validCaptions line 54 fatal UTF-8 decode -> 400 caption message",
    )
    post(
        "F13-upload-vtt-over-limit",
        fields=[("kind", "captions")],
        files=[("file", "probe.vtt", "text/vtt", VALID_VTT + b"\n" + b"x" * (1024 * 1024))],
        branch="route line 31 vtt limit 1 MB exceeded -> 413 'files totaling less than 1 MB'",
        caveat=BODY_LIMIT_CAVEAT,
    )

    # --- The prepared-variant rules ----------------------------------------- #
    small = _webp(64, 48)
    post(
        "F13-upload-variant-not-webp",
        fields=[("optimized", "true")],
        files=[
            ("file", "probe.webp", "image/webp", _webp(128, 96)),
            ("variants", "variant.png", "image/png", _png(64, 48)),
        ],
        branch="route line 37 variant mime != image/webp -> 400 'must use WebP'",
    )
    post(
        "F13-upload-three-variants",
        fields=[("optimized", "true")],
        files=[
            ("file", "probe.webp", "image/webp", _webp(128, 96)),
            ("variants", "a.webp", "image/webp", small),
            ("variants", "b.webp", "image/webp", small),
            ("variants", "c.webp", "image/webp", small),
        ],
        branch="route line 28 variants.length > 2 -> 400 'could not be verified'",
    )
    post(
        "F13-upload-variants-without-optimized",
        files=[
            ("file", "probe.webp", "image/webp", _webp(128, 96)),
            ("variants", "a.webp", "image/webp", small),
        ],
        branch="route line 28 variants present with optimized false -> 400",
    )
    post(
        "F13-upload-optimized-not-webp",
        fields=[("optimized", "true")],
        files=[("file", "probe.png", "image/png", _png(128, 96))],
        branch="route line 28 optimized with mime != image/webp -> 400",
    )
    post(
        "F13-upload-optimized-too-large",
        fields=[("optimized", "true")],
        files=[("file", "probe.webp", "image/webp", _webp(2000, 1500))],
        branch="route line 44 optimized dimension > 1600 -> 400 'no larger than 1600 pixels'",
    )
    post(
        "F13-upload-variant-larger-than-original",
        fields=[("optimized", "true")],
        files=[
            ("file", "probe.webp", "image/webp", _webp(64, 48)),
            ("variants", "a.webp", "image/webp", _webp(128, 96)),
        ],
        branch="route line 47 variant exceeds original -> 400 'must match the original framing'",
    )

    recorder.snapshot(
        "S5-after-uploads",
        "After the upload family: the asset rows the accepted-type recordings created.",
    )


def refresh_revision(base: str) -> int:
    """Re-read the live revision. The write fixtures above have moved it."""
    response = httpx.get(f"{base}/api/content", headers=OWNER, timeout=60.0)
    response.raise_for_status()
    revision: int = response.json()["revision"]
    return revision


# --------------------------------------------------------------------------- #
# Manifest
# --------------------------------------------------------------------------- #


def build_manifest(out: pathlib.Path, prov: dict[str, Any]) -> dict[str, Any]:
    """Index the fixture set from what is actually on disk, never from what was intended."""
    http_rows: list[dict[str, Any]] = []
    for path in sorted((out / "http").glob("*.meta.json")):
        meta = json.loads(path.read_text())
        http_rows.append(
            {
                "name": meta["name"],
                "kind": "http",
                "method": meta["request"]["method"],
                "path": meta["request"]["path"],
                "identity": meta["identity"],
                "status": meta["response"]["status"],
                "bodyBytes": meta["response"]["bodyBytes"],
                "bodySha256": meta["response"]["bodySha256"],
                "sourceBranch": meta.get("sourceBranch"),
                "deliberateDefect": meta.get("deliberateDefect"),
                "recorderCaveat": meta.get("recorderCaveat"),
            }
        )

    db_rows: list[dict[str, Any]] = []
    for path in sorted((out / "db").glob("*.json")):
        snapshot = json.loads(path.read_text())
        content = snapshot["site_content"][0] if snapshot["site_content"] else {}
        db_rows.append(
            {
                "name": snapshot["name"],
                "kind": "db",
                "note": snapshot.get("note"),
                "revision": content.get("revision"),
                "revisionRows": len(snapshot["content_revisions"]),
            }
        )

    return {
        "provenance": prov,
        "recorder": RECORDER_PATH,
        "preconditions": {
            "server": (
                "`node scripts/run-framework.mjs dev` on http://localhost:5173 -- NOT `pnpm "
                "start`, which runs wrangler against dist/ where the mock-auth vite plugin "
                "(configureServer) does not run and no owner identity is obtainable."
            ),
            "host": (
                "Must be `localhost`. The dev server binds [::1]:5173 only; 127.0.0.1 is refused."
            ),
            "ownerIdentity": (
                "Cookie __sites_local_auth=1 -> the vite plugin injects "
                f"oai-authenticated-user-* for {MOCK_USER_ID} / {MOCK_EMAIL}."
            ),
            "editorsRowRequired": (
                "CRITICAL. server.ts isEditor() grants access only if an `editors` row exists, "
                "or if the email equals OWNER_EMAIL ('madhavi.tri16@gmail.com'). The mock "
                f"identity is {MOCK_EMAIL}, which is NOT the owner email -- so on a genuinely "
                "EMPTY database the cookie yields editorAccess()==FALSE and every owner fixture "
                "records 404. This run used the existing local DB, which already contains "
                f"editors({MOCK_USER_ID}, {MOCK_EMAIL}). Any re-record against a fresh DB MUST "
                "insert that row first."
            ),
        },
        "fixtures": http_rows + db_rows,
        "counts": {
            "http": len(http_rows),
            "db": len(db_rows),
            "total": len(http_rows) + len(db_rows),
            "deliberateDefects": sum(1 for row in http_rows if row["deliberateDefect"]),
            "recorderCaveats": sum(1 for row in http_rows if row["recorderCaveat"]),
        },
        "findings": FINDINGS,
    }


# --------------------------------------------------------------------------- #


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Record the golden source-behaviour fixtures from the running madhavi-tripathi "
            "app. Overwrites chiku-website/fixtures/. This is a deliberate operator action, "
            "never part of a test run."
        )
    )
    parser.add_argument("--base", default=DEFAULT_BASE, help="Source app base URL.")
    parser.add_argument("--src", type=pathlib.Path, default=DEFAULT_SRC, help="Source checkout.")
    parser.add_argument("--out", type=pathlib.Path, default=DEFAULT_OUT, help="Fixture directory.")
    parser.add_argument(
        "--check-only",
        action="store_true",
        help="Run the preconditions and exit without recording or writing anything.",
    )
    args = parser.parse_args(argv)

    try:
        # Order matters: every check that can fail without touching anything runs before
        # the backup, and the backup runs before the first request that writes.
        require_loopback_base(args.base)
        require_server_reachable(args.base)
        database = locate_database(args.src)
        require_editor_row(database)
        state = require_owner_identity(args.base)
        draft_only, malformed, published_key = resolve_media_keys(database, state["published"])
        print("Preconditions met.")
        print(f"  database    {database}")
        print(f"  draft-only  {draft_only}")
        print(f"  malformed   {malformed}")
        print(f"  published   {published_key or '(none -- the public branch cannot be recorded)'}")
        if args.check_only:
            return 0

        backup = back_up_state(args.src)
        print(f"  state backup {backup}")
        prov = provenance(args.src, args.base)
        recorder = Recorder(args.base, args.out, database, prov)
        run(recorder, draft_only, malformed, published_key)
        manifest = build_manifest(args.out, prov)
        (args.out / "MANIFEST.json").write_text(
            json.dumps(manifest, indent=2, ensure_ascii=False) + "\n"
        )
        counts = manifest["counts"]
        print(f"\nWrote {counts['total']} fixtures -> {args.out}")
        print(f"  {counts['deliberateDefects']} deliberate defects preserved (BR21.3)")
        print(f"  {counts['recorderCaveats']} recorder caveats flagged")
        print(f"  state backup retained at {backup}")
    except Blocked as exc:
        # BR21.5. Blocked, with the reason named -- never silently skipped.
        print(f"\nBLOCKED: {exc}", file=sys.stderr)
        print(
            "\nNothing was recorded. Until this is resolved, every dependent unit's parity\n"
            "claim rests on the written knowledge base rather than on recorded behaviour,\n"
            "and must say so.",
            file=sys.stderr,
        )
        return 2

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
