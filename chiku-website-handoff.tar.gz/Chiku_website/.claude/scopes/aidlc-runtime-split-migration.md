---
name: runtime-split-migration
depth: Standard
keywords: []
description: Runtime-split migration - strict frontend/backend language boundary, ported persistence and auth, containerized delivery
skeleton: on
change_control: strict
---

# runtime-split-migration scope

A custom scope composed by the adaptive composer for a behaviour-preservation
migration that moves all application logic across a language boundary while the
user-visible behaviour is required to stay the same.

Composed 2026-09-24. ARS 46/100 (Standard band): IAE 0.18 LOW, CSU 0.48 MED,
VE 0.72 HIGH, R 0.50 MED, UA 0.28 LOW. Nearest stock scope was `classic` at
diff=5, beyond the match threshold, so no stock scope was adopted.

## Shape

19 stages EXECUTE, 14 SKIP, 16 approval gates.

The budget is deliberately shifted **out of** the framing phase and the whole
operation phase, and **into** specification, contract design and verification.
Verification entropy is the only HIGH component and is where the cost lives:
two runtimes, a strict language boundary, a security-sensitive auth replacement,
optimistic-concurrency semantics, upload validation rules, media access control
keyed on published content, SEO preservation, and a containerized end-to-end
pass - against a source that ships no test framework at all.

## Why the framing stages are skipped

Discovery completed before the workflow started, and the four contested design
questions (auth model, persistence, plan-only cloud, container deliverable) were
settled by the human at the outset. Market research, feasibility, team formation
and both mockup stages had nothing left to resolve: the existing interface *is*
the design spec, and there is no market question in rebuilding one person's
existing site.

`requirements-analysis` is retained against the mechanical screen, because in a
behaviour-preservation migration the specification is not there to decide what to
build - it is the **test oracle** for whether the rebuild matches.

`nfr-design` is retained because in a two-runtime container split the security
design *is* partly the infrastructure design: container privileges, session-key
handling, volume permissions, cookie flags against TLS termination.

## Why the operation phase is skipped

Nothing deploys in this piece of work. Google Cloud is plan-only by the human's
decision, `gcloud` is not installed, and there is no running service to
instrument or to write a runbook against.

## Walking skeleton

`skeleton: on`. The first Bolt carries one end-to-end public and management flow
through both runtimes before the remaining Bolts run, so the language boundary,
the session contract and the storage port are proven on a thin slice first.

## Un-skip triggers

- `feasibility` - if infrastructure design finds the free-tier envelope does not fit.
- `ci-pipeline` - once the project is under git with a remote.
- `observability-setup`, `deployment-pipeline`, `environment-provisioning`,
  `deployment-execution` - when a future intent actually deploys to Cloud Run.
