import { sqliteTable, text, integer, index } from 'drizzle-orm/sqlite-core';
export const siteContent=sqliteTable('site_content',{id:integer('id').primaryKey(),draft:text('draft').notNull(),published:text('published').notNull(),revision:integer('revision').notNull().default(0),updatedAt:text('updated_at').notNull(),publishedAt:text('published_at'),lastMutation:text('last_mutation')});
export const contentRevisions=sqliteTable('content_revisions',{
 id:text('id').primaryKey(),revision:integer('revision').notNull(),action:text('action',{enum:['draft','publish']}).notNull(),content:text('content').notNull(),createdAt:text('created_at').notNull(),baseline:integer('baseline',{mode:'boolean'}).notNull().default(false),
},table=>[index('idx_content_revisions_action_revision').on(table.action,table.revision)]);
export const editors=sqliteTable('editors',{userId:text('user_id').primaryKey(),email:text('email').notNull().unique()});
export const assets=sqliteTable('assets',{key:text('key').primaryKey(),filename:text('filename').notNull(),mime:text('mime').notNull(),size:integer('size').notNull(),createdAt:text('created_at').notNull()});
