import { env } from 'cloudflare:workers';
export function database(){if(!env.DB)throw new Error('Content storage is unavailable');return env.DB;}
export function bucket(){if(!env.BUCKET)throw new Error('File storage is unavailable');return env.BUCKET;}
