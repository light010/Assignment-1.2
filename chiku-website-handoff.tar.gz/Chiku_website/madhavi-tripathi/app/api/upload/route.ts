import { editorAccess, sameOrigin } from '@/app/server';
import { bucket, database } from '@/db';
import { imageDimensions, validCaptions } from '@/app/upload-validation';
export const dynamic = 'force-dynamic';
const MB = 1024 * 1024;
const types: Record<string, string> = {
  'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp',
  'application/pdf': 'pdf', 'video/mp4': 'mp4', 'video/webm': 'webm', 'text/vtt': 'vtt',
};

export async function POST(request: Request) {
  const written: string[] = [];
  const checkCancelled = () => {
    if (request.signal.aborted) throw new DOMException('Upload cancelled.', 'AbortError');
  };
  try {
    if (!sameOrigin(request) || !await editorAccess()) return Response.json({ error: 'Please sign in with the website owner’s account.' }, { status: 403 });
    checkCancelled();
    if (Number(request.headers.get('content-length') || 0) > 51 * MB) return Response.json({ error: 'Choose a video smaller than 50 MB, a photo / PDF smaller than 10 MB, or captions smaller than 1 MB.' }, { status: 413 });
    const data = await request.formData(), file = data.get('file');
    checkCancelled();
    if (!(file instanceof File) || !file.size) return Response.json({ error: 'Choose a non-empty file.' }, { status: 400 });
    const caption = data.get('kind') === 'captions';
    const mime = caption && /\.vtt$/i.test(file.name) && (!file.type || ['text/vtt', 'text/plain', 'application/octet-stream'].includes(file.type)) ? 'text/vtt' : file.type;
    if (!types[mime] || (caption && mime !== 'text/vtt')) return Response.json({ error: 'Please upload a JPG, PNG, WebP, PDF, MP4, WebM, or WebVTT caption file.' }, { status: 400 });
    const variants = data.getAll('variants');
    const optimized = data.get('optimized') === 'true';
    if (variants.length > 2 || variants.some(variant => !(variant instanceof File) || !variant.size) || (variants.length && !optimized) || (optimized && mime !== 'image/webp')) return Response.json({ error: 'The prepared image sizes could not be verified. Please choose the photo again.' }, { status: 400 });
    const files = [file, ...variants as File[]];
    const limit = mime.startsWith('video/') ? 50 : mime === 'text/vtt' ? 1 : 10;
    if (files.reduce((size, entry) => size + entry.size, 0) > limit * MB) return Response.json({ error: `Choose files totaling less than ${limit} MB.` }, { status: 413 });
    const entries: Array<{ file: File; mime: string; dimensions: { width: number; height: number } | null }> = [];
    for (const [index, entry] of files.entries()) {
      const entryMime = index ? entry.type : mime;
      if (index && entryMime !== 'image/webp') return Response.json({ error: 'Prepared photo sizes must use WebP.' }, { status: 400 });
      const bytes = new Uint8Array(await (entryMime.startsWith('image/') || entryMime === 'text/vtt' ? entry : entry.slice(0, 32)).arrayBuffer());
      checkCancelled();
      const head = new TextDecoder().decode(bytes.slice(0, 12));
      const dimensions = entryMime.startsWith('image/') ? imageDimensions(bytes, entryMime) : null;
      const valid = entryMime.startsWith('image/') ? !!dimensions : entryMime === 'text/vtt' ? validCaptions(bytes) : entryMime === 'video/mp4' ? head.slice(4, 8) === 'ftyp' : entryMime === 'video/webm' ? bytes[0] === 0x1a && bytes[1] === 0x45 && bytes[2] === 0xdf && bytes[3] === 0xa3 : head.startsWith('%PDF-');
      if (!valid) return Response.json({ error: entryMime === 'text/vtt' ? 'Choose a UTF-8 .vtt file beginning with WEBVTT and containing valid timed captions.' : 'The file format could not be verified. Please choose another file.' }, { status: 400 });
      if (optimized && (!dimensions || Math.max(dimensions.width, dimensions.height) > 1600)) return Response.json({ error: 'Prepared photo sizes must be no larger than 1600 pixels.' }, { status: 400 });
      if (index && dimensions) {
        const original = entries[0].dimensions!;
        const aspectError = Math.abs(dimensions.width / dimensions.height - original.width / original.height);
        if (dimensions.width > original.width || dimensions.height > original.height || aspectError > 2 / Math.min(dimensions.height, original.height)) return Response.json({ error: 'Prepared photo sizes must match the original framing.' }, { status: 400 });
      }
      entries.push({ file: entry, mime: entryMime, dimensions });
    }
    const sources: Array<{ src: string; width: number; height: number }> = [];
    for (const entry of entries) {
      checkCancelled();
      const key = `${crypto.randomUUID()}.${types[entry.mime]}`;
      written.push(key);
      await bucket().put(key, entry.file, { httpMetadata: { contentType: entry.mime } });
      checkCancelled();
      await database().prepare('INSERT INTO assets (key, filename, mime, size, created_at) VALUES (?, ?, ?, ?, ?)').bind(key, entry.file.name.slice(0, 200), entry.mime, entry.file.size, new Date().toISOString()).run();
      checkCancelled();
      if (optimized && entry.dimensions) sources.push({ src: `/api/media/${key}`, ...entry.dimensions });
    }
    checkCancelled();
    return Response.json({ url: `/api/media/${written[0]}`, filename: file.name, sources: sources.sort((a, b) => a.width - b.width) }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    // Best-effort cleanup also runs when the host exposes a client disconnect.
    await Promise.allSettled(written.map(async key => {
      await Promise.allSettled([
        bucket().delete(key),
        database().prepare('DELETE FROM assets WHERE key = ?').bind(key).run(),
      ]);
    }));
    if (error instanceof DOMException && error.name === 'AbortError') return Response.json({ error: 'Upload cancelled. Your previous file is unchanged.' }, { status: 499 });
    console.error('Upload failed', error);
    return Response.json({ error: 'Upload failed. Please try again; your form changes are safe.' }, { status: 503 });
  }
}
