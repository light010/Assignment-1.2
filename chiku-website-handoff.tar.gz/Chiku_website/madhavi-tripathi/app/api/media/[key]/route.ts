import { bucket, database } from '@/db';
import { readContent, editorAccess } from '@/app/server';
import { parseByteRange } from '@/app/media-utils';
export const dynamic='force-dynamic';
async function serve(request:Request,{params}:{params:Promise<{key:string}>}){try{
 const {key}=await params;if(!/^[a-f0-9-]+\.(jpg|png|webp|pdf|mp4|webm|vtt)$/.test(key))return new Response('Not found',{status:404});
 const {published}=await readContent();const isPublic=JSON.stringify(published).includes(`/api/media/${key}`);
 if(!isPublic&&!await editorAccess())return new Response('Not found',{status:404});
 const asset=await database().prepare('SELECT mime FROM assets WHERE key = ?').bind(key).first<{mime:string}>();if(!asset)return new Response('Not found',{status:404});
 const storage=bucket(),metadata=await storage.head(key);if(!metadata)return new Response('Not found',{status:404});
 const headers=new Headers({'Content-Type':asset.mime,'Cache-Control':'private, no-cache','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; sandbox",'Accept-Ranges':'bytes','ETag':metadata.httpEtag,'Content-Length':String(metadata.size)});
 if(request.method==='HEAD')return new Response(null,{headers});
 const ifRange=request.headers.get('if-range');
 const range=parseByteRange(!ifRange||ifRange===metadata.httpEtag?request.headers.get('range'):null,metadata.size);
 if(range==='invalid'){headers.set('Content-Range',`bytes */${metadata.size}`);headers.set('Content-Length','0');return new Response(null,{status:416,headers})}
 const object=await storage.get(key,range?{range}:undefined);if(!object)return new Response('Not found',{status:404});
 if(range){headers.set('Content-Range',`bytes ${range.offset}-${range.offset+range.length-1}/${metadata.size}`);headers.set('Content-Length',String(range.length))}
 return new Response(object.body,{status:range?206:200,headers});
 }catch(e){console.error(e);return new Response('File temporarily unavailable',{status:503});}}
export const GET=serve;
export const HEAD=serve;
