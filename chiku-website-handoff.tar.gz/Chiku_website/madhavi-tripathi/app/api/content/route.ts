import { editorAccess, readContent, sameOrigin } from '@/app/server';
import { contentSchema } from '@/app/content';
import { contentMetadata, writeContent } from '@/app/content-persistence';
export const dynamic='force-dynamic';
const reply=(body:unknown,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'no-store'}});
export async function GET(){try{if(!await editorAccess())return reply({error:'Please sign in with the website owner’s account.'},403);return reply(await readContent());}catch(e){console.error(e);return reply({error:'Unable to load your draft. Please try again.'},503);}}
export async function PUT(request:Request){
 try{
  if(!sameOrigin(request))return reply({error:'This request could not be verified. Refresh and try again.'},403);
  if(!await editorAccess())return reply({error:'Please sign in with the website owner’s account.'},403);
  const bodyText=await request.text();if(bodyText.length>1500000)return reply({error:'This update is too large.'},413);
  let body;try{body=JSON.parse(bodyText)}catch{return reply({error:'The update could not be read.'},400)}
  if(!body||typeof body!=='object'||Array.isArray(body))return reply({error:'Invalid save request.'},400);
  const parsed=contentSchema.safeParse(body.content);
  if(!parsed.success)return reply({error:'Please check the highlighted fields before saving.',issues:parsed.error.issues.map(issue=>({path:issue.path,message:issue.message}))},400);
  if(!Number.isSafeInteger(body.revision)||body.revision<0||body.revision>=Number.MAX_SAFE_INTEGER||!['draft','publish'].includes(body.action)||(body.autosave!==undefined&&typeof body.autosave!=='boolean')||(body.autosave===true&&body.action!=='draft'))return reply({error:'Invalid save request.'},400);
  const result=await writeContent({content:parsed.data,revision:body.revision,action:body.action});
  if(!result){const latest=contentMetadata(await readContent());return reply({error:'This draft changed in another tab. Your edits are still here. Review the latest saved draft before saving again.',...latest},409)}
  return reply({...result,published:body.action==='publish'});
 }catch(e){console.error('Save failed',e);return reply({error:'Your changes could not be saved. They are still in the form. Please try again.'},503);}
}
