import { editorAccess } from '@/app/server';
import { listContentRevisions, readContentRevision } from '@/app/content-persistence';
export const dynamic='force-dynamic';
const reply=(body:unknown,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'no-store'}});
export async function GET(request:Request){
 try{
  if(!await editorAccess())return reply({error:'Please sign in with the website owner’s account.'},403);
  const id=new URL(request.url).searchParams.get('id');
  if(id===null)return reply({revisions:await listContentRevisions()});
  if(!id||id.length>100||!/^[a-zA-Z0-9-]+$/.test(id))return reply({error:'Choose a saved version from the history list.'},400);
  const revision=await readContentRevision(id);
  return revision?reply(revision):reply({error:'This version is no longer in the recent history. Your current draft is unchanged.'},404);
 }catch(e){console.error('History failed',e);return reply({error:'Version history is temporarily unavailable. Your current edits are safe.'},503);}
}
