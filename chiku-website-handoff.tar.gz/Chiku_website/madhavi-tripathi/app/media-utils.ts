/** Resolve only known video hosts; arbitrary URLs are never placed in an iframe. */
export function videoSource(value:string):{kind:'file'|'embed'|'external';src:string}{
 if(/^\/api\/media\/[a-zA-Z0-9.-]+\.(mp4|webm)$/i.test(value))return{kind:'file',src:value};
 try{const u=new URL(value);if(!['https:','http:'].includes(u.protocol))return{kind:'external',src:''};
  if(/\.(mp4|webm)$/i.test(u.pathname))return{kind:'file',src:value};
  const host=u.hostname.toLowerCase();let id='';
  if(host==='youtu.be')id=u.pathname.slice(1).split('/')[0];
  if(['youtube.com','www.youtube.com','m.youtube.com','youtube-nocookie.com','www.youtube-nocookie.com'].includes(host))id=u.pathname==='/watch'?u.searchParams.get('v')||'':/^\/(embed|shorts)\//.test(u.pathname)?u.pathname.split('/')[2]:'';
  if(/^[A-Za-z0-9_-]{11}$/.test(id))return{kind:'embed',src:`https://www.youtube-nocookie.com/embed/${id}?autoplay=1&rel=0`};
  if(['vimeo.com','www.vimeo.com','player.vimeo.com'].includes(host)){const m=u.pathname.match(/^\/(?:video\/)?(\d+)(?:\/([a-zA-Z0-9]+))?\/?$/);if(m){const h=m[2]||u.searchParams.get('h');return{kind:'embed',src:`https://player.vimeo.com/video/${m[1]}?autoplay=1${h&&/^[a-zA-Z0-9]+$/.test(h)?`&h=${h}`:''}`}}}
  return{kind:'external',src:value};
 }catch{return{kind:'external',src:''}}
}

export function parseByteRange(header:string|null,size:number):{offset:number;length:number}|'invalid'|null{
 if(!header)return null;
 const match=/^bytes=(\d*)-(\d*)$/.exec(header.trim());if(!match||(!match[1]&&!match[2])||!Number.isSafeInteger(size)||size<1)return'invalid';
 let start:number,end:number;
 if(!match[1]){const suffix=Number(match[2]);if(!Number.isSafeInteger(suffix)||suffix<=0)return'invalid';start=Math.max(0,size-suffix);end=size-1}
 else{start=Number(match[1]);end=match[2]?Number(match[2]):size-1;if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start>=size||end<start)return'invalid';end=Math.min(end,size-1)}
 return{offset:start,length:end-start+1};
}
