export const researchTopics=['materials','ultrasound','photoacoustic','general'] as const;
export type ResearchTopic=typeof researchTopics[number];
export const researchTopicLabels:Record<ResearchTopic,string>={
 materials:'Nanomaterials · blue',
 ultrasound:'Ultrasound · violet',
 photoacoustic:'Photoacoustic · teal',
 general:'General research · slate',
};

// Existing published cards acquire a stable identity without changing their text or order.
const originalTopics=new Map<string,ResearchTopic>([
 ['nano-materials','materials'],
 ['ultrasound-imaging','ultrasound'],
 ['photoacoustics','photoacoustic'],
]);
export function researchIdentity(item:{id:string;researchTopic?:ResearchTopic}):ResearchTopic{
 return item.researchTopic??originalTopics.get(item.id)??'general';
}
