import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { sceneOrder, type SceneView } from './scene-content';

type Options={accent:string;view:SceneView;playing:boolean;touring:boolean};
type Callbacks={onView:(view:SceneView)=>void;onPhase:(phase:string)=>void;onProgress:(progress:number)=>void;onLost:()=>void};
export type NanoRenderer={select:(view:SceneView)=>void;playback:(playing:boolean,touring:boolean)=>void;reset:()=>void;dispose:()=>void};
const clamp=(x:number)=>Math.max(0,Math.min(1,x));
const smooth=(x:number)=>{x=clamp(x);return x*x*(3-2*x)};

/** Conceptual explanatory scenes. Geometry, speeds, wavelengths and scales are illustrative. */
export function createNanoRenderer(host:HTMLElement,options:Options,cb:Callbacks):NanoRenderer{
 const renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:'low-power'});
 renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));renderer.setClearColor(0,0);
 renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.3;
 host.appendChild(renderer.domElement);
 const scene=new THREE.Scene(),world=new THREE.Group();scene.add(world);
 const camera=new THREE.PerspectiveCamera(35,1,.1,60);camera.position.set(0,.12,9.6);
 const pmrem=new THREE.PMREMGenerator(renderer),room=new RoomEnvironment(),environment=pmrem.fromScene(room,.05);
 scene.environment=environment.texture;room.dispose();pmrem.dispose();
 const cool=options.accent==='forest'?0x8ff7ce:options.accent==='burgundy'?0xc2b0ff:0x90dcff;
 const violet=0xb8a0ff,gold=0xffc77c;
 scene.add(new THREE.HemisphereLight(0xc8ddff,0x0b1025,2));
 const keyLight=new THREE.PointLight(cool,28,14);keyLight.position.set(3,3,4);scene.add(keyLight);
 const backLight=new THREE.PointLight(violet,24,14);backLight.position.set(-3,-2,1);scene.add(backLight);
 const warmth=new THREE.PointLight(gold,0,7);warmth.position.set(-1,1,2);scene.add(warmth);
 const nano=new THREE.Group();world.add(nano);
 const phi=.67*Math.PI,span=1.38*Math.PI;
 const shellMaterial=new THREE.MeshPhysicalMaterial({color:0xa7bbdf,metalness:.48,roughness:.19,clearcoat:1,iridescence:.8,iridescenceIOR:1.3,transparent:true,opacity:.36,side:THREE.DoubleSide,depthWrite:false,envMapIntensity:2.1});
 const shell=new THREE.Mesh(new THREE.SphereGeometry(1.55,80,56,phi,span),shellMaterial);nano.add(shell);
 const gelMaterial=new THREE.MeshPhysicalMaterial({color:violet,metalness:.1,roughness:.32,transparent:true,opacity:.12,side:THREE.DoubleSide,depthWrite:false,clearcoat:.8});
 const gel=new THREE.Mesh(new THREE.SphereGeometry(1.39,56,40,phi,span),gelMaterial);nano.add(gel);
 const networkMaterial=new THREE.MeshBasicMaterial({color:0x9baafa,wireframe:true,transparent:true,opacity:.13,depthWrite:false});
 const network=new THREE.Mesh(new THREE.IcosahedronGeometry(1.36,3),networkMaterial);nano.add(network);
 const edgeMaterial=new THREE.LineBasicMaterial({color:0xc8dfff,transparent:true,opacity:.7});
 for(const a of [phi,phi+span]){const points=[];for(let i=0;i<=80;i++){const t=i/80*Math.PI;points.push(new THREE.Vector3(-1.552*Math.cos(a)*Math.sin(t),1.552*Math.cos(t),1.552*Math.sin(a)*Math.sin(t)))}nano.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(points),edgeMaterial))}
 // Drug payload and CuS are schematic particles, not molecular structures.
 const drugMaterial=new THREE.MeshStandardMaterial({color:gold,metalness:.55,roughness:.24,emissive:0xb96318,emissiveIntensity:.35,transparent:true});
 const cusMaterial=new THREE.MeshPhysicalMaterial({color:cool,metalness:.8,roughness:.16,emissive:0x186ba3,emissiveIntensity:.35,clearcoat:1,transparent:true});
 const drug=new THREE.InstancedMesh(new THREE.SphereGeometry(.077,16,12),drugMaterial,42);
 const cus=new THREE.InstancedMesh(new THREE.IcosahedronGeometry(.115,1),cusMaterial,20);nano.add(drug,cus);
 let seed=126;const random=()=>{seed=seed*16807%2147483647;return(seed-1)/2147483646};
 const bases=(count:number)=>Array.from({length:count},(_,i)=>{const y=1-2*(i+.5)/count,a=i*2.39996,r=.35+random()*.8;return new THREE.Vector3(Math.cos(a)*Math.sqrt(1-y*y)*r,y*r,Math.sin(a)*Math.sqrt(1-y*y)*r)});
 const drugBase=bases(42),cusBase=bases(20);const dummy=new THREE.Object3D(),normal=new THREE.Vector3();
 // The transducer in the photoacoustic view receives generated acoustic signals.
 const makeProbe=(x:number)=>{
  const group=new THREE.Group();group.position.x=x;
  const bodyMaterial=new THREE.MeshPhysicalMaterial({color:0xa4b4d5,metalness:.9,roughness:.19,clearcoat:1,transparent:true});
  const faceMaterial=new THREE.MeshStandardMaterial({color:cool,metalness:.55,roughness:.23,emissive:cool,emissiveIntensity:.25,transparent:true});
  const body=new THREE.Mesh(new THREE.BoxGeometry(.25,1.98,.55),bodyMaterial);group.add(body);
  const elements=new THREE.InstancedMesh(new THREE.BoxGeometry(.075,.071,.48),faceMaterial,20);
  for(let i=0;i<20;i++){dummy.position.set(x<0?.155:-.155,-.9+i*.095,0);dummy.rotation.set(0,0,0);dummy.scale.setScalar(1);dummy.updateMatrix();elements.setMatrixAt(i,dummy.matrix)}group.add(elements);world.add(group);
  return{group,bodyMaterial,faceMaterial};
 };
 const receiver=makeProbe(2.24),probe=makeProbe(-2.3);
 const optical=new THREE.Group();world.add(optical);
 const beamMaterial=new THREE.LineBasicMaterial({color:gold,transparent:true,opacity:0,blending:THREE.AdditiveBlending,depthWrite:false});
 const beamPoints:THREE.Vector3[]=[];
 for(let i=0;i<5;i++){const z=(i-2)*.085;beamPoints.push(new THREE.Vector3(-2.85,1.45+i*.03,z),new THREE.Vector3(-.1,.12,z))}
 optical.add(new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(beamPoints),beamMaterial));
 const pulseGeometry=new THREE.TorusGeometry(1,.009,5,90);
 const acoustic=Array.from({length:6},(_,i)=>{const material=new THREE.MeshBasicMaterial({color:cool,transparent:true,opacity:0,depthWrite:false,blending:THREE.AdditiveBlending});const mesh=new THREE.Mesh(pulseGeometry,material);mesh.rotation.y=i%2?.42:0;world.add(mesh);return{mesh,material}});
 // Tissue-scale ultrasound view: transmitted wavefronts and returning echoes.
 const tissue=new THREE.Group();tissue.position.x=.7;world.add(tissue);
 const tissuePositions=new Float32Array(950*3),tissueColors=new Float32Array(950*3);
 for(let i=0;i<950;i++){const x=(random()-.5)*2.1,y=(random()-.5)*2.7,z=(random()-.5)*1.05;
  const lowScatter=(x+.12)**2+(y-.52)**2+z*z<.34;
  tissuePositions.set([x,y,z],i*3);const intensity=lowScatter?.13:.4+random()*.6;tissueColors.set([.37*intensity,.66*intensity,intensity],i*3)}
 const tissueGeometry=new THREE.BufferGeometry();tissueGeometry.setAttribute('position',new THREE.BufferAttribute(tissuePositions,3));tissueGeometry.setAttribute('color',new THREE.BufferAttribute(tissueColors,3));
 const tissueMaterial=new THREE.PointsMaterial({vertexColors:true,size:.037,transparent:true,opacity:0,depthWrite:false,sizeAttenuation:true});tissue.add(new THREE.Points(tissueGeometry,tissueMaterial));
 const boundaryMaterial=new THREE.LineBasicMaterial({color:0x6b94c7,transparent:true,opacity:0});
 const boxGeometry=new THREE.BoxGeometry(2.15,2.75,1.1);const edges=new THREE.EdgesGeometry(boxGeometry);boxGeometry.dispose();tissue.add(new THREE.LineSegments(edges,boundaryMaterial));
 const wavefronts=Array.from({length:7},(_,i)=>{const material=new THREE.MeshBasicMaterial({color:i<4?cool:violet,transparent:true,opacity:0,depthWrite:false,blending:THREE.AdditiveBlending});const mesh=new THREE.Mesh(pulseGeometry,material);mesh.rotation.y=Math.PI/2;world.add(mesh);return{mesh,material}});
 const dustGeometry=new THREE.BufferGeometry();const dustPositions=new Float32Array(110*3);
 for(let i=0;i<110;i++)dustPositions.set([(random()-.5)*8,(random()-.5)*6,(random()-.5)*4-2],i*3);
 dustGeometry.setAttribute('position',new THREE.BufferAttribute(dustPositions,3));const dust=new THREE.Points(dustGeometry,new THREE.PointsMaterial({color:0x7e9ec5,size:.013,transparent:true,opacity:.42,depthWrite:false}));scene.add(dust);
 let mode=options.view,playing=options.playing,touring=options.touring,age=options.playing?0:options.view==='delivery'?1.5:2.8,clock=0,last=0,frame=0,disposed=false,visible=true,lost=false,phase='',nanoFade=mode==='ultrasound'?0:1,usFade=mode==='ultrasound'?1:0,paFade=mode==='photoacoustic'?1:0;
 let drag=false,dragX=0,dragY=0,turnX=0,turnY=0;const pointer={x:0,y:0},easePointer={x:0,y:0};
 const shouldRun=()=>playing&&visible&&!document.hidden&&!lost;
 const phaseUpdate=(value:string)=>{if(value!==phase){phase=value;cb.onPhase(value)}};
 function draw(now:number,once=false){
  if(disposed||lost)return;const dt=last?Math.min((now-last)/1000,.06):0;last=now;
  if(shouldRun()){age+=dt;clock+=dt;if(touring&&age>(mode==='delivery'?15:12)){mode=sceneOrder[(sceneOrder.indexOf(mode)+1)%3];age=0;turnX=turnY=0;cb.onView(mode)}}
  const blend=once?1:1-Math.exp(-dt*5.5);nanoFade+=(Number(mode!=='ultrasound')-nanoFade)*blend;usFade+=(Number(mode==='ultrasound')-usFade)*blend;paFade+=(Number(mode==='photoacoustic')-paFade)*blend;
  easePointer.x+=(pointer.x-easePointer.x)*.06;easePointer.y+=(pointer.y-easePointer.y)*.06;
  world.rotation.set(turnX+easePointer.y*.08,turnY+easePointer.x*.12,0);
  nano.rotation.set(.05+Math.sin(clock*.13)*.055,-.18+Math.sin(clock*.16)*.12,-.12);nano.position.set(mode==='photoacoustic'?-.3:0,.06+Math.sin(clock*.55)*.035,0);
  nano.scale.setScalar(1-paFade*.23);nano.visible=nanoFade>.002;
  const cycle=age%15,heat=mode==='delivery'?smooth((cycle-3.2)/2.2)*(1-smooth((cycle-12.2)/2.1)):0;
  const release=mode==='delivery'?smooth((cycle-5.8)/5)*(1-smooth((cycle-12.1)/2.5)):0;
  warmth.intensity=heat*11;shellMaterial.opacity=(.36-release*.2)*nanoFade;gelMaterial.opacity=.13*(1-release*.7)*nanoFade;networkMaterial.opacity=.15*(1-release*.85)*nanoFade;edgeMaterial.opacity=.66*(1-release*.5)*nanoFade;
  drugMaterial.opacity=nanoFade;cusMaterial.opacity=nanoFade;
  const updateParticles=(mesh:THREE.InstancedMesh,positions:THREE.Vector3[],amount:number)=>{positions.forEach((p,i)=>{const spread=smooth((release-i*.006)/.8)*amount;normal.copy(p).normalize();dummy.position.copy(p).addScaledVector(normal,spread);dummy.position.y+=Math.sin(clock*.7+i)*.025;dummy.rotation.set(i*.8+clock*.035,i*.42,0);dummy.scale.setScalar(1);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix)});mesh.instanceMatrix.needsUpdate=true};
  updateParticles(drug,drugBase,1.2);updateParticles(cus,cusBase,.78);
  const photoPhase=age%5.5;beamMaterial.opacity=paFade*(photoPhase<1.05?Math.sin(photoPhase/1.05*Math.PI)*.95:0);
  cusMaterial.emissiveIntensity=.25+paFade*Math.max(0,1-photoPhase/2)*1.8;
  acoustic.forEach(({mesh,material},i)=>{const p=(photoPhase-1.05-i*.19)/2.75;mesh.visible=p>0&&p<1&&paFade>.002;mesh.position.set(-.3,.08,0);mesh.scale.setScalar(.55+Math.max(0,p)*2.3);material.opacity=paFade*(1-clamp(p))*.48;mesh.rotation.x=i%2?.25:-.2});
  receiver.group.visible=paFade>.002;receiver.bodyMaterial.opacity=paFade*.9;receiver.faceMaterial.opacity=paFade;
  probe.group.visible=usFade>.002;probe.bodyMaterial.opacity=usFade*.95;probe.faceMaterial.opacity=usFade;
  tissue.visible=usFade>.002;tissueMaterial.opacity=usFade*.85;boundaryMaterial.opacity=usFade*.16;
  const usPhase=age%6;
  wavefronts.forEach(({mesh,material},i)=>{const transmit=i<4;const p=transmit?(usPhase-i*.18)/2.35:(usPhase-2.45-(i-4)*.22)/2.7;mesh.visible=p>=0&&p<=1&&usFade>.002;
   mesh.position.set(transmit?-2+clamp(p)*3.9:1.55-clamp(p)*3.55,0,0);mesh.scale.setScalar(transmit?.5+clamp(p)*.68:.42+clamp(p)*.72);material.opacity=usFade*Math.sin(clamp(p)*Math.PI)*.75});
  if(mode==='delivery')phaseUpdate(cycle<3.5?'Payload encapsulated':cycle<6.5?'Thermal response':cycle<12.5?'Payload release':'Carrier concept');
  if(mode==='photoacoustic')phaseUpdate(photoPhase<1.1?'Light absorbed':photoPhase<3.6?'Acoustic signal generated':'Signal received');
  if(mode==='ultrasound')phaseUpdate(usPhase<2.4?'Sound transmitted':usPhase<3?'Tissue scatters sound':'Echoes received');
  cb.onProgress(touring?clamp(age/(mode==='delivery'?15:12)):0);dust.rotation.y=clock*.006;
  renderer.render(scene,camera);if(!once&&shouldRun())frame=requestAnimationFrame(draw);
 }
 const restart=()=>{cancelAnimationFrame(frame);last=0;if(!disposed&&!lost&&visible&&!document.hidden)frame=requestAnimationFrame(t=>draw(t,!playing))};
 const size=()=>{const w=host.clientWidth,h=host.clientHeight;if(!w||!h)return;renderer.setSize(w,h);camera.aspect=w/h;camera.position.z=camera.aspect<.95?9.8:8.6;camera.updateProjectionMatrix();draw(performance.now(),true)};
 const move=(e:PointerEvent)=>{const box=host.getBoundingClientRect();pointer.x=(e.clientX-box.left)/box.width*2-1;pointer.y=(e.clientY-box.top)/box.height*2-1;if(drag){turnY+=(e.clientX-dragX)*.007;turnX=Math.max(-.9,Math.min(.9,turnX+(e.clientY-dragY)*.006));dragX=e.clientX;dragY=e.clientY}if(!playing)draw(performance.now(),true)};
 const down=(e:PointerEvent)=>{if(e.button!==0)return;drag=true;dragX=e.clientX;dragY=e.clientY;host.setPointerCapture(e.pointerId)};
 const up=()=>{drag=false};const leave=()=>{pointer.x=pointer.y=0};
 const key=(e:KeyboardEvent)=>{if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key))return;e.preventDefault();turnY+=e.key==='ArrowLeft'?-.15:e.key==='ArrowRight'?.15:0;turnX+=e.key==='ArrowUp'?-.12:e.key==='ArrowDown'?.12:0;draw(performance.now(),true)};
 host.addEventListener('pointermove',move);host.addEventListener('pointerdown',down);host.addEventListener('pointerup',up);host.addEventListener('pointercancel',up);host.addEventListener('pointerleave',leave);host.addEventListener('keydown',key);
 const resize=new ResizeObserver(size);resize.observe(host);const observer=new IntersectionObserver(([entry])=>{visible=entry.isIntersecting;restart()},{threshold:.06});observer.observe(host);
 document.addEventListener('visibilitychange',restart);
 const contextLost=(e:Event)=>{e.preventDefault();lost=true;cancelAnimationFrame(frame);cb.onLost()};renderer.domElement.addEventListener('webglcontextlost',contextLost);
 size();restart();
 return{
  select:view=>{mode=view;age=playing?0:view==='delivery'?1.5:2.8;turnX=turnY=0;cb.onView(view);if(!playing)draw(performance.now(),true);restart()},
  playback:(isPlaying,isTouring)=>{playing=isPlaying;touring=isTouring;restart()},
  reset:()=>{turnX=turnY=0;pointer.x=pointer.y=0;age=0;draw(performance.now(),true);restart()},
  dispose:()=>{disposed=true;cancelAnimationFrame(frame);resize.disconnect();observer.disconnect();document.removeEventListener('visibilitychange',restart);host.removeEventListener('pointermove',move);host.removeEventListener('pointerdown',down);host.removeEventListener('pointerup',up);host.removeEventListener('pointercancel',up);host.removeEventListener('pointerleave',leave);host.removeEventListener('keydown',key);renderer.domElement.removeEventListener('webglcontextlost',contextLost);
   const geometries=new Set<THREE.BufferGeometry>(),materials=new Set<THREE.Material>();scene.traverse(object=>{if(object instanceof THREE.Mesh||object instanceof THREE.Points||object instanceof THREE.Line){geometries.add(object.geometry);(Array.isArray(object.material)?object.material:[object.material]).forEach(m=>materials.add(m));if(object instanceof THREE.InstancedMesh)object.dispose()}});geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());environment.dispose();renderer.dispose();renderer.domElement.remove();
  }
 };
}
