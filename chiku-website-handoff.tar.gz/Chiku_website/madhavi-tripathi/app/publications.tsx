'use client';
import { useEffect,useMemo,useRef,useState } from 'react';
import { ArrowDown,ArrowUpRight,BookOpen,Check,ChevronDown,ChevronUp,Link2,Search,X } from 'lucide-react';
import { Select,SelectContent,SelectItem,SelectTrigger,SelectValue } from '@/components/ui/select';
import { Collapsible,CollapsibleContent,CollapsibleTrigger } from '@/components/ui/collapsible';
import type { Item } from './content';
import type { SectionCopy } from './site-copy';
import { defaultPublicationFilters,publicationAnchor,publicationCitations,publicationFilterEvent,publicationFilterUrl,publicationPaperUrl,publicationYear,readPublicationFilters,selectPublications,type PublicationFilters,type PublicationSort } from './publication-utils';

const emptyResearch:Item[]=[];
const sortOptions:[PublicationSort,string][]=[['newest','Newest first'],['oldest','Oldest first'],['citations','Most cited'],['title','Title A–Z']];
function PaperRow({paper,scholar,showCitations}:{paper:Item;scholar:string;showCitations:boolean}){
 const [open,setOpen]=useState(false),[copied,setCopied]=useState(false),[fallbackLink,setFallbackLink]=useState(''),count=publicationCitations(paper);
 const summary=paper.contribution||paper.description;
 const background=paper.contribution&&paper.description!==paper.contribution?paper.description:'';
 const hasDetails=!!(background||paper.approach||paper.outcome||paper.code||paper.dataset||paper.video);
 useEffect(()=>{if(!copied)return;const timer=setTimeout(()=>setCopied(false),2500);return()=>clearTimeout(timer)},[copied]);
 async function copyLink(){const url=publicationPaperUrl(window.location.href,paper.id).href;try{await navigator.clipboard.writeText(url);setCopied(true);setFallbackLink('')}catch{setFallbackLink(url)}}
 return <Collapsible open={open} onOpenChange={setOpen} asChild><article id={publicationAnchor(paper.id)} tabIndex={-1} className={`publication-row ${showCitations?'':'without-citations'}`} aria-labelledby={`${publicationAnchor(paper.id)}-title`}>
  <span className="publication-year">{paper.year||'Undated'}</span>
  <div className="publication-main"><h3 id={`${publicationAnchor(paper.id)}-title`}>{paper.link?<a href={paper.link} target="_blank" rel="noopener noreferrer">{paper.title}</a>:paper.title}</h3><p className="publication-authors">{paper.subtitle}</p>
   {summary&&<p className="publication-contribution">{summary}</p>}
   <div className="publication-actions">{paper.link&&<a href={paper.link} target="_blank" rel="noopener noreferrer">Read paper<ArrowUpRight size={14}/></a>}{hasDetails&&<CollapsibleTrigger className="publication-details-trigger" aria-label={`${open?'Less':'Details'} for ${paper.title}`}>{open?'Less':'Details'}<ChevronDown size={15}/></CollapsibleTrigger>}<button type="button" className="publication-copy" onClick={copyLink} aria-label={`${copied?'Copied':'Copy link'} to ${paper.title}`}>{copied?<Check size={14}/>:<Link2 size={14}/>}<span>{copied?'Copied':'Copy link'}</span></button><span className="sr-only" role="status">{copied?'Publication link copied.':''}</span></div>
   {fallbackLink&&<label className="publication-link-fallback">Select and copy this publication link<input readOnly value={fallbackLink} onFocus={e=>e.currentTarget.select()} aria-label={`Link to ${paper.title}`}/></label>}
   {hasDetails&&<CollapsibleContent className="publication-details">{background&&<p>{background}</p>}{paper.approach&&<div className="publication-detail-copy"><h4>Approach</h4><p>{paper.approach}</p></div>}{paper.outcome&&<div className="publication-detail-copy"><h4>Findings</h4><p>{paper.outcome}</p></div>}<div className="publication-resources">{([['code','Code'],['dataset','Dataset'],['video','Video']] as const).map(([key,label])=>paper[key]&&<a key={key} href={paper[key]} target="_blank" rel="noopener noreferrer">{label}<ArrowUpRight size={14}/></a>)}</div></CollapsibleContent>}
  </div>
  {showCitations&&<div className={`publication-citations ${count===null?'citation-unavailable':''}`}>{count===null?<><span aria-hidden="true">—</span><span className="sr-only">Citation count unavailable for {paper.title}</span></>:<><strong>{count.toLocaleString('en-US')}</strong><span>{count===1?'citation':'citations'}</span><small>{paper.citationsAsOf?`As of ${paper.citationsAsOf}`:'Saved snapshot'}</small>{scholar&&<a href={scholar} target="_blank" rel="noopener noreferrer">Google Scholar<ArrowUpRight size={12}/></a>}</>}</div>}
 </article></Collapsible>;
}

export function Publications({papers,scholar,research=emptyResearch,copy,canEdit=false}:{papers:Item[];scholar:string;research?:Item[];copy?:SectionCopy;canEdit?:boolean}){
 const [filters,setFilters]=useState<PublicationFilters>(defaultPublicationFilters),[expanded,setExpanded]=useState(false),[pendingAnchor,setPendingAnchor]=useState('');
 const {query,year,sort,topic}=filters;
 const viewport=useRef<HTMLDivElement>(null),[canScroll,setCanScroll]=useState(false),[atEnd,setAtEnd]=useState(false);
 const years=useMemo(()=>[...new Set(papers.map(publicationYear).filter((y):y is number=>y!==null))].sort((a,b)=>b-a),[papers]);
 const undated=papers.some(p=>publicationYear(p)===null),filtered=useMemo(()=>selectPublications(papers,query,year,sort,topic),[papers,query,year,sort,topic]);
 const known=filtered.filter(p=>publicationCitations(p)!==null).length,allKnown=papers.filter(p=>publicationCitations(p)!==null).length;
 const hasFilters=query.trim()!==''||year!=='all'||topic!=='all';
 const topicTitle=research.find(item=>item.id===topic)?.title;
 function update(next:Partial<PublicationFilters>){const value={...filters,...next};setFilters(value);const url=publicationFilterUrl(window.location.href,value);if(url.hash.startsWith('#paper-'))url.hash='publications';window.history.replaceState(window.history.state,'',url)}
 useEffect(()=>{
  function restore(){
   const next=readPublicationFilters(new URLSearchParams(window.location.search));
   if(next.year==='undated'&&!papers.some(item=>publicationYear(item)===null))next.year='all';
   if(next.year!=='all'&&next.year!=='undated'&&!years.includes(Number(next.year)))next.year='all';
   if(next.topic!=='all'&&!research.some(item=>item.id===next.topic))next.topic='all';
   const anchor=window.location.hash.slice(1),paper=papers.find(item=>publicationAnchor(item.id)===anchor);
   if(paper){setFilters(defaultPublicationFilters);setExpanded(true);setPendingAnchor(anchor)}else setFilters(next);
  }
  function chooseTopic(event:Event){const id=(event as CustomEvent<{topic?:string}>).detail?.topic;if(!id||!research.some(item=>item.id===id))return;const next={...defaultPublicationFilters,topic:id};setFilters(next);const url=publicationFilterUrl(window.location.href,next);url.hash='publications';window.history.replaceState(window.history.state,'',url);document.getElementById('publications')?.scrollIntoView({block:'start'});viewport.current?.focus({preventScroll:true})}
  restore();window.addEventListener('popstate',restore);window.addEventListener('hashchange',restore);window.addEventListener(publicationFilterEvent,chooseTopic);
  return()=>{window.removeEventListener('popstate',restore);window.removeEventListener('hashchange',restore);window.removeEventListener(publicationFilterEvent,chooseTopic)};
 },[papers,research,years]);
 useEffect(()=>{if(!pendingAnchor)return;const frame=requestAnimationFrame(()=>{const node=document.getElementById(pendingAnchor);if(node){node.scrollIntoView({block:'start'});node.focus({preventScroll:true})}setPendingAnchor('')});return()=>cancelAnimationFrame(frame)},[pendingAnchor,expanded,filtered]);
 useEffect(()=>{const node=viewport.current;if(node)node.scrollTop=0},[query,year,sort,topic]);
 useEffect(()=>{const node=viewport.current;if(!node)return;const measure=()=>{setCanScroll(!expanded&&node.scrollHeight>node.clientHeight+2);setAtEnd(node.scrollTop+node.clientHeight>=node.scrollHeight-3)};measure();const resize=new ResizeObserver(measure);resize.observe(node);if(node.firstElementChild)resize.observe(node.firstElementChild);node.addEventListener('scroll',measure,{passive:true});return()=>{resize.disconnect();node.removeEventListener('scroll',measure)}},[filtered,expanded]);
 function reset(){update(defaultPublicationFilters)}
 return <section id="publications" className="publications-section publication-browser section" aria-labelledby="publications-title"><div className="wrap">
  <div className="section-heading reveal"><div><p className="section-kicker"><span>02</span>RESEARCH PUBLICATIONS</p><h2 id="publications-title">{copy?.title||<>Selected <span>publications.</span></>}</h2>{copy?.description&&<p className="publication-intro">{copy.description}</p>}</div>{scholar&&<a className="quiet-link" href={scholar} target="_blank" rel="noopener noreferrer">Full record on Scholar<ArrowUpRight size={17}/></a>}</div>
  <div className={`publication-panel ${expanded?'publication-panel-expanded':''}`}>
   <div className={`publication-toolbar ${research.length?'has-topic-filter':''}`}>
    <label className="publication-search"><span className="sr-only">Search publications by title, author, or topic</span><Search size={17}/><input value={query} maxLength={1000} onChange={e=>update({query:e.target.value})} placeholder="Search title, author, or topic…" type="search"/></label>
    {research.length>0&&<div className="publication-filter publication-topic-filter"><span id="publication-topic-label">Topic</span><Select value={topic} onValueChange={v=>update({topic:v})}><SelectTrigger aria-labelledby="publication-topic-label" className="publication-select"><SelectValue/></SelectTrigger><SelectContent className="publication-select-menu" position="popper"><SelectItem value="all">All topics</SelectItem>{research.map(item=><SelectItem key={item.id} value={item.id}>{item.title}</SelectItem>)}</SelectContent></Select></div>}
    <div className="publication-filter"><span id="publication-year-label">Year</span><Select value={year} onValueChange={v=>update({year:v})}><SelectTrigger aria-labelledby="publication-year-label" className="publication-select"><SelectValue/></SelectTrigger><SelectContent className="publication-select-menu" position="popper"><SelectItem value="all">All years</SelectItem>{years.map(y=><SelectItem key={y} value={String(y)}>{y}</SelectItem>)}{undated&&<SelectItem value="undated">Undated</SelectItem>}</SelectContent></Select></div>
    <div className="publication-filter"><span id="publication-sort-label">Sort by</span><Select value={sort} onValueChange={v=>update({sort:v as PublicationSort})}><SelectTrigger aria-labelledby="publication-sort-label" aria-describedby="publication-count-coverage" className="publication-select"><SelectValue/></SelectTrigger><SelectContent className="publication-select-menu" position="popper">{sortOptions.map(([key,label])=><SelectItem key={key} value={key}>{label}{key==='citations'&&allKnown===0?' · counts unavailable':''}</SelectItem>)}</SelectContent></Select></div>
   </div>
   <div className="publication-result-bar"><p aria-live="polite" aria-atomic="true"><strong>{filtered.length}</strong> of {papers.length} selected {papers.length===1?'paper':'papers'}{year!=='all'?` · ${year==='undated'?'Undated':year}`:''}{topicTitle?` · ${topicTitle}`:''}</p><div className="publication-list-controls">{(hasFilters||sort!=='newest')&&<button type="button" onClick={reset}>Reset<X size={14}/></button>}{papers.length>0&&<button type="button" className="publication-expand" onClick={()=>setExpanded(value=>!value)} aria-controls="publication-list-viewport" aria-expanded={expanded}>{expanded?'Compact list':'Expand list'}{expanded?<ChevronUp size={15}/>:<ChevronDown size={15}/>}</button>}</div></div>
   <p id="publication-count-coverage" className={`publication-count-coverage ${sort==='citations'?'is-active':''}`} role="status">{sort==='citations'?(known===0?'No saved citation counts for this selection. Showing newest first.':`${known} of ${filtered.length} papers have saved citation counts. Unavailable counts appear last.`):`${allKnown} of ${papers.length} papers have saved citation counts.`}{sort==='citations'&&scholar&&<> <a href={scholar} target="_blank" rel="noopener noreferrer">Check Google Scholar<ArrowUpRight size={13}/></a></>}</p>
   <div id="publication-list-viewport" className="publication-viewport" ref={viewport} tabIndex={0} role="region" aria-label={expanded?'Selected publications':'Scrollable selected publications'} aria-describedby="publication-scroll-help"><div className="publication-list">{filtered.length?filtered.map(paper=><PaperRow key={paper.id} paper={paper} scholar={scholar} showCitations={known>0}/>):<div className="publication-no-results"><BookOpen size={30}/><h3>{papers.length?'No matching publications':'Publications coming soon'}</h3><p>{papers.length?'Try another keyword, year, or research topic.':'Selected research will appear here.'}</p>{hasFilters&&<button type="button" onClick={reset}>Clear filters</button>}</div>}</div></div>
   <div className="publication-panel-footer"><span id="publication-scroll-help">{canScroll?<><ArrowDown size={14}/>{atEnd?'End of this selection':'Scroll to explore, or expand the list'}</>:filtered.length?'All matching papers are shown':papers.length?'Try adjusting the filters':'No publications added yet'}</span>{filtered.length>0&&<span>{known===0?'Paper-level citation counts have not been added.':known<filtered.length?'Saved Scholar counts · — means unavailable.':'Citation counts are saved Google Scholar snapshots.'}</span>}</div>
  </div>
  <div className="publication-foot"><span>Filter by topic or year. Copy a paper’s link to share it.</span>{canEdit&&<a href="/edit?tab=publications">Manage papers & citation counts<ArrowUpRight size={15}/></a>}</div>
 </div></section>;
}
