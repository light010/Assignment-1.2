'use client';
import { useEffect, useRef, useState } from 'react';
import { Pause, Play, RotateCcw, ArrowUpRight, Atom, AudioLines, ScanLine, ChevronDown, BookOpen } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { initialScene, sceneOrder, type SceneSettings, type SceneView } from './scene-content';
import { shouldLoadResearchScene, type ScenePreferences } from './scene-performance';
import type { NanoRenderer } from './nano-renderer';

const labels = {delivery:'Drug delivery', photoacoustic:'Photoacoustic', ultrasound:'Ultrasound'};
const icons = {delivery:Atom, photoacoustic:ScanLine, ultrasound:AudioLines};
const legends = {
 delivery:[['coat','Responsive carrier'],['gold','Drug payload'],['cyan','CuS nanoparticles']],
 photoacoustic:[['gold','Light excitation'],['cyan','Acoustic signal'],['coat','Receiver']],
 ultrasound:[['cyan','Transmitted sound'],['purple','Returning echoes'],['coat','Tissue scatterers']],
};
const steps: Record<SceneView, {title:string; description:string}[]> = {
 delivery:[
  {title:'Payload encapsulated', description:'The carrier holds a drug payload and CuS nanoparticles.'},
  {title:'Thermal response', description:'The thermoresponsive carrier responds to a change in temperature.'},
  {title:'Payload released', description:'Release is illustrated as the drug leaving the carrier.'},
 ],
 photoacoustic:[
  {title:'Light absorbed', description:'A light-absorbing material receives optical excitation.'},
  {title:'Acoustic wave generated', description:'Absorbed light gives rise to an acoustic signal.'},
  {title:'Signal received', description:'A receiver detects the acoustic signal for imaging.'},
 ],
 ultrasound:[
  {title:'Sound transmitted', description:'The probe sends an ultrasound pulse into tissue.'},
  {title:'Sound scattered', description:'Structures in the tissue scatter the sound.'},
  {title:'Echoes received', description:'Returning echoes are recorded by the probe.'},
 ],
};
type DataConnection = EventTarget & {saveData?:boolean};
type NavigatorWithConnection = Navigator & {connection?:DataConnection};

function SceneSteps({view, compact=false}:{view:SceneView; compact?:boolean}) {
 return <ol className={`nano-guide-steps ${compact?'nano-guide-steps-compact':''}`} aria-label={`${labels[view]} conceptual sequence`}>
  {steps[view].map((step,index)=><li key={step.title}><span aria-hidden="true">0{index+1}</span><div><strong>{step.title}</strong><p>{step.description}</p></div></li>)}
 </ol>;
}

export function ResearchScene({motion=true,accent='blue',settings=initialScene}:{motion?:boolean;accent?:string;settings?:SceneSettings}) {
 const mount = useRef<HTMLDivElement>(null), progress = useRef<HTMLDivElement>(null), api = useRef<NanoRenderer|null>(null);
 const focusAfterLoad = useRef(false);
 const [view,setView] = useState<SceneView>(settings.initialView);
 const [paused,setPaused] = useState(!motion), [touring,setTouring] = useState(false);
 const [preferences,setPreferences] = useState<ScenePreferences>({known:false,reducedMotion:false,saveData:false});
 const [requested,setRequested] = useState(false), [attempt,setAttempt] = useState(0);
 const [ready,setReady] = useState(false), [failed,setFailed] = useState(false), [guideOpen,setGuideOpen] = useState(false);
 const [phase,setPhase] = useState('Payload encapsulated');
 const reduced = preferences.reducedMotion;
 const mayLoad = shouldLoadResearchScene(motion,preferences,requested);
 const live = useRef({view,paused,touring,motion,reduced});
 live.current = {view,paused,touring,motion,reduced};

 useEffect(()=>{
  const query = window.matchMedia('(prefers-reduced-motion: reduce)');
  const connection = (navigator as NavigatorWithConnection).connection;
  const update = ()=>setPreferences({known:true,reducedMotion:query.matches,saveData:connection?.saveData===true});
  update();
  query.addEventListener('change',update);
  connection?.addEventListener('change',update);
  return ()=>{query.removeEventListener('change',update);connection?.removeEventListener('change',update)};
 },[]);
 useEffect(()=>{if(!motion||reduced){setPaused(true);setTouring(false)}},[motion,reduced]);
 useEffect(()=>{api.current?.playback(motion&&!paused&&!reduced,touring)},[motion,paused,reduced,touring]);
 useEffect(()=>{if(!settings.offerTour||!mayLoad)setTouring(false)},[settings.offerTour,mayLoad]);
 useEffect(()=>{setView(settings.initialView);api.current?.select(settings.initialView)},[settings.initialView]);
 useEffect(()=>{
  if(!ready||!focusAfterLoad.current)return;
  focusAfterLoad.current=false;
  // A removed load button returns focus to the document. Restore it to the
  // illustration, unless the visitor has already moved to another control.
  if(document.activeElement===document.body)mount.current?.focus({preventScroll:true});
 },[ready]);
 useEffect(()=>{
  const host = mount.current;
  if(!host)return;
  let disposed = false, engine:NanoRenderer|null = null;
  setReady(false);setFailed(false);
  if(!mayLoad)return;
  (async()=>{
   try{
    const {createNanoRenderer} = await import('./nano-renderer');
    if(disposed)return;
    const current = live.current;
    // Recheck a preference that could change while the bundle is downloading.
    if(!current.motion||current.reduced||window.matchMedia('(prefers-reduced-motion: reduce)').matches)return;
    engine = createNanoRenderer(host,{
     accent,view:current.view,playing:!current.paused,touring:current.touring,
    },{
     onView:setView,onPhase:setPhase,
     onProgress:p=>{progress.current?.style.setProperty('--tour-progress',`${p*100}%`)},
     onLost:()=>{if(!disposed){setFailed(true);setReady(false);setTouring(false)}},
    });
    api.current = engine;setReady(true);
   }catch(error){
    console.warn('Research visualization unavailable',error);
    if(!disposed){setFailed(true);setTouring(false)}
   }
  })();
  return ()=>{disposed=true;engine?.dispose();api.current=null};
 },[accent,mayLoad,attempt]);

 function choose(value:string){const next=value as SceneView;setTouring(false);setView(next);api.current?.select(next)}
 function toggleTour(){if(!touring){api.current?.select(view);setPaused(false)}setTouring(v=>!v)}
 const canAnimate = motion&&!reduced;
 const waitingForOptIn = preferences.known&&motion&&!reduced&&preferences.saveData&&!requested;
 const fallbackNote = failed?'The 3D illustration is unavailable. Explore the sequence and research below.':
  !motion?'Explore the research through this static sequence.':
  reduced?'A static sequence respects your reduced-motion preference.':
  waitingForOptIn?'Data saving is on. You can load the interactive 3D illustration.':
  'Explore the sequence while the 3D illustration prepares.';

 return <Tabs value={view} onValueChange={choose} onFocusCapture={e=>{if(!(e.target as HTMLElement).closest('.tour-toggle'))setTouring(false)}} className={`research-scene nano-experience ${ready?'scene-ready':''} ${failed?'scene-failed':''}`}>
  <div className="nano-heading"><span>{ready?'THE RESEARCH, IN MOTION':'EXPLORE THE RESEARCH'}</span><span>0{sceneOrder.indexOf(view)+1} / 03</span></div>
  <TabsList className="nano-tabs" aria-label="Explore research topics">{sceneOrder.map(key=>{const Icon=icons[key];return <TabsTrigger key={key} value={key}><Icon size={15}/><span>{key==='photoacoustic'?<>Photo<wbr/>acoustic</>:labels[key]}</span></TabsTrigger>})}</TabsList>
  <div className={`nano-stage view-${view} ${ready?'':'nano-stage-static'}`}>
   <div ref={mount} className="scene-canvas" tabIndex={ready?0:-1} role={ready?'img':undefined} aria-hidden={!ready} aria-label={ready?`${labels[view]} conceptual 3D illustration. Drag or use arrow keys to rotate.`:undefined}/>
   {!ready&&<div className="nano-static-sequence">
    <p className="nano-static-label">{labels[view]} · three conceptual stages</p>
    <SceneSteps view={view} compact/>
    <p className="nano-static-note" role="status">{fallbackNote}</p>
    {waitingForOptIn&&<button className="nano-load" onClick={()=>{focusAfterLoad.current=true;setRequested(true)}}><Play size={15}/>Load 3D illustration</button>}
    {failed&&mayLoad&&<button className="nano-load" onClick={()=>{focusAfterLoad.current=true;setAttempt(value=>value+1)}}><RotateCcw size={15}/>Retry 3D illustration</button>}
   </div>}
   {ready&&<>
    <div className="nano-phase"><span className={view==='delivery'?'phase-amber':'phase-cyan'}/>{phase}</div>
    <div className="nano-scale">{view==='delivery'?'CARRIER CUTAWAY':view==='photoacoustic'?'OPTICAL EXCITATION → ACOUSTIC DETECTION':'TRANSMIT → SCATTER → RECEIVE'}</div>
    <div className="nano-interaction"><span>Drag to rotate</span><div><button onClick={()=>setPaused(value=>!value)} disabled={!canAnimate} aria-label={paused?'Play animation':'Pause animation'} title={!canAnimate?'Animation disabled by motion preference':paused?'Play animation':'Pause animation'}>{paused||!canAnimate?<Play size={15}/>:<Pause size={15}/>}</button><button onClick={()=>api.current?.reset()} aria-label="Reset illustration"><RotateCcw size={15}/></button></div></div>
   </>}
  </div>
  <div className="nano-legend" aria-label="Illustration legend">{legends[view].map(([color,label])=><span key={label}><i className={`legend-${color}`}/>{label}</span>)}</div>
  {ready&&<Collapsible open={guideOpen} onOpenChange={setGuideOpen} className="nano-guide">
   <CollapsibleTrigger className="nano-guide-trigger"><BookOpen size={16}/><span>{guideOpen?'Hide':'Show'} the three-step guide</span><ChevronDown size={16}/></CollapsibleTrigger>
   <CollapsibleContent className="nano-guide-content"><SceneSteps view={view}/></CollapsibleContent>
  </Collapsible>}
  <div className="nano-story">{sceneOrder.map(key=><TabsContent value={key} key={key} className="nano-story-panel"><h3>{settings[key].title}</h3><p>{settings[key].description}</p></TabsContent>)}<div className="nano-story-bottom">{settings[view].link&&<a href={settings[view].link} target="_blank" rel="noopener noreferrer">The research behind it<ArrowUpRight size={14}/></a>}{ready&&canAnimate&&settings.offerTour&&<button className="tour-toggle" onClick={toggleTour} aria-pressed={touring} title={touring?'Stop automatic topic changes':'Start a guided tour of all three topics'}>{touring?'Stop tour':'Start tour'}<span aria-hidden="true">{touring?'↻':'→'}</span></button>}</div></div>
  <div className="nano-footnote"><p>Conceptual illustration · not to scale</p><div ref={progress} className={`nano-tour-track ${!touring||paused||!canAnimate?'track-idle':''}`} aria-hidden="true"><span/></div></div>
 </Tabs>;
}
