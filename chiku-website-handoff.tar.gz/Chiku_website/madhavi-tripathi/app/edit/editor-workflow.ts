'use client';
import { useCallback,useEffect,useRef,useState } from 'react';
import { contentSchema,initialContent,newItem,type Content,type Collection } from '../content';
import { researchIdentity } from '../research-identity';
import { initialResearchLinks } from '../site-copy';

export type FieldIssue={path:(string|number)[];message:string};
export type DraftRecovery={content:Content;revision:number;savedAt:string;storageKey?:string};
type SavedState={revision:number;updatedAt:string|null;publishedAt:string|null;hasUnpublishedChanges:boolean};
type SaveResponse=SavedState&{error?:string;issues?:FieldIssue[]};
type ContentResponse=SavedState&{draft:unknown;error?:string};
export const recoveryKey='academic-site:draft-recovery:v1';
export function fieldId(path:(string|number)[]){return `edit-${path.join('-').replace(/[^a-zA-Z0-9_-]/g,'-')}`;}
export function parseRecovery(raw:string|null):DraftRecovery|null {
 if(!raw||raw.length>6_000_000)return null;
 try{const value=JSON.parse(raw);if(!value||!Number.isInteger(value.revision)||typeof value.savedAt!=='string'||!Number.isFinite(Date.parse(value.savedAt)))return null;
 const parsed=contentSchema.safeParse(value.content);
 // Locally authored drafts can contain a temporarily empty title or invalid link.
 // Retain these recoverable edits, but reject malformed field types or shapes.
 if(!parsed.success&&parsed.error.issues.some(issue=>!['too_small','too_big','custom','invalid_format'].includes(issue.code)))return null;
 let content:Content;
 if(parsed.success)content=parsed.data;
 else {
  // Validation errors must not discard freshly added schema defaults. Invalid
  // text remains editable, while legacy local records receive the same new fields.
  const raw=value.content;content={...initialContent,...raw,scene:{...initialContent.scene,...raw.scene},scholarHighlights:{...initialContent.scholarHighlights,...raw.scholarHighlights},sections:{...initialContent.sections,...raw.sections},copy:Object.fromEntries(Object.entries(initialContent.copy).map(([group,fields])=>[group,{...fields,...raw.copy?.[group]}]))} as Content;
  for(const group of ['achievements','research','publications','journey','news'] as Collection[])content[group]=(raw[group]??initialContent[group]).map((item:Content[Collection][number])=>({...newItem(),...item,researchTopic:researchIdentity(item),researchIds:item.researchIds??initialResearchLinks.get(item.id)??[]}));
 }
 return {content,revision:value.revision,savedAt:value.savedAt};}catch{return null;}
}
export function useDraftWorkflow(initial:Content,initialState:SavedState){
 const [ownRecoveryKey]=useState(()=>`${recoveryKey}:${crypto.randomUUID()}`);
 const [content,setContent]=useState(initial),[state,setState]=useState(initialState),[saved,setSaved]=useState(JSON.stringify(initial));
 const [busy,setBusy]=useState<'draft'|'publish'|null>(null),[uploads,setUploads]=useState(0),[message,setMessage]=useState(''),[error,setError]=useState('');
 const [issues,setIssues]=useState<FieldIssue[]>([]),[conflict,setConflict]=useState(false),[paused,setPaused]=useState(false),[recovery,setRecovery]=useState<DraftRecovery|null>(null),[recoveryReady,setRecoveryReady]=useState(false);
 const [storageWarning,setStorageWarning]=useState('');
 const current=useRef(content),stateRef=useRef(state),savedRef=useRef(saved),busyRef=useRef(false),uploadRef=useRef(uploads),recoveryRef=useRef(recovery),conflictRef=useRef(conflict);
 current.current=content;stateRef.current=state;savedRef.current=saved;uploadRef.current=uploads;recoveryRef.current=recovery;conflictRef.current=conflict;
 const dirty=JSON.stringify(content)!==saved;
 useEffect(()=>{try{
  const keys=new Set([recoveryKey]);
  // Each mounted editor owns its own recovery record. A clean second tab must
  // never clear another tab's unfinished work. Legacy singleton records remain
  // recoverable, and other records are removed only after an explicit choice.
  for(let index=0;index<Math.min(localStorage.length,500);index++){const key=localStorage.key(index);if(key?.startsWith(`${recoveryKey}:`))keys.add(key);}
  let latest:DraftRecovery|null=null;
  for(const key of keys){if(key===ownRecoveryKey)continue;const candidate=parseRecovery(localStorage.getItem(key));if(candidate&&JSON.stringify(candidate.content)!==JSON.stringify(initial)&&(!latest||Date.parse(candidate.savedAt)>Date.parse(latest.savedAt)))latest={...candidate,storageKey:key};}
  if(latest)setRecovery(latest);
 }catch{setStorageWarning('Temporary recovery is unavailable in this browser. Save valid edits before closing.');}setRecoveryReady(true);},[]);
 useEffect(()=>{if(!recoveryReady||recovery)return;try{if(dirty)localStorage.setItem(ownRecoveryKey,JSON.stringify({content,revision:state.revision,savedAt:new Date().toISOString()}));else localStorage.removeItem(ownRecoveryKey);}catch{setStorageWarning('This browser could not keep a temporary recovery copy. Keep this tab open until your draft is saved.');}},[content,dirty,state.revision,recovery,recoveryReady,ownRecoveryKey]);
 useEffect(()=>{const warn=(event:BeforeUnloadEvent)=>{if(dirty||uploads||busy){event.preventDefault();event.returnValue='';}};window.addEventListener('beforeunload',warn);return()=>window.removeEventListener('beforeunload',warn);},[dirty,uploads,busy]);
 const save=useCallback(async(action:'draft'|'publish',automatic=false)=>{
  if(busyRef.current||uploadRef.current||recoveryRef.current||conflictRef.current)return false;
  const snapshot=current.current,serialized=JSON.stringify(snapshot),validation=contentSchema.safeParse(snapshot);
  if(!validation.success){setIssues(validation.error.issues.map(issue=>({path:issue.path.map(String),message:issue.message})));if(!automatic)setError('Check the highlighted fields before saving. Your edits are kept in this browser.');return false;}
  if(automatic&&serialized===savedRef.current)return true;
  busyRef.current=true;setBusy(action);setError('');setIssues([]);if(!automatic)setMessage('');
  try{const response=await fetch('/api/content',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({content:validation.data,revision:stateRef.current.revision,action,autosave:automatic})});const result=await response.json() as SaveResponse;
   if(response.status===409){setConflict(true);conflictRef.current=true;setPaused(true);throw new Error('Another tab saved a newer draft. Your edits are safe here. Load the latest draft before choosing whether to recover your edits.');}
   if(!response.ok){if(Array.isArray(result.issues))setIssues(result.issues);throw new Error(result.error||'The draft could not be saved. Please try again.');}
   const next={revision:result.revision,updatedAt:result.updatedAt,publishedAt:result.publishedAt??stateRef.current.publishedAt,hasUnpublishedChanges:Boolean(result.hasUnpublishedChanges)};
   const canonical=JSON.stringify(validation.data);stateRef.current=next;savedRef.current=canonical;setState(next);setSaved(canonical);setPaused(false);
   // New keystrokes during this request belong to the next draft, never this response.
   setContent(latest=>JSON.stringify(latest)===serialized?validation.data:latest);
   setMessage(action==='publish'?'Published. Visitors now see this saved version.':automatic?'Draft saved automatically. Publish when you are ready.':'Draft saved. Publish when you are ready.');return true;
  }catch(cause){setError(cause instanceof Error?cause.message:'The draft could not be saved. Please try again.');setPaused(true);return false;}
  finally{busyRef.current=false;setBusy(null);}
 },[]);
 useEffect(()=>{if(!dirty||!recoveryReady||recovery||busy||uploads||paused||conflict)return;const timer=window.setTimeout(()=>{void save('draft',true);},1500);return()=>window.clearTimeout(timer);},[content,dirty,recoveryReady,recovery,busy,uploads,paused,conflict,save]);
 function edit(updater:(previous:Content)=>Content){setContent(updater);setMessage('');setIssues([]);}
 function chooseRecovery(restore:boolean){if(restore&&recovery)setContent(recovery.content);setRecovery(null);recoveryRef.current=null;setMessage(restore?'Recovered your edits for review. Autosave is paused: choose Save draft when you are ready to replace the saved draft. Nothing is published automatically.':'Using the saved website draft.');setPaused(restore);try{if(recovery?.storageKey)localStorage.removeItem(recovery.storageKey);}catch{}}
 async function reloadLatest(){if(busyRef.current||uploadRef.current)return;busyRef.current=true;setBusy('draft');setError('');
  try{const response=await fetch('/api/content',{cache:'no-store'});const result=await response.json() as ContentResponse;const parsed=contentSchema.safeParse(result.draft);if(!response.ok||!parsed.success)throw new Error('The latest draft could not be loaded. Your edits remain here.');
   const next={revision:result.revision,updatedAt:result.updatedAt,publishedAt:result.publishedAt,hasUnpublishedChanges:result.hasUnpublishedChanges};setRecovery({content:current.current,revision:stateRef.current.revision,savedAt:new Date().toISOString(),storageKey:ownRecoveryKey});setContent(parsed.data);setSaved(JSON.stringify(parsed.data));setState(next);stateRef.current=next;savedRef.current=JSON.stringify(parsed.data);setConflict(false);conflictRef.current=false;setPaused(false);setMessage('Latest saved draft loaded. Choose whether to restore your local edits; restored edits pause for review before saving.');
  }catch(cause){setError(cause instanceof Error?cause.message:'Unable to load the draft.');}finally{busyRef.current=false;setBusy(null);}
 }
 return {content,edit,state,dirty,busy,uploads,uploadBusy:(active:boolean)=>setUploads(n=>Math.max(0,n+(active?1:-1))),message,setMessage,error,setError,issues,setIssues,conflict,paused,recovery,recoveryReady,storageWarning,save,chooseRecovery,reloadLatest};
}
