import { requireChatGPTUser } from '../../chatgpt-auth';
import { isEditor } from '../../server';
import { PreviewClient } from './preview-client';
export const dynamic='force-dynamic';
export const metadata={title:'Private draft preview',robots:{index:false,follow:false}};
export default async function PreviewPage(){
 const user=await requireChatGPTUser('/edit/preview');
 if(!await isEditor(user))return <main className="unavailable"><h1>Private draft preview</h1><p>Sign in as the website owner to preview a draft.</p><a href="/edit" target="_top">Open the editor</a></main>;
 return <PreviewClient/>;
}
