'use client';
import { useEffect,useState } from 'react';
import { contentSchema,type Content } from '../../content';
import { AcademicSite } from '../../site';
export function PreviewClient(){
 const [content,setContent]=useState<Content|null>(null),[theme,setTheme]=useState<'light'|'dark'>('light'),[error,setError]=useState('');
 useEffect(()=>{const receive=(event:MessageEvent)=>{
  if(event.origin!==location.origin||event.source!==window.parent||event.data?.type!=='academic-draft-preview')return;
  try{if(JSON.stringify(event.data.content).length>6_000_000)throw new Error();const result=contentSchema.safeParse(event.data.content);if(!result.success)throw new Error();setContent(result.data);setTheme(event.data.theme==='dark'?'dark':'light');setError('');window.parent.postMessage({type:'academic-preview-rendered'},location.origin);}catch{setError('This draft contains a field that needs attention. Return to the editor to review it.');}
 };window.addEventListener('message',receive);if(window.parent!==window)window.parent.postMessage({type:'academic-preview-ready'},location.origin);return()=>window.removeEventListener('message',receive);},[]);
 useEffect(()=>{const root=document.documentElement;const apply=()=>{if(root.getAttribute('data-color-mode')!==theme)root.setAttribute('data-color-mode',theme);root.style.colorScheme=theme;};apply();const observer=new MutationObserver(apply);observer.observe(root,{attributes:true,attributeFilter:['data-color-mode']});return()=>observer.disconnect();},[theme]);
 return <div className="isolated-draft-preview">{error?<div className="unavailable"><h1>Preview needs attention</h1><p>{error}</p></div>:content?<AcademicSite content={content} preview/>:<div className="unavailable"><h1>Private draft preview</h1><p>Open Preview draft from the website editor to see your current changes.</p><a href="/edit" target="_top">Back to editor</a></div>}</div>;
}
