import { requireChatGPTUser } from '../chatgpt-auth';
import { isEditor,readContent } from '../server';
import { Editor } from './editor';
export const dynamic='force-dynamic';
export const metadata={title:'Website editor | Madhavi Tripathi',robots:{index:false,follow:false}};
export default async function EditPage(){
 const user=await requireChatGPTUser('/edit');
 try{if(!await isEditor(user))return <main className="unavailable"><h1>Website editor</h1><p>Editing is available to the website owner. Please sign in with the owner’s account.</p><a className="button" href="/signout-with-chatgpt?return_to=%2Fedit" target="_top">Switch account</a><a href="/">Back to website</a></main>;
 const data=await readContent();return <Editor initial={data.draft} initialRevision={data.revision} initialUpdatedAt={data.updatedAt} initialPublishedAt={data.publishedAt} initialHasUnpublishedChanges={data.hasUnpublishedChanges}/>;
 }catch(e){console.error(e);return <main className="unavailable"><h1>Your editor is temporarily unavailable</h1><p>Please try again in a moment.</p><a className="button" href="/edit">Try again</a></main>}
}
