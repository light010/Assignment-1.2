'use client';
import { useEffect, useId, useRef, useState } from 'react';
import { Upload, X, RotateCcw, Check } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { prepareImage } from '../image-processing';
import type { ImageSource } from '../responsive-image';

type Kind = 'image' | 'pdf' | 'video' | 'captions';
type UploadResult = { url: string; sources?: ImageSource[]; error?: string };
type UploadFieldProps = {
  label: string;
  value: string;
  onChange: (value: string) => void;
  kind?: Kind;
  disabled?: boolean;
  onBusy: (busy: boolean) => void;
  onSourcesChange?: (sources: ImageSource[]) => void;
  path?: (string | number)[];
  error?: string;
};

function sendUpload(body: FormData, signal: AbortSignal, onProgress: (value: number | null) => void): Promise<UploadResult> {
  return new Promise((resolve, reject) => {
    const request = new XMLHttpRequest();
    const abort = () => request.abort();
    const cleanup = () => signal.removeEventListener('abort', abort);
    request.open('POST', '/api/upload');
    request.responseType = 'json';
    request.timeout = 300000;
    request.upload.onprogress = event => onProgress(event.lengthComputable ? Math.round(event.loaded / event.total * 100) : null);
    request.onload = () => {
      cleanup();
      const result = request.response as UploadResult | null;
      if (request.status >= 200 && request.status < 300 && result?.url) resolve(result);
      else reject(new Error(result?.error || 'The upload could not finish. Please retry; your other changes are safe.'));
    };
    request.onerror = () => { cleanup(); reject(new Error('The connection was interrupted. Check your connection and retry.')); };
    request.ontimeout = () => { cleanup(); reject(new Error('The upload took too long. Check your connection and retry.')); };
    request.onabort = () => { cleanup(); reject(new DOMException('Upload cancelled.', 'AbortError')); };
    signal.addEventListener('abort', abort, { once: true });
    if (signal.aborted) { cleanup(); reject(new DOMException('Upload cancelled.', 'AbortError')); return; }
    request.send(body);
  });
}

export function UploadField({ label, value, onChange, kind = 'image', disabled = false, onBusy, onSourcesChange, path, error: validationError }: UploadFieldProps) {
  const id = useId();
  const [phase, setPhase] = useState<'idle' | 'preparing' | 'uploading' | 'finishing'>('idle');
  const [progress, setProgress] = useState<number | null>(null);
  const [error, setError] = useState('');
  const inputId = path ? `edit-${path.join('-').replace(/[^a-zA-Z0-9_-]/g, '-')}` : `${id}-url`;
  const [notice, setNotice] = useState('');
  const [retryFile, setRetryFile] = useState<File | null>(null);
  const active = useRef<AbortController | null>(null);
  const mounted = useRef(true);
  const callbacks = useRef({ onBusy, onChange, onSourcesChange });
  callbacks.current = { onBusy, onChange, onSourcesChange };
  const busy = phase !== 'idle';
  const limit = kind === 'video' ? 50 : kind === 'captions' ? 1 : 10;
  const accept = kind === 'image' ? 'image/jpeg,image/png,image/webp' : kind === 'video' ? 'video/mp4,video/webm' : kind === 'captions' ? '.vtt,text/vtt' : 'application/pdf';
  const description = kind === 'image' ? 'JPG, PNG or WebP' : kind === 'video' ? 'MP4 or WebM' : kind === 'captions' ? 'UTF-8 WebVTT (.vtt)' : 'PDF';
  const action = kind === 'image' ? 'Choose photo' : kind === 'video' ? 'Choose video' : kind === 'captions' ? 'Choose captions' : 'Choose PDF';
  const placeholder = kind === 'image' ? 'Upload a photo or paste an image link' : kind === 'video' ? 'Upload a clip or paste a YouTube, Vimeo, or MP4 link' : kind === 'captions' ? 'Upload a .vtt file or paste a caption link' : 'Upload a PDF or paste a document link';

  useEffect(() => {
    mounted.current = true;
    return () => { mounted.current = false; active.current?.abort(); };
  }, []);

  async function upload(file?: File) {
    if (!file || active.current || disabled) return;
    setError(''); setNotice(''); setRetryFile(null);
    if (!file.size) { setError('Choose a non-empty file.'); return; }
    if (file.size > limit * 1024 * 1024) { setError(`Choose a file smaller than ${limit} MB.`); return; }
    const allowed = kind === 'image' ? ['image/jpeg', 'image/png', 'image/webp'].includes(file.type) : kind === 'video' ? ['video/mp4', 'video/webm'].includes(file.type) : kind === 'captions' ? /\.vtt$/i.test(file.name) : file.type === 'application/pdf';
    if (!allowed) { setError(`Choose a ${description} file.`); return; }
    const controller = new AbortController();
    active.current = controller;
    callbacks.current.onBusy(true);
    setPhase(kind === 'image' ? 'preparing' : 'uploading'); setProgress(null);
    try {
      const prepared = kind === 'image' ? await prepareImage(file, controller.signal) : { file, variants: [], optimized: false };
      if (controller.signal.aborted) throw new DOMException('Upload cancelled.', 'AbortError');
      const body = new FormData();
      body.append('file', prepared.file); body.append('kind', kind);
      if (prepared.optimized) body.append('optimized', 'true');
      prepared.variants.forEach(variant => body.append('variants', variant));
      if (mounted.current) setPhase('uploading');
      const result = await sendUpload(body, controller.signal, percent => {
        if (!mounted.current) return;
        setProgress(percent); setPhase(percent === 100 ? 'finishing' : 'uploading');
      });
      if (!mounted.current || controller.signal.aborted) return;
      callbacks.current.onChange(result.url);
      callbacks.current.onSourcesChange?.(kind === 'image' ? result.sources || [] : []);
      setNotice(kind === 'image' ? prepared.optimized ? 'Photo uploaded with optimized sizes for phones and larger screens.' : 'Photo uploaded. This browser could not prepare smaller versions, so the original image was kept.' : kind === 'captions' ? 'Caption track uploaded. Preview the video to check its timing.' : 'Upload complete. Save or publish when you are ready.');
    } catch (cause) {
      if (!mounted.current) return;
      setRetryFile(file);
      if (controller.signal.aborted) setNotice('Upload cancelled. Your previous file and other changes are unchanged.');
      else setError(cause instanceof Error ? cause.message : 'Upload failed. Please retry.');
    } finally {
      if (active.current === controller) { active.current = null; callbacks.current.onBusy(false); }
      if (mounted.current) { setPhase('idle'); setProgress(null); }
    }
  }

  function changeUrl(url: string) {
    callbacks.current.onChange(url); callbacks.current.onSourcesChange?.([]);
    setError(''); setNotice(''); setRetryFile(null);
  }

  return <div className="upload-field media-upload-field" aria-busy={busy}>
    <label className="field" htmlFor={inputId}><span>{label}</span><input id={inputId} type="text" inputMode="url" value={value} onChange={event => changeUrl(event.target.value)} placeholder={placeholder} disabled={busy || disabled} aria-describedby={`${id}-hint${validationError ? ` ${inputId}-validation` : ''}`} aria-invalid={!!validationError} /></label>
    <div className="upload-controls"><label className={`upload-button ${busy || disabled ? 'disabled' : ''}`}><Upload size={16} aria-hidden="true"/>{action}<input type="file" aria-label={`${action} for ${label.toLowerCase()}`} accept={accept} aria-invalid={!!error} aria-describedby={`${id}-hint${error ? ` ${id}-error` : ''}`} disabled={busy || disabled} onChange={event => { void upload(event.target.files?.[0]); event.target.value = ''; }}/></label><span id={`${id}-hint`} className="field-hint">{description} · up to {limit} MB</span></div>
    {busy && <div className="upload-progress-wrap"><div className="upload-progress-heading"><span role="status">{phase === 'preparing' ? 'Preparing photo sizes…' : phase === 'finishing' ? 'Finishing upload…' : progress === null ? 'Uploading…' : `Uploading ${progress}%`}</span><button type="button" className="upload-cancel" onClick={() => active.current?.abort()}><X size={15} aria-hidden="true"/>Cancel upload</button></div><Progress value={phase === 'preparing' || progress === null ? null : progress} className="upload-progress" aria-label={`${label} upload`} aria-valuetext={phase === 'preparing' ? 'Preparing image' : phase === 'finishing' ? 'Finishing upload' : progress === null ? 'Uploading' : `${progress}% uploaded`}/></div>}
    {kind === 'image' && <p className="upload-note">When supported, this browser prepares WebP display sizes up to 1600 pixels without enlarging small photos. Your original is used if image preparation is unavailable.</p>}
    {kind === 'video' && <p className="upload-note">Use MP4 with H.264 video for broad compatibility. Longer films can use YouTube or Vimeo. Videos play only when a visitor chooses to watch.</p>}
    {kind === 'captions' && <p className="upload-note">Use a UTF-8 WebVTT track with timed captions for uploaded MP4 or WebM videos. For YouTube or Vimeo, manage captions on the video platform.</p>}
    {value && kind === 'image' && <img className="upload-preview" src={value} alt={`Current ${label.toLowerCase()}`} />}
    {validationError && <p id={`${inputId}-validation`} className="form-error">{validationError}</p>}
    {error && <p id={`${id}-error`} role="alert" className="form-error">{error}</p>}
    {notice && <p className="upload-feedback" role="status"><Check size={16} aria-hidden="true"/>{notice}</p>}
    {retryFile && !busy && <button type="button" className="upload-retry" disabled={disabled} onClick={() => void upload(retryFile)}><RotateCcw size={16} aria-hidden="true"/>Retry upload<span className="upload-retry-name">{retryFile.name}</span></button>}
  </div>;
}
