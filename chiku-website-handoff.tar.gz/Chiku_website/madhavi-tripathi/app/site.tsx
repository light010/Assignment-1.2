'use client';
import { useEffect, useRef, useState } from 'react';
import { ArrowUpRight, ArrowDown, Menu, X, Pencil, Download, GraduationCap, Copy, Check } from 'lucide-react';
import type { Content, ImageSource } from './content';
import { ResearchScene } from './scene';
import { Achievements } from './achievements';
import { Publications } from './publications';
import { ResearchSection } from './research-section';
import { ColorModeToggle } from './color-mode';
import { ResponsiveImage } from './responsive-image';
import { Updates } from './updates';

const sectionKeys = ['achievements','research','publications','journey','news','contact'] as const;
function External({href,children,className=''}:{href:string;children:React.ReactNode;className?:string}) {
 return <a href={href} className={className} target="_blank" rel="noopener noreferrer">{children}</a>;
}
function Label({number,children}:{number:string;children:React.ReactNode}) {
 return <p className="section-kicker"><span>{number}</span>{children}</p>;
}
function ProfilePortrait({name,photo,description,sources,focalX,focalY,editable}:{name:string;photo:string;description:string;sources:ImageSource[];focalX:number;focalY:number;editable:boolean}) {
 const [failedPhoto,setFailedPhoto]=useState('');
 const parts=name.trim().split(/\s+/);
 const initials=[parts[0],parts.length>1?parts.at(-1):''].map(part=>part?.[0]||'').join('').toUpperCase();
 const showPhoto=!!photo&&photo!==failedPhoto;
 return <div className="hero-portrait">
  <div className={`portrait-frame ${showPhoto?'has-portrait':'portrait-empty'}`}>
   {showPhoto?<ResponsiveImage src={photo} sources={sources} focalX={focalX} focalY={focalY} sizes="160px" alt={description||name} width={320} height={400} loading="eager" decoding="async" onError={()=>setFailedPhoto(photo)}/>:<div className="portrait-initials" aria-hidden="true"><span>{initials}</span><small>Portrait</small></div>}
  </div>
  {editable&&<a className="portrait-edit" href="/edit?tab=profile#profile-photo"><Pencil size={14} aria-hidden="true"/>{photo?'Change portrait':'Add portrait'}</a>}
 </div>;
}
export function AcademicSite({content:c,canEdit=false,preview=false}:{content:Content;canEdit?:boolean;preview?:boolean}) {
 const root=useRef<HTMLDivElement>(null),header=useRef<HTMLElement>(null),menuButton=useRef<HTMLButtonElement>(null);
 const [menu,setMenu]=useState(false),[active,setActive]=useState(''),[progress,setProgress]=useState(0),[copyMessage,setCopyMessage]=useState('');
 const nav=sectionKeys.filter(key=>c.sections[key]&&(key!=='news'||c.news.length>0));
 const profiles=[['Google Scholar',c.scholar],['ORCID',c.orcid],['GitHub',c.github],['LinkedIn',c.linkedin]].filter(([,url])=>url);
 const s=c.scholarHighlights,interests=s.interests.split(',').map(v=>v.trim()).filter(Boolean);
 const featured=c.publications.filter(p=>p.featured),papers=featured.length?featured:c.publications;
 const nameParts=c.name.trim().split(/\s+/),first=nameParts.slice(0,-1).join(' ')||c.name,last=nameParts.length>1?nameParts.at(-1):'';
 const copy=c.copy;
 useEffect(()=>{
  const node=root.current;if(!node)return;
  const reveal=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('revealed');reveal.unobserve(e.target)}}),{threshold:.09});
  node.querySelectorAll('.reveal').forEach(e=>{e.classList.add('reveal-ready');reveal.observe(e)});
  const observe=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting)setActive(e.target.id)}),{rootMargin:'-15% 0px -65% 0px'});
  node.querySelectorAll('section[id]').forEach(e=>observe.observe(e));
  let frame=0;
  const scroll=()=>{cancelAnimationFrame(frame);frame=requestAnimationFrame(()=>{const max=document.documentElement.scrollHeight-innerHeight;setProgress(max>0?Math.min(100,scrollY/max*100):0)})};
  window.addEventListener('scroll',scroll,{passive:true});scroll();
  const escape=(e:KeyboardEvent)=>{if(e.key==='Escape'){if(node.querySelector('nav.nav-open')?.contains(document.activeElement))menuButton.current?.focus();setMenu(false)}};
  window.addEventListener('keydown',escape);
  return()=>{reveal.disconnect();observe.disconnect();window.removeEventListener('scroll',scroll);window.removeEventListener('keydown',escape);cancelAnimationFrame(frame)};
 },[c]);
 useEffect(()=>{
  const node=header.current;if(!node)return;
  const measure=()=>root.current?.style.setProperty('--site-header-height',`${Math.ceil(node.getBoundingClientRect().height)+32}px`);
  measure();const observer=new ResizeObserver(measure);observer.observe(node);
  const desktop=matchMedia('(min-width: 1001px)');const close=()=>{if(desktop.matches)setMenu(false)};
  const outside=(e:PointerEvent)=>{if(!node.contains(e.target as Node))setMenu(false)};
  desktop.addEventListener('change',close);document.addEventListener('pointerdown',outside);
  return()=>{observer.disconnect();desktop.removeEventListener('change',close);document.removeEventListener('pointerdown',outside)};
 },[]);
 async function copyEmail(){
  try{await navigator.clipboard.writeText(c.email);setCopyMessage('Email address copied.');}
  catch{setCopyMessage(`Select and copy the email address above: ${c.email}`)}
 }
 return <div ref={root} className={`academic immersive theme-${c.accent} ${c.motion?'motion-on':'motion-off'}`}>
  <a className="skip-link" href="#main">Skip to content</a>
  <div className="reading-progress" style={{transform:`scaleX(${progress/100})`}} aria-hidden="true"/>
  {preview&&<div className="preview-ribbon">Draft preview · Publish your changes to update the website</div>}
  <header ref={header} className="site-header">
   <a className="brand" href={preview?'#main':'/'} aria-label={`${c.name} home`}><span className="brand-monogram">mt<span>.</span></span><span>{c.name}</span></a>
   <nav id="site-navigation" className={menu?'nav-open':''} aria-label="Main navigation">{nav.map(key=><a key={key} href={`#${key}`} aria-current={active===key?'location':undefined} onClick={()=>setMenu(false)}>{copy[key].navigation}</a>)}</nav>
   {c.scholar&&<External href={c.scholar} className="nav-scholar">Scholar<ArrowUpRight size={16}/></External>}
   {!preview&&<ColorModeToggle/>}
   <button ref={menuButton} className="menu-toggle" aria-controls="site-navigation" onClick={()=>setMenu(!menu)} aria-label={menu?'Close navigation':'Open navigation'} aria-expanded={menu}>{menu?<X/>:<Menu/>}</button>
  </header>
  <main id="main">
   <section className="hero wrap" aria-labelledby="hero-name">
    <div className="hero-copy">
     <div className="hero-identity">
      <ProfilePortrait name={c.name} photo={c.photo} description={c.photoAlt} sources={c.photoSources} focalX={c.photoFocalX} focalY={c.photoFocalY} editable={canEdit&&!preview}/>
      <div className="hero-identity-copy">{c.role&&<p className="hero-role"><span className="role-line" aria-hidden="true"/>{c.role}</p>}<h1 id="hero-name">{first}{last&&' '}{last&&<span>{last}<i aria-hidden="true">.</i></span>}</h1></div>
     </div>
     <h2 className="hero-statement">{c.headline}</h2><p className="hero-intro">{c.intro}</p>
     <div className="hero-actions">{c.sections.research&&<a className="action primary-action" href="#research">{copy.hero.researchAction}<ArrowUpRight size={19}/></a>}{c.scholar&&<External href={c.scholar} className="quiet-link">{copy.hero.scholarAction}<ArrowUpRight size={16}/></External>}</div>
     {c.affiliation&&<p className="hero-affiliation">{c.affiliation}{c.location&&` · ${c.location}`}</p>}
    </div>
    <div className="hero-spatial"><ResearchScene motion={c.motion} accent={c.accent} settings={c.scene}/></div>
    <div className="hero-bottom"><span>{copy.hero.topics}</span><a href={c.sections.achievements?'#achievements':s.visible&&c.scholar?'#scholar':`#${nav[0]||'main'}`}>{copy.hero.discover}<ArrowDown size={16}/></a></div>
   </section>
   {c.showNotice&&c.notice&&<div className="site-notice wrap"><span>NOTE</span><p>{c.notice}</p></div>}
   {c.sections.achievements&&<Achievements items={c.achievements} canEdit={canEdit} preview={preview} motion={c.motion} copy={copy.achievements}/>}
   {s.visible&&c.scholar&&<section id="scholar" className="scholar-section wrap reveal" aria-labelledby="scholar-title">
    <div className="scholar-card">
     <div className="scholar-intro"><span className="small-label"><GraduationCap size={18}/>GOOGLE SCHOLAR</span><h2 id="scholar-title" className="editable-heading">{copy.scholar.title}</h2>{s.affiliation&&<p>Profile affiliation<br/><strong>{s.affiliation}</strong></p>}<External href={c.scholar} className="quiet-link">{copy.scholar.profileAction}<ArrowUpRight size={17}/></External></div>
     <div className="scholar-detail"><div className="scholar-stats">
      {s.citations&&<div className="stat stat-primary"><strong>{s.citations}</strong><span>Citations</span><small>Indexed snapshot</small></div>}
      {s.hIndex&&<div className="stat"><strong>{s.hIndex}</strong><span>h-index</span></div>}
      {s.i10Index&&<div className="stat"><strong>{s.i10Index}</strong><span>i10-index</span></div>}
      <div className="stat"><strong>{String(papers.length).padStart(2,'0')}</strong><span>Selected papers</span><small>Featured on this site</small></div>
     </div>{interests.length>0&&<div className="interest-tags">{interests.map(i=><span key={i}>{i}</span>)}</div>}<p className="snapshot-note">{s.asOf?`Snapshot checked ${s.asOf}. `:''}For current citation counts and the complete publication record, visit Google Scholar.</p></div>
    </div>
   </section>}
   {c.sections.research&&<ResearchSection items={c.research} papers={c.sections.publications?papers:[]} copy={copy.research} motion={c.motion}/>}
   {c.sections.publications&&<Publications papers={papers} scholar={c.scholar} research={c.research} copy={copy.publications} canEdit={canEdit&&!preview}/>}
   {c.sections.journey&&<section id="journey" className="journey-section section wrap">
    <div className="journey-intro reveal"><Label number="03">{copy.journey.navigation.toUpperCase()}</Label><h2 className="editable-heading">{copy.journey.title}</h2>{copy.journey.description&&<p>{copy.journey.description}</p>}<div className="biography-copy">{c.bio.split(/\n\s*\n/).filter(Boolean).map((paragraph,i)=><p key={i}>{paragraph}</p>)}</div>{c.cv&&<External href={c.cv} className="quiet-link">Curriculum vitae<Download size={17}/></External>}</div>
    <div className="journey-timeline">{c.journey.map(item=><article key={item.id} className="milestone reveal"><span className="milestone-node" aria-hidden="true"/><span className="milestone-date">{item.year}</span><h3>{item.title}</h3><p className="milestone-place">{item.subtitle}</p><p>{item.description}</p>{item.image&&<ResponsiveImage src={item.image} sources={item.imageSources} focalX={item.focalX} focalY={item.focalY} sizes="(max-width: 800px) 90vw, 550px" alt={item.imageAlt||item.title} loading="lazy"/>}{item.link&&<External href={item.link} className="quiet-link">Learn more<ArrowUpRight size={15}/></External>}</article>)}</div>
   </section>}
   {c.sections.news&&<Updates items={c.news} copy={copy.news} motion={c.motion}/>}
   {c.sections.contact&&<section id="contact" className="contact-section section wrap"><div className="contact-panel reveal">
    <Label number="05">{copy.contact.navigation.toUpperCase()}</Label><div className="contact-heading"><h2 className="editable-heading">{copy.contact.title}</h2></div>
    <div className="contact-bottom"><p className="editable-heading">{copy.contact.description}</p><div>
     {c.email&&<><a className="contact-email" href={`mailto:${c.email}`}>{c.email}<ArrowUpRight size={20}/></a><button type="button" className="copy-email" onClick={copyEmail}>{copyMessage==='Email address copied.'?<Check size={16}/>:<Copy size={16}/>}Copy email</button><p className="copy-feedback" role="status">{copyMessage}</p></>}
     <div className="profile-links">{profiles.map(([name,url])=><External key={name} href={url}>{name}<ArrowUpRight size={16}/></External>)}</div>
    </div></div>
   </div></section>}
  </main>
  <footer className="site-footer wrap"><a href="#main" className="footer-brand">{c.name}<span>.</span></a><span>{copy.footer.tagline}</span><div>{canEdit&&!preview&&<a href="/edit"><Pencil size={14}/>Edit website</a>}<a href="#main" aria-label="Back to top"><ArrowUpRight size={19}/></a></div></footer>
 </div>;
}
