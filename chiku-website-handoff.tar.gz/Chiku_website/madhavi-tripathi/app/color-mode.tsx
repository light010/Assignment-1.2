'use client';
import { useEffect,useState } from 'react';
import { ThemeProvider,useTheme } from 'next-themes';
import { Moon,Sun } from 'lucide-react';
import { Toggle } from '@/components/ui/toggle';

export function ColorModeProvider({children}:{children:React.ReactNode}){
 return <ThemeProvider attribute="data-color-mode" storageKey="madhavi-color-mode" defaultTheme="system" enableSystem enableColorScheme disableTransitionOnChange>{children}</ThemeProvider>;
}

export function ColorModeToggle(){
 const {resolvedTheme,setTheme}=useTheme(),[mounted,setMounted]=useState(false);
 useEffect(()=>setMounted(true),[]);
 const dark=resolvedTheme==='dark';
 return <Toggle className="color-mode-toggle" variant="outline" pressed={mounted&&dark} onPressedChange={pressed=>setTheme(pressed?'dark':'light')} disabled={!mounted} aria-label="Dark mode" title={mounted?`Switch to ${dark?'light':'dark'} mode`:'Light and dark mode'}>
  <Sun className="mode-sun" size={19} strokeWidth={1.7} aria-hidden="true"/>
  <Moon className="mode-moon" size={19} strokeWidth={1.7} aria-hidden="true"/>
 </Toggle>;
}
