import type { Metadata } from 'next';
import type { Content } from './content';

// Canonical origin returned by Sites for this project; access remains managed by Sites.
export const siteOrigin = 'https://madhavi-tripathi.madhavi-tri16.chatgpt.site';
// Older saved drafts can contain partially typed URLs. Metadata must never
// prevent otherwise valid page content from rendering.
const absolute = (url: string): string | undefined => {
 try {
  if (!url) return undefined;
  const parsed = new URL(url, siteOrigin);
  return ['http:', 'https:'].includes(parsed.protocol) ? parsed.href : undefined;
 } catch { return undefined; }
};

export function profileMetadata(c: Content): Metadata {
 const title = `${c.name} | ${c.role || 'Academic profile'}`;
 const description = c.headline.replace(/\n/g, ' ');
 const photo = absolute(c.photo);
 const image = photo ? [{ url: photo, alt: c.photoAlt || c.name }] : undefined;
 return {
  metadataBase: new URL(siteOrigin), title, description,
  alternates: { canonical: '/' },
  openGraph: { type: 'profile', title, description, url: siteOrigin, siteName: c.name, images: image },
  twitter: { card: 'summary', title, description, images: image },
 };
}

export function profileStructuredData(c: Content, updatedAt: string | null) {
 const photo = absolute(c.photo);
 return {
  '@context': 'https://schema.org', '@type': 'ProfilePage', url: siteOrigin,
  ...(updatedAt ? { dateModified: updatedAt } : {}),
  mainEntity: {
   '@type': 'Person', '@id': `${siteOrigin}/#researcher`, name: c.name, url: siteOrigin,
   description: c.headline.replace(/\n/g, ' '),
   ...(c.role ? { jobTitle: c.role } : {}),
   ...(photo ? { image: photo } : {}),
   sameAs: [c.scholar, c.orcid, c.github, c.linkedin].map(absolute).filter((url): url is string => Boolean(url)),
  },
 };
}
