'use client';
import { useEffect, useState, type KeyboardEvent } from 'react';
import type { CarouselApi } from '@/components/ui/carousel';

// Embla applies a drag-release duration independently of opts.duration.
export function settleCarouselWithoutMotion(api:NonNullable<CarouselApi>) {
 api.scrollTo(api.selectedScrollSnap(),true);
 const animation=api.internalEngine().animation;
 animation.update();
 animation.render(1);
}

export function useSectionCarousel(motion:boolean) {
 const [api,setApi]=useState<CarouselApi>();
 const [index,setIndex]=useState(0);
 const [range,setRange]=useState<[number,number]>([1,1]);
 const [reduced,setReduced]=useState(false);
 useEffect(()=>{
  const query=window.matchMedia('(prefers-reduced-motion: reduce)');
  const sync=()=>setReduced(query.matches);sync();query.addEventListener('change',sync);
  return()=>query.removeEventListener('change',sync);
 },[]);
 useEffect(()=>{
  if(!api)return;
  const sync=()=>{setIndex(api.selectedScrollSnap());const visible=api.slidesInView();if(visible.length)setRange([Math.min(...visible)+1,Math.max(...visible)+1]);};
  sync();api.on('select',sync);api.on('reInit',sync);api.on('slidesInView',sync);
  return()=>{api.off('select',sync);api.off('reInit',sync);api.off('slidesInView',sync);};
 },[api]);
 useEffect(()=>{
  if(!api||(!reduced&&motion))return;
  const settle=()=>settleCarouselWithoutMotion(api);api.on('pointerUp',settle);
  return()=>{api.off('pointerUp',settle);};
 },[api,reduced,motion]);
 function carouselKeys(event:KeyboardEvent<HTMLDivElement>) {
  if(event.altKey||event.ctrlKey||event.metaKey)return;
  // Keep focused card links stable. The region and persistent arrow controls
  // support arrow keys; links retain their normal keyboard behavior.
  if(event.target!==event.currentTarget&&!(event.target as Element).closest('[data-slot="carousel-previous"],[data-slot="carousel-next"]'))return;
  if(event.key==='ArrowLeft'){event.preventDefault();api?.scrollPrev(reduced||!motion);}
  else if(event.key==='ArrowRight'){event.preventDefault();api?.scrollNext(reduced||!motion);}
 }
 return {api,setApi,index,range,reduced,carouselKeys,duration:reduced||!motion?0:25};
}
