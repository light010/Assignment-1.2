import type { Item } from './content';

export type PublicationSort='newest'|'oldest'|'citations'|'title';
export type PublicationFilters={query:string;year:string;sort:PublicationSort;topic:string};
export const defaultPublicationFilters:PublicationFilters={query:'',year:'all',sort:'newest',topic:'all'};
export const publicationFilterEvent='publication-filter';
export const publicationYear=(paper:Item):number|null=>{
 const match=paper.year.match(/\b(?:18|19|20|21)\d{2}\b/);
 return match?Number(match[0]):null;
};
export const publicationCitations=(paper:Item):number|null=>{
 const value=paper.citations?.trim();
 return value&&/^\d+$/.test(value)&&Number.isSafeInteger(Number(value))?Number(value):null;
};
const normalize=(text:string)=>text.normalize('NFKD').replace(/\p{M}/gu,'').toLowerCase();
const compareNullable=(a:number|null,b:number|null,direction:1|-1)=>a===null?(b===null?0:1):b===null?-1:(a-b)*direction;
export function selectPublications(papers:Item[],query:string,year:string,sort:PublicationSort,topic='all'):Item[]{
 const terms=normalize(query).split(/\s+/).filter(Boolean);
 return papers.filter(paper=>{
  const matchesYear=year==='all'||(year==='undated'?publicationYear(paper)===null:String(publicationYear(paper))===year);
  const matchesTopic=topic==='all'||paper.researchIds?.includes(topic);
  const text=normalize(`${paper.title} ${paper.subtitle} ${paper.description} ${paper.contribution||''} ${paper.approach||''} ${paper.outcome||''} ${paper.year}`);
  return matchesYear&&matchesTopic&&terms.every(term=>text.includes(term));
 }).sort((a,b)=>{
  const newest=compareNullable(publicationYear(a),publicationYear(b),-1);
  if(sort==='title')return a.title.localeCompare(b.title,'en',{sensitivity:'base'})||newest;
  if(sort==='citations')return compareNullable(publicationCitations(a),publicationCitations(b),-1)||newest;
  return sort==='oldest'?compareNullable(publicationYear(a),publicationYear(b),1):newest;
 });
}

/** Filter URLs preserve tracking parameters and any other page state. */
export function publicationFilterUrl(input:string|URL,filters:PublicationFilters):URL{
 const url=new URL(input);
 for(const [key,value,fallback] of [['q',filters.query,''],['year',filters.year,'all'],['sort',filters.sort,'newest'],['topic',filters.topic,'all']]){
  if(value===fallback)url.searchParams.delete(key);else url.searchParams.set(key,value);
 }
 return url;
}
export function readPublicationFilters(params:URLSearchParams):PublicationFilters{
 const sort=params.get('sort');const year=params.get('year')||'all';
 return{query:(params.get('q')||'').slice(0,1000),year:/^(all|undated|(?:18|19|20|21)\d{2})$/.test(year)?year:'all',sort:sort==='oldest'||sort==='citations'||sort==='title'?sort:'newest',topic:params.get('topic')||'all'};
}
/** Escape every unsafe byte, including the escape marker, to avoid ID collisions. */
export const publicationAnchor=(id:string)=>`paper-${encodeURIComponent(id).replace(/~/g,'%7E').replace(/%/g,'~')}`;
export function publicationPaperUrl(input:string|URL,paperId:string):URL{
 const url=publicationFilterUrl(input,defaultPublicationFilters);
 url.hash=publicationAnchor(paperId);
 return url;
}
