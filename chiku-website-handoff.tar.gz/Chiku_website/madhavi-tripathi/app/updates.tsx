'use client';
import { ArrowUpRight } from 'lucide-react';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import type { Item } from './content';
import type { SectionCopy } from './site-copy';
import { ResponsiveImage } from './responsive-image';
import { useSectionCarousel } from './use-section-carousel';

function UpdateCard({item}: {item:Item}) {
 return <article className="update-card">
  {item.image&&<ResponsiveImage src={item.image} sources={item.imageSources} focalX={item.focalX} focalY={item.focalY} sizes="(max-width: 800px) 85vw, 46vw" alt={item.imageAlt||item.title} loading="lazy"/>}
  <div className="update-meta"><span>{item.subtitle||'UPDATE'}</span><span>{item.year}</span></div>
  <h3>{item.title}</h3><p>{item.description}</p>
  {item.link&&<a href={item.link} className="quiet-link" target="_blank" rel="noopener noreferrer">Read the story<ArrowUpRight size={15}/></a>}
 </article>;
}

export function Updates({items,copy,motion=true}: {items:Item[];copy:SectionCopy;motion?:boolean}) {
 const {setApi,range,carouselKeys,duration}=useSectionCarousel(motion);
 if(!items.length)return null;
 return <section id="news" className="updates-section updates-showcase section" aria-labelledby="updates-title"><div className="wrap">
  <div className="section-heading reveal"><div><p className="section-kicker"><span>04</span>{copy.navigation.toUpperCase()}</p><h2 id="updates-title" className="editable-heading">{copy.title}</h2></div>{copy.description&&<p>{copy.description}</p>}</div>
  {items.length>1?<Carousel className="updates-carousel" opts={{align:'start',containScroll:'trimSnaps',slidesToScroll:1,inViewThreshold:.6,watchFocus:true,duration}} setApi={setApi} aria-label="Research updates" aria-describedby="updates-carousel-help" tabIndex={0} onKeyDownCapture={carouselKeys}>
   <p id="updates-carousel-help" className="sr-only">Use the previous and next buttons, swipe, or use arrow keys while this carousel is focused to browse the updates.</p>
   <CarouselContent className="updates-track">{items.map((item,index)=><CarouselItem key={item.id} className="update-slide" aria-label={`${index+1} of ${items.length}: ${item.title}`}><UpdateCard item={item}/></CarouselItem>)}</CarouselContent>
   <div className="moment-toolbar updates-toolbar"><p className="moment-position" aria-live="polite" aria-atomic="true"><strong>{range[0]===range[1]?range[0]:`${range[0]}–${range[1]}`}</strong> / {items.length}<span className="sr-only"> updates visible</span></p><div className="moment-carousel-actions"><CarouselPrevious className="moment-arrow" aria-label="Previous updates"/><CarouselNext className="moment-arrow" aria-label="Next updates"/></div></div>
  </Carousel>:<div className="update-single"><UpdateCard item={items[0]}/></div>}
 </div></section>;
}
