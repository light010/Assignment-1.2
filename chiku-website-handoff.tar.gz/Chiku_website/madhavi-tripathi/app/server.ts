import { database } from '@/db';
import { getChatGPTUser, type ChatGPTUser } from './chatgpt-auth';
export { readContentState as readContent } from './content-persistence';
// The verified Site owner may initialize the editor with dispatch-provided identity.
const OWNER_EMAIL='madhavi.tri16@gmail.com';
export async function isEditor(user:ChatGPTUser|null){
 if(!user)return false;
 const db=database();
 const editor=await db.prepare('SELECT user_id FROM editors WHERE user_id = ?').bind(user.userId).first();
 if(editor)return true;
 if(user.email.toLowerCase()!==OWNER_EMAIL)return false;
 await db.prepare('INSERT OR IGNORE INTO editors (user_id, email) VALUES (?, ?)').bind(user.userId,OWNER_EMAIL).run();
 return !!await db.prepare('SELECT user_id FROM editors WHERE user_id = ?').bind(user.userId).first();
}
export async function editorAccess(){return isEditor(await getChatGPTUser());}
export function sameOrigin(request:Request){const origin=request.headers.get('origin');return !!origin&&origin===new URL(request.url).origin;}
