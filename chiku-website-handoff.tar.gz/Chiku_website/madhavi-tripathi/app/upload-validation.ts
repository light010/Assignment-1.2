export type ImageDimensions = { width: number; height: number };
const pngSignature = [137, 80, 78, 71, 13, 10, 26, 10];

/** Reads dimensions from the supported image headers without decoding pixel data. */
export function imageDimensions(bytes: Uint8Array, mime: string): ImageDimensions | null {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let width = 0, height = 0;
  if (mime === 'image/png') {
    if (bytes.length < 33 || !pngSignature.every((value, index) => bytes[index] === value) || new TextDecoder().decode(bytes.slice(12, 16)) !== 'IHDR') return null;
    width = view.getUint32(16); height = view.getUint32(20);
  } else if (mime === 'image/webp') {
    if (bytes.length < 30 || new TextDecoder().decode(bytes.slice(0, 4)) !== 'RIFF' || new TextDecoder().decode(bytes.slice(8, 12)) !== 'WEBP' || view.getUint32(4, true) + 8 > bytes.length) return null;
    const type = new TextDecoder().decode(bytes.slice(12, 16));
    if (type === 'VP8X') {
      width = 1 + bytes[24] + (bytes[25] << 8) + (bytes[26] << 16);
      height = 1 + bytes[27] + (bytes[28] << 8) + (bytes[29] << 16);
    } else if (type === 'VP8L' && bytes[20] === 0x2f) {
      width = 1 + bytes[21] + ((bytes[22] & 0x3f) << 8);
      height = 1 + (bytes[22] >> 6) + (bytes[23] << 2) + ((bytes[24] & 0x0f) << 10);
    } else if (type === 'VP8 ' && bytes[23] === 0x9d && bytes[24] === 1 && bytes[25] === 0x2a) {
      width = view.getUint16(26, true) & 0x3fff;
      height = view.getUint16(28, true) & 0x3fff;
    }
  } else if (mime === 'image/jpeg') {
    if (bytes.length < 4 || bytes[0] !== 0xff || bytes[1] !== 0xd8) return null;
    let position = 2;
    while (position + 3 < bytes.length) {
      if (bytes[position++] !== 0xff) return null;
      while (bytes[position] === 0xff) position++;
      const marker = bytes[position++];
      if (marker === 0xd9 || marker === 0xda || position + 2 > bytes.length) break;
      if (marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) continue;
      const length = view.getUint16(position);
      if (length < 2 || position + length > bytes.length) return null;
      if ([0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf].includes(marker)) {
        if (length < 8) return null;
        height = view.getUint16(position + 3); width = view.getUint16(position + 5); break;
      }
      position += length;
    }
  }
  return width > 0 && height > 0 && width <= 40000 && height <= 40000 && width * height <= 100000000 ? { width, height } : null;
}

function cueTime(value: string) {
  const parts = value.split(':');
  const seconds = Number(parts.pop()), minutes = Number(parts.pop()), hours = Number(parts.pop() || 0);
  return Number.isFinite(hours) && seconds < 60 && minutes < 60 ? hours * 3600 + minutes * 60 + seconds : NaN;
}

/** Restricts uploads to UTF-8 WebVTT caption tracks containing valid timed cues. */
export function validCaptions(bytes: Uint8Array): boolean {
  let text: string;
  try { text = new TextDecoder('utf-8', { fatal: true }).decode(bytes).replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n'); } catch { return false; }
  if (!/^WEBVTT(?:[ \t][^\n]*)?\n/.test(text) || /\u0000/.test(text) || /<(?:script|iframe|object|embed|svg|style)\b/i.test(text)) return false;
  const blocks = text.trim().split(/\n[ \t]*\n/);
  if (!blocks.length || blocks[0].includes('-->')) return false;
  let cues = 0;
  for (const block of blocks.slice(1)) {
    if (/^NOTE(?:[ \t\n]|$)/.test(block)) continue;
    const lines = block.split('\n');
    const index = lines[0].includes('-->') ? 0 : 1;
    const match = lines[index]?.match(/^((?:\d{2,}:)?\d{2}:\d{2}\.\d{3})[ \t]+-->[ \t]+((?:\d{2,}:)?\d{2}:\d{2}\.\d{3})(?:[ \t]+.*)?$/);
    if (!match || !(cueTime(match[2]) > cueTime(match[1])) || !lines.slice(index + 1).join('\n').trim()) return false;
    cues++;
  }
  return cues > 0;
}
