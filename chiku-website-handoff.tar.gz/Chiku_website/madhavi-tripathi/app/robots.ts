import type { MetadataRoute } from 'next';
import { siteOrigin } from './site-metadata';
export default function robots(): MetadataRoute.Robots {
 return { rules: { userAgent: '*', allow: '/', disallow: ['/edit', '/api/'] }, sitemap: `${siteOrigin}/sitemap.xml` };
}
