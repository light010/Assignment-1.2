import { z } from 'zod';

export const initialCopy = {
  hero: { researchAction: 'Explore my research', scholarAction: 'Google Scholar', discover: 'Scroll to discover', topics: 'Drug delivery · Photoacoustics · Ultrasound' },
  achievements: { title: 'The work.\nThe moments behind it.', description: 'Recognition, shared discoveries, and the people along the way.', navigation: 'Highlights' },
  research: { title: 'Small scale.\nWide possibilities.', description: 'Responsive carriers. Optical contrast.\nInformation carried by sound.', navigation: 'Research' },
  publications: { title: 'Selected publications.', description: 'A curated selection. The complete record is on Google Scholar.', navigation: 'Publications' },
  journey: { title: 'Curiosity.\nA constant in motion.', description: '', navigation: 'About' },
  news: { title: 'From the research.', description: '', navigation: 'Updates' },
  contact: { title: 'Good questions.\nNew connections.', description: 'Research, collaboration,\nor a shared curiosity.', navigation: 'Connect' },
  scholar: { title: 'A snapshot of\nthe research.', profileAction: 'Explore the full profile' },
  footer: { tagline: 'Materials. Delivery. Light & sound.' },
};

const label = (fallback: string) => z.string().trim().min(1, 'Add a label.').max(80).default(fallback);
const section = (value: typeof initialCopy.research) => z.object({
  title: z.string().trim().min(1, 'Add a heading.').max(200).default(value.title),
  description: z.string().max(1000).default(value.description),
  navigation: label(value.navigation),
}).default(value);

export const copySchema = z.object({
  hero: z.object({ researchAction: label(initialCopy.hero.researchAction), scholarAction: label(initialCopy.hero.scholarAction), discover: label(initialCopy.hero.discover), topics: z.string().max(200).default(initialCopy.hero.topics) }).default(initialCopy.hero),
  achievements: section(initialCopy.achievements),
  research: section(initialCopy.research),
  publications: section(initialCopy.publications),
  journey: section(initialCopy.journey),
  news: section(initialCopy.news),
  contact: section(initialCopy.contact),
  scholar: z.object({ title: z.string().trim().min(1).max(200).default(initialCopy.scholar.title), profileAction: label(initialCopy.scholar.profileAction) }).default(initialCopy.scholar),
  footer: z.object({ tagline: z.string().max(200).default(initialCopy.footer.tagline) }).default(initialCopy.footer),
}).default(initialCopy);

export type SiteCopy = z.infer<typeof copySchema>;
export type SectionCopy = SiteCopy['research'];

export const initialResearchLinks = new Map<string, string[]>([
  ['breast-imaging-2026', ['photoacoustics']],
  ['ultrasound-coherence-2025', ['ultrasound-imaging']],
  ['mucin-cus-2025', ['nano-materials', 'photoacoustics']],
  ['nanoflakes-2024', ['nano-materials']],
  ['nanohybrids-2023', ['nano-materials', 'photoacoustics']],
]);
