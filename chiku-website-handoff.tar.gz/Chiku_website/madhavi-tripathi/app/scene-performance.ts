export type ScenePreferences = {
  known: boolean;
  reducedMotion: boolean;
  saveData: boolean;
};

// Wait for the visitor's preferences before importing the WebGL bundle.
// Explicit loading can override data saving, but never a motion preference.
export function shouldLoadResearchScene(
  motion: boolean,
  preferences: ScenePreferences,
  requested: boolean,
) {
  return preferences.known && motion && !preferences.reducedMotion &&
    (!preferences.saveData || requested);
}
