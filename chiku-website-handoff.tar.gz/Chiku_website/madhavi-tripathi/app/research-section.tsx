'use client';
import { useState,type CSSProperties,type MouseEvent,type PointerEvent } from 'react';
import { ArrowUpRight,Atom,AudioLines,ChevronDown,Layers3,ScanLine } from 'lucide-react';
import { Collapsible,CollapsibleContent,CollapsibleTrigger } from '@/components/ui/collapsible';
import type { Item } from './content';
import type { SectionCopy } from './site-copy';
import { researchIdentity } from './research-identity';
import { publicationFilterEvent } from './publication-utils';
import { ResponsiveImage } from './responsive-image';

const defaultResearchCopy:SectionCopy={title:'Small scale.\nWide possibilities.',description:'Responsive carriers. Optical contrast.\nInformation carried by sound.',navigation:'Research'};
const researchIcons={materials:Atom,ultrasound:AudioLines,photoacoustic:ScanLine,general:Layers3};
function RelatedPapers({item,count}:{item:Item;count:number}){
 function select(event:MouseEvent<HTMLAnchorElement>){
  if(event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey||!document.getElementById('publications'))return;
  event.preventDefault();window.dispatchEvent(new CustomEvent(publicationFilterEvent,{detail:{topic:item.id}}));
 }
 return <a className="research-related" href={`?topic=${encodeURIComponent(item.id)}#publications`} onClick={select} aria-label={`Related papers for ${item.title}: ${count}`}><span>Related papers <span className="related-paper-count">{count}</span></span><ArrowUpRight size={16}/></a>;
}
function ResearchCard({item,index,papers,motion}:{item:Item;index:number;papers:Item[];motion:boolean}){
 const [open,setOpen]=useState(false);
 const topic=researchIdentity(item),Icon=researchIcons[topic];
 const related=papers.filter(paper=>paper.researchIds?.includes(item.id));
 const story=([['contribution','My contribution'],['approach','Approach'],['outcome','Findings & next questions']] as const).filter(([key])=>item[key]?.trim());
 function tilt(event:PointerEvent<HTMLElement>){
  if(event.pointerType!=='mouse'||!motion||matchMedia('(prefers-reduced-motion: reduce)').matches)return;
  const box=event.currentTarget.getBoundingClientRect();
  event.currentTarget.style.setProperty('--rx',`${-((event.clientY-box.top)/box.height-.5)*5}deg`);event.currentTarget.style.setProperty('--ry',`${((event.clientX-box.left)/box.width-.5)*5}deg`);
  event.currentTarget.style.setProperty('--mx',`${(event.clientX-box.left)/box.width*100}%`);event.currentTarget.style.setProperty('--my',`${(event.clientY-box.top)/box.height*100}%`);
 }
 function untilt(event:PointerEvent<HTMLElement>){event.currentTarget.style.setProperty('--rx','0deg');event.currentTarget.style.setProperty('--ry','0deg')}
 return <article data-research-topic={topic} className={`research-card topic-${topic} reveal`} style={{'--delay':`${index%3*90}ms`} as CSSProperties} onPointerMove={tilt} onPointerLeave={untilt}>
  <div className="research-card-top"><span className="research-icon"><Icon size={31} strokeWidth={1.3} aria-hidden="true"/></span><span className="card-index" aria-hidden="true">{String(index+1).padStart(2,'0')}</span></div>
  {item.image&&<ResponsiveImage className="research-photo" src={item.image} sources={item.imageSources} focalX={item.focalX} focalY={item.focalY} alt={item.imageAlt||item.title} sizes="(max-width: 800px) calc(100vw - 92px), (max-width: 1000px) 45vw, 30vw" loading="lazy"/>}
  <h3>{item.title}</h3>{item.subtitle&&<p className="research-question">{item.subtitle}</p>}{item.description&&<p className="research-description">{item.description}</p>}
  {story.length>0&&<Collapsible open={open} onOpenChange={setOpen} className="research-story"><CollapsibleTrigger className="research-story-trigger" aria-label={`${open?'Close story':'Research story'} for ${item.title}`}>{open?'Close story':'Research story'}<ChevronDown size={16}/></CollapsibleTrigger><CollapsibleContent className="research-story-content"><dl>{story.map(([key,label])=><div key={key}><dt>{label}</dt><dd>{item[key]}</dd></div>)}</dl></CollapsibleContent></Collapsible>}
  <div className="work-links">{related.length>0&&<RelatedPapers item={item} count={related.length}/>}{([['link','Explore research'],['code','Code'],['dataset','Dataset'],['video','Video']] as const).map(([key,label])=>item[key]&&<a key={key} href={item[key]} target="_blank" rel="noopener noreferrer">{label}<ArrowUpRight size={16}/></a>)}</div>
 </article>;
}
export function ResearchSection({items,papers,copy=defaultResearchCopy,motion=true}:{items:Item[];papers:Item[];copy?:SectionCopy;motion?:boolean}){
 const title=copy.title.split('\n');
 return <section id="research" className="research-section section wrap" aria-labelledby="research-title"><div className="section-heading reveal"><div><p className="section-kicker"><span>01</span>RESEARCH DIRECTIONS</p><h2 id="research-title">{title.map((line,index)=>index===0?<span className="heading-first-line" key={index}>{line}</span>:<span key={index}>{line}</span>)}</h2></div>{copy.description&&<p>{copy.description}</p>}</div><div className="research-grid">{items.length?items.map((item,index)=><ResearchCard key={item.id} item={item} index={index} papers={papers} motion={motion}/>):<p>Research themes will be shared here.</p>}</div></section>;
}
