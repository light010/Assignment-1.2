/** Image work runs in the owner's browser before the upload begins. */
export type PreparedImage = { file: File; variants: File[]; optimized: boolean };

function checkAborted(signal?: AbortSignal) {
  if (signal?.aborted) throw new DOMException('Upload cancelled.', 'AbortError');
}

function canvasBlob(canvas: HTMLCanvasElement): Promise<Blob | null> {
  return new Promise(resolve => canvas.toBlob(resolve, 'image/webp', 0.84));
}

export async function prepareImage(file: File, signal?: AbortSignal): Promise<PreparedImage> {
  const original = { file, variants: [], optimized: false };
  checkAborted(signal);
  if (typeof createImageBitmap !== 'function' || typeof document === 'undefined') return original;
  let bitmap: ImageBitmap | undefined;
  try {
    // ImageBitmap applies EXIF orientation. Canvas also removes location metadata.
    bitmap = await createImageBitmap(file, { imageOrientation: 'from-image' });
    checkAborted(signal);
    if (!bitmap.width || !bitmap.height) return original;
    const edge = Math.max(bitmap.width, bitmap.height);
    const largest = Math.min(edge, 1600);
    const sizes = [...new Set([480, 960, largest].filter(size => size <= largest))].sort((a, b) => b - a);
    const files: File[] = [];
    for (const size of sizes) {
      checkAborted(signal);
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(bitmap.width * size / edge));
      canvas.height = Math.max(1, Math.round(bitmap.height * size / edge));
      const context = canvas.getContext('2d');
      if (!context) return original;
      context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      const blob = await canvasBlob(canvas);
      canvas.width = canvas.height = 0;
      checkAborted(signal);
      // Some browsers silently use PNG when WebP encoding is unavailable.
      if (!blob || blob.type !== 'image/webp' || !blob.size) return original;
      files.push(new File([blob], `${file.name.replace(/\.[^.]+$/, '')}-${size}.webp`, { type: 'image/webp' }));
    }
    return { file: files[0], variants: files.slice(1), optimized: true };
  } catch (error) {
    if (signal?.aborted || (error instanceof DOMException && error.name === 'AbortError')) throw error;
    return original;
  } finally {
    bitmap?.close();
  }
}
