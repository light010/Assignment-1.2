import type { Metadata } from 'next';
import './globals.css';
import './color-mode.css';
import './media-upload.css';
import './site-navigation.css';
import './research-navigation.css';
import './gallery.css';
import './updates.css';
import './scene-guide.css';
import './editor-workflow.css';
import { ColorModeProvider } from './color-mode';
export const metadata:Metadata={title:'Madhavi Tripathi | Translational Scientist',description:'The academic home of Madhavi Tripathi. Research, selected publications, and a journey in discovery.',icons:{icon:'/favicon.svg',shortcut:'/favicon.svg'}};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en" suppressHydrationWarning><head><meta name="color-scheme" content="light dark"/></head><body><ColorModeProvider>{children}</ColorModeProvider></body></html>}
