'use client';

import { useEffect, useMemo, useRef, useState, type KeyboardEvent, type MouseEvent } from 'react';
import { ArrowLeft, ArrowRight, ArrowUpRight, Award, Expand, Film, Grid2X2, ImagePlus, Play, X } from 'lucide-react';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { Dialog, DialogClose, DialogContent, DialogDescription, DialogTitle } from '@/components/ui/dialog';
import type { Item } from './content';
import { videoSource } from './media-utils';
import { ResponsiveImage } from './responsive-image';
import { useSectionCarousel } from './use-section-carousel';

type GalleryCopy = {title:string;description:string;navigation?:string};
const defaultCopy:GalleryCopy = {title:'The work.\nThe moments behind it.',description:'Recognition, shared discoveries, and the people along the way.'};

/** A card never mounts a player: only the selected moment in the dialog can play. */
function MomentPreview({item}: {item:Item}) {
 const [failed,setFailed] = useState(false);
 if (!item.image || failed) return <div className={`moment-cover moment-cover-symbol ${item.video?'moment-video-symbol':''}`} aria-hidden="true">{item.video?<Film size={34} strokeWidth={1.4}/>:<Award size={31} strokeWidth={1.4}/>}<span>{failed?'Photo unavailable':item.video?'Video':'From the journey'}</span></div>;
 return <div className="moment-cover"><ResponsiveImage src={item.image} sources={item.imageSources} focalX={item.focalX} focalY={item.focalY} alt={item.imageAlt||item.title} loading="lazy" sizes="(max-width: 640px) 85vw, (max-width: 1000px) 65vw, 44vw" onError={()=>setFailed(true)}/><span className="moment-cover-action" aria-hidden="true">{item.video?<Play size={17} fill="currentColor"/>:<Expand size={17}/>}<span>{item.video?'Watch moment':'View photo'}</span></span></div>;
}

function MomentCard({item,onOpen,compact=false,buttonRef}: {item:Item;onOpen:(event:MouseEvent<HTMLButtonElement>)=>void;compact?:boolean;buttonRef?:(node:HTMLButtonElement|null)=>void}) {
 const hasMedia = Boolean(item.image||item.video);
 return <article className={`moment-card ${item.featured?'moment-featured':''} ${!hasMedia?'moment-without-media':''} ${compact?'moment-grid-card':''}`}>
   {hasMedia&&<MomentPreview key={`${item.image}|${item.video}`} item={item}/>}
   <div className="moment-card-body">
    <div className="moment-meta"><span>{item.subtitle||'Highlight'}</span>{item.year&&<span>{item.year}</span>}</div>
    {!hasMedia&&<Award className="moment-text-symbol" size={28} strokeWidth={1.4} aria-hidden="true"/>}
    <h3><button ref={buttonRef} type="button" className="moment-open" onClick={onOpen} aria-label={`View moment: ${item.title}`}>{item.title}</button></h3>
    {item.description&&<p className="moment-card-description">{item.description}</p>}
    <span className="moment-open-label">{hasMedia?'Explore moment':'Read the story'}<ArrowUpRight size={16} aria-hidden="true"/></span>
   </div>
 </article>;
}

/** Preserve the original feature-and-supporting-card composition. */
function AchievementShowcaseCard({item,featured=false,onOpen}: {item:Item;featured?:boolean;onOpen:(event:MouseEvent<HTMLButtonElement>)=>void}) {
 const [imageFailed,setImageFailed]=useState(false);
 const hasMedia=Boolean(item.image||item.video);
 return <article className={`achievement-card ${featured?'achievement-feature':''}`}>
  {hasMedia?<button type="button" className={`achievement-media ${item.video?'video-cover':'has-media achievement-photo'} ${imageFailed?'media-unavailable':''}`} onClick={onOpen} aria-label={`${item.video?'Watch':'View photo for'} ${item.title}`}>
   {item.image&&!imageFailed&&<ResponsiveImage src={item.image} sources={item.imageSources} focalX={item.focalX} focalY={item.focalY} alt={item.imageAlt||item.title} loading="lazy" sizes={featured?'(max-width: 800px) 90vw, 48vw':'(max-width: 800px) 90vw, 24vw'} onError={()=>setImageFailed(true)}/>}
   {item.video?<span className="achievement-play"><Play size={25} fill="currentColor"/><span>Watch the moment</span></span>:imageFailed?<><ImagePlus size={28}/><span>This photo could not be loaded.</span></>:<span className="photo-expand"><Expand size={17}/><span>View photo</span></span>}
  </button>:<div className={`achievement-media media-reserved ${featured?'reserved-feature':''}`}>
   <div className="reserved-top"><span>{featured?'A MOMENT WORTH SHARING':'FROM THE JOURNEY'}</span><div><ImagePlus size={16}/><Film size={16}/></div></div>
   <div className="reserved-center">{featured?<Award size={46} strokeWidth={1}/>:<ImagePlus size={28} strokeWidth={1}/>}<span>Photos & videos coming soon</span></div><span className="reserved-year">{item.year}</span>
  </div>}
  <div className="achievement-copy"><div className="achievement-meta"><span>{item.subtitle||'HIGHLIGHT'}</span><span>{item.year}</span></div><h3><button className="achievement-title-button" type="button" onClick={onOpen}>{item.title}</button></h3>{item.description&&<p>{item.description}</p>}{item.link&&<a className="quiet-link" href={item.link} target="_blank" rel="noopener noreferrer">Read more<ArrowUpRight size={15}/></a>}</div>
 </article>;
}

function CaptionLoadError({item}: {item:Item}) {
 return <div className="moment-media-message moment-caption-error" role="status"><p>Captions could not be loaded in this player.{item.transcript?' A transcript is available in this moment’s details.':''}</p><a href={item.captions} target="_blank" rel="noopener noreferrer">Open caption file<ArrowUpRight size={15}/></a></div>;
}

function ViewerMedia({item}: {item:Item}) {
 const [failed,setFailed] = useState(false);
 const [captionsFailed,setCaptionsFailed] = useState(false);
 const video = useRef<HTMLVideoElement>(null);
 const source = videoSource(item.video);
 useEffect(()=>{const player=video.current;return()=>{player?.pause()}},[]);
 if(item.video&&source.kind==='file') return <div className="moment-viewer-media"><video ref={video} controls playsInline preload="metadata" poster={item.image||undefined} aria-label={item.title} onError={event=>{if(event.target===event.currentTarget)setFailed(true)}}><source src={source.src} onError={()=>setFailed(true)}/>{item.captions&&<track key={item.captions} kind="captions" src={item.captions} srcLang="en" label="Captions" default onLoad={()=>setCaptionsFailed(false)} onError={event=>{event.stopPropagation();setCaptionsFailed(true)}}/>}</video>{captionsFailed&&<CaptionLoadError item={item}/>} {failed&&<p className="moment-media-message">This video could not be loaded. <a href={source.src} target="_blank" rel="noopener noreferrer">Open the original video<ArrowUpRight size={15}/></a></p>}</div>;
 if(item.video&&source.kind==='embed'){
  const embed = new URL(source.src); embed.searchParams.set('autoplay','0');
  return <div className="moment-viewer-media moment-embed"><iframe src={embed.toString()} title={item.title} allow="fullscreen; picture-in-picture" allowFullScreen referrerPolicy="strict-origin-when-cross-origin"/><p className="moment-embed-note">Use the player controls to play this video. Captions, when provided by the host, are available in the player.</p></div>;
 }
 if(item.video) return <div className="moment-viewer-fallback"><Film size={34} strokeWidth={1.3}/><p>This video is available on its original website.</p>{source.src?<a className="moment-button" href={source.src} target="_blank" rel="noopener noreferrer">Watch video<ArrowUpRight size={16}/></a>:<p>The video link is unavailable.</p>}</div>;
 if(item.image&&!failed) return <div className="moment-viewer-media moment-image"><ResponsiveImage src={item.image} sources={item.imageSources} alt={item.imageAlt||item.title} sizes="(max-width: 1000px) 94vw, 640px" onError={()=>setFailed(true)}/></div>;
 return <div className="moment-viewer-fallback"><Award size={36} strokeWidth={1.2}/><p>{failed?'This photo could not be loaded.':'A moment from the research journey.'}</p>{failed&&<a href={item.image} target="_blank" rel="noopener noreferrer">Open the original photo<ArrowUpRight size={16}/></a>}</div>;
}

export function Achievements({items,canEdit=false,preview=false,motion=true,copy=defaultCopy}: {items:Item[];canEdit?:boolean;preview?:boolean;motion?:boolean;copy?:GalleryCopy}) {
 const ordered = useMemo(()=>[...items].sort((a,b)=>Number(b.featured)-Number(a.featured)),[items]);
 const {setApi,index:spotlightIndex,reduced,carouselKeys,duration}=useSectionCarousel(motion);
 const supporting=ordered.filter((_,index)=>index!==spotlightIndex).slice(0,2);
 const [open,setOpen] = useState(false);
 const [mode,setMode] = useState<'all'|'moment'>('all');
 const [selectedId,setSelectedId] = useState<string|null>(null);
 const returnFocus = useRef<HTMLElement|null>(null);
 const dialogHeading = useRef<HTMLHeadingElement>(null);
 const dialogContent = useRef<HTMLDivElement>(null);
 const collectionButtons = useRef(new Map<string,HTMLButtonElement>());
 const collectionScroll = useRef(0);
 const cameFromCollection = useRef(false);
 const returnToCollection = useRef<string|null>(null);
 const selectedIndex = Math.max(0,ordered.findIndex(item=>item.id===selectedId));
 const selected = ordered[selectedIndex];
 useEffect(()=>{
  if(!open)return;
  if(mode==='all'&&returnToCollection.current){
   const button=collectionButtons.current.get(returnToCollection.current);
   if(button){button.focus({preventScroll:cameFromCollection.current});if(cameFromCollection.current&&dialogContent.current)dialogContent.current.scrollTop=collectionScroll.current}
   else dialogHeading.current?.focus();
   returnToCollection.current=null;
  }else dialogHeading.current?.focus();
 },[mode,open]);
 function openMoment(id:string,event?:MouseEvent<HTMLButtonElement>){if(!open&&event)returnFocus.current=event.currentTarget;cameFromCollection.current=open&&mode==='all';if(cameFromCollection.current)collectionScroll.current=dialogContent.current?.scrollTop||0;setSelectedId(id);setMode('moment');setOpen(true)}
 function openAll(event:MouseEvent<HTMLButtonElement>){returnFocus.current=event.currentTarget;returnToCollection.current=null;setMode('all');setOpen(true)}
 function move(step:number){const next=ordered[selectedIndex+step];if(next)setSelectedId(next.id)}
 function viewerKeys(event:KeyboardEvent<HTMLDivElement>){
  if(mode!=='moment'||event.altKey||event.ctrlKey||event.metaKey||!(event.target instanceof Element)||event.target.closest('video,iframe,input,textarea,select,[role="slider"],[contenteditable="true"]'))return;
  if(event.key==='ArrowLeft'){event.preventDefault();move(-1)}
  else if(event.key==='ArrowRight'){event.preventDefault();move(1)}
 }
 const galleryTitle = copy.title||defaultCopy.title;
 return <section id="achievements" className="achievement-section achievement-showcase" aria-labelledby="achievement-title"><div className="wrap">
  <div className="achievement-heading"><div><p className="section-kicker"><span>IN FOCUS</span>ACHIEVEMENTS & MOMENTS</p><h2 id="achievement-title">{galleryTitle.split('\n').map((line,index)=>index===0?<span className="achievement-heading-first" key={index}>{line}</span>:<span key={index}>{line}</span>)}</h2></div><p>{copy.description}</p></div>
  {ordered.length>1?<Carousel className="achievement-carousel" opts={{align:'start',containScroll:'trimSnaps',slidesToScroll:1,watchFocus:true,duration}} setApi={setApi} aria-label="Achievements and moments" aria-describedby="moment-carousel-help" tabIndex={0} onKeyDownCapture={carouselKeys}>
   <p id="moment-carousel-help" className="sr-only">Browse the featured achievement with the previous and next buttons, swipe, or arrow keys while this carousel is focused. Open any achievement for its full story and media.</p>
   <div className={`achievement-grid ${ordered.length===2?'achievement-grid-pair':''}`}>
    <CarouselContent className="achievement-feature-track">{ordered.map((item,index)=><CarouselItem key={item.id} className="achievement-feature-slide" aria-label={`${index+1} of ${ordered.length}: ${item.title}`} aria-hidden={index!==spotlightIndex} inert={index!==spotlightIndex}><AchievementShowcaseCard key={`${item.image}|${item.video}`} item={item} featured onOpen={event=>openMoment(item.id,event)}/></CarouselItem>)}</CarouselContent>
    {supporting.map(item=><AchievementShowcaseCard key={`${item.id}|${item.image}|${item.video}`} item={item} onOpen={event=>openMoment(item.id,event)}/>)}
   </div>
   <div className="moment-toolbar"><p className="moment-position" aria-live="polite" aria-atomic="true"><strong>{spotlightIndex+1}</strong> / {ordered.length}<span className="sr-only"> featured achievement</span></p><div className="moment-carousel-actions"><CarouselPrevious className="moment-arrow" aria-label="Previous achievement"/><CarouselNext className="moment-arrow" aria-label="Next achievement"/></div><button type="button" className="moment-all" onClick={openAll}><Grid2X2 size={17} aria-hidden="true"/>View all moments<span className="moment-total">{ordered.length}</span></button></div>
  </Carousel>:ordered.length===1?<div className="achievement-single"><AchievementShowcaseCard key={`${ordered[0].image}|${ordered[0].video}`} item={ordered[0]} featured onOpen={event=>openMoment(ordered[0].id,event)}/></div>:<div className="achievement-empty"><ImagePlus size={28} aria-hidden="true"/><p>Photos, films, and milestones will be shared here.</p></div>}
  {canEdit&&!preview&&<a href="/edit?tab=achievements" className="achievement-edit"><ImagePlus size={16} aria-hidden="true"/>Add photos & videos<ArrowUpRight size={15} aria-hidden="true"/></a>}
  <Dialog open={open} onOpenChange={setOpen}><DialogContent ref={dialogContent} className={`moment-dialog ${mode==='all'?'moment-dialog-grid':'moment-dialog-viewer'} ${reduced||!motion?'moment-dialog-no-motion':''}`} showCloseButton={false} onKeyDown={viewerKeys} onOpenAutoFocus={event=>{event.preventDefault();dialogHeading.current?.focus()}} onCloseAutoFocus={event=>{event.preventDefault();returnFocus.current?.focus()}}>
   <div className="moment-dialog-top"><span className="moment-dialog-eyebrow">{mode==='all'?'THE COLLECTION':`MOMENT ${selectedIndex+1} OF ${ordered.length}`}</span><DialogClose asChild><button type="button" className="moment-close" aria-label="Close gallery"><X size={22}/></button></DialogClose></div>
   {mode==='all'?<><DialogTitle ref={dialogHeading} tabIndex={-1} className="moment-dialog-title">All moments</DialogTitle><DialogDescription className="moment-dialog-description">Browse achievements, shared discoveries, and moments from the journey. Select any item to explore it.</DialogDescription><div className="moment-collection">{ordered.map(item=><MomentCard key={item.id} item={item} compact buttonRef={node=>{if(node)collectionButtons.current.set(item.id,node);else collectionButtons.current.delete(item.id)}} onOpen={()=>openMoment(item.id)}/>)}</div></>:selected?<>
    <div className="moment-viewer-layout"><div className="moment-viewer-heading"><p className="moment-meta"><span>{selected.subtitle||'Highlight'}</span>{selected.year&&<span>{selected.year}</span>}</p><DialogTitle ref={dialogHeading} tabIndex={-1} className="moment-dialog-title">{selected.title}</DialogTitle></div><div className="moment-viewer-stage">{open&&<ViewerMedia key={`${selected.id}|${selected.image}|${selected.video}|${selected.captions}`} item={selected}/>}</div><div className="moment-viewer-copy"><DialogDescription className="moment-dialog-description">{selected.description||'A highlight from the research journey.'}</DialogDescription>{selected.link&&<a className="moment-resource" href={selected.link} target="_blank" rel="noopener noreferrer">Read more about this moment<ArrowUpRight size={16}/></a>}{selected.captions&&selected.video&&<a className="moment-resource" href={selected.captions} target="_blank" rel="noopener noreferrer">Open video captions<ArrowUpRight size={16}/></a>}{selected.transcript&&<details className="moment-transcript"><summary>Read transcript</summary><p>{selected.transcript}</p></details>}</div></div>
    <div className="moment-viewer-navigation">{ordered.length>1&&<><button className="moment-button" type="button" disabled={selectedIndex===0} onClick={()=>move(-1)} aria-label="Previous moment"><ArrowLeft size={17}/><span>Previous</span></button><button className="moment-all" type="button" onClick={()=>{returnToCollection.current=selectedId;setMode('all')}}><Grid2X2 size={16}/>All moments</button><button className="moment-button" type="button" disabled={selectedIndex===ordered.length-1} onClick={()=>move(1)} aria-label="Next moment"><span>Next</span><ArrowRight size={17}/></button></>}</div><p className="sr-only" role="status" aria-live="polite">Moment {selectedIndex+1} of {ordered.length}: {selected.title}</p>
   </>:<><DialogTitle ref={dialogHeading} tabIndex={-1} className="moment-dialog-title">This moment is no longer available</DialogTitle><DialogDescription className="moment-dialog-description">Close the gallery to return to the page.</DialogDescription></>}
  </DialogContent></Dialog>
 </div></section>;
}
