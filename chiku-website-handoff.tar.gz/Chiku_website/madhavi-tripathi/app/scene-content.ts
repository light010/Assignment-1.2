export type SceneView='delivery'|'photoacoustic'|'ultrasound';
export const sceneOrder:SceneView[]=['delivery','photoacoustic','ultrasound'];
export type SceneStory={title:string;description:string;link:string};
export type SceneSettings={offerTour:boolean;initialView:SceneView;delivery:SceneStory;photoacoustic:SceneStory;ultrasound:SceneStory};
export const initialScene:SceneSettings={
 offerTour:true,initialView:'delivery',
 delivery:{title:'Small carriers. Purposeful delivery.',description:'A thermoresponsive nanogel brings a drug payload and CuS nanoparticles together, with release designed to respond to heat.',link:'https://etd.iisc.ac.in/handle/2005/6575'},
 photoacoustic:{title:'Light in. Sound out.',description:'Light-absorbing materials generate acoustic signals—connecting nanoscale material design with photoacoustic imaging.',link:'https://doi.org/10.1021/acsanm.3c02405'},
 ultrasound:{title:'From echoes to clearer insight.',description:'Ultrasound transmits sound and receives echoes. My work explores coherence-based imaging to help distinguish breast cysts from solid masses.',link:'https://doi.org/10.1093/radadv/umaf037'}
};
