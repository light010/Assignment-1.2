import { z } from 'zod';
import { initialScene } from './scene-content';
import { researchTopics,researchIdentity } from './research-identity';
import { copySchema, initialCopy, initialResearchLinks } from './site-copy';
const text = z.string().max(10000);
const url = z.string().max(2000).refine(v => !v || /^https?:\/\/[^\s]+$/i.test(v) || /^\/api\/media\/[a-zA-Z0-9.-]+$/.test(v), 'Use a full https:// link.');
const citationCount=z.string().trim().max(9).refine(v=>v===''||/^\d+$/.test(v),'Use a whole, non-negative citation count, or leave it blank.').default('');
const citationDate=z.string().max(10).refine(v=>!v||(/^\d{4}-\d{2}-\d{2}$/.test(v)&&!Number.isNaN(Date.parse(v))&&new Date(v).toISOString().slice(0,10)===v),'Use a valid snapshot date.').default('');
export const imageSourceSchema=z.object({src:url,width:z.number().int().min(1).max(16000),height:z.number().int().min(1).max(16000)});
export type ImageSource=z.infer<typeof imageSourceSchema>;
const item = z.object({
 id:z.string().max(100), title:z.string().trim().min(1, 'Add a title before saving.').max(1000), subtitle:text, description:text, year:z.string().max(40),
 image:url,imageAlt:text,imageSources:z.array(imageSourceSchema).max(4).default([]),focalX:z.number().min(0).max(100).default(50),focalY:z.number().min(0).max(100).default(50),
 link:url,code:url,dataset:url,video:url,captions:url.default(''),transcript:z.string().max(60000).default(''),featured:z.boolean(),citations:citationCount,citationsAsOf:citationDate,
 researchTopic:z.enum(researchTopics).optional(),researchIds:z.array(z.string().max(100)).max(100).optional(),
 contribution:text.default(''),approach:text.default(''),outcome:text.default(''),
}).transform(row=>({...row,researchTopic:researchIdentity(row),researchIds:row.researchIds??initialResearchLinks.get(row.id)??[]}));
const scholarHighlights=z.object({visible:z.boolean(),citations:z.string().max(20),hIndex:z.string().max(20),i10Index:z.string().max(20),asOf:z.string().max(100),affiliation:z.string().max(200),interests:z.string().max(1000)});
const sceneStory=z.object({title:z.string().max(150),description:z.string().max(600),link:url});
// Legacy autoTour is deliberately retired: tours now start only after visitor input.
const sceneSchema=z.object({offerTour:z.boolean().default(true),initialView:z.enum(['delivery','photoacoustic','ultrasound']),delivery:sceneStory,photoacoustic:sceneStory,ultrasound:sceneStory});
export const contentSchema=z.object({name:z.string().trim().min(1).max(100),role:z.string().max(200),affiliation:z.string().max(200),location:z.string().max(200),headline:z.string().max(240),intro:text,bio:text,email:z.string().max(200).refine(v=>!v||/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v),'Enter a valid email.'),photo:url,photoAlt:text,photoSources:z.array(imageSourceSchema).max(4).default([]),photoFocalX:z.number().min(0).max(100).default(50),photoFocalY:z.number().min(0).max(100).default(35),copy:copySchema,cv:url,scholar:url,orcid:url,github:url,linkedin:url,accent:z.enum(['blue','burgundy','forest']),motion:z.boolean().default(true),scene:sceneSchema.default(initialScene),scholarHighlights:scholarHighlights.default({visible:false,citations:'',hIndex:'',i10Index:'',asOf:'',affiliation:'',interests:''}),showNotice:z.boolean(),notice:text,sections:z.object({achievements:z.boolean().default(true),research:z.boolean(),publications:z.boolean(),journey:z.boolean(),news:z.boolean(),contact:z.boolean()}),achievements:z.array(item).max(60).default([]),research:z.array(item).max(100),publications:z.array(item).max(500),journey:z.array(item).max(100),news:z.array(item).max(100)});
export type Content=z.infer<typeof contentSchema>;
export type Item=z.infer<typeof item>;
export type Collection='achievements'|'research'|'publications'|'journey'|'news';
const record=(id:string,values:Partial<Item>):Item=>({id,title:'',subtitle:'',description:'',year:'',image:'',imageAlt:'',link:'',code:'',dataset:'',video:'',featured:false,citations:'',citationsAsOf:'',researchTopic:researchIdentity({id}),researchIds:initialResearchLinks.get(id)??[],imageSources:[],focalX:50,focalY:50,captions:'',transcript:'',contribution:'',approach:'',outcome:'',...values});
export const newItem=():Item=>record(crypto.randomUUID(),{});
export const initialContent:Content={
 name:'Madhavi Tripathi',role:'Translational scientist',affiliation:'Lead Scientist · SynapSeek',location:'Remote',
 headline:'Nanomaterials for delivery.\nLight & sound for imaging.',
 intro:'I develop nanomaterials for drug delivery and explore photoacoustic and ultrasound imaging—connecting how we deliver with how we see.',
 bio:'I am a translational scientist working across biomaterials, drug delivery, ultrasound, and photoacoustic imaging. I earned my Ph.D. in Materials Engineering at IISc and completed postdoctoral training in the PULSE Lab at Johns Hopkins University.\n\nMy work connects material synthesis and biological evaluation with image reconstruction, quantitative analysis, and clinical imaging studies. I now lead scientific and AI/ML strategy at SynapSeek, developing reproducible workflows for a neuro-diagnostic mapping platform.\n\nAlongside research, I mentor junior scientists and serve on the Women in Molecular Imaging Network leadership committee.',
 email:'madhavi.tri16@gmail.com',photo:'',photoAlt:'Madhavi Tripathi',photoSources:[],photoFocalX:50,photoFocalY:35,copy:initialCopy,cv:'',scholar:'https://scholar.google.com/citations?user=zZx1Td0AAAAJ&hl=en',orcid:'https://orcid.org/0000-0002-4736-9134',github:'',linkedin:'https://www.linkedin.com/in/mtri16',accent:'blue',motion:true,scene:initialScene,
 scholarHighlights:{visible:true,citations:'104',hIndex:'',i10Index:'',asOf:'23 September 2026',affiliation:'Johns Hopkins University',interests:'Bioengineering, Nanotheranostics, Bioimaging, Photothermal therapy, Optoacoustic imaging'},
 showNotice:false,notice:'',sections:{achievements:true,research:true,publications:true,journey:true,news:true,contact:true},
 achievements:[
  record('iisc-gold-medal',{title:'Best Thesis Award · Gold Medal',subtitle:'Indian Institute of Science',description:'Recognition for doctoral research in Materials Engineering and cancer theranostics.',year:'2025',featured:true}),
  record('wimin-leadership',{title:'Women in Molecular Imaging',subtitle:'Leadership committee',description:'Contributing to a community of women working in molecular imaging.',year:'2024–present'}),
  record('materials-symposium',{title:'Bringing researchers together',subtitle:'Symposium convener · IISc',description:'Convener of the 36th Annual Symposium of Materials Engineering.',year:'2023'})
 ],
 research:[
  record('nano-materials',{title:'Nanomaterials & drug delivery',subtitle:'How can a carrier respond when it matters?',description:'Designing CuS, CuS–Au, and thermoresponsive nanogel platforms, from synthesis and characterization to drug delivery, 3D tumor models, and preclinical evaluation.',link:'https://etd.iisc.ac.in/handle/2005/6575'}),
  record('ultrasound-imaging',{title:'Ultrasound imaging',subtitle:'What can the echoes tell us more clearly?',description:'Working with DAS and SLSC beamforming, RF-data analysis, and quantitative contrast metrics, including breast cyst and solid-mass characterization.',link:'https://doi.org/10.1093/radadv/umaf037'}),
  record('photoacoustics',{title:'Photoacoustic imaging',subtitle:'How can light and sound reveal more?',description:'Connecting contrast-agent development with sound-speed selection, oxygenation mapping, and target-detectability studies across simulations, phantoms, and clinical images.',link:'https://doi.org/10.1038/s44303-026-00193-4'})
 ],
 publications:[
  record('breast-imaging-2026',{title:'In vivo photoacoustic breast imaging and the interactive effects of skin tone, wavelength, beamformer, and depth on target detectability',subtitle:'Jamie Enslein, Madhavi Tripathi, et al. · npj Imaging',description:'A study of 29 patients examines how skin tone and imaging choices interact to affect photoacoustic target visibility.',year:'2026',link:'https://doi.org/10.1038/s44303-026-00193-4',featured:true}),
  record('ultrasound-coherence-2025',{title:'Generalized contrast-to-noise ratio applied to short-lag spatial coherence ultrasound differentiates breast cysts from solid masses',subtitle:'Arunima Sharma, Eniola T. Oluyemi, Madhavi Tripathi, et al. · Radiology Advances',description:'Evaluates an objective contrast metric with coherence-based ultrasound for distinguishing complicated cysts from solid breast masses.',year:'2025',link:'https://doi.org/10.1093/radadv/umaf037',featured:true}),
  record('mucin-cus-2025',{title:'Mucin-capped CuS nanoparticles for mitochondrial targeted NIR-II photothermal therapy and photoacoustic imaging',subtitle:'Madhavi Tripathi, Ananya Sharma, Victor A. Ajisafe, Sanhita Sinharay & Ashok M. Raichur · Journal of Drug Delivery Science and Technology',description:'Explores mucin-capped copper sulfide nanoparticles for photothermal therapy and photoacoustic imaging.',year:'2025',link:'https://doi.org/10.1016/j.jddst.2025.106668',featured:true}),
  record('nanoflakes-2024',{title:'Effect of PVP Molecular Weights on the Synthesis of Ultrasmall CuS Nanoflakes: Synthesis, Properties, and Potential Application for Phototheranostics',subtitle:'Madhavi Tripathi, Ananya Sharma, Sanhita Sinharay & Ashok M. Raichur · ACS Applied Bio Materials',description:'Investigates how polymer molecular weight influences ultrasmall copper sulfide nanoflakes and their phototheranostic properties.',year:'2024',link:'https://doi.org/10.1021/acsabm.3c01123',featured:true}),
  record('nanohybrids-2023',{title:'Seed-Mediated Galvanic Synthesis of CuS–Au Nanohybrids for Photo-Theranostic Applications',subtitle:'Madhavi Tripathi, Swathi Padmanabhan, Jaya Prakash & Ashok M. Raichur · ACS Applied Nano Materials',description:'Combines copper sulfide and gold in ultrasmall nanohybrids to investigate light-driven heating and photoacoustic contrast.',year:'2023',link:'https://doi.org/10.1021/acsanm.3c02405',featured:true})
 ],
 journey:[
  record('synapseek-current',{title:'Lead Scientist',subtitle:'SynapSeek · Remote',description:'Leading scientific and AI/ML strategy, data pipelines, model evaluation, and validation for a neuro-diagnostic mapping platform.',year:'Feb 2026–present'}),
  record('pulse-lab',{title:'Postdoctoral Research Fellow',subtitle:'PULSE Lab · Johns Hopkins University',description:'Ultrasound and photoacoustic image reconstruction, quantitative analysis, and breast-imaging studies with Prof. Muyinatu A. Lediju Bell.',year:'Dec 2024–Jan 2026',link:'https://pulselab.jhu.edu/people/'}),
  record('phd-iisc',{title:'Ph.D. in Materials Engineering',subtitle:'Indian Institute of Science · Bengaluru',description:'Doctoral research on nanotheranostic platforms for photoacoustic imaging and image-guided therapy. Best Thesis Award / Gold Medal, 2025. Advisor: Prof. Ashok M. Raichur.',year:'March 2025',link:'https://etd.iisc.ac.in/handle/2005/6575'}),
  record('masters-iiit',{title:'Integrated M.Tech. in Biomedical Engineering',subtitle:'Indian Institute of Information Technology · Allahabad',description:'A five-year foundation in biomedical engineering, bringing together engineering methods and biological questions.',year:'July 2018'})
 ],
 news:[
  record('new-imaging-paper',{title:'A closer look at photoacoustic breast imaging',subtitle:'New publication',year:'04 Sep 2026',description:'New work in npj Imaging examines the interacting effects of skin tone and imaging parameters.',link:'https://www.nature.com/articles/s44303-026-00193-4'}),
  record('synapseek-appointment',{title:'A new chapter in translational science',subtitle:'Research appointment',year:'February 2026',description:'Joining SynapSeek as Lead Scientist to lead scientific and AI/ML strategy for neuro-diagnostic mapping.'}),
  record('gold-medal-2025',{title:'IISc Best Thesis Award · Gold Medal',subtitle:'Recognition',year:'2025',description:'Recognition for doctoral research in Materials Engineering.'}),

  record('iisc-research-highlight',{title:'Hybrid nanoparticles in the spotlight',subtitle:'Research feature',year:'11 Sep 2023',description:'IISc shares the story behind copper sulfide–gold nanohybrids and their potential for light-based applications.',link:'https://www.iisc.ac.in/events/hybrid-nanoparticles-shine-new-light-on-targeting-cancer-cells/'})
 ]
};
