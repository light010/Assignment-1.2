import { database } from '@/db';
import { contentSchema, initialContent, type Content } from './content';

type ContentRow={draft:string;published:string;revision:number;updated_at:string;published_at:string|null};
export type ContentMetadata={revision:number;updatedAt:string|null;publishedAt:string|null;hasUnpublishedChanges:boolean};
export type ContentState=ContentMetadata&{draft:Content;published:Content};
export type RevisionSummary={id:string;revision:number;action:'draft'|'publish';createdAt:string;baseline:boolean};
type RevisionRow={id:string;revision:number;action:'draft'|'publish';created_at:string;baseline:number;content?:string};

export function normalizeStoredContent(serialized:string){return contentSchema.parse(JSON.parse(serialized));}
export function contentMetadata(state:ContentState):ContentMetadata{
 return {revision:state.revision,updatedAt:state.updatedAt,publishedAt:state.publishedAt,hasUnpublishedChanges:state.hasUnpublishedChanges};
}
function stateFromRow(row:ContentRow):ContentState{
 const draft=normalizeStoredContent(row.draft),published=normalizeStoredContent(row.published);
 return {draft,published,revision:row.revision,updatedAt:row.updated_at,publishedAt:row.published_at,hasUnpublishedChanges:JSON.stringify(draft)!==JSON.stringify(published)};
}
export async function readContentState():Promise<ContentState>{
 const row=await database().prepare('SELECT draft, published, revision, updated_at, published_at FROM site_content WHERE id = 1').first<ContentRow>();
 return row?stateFromRow(row):{draft:initialContent,published:initialContent,revision:0,updatedAt:null,publishedAt:null,hasUnpublishedChanges:false};
}

/**
 * All statements run in one D1 batch transaction. The random mutation token gates
 * history and retention after the optimistic revision guard. A stale request can
 * therefore neither modify content nor add misleading history entries.
 */
export function contentWriteStatements(db:D1Database,input:{content:Content;revision:number;action:'draft'|'publish';now:string;mutationId:string}){
 const serialized=JSON.stringify(input.content),initial=JSON.stringify(initialContent),publish=input.action==='publish'?1:0,nextRevision=input.revision+1;
 return [
  db.prepare('INSERT INTO site_content (id, draft, published, revision, updated_at) SELECT 1, ?, ?, 0, ? WHERE ? = 0 ON CONFLICT(id) DO NOTHING').bind(initial,initial,input.now,input.revision),
  // Capture starting versions once, without guessing their original publication date.
  db.prepare("INSERT OR IGNORE INTO content_revisions (id, revision, action, content, created_at, baseline) SELECT 'starting-published', revision, 'publish', published, ?, 1 FROM site_content WHERE id = 1 AND revision = ?").bind(input.now,input.revision),
  db.prepare("INSERT OR IGNORE INTO content_revisions (id, revision, action, content, created_at, baseline) SELECT 'starting-draft', revision, 'draft', draft, ?, 1 FROM site_content WHERE id = 1 AND revision = ?").bind(input.now,input.revision),
  db.prepare(`UPDATE site_content SET draft = ?, published = CASE WHEN ? = 1 THEN ? ELSE published END, revision = revision + 1, updated_at = ?, published_at = CASE WHEN ? = 1 THEN ? ELSE published_at END, last_mutation = ? WHERE id = 1 AND revision = ? RETURNING draft, published, revision, updated_at, published_at`).bind(serialized,publish,serialized,input.now,publish,input.now,input.mutationId,input.revision),
  db.prepare('INSERT INTO content_revisions (id, revision, action, content, created_at, baseline) SELECT ?, revision, ?, draft, updated_at, 0 FROM site_content WHERE id = 1 AND revision = ? AND last_mutation = ?').bind(input.mutationId,input.action,nextRevision,input.mutationId),
  db.prepare("DELETE FROM content_revisions WHERE action = 'draft' AND baseline = 0 AND id NOT IN (SELECT id FROM content_revisions WHERE action = 'draft' AND baseline = 0 ORDER BY revision DESC LIMIT 30) AND EXISTS (SELECT 1 FROM site_content WHERE id = 1 AND revision = ? AND last_mutation = ?)").bind(nextRevision,input.mutationId),
  db.prepare("DELETE FROM content_revisions WHERE action = 'publish' AND baseline = 0 AND id NOT IN (SELECT id FROM content_revisions WHERE action = 'publish' AND baseline = 0 ORDER BY revision DESC LIMIT 20) AND EXISTS (SELECT 1 FROM site_content WHERE id = 1 AND revision = ? AND last_mutation = ?)").bind(nextRevision,input.mutationId),
 ];
}

export async function writeContent(input:{content:Content;revision:number;action:'draft'|'publish'}){
 const db=database(),results=await db.batch<ContentRow>(contentWriteStatements(db,{...input,now:new Date().toISOString(),mutationId:crypto.randomUUID()}));
 const saved=results[3]?.results?.[0];
 return saved?contentMetadata(stateFromRow(saved)):null;
}

function revisionSummary(row:RevisionRow):RevisionSummary{
 return {id:row.id,revision:row.revision,action:row.action,createdAt:row.created_at,baseline:!!row.baseline};
}
export async function listContentRevisions(){
 const result=await database().prepare('SELECT id, revision, action, created_at, baseline FROM content_revisions ORDER BY revision DESC, baseline ASC, action DESC LIMIT 52').all<RevisionRow>();
 return result.results.map(revisionSummary);
}
export async function readContentRevision(id:string){
 const row=await database().prepare('SELECT id, revision, action, content, created_at, baseline FROM content_revisions WHERE id = ?').bind(id).first<RevisionRow>();
 return row?.content?{...revisionSummary(row),content:normalizeStoredContent(row.content)}:null;
}
