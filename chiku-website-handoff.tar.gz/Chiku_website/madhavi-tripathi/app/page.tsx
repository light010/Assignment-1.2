import { readContent, editorAccess } from './server';
import { AcademicSite } from './site';
import { profileMetadata, profileStructuredData } from './site-metadata';
export const dynamic='force-dynamic';
export async function generateMetadata(){try{const {published:c}=await readContent();return profileMetadata(c)}catch{return {title:'Madhavi Tripathi | Academic profile'}}}
export default async function Home(){
 try{const [data,canEdit]=await Promise.all([readContent(),editorAccess()]);return <><script type="application/ld+json" dangerouslySetInnerHTML={{__html:JSON.stringify(profileStructuredData(data.published,data.publishedAt)).replace(/</g,'\\u003c')}}/><AcademicSite content={data.published} canEdit={canEdit}/></>}
 catch(error){console.error('Unable to load academic profile',error);return <main className="unavailable"><h1>Madhavi Tripathi</h1><p>The profile is temporarily unavailable. Please try again in a moment.</p><a className="button" href="/">Try again</a></main>}
}
