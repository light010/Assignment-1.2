import type { ImgHTMLAttributes } from 'react';

export type ImageSource = { src: string; width: number; height: number };
type ResponsiveImageProps = ImgHTMLAttributes<HTMLImageElement> & {
  sources?: ImageSource[];
  focalX?: number;
  focalY?: number;
};

function safeSource(source: string): string | null {
  if (typeof source !== 'string' || /[\s\u0000-\u001f\u007f]/.test(source)) return null;
  if (/^\/api\/media\/[a-zA-Z0-9.-]+$/.test(source)) return source;
  try {
    const url = new URL(source);
    if (url.protocol !== 'https:' && url.protocol !== 'http:') return null;
    // A literal comma delimits srcset candidates, even when it belongs to a URL.
    return url.href.replace(/,/g, '%2C');
  } catch { return null; }
}

export function ResponsiveImage({ sources = [], focalX = 50, focalY = 50, style, srcSet, sizes, alt = '', ...props }: ResponsiveImageProps) {
  const unique = new Map<number, ImageSource>();
  for (const source of sources) {
    const src = safeSource(source.src);
    if (src && Number.isInteger(source.width) && source.width > 0 && source.width <= 16000 && Number.isInteger(source.height) && source.height > 0 && source.height <= 16000) unique.set(source.width, { ...source, src });
  }
  const candidates = [...unique.values()].sort((a, b) => a.width - b.width);
  const generated = candidates.map(source => `${source.src} ${source.width}w`).join(', ');
  const clamp = (value: number) => Math.min(100, Math.max(0, Number.isFinite(value) ? value : 50));
  return <img {...props} alt={alt} srcSet={generated || srcSet} sizes={generated || srcSet ? (sizes || '(max-width: 760px) 100vw, 50vw') : undefined} style={{ ...style, objectPosition: `${clamp(focalX)}% ${clamp(focalY)}%` }} />;
}
