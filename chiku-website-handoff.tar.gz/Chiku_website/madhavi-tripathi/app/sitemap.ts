import type { MetadataRoute } from 'next';
import { readContent } from './server';
import { siteOrigin } from './site-metadata';
export const dynamic = 'force-dynamic';
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
 const { publishedAt } = await readContent();
 return [{ url: siteOrigin, ...(publishedAt ? { lastModified: publishedAt } : {}) }];
}
