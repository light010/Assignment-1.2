# Madhavi Tripathi website — start here

This ZIP contains the complete latest published source, including the restored
Achievement layout with a carousel and the Updates carousel.

Source commit: `161690d54eb79c3245419676006e08bf8755e5da`  
Source commit date: `2026-09-23T17:10:42-05:00`  
Existing hosted site: https://madhavi-tripathi.madhavi-tri16.chatgpt.site

## Use it in ChatGPT desktop

1. Extract the ZIP. Open the extracted `madhavi-tripathi` folder as your local
   project in ChatGPT desktop, or make that folder available to its coding task.
2. Paste the contents of `CHATGPT-DESKTOP-PROMPT.txt` into the task. It explains
   the local database, local sign-in identity, preview, and verification steps.
3. Ask ChatGPT to start the local site and inspect it in Browser. Opening a TSX
   file directly in a browser does not run this application.

The source files are preserved from the published commit. The two handoff files
and `SOURCE-MANIFEST.json` were added to this archive only. The existing README
contains notes from earlier stages of the project; use this guide for the current
handoff and `app/content.ts` for the current starting content.

## What is included

- React / TypeScript page and component source; CSS for light and dark modes.
- Three.js nanomaterial delivery, photoacoustic, and ultrasound illustrations.
- Achievement feature carousel, complete media viewer, and Updates carousel.
- Publication search, filters, sorting, related research, and shareable links.
- Owner editor, draft autosave and recovery, revision history, preview, uploads,
  crop controls, captions, and transcripts.
- Backend routes, D1 schema and migrations, R2 integration, and sign-in handling.
- Dependency manifest and lockfile, build configuration, fonts, assets, and
  bundled component/source licenses.

## What is stored separately

Live draft/published content and revision history are stored in the hosted D1
database. Photos, videos, PDFs, and captions uploaded through the editor are
stored in hosted R2. They are not part of a Git source export and are not included
in this ZIP. On a fresh local database, the app starts with `app/content.ts`.

The original attached resume is not a website source file and is not included.
No credentials, environment secrets, browser sessions, installed dependencies,
generated builds, local database files, or Git history are included.

## Local runtime requirements

- Node.js 22.13.0 or later, as specified in `package.json`.
- pnpm 11.25.0, matching the project's `packageManager` declaration.
- A working internet connection for the initial dependency installation.
- Cloudflare's local Workers/D1/R2 emulator, supplied through the declared
  Cloudflare Vite plugin and Wrangler dependencies.

The export intentionally omits this cloud session's `.sites-runtime` directory.
`scripts/execution-profile.mjs` therefore selects the existing **portable** path
on a clean extraction. Do not copy this session's managed preview settings into
your desktop project.

### Setup order

1. Install dependencies from the supplied lockfile:

   ```sh
   pnpm install --frozen-lockfile
   ```

2. Initialize the **local** D1 database using the two SQL migrations under
   `drizzle/`, in order. Have ChatGPT desktop derive the local database binding
   and persistence location from `vite.config.ts` and the installed Cloudflare
   tooling, so the migration command and development server use the same local
   database. Keep deployed migration files unchanged.

3. For local editor testing, the existing portable development sign-in plugin
   uses `local_seedy` / `seedy@sites.test`. After applying the schema, authorize
   that test identity **only in the local emulator's** `editors` table:

   ```sql
   INSERT OR IGNORE INTO editors (user_id, email)
   VALUES ('local_seedy', 'seedy@sites.test');
   ```

   The production owner check in `app/server.ts` remains unchanged. The test
   identity is a development convention, not Madhavi's real account.

4. Start development:

   ```sh
   pnpm dev
   ```

   The portable wrapper requests port 5173. Open the local address printed by
   the server. Visit `/edit` to exercise the local sign-in flow and editor.

5. Verify source and build when making changes:

   ```sh
   pnpm exec tsc --noEmit --incremental false
   pnpm build
   ```

`pnpm run install:ci` is the managed cloud installer and uses Linux-specific
helpers; the direct pnpm installation above is the desktop starting path.
The source was type-checked and built successfully in the hosted environment.
Desktop startup and browser rendering still need to be verified on your machine.

## Common first-launch issues

- **Content unavailable / missing table:** apply the migrations to the same local
  D1 persistence location used by the development server.
- **Owner-only editor message:** verify the local test identity row above exists
  in the local database; keep the production owner check intact.
- **Old uploaded media does not load:** production media objects have not been
  exported; upload local test files through the local editor.
- **Dependency installation fails:** use the pinned pnpm version and inspect the
  actual error before modifying the manifest or lockfile.

## File map

| Area | Files |
| --- | --- |
| Main website | `app/site.tsx`, `app/page.tsx` |
| Starting profile and editable text | `app/content.ts`, `app/site-copy.ts` |
| Achievements and media viewer | `app/achievements.tsx`, `app/gallery.css` |
| Updates | `app/updates.tsx`, `app/updates.css` |
| Shared carousel behavior | `app/use-section-carousel.ts` |
| 3D research illustration | `app/scene.tsx`, `app/nano-renderer.ts`, `app/scene-content.ts` |
| Research and publications | `app/research-section.tsx`, `app/publications.tsx`, `app/publication-utils.ts` |
| Color modes | `app/color-mode.tsx`, `app/color-mode.css`, `app/globals.css` |
| No-code editor | `app/edit/` |
| Content and history storage | `app/content-persistence.ts`, `app/api/content/`, `app/api/history/` |
| Media handling | `app/api/upload/`, `app/api/media/`, `app/image-processing.ts` |
| Database | `db/`, `drizzle/` |
| Local development integration | `vite.config.ts`, `build/sites-vite-plugin.ts`, `scripts/` |
| Existing Sites project binding | `.openai/hosting.json` |

## Continuing the hosted Site

`.openai/hosting.json` retains the existing Site project ID and logical storage
bindings; it contains no access token. Local code and local database edits do not
update the hosted Site. To publish to that same Site, use the Sites plugin with
the authorized account. Keep its current access settings unless you explicitly
choose to change them.

For independent hosting, the Worker deployment, D1/R2 bindings, trusted
authentication, and canonical URL in `app/site-metadata.ts` need appropriate
configuration. This export does not claim to be a static HTML deployment.
