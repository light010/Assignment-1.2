# Madhavi Tripathi — academic website

A responsive academic profile with an owner-only, no-code editor at `/edit`.

## Everyday updates

1. Open the website while signed in with the Site owner's ChatGPT account.
2. Choose **Edit website** in the footer.
3. Fill in Profile, Research, Publications, Journey, or Notes & news.
4. Choose **Save draft** to save privately, **Preview draft** to review, and **Publish changes** to update the visitor page.
5. Appearance lets you change the accent color or hide a section. Photos, CVs, and paper PDFs can be uploaded from the forms.

Only Madhavi's name and current postdoctoral role are confirmed. The starting copy is editable and missing facts are intentionally empty. No affiliation, research area, publication, award, degree, or contact address is invented.

## Implementation

Vinext / React on Cloudflare Workers. D1 stores draft and published documents with optimistic concurrency control. R2 stores photos and PDFs; unpublished assets require editor authorization. Uploaded image and PDF signatures are checked. Every write requires dispatcher-provided ChatGPT identity, server-side editor authorization, and a matching Origin header. The verified Site owner's email bootstraps a stable per-Site user ID in the editor table.

Production schema changes are generated with Drizzle; migration files are immutable after deployment. `.openai/hosting.json` declares logical DB and BUCKET bindings. Site source is versioned by Sites.

The editor optionally registers `stage_academic_profile` with WebMCP. It stages profile fields and never saves or publishes automatically. Browser and WebMCP validation were unavailable in this session because the managed preview service was unavailable. TypeScript, the production build, content validation, and SQL save/publish/conflict checks passed.

## Editorial redesign

The visitor website uses a dark illustrated cover, large serif typography, a section index, research spreads, a publication archive, an editorial timeline, and a blue contact section. Existing draft/published content and all editing controls are preserved. Uploaded portraits replace the abstract cover image.

The original abstract artwork in `public/images/academic-flow.webp` was created once using the built-in image-generation tool, then compressed for the website. Prompt: a sculptural flowing ribbon of fine silver-blue and cobalt filaments on deep ink/navy, concentrated in the center/right with dark space on the left; no text, people, scientific diagrams, data, or specific discipline. It is decorative artwork and does not depict Madhavi's research findings.
