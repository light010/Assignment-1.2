# Local website inspection — 23 September 2026

Preview: http://localhost:5173/  
Local editor: http://localhost:5173/edit

The development server is running in the current Codex task. The hosted URL redirected to OpenAI sign-in, so the authenticated hosted website and its live content were not inspected. All functional and visual results below refer to the local source export.

## Setup and source preservation

- Installed the supplied frozen lockfile with pnpm 11.25.0. Node 25.8.2 meets the declared minimum.
- Kept the existing portable execution path.
- Applied both supplied SQL migrations in order to local D1, using binding `DB`, database ID `00000000-0000-4000-8000-000000000000`, and `.wrangler/state/v3/d1`. The installed Cloudflare Vite plugin uses this same persistence root.
- Added only the documented local editor identity, `local_seedy` / `seedy@sites.test`, to the local emulator.
- Created an ignored helper config at `.sites-runtime/wrangler.local.json`. Downloaded package-manager/cache files are also under `.sites-runtime`.
- Verified all 155 source-file SHA-256 values against `SOURCE-MANIFEST.json`: no source changes, including the manifest, lockfile, production authorization, migrations, and Sites binding.
- No deployment, hosted database access, hosted upload, or sharing change was performed.

To restart from this project directory:

```sh
COREPACK_HOME="$PWD/.sites-runtime/corepack" COREPACK_ENABLE_DOWNLOAD_PROMPT=0 pnpm dev
```

The database is already initialized; do not reapply the initial migrations to it.

## Browser checks performed

| Area | Observed result |
| --- | --- |
| Desktop | Inspected at 1200 and 1440 CSS pixels. The hero and research illustration render. Achievement composition has one large feature and two supporting cards. |
| Mobile | Inspected at 390 CSS pixels, with an additional narrow 325-pixel check. Cards stack, navigation opens and closes, and the page has no horizontal document overflow. |
| Themes | Switched between dark and light modes. Inspected desktop and mobile surfaces, including the photo viewer. |
| Achievement carousel | Next and previous controls change the feature, update the counter, and replace the two supporting cards. Arrow-key advance works. Endpoint focus issue described below. |
| Updates carousel | Advanced through all four updates by button and arrow key. Desktop shows two visible updates; mobile reaches the final single card with a `4 / 4` counter. |
| Moment viewer | Opened collection and individual moments. Arrow keys change the selected moment. Escape closes it and restores focus to the opener. |
| Publication search | `mucin` returns one paper. Combining it with Ultrasound produces the expected empty state. Reset restores all five papers. |
| Publication year and sort | 2025 returns two papers. Oldest-first starts with the 2023 paper and ends with the 2026 paper. Filter changes appear in the URL. |
| Local editor | `/edit` completes the existing local sign-in flow and grants editor access. Required-title validation is displayed. |
| Local image upload | Uploaded a disposable copy of the bundled WebP into a temporary highlight. Observed successful image preparation, local upload, responsive variants, alt-text entry, crop-slider keyboard operation, and draft autosave. |
| Draft preview | Opened the private draft preview and viewed the uploaded image in the media viewer at desktop and phone widths, including light mode. |
| Revision history | Observed starting versions and saved draft revisions. Removed the disposable highlight and saved the draft. Both local draft and published content have the original three highlights, with no differing leaf values. |
| Browser diagnostics | No captured browser warnings or errors in the inspected local tab. |

## Findings and limits

1. **Keyboard focus drops at carousel endpoints.** With focus on Next achievement, advancing to the third/final item disables that button and moves `document.activeElement` to `BODY`. The same behavior was observed at the Updates endpoint. Arrow-key navigation then requires refocusing a carousel control or region. The shared arrow buttons use native `disabled` state in `components/ui/carousel.tsx`; retaining focus with guarded `aria-disabled` controls or moving focus to the carousel region would address this. No fix was applied during this inspection.
2. **Exported media is absent by design.** The local starting profile has an initials portrait and “Photos & videos coming soon” achievement placeholders. The handoff explicitly excludes hosted D1 content and R2 uploads, so this does not establish a defect in the hosted website.
3. **Build size warning.** The production build succeeds but reports a chunk over 500 kB. The minified nanomaterial renderer is approximately 560 kB before compression. Network performance was not benchmarked.
4. **Coverage limits.** Hosted authenticated rendering, real hosted media, video playback/captions, touch swiping, and a full assistive-technology audit were not tested. Photo upload and photo-viewer behavior were tested in the browser.

The removed test highlight remains only in local revision history, and its three uploaded WebP variants remain as unreferenced local test assets. Nothing was published. The copied fixture is in `outputs/inspection-fixtures/`.

## Build checks

- `tsc --noEmit --incremental false`: passed.
- `pnpm build`: passed, with the size warning above.
- Initial local page response: HTTP 200.

