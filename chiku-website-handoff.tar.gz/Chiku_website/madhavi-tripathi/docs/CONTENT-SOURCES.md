# Academic content provenance

Checked 23 September 2026. These are editable starting details, not a live Scholar sync.

- User confirmed name Madhavi Tripathi and current postdoctoral role.
- Exact supplied Scholar profile: https://scholar.google.com/citations?user=zZx1Td0AAAAJ&hl=en . Its indexed result showed Johns Hopkins University, 104 citations, and five interests: Bioengineering, Nanotheranostics, Bioimaging, Photothermal therapy, Optoacoustic imaging. Direct page access was rate limited. The citation count is labeled an indexed snapshot, not a live total. h-index and i10-index are intentionally blank. Scholar affiliation is labeled separately from current institutional affiliation, which remains unset.
- 2026 npj Imaging paper: https://www.nature.com/articles/s44303-026-00193-4 . Published 4 September 2026, 29-patient study. DOI: 10.1038/s44303-026-00193-4.
- 2024 ACS Applied Bio Materials paper: https://pubs.acs.org/doi/10.1021/acsabm.3c01123 . Author list corroborated by https://sinharay.wixsite.com/cancersystemsimaging/publications . DOI: 10.1021/acsabm.3c01123.
- 2023 ACS Applied Nano Materials paper: https://pubs.acs.org/doi/10.1021/acsanm.3c02405 . DOI: 10.1021/acsanm.3c02405. The IISc research feature corroborates the co-first authors and experimental scope: https://www.iisc.ac.in/events/hybrid-nanoparticles-shine-new-light-on-targeting-cancer-cells/ . Experiments do not establish efficacy of a treatment in humans.
- PULSE Lab people page lists Madhavi Tripathi as an alumna, postdoc 2024–2025: https://pulselab.jhu.edu/people/ . This is presented as a dated appointment, not her current laboratory.
- Doctoral thesis defence: https://materials.iisc.ac.in/defence/madhavi-13-dec-2024 . Presented as a defence, without asserting a degree conferral date.
- ORCID from the ACS author record: https://orcid.org/0000-0002-4736-9134 .

Three papers are selected for this site; that number does not represent her complete publication count. Selected paper summaries and research-theme descriptions are editorial paraphrases. Scholar links appear in the navigation, introduction, profile highlights, publications, and professional links.

The 3D sculpture is abstract artwork and is explicitly labeled as such. It is not a structural or experimental scientific model. Photos and public email remain unset because none were supplied.

## Drug delivery and ultrasound refinement

The user explicitly confirmed work in ultrasound and requested a drug-delivery explanation in the hero. The new views distinguish thermally responsive delivery, optical generation of acoustic signals, and ultrasound pulse/echo imaging. Ultrasound is not depicted as the trigger for the thesis carrier's drug release.

The IISc thesis record supports a thermoresponsive nanogel carrying CuS nanoparticles and a drug payload, and exploration of a red-blood-cell membrane coating: https://etd.iisc.ac.in/handle/2005/6575 . The cutaway, particle shapes, movement, timing, apparent material transitions, and imaging scales are conceptual. They are not experimentally calibrated or claimed to reproduce the exact carrier structure.

Ultrasound citation verified in PubMed: https://pubmed.ncbi.nlm.nih.gov/41415217/ . Arunima Sharma, Eniola T. Oluyemi, Madhavi Tripathi, et al., Radiology Advances, 2025, DOI 10.1093/radadv/umaf037. The site uses a short contribution summary and does not label the study's AUC values as diagnostic accuracy. Four papers are now selected on the website.

## Résumé and achievement showcase update

The user supplied `madhavi_2026 (1).pdf` as context and explicitly requested a prime placeholder for forthcoming achievement photos and videos. The résumé supersedes the earlier role and education starting details above: current Lead Scientist at SynapSeek since February 2026; Johns Hopkins PULSE Lab postdoc December 2024–January 2026; IISc Materials Engineering Ph.D. March 2025; integrated Biomedical Engineering M.Tech. at IIIT Allahabad July 2018.

The new gallery sits directly after the hero. Its three initial records use résumé facts: the IISc Best Thesis Award / Gold Medal (2025), WIMIN leadership committee (2024–present), and the 36th Annual Symposium of Materials Engineering convenership (2023). No achievement photography or videos have yet been supplied; the visible frames explicitly say they are coming soon. Owners can upload, replace, feature, and reorder highlights through the Highlights tab; photos and video covers have editable alternative text. Video uploads support MP4 / WebM up to 50 MB, with on-demand YouTube / Vimeo playback as an alternative.

The public email and LinkedIn URL now come from the résumé. The source PDF and its phone number have not been copied into the website. Mentoring, scientific leadership, synthesis, and quantitative ultrasound / photoacoustic analysis descriptions are editorial paraphrases of the résumé. Five papers are now selected: the added 2025 mucin-capped CuS article is cited in the résumé at https://doi.org/10.1016/j.jddst.2025.106668 . This is a curated selection, not a complete publication count. No author-rank claim is made for the ultrasound paper, and the verified published status of the 2026 npj Imaging paper is retained.

Validation: TypeScript and the production build, plus focused local checks for legacy content defaults, upload permissions / signatures / size limits, approved embed hosts, and partial media responses. The supervised preview service was unavailable, so browser visual and playback verification could not be completed in this environment.

## Compact publication browser

Selected publications now occupy a bounded, keyboard-focusable scrolling panel with search, a year filter, and newest / oldest / most-cited / title sorting. Controls remain above the scrolling results; contribution summaries and resource links expand on demand. Current selection, unavailable counts, no-result states, and resetting filters are explicit.

Individual Google Scholar citation counts were not supplied in the résumé and could not be verified during this update (the exact supplied Scholar profile returned HTTP 429). Crossref API reads were unavailable and ACS publisher pages returned HTTP 403. Search snippets and counts from different citation indexes were not combined. No per-paper citation numbers have been invented or inferred from the profile total. The optional count and checked-date fields in the publication editor persist with the existing content document. Blank means unavailable; zero is a real recorded count. Most-cited sorting puts missing counts last, breaks ties by newest year, and explicitly falls back to newest first when the selection has no saved counts. Existing saved content gets blank defaults without a SQL migration or overwriting owner edits.

Focused checks cover numeric citation ordering (including 0 versus unknown), chronological ordering, search plus year filters, empty results, legacy content compatibility, and count / date validation. The preview service remains unavailable for browser inspection.

## Light and dark appearance

Research consulted 23 September 2026:

- Carbon Design System, color roles and layered light / dark surfaces: https://carbondesignsystem.com/elements/color/overview/ and https://carbondesignsystem.com/elements/themes/overview/ .
- W3C text contrast guidance: https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html .
- W3C control / non-text contrast guidance: https://www.w3.org/WAI/WCAG21/Understanding/non-text-contrast.html .
- MDN browser color-scheme and device preference behavior: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/color-scheme and https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@media/prefers-color-scheme .

The visitor theme uses semantic surface, text, border, accent, focus, and shadow roles. Light mode pairs cool white (#f4f7fb / #ffffff), navy text (#14263e), and blue-teal (#12617e). Dark mode pairs midnight navy (#080c14 / #111927) with ice cyan (#9ee6ff). Gold is reserved for achievement recognition; the existing rose and green accent options have corresponding contrast-checked values for both modes. Original photographs and videos are not recolored. The scientific canvas retains a dark instrument stage in both themes to preserve the rendering's bright particle and signal contrast.

The header toggle uses the installed accessible Toggle primitive and next-themes provider, with its own device-local preference key. It follows system preference until a visitor chooses a mode, remembers the override when storage is available, synchronizes through the provider, resolves the stored choice before content paint, and provides CSS system-preference fallbacks. Theme changes do not recreate the Three.js renderer or clear publication filters. The owner editor remains its existing light workspace, and draft previews use the visitor theme.

Checks: server-rendered toggle and theme script, system preferences, saved overrides, unavailable storage, CSS fallback parity, and TypeScript / production build. Among 41 checked text-on-surface pairs per mode, the minimum contrast is 4.78:1 in light and 5.28:1 in dark. Checked control outlines are at least 3.24:1 and 4.24:1 respectively; these are palette checks, not a claim of complete WCAG conformance. Supervised preview remains unavailable, so browser visual inspection is not included in this verification.
