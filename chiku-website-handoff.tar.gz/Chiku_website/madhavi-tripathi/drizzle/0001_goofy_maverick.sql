CREATE TABLE `content_revisions` (
	`id` text PRIMARY KEY NOT NULL,
	`revision` integer NOT NULL,
	`action` text NOT NULL,
	`content` text NOT NULL,
	`created_at` text NOT NULL,
	`baseline` integer DEFAULT false NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_content_revisions_action_revision` ON `content_revisions` (`action`,`revision`);--> statement-breakpoint
ALTER TABLE `site_content` ADD `published_at` text;--> statement-breakpoint
ALTER TABLE `site_content` ADD `last_mutation` text;