# Contract Design — Questions

Upstream: `inception/units-generation/unit-of-work.md`, `…/unit-of-work-dependency.md`,
`inception/domain-design/components.md`, `inception/requirements-analysis/requirements.md`.

The human asked for the design stages to be batched with a single consolidated
approval before code generation, so no question here was put to them
interactively. Each is answered from a decision already confirmed, or resolved by
analysis with the evidence recorded. **Nothing here is a new preference.**

---

## Q1. Which units expose an API consumed outside the system?

**Resolved from the record.** One: `U6 http-api`. It is the only unit declaring
`kind: service` and the only deployed Python executable. Its consumers are the
browser (public reads, owner operations) and — through the generated client —
the two frontend units.

`U7 api-client` is not an external surface; it is the generated consumer side of
`U6`'s contract.

[Answer]: Resolved from confirmed decisions — `U6 http-api` is the single external API surface.

---

## Q2. Integration mechanism per boundary

**Resolved from the record.** Every boundary is **synchronous, in-process** except
one.

| Boundary | Mechanism |
|---|---|
| Browser → frontend | HTTP, server-rendered pages |
| Browser / renderer → `U6` | **Synchronous HTTP, same origin**, via a Next.js `rewrites()` entry. Same-origin because a cross-site session cookie is unreliable under third-party-cookie restrictions |
| `U6` → `U3`, `U4`, `U5` | In-process Python calls |
| `U4` → `U2` `ContentStore` | In-process, one combined transactional call |
| `U3` → `U2` `IdentityStore` | In-process |
| `U5` → `U2` `AssetStore`, `ContentStore`, and `U4` | In-process |
| `U11` → the three ports | Implements the same interfaces |

No queue, no event bus, no scheduler, no gRPC. Nothing in scope is asynchronous.

[Answer]: Resolved — synchronous HTTP at the one external boundary, in-process calls everywhere else. No async mechanisms.

---

## Q3. Contract ownership

**Resolved from the record.** The provider owns the spec in every case.

- `U6` owns the OpenAPI document. It is generated from the Pydantic models, not hand-maintained.
- `U2` owns the three port interfaces. `U11` implements them and may not change them.
- `U7`'s types are **generated output**, owned by nobody — regenerated at the gate, and the gate fails if the committed output is dirty.

[Answer]: Resolved — provider owns each spec; the client's types are generated output, not an owned artifact.

---

## Q4. Versioning and breaking-change policy

**Resolved from the record.** There is no external consumer to version against:
one owner, one browser, one deployment, no public API clients, no remote.

A backend change that breaks the frontend fails `tsc --noEmit` at the same merge
gate, with a file and a line, because the frontend's types are generated from the
backend's document and regenerated at that gate. That is the versioning policy:
**breaking changes are caught synchronously rather than negotiated across
versions.** No URL versioning, no deprecation window, no parallel schema support.

Additive changes stay safe by the ordinary rule — consumers ignore unknown fields.

[Answer]: Resolved — no versioning scheme. Breaking changes fail the type check at the same gate; there is no independently-deployed consumer to protect.

---

## Q5. Error, timeout and retry behaviour at each boundary

**Resolved from confirmed decisions.** The error envelope is **ported, not
designed** (FR10.1, hazard): `{error: "<sentence>"}` plus `issues: [{path, message}]`
on validation failure, statuses 400 / 403 / 409 / 413 / 503, produced by exception
handlers rather than per route. FastAPI's defaults would break the editor's field
highlighting and conflict recovery while appearing to work.

Retry policy: the client retries **nothing** automatically. A 409 is a conflict the
owner resolves; a 503 is surfaced with the owner's edits intact. Automatic retry of
a mutation is forbidden — the write is not idempotent and a retried publish would
consume a revision.

[Answer]: Resolved — the ported envelope and taxonomy; no automatic client retry of any mutation.

---

## Q6. Do the three port contracts assume relational semantics Firestore does not provide?

**This was the stage's one genuinely open question**, carried from units-generation
with `contract-design` as its named owner. It is a technical question with a
determinate answer, so it is resolved here by analysis rather than by asking.

Three specific worries were recorded:

1. **A transaction spanning documents.** `ContentStore`'s combined write touches
   the content document, inserts one revision entry, and prunes retired entries —
   at most 1 + 1 + 50 documents. Firestore transactions in Native mode operate
   across multiple documents. The combined write fits. **No conflict**, with one
   constraint: the prune must stay bounded, which retention already guarantees
   (30 draft + 20 publish + 2 permanent baselines).
2. **Compare-and-set.** Firestore transactions read then write, retrying on
   contention. Reading the current revision inside the transaction and asserting it
   matches the caller's base revision reproduces the compare-and-set exactly. The
   `last_mutation` token remains necessary for the same reason it is necessary in
   SQLite — it guards the *side effects*, whose guard condition is not unique to
   the writer. **No conflict.**
3. **Ordered pagination with multi-key tie-breaks.** `RevisionLedger`'s listing is
   `revision DESC, baseline ASC, action DESC`. Firestore supports composite
   ordering, but it **requires a composite index to be declared explicitly** —
   unlike SQLite, which will scan. This is the one real asymmetry, and it is a
   deployment artifact rather than a contract change. **No conflict**, with an
   obligation: the deployment plan must carry the index definition, and the
   conformance suite must assert the three-part order so a missing index surfaces
   as a failing test rather than as a silently different list.

One further asymmetry, not previously recorded: **Firestore has no
`DELETE ... WHERE id NOT IN (subquery)`.** The retention prune must be expressed as
read-the-survivors-then-delete-the-rest inside the transaction. That shape works in
both adapters and is therefore what the **port** specifies — the port must not
expose a SQL-shaped prune that only SQLite can satisfy.

**Corrected at review.** The analysis above was incomplete. Finding R-01 identified
a fourth incompatibility it missed: **Firestore's 1,048,576-byte per-document
limit** against FR4.6's ceiling of 1,500,000 decoded characters, which in UTF-8 can
exceed 4 MB. A revision entry stores the full content, so a save this port is
required to accept cannot fit in one Firestore document. SQLite has no such limit,
so the verified adapter is unaffected. Resolved in C2's `payload_size` clause.

[Answer]: Resolved by analysis, then corrected at review — three obligations (bounded prune, declared composite index, read-then-delete prune) plus the 1 MiB per-document limit the first pass missed, resolved by an external content-addressed blob path on the Firestore adapter only.

