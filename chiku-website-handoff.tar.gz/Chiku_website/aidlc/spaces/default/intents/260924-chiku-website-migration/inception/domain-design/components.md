# Component Catalogue — chiku-website runtime-split migration

**Upstream:** `inception/requirements-analysis/requirements.md`,
`codekb/Chiku_website/architecture.md`, `codekb/Chiku_website/component-inventory.md`,
`inception/practices-discovery/team-practices.md`.

Entities are captured at **ownership and shape** only — owner, identifier,
attribute names, cross-component references. Types, constraints, allowed values
and cardinality belong to Functional Design.

## Part A — catalogue

```yaml
components:
  - name: PublicSite
    summary: Renders the published website for visitors. Frontend only; decides nothing.
    behaviour: >
      Server-renders the published content document fetched from HttpApi, including every
      enabled section, the publication browser with its search, year filter and four sort
      orders, the three-dimensional research illustration honouring the motion flag and
      offering its tour only after visitor input, and the light/dark appearance resolved
      before first paint. Derives page metadata, Open Graph, Twitter card and ProfilePage
      structured data from the same content, and serves the sitemap and robots responses.
      Renders the unavailable page when the content cannot be loaded. Carries no
      application decision: it does not authenticate, does not authorise, does not validate
      authoritatively, and never touches storage.
    responsibilities:
      - Every public route and its rendered output
      - The discoverability surface derived from content
      - Visitor-side presentation state (appearance preference, filter state in the URL)
    depends_on:
      - component: ApiClient
        interaction: Fetches the published content document and the viewer's session state
        style: sync
    dependents: []
    external_dependencies:
      - name: Node.js runtime
        kind: other
        purpose: Server-side rendering for the public routes
    entities: []

  - name: OwnerEditor
    summary: The owner's no-code editing surface. Frontend only; decides nothing.
    behaviour: >
      Presents every editing surface that exists today, autosaves drafts after an idle
      period, suspends autosave while an upload is in flight or a conflict is unresolved or
      a recovered draft awaits a decision, warns before leaving with unsaved work, and
      renders the private draft preview in an isolated frame. Keeps unsaved work in
      per-tab browser storage. On recovery it does NOT decide whether the draft is
      salvageable: it submits the recovered draft to ContentAuthority's inspect operation
      and renders the verdict returned, offering the repaired draft for review or reporting
      it unusable. The rule separating a recoverable field problem from a corrupt record is
      a correctness rule the previous system got wrong, so it lives in Python; the editor
      holds the bytes and renders the answer. There is a THIRD recovery state, distinct from
      both verdicts: when the inspect request fails or the backend is unreachable, the editor
      HOLDS the draft, shows an unavailable-and-retry state, and never discards it. Silently
      discarding on a transport failure would reproduce the exact class of loss this
      requirement exists to prevent, so the unreachable case is a specified state rather than
      an error path. Registers the browser tool that stages
      profile text fields into the form and never saves or publishes. Client-side
      validation exists for responsiveness only and is generated from the backend schema
      document, never hand-written.
    responsibilities:
      - Every editing surface, its autosave and conflict states
      - Per-tab local retention of unsaved work, and rendering the recovery verdict it is given
      - Holding an unclassifiable draft when inspect is unavailable, and never discarding it
      - The private draft preview
      - The browser tool registration
    depends_on:
      - component: ApiClient
        interaction: Reads and writes content, lists and restores revisions, uploads media, signs in and out
        style: sync
    dependents: []
    external_dependencies:
      - name: Browser storage
        kind: other
        purpose: Per-tab retention of unsaved work
    entities: []

  - name: ApiClient
    summary: The frontend's only route to the backend. Generated types plus a thin HTTP client.
    behaviour: >
      Exposes typed operations for every backend endpoint. Its TypeScript types are
      generated from HttpApi's OpenAPI document and committed, so a backend field rename
      fails the frontend type check with a file and a line rather than surfacing as a
      runtime error. Sends credentials on same-origin requests, attaches the CSRF token to
      mutations, and surfaces the backend's error envelope unchanged so callers can branch
      on the conflict status and read field-level issues. Holds no business rule and
      caches nothing.
    responsibilities:
      - The generated contract types
      - Transport, credentials and CSRF token attachment
      - Faithful propagation of the error envelope
    depends_on:
      - component: HttpApi
        interaction: Every backend operation, over HTTP on the same origin
        style: sync
    dependents:
      - component: PublicSite
        interaction: Published content and session state
      - component: OwnerEditor
        interaction: Content, revisions, uploads, authentication
    external_dependencies: []
    entities: []

  - name: HttpApi
    summary: The Python HTTP surface. Where the language boundary physically is.
    behaviour: >
      Exposes every operation as a route, keeps handlers thin, and owns exactly one error
      envelope across the whole surface - a single message field plus field-level issues on
      validation failure - mapped once from a four-member exception taxonomy rather than
      constructed per route. Applies request-context, origin and CSRF middleware. Publishes
      the OpenAPI document that ApiClient's types are generated from. Enforces nothing
      itself beyond transport concerns: every authorization decision belongs to the
      component behind the route, so a request that bypasses the frontend is rejected
      identically to one that does not.
    responsibilities:
      - Route definitions and the request/response envelope
      - The error taxonomy mapping and its status codes
      - Origin and CSRF middleware, request context
      - The OpenAPI document
    depends_on:
      - component: OwnerIdentity
        interaction: Sign-in credential verification and owner provisioning
        style: sync
      - component: SessionAuthority
        interaction: Session issue, verify and revoke on every request
        style: sync
      - component: LoginGuard
        interaction: Rate-limit check before and after a sign-in attempt
        style: sync
      - component: ContentAuthority
        interaction: Read content state, inspect a recovered draft, save draft, publish
        style: sync
      - component: RevisionLedger
        interaction: List revisions, fetch one by id
        style: sync
      - component: MediaIntake
        interaction: Accept an upload
        style: sync
      - component: MediaDelivery
        interaction: Serve an asset, including range requests
        style: sync
    dependents:
      - component: ApiClient
        interaction: Every backend operation
    external_dependencies: []
    entities: []

  - name: OwnerIdentity
    summary: The single owner account, its credential, and how it comes to exist.
    behaviour: >
      Verifies a supplied password against an argon2id hash and answers only whether it
      matched, never why. Provisions the initial owner exactly once: while no owner record
      exists and the bootstrap secret is configured, a single one-shot provisioning
      operation accepts the chosen password and stores only its hash. The gate is the
      existence of the owner record, not a consumed flag, so a restart cannot reopen it.
      With no secret configured and no owner present the service starts and refuses every
      sign-in rather than creating an account. No default, seeded or sample credential
      exists anywhere.
    responsibilities:
      - The owner record and its credential hash
      - Credential verification
      - One-shot initial provisioning and its gate condition
    depends_on:
      - component: IdentityStore
        interaction: Reads and writes the owner record
        style: sync
    dependents:
      - component: HttpApi
        interaction: Sign-in verification and provisioning
    external_dependencies: []
    entities:
      - name: OwnerAccount
        identifier: ownerId
        attributes: [ownerId, email, passwordHash, createdAt, passwordUpdatedAt]

  - name: SessionAuthority
    summary: Issues, verifies and revokes owner sessions. The root of trust for every protected operation.
    behaviour: >
      Issues a session on successful credential verification and returns it as a signed
      cookie marked HttpOnly, Secure and SameSite=Lax. Expires a session after eight hours
      idle, sliding within that window, and seven days absolute regardless of activity.
      Verifies the session on every protected request and returns the owner identity or
      nothing. Revokes server-side on sign-out, so a stolen cookie stops working rather
      than merely disappearing from one browser. Issues and verifies the CSRF token paired
      with the session. Refuses to start when the signing key is absent, empty or too
      short - no default, and explicitly no auto-generated per-process key, which would
      look like it works while silently invalidating every session on restart.
    responsibilities:
      - Session issue, verification, sliding and absolute expiry, revocation
      - The CSRF token paired with a session
      - Signing-key presence as a startup precondition
    depends_on:
      - component: IdentityStore
        interaction: Persists and revokes session records
        style: sync
    dependents:
      - component: HttpApi
        interaction: Session verification on every request; issue on sign-in; revoke on sign-out
    external_dependencies: []
    entities:
      - name: Session
        identifier: sessionId
        attributes: [sessionId, issuedAt, lastSeenAt, absoluteExpiresAt, revokedAt, csrfToken]
        references:
          - entity: OwnerAccount
            owned_by: OwnerIdentity
            relationship: each Session belongs to exactly one OwnerAccount

  - name: LoginGuard
    summary: Bounds failed sign-in attempts per account and per source address.
    behaviour: >
      Counts failed sign-in attempts in a rolling window, per account and per source
      address independently. Refuses further attempts beyond five per account per fifteen
      minutes or twenty per source address per fifteen minutes. The refusal message is the
      same as an ordinary credential failure, so it reveals neither whether the account
      exists nor whether the limit was reached. A successful sign-in clears that account's
      counter.
    responsibilities:
      - The rolling failure counters and their windows
      - The refusal decision, phrased so it enumerates nothing
    depends_on:
      - component: IdentityStore
        interaction: Persists attempt counters so a restart does not reset them
        style: sync
    dependents:
      - component: HttpApi
        interaction: Checked before a sign-in attempt and updated after it
    external_dependencies: []
    entities:
      - name: LoginAttemptWindow
        identifier: windowKey
        attributes: [windowKey, scope, failureCount, windowStartedAt]

  - name: ContentAuthority
    summary: Owns the content document, its authoritative validation, and the draft-to-published lifecycle.
    behaviour: >
      Holds the single content document in its draft and published forms. Validates every
      write authoritatively and returns field-level issues on failure. Saves a draft or
      publishes, both under optimistic concurrency on the revision number, rejecting a
      write whose base revision no longer matches and returning current state so the caller
      can reconcile. Critically, the same write also guards its side effects with a token
      unique to the request rather than with the resulting revision number, because that
      number is not unique to the writer - without it a losing writer would record history
      carrying the winner's content and prune revisions it had no right to prune. Rejects a
      body over one million five hundred thousand characters of decoded text, counting
      characters rather than bytes so that no document the previous system accepted is
      refused. Resolves the two content-carrying schema defaults rather than defaulting them
      empty, and preserves an explicitly emptied list as empty. Owns a short-lived cache of
      the published document and invalidates it on publish. Also exposes an inspect
      operation over a candidate document that returns the normalised document plus each
      issue classified as recoverable or corrupting - the rule the editor's draft recovery
      renders rather than decides. Performs the write itself as ONE combined ContentStore
      call carrying the content update, the revision entry and the retention prune, using
      the retention policy RevisionLedger supplies; no transaction context crosses a
      component boundary and nothing else writes revision rows.
    responsibilities:
      - The content document in both forms and its schema
      - Authoritative validation, the issue list it returns, and each issue's recoverable-or-corrupting classification
      - The draft-save and publish operations, their concurrency guard and their side-effect guard
      - Executing the single combined write that carries content, revision and prune together
      - The request-size limit and its unit
      - The published-document cache and its invalidation
    depends_on:
      - component: ContentStore
        interaction: One combined compare-and-set write carrying content, revision entry and retention prune
        style: sync
      - component: RevisionLedger
        interaction: Obtains the retention policy to include in that write; does not delegate the write itself
        style: sync
    dependents:
      - component: HttpApi
        interaction: Read content state, inspect a recovered draft, save draft, publish
      - component: MediaDelivery
        interaction: Supplies the current published document for the asset-visibility test
    external_dependencies: []
    entities:
      - name: ContentDocument
        identifier: documentId
        attributes: [documentId, draft, published, revision, updatedAt, publishedAt, lastMutation]

  - name: RevisionLedger
    summary: The history of saved drafts and publishes, and what is kept.
    behaviour: >
      Records one entry per accepted write, carrying the content as written, the action and
      the time. Lists entries with a three-part ordering that is load-bearing for what the
      owner sees - revision descending, then non-baseline before baseline, then publish
      before draft - capped at the current limit. Fetches one entry by identifier for
      restoration into the editor, which never publishes. Retains the most recent thirty
      draft entries and twenty publish entries, and keeps the two starting baselines
      permanently. Reports a missing or no-longer-retained identifier as absent while
      stating the current draft is unaffected. **Owns the retention policy but performs no
      write.** The prune happens inside ContentAuthority's single combined write, using the
      policy this component supplies, so one transaction never has to span two components
      and no transaction context crosses a boundary. This component's own ContentStore use
      is read-only.
    responsibilities:
      - The retention policy - how many of each action are kept, and which entries are permanent
      - The listing order and its tie-breaks
      - Reading revision entries and fetching one by identifier
    depends_on:
      - component: ContentStore
        interaction: Reads and lists revision entries; performs no write
        style: sync
    dependents:
      - component: HttpApi
        interaction: List revisions, fetch one by id
      - component: ContentAuthority
        interaction: Supplies the retention policy carried inside the single combined write
    external_dependencies: []
    entities:
      - name: ContentRevision
        identifier: revisionEntryId
        attributes: [revisionEntryId, revision, action, content, createdAt, baseline]
        references:
          - entity: ContentDocument
            owned_by: ContentAuthority
            relationship: each ContentRevision is a past state of the one ContentDocument

  - name: MediaIntake
    summary: Accepts uploads, decides what is acceptable, and derives what is served.
    behaviour: >
      Accepts only the seven permitted file kinds and determines the kind by inspecting the
      file's own bytes rather than trusting its declared type or extension, reproducing the
      existing accept and reject decisions including their endianness and field-order
      quirks. Enforces the existing size ceilings per kind. Validates a caption track as
      well-formed timed text with at least one cue. Generates the responsive image variants
      server-side from the uploaded original, so the browser no longer prepares them and the
      surface that verified browser-prepared variants disappears. Leaves no orphaned blob and
      no orphaned record when an upload fails or is cancelled, and never lets cleanup mask
      the original error.
    responsibilities:
      - Accept and reject decisions, made from file bytes
      - Size ceilings and caption-track validation
      - Server-side variant generation
      - Orphan-free failure and cancellation
    depends_on:
      - component: AssetStore
        interaction: Writes the original and each derived variant, and removes them on failure
        style: sync
      - component: ContentStore
        interaction: Registers and removes asset metadata
        style: sync
    dependents:
      - component: HttpApi
        interaction: Accept an upload
    external_dependencies:
      - name: Image processing library
        kind: third-party-api
        purpose: Decoding uploaded images and producing responsive variants
    entities:
      - name: Asset
        identifier: assetKey
        attributes: [assetKey, filename, mediaType, byteSize, width, height, createdAt, derivedFrom]

  - name: MediaDelivery
    summary: Serves stored assets, and decides which the public may see.
    behaviour: >
      Serves an asset only when its key is well formed. Treats an asset as publicly readable
      if and only if the literal media path for its key appears anywhere in the serialised
      published document - including inside a transcript, the biography, any description, the
      notice, or any editable copy block. A structured field check is explicitly not
      equivalent: it would make strictly fewer assets public and would return not-found for
      an image referenced from prose. An asset that is not public is served only to the
      authenticated owner and is reported as absent rather than forbidden, so the response
      does not disclose that the key exists. Reproduces the existing range behaviour branch
      for branch, including that a head request never inspects the range header, that there
      is deliberately no not-modified path despite an entity tag being emitted, and the four
      non-obvious range outcomes. Emits the existing protective headers.
    responsibilities:
      - The asset-visibility rule, preserved exactly
      - Range handling, branch for branch, and the head-versus-get divergence
      - Not-found rather than forbidden for a non-public asset
      - The protective response headers
    depends_on:
      - component: AssetStore
        interaction: Reads asset bytes, whole or by range
        style: sync
      - component: ContentStore
        interaction: Reads asset metadata
        style: sync
      - component: ContentAuthority
        interaction: Obtains the current published document for the visibility test
        style: sync
    dependents:
      - component: HttpApi
        interaction: Serve an asset, including range requests
    external_dependencies: []
    entities: []

  - name: ContentStore
    summary: Persistence port for the content document and its revision ledger.
    behaviour: >
      Defines the operations ContentAuthority and RevisionLedger need. Its central
      operation is ONE compare-and-set write that carries the content update, the revision
      entry and the retention prune together as a single atomic call made by a single
      caller - because splitting them across callers is precisely what the side-effect
      guard exists to prevent, and because a transaction that spans two components cannot
      be expressed in a port contract without leaking a connection handle through it. Also carries asset metadata, which is row-shaped
      rather than blob-shaped. Two adapter families implement it: one for local verified
      operation and one for the cloud target. The port is what the conformance suite tests;
      neither adapter is.
    responsibilities:
      - The persistence contract for content, revisions and asset metadata
      - Atomicity of the compare-and-set write and its side effects
    depends_on: []
    dependents:
      - component: ContentAuthority
        interaction: Content reads and compare-and-set writes
      - component: RevisionLedger
        interaction: Revision reads and listing only; it performs no write
      - component: MediaIntake
        interaction: Asset metadata registration and removal
      - component: MediaDelivery
        interaction: Asset metadata reads
    external_dependencies:
      - name: SQLite
        kind: database
        purpose: The locally verified adapter, durable through a mounted volume
      - name: Firestore
        kind: database
        purpose: The cloud adapter, written against the same port and shipped unverified against the real service
    entities: []

  - name: IdentityStore
    summary: Persistence port for the owner account, sessions and login counters.
    behaviour: >
      Defines the operations OwnerIdentity, SessionAuthority and LoginGuard need. Separate
      from ContentStore because identity has a different reason to change and a different
      sensitivity: a change to session handling should not touch the file that writes
      content. Two adapter families, as with ContentStore.
    responsibilities:
      - The persistence contract for the owner record, sessions and attempt counters
    depends_on: []
    dependents:
      - component: OwnerIdentity
        interaction: Owner record reads and writes
      - component: SessionAuthority
        interaction: Session persistence and revocation
      - component: LoginGuard
        interaction: Attempt-counter persistence
    external_dependencies:
      - name: SQLite
        kind: database
        purpose: The locally verified adapter
      - name: Firestore
        kind: database
        purpose: The cloud adapter, shipped unverified against the real service
    entities: []

  - name: AssetStore
    summary: Persistence port for asset bytes.
    behaviour: >
      Defines put, get, get-by-range, head and delete for opaque binary objects. Separate
      from the row-shaped ports because a blob and a row are not the same kind of thing and
      their cloud implementations are entirely different services. Range reading is part of
      the port rather than something MediaDelivery does after loading a whole object,
      because loading a whole video to serve one range is the thing the port exists to avoid.
    responsibilities:
      - The binary object contract, including ranged reads
    depends_on: []
    dependents:
      - component: MediaIntake
        interaction: Writes originals and variants; removes them on failure
      - component: MediaDelivery
        interaction: Reads bytes, whole or by range
    external_dependencies:
      - name: Local filesystem volume
        kind: object-store
        purpose: The locally verified adapter, durable across container recreation
      - name: Cloud Storage
        kind: object-store
        purpose: The cloud adapter, shipped unverified against the real service
    entities: []
```

## Part B — human view

### Component diagram

```mermaid
graph TD
  PublicSite -->|published content| ApiClient
  OwnerEditor -->|content, revisions, uploads, auth| ApiClient
  ApiClient -->|HTTP, same origin| HttpApi
  HttpApi -->|verify credential| OwnerIdentity
  HttpApi -->|issue, verify, revoke| SessionAuthority
  HttpApi -->|rate-limit check| LoginGuard
  HttpApi -->|read, save, publish| ContentAuthority
  HttpApi -->|list, fetch| RevisionLedger
  HttpApi -->|accept upload| MediaIntake
  HttpApi -->|serve asset| MediaDelivery
  OwnerIdentity -->|owner record| IdentityStore
  SessionAuthority -->|session records| IdentityStore
  LoginGuard -->|attempt counters| IdentityStore
  ContentAuthority -->|one combined write: content + revision + prune| ContentStore
  ContentAuthority -->|retention policy| RevisionLedger
  RevisionLedger -->|read, list| ContentStore
  MediaIntake -->|asset bytes| AssetStore
  MediaIntake -->|asset metadata| ContentStore
  MediaDelivery -->|asset bytes, ranged| AssetStore
  MediaDelivery -->|asset metadata| ContentStore
  MediaDelivery -->|published document| ContentAuthority
```

Text fallback: the two frontend components reach the backend only through
`ApiClient`, which speaks to `HttpApi` and nothing else. `HttpApi` fans out to
the seven backend components. Those reach persistence only through the three
ports. `ContentAuthority` calls `RevisionLedger` only to obtain the retention policy it
carries inside its own single combined write, so the transaction never spans two
components; `MediaDelivery` calls `ContentAuthority` for the published document its
visibility test needs. There are no cycles.

### Component summary

| Component | Purpose | Depends On | Dependents | Entities Owned |
|---|---|---|---|---|
| PublicSite | Renders the published site | ApiClient | — | — |
| OwnerEditor | The owner's editing surface | ApiClient | — | — |
| ApiClient | Generated types plus transport | HttpApi | PublicSite, OwnerEditor | — |
| HttpApi | The HTTP surface and error envelope | OwnerIdentity, SessionAuthority, LoginGuard, ContentAuthority, RevisionLedger, MediaIntake, MediaDelivery | ApiClient | — |
| OwnerIdentity | The owner account and its credential | IdentityStore | HttpApi | OwnerAccount |
| SessionAuthority | Session issue, verify, revoke | IdentityStore | HttpApi | Session |
| LoginGuard | Failed-attempt bounding | IdentityStore | HttpApi | LoginAttemptWindow |
| ContentAuthority | The content document, its lifecycle, and the one combined write | ContentStore, RevisionLedger | HttpApi, MediaDelivery | ContentDocument |
| RevisionLedger | History reads, ordering, and the retention policy | ContentStore | HttpApi, ContentAuthority | ContentRevision |
| MediaIntake | Upload acceptance and derivation | AssetStore, ContentStore | HttpApi | Asset |
| MediaDelivery | Asset serving and visibility | AssetStore, ContentStore, ContentAuthority | HttpApi | — |
| ContentStore | Content persistence port | — | ContentAuthority, RevisionLedger, MediaIntake, MediaDelivery | — |
| IdentityStore | Identity persistence port | — | OwnerIdentity, SessionAuthority, LoginGuard | — |
| AssetStore | Binary object port | — | MediaIntake, MediaDelivery | — |

### Entity ownership

| Entity | Owning Component | Identifier | Attributes | References |
|---|---|---|---|---|
| OwnerAccount | OwnerIdentity | ownerId | ownerId, email, passwordHash, createdAt, passwordUpdatedAt | — |
| Session | SessionAuthority | sessionId | sessionId, issuedAt, lastSeenAt, absoluteExpiresAt, revokedAt, csrfToken | OwnerAccount (each Session belongs to exactly one OwnerAccount) |
| LoginAttemptWindow | LoginGuard | windowKey | windowKey, scope, failureCount, windowStartedAt | — |
| ContentDocument | ContentAuthority | documentId | documentId, draft, published, revision, updatedAt, publishedAt, lastMutation | — |
| ContentRevision | RevisionLedger | revisionEntryId | revisionEntryId, revision, action, content, createdAt, baseline | ContentDocument (each ContentRevision is a past state of the one ContentDocument). **Write note:** `RevisionLedger` owns this entity, its ordering and its retention policy, but does **not** write it — `ContentAuthority` performs the insert and the prune inside its one combined write, under the policy `RevisionLedger` supplies (ADR-001). Reading this table alone would otherwise suggest `RevisionLedger` is the writer. |
| Asset | MediaIntake | assetKey | assetKey, filename, mediaType, byteSize, width, height, createdAt, derivedFrom | — |

### External dependencies

| Component | Dependency | Kind | Purpose |
|---|---|---|---|
| PublicSite | Node.js runtime | other | Server-side rendering for the public routes |
| OwnerEditor | Browser storage | other | Per-tab retention of unsaved work |
| MediaIntake | Image processing library | third-party-api | Decoding uploads and producing responsive variants |
| ContentStore | SQLite | database | Locally verified adapter, durable through a mounted volume |
| ContentStore | Firestore | database | Cloud adapter, shipped unverified against the real service |
| IdentityStore | SQLite | database | Locally verified adapter |
| IdentityStore | Firestore | database | Cloud adapter, shipped unverified against the real service |
| AssetStore | Local filesystem volume | object-store | Locally verified adapter, durable across container recreation |
| AssetStore | Cloud Storage | object-store | Cloud adapter, shipped unverified against the real service |

### Rationale

| Component | Why it is a separate building block |
|---|---|
| PublicSite | Distinct concern and distinct change rate: visitor presentation changes for design reasons, never for rule reasons. Separating it is what makes "the frontend decides nothing" checkable. |
| OwnerEditor | Distinct lifecycle from the public site: it changes when editing capability changes, and it is the only frontend that mutates anything. |
| ApiClient | Distinct concern: it is the single place the language boundary is crossed, and making it one component is what lets a gate check assert nothing else crosses. |
| HttpApi | Distinct concern: transport, the error envelope and the published contract. Its separation is what keeps route handlers thin and keeps the envelope in one place rather than per route. |
| OwnerIdentity | Distinct data ownership and distinct sensitivity: the credential is the highest-value datum in the system and nothing else should be able to read it. |
| SessionAuthority | Distinct lifecycle: a session's rules change for security reasons, independently of who the owner is. Separating it also means the signing-key startup precondition has one clear home. |
| LoginGuard | Distinct change rate and distinct data: counters are ephemeral and their thresholds are tuned separately from anything about identity. |
| ContentAuthority | Distinct data ownership: it owns the one document every other component reads and none may write. The concurrency and side-effect guards live with the data they protect. |
| RevisionLedger | Distinct lifecycle: the retention policy and the listing order are separately testable rules that change for different reasons than concurrency does. It stays separate from ContentAuthority even though it no longer writes, because a policy that is read and applied elsewhere is still a policy with one owner. |
| MediaIntake | Distinct concern: deciding what may enter the system is input validation, and it carries the system's largest untrusted-input surface. |
| MediaDelivery | Distinct concern from intake: what may leave, and to whom, is an access-control question. Merging the two would put an access rule and a validation rule in one place with no boundary between them. |
| ContentStore | Distinct concern: persistence mechanism, separable so the same rules run against a local and a cloud implementation and are proven by one conformance suite. |
| IdentityStore | Distinct reason to change from content: session handling should not be edited in the file that writes content. |
| AssetStore | Distinct shape: a blob is not a row, its cloud implementation is a different service entirely, and ranged reading belongs in the port rather than above it. |

### Alternatives rejected

- **One store for everything.** Fewest adapters and one conformance suite, but a
  single interface spanning content, identity and blobs, where a session change
  edits the same file as a content write. Rejected at the gate in favour of three
  ports. Recorded as ADR-001.
- **One port per owning component.** Perfectly aligned with entity ownership and
  twelve adapters for a single-owner website. This is the generic-repository
  shape the affirmed practices forbid, reached from the opposite direction.
  Recorded as ADR-001.
- **Split `PublicApi` and `OwnerApi`.** Would make the protected surface
  structurally obvious, but the media route is public when its asset is published
  and owner-only otherwise, so the split fails exactly where it would matter
  most — and two documents would mean two generated clients. Recorded as ADR-003.
- **The published-document cache in `MediaDelivery`.** Puts the remedy next to the
  cost, but invalidation would have to cross a component boundary on publish, and
  a second reader would silently miss it. Recorded as ADR-002.

## Assumptions & Open Questions

- **[assumption]** `ContentStore` carries asset *metadata* while `AssetStore`
  carries asset *bytes*. The alternative — metadata inside `AssetStore` — would
  give `MediaDelivery` one dependency instead of two, but would put a row-shaped
  concern inside a blob port whose cloud implementation has no query capability.
- **[assumption]** `ContentAuthority` calling `RevisionLedger` inside a single
  write means both must share one transaction through `ContentStore`. Contract
  Design must make that atomicity explicit in the port signature; if it cannot,
  the two components merge rather than the guarantee weakening.
- **[open, owner `functional-design`]** Whether the editor's multi-flag save
  state machine lives in `OwnerEditor` or moves behind `HttpApi`. It is placed in
  `OwnerEditor` here because it is presentation state, but if any part of it turns
  out to be a rule rather than a display concern, it crosses the boundary. The
  adjacent question — where the draft-recovery classification lives — is now
  **closed**: review finding R-01 established it as a correctness rule, so it sits
  behind `ContentAuthority` and the editor renders the verdict.
- **[resolved]** The atomicity tension recorded in ADR-001 is closed rather than
  deferred. Review finding R-02 showed the graph as originally drawn already forced
  the fallback: `ContentAuthority` delegated the revision write to `RevisionLedger`,
  which made its own store call, so one transaction would have had to span two
  components. `ContentAuthority` now performs one combined write and `RevisionLedger`
  owns the retention policy and the read side. Nothing is left for Contract Design
  to discover.
- **[assumption]** No component here is a background worker, scheduler or queue
  consumer. Retention runs inside the write that triggers it, as it does today.
