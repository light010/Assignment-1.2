**Collaborator:** aidlc-quality-agent

## Contribution

Scope of this review: testing posture and quality gates only. Code style and security tooling are
out of my lane and I have not judged them.

The section is well-reasoned and its two hardest calls — that no org floor reaches a custom scope,
and that a percentage is the wrong instrument for the hazard modules — are both right. What it is
missing is an **oracle**, an **enforcement mechanism**, and **branch** rather than line
granularity. All three of the named high-risk behaviours survive the posture exactly as drafted.

### 1. Methodology: `test-after` is the wrong pick. Use `custom`.

The oracle in this project is "the old system did X". That oracle exists *before* any Python is
written — it is enumerated branch-by-branch in `code-quality-assessment.md` and
`api-documentation.md`. When the oracle predates the implementation, test-after throws away its
only advantage and keeps all of its cost.

The failure mode is specific, not generic. Under test-after, a developer who misreads a dense
source line implements from the misreading and then writes the test **from the same misreading**.
The test is green, coverage is satisfied, and the defect ships. `evidence.md` D1 already names
this; the draft nonetheless picks the option it describes as unsafe. That would be acceptable if
something downstream caught it, but nothing does: take hazard 3 as the worked example. A port that
declares `research_topic: Topic | None = None` and `research_ids: list[str] = []` passes `ruff`,
passes `mypy --strict`, passes `tsc`, passes the Compose end-to-end flow, and can reach 100% line
coverage. Every gate in the draft's merge-gate list goes green on a build where the research
section renders three identical slate cards and the publications topic filter returns zero results
for every theme. Only a test whose assertion came from the *source* behaviour catches it.

`tdd` across the board is equally wrong: most of the ported render layer has no enumerated oracle,
and writing failing render assertions first for ported JSX is waste. The honest value is `custom`,
and `custom` only means something if the Ordering field spells it out — which is what the next
item does.

Note this is **characterization testing**, not TDD, and the distinction is load-bearing: the test
is written from the documented behaviour of the source, so a test written from a *wrong reading of
the document* is still wrong. See item 4 for the fix (record the behaviour, do not transcribe it).

Proposed replacement:

> - **Methodology**: `custom` — characterization-test-first for every behaviour on the hazard
>   register and for the storage port; test-after everywhere else.

### 2. The Ordering sentence is not executable. Four readings, three undefined cases.

Current text: *"For each unit, implement the Python backend behaviour first, then write and run
that unit's backend tests against the behaviour enumerated in the reverse-engineering knowledge
base before the unit is considered done; the frontend render layer for that unit is ported and
smoke-tested only after its backend tests are green."*

- **"first" does double duty.** It carries both the test-vs-code axis and the backend-vs-frontend
  axis in one word. A reader can take "implement the backend first" as "before the frontend" and
  then read the test clause as unsequenced.
- **Frontend-only units are undefined.** Several units will have no backend surface (a static
  public page port). Read literally, such a unit can never start, because it has no backend tests
  to make green.
- **Units whose behaviour is not in the knowledge base are undefined.** The sentence names one
  oracle and most units do not have an entry in it. What is the oracle for the rest?
- **"done" is defined twice** — once here, once by the merge-gate bullet. `org.md` requires Code
  Generation to resolve `Ordering` independently of coverage and tooling; a definition of done
  embedded in the ordering field breaks that separation. Delete it here; the merge gate owns
  "done".

Proposed replacement:

> - **Ordering**: Within each unit, the characterization tests for that unit's hazard-register
>   behaviours are written and observed to fail before that behaviour's Python implementation
>   exists; every other backend test is written immediately after the code it covers; the unit's
>   frontend render layer is ported only once the unit's backend tests pass; a unit with no
>   backend surface begins at the frontend step.

### 3. Coverage floor: keep a number, but change the metric and add a second floor.

**Position: 80% *branch* coverage aggregate over `backend/`, plus 100% branch coverage on a named
hazard-module list. No numeric floor on the frontend.**

- **Branch, not line.** This is the most important single change in my review and it costs one
  flag. All three high-risk behaviours are branches or fallback chains — `??` precedence in
  `researchIdentity`, the `isPublic` short-circuit before `editorAccess()`, the
  `AND last_mutation = ?` guard. Line coverage marks a `??` line covered when *one* side is
  exercised, so the `[]`-preserving path in hazard 3 and the guard-fails path in hazard 1 count as
  covered while never running. Turn on `--cov-branch`.
- **80% is the right aggregate number.** Not because 80 is special, but because the aggregate
  floor's only job here is anti-drift on modules nobody finds interesting, and arguing 75 against
  85 is not worth a gate's attention. Keep the draft's exclusions.
- **The second floor is what makes the first one safe.** 80% aggregate over a backend that is 100%
  new is close to "test the code you wrote"; the hazard modules are a small share of total lines,
  so the aggregate can be green with the ABA token entirely untested. Enforce it as a second
  report over the same coverage data, which makes the draft's unenforceable "a test per enumerated
  branch" into a command:

  ```
  coverage report --fail-under=80                     # aggregate
  coverage report --fail-under=100 --include=<hazard module globs>
  ```

  The `--include` list is the hazard register (item 7) and changing it is a reviewed edit, not a
  developer's discretion.
- **Frontend: agree there is no percentage, disagree with the replacement.** "The page mounts and
  its top-level landmarks are present" passes identically in the correct world and in the hazard-3
  world. Replace the count-of-smoke-tests requirement with **named assertions** (item 5, M6).

### 4. With no CI, nothing in the draft stops untested code being called done.

The draft lists seven commands and calls that a merge gate. Nothing runs them. There is no CI, no
PR, no remote, and the AI-DLC stage gate is a human approving prose — so as written, "the
verification commands pass" is a developer's unverified assertion at the moment it matters most.
Three mechanisms, in increasing order of how much they actually bind:

1. **One committed entry point.** A single `make verify` (or `scripts/verify.sh`) that runs the
   whole list and exits non-zero on first failure. Removes any argument about what "the commands"
   were on a given day, and makes the gate a thing that can be *run* rather than a list to be
   followed.
2. **A committed hook.** `.githooks/pre-commit` calling `make verify`, with `core.hooksPath` set to
   `.githooks`. `git merge --squash` leaves changes staged and the subsequent `git commit` fires
   `pre-commit`, so this catches the squash-merge the draft describes. Record explicitly that
   `--no-verify` voids the Bolt on the same footing as weakening a gate.
3. **Evidence at the gate — this is the actual answer.** Mechanisms 1 and 2 are bypassable by
   anyone in a hurry, and on a single-developer project with no second pair of eyes that is not a
   hypothetical. The only lever the framework really has here is the artifact the human reads.
   **Require the Bolt's `build-and-test` artifact to carry the verbatim tail of the `make verify`
   run** — exit status, the `pytest` summary line, both `coverage report` totals, and the
   `docker compose` health output — and make a gate approval without it a refusal. That converts
   "it passed" into "here is the output", which is the difference between a gate and a promise.

Proposed replacement for the merge-gate bullet:

> - **Merge gate (the CI substitute)**: a Bolt may squash-merge to `main` only when `make verify`
>   exits zero on the developer machine. It runs, in order: `ruff check`, `ruff format --check`,
>   `mypy`, `pytest --cov --cov-branch`, both `coverage report` floors, `tsc --noEmit`,
>   `pnpm lint`, and the Docker Compose end-to-end verification. The run's verbatim tail — exit
>   status, pytest summary, both coverage totals, Compose health output — is pasted into the
>   Bolt's build-and-test artifact, and the stage gate is not approved without it. Gates protect
>   the parity guarantee; weakening one, or committing with `--no-verify`, voids the Bolt.

### 5. Test types for the two-runtime split

Mandatory (M) and optional (O), with what each is *for*.

**M1 — Recorded source-behaviour fixtures. Mandatory, and it must happen before any port.** This
is the draft's largest omission. The source app is runnable today; every hazard except the D1 batch
internals is HTTP-observable. Drive the running `madhavi-tripathi/` app with `httpx` once and
record as golden fixtures: every public route's rendered HTML, `GET /api/content`, the media route's
status codes across public / draft-only / missing keys, the 413 boundary in both characters and
UTF-8 bytes, byte-range responses across all six rejection branches, and the stored-row state
after a save / publish / conflict sequence. *For:* turning "the old system did X" from prose into
data. Every other test on this list asserts against a human's reading of a document until this
exists; after it exists they assert against the system. It also costs about half a day and it is
the only item here with an expiry date — once the source is retired or drifts, it cannot be made.

**M2 — Backend unit tests. Mandatory.** *For:* branch-level behaviour of ported logic — schema
transforms and defaulting chains, the upload validators and the three image header parsers
(endianness differs per format and JPEG stores height before width), the WebVTT grammar, the
byte-range parser, `parseRecovery`'s allowlist. Hazard 3 and runners-up R2/R3 live here.

**M3 — Storage-port contract tests. Mandatory, parameterized over two adapters.** Cloud is
plan-only, so only the SQLite/volume family will be implemented. Write the suite as an
adapter-parameterized conformance suite and run it against the real adapter **and an in-memory
fake** — two implementations is the minimum that proves the suite tests the *port contract* rather
than SQLite's behaviour, and it is what lets the Firestore/GCS adapter plug in later at zero
additional test cost, which is the entire argument for having a port. *For:* CAS semantics, the
ABA token, history insert, retention, idempotent baseline creation. Hazard 1 lives here.

**M4 — API contract tests. Mandatory, but not in the obvious form.** Testing a FastAPI app against
its own generated OpenAPI is circular — the schema is derived from the code, so it agrees with the
code by construction and proves nothing. Two things that are not circular and are both mandatory:
(a) assert the **generated** schema against the **hand-written** contract from `contract-design` —
status codes, error body shape, header names, the 409 and 413 contracts; (b) commit the generated
`openapi.json` as a snapshot so any unintended contract change surfaces as a diff at the merge
gate rather than as a frontend 422 three Bolts later.

**M5 — End-to-end through Docker Compose. Mandatory, and per-Bolt.** Taking a position on D6:
**per-Bolt**. With no CI, the per-merge run *is* the CI, and the alternative is a container-level
regression surfacing many Bolts after the one that caused it with no bisect signal and nobody
watching a dashboard. Keep the cost bounded by keeping the e2e flow small and fixed — the
skeleton's two paths plus one auth-failure path — so it stays inside a few minutes on cached
layers. *For:* the language boundary, the session-cookie contract against TLS termination, and
volume permissions. None of those exist outside a composed run.

**M6 — Frontend render checks. Mandatory, but the draft has no tooling for them.** `tsc --noEmit`
and ESLint cannot execute a component, so the current "render smoke test" requirement has nothing
behind it. Cheapest resolution, and my recommendation: **do not add a frontend test framework** —
assert against the HTML returned by the composed stack (M5) using M1's recorded fixtures, since the
frontend renders only and the parity oracle is HTML anyway. If component-level isolation is wanted
later, that is Vitest plus `@testing-library/react`, and it should be named as a new dependency
rather than assumed. Either way the assertions must be **named**, not "landmarks present": for each
of the three original research cards the topic class and icon are distinct; the publications topic
filter returns non-zero for each seeded theme; each research card shows non-zero related papers.

**O1 — Browser checks (Playwright). Optional, with one condition that flips it.** *For:* what only
a real browser does — `localStorage` draft recovery and its 500-key scan cap, the
unsaved-changes/`beforeunload` path, client-side upload validation UX. **If the six-flag editor
state machine is ported to the frontend rather than to the backend, a browser check becomes the
only possible verification of it and this becomes mandatory.** The draft lists the editor state
machine as behaviour-critical without noticing that where it lands decides whether it is testable
at all. Flag that as a dependency on `domain-design`.

**O2 — Visual parity. Optional as screenshots; I recommend DOM-structure diff instead.** This is
D8, which `evidence.md` correctly calls the largest gap, and the draft offers the human no
recommendation. Take one: **normalized DOM-structure comparison against M1's recorded HTML** —
strip volatile attributes, build hashes and whitespace, then diff the element tree plus text
content per route. It catches what actually breaks in a port (a dropped section, a wrong class, a
missing copy default among the 25 leaf defaults) at a fraction of the setup cost of pixel
screenshots and without their flakiness. Pixel comparison should be rejected explicitly, not left
as a live option.

### 6. How each high-risk behaviour actually gets covered

None of the three fails loudly, so "run it and look" is not a backstop for any of them.

**Hazard 1 — the `last_mutation` ABA token.** No coverage percentage, no single-writer test and no
end-to-end flow reaches this; its absence is observable *only* at an interleaving, so the test must
create the interleaving deliberately. Required, in M3: reproduce the documented sequence — row at
revision 5, writers A and B both read revision 5, B commits, then A's batch runs — and assert three
things, because the token's loss shows up in the second and third, not the first: A receives 409;
the history table gained **exactly one** row and it is B's; **no row was pruned**. Build it on a
test seam that holds A between its read and its batch — not threads and sleeps, because a
sleep-based race test is flaky and will be deleted within a month. Three more in the same suite:
pin the batch's statement order structurally so the `results[3]` positional dependency fails a test
instead of silently converting successful writes into 409s; assert the retention boundary at
30+20+2=52 including the baseline-pair case where `ORDER BY revision DESC` is not tiebreak-stable;
assert `baseline = 1` rows are never pruned and that a second baseline insert is idempotent under
concurrency.

**Hazard 2 — the media access rule.** The tests that matter assert the *surprising* direction,
because a "clean" reimplementation that derives public-ness from structured fields is strictly more
correct-looking and silently wrong. Required: an asset URL pasted into a free-text field (the
60,000-character `transcript`) makes that asset return 200 to an anonymous request; an asset
referenced only from a section toggled off via `sections.*` is still public; a draft-only asset is
denied anonymously and served to the authenticated owner; `/api/media/0.webp` does not match inside
`/api/media/1230.webp`; and — the one nobody writes — a stored document that fails validation makes
the media route, `/`, and `/api/content` **all** return 503 together. Every one of these is
HTTP-observable, so they come directly from M1 recorded against the source and replayed against the
Python backend. This is the clearest case for why M1 pays for itself. These are access-control
assertions, so the set should be handed to whoever owns the security test suite rather than living
only in my lane.

**Hazard 3 — the `researchIdentity` / `initialResearchLinks` shims.** Required: parse a stored
document carrying the three original card ids with **no** `researchTopic` and assert `'materials'`,
`'ultrasound'`, `'photoacoustic'` — not `None`, not `'general'`; assert an explicit `researchTopic`
beats the map; assert the transform runs on read-from-storage, not only on write; construct
`initialContent` from scratch and assert all five seeded publications carry their documented
`researchIds`, since a fresh install depends entirely on the shims; and add the two frontend
assertions from M6. The single most important one, and the one most likely to be skipped because
`[]` reads as "unset": **an item with `researchIds` explicitly set to `[]` stays `[]` and is never
repopulated from the map.** That test is exactly the difference between a correct port
(`if x is None`) and a wrong one (`x or default`), and nothing else on the gate list distinguishes
them.

### 7. What is asserted as practice but is an untested proposal

`evidence.md` handles this honestly — its discovered-vs-proposed table is the best thing in the
pair. The problem is structural: **the provenance lives in the file that is discarded and is absent
from the file that persists.** The OPEN blockquotes are removed at promotion by design, so
`team.md` will end up reading as though `test-after` and 80% were discovered practice on this
project. Fix it with one sentence that survives promotion, at the head of `## Testing Posture`:

> No testing practice was observed on this project: the source ships zero tests, no test framework,
> no `test` script and no testing dependency. Every item in this section is a decision taken at
> practices-discovery on 2026-09-24, not an inherited practice, and each is revisable on evidence
> from the first Bolts.

Beyond the items already flagged as OPEN, these read as settled and are not:

- **The Ordering sentence** — no precedent, and not flagged even as OPEN. It is a proposal.
- **The tooling versions** — `evidence.md` records them as "given, not independently verified", but
  the draft states them as settled. Python 3.14 with pytest 9.1.1, mypy 2.3.1 and ruff 0.16.8 is a
  specific combination, and if any of it fails to resolve the merge gate is undefined on day one.
  Make proving the toolchain resolves and `make verify` runs green on an empty project the
  **first** task of the skeleton Bolt, and mark the versions provisional until it does.
- **"Behaviour-critical modules carry a test per enumerated branch"** — as written this is
  unenforceable: no list of modules, no definition of "enumerated branch", no command that checks
  it. It becomes real as a **committed hazard register** (one row per behaviour: source location,
  documented behaviour, the test id that covers it, the recorded M1 fixture it asserts against),
  whose module paths are the `--include` list in item 3's second coverage report.
- **The merge-gate command list** — a proposal, and unenforced until item 4 exists.
- **The frontend render smoke test** — a proposal with no tooling behind it (M6).

## Positions

- AGREE: No numeric coverage floor on the frontend — a percentage over a render-only layer measures JSX traversal, not behaviour.
- AGREE: The 80% floor is chosen rather than inherited; the custom-scope reading of `org.md` is correct and stating it explicitly is worth the words.
- AGREE: Per-branch requirements on hazard modules instead of a percentage — a percentage cannot distinguish "exercised" from "ported correctly".
- AGREE: Recording that there is no existing suite to keep green, so a future reader does not assume a regression baseline exists.
- AGREE: pytest plus `httpx` for transport-level FastAPI tests is the right shape, and `ruff`/`mypy` as gating rather than advisory checks is right for a codebase with no parity obligation.
- AGREE: Gates are not weakened to make a Bolt pass, framed as an incident rather than a shortcut.
- AGREE: The walking skeleton must cross both runtimes *and* run inside Compose — the boundary defects only exist in the composed stack.
- OBJECT: Methodology `test-after` — the oracle predates the code here, and test-after lets a misread source produce a matching implementation and a matching test; use `custom` (characterization-first on the hazard register and the storage port, test-after elsewhere).
- OBJECT: The Ordering sentence is not executable — "first" carries two sequencing axes, frontend-only units and non-enumerated units are undefined, and it defines "done" a second time; replacement wording in item 2.
- OBJECT: Line coverage rather than branch coverage — all three hazards are branches or `??` fallback chains, and line coverage marks them covered when only one side runs.
- OBJECT: The merge gate has no enforcement mechanism and no evidence requirement, so with no CI and no PR it is an unverified assertion at the point it matters most; the gate must require the verbatim run output.
- OBJECT: The frontend render smoke test has no tooling behind it and asserts the wrong thing — "landmarks present" passes identically in the hazard-3 broken world.
- OBJECT: Nothing records the source system's behaviour while it is still runnable; without M1 every assertion is checked against a human's reading of a document, and this is the only item on the list that expires.
- OBJECT: "A test per enumerated branch" is unenforceable as written — it needs a committed hazard register and a second scoped coverage report to become a gate.
- OBJECT: Tooling versions are stated as settled although `evidence.md` records them as unverified; the skeleton Bolt should prove the toolchain resolves before the gate depends on it.
- OBJECT: D6 is left entirely open — take the position: the Compose end-to-end run is required on every Bolt merge, because with no CI it *is* the CI and end-only removes the bisect signal.
- OBJECT: D8 is handed to the human with no recommendation although `evidence.md` calls it the largest gap — recommend normalized DOM-structure diff against recorded source HTML and reject pixel screenshots explicitly.
