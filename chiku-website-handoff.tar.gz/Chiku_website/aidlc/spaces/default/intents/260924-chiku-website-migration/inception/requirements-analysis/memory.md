<!-- INVARIANT: examples are single-line HTML comments so a fresh template parses to total=0 (MEMORY_EMPTY). Do NOT un-comment or split across lines. t100 guards this. -->
> This file is kept up to date automatically while the stage runs. Add observations at the review step, not by editing here directly.

## Interpretations
<!-- example: 2026-05-29T10:14:32Z — chose REST over GraphQL; the consuming team only needs CRUD, revisit if subscriptions land -->

- 2026-09-24T16:19:23Z — wrote most functional requirements directly from the knowledge base rather than asking about them, because the parity rule makes the existing behaviour the requirement; asking "should GET / still render the published content?" would be ceremony. Each such requirement cites the knowledge-base file that establishes it, and the five genuinely open points were the only things put to the human.
- 2026-09-24T16:19:23Z — marked three requirements [hazard] and tied them to the 100% scoped coverage floor: the concurrency side-effect guard (FR4.5), the content-carrying schema defaults (FR9.2) and the media substring rule (FR7.2), plus the byte-inspection parser (FR6.2), the draft-recovery allowlist (FR8.3) and the error envelope (FR10.1). The common property is that each fails silently - no error, no log, no failing check - which is exactly what an aggregate coverage percentage cannot catch.
## Deviations
<!-- example: 2026-05-29T10:14:32Z — skipped the optional caching layer the stage prose suggested; the dataset is small enough that it adds risk -->

- 2026-09-24T16:19:23Z — Q2 came back not as an option but as a correction: "i don't want chatgpt dependencies, it should be a standard method with standard set of practices." My framing ("the old system never had to answer this - ChatGPT's platform owned the session") read as though a ChatGPT dependency were on the table. It never was; removing it is the migration. I stated that plainly, re-framed the question as the one value standard practice leaves open (cookie lifetime), cited OWASP's idle-plus-absolute shape, and re-asked. RULE: when explaining why a decision is open, do not describe the discarded system in a way that implies it is a live option.
## Tradeoffs
<!-- example: 2026-05-29T10:14:32Z — picked TDD over BDD this run; the team is unit-first and the domain is well-understood -->

- 2026-09-24T16:19:23Z — Q4 preserved the media substring scan exactly and added an in-process cache of the published document, rather than replacing the scan with a structured field check. The scan is genuinely bad engineering (two schema validations and three serialisations of a 15 KB document per media byte served, no 304 path, repeated per byte-range request of a streaming video) but it is also load-bearing: it makes an image referenced from prose public, and a structured check would 404 it. Caching separates the two - identical public/private decisions, collapsed cost.
- 2026-09-24T16:19:23Z — Q3 kept the UTF-16 character cap rather than switching to a byte cap. A byte cap is the defensible engineering choice and is what a fresh implementation would use, but it silently rejects documents the current system accepts, and the rejection would land on the owner's longest transcript - the least discoverable possible parity break.
## Open questions
<!-- example: 2026-05-29T10:14:32Z — confirm the retention window with compliance before the next stage hardens the schema -->

- 2026-09-24T16:19:23Z — FR7.6's cache interval is deliberately unset here; it trades staleness against cost and belongs to nfr-design. Left open with a named owner rather than guessed at.