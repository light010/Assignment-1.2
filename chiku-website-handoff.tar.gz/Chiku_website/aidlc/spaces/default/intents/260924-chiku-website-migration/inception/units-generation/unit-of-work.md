# Units of Work — chiku-website runtime-split migration

**Upstream:** `inception/domain-design/components.md`,
`inception/domain-design/decisions.md`,
`inception/requirements-analysis/requirements.md`.

Twelve units, grouped by component cluster following the dependency graph. [Q1]
Implementation order is **not** decided here — that is Delivery Planning's job,
using this stage's DAG as input.

## Unit index

| Unit ID | Name | Directory | Kind | Complexity | Deployment |
|---|---|---|---|---|---|
| U1 | source-fixtures | `u1-source-fixtures` | spec | M | shared (test data, consumed in place) |
| U2 | storage-ports | `u2-storage-ports` | library | L | embedded |
| U3 | identity-and-session | `u3-identity-and-session` | library | L | embedded |
| U4 | content-core | `u4-content-core` | library | XL | embedded |
| U5 | media | `u5-media` | library | XL | embedded |
| U6 | http-api | `u6-http-api` | service | L | standalone |
| U7 | api-client | `u7-api-client` | library | S | embedded |
| U8 | public-site | `u8-public-site` | ui | L | embedded in the frontend image |
| U9 | owner-editor | `u9-owner-editor` | ui | XL | embedded in the frontend image |
| U10 | containers | `u10-containers` | packaging | M | standalone |
| U11 | cloud-adapters | `u11-cloud-adapters` | library | M | embedded |
| U12 | deployment-plan | `u12-deployment-plan` | spec | S | shared (document) |

Only **U6** declares `service`: there is exactly one deployed Python executable.
[Q3] The Next.js renderer is a deployed runtime but owns no application logic,
so it is `ui` rather than `service` and owes no service-level design artifacts.

---

## U1 — source-fixtures

**Owns.** Recorded responses from the running `madhavi-tripathi/` application,
captured over HTTP before any Python is written: every public route's rendered
HTML, the content read, the media route's status codes across public /
draft-only / missing keys, the request-size boundary in both characters and
bytes, byte-range responses across all rejection branches, and stored-row state
after a save / publish / conflict sequence.

**Delivers.** A committed fixture set plus the harness that produced it, so a
later reader can see how each fixture was obtained.

**Boundary.** It records; it asserts nothing. The assertions live in the units
that consume it.

**Constraints.** Uses a disposable local database and a test identity; nothing
hosted is touched. **This unit expires.** Once the source application is retired
its fixtures cannot be recreated, which is why five other units declare a
dependency on it rather than merely referencing it. [Q2]

**Realises.** The oracle behind NFR10, and the evidence for every
behaviour-preservation claim in FR1, FR4, FR5, FR6, FR7 and FR9.

---

## U2 — storage-ports

**Owns.** The three persistence ports — `ContentStore`, `IdentityStore`,
`AssetStore` — their SQLite adapters, an in-memory fake per port, and one
adapter-parameterised conformance suite per port run over both implementations.

**Delivers.** The contract every backend unit persists through, proven by a suite
that runs against two implementations so it tests the port rather than SQLite.

**Boundary.** Defines and implements persistence. Owns no business rule: it does
not know what a revision means, only how to store one.

**Constraints.** `ContentStore`'s central operation is the single combined
compare-and-set write carrying content, revision entry and retention prune
together, made by one caller. Splitting it across callers is what ADR-001 and
FR4.5 exist to prevent. `AssetStore` exposes ranged reads, because loading a
whole video to serve one range is the thing the port exists to avoid.

**Realises.** NFR3, and the persistence half of FR4, FR5, FR6 and FR7.

---

## U3 — identity-and-session

**Owns.** `OwnerIdentity`, `SessionAuthority` and `LoginGuard`: the owner
account and its argon2id hash, session issue / verify / revoke with sliding and
absolute expiry, the CSRF token, failed-attempt bounding, and one-shot initial
provisioning.

**Delivers.** The complete authentication and session surface, enforceable
independently of any frontend.

**Boundary.** Answers "who is this, and may they act?" It owns no content.

**Constraints.** No default, seeded or sample credential exists anywhere in the
source tree. A missing or too-short session signing key is a **startup failure**
with a named variable — no default, and explicitly no auto-generated per-process
key. The provisioning gate is the existence of an owner record, not a consumed
flag, so restarting cannot reopen it.

**Realises.** FR3.1–FR3.7, NFR5.

---

## U4 — content-core

**Owns.** `ContentAuthority` and `RevisionLedger`: the content document in draft
and published form, the Pydantic schema as the single authoritative validator,
the draft-save and publish operations, the concurrency guard and its side-effect
guard, the request-size limit, the published-document cache, the inspect
operation behind draft recovery, the revision listing order and the retention
policy.

**Delivers.** Every content operation, and the seed content.

**Boundary.** Owns the one document every other unit reads and none may write.

**Constraints.** Three hazard requirements live here and each carries a test per
enumerated branch under a 100% scoped coverage floor: the side-effect guard
(FR4.5), the content-carrying schema defaults (FR9.2), and the recoverable /
corrupting classification (FR8.3.1–FR8.3.3). The size limit counts **characters,
not bytes**. `RevisionLedger` owns the retention policy but performs no write;
`ContentAuthority` executes the combined write under that policy.

**Realises.** FR4, FR5, FR7.6, FR8.3.1–FR8.3.3, FR9, **NFR8** (a publish reaches a visitor without a rebuild, and the cache it owns has an explicit invalidation path — ADR-002 records that the invalidation needs its own test, because a stale cache here is an authorization defect rather than a performance one) and **NFR11** (the draft and published forms are separate; no draft content may appear in any public response).

---

## U5 — media

**Owns.** `MediaIntake` and `MediaDelivery`: upload acceptance by byte
inspection, per-kind size ceilings, caption-track validation, server-side
responsive variant generation, orphan-free failure, the asset-visibility rule,
range handling and the protective response headers.

**Delivers.** The complete upload and serving path.

**Boundary.** Intake decides what may enter; delivery decides what may leave and
to whom. Kept together as one unit because they share `AssetStore` and the asset
metadata shape, kept as two components because one is input validation and the
other is access control.

**Acknowledged trade-off.** ADR-004 separated these two components partly so that
a defect in one would not be reviewed in the same breath as the other. Grouping
them into a single unit preserves the component boundary but **not** that
review-cadence separation: both hazard surfaces will land and pass a merge gate
together. Accepted deliberately — they share the port and the metadata shape, so
splitting the unit would create two Bolts that must be built and merged in
lockstep anyway. The mitigation is that each hazard keeps its own per-branch tests
and its own 100% scoped coverage floor, so the gate still distinguishes them even
though the review does not.

**Constraints.** Two hazard requirements with per-branch tests: byte-signature
typing including its endianness and field-order quirks (FR6.2), and the asset
visibility rule preserved exactly as a substring test over the serialised
published document (FR7.2). Range handling reproduces all seven enumerated
behaviours including that `HEAD` never inspects the range header and that there
is deliberately no not-modified path (FR7.4).

**Realises.** FR6, FR7.1–FR7.5, and **NFR11** (an asset is served publicly only while published content references it; a non-public asset is reported absent rather than forbidden, so the response does not disclose that the key exists).

---

## U6 — http-api

**Owns.** `HttpApi`: every route, the single error envelope and its four-member
exception taxonomy, origin and CSRF middleware, request context, and the
OpenAPI document.

**Delivers.** The one deployed Python executable, and the published contract the
frontend's types are generated from.

**Boundary.** Transport and envelope only. Route handlers stay thin; every
authorization decision belongs to the unit behind the route.

**Constraints.** One hazard requirement: the error envelope is **ported, not
redesigned** (FR10.1). FastAPI's defaults would silently break the editor's
field highlighting and conflict recovery while appearing to work. The envelope is
produced by exception handlers, never constructed per route. A three-line gate
grep and an AST test enforce that no route module imports a store.

**Realises.** FR3.8, FR10, NFR1, NFR2.

---

## U7 — api-client

**Owns.** The TypeScript types generated from U6's OpenAPI document, committed
and regenerated at the gate, plus the thin transport that attaches credentials
and the CSRF token and propagates the error envelope unchanged.

**Delivers.** The frontend's only route to the backend.

**Boundary.** The single crossing point of the language boundary. Holds no
business rule, caches nothing, and hand-written mirrors of backend types are
forbidden.

**Constraints.** The gate fails if the committed generated output is dirty after
regeneration — which is what makes a backend field rename fail `tsc` with a file
and a line rather than surfacing as a runtime error three units later.

**Realises.** FR8.9, and the enforcement half of NFR1.

---

## U8 — public-site

**Owns.** Every public route and its rendered output, all enabled sections, the
publication browser, the three-dimensional illustration, light and dark
appearance, and the discoverability surface — metadata, Open Graph, structured
data, sitemap and robots.

**Delivers.** What a visitor sees.

**Boundary.** Renders. Decides nothing.

**Constraints.** Under the parity rule: layout and content reproduce as-is while
accessibility and semantics may improve without moving anything visually.
Verified by normalised DOM-structure diff against U1's fixtures plus a
page-by-page human review. Ported files are byte-identical to their originals
except imports and the rewired data call, or listed in `PORTED-MODIFIED.md` and
reformatted wholesale. The site origin becomes configuration; it is a source
literal today.

**Realises.** FR1, FR2, FR10.2, and **NFR7** (keyboard navigation, visible focus, semantic markup, labels, contrast and reduced motion on every changed interface — improvements permitted only where nothing moves visually, and no conformance claim beyond what is tested).

---

## U9 — owner-editor

**Owns.** Every editing surface, draft autosave and its suspension rules,
per-tab local retention, the recovery flow including the third unreachable state,
the conflict flow, the private draft preview, focal-point and caption controls,
and the browser tool registration.

**Delivers.** What the owner uses.

**Boundary.** Renders and holds local state. The rule separating a recoverable
draft from a corrupt one lives in U4; this unit submits and renders the verdict.

**Constraints.** Largest frontend surface and the only one that mutates anything.
When the inspect request fails, the editor **holds** the draft and shows an
unavailable-and-retry state — never discards it. The browser tool stages profile
fields only and never saves or publishes. If the multi-flag save state machine
turns out to contain a rule rather than presentation state, that part crosses the
boundary — an open question owned by Functional Design.

**Realises.** FR8.1–FR8.2, FR8.3.4, FR8.4–FR8.8, and **NFR7** (as for the public site; this unit also carries the one agreed user-visible behavioural change, the carousel keyboard-focus fix, and the focal-point and caption controls whose keyboard operation must work).

---

## U10 — containers

**Owns.** Both Dockerfiles, the Compose file, `.dockerignore` rules, the safe
environment example, the named volume layout, health checks, graceful
termination, non-root users, and the end-to-end flow exercised against the
composed stack.

**Delivers.** The verified containerised system.

**Boundary.** Packaging and orchestration. Adds no application behaviour.

**Constraints.** Locked dependencies via frozen installs only. Base images pinned
**by digest**, never a floating tag. No secret through a build argument or
environment instruction, and none baked into a layer. Durability proven by
recreating the runtime container and re-reading. No source mounts and no
development servers in the verification run.

**Realises.** NFR4, and the container half of NFR3 and NFR5.

---

## U11 — cloud-adapters

**Owns.** Firestore and Cloud Storage adapters written against the three ports
from U2 and run over the same conformance suites.

**Delivers.** The cloud persistence path, code-complete.

**Boundary.** Adapters only. No new port, no new rule.

**Constraints.** **Shipped unverified against the real Google services**, by
explicit choice, and labelled as such in the README and the deployment plan so
nobody mistakes them for proven. The conformance suite proves they satisfy the
port; it does not prove they work against Firestore. Specific risk to resolve in
Contract Design: whether the ports assume relational semantics Firestore does not
offer — a transaction spanning documents, compare-and-set, or ordered pagination
with multi-key tie-breaks. `RevisionLedger`'s three-part sort is the known worry.

**Realises.** The cloud half of NFR3; supports NFR6.

---

## U12 — deployment-plan

**Owns.** The Cloud Run topology, region, usage assumptions, the costed table
with every line item traced to a current official free-tier source, prerequisites,
and deploy and rollback commands.

**Delivers.** A reviewed plan. Nothing is deployed.

**Boundary.** A document. It provisions nothing and changes no billing.

**Constraints.** Container image sizes are **measured** from U10's real images,
never estimated — a rule already in `project.md` after an earlier estimate was
wrong in exactly that way. The zero recurring-cost target is verified as a
property of this document: every line item cites a current source and the
architecture requires no paid storage. This is what closes the finding that the
cost condition was unmeasurable while nothing is deployed.

**Realises.** NFR6, and success condition S4.

---

## Assumptions & Open Questions

- **[assumption]** U4 and U5 are XL because each carries multiple hazard
  requirements with per-branch tests and a 100% scoped coverage floor, not
  because of line count.
- **[open, owner `delivery-planning`]** Shared frontend presentation code — the
  design system, the CSS, the eleven used vendored components — is carried by
  whichever of U8 or U9 lands first and consumed by the other. **No DAG edge
  encodes that**, so nothing in the topology stops a scheduler from running the
  two in true parallel and colliding on exactly those files. Delivery Planning
  must either order U8 before U9 (or the reverse) in its sequence, or promote the
  shared code to a thirteenth unit. It is not a unit now because it has no
  independent deliverable, but that is a reason to sequence it, not to ignore it.
- **[open, owner `contract-design`]** Whether the three port contracts assume
  relational semantics Firestore does not provide. This is U11's principal risk
  and it is cheaper to discover in a contract than in an adapter.
- **[open, owner `delivery-planning`]** Which units the walking-skeleton Bolt cuts
  a thin slice through. The scope requires it to cross both runtimes and the
  container boundary, which implies a slice of U2, U3, U4, U6, U7, U8, U9 and
  U10 — but the depth of each slice is a sequencing decision, not a boundary one.
