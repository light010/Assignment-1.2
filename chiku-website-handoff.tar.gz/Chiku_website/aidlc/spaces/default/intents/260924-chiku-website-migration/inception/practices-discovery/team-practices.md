# Team practices — chiku-website runtime-split migration

> **Affirmed at the practices-discovery gate on 2026-09-24.** The five H2 sections below mirror
> `aidlc/spaces/default/memory/team.md` and are what `practices-promote` writes there. Every
> decision that was open in the draft has been settled — by the site owner's eight rulings in
> `practices-discovery-questions.md`, or by a reviewer objection accepted without asking (the two
> tables at the head of that file record which, and why). Nothing below is still a question.
>
> `evidence.md` carries the reasoning and the costs; it is **not** promoted, so anything a future
> reader must know to apply a rule correctly is stated here rather than left there.

## Way of Working

We use trunk-based development on `main`. Each Bolt runs in its own short-lived worktree branch
based on `main` and squash-merges back to `main` as a single commit named by the Bolt slug, per
the org default. Nothing about this project's shape argues against that, so we inherit it
unchanged.

**This project stays local.** The workspace became a git repository today — `main`, no remote, no
forge — and the site owner affirmed that it stays that way for the duration of this workflow. Three
consequences follow, and we record them explicitly rather than leave them implied:

- **There is no pull request, so there is no pull-request review gate.** The org rule "linter runs
  in CI before merge; failure blocks the PR" has no vehicle here.
- **`ci-pipeline` is SKIPPED** in this workflow's composed scope (`runtime-split-migration`),
  because there is no remote for a pipeline to run on.
- **The local merge gate is the only enforcement point this project has.** It is not a convention
  and not a checklist someone keeps in their head: it is the explicit, ordered command list in
  `## Testing Posture`, run on the developer machine, and its **verbatim output** — exit status,
  pytest summary, both coverage totals, the Compose health result — is pasted into the Bolt's gate
  approval. **Gate approval is refused without that output.** With no CI and no PR, an unwitnessed
  gate is an assertion, not a check.

There is also no off-machine backup. That was offered and declined; it is a known, accepted
exposure, not an oversight.

We work dependency-first: a Bolt may only be scheduled once every Bolt it depends on has merged.
This was confirmed by the site owner and is not a framework default.

## Walking Skeleton

The active scope declares `skeleton: on`, so Bolt 1 is a walking skeleton: solo, gated, and the
site owner explicitly approves it before any other Bolt runs.

For this project the skeleton is only meaningful if it crosses **both runtimes and the container
boundary**. We require Bolt 1 to carry, end to end:

- one public read path — a request that reaches the Next.js frontend, is served content that the
  Python backend owns, and renders;
- one owner-management write path — authenticate as the single site owner, change something,
  persist it through the storage port, and observe the change on the public path;
- both of the above executed **inside the Docker Compose run**, not only against processes
  started by hand.

That is the point of the skeleton here: the language boundary, the session contract and the
ContentStore/AssetStore port are the three things most likely to be wrong, and all three are
cheapest to correct on a thin slice.

**Bolt 1 also carries four deliverables that everything downstream depends on:**

1. **The recorded source-behaviour fixtures** (`## Testing Posture`, first bullet). These must
   exist before any Python is written, and they are the only item in this document with an expiry
   date — once `madhavi-tripathi/` is retired they cannot be made.
2. **A committed `.env.example`**, listing every variable the system reads with empty values and a
   one-line comment each. None exists today, and it is the only place a reader learns what
   configuration the system needs.
3. **The pinned flag spellings** for the supply-chain commands in `## Deployment`. They were
   written against `uv` 0.10.0 and `pnpm` but not executed; Bolt 1 runs each one, fixes the exact
   spelling, and records it. What is affirmed here is the gate entry, not the flag string.
4. **A `docker history` check on both images** confirming no secret value landed in a layer. This
   is checked once, at the skeleton gate, not on every Bolt.

After Bolt 1 ships, the orchestrator fires the ladder prompt and the site owner chooses whether
the remaining Bolts run autonomously or each gate individually. We do not pre-commit that choice
here.

## Testing Posture

> **Read this section as a proposal we have adopted, not as practice we observed.** The source
> project contains zero test files, zero testing dependencies and no `test` script, so there was no
> prior testing practice to discover — every item below was chosen at the practices-discovery gate
> on 2026-09-24 and affirmed by the site owner, rather than read off how this team already works.

- **Methodology**: custom
- **Ordering**: Within each unit, the characterization tests for that unit's hazard-register
  behaviours and for the storage port are written and observed to fail before the Python
  implementation of that behaviour exists; every other backend test is written immediately after
  the code it covers; that unit's frontend render layer is ported only once its backend tests
  pass; a unit with no backend surface begins at the frontend step; and a unit whose behaviour is
  not enumerated in the hazard register takes the recorded source fixtures as its oracle, falling
  back to the reverse-engineering knowledge base where no fixture exists.
- **What `custom` means, and why it is not `test-after`.** Under test-after, a developer who
  misreads a dense source line implements from the misreading and then writes the test from the
  same misreading: the test is green, coverage is satisfied, and the defect ships. That is not
  hypothetical here — a port declaring `research_topic: Topic | None = None` passes `ruff`,
  `mypy --strict`, `tsc`, the Compose end-to-end flow and 100% line coverage while rendering three
  identical research cards and returning zero publications for every topic filter. Only a test
  whose assertion came from the *source* behaviour catches it. `tdd` everywhere is equally wrong:
  most of the ported render layer has no enumerated oracle, and writing failing render assertions
  first for ported JSX is waste. Note this is **characterization** testing, not TDD — the test is
  written from the recorded behaviour of the source, which is why the fixtures below matter.
- **Recorded source-behaviour fixtures come first, before any Python is written.** Drive the
  running `madhavi-tripathi/` app over HTTP with `httpx` once and record as golden fixtures: every
  public route's rendered HTML, `GET /api/content`, the media route's status codes across public /
  draft-only / missing keys, the 413 boundary in both characters and UTF-8 bytes, byte-range
  responses across all six rejection branches, and the stored-row state after a save / publish /
  conflict sequence. It uses a disposable local database and a test identity; nothing hosted is
  touched. Until these exist, every parity assertion in this project rests on a human's reading of
  a document; after they exist, they assert against the system. **This capability expires when the
  source app is retired** — a fixture not recorded before then cannot be recovered.
- **Coverage floor — backend**: **80% branch coverage** over `chiku-website/backend/`, measured by
  `pytest --cov --cov-branch` and `coverage report --fail-under=80`, with generated migration
  files and `__main__` entry points excluded. Branch, not line, is deliberate and costs one flag:
  every high-risk behaviour in this port is a branch or a `??` fallback chain, and line coverage
  marks those covered when only one side ever runs. This is a **new floor we are choosing**, not
  an inherited one — `org.md`'s 80% floor is written for the named stock scopes (`mvp`,
  `enterprise`, `feature`, `infra`, `classic`) and this workflow runs the custom scope
  `runtime-split-migration`, which appears in none of them. Absent this affirmation there would be
  no numeric floor at all. The active `Test Strategy` is **Standard** and continues to govern test
  volume and type independently of this number.
- **Coverage floor — hazard modules**: a second, scoped
  `coverage report --fail-under=100 --include=<hazard module globs>`. The hazard modules are the
  ports of the behaviours ranked in `code-quality-assessment.md` § *Hazard index* — the
  seven-statement concurrency batch and its `last_mutation` ABA defence, the media access rule, the
  `researchIdentity` back-compat shims, the request-size cap, the three hand-written image header
  parsers, the WebVTT validator, the byte-range parser and the editor state machine. Each carries a
  test per enumerated branch. An aggregate percentage cannot distinguish "this branch is exercised"
  from "this branch was ported correctly"; these are precisely the branches whose silent loss ships
  a defect, so they get both the per-branch tests and a floor that leaves no room.
- **Coverage floor — frontend**: none. The Next.js frontend renders only and owns no application
  decision, so a line-coverage number on it would measure JSX traversal rather than behaviour.
- **The test families, and which are mandatory.** Mandatory: the recorded fixtures above; backend
  unit tests for branch-level behaviour of ported logic; **storage-port contract tests written as
  an adapter-parameterized conformance suite and run against both the real SQLite adapter and an
  in-memory fake** (two implementations is the minimum that proves the suite tests the port
  contract rather than SQLite, and it is the whole argument for having a port); API contract tests
  in the non-circular form — assert the **generated** OpenAPI document against the **hand-written**
  contract from `contract-design`, and commit the generated `openapi.json` as a snapshot so an
  unintended contract change surfaces as a gate diff rather than as a frontend 422 three Bolts
  later; and the Compose end-to-end flow. Frontend render checks are mandatory but add **no
  frontend test framework**: assert against the HTML the composed stack returns, using the recorded
  fixtures, and make the assertions named rather than "landmarks present" — each of the three
  research cards has a distinct topic class and icon, the publications topic filter returns
  non-zero for each seeded theme, each research card shows non-zero related papers. Browser checks
  (Playwright) are optional today with one condition that flips them: **if the six-flag editor
  state machine lands in the frontend rather than the backend, a browser check becomes the only
  possible verification of it and becomes mandatory.** Flag that as a dependency on `domain-design`.
- **Compose end-to-end runs on every Bolt merge**, not only at the skeleton gate and at the end.
  With no CI, the per-merge run *is* the CI, and the alternative is a container-level regression
  surfacing many Bolts after the one that caused it, with no bisect signal and nobody watching a
  dashboard. Keep the cost bounded by keeping the flow small and fixed — the skeleton's two paths
  plus one auth-failure path — so it stays inside a few minutes on cached layers.
- **Parity is verified two ways, and pixel comparison is rejected.** (1) A **normalised
  DOM-structure diff** against the recorded source HTML: strip volatile attributes, build hashes
  and whitespace, then diff the element tree plus text content per route. It catches what actually
  breaks in a port — a dropped section, a wrong class, a missing copy default among the 25 leaf
  defaults — at a fraction of the setup cost of pixel screenshots and without their flakiness.
  (2) An explicit **page-by-page human review at the end**, recorded as a checklist. Per-route
  screenshot comparison was considered and **rejected**: it is brittle against fonts, antialiasing
  and animation, and it is not a live option to be reopened later. Until the DOM diff exists, the
  parity rule is an unfalsifiable claim, which is what this closes.
- **Boundary enforcement is a command, not an assertion.** A rule nobody can check is a wish. Three
  checks, all on the gate: the frontend's TypeScript types for backend payloads are **generated**
  from the backend's `/openapi.json` with `openapi-typescript`, committed, regenerated at the gate,
  and the gate fails if the output is dirty — which makes the boundary type-checked rather than
  asserted, since a backend field rename then fails `tsc --noEmit` with a file and a line; a
  three-line grep fails the gate if `chiku-website/frontend` contains any `'use server'` directive,
  any `app/**/route.ts`, or any `middleware.ts` (an ESLint `no-restricted-syntax` rule is a nicer
  editor experience, but the grep is the one that is certain); and one pytest walks the AST of
  `routers/` modules and asserts none of them imports a `store` module or `sqlite3`.
- **The source has no suite to keep green.** The org rules for several scopes say "the existing
  suite remains green". There is none — the scan found zero test files, zero testing dependencies
  and no `test` script anywhere in `madhavi-tripathi/`. Every test in this project is a new test.
  The only inherited automated checks are `tsc --noEmit` (strict) and `pnpm lint`.
- **Tooling**: backend — pytest 9.1.1 with `httpx` 0.28.1 for FastAPI transport-level tests,
  `ruff` 0.16.8 and `mypy` 2.3.1 as gating checks, dependencies resolved by `uv` 0.10.0. Frontend
  — `tsc --noEmit` and ESLint 9 with `eslint-config-next`, unchanged from the source project.
- **The merge gate.** A Bolt may squash-merge to `main` only when every one of these passes on the
  developer machine, in this order, with the **verbatim output pasted into the gate approval**:

  ```
  ruff check
  ruff format --check
  mypy --strict
  pytest --cov --cov-branch
  coverage report --fail-under=80
  coverage report --fail-under=100 --include=<hazard module globs>
  tsc --noEmit
  pnpm lint
  git diff --no-index madhavi-tripathi/app/<f> chiku-website/frontend/app/<f>   # per unmodified ported file
  <boundary grep: 'use server' / app/**/route.ts / middleware.ts>
  <openapi-typescript regeneration — gate fails if the committed output is dirty>
  uv export --frozen --no-dev --no-emit-project -o .audit/requirements.txt && uvx pip-audit -r .audit/requirements.txt
  pnpm audit --prod --audit-level high
  docker compose up  +  the end-to-end flow
  ```

  **Dependency advisories block at High and above.** An advisory with no fix available does not
  silently pass and does not silently block: it is recorded with the **package, the advisory id,
  the reason it cannot be fixed, and the named Bolt that owns it**, and the gate then proceeds on
  that record. This is consistent with the correction already in `project.md` that any finding
  carried past a gate needs a named owner.

  Gates protect the parity guarantee; weakening one to make a Bolt pass is an incident, not a
  shortcut.

## Deployment

**Nothing is deployed in this piece of work.** We record that as a practice rather than omitting
the section, so a later reader can tell a deliberate decision from an oversight.

- The org default "deploy on merge to staging, manual approval to production" **does not apply
  here**. There is no staging environment and no production environment. The composed scope skips
  the entire operation phase — `environment-provisioning`, `deployment-pipeline`,
  `deployment-execution` and `observability-setup` are all SKIPPED — because there is no running
  service to provision, deploy to or instrument.
- **Docker Compose is the verification vehicle**, in place of a deployment. A change is "verified"
  when both container images build, `docker compose up` brings both runtimes and the persistent
  volume up clean, and the end-to-end flow described in `## Walking Skeleton` passes against the
  composed stack.
- **Configuration and secrets.** Two secrets exist: the session signing key and the initial-owner
  bootstrap secret. Both reach the process as **environment variables read at startup**. Neither is
  ever a literal in a source file, and neither is ever baked into an image.
- **The signing key is generated, never chosen.** Generate once per environment with
  `python -c "import secrets; print(secrets.token_urlsafe(64))"` and keep it outside the
  repository. In development it lives in an uncommitted `.env` that Compose loads via `env_file:`;
  in a container it is injected at run time.
- **A missing key is a boot failure.** If `SESSION_SIGNING_KEY` is unset, empty, or under 32 bytes,
  the backend raises during startup with a message naming the variable and exits non-zero. There is
  **no default value, no fallback, and no auto-generated per-process key** — an auto-generated key
  silently invalidates every session on restart and hides the misconfiguration, which makes it the
  worse of the two failure modes because it looks like it works. The same rule holds for every
  required setting: fail at boot, not at first request.
- **`.env` discipline.** A committed `.env.example` lists every variable the system reads, with
  empty values and a one-line comment each; real `.env` files are never committed. The workspace
  `.gitignore` already enforces the split (`.env`, `.env.*`, `!.env.example`, `!.env.*.example`).
  Creating `.env.example` is a Bolt 1 deliverable.
- **`NEXT_PUBLIC_*` is public forever.** Next.js inlines any `NEXT_PUBLIC_`-prefixed value into the
  client bundle at build time: it is readable by every visitor, baked into the built image, and
  cannot be rotated without a rebuild. **Only the public backend base URL and the site origin** —
  the replacement for the hard-coded `siteOrigin` — may carry that prefix. No key, token, hash or
  address goes there; in particular `OWNER_EMAIL` becomes backend-only configuration and **must
  never reappear as `NEXT_PUBLIC_OWNER_EMAIL`**.
- **Initial-owner provisioning.** The backend ships no owner row and no seed SQL that creates one.
  On startup, when no owner record exists **and** `ADMIN_BOOTSTRAP_SECRET` is set, the backend
  enables a single one-shot provisioning route that requires that secret, accepts the owner's chosen
  password, stores only its argon2id hash, and is refused permanently once an owner row exists. The
  gate condition is "an owner row exists", not a consumed flag, so restarting the container cannot
  re-open the route. When the secret is unset and no owner exists, the service starts and refuses
  every login rather than creating an account. The acceptance test for the no-default-credential
  rule is exactly this: **a fresh `docker compose up` against an empty volume has no account anyone
  can log into.**
- **Supply chain — building an image is a supply-chain act even when nothing ships.**
  `uv sync --frozen` and `pnpm install --frozen-lockfile` are the **only** install commands used at
  the gate and in both `Dockerfile`s, because a non-frozen install lets the verified tree and the
  built tree differ silently and with no CI nothing else notices. Base images are pinned **by
  digest, never by a floating tag** (`FROM python:3.14-slim@sha256:…` and the Node equivalent);
  digests are bumped deliberately, in their own commit, with the audits re-run. Each image creates
  a **non-root user**, and the persistent volume is owned by that uid — the backend writes uploaded
  files, the source's PDF check is five bytes (`%PDF-`) with no polyglot detection, and the serving
  CSP is what contains that, so an upload path running as root removes the last margin.
- **Two supply-chain settings inherited from the source, both decided rather than copied.**
  `madhavi-tripathi/pnpm-workspace.yaml` sets `minimumReleaseAge: 10080`. That is **a supply-chain
  control, not the friction the draft called it** — a seven-day cooldown is the cheapest available
  defence against a compromised fresh release, and it costs nothing. It stays in the ported
  workspace file; if it is ever removed, it is removed knowingly. `madhavi-tripathi/.npmrc` sets
  `audit=false`; whatever else is copied forward, **that line is not**. A suppression copied forward
  is a suppression nobody chose.
- **Google Cloud is plan-only.** Cloud Run, Firestore and GCS appear in design artifacts as adapter
  targets and as a cost envelope. No cloud resource is provisioned, no project is created, no
  credential is issued in this workflow.
- **Zero recurring cost is a hard target, not an aspiration.** Any proposal that introduces a
  metered or billed component is rejected at design time, not deferred to a cost review. Cost and
  image-size figures are reported as measured values only, never estimates (already recorded in
  `project.md`).
- **Rollback, while nothing is deployed, is `git revert` of the Bolt's squash commit** plus a
  rebuild of the Compose stack. There is no deployed artifact to roll back and no data to migrate
  backwards. We state this rather than leave the org's rollback expectation apparently unmet.

## Code Style

The two runtimes are governed separately. They have different histories and only one of them has
a parity obligation.

### TypeScript / React (frontend)

- **Linter**: ESLint 9 with `eslint-config-next` (core-web-vitals + typescript), carried over from
  `madhavi-tripathi/eslint.config.mjs` including its three relaxations scoped to vendored
  `components/ui/**`. **Type check**: `tsc --noEmit` with `strict: true`.
- **Formatter**: none. We deliberately do **not** introduce Prettier to the frontend in this
  workflow. Introducing it later without path-scoping would silently reformat the ported files and
  void the rule below.
- **A ported file is in one of exactly two states, and the file is the unit.** **Unmodified**:
  byte-identical to its `madhavi-tripathi/` original except for import specifiers and the rewired
  data-access call, keeping the dense style entirely. **Modified**: listed in
  `chiku-website/frontend/PORTED-MODIFIED.md` with one line saying what changed and why, and then
  the **whole file** is formatted conventionally — not the edited region. New frontend files and
  all Python are conventional from the first line. The merge gate runs
  `git diff --no-index madhavi-tripathi/app/<f> chiku-website/frontend/app/<f>` for every file
  **not** on that list and fails if any hunk is not an import or a data-access call. The earlier
  edited-region formulation is withdrawn: it mandated intra-file style mixing, which is worse than
  the inter-file mixing we accept, and "untouched region" is not a property any tool can evaluate.
- **Two files cannot be unmodified, and go on the list on day one.** `server.ts:5` hard-codes
  `OWNER_EMAIL='madhavi.tri16@gmail.com'` and `site-metadata.ts:5` hard-codes `siteOrigin`. Both
  are environment-dependent literals, and the construction-phase rules forbid carrying that pattern
  forward.
- **Why the dense style is kept, and what it costs.** The code scan adjudicated the extremely dense
  single-line style (up to 3,969 characters on one line; `app/content.ts` holds all 31 schema fields
  with their refinements and defaults on a single 1,189-character line) as deliberate, consistently
  applied house style rather than defect. With zero tests in the source, a line-granular diff of a
  ported file against its original is the only cheap parity evidence we have, and running a
  formatter destroys that evidence for exactly the files that hide the most branches. It also keeps
  the frontend's lint-clean run meaningful as parity evidence, because the ruleset is unchanged. The
  cost is real: **two styles in one tree** for the duration, which makes review harder.
- **Normalisation happens once, after parity is signed off** — a single mechanical formatting
  commit at a point when tests exist to prove it changed nothing. Not during the port: a
  reformatted diff hides exactly the branches most worth checking. Keeping the dense style
  permanently was considered and not chosen.
- **The vendored MIT notices travel with the files they cover.** `components/ui/**` carries a
  `vendor/` notice covering 61 files that have no per-file header, and there is a second MIT notice
  on `build/sites-vite-plugin.ts`. Copying the component files without the notice breaks an
  attribution obligation.
- **Naming**: camelCase for values, PascalCase for components, unchanged from source.

### Python (backend)

There is no legacy and no parity obligation here — every line is new — so we take the strictest
reasonable defaults from day one and there is nothing to trade off.

- **Formatter**: `ruff format` (ruff 0.16.8), **line length 100**, enforced by
  `ruff format --check` at the merge gate.
- **Linter**: `ruff check`, configured in `pyproject.toml`, with
  `select = ["E","F","I","UP","B","ASYNC","S","BLE","A","C4","SIM","TID","RUF"]` and no blanket
  per-file ignores. `I` matters: import sorting is **not** on by default, so without it import
  ordering is literally unspecified and will differ per file. `S` (flake8-bandit) matters more:
  this backend is the product's entire security surface, and `S` is free and local. `S101` (bare
  `assert`) is ignored under `tests/` through `per-file-ignores`; nothing else in `S` is disabled
  without a written reason.
- **Type check**: `mypy --strict`, with no blanket `ignore_missing_imports`. Without `strict`,
  untyped function bodies go unchecked, and retrofitting strict later costs far more than starting
  with it.
- **Dependency resolution**: `uv` 0.10.0, with a committed lockfile. Targets Python 3.14.
- **Naming**: PEP 8 — `snake_case` for functions and variables, `PascalCase` for classes.
- **Naming across the boundary — the wire format is inherited, not chosen.** Python identifiers are
  `snake_case` everywhere, including storage columns. The JSON wire format is **`camelCase` and
  frozen**, for two independent reasons: ported components read it directly and unchanged
  (`site.tsx` reads `c.scholarHighlights`, `c.publications[].featured`, `focalX`/`focalY`; the
  editor reads the same shape), so `snake_case` JSON would turn "components port largely unchanged"
  into a rename sweep that voids the file-as-unit rule for every file it touches; and the persisted
  content **is** that JSON — `normalizeStoredContent()` parses the stored `draft`/`published`
  columns through the same schema, so a wire rename is also a data migration. Conversion happens in
  **exactly one place**: a shared Pydantic `BaseModel` with `alias_generator=to_camel` and
  `populate_by_name=True`, from which every request and response model inherits. No hand-written
  mapping, no `camelCase` identifier in Python, no `snake_case` key on the wire. This reproduces the
  discipline the source already has — `stateFromRow()` performs exactly one conversion,
  `row.updated_at` → `updatedAt`.
- **The error envelope is ported, not redesigned — this is the highest-probability silent
  regression in the migration.** The four source routes share one envelope: `{error: '<sentence>'}`,
  plus `issues: [{path, message}]` on validation failures, with statuses **400 / 403 / 409 / 413 /
  503**. The frontend is built on it — `editor-workflow.ts` branches on `409` to enter conflict
  recovery and reads `result.issues` to highlight fields. FastAPI's defaults (`{"detail": ...}` and
  Pydantic's `loc`/`msg`) **silently break field highlighting and conflict recovery while appearing
  to work**. So: one envelope, produced by exception handlers rather than by each route, and a
  four-member taxonomy mapped once — `NotAuthorized` → 403, `Conflict` → 409, `TooLarge` → 413,
  `Invalid` → 400 (carrying `issues`), anything else → 503 with `logger.exception()`. 503 rather
  than 500 matches the source. Services raise these; routers do not construct responses. Recoverable
  versus fatal is a **wire-level** distinction: 409 and 400-with-issues are recoverable and the
  frontend keeps its specific handling for each; 503 is retryable with no specific handling.
- **The source routes' user-facing error strings are product copy** and fall under the parity rule.
  Parity is not layout-and-content only; a port that rewrites an error sentence has changed what the
  site owner sees.
- **`async` by default.** Route handlers and services are `async`. Where a dependency is
  synchronous (`sqlite3`), the **adapter** wraps it in `anyio.to_thread.run_sync`; a handler or a
  service never calls a blocking driver directly. Event-loop blocking is invisible to every check
  on the merge-gate list, which is why it has to be a rule rather than something a gate catches.
- **A layer exists only when it has a job.** No service-per-route, no generic repository
  abstraction. The ports are named for real things — `ContentStore`, `AssetStore` — and the
  pure-versus-execute split the source already has (`contentWriteStatements()` returning statements
  plus `writeContent()` as a thin executor) **survives the port**: that factoring is what makes the
  concurrency batch inspectable, and flattening it loses the property.
- **Boundary discipline**: FastAPI route handlers stay thin; application decisions live in service
  modules behind the route layer, and persistence lives behind the ContentStore / AssetStore ports
  rather than in the handlers. The AST test in `## Testing Posture` is what enforces this.
- **Naming**: PEP 8 module and package names — lowercase, no hyphens. Feature modules are named
  for the domain thing they own (`content`, `assets`, `auth`, `owner`), never for a layer
  (`services`, `helpers`, `utils`), which is the same rule as "a layer exists only when it has a
  job" applied to the directory tree.
