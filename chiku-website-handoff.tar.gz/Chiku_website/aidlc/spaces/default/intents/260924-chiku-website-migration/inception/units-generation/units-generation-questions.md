# Units Generation — Questions

Upstream: `inception/domain-design/components.md`, `…/decisions.md`,
`inception/requirements-analysis/requirements.md`.

Implementation *order* is not asked here — value-first, risk-first and the
walking skeleton are economic decisions that belong to Delivery Planning. This
stage decides only what the units **are** and how they depend on each other.

---

## Q1. Unit boundary strategy

The fourteen components group into units in more than one defensible way.

**Option A — by component cluster, following the dependency graph.** Each unit is
one component or a tight cluster that shares a port: the storage ports and their
local adapters; identity/session/login-guard; content and revisions; media intake
and delivery; the HTTP surface; the generated client; the public site; the
editor; the containers; the cloud adapters. Roughly twelve units.
*Pro:* unit boundaries are component boundaries, so the hazard requirements stay
separately testable and the dependency-first order falls out of the graph.
*Con:* twelve units for one small website; more Bolt ceremony.

**Option B — by deliverable layer.** Four units: backend, frontend, containers,
cloud plan.
*Pro:* fewest units, least ceremony. *Con:* the backend unit would contain
authentication, content concurrency, upload validation and media access control
in one Bolt — four of the seven hazard requirements — so a failure anywhere
blocks all of them, and nothing can be verified until the whole backend exists.

**Option C — by user-visible feature.** Units like "sign in", "edit a
publication", "upload a photo".
*Pro:* each unit delivers something demonstrable. *Con:* every feature cuts
across the storage port, the backend and both frontends, so the units share
files and cannot be built independently — which is the one thing unit boundaries
exist to enable.

A. Option A — by component cluster, roughly twelve units.
B. Option B — by deliverable layer, four units.
C. Option C — by user-visible feature.
D. Not yet defined.
X. Other (please specify)

[Answer]: A. Option A — by component cluster, roughly twelve units.

---

## Q2. Are the recorded source fixtures their own unit?

You confirmed that the running `madhavi-tripathi/` app is driven over HTTP and
its real responses recorded as golden fixtures before any Python is written, and
that this capability **expires** when the source app is retired.

**Option A — a unit of its own, with nothing depending on it in the graph.** It
gets scheduled first by Delivery Planning and everything else simply uses its
output.
*Pro:* simplest graph. *Con:* nothing structurally stops a later unit being
built before the fixtures exist, which is exactly the mistake that cannot be
undone.

**Option B — a unit that the behaviour-preserving units depend on.** Content,
media, the public site and the editor all declare a dependency on it.
*Pro:* the expiry risk becomes a graph constraint rather than a note in a
document — you cannot schedule a characterization test before its oracle exists.
*Con:* four extra edges, and the dependency is on *data* rather than on code.

**Option C — not a unit; a task inside the first Bolt.**
*Pro:* no extra unit. *Con:* it disappears from the dependency graph entirely,
and it is the one deliverable with a deadline imposed by physics rather than by
choice.

A. Option A — its own unit, no dependents.
B. Option B — its own unit, and the behaviour-preserving units depend on it.
C. Option C — a task inside the first Bolt, not a unit.
D. Not yet defined.
X. Other (please specify)

[Answer]: B. Option B — its own unit, and the behaviour-preserving units depend on it.

---

## Q3. Deployment model per unit

The system deploys as two runtime images. The question is what the units
*declare*, since that drives which design artifacts each one owes in Construction.

**Option A — one `service` unit, the rest `library`, `ui`, `spec` or
`packaging`.** Only the HTTP surface is a deployed executable; identity, content
and media are libraries inside it with no standalone runtime; the two frontends
are `ui`; the containers are `packaging`; fixtures and the cloud plan are `spec`.
*Pro:* honest — there is exactly one Python process, and a unit that declares
`service` owes scalability and runtime design artifacts it does not need.
*Con:* the frontend is also a deployed runtime, so `ui` slightly understates it.

**Option B — two `service` units**: the HTTP surface and the Next.js renderer,
with the rest as above.
*Pro:* matches the two container images exactly. *Con:* the renderer owns no
application logic, so the service-level design artifacts would be largely empty.

A. Option A — one `service` unit; the Next.js renderer is `ui`.
B. Option B — two `service` units, one per container image.
C. Not yet defined.
X. Other (please specify)

[Answer]: A. Option A — one `service` unit; the Next.js renderer is `ui`.

---

## Consolidated Summary Confirmation

This entry serves as both the decomposition-plan approval required by the stage
and the pre-generation confirmation.

**Strategy:** by component cluster, following the dependency graph. [Q1]

**Twelve units**, with `kind` in brackets:

- `U1 source-fixtures` [spec] — recorded responses from the running source app. No dependencies. Expires when the source is retired.
- `U2 storage-ports` [library] — the three ports, their SQLite adapters, in-memory fakes, and one conformance suite per port. No dependencies.
- `U3 identity-and-session` [library] — owner account, sessions, login guard. Depends on U2.
- `U4 content-core` [library] — content document, validation, the combined write, revisions, retention policy, the published-document cache and the inspect operation. Depends on U2, U1.
- `U5 media` [library] — upload acceptance, variant generation, asset visibility, range handling. Depends on U2, U4, U1.
- `U6 http-api` [service] — routes, the single error envelope, middleware, the OpenAPI document. The one deployed Python executable. Depends on U3, U4, U5, U1.
- `U7 api-client` [library] — types generated from that OpenAPI document, plus transport. Depends on U6.
- `U8 public-site` [ui] — every public route, the SEO surface, the 3D scene. Depends on U7, U1.
- `U9 owner-editor` [ui] — every editing surface, recovery, preview, the browser tool. Depends on U7, U1.
- `U10 containers` [packaging] — two Dockerfiles, Compose, the volume layout, the end-to-end flow. Depends on U6, U8, U9.
- `U11 cloud-adapters` [library] — Firestore and Cloud Storage adapters run against the same conformance suites, shipped unverified against the real services. Depends on U2.
- `U12 deployment-plan` [spec] — the costed Cloud Run plan with measured image sizes. Depends on U10, U11.

**Fixture dependencies are real edges** [Q2]: U4, U5, U6, U8 and U9 each depend on
U1, so no characterization test can be scheduled before its oracle exists.

**Parallel opportunities:** U1 ∥ U2 at the start; U3 ∥ U4 once U2 lands;
U11 ∥ everything after U2; U8 ∥ U9 once U7 lands.

**One `service` unit** [Q3]: only `U6 http-api` is a deployed executable.

Does this all look correct before I generate the artifact?

- Looks correct
- Request changes

[Answer]: Looks correct
