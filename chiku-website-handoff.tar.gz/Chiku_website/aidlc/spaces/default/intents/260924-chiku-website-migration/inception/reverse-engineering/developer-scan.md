# Reverse-engineering scan results — `madhavi-tripathi/`

Link 1 of 2. Structured scan output for the architect, who authors the nine CodeKB
artifacts from this file. Every count below was produced by running a command against
the tree, not estimated. Section names match the nine target artifacts exactly.

Scope note: `.claude/` and `aidlc/` are the AI-DLC framework shell and workflow record.
They are excluded from every inventory, count and assessment in this document and are
mentioned only here to record the exclusion. `chiku-website/` does not exist yet and is
not described anywhere below.

---

## business-overview

**What the product is.** A single-person academic profile website with an owner-only,
no-code editor bolted onto it. One public page presents a researcher's profile,
selected work and news to visitors; one private page (`/edit`) lets exactly one person —
the site owner — rewrite every word of that page through forms, without touching code.

**The two audiences.**

| Audience | Reaches | Sees |
|---|---|---|
| Anonymous visitor | `/`, `/robots.txt`, `/sitemap.xml`, published media | The **published** document only |
| Site owner | `/edit`, `/edit/preview`, all four `/api/*` routes | Both the **draft** and the **published** document |

**The domain entities.** The content model is one document, not a set of tables. Every
entity below is a field or sub-object of that single document (`app/content.ts:20`,
serialised to ~15 KB — measured at 15,423 bytes in the local emulator database).

1. **Profile** — the person. Name, role, affiliation, location, headline, intro, bio,
   email, portrait photo with alt text, responsive photo variants and a focal point.
2. **Research themes** — up to 100 items. The strands of work the researcher pursues.
   Each carries a *card identity* (`materials`, `ultrasound`, `photoacoustic`,
   `general`) that drives its colour and icon on the page.
3. **Publications** — up to 500 items. Papers, each optionally linked to one or more
   research themes, with a citation count and the date that count was taken.
4. **Journey milestones** — up to 100 items. The career timeline (degrees, posts, moves).
5. **News / notes** — up to 100 items. Short updates.
6. **Achievements / highlights** — up to 60 items. Awards and moments, shown as a
   gallery carousel directly below the cover, with optional photo or video and captions.
7. **Site copy** — nine editable blocks of the page's own wording (hero, each of the six
   sections, the Scholar panel, the footer tagline). The owner can rename "Publications"
   to anything, rewrite every section heading and description, and change every button label.
8. **Appearance settings** — accent colour (`blue`, `burgundy`, `forest`), a motion
   on/off switch, six per-section visibility toggles, and an optional site-wide notice banner.
9. **3D scene story** — the animated cover. Three narrated views (delivery,
   photoacoustic, ultrasound) each with a title, description and link, plus which view
   opens first and whether a guided tour is offered.
10. **Scholar highlights** — an optional panel of hand-entered Google Scholar figures
    (citations, h-index, i10-index, "as of" date, affiliation, interests). It is
    explicitly a snapshot the owner types in, **not** a live sync
    (`docs/CONTENT-SOURCES.md`).

The five numbered collections (2–6) all share one **Item** shape, which is why the
editor can present them with the same form. See `## api-documentation` → *Content schema*
for every field and constraint.

**The draft/publish lifecycle.** The heart of the product. One database row holds two
complete copies of the document:

- **draft** — what the owner is working on. Private. Never shown to a visitor.
- **published** — what visitors see. Only changes when the owner explicitly publishes.

Every save is one of two actions. `draft` writes the draft column only. `publish` writes
*both* columns to the same value, so publishing is "make the draft the live page". There
is no scheduling, no partial publish and no per-section publish: the document is
published whole or not at all.

A **revision counter** on the row increments on every save of either kind. The editor
holds the revision it loaded and sends it back with each save; if it no longer matches,
the save is refused and the owner is told the draft changed elsewhere.

**The editorial workflow as the owner experiences it.**

1. Sign in, open the site, choose *Edit website* in the footer.
2. Work through ten tabs: Profile, Highlights, Research, Publications, Journey,
   Notes & news, 3D story, Scholar, Website text, Appearance.
3. **Valid** changes save themselves as a draft 1.5 seconds after typing stops. Invalid
   ones do not — the offending fields are listed and the owner is told to fix them.
4. *Preview draft* renders the draft exactly as visitors would see it, without publishing.
5. *Publish changes* makes the draft live.
6. **Revision history** offers the last 52 saved versions and can restore any of them as
   a draft. Restoring never publishes. The very first save also captures a permanent
   "starting draft" and "starting published" pair that is never pruned.
7. If the browser dies mid-edit, unsaved work is offered back on the next visit
   ("Recover an editing session?"), per tab.

**Who may edit.** Exactly one person. Authorisation is a row in an `editors` table,
bootstrapped by a single hard-coded owner email (`app/server.ts:5`). There are no roles,
no tiers, no editor-versus-publisher split, and no invite mechanism.

**Content provenance.** The seed content is real, sourced data about a named individual,
with every claim traced to a citation in `docs/CONTENT-SOURCES.md`. The README states
that missing facts were deliberately left blank rather than invented. Any migration that
"fills in" empty fields would violate a stated product rule.

**An in-product agent capability.** When the browser exposes WebMCP, the editor
registers a `stage_academic_profile` tool that lets an assistant fill six profile fields
into the form. It stages only; it never saves and never publishes. Detail in
`## code-quality-assessment` → *WebMCP tool*.

---

## architecture

### Runtime topology as it is today

Everything — page rendering, API handling, authorisation and data access — runs in **one
Cloudflare Worker**. There is no separate application server, no container, and no
network hop between "frontend" and "backend". `vinext@1.0.0-beta.5` is a Vite-based
runtime that presents a Next.js 16.3.4 App Router programming model on top of the Workers
runtime. React Server Components render inside the Worker; the browser receives HTML plus
a client bundle.

Two Cloudflare services are bound to the Worker by logical name, declared in
`.openai/hosting.json`:

```json
{ "d1": "DB", "r2": "BUCKET", "project_id": "appgprj_6ab410c1958881919d6bb03246327b86" }
```

`db/index.ts` (3 lines) is the entire data-access abstraction — it reads
`env.DB` / `env.BUCKET` from `cloudflare:workers` and throws if either is missing. Every
query in the application is raw SQL against the returned `D1Database` handle.

### Request path

```mermaid
flowchart TD
  V["Visitor browser"] --> W
  O["Owner browser at /edit"] --> W
  W["Cloudflare Worker: vinext + Next.js 16.3.4"]
  W --> RSC["Server components: page.tsx, edit/page.tsx, sitemap.ts, robots.ts"]
  W --> API["Route handlers: api/content, api/history, api/upload, api/media"]
  RSC --> AUTH
  API --> AUTH
  AUTH["editorAccess in app/server.ts line 15"]
  AUTH --> HDR["getChatGPTUser reads oai-authenticated headers"]
  AUTH --> ED[("D1 table: editors")]
  API --> ORIG["sameOrigin check, PUT and POST only"]
  API --> ZOD["contentSchema.safeParse in app/content.ts line 20"]
  ZOD --> CP["content-persistence.ts: seven-statement D1 batch"]
  CP --> SC[("D1 table: site_content, draft and published and revision")]
  CP --> CR[("D1 table: content_revisions")]
  API --> R2[("R2 bucket: BUCKET")]
  API --> AS[("D1 table: assets")]
  RSC --> CP
```

**Text fallback for the diagram.** Both the visitor browser and the owner browser talk to
a single Cloudflare Worker running vinext plus Next.js 16.3.4. Inside the Worker, requests
split two ways: server components (`page.tsx`, `edit/page.tsx`, `sitemap.ts`, `robots.ts`)
and route handlers (`/api/content`, `/api/history`, `/api/upload`, `/api/media/[key]`).
Both paths call `editorAccess()` at `app/server.ts:15`, which calls `getChatGPTUser()` to
read the platform-injected `oai-authenticated-*` headers and then looks the user up in the
D1 `editors` table. The two mutating route handlers additionally call `sameOrigin()`.
Content writes go through `contentSchema.safeParse` in `app/content.ts:20` and then into
`content-persistence.ts`, which issues one seven-statement D1 batch against `site_content`
and `content_revisions`. Uploads write to the R2 bucket and to the D1 `assets` table.
Server components read content through the same persistence module.

### Where authentication is decided

**Nowhere in this codebase.** The application does not authenticate anyone. It trusts
four HTTP headers injected by the ChatGPT hosting platform
(`app/chatgpt-auth.ts:11-16`):

- `oai-authenticated-user-id`
- `oai-authenticated-user-email`
- `oai-authenticated-user-full-name`
- `oai-authenticated-user-full-name-encoding`

`getChatGPTUser()` (`app/chatgpt-auth.ts:21`) returns `null` unless **both** the user-id
and email headers are present; otherwise it returns them as a trusted identity. There is
no signature check, no token validation, no session cookie and no expiry. The security
model is entirely "the platform terminates the request and the Worker is not reachable
directly". Sign-in, sign-out and callback are platform routes (`/signin-with-chatgpt`,
`/signout-with-chatgpt`, `/callback`) that are **not** implemented in this repository.

Locally, `build/sites-vite-plugin.ts` fakes these headers for `local_seedy` /
`seedy@sites.test` via a `__sites_local_auth` cookie, restricted to localhost.

> **Migration hazard.** Anything that puts the Worker behind a proxy, or reproduces this
> pattern without the platform in front of it, makes the editor world-writable: an
> attacker who can set two request headers becomes the owner. There is no second factor
> anywhere in the code.

### Where authorization is decided

`app/server.ts`, in `isEditor()` (lines 6–14), reached through `editorAccess()` (line 15):

1. No user → not an editor.
2. `SELECT user_id FROM editors WHERE user_id = ?` → row exists → editor.
3. Otherwise, if `user.email.toLowerCase()` equals the hard-coded
   `OWNER_EMAIL = 'madhavi.tri16@gmail.com'` (line 5) → `INSERT OR IGNORE` that user into
   `editors`, re-select, and return the result.

So authorisation is a self-bootstrapping allowlist of one, seeded by a **hard-coded email
address in source**. There are no roles and no permission levels: `isEditor` is the only
authorisation predicate in the codebase, and it gates every privileged path.

Call sites: `app/api/content/route.ts:6,10`, `app/api/history/route.ts:7`,
`app/api/upload/route.ts:17`, `app/api/media/[key]/route.ts:8`, `app/edit/page.tsx:8`,
`app/edit/preview/page.tsx:8`, and `app/page.tsx:7` (to decide whether to show the
"Edit website" footer link).

> **Migration hazard.** `app/page.tsx:7` calls `editorAccess()` on **every public page
> render**, purely to decide whether to show one footer link. That means every anonymous
> visitor request performs a D1 lookup that is only meaningful for one person.

### Where validation happens — in both places, via the same schema

`app/content.ts` exports one zod schema, `contentSchema`. It is imported and executed on
**both sides of the network boundary**:

| Side | File and line | What it does with the result |
|---|---|---|
| Browser | `app/edit/editor-workflow.ts:54` | Blocks the save entirely; renders `issues[]` as a "check these fields" list |
| Browser | `app/edit/editor-workflow.ts:17` | Validates a recovered localStorage draft |
| Browser | `app/edit/editor-workflow.ts:73` | Re-validates the draft fetched by *Load latest draft* |
| Browser | `app/edit/editor.tsx` (`RevisionHistory.select`) | Validates a historical revision before offering to restore it |
| Worker | `app/api/content/route.ts:14` | Rejects with 400 and returns `issues[]` |
| Worker | `app/content-persistence.ts:10` | `normalizeStoredContent` — re-parses **on every read out of D1** |

Because the same module runs in both places, client and server can never disagree today.

> **Migration hazard — the highest-leverage one in this section.** The moment the server
> is Python, this single schema becomes two schemas in two languages. Every constraint in
> `## api-documentation` → *Content schema* must be reproduced exactly, and the
> `.transform()` and `.default()` behaviour must be reproduced too — not just the
> validation rules. `normalizeStoredContent` re-parsing on every read means the schema is
> also the **storage read path**: tighten a rule and previously-stored documents stop
> loading, which surfaces as a 503 on `/`, `/api/content` and every `/api/media/*`
> request simultaneously.

### The draft/published split and how a change reaches a visitor

One row, `site_content` with `id = 1`, holds both documents:

```
site_content(id=1, draft TEXT, published TEXT, revision INT,
             updated_at TEXT, published_at TEXT NULL, last_mutation TEXT NULL)
```

The path from an owner's keystroke to a visitor's screen:

1. Owner types. `useDraftWorkflow` marks the document dirty.
2. 1.5 s after typing stops, if the document is valid, the editor `PUT`s
   `{content, revision, action: 'draft', autosave: true}`.
3. The Worker validates, then runs the seven-statement D1 batch. `draft` is replaced;
   `published` is untouched; `revision` increments.
4. Nothing changes for visitors. Repeat 1–3 indefinitely.
5. Owner presses *Publish changes*. Same `PUT`, `action: 'publish'`, `autosave` absent.
6. The batch's `UPDATE` sets `published = draft = <new content>` and stamps
   `published_at = now`.
7. The next visitor request runs `app/page.tsx`, which is `dynamic = 'force-dynamic'`.
   It reads the row fresh from D1 and renders `data.published`.

**Propagation is immediate and uncached.** Every public page render is a fresh D1 read;
there is no ISR, no revalidation window and no CDN cache in front of the HTML. There is
therefore no "publish then wait" step and no cache to purge. `hasUnpublishedChanges` is
computed on the fly as `JSON.stringify(draft) !== JSON.stringify(published)`
(`app/content-persistence.ts:16`) — a full string comparison of two ~15 KB documents on
every single read.

> **Migration hazard.** That `force-dynamic` + no-cache posture is load-bearing for the
> product's feel ("publish and it's live"), but it means the read path has no caching
> headroom designed into it. Any new architecture that introduces caching changes
> observable publish behaviour.

### Trade-off note for the architect

This topology has exactly one merit worth recording and one cost. The merit: colocating
render and data in one Worker makes the published document reachable with zero network
hops and makes the draft/published swap atomic within a single D1 transaction. The cost:
authentication is delegated entirely to the host platform, so the application has no
identity mechanism of its own to carry forward — the migration must *add* one, not port one.

---

## code-structure

### Top-level layout

Counts are from `find` over the tree with `node_modules/`, `.next/`, `.vinext/`, `dist/`,
`.wrangler/`, `.sites-runtime/`, `outputs/` and `examples/` excluded. **157 files** remain
(git tracks 158 under `madhavi-tripathi/`; the difference is `tsconfig.tsbuildinfo`, a
generated file recorded as omitted in `SOURCE-MANIFEST.json`).

| Directory | Files | Purpose |
|---|---|---|
| `app/` | 47 (22 `.ts`, 16 `.tsx`, 9 `.css`) | The entire application: pages, API routes, domain logic, styles |
| `components/ui/` | 61 `.tsx` | Vendored shadcn 4.17.0 registry components |
| `db/` | 2 | `index.ts` (binding accessors) + `schema.ts` (drizzle, build-time only) |
| `drizzle/` | 5 | 2 SQL migrations + drizzle-kit metadata |
| `hooks/` | 1 | `use-mobile.ts` |
| `lib/` | 1 | `utils.ts` (the shadcn `cn()` helper) |
| `public/` | 6 | favicon, cover image, Inter woff2, 3 unused SVGs |
| `scripts/` | 10 | Cloudflare/OpenAI-Sites installer and environment shims (1,089 lines) |
| `build/` | 2 | Vendored `@openai/sites-vite-plugin` 0.2.0 + its MIT licence |
| `vendor/` | 2 | shadcn Tailwind 4.13.0 CSS + its MIT licence |
| `docs/` | 1 | `CONTENT-SOURCES.md` — content provenance |
| root | 18 | configs, manifests, README, two archive-only prompt files |

**Line counts.** 9,513 lines of `.ts`/`.tsx` across the scanned tree. Of those,
`components/ui/` is **7,334** (77%) and `app/` is **1,819** (19%). Plus 1,124 lines of
CSS in `app/` and 629 in `vendor/`.

The shape to notice: the application's own logic is under 1,900 lines. Three quarters of
the TypeScript in the repository is vendored UI library code, most of which is never used
(see `## component-inventory`).

### `app/` module responsibilities

Line counts are exact. Note how small these files are — see
`## code-quality-assessment` for why that number is misleading.

**Route entry points (10).** These are the only files the framework invokes directly.

| File | Lines | Responsibility |
|---|---|---|
| `app/page.tsx` | 9 | Public page. Parallel `readContent()` + `editorAccess()`; injects JSON-LD; renders `AcademicSite` |
| `app/layout.tsx` | 13 | HTML shell; imports all 9 CSS files; wraps in `ColorModeProvider` |
| `app/robots.ts` | 5 | Static robots rules; disallows `/edit` and `/api/` |
| `app/sitemap.ts` | 8 | One URL, `lastModified` = `publishedAt` |
| `app/edit/page.tsx` | 11 | Owner gate → renders `Editor` with the draft |
| `app/edit/preview/page.tsx` | 10 | Owner gate → renders `PreviewClient` |
| `app/api/content/route.ts` | 21 | GET draft+published state; PUT save/publish |
| `app/api/history/route.ts` | 14 | GET revision list or one revision |
| `app/api/upload/route.ts` | 75 | POST multipart media upload |
| `app/api/media/[key]/route.ts` | 21 | GET/HEAD media bytes |

**Domain and persistence (server-reachable).**

| File | Lines | Responsibility |
|---|---|---|
| `app/content.ts` | 66 | **The schema.** zod `contentSchema` + `initialContent` seed. 12,484 bytes |
| `app/content-persistence.ts` | 58 | All content SQL: read state, the 7-statement write batch, revision list/fetch |
| `app/server.ts` | 16 | `isEditor` / `editorAccess` / `sameOrigin`; re-exports `readContent` |
| `app/chatgpt-auth.ts` | 90 | Platform header identity; sign-in/out path builders; return-path sanitisation |
| `app/upload-validation.ts` | 68 | Hand-written PNG/WebP/JPEG header parsers + WebVTT validator |
| `app/media-utils.ts` | 22 | `videoSource()` host allowlist; `parseByteRange()` |
| `app/site-copy.ts` | 43 | `copySchema`, `initialCopy`, **and** `initialResearchLinks` |
| `app/research-identity.ts` | 18 | Topic enum, labels, and the `originalTopics` back-compat map |
| `app/scene-content.ts` | 10 | Scene types + `initialScene` defaults |
| `app/site-metadata.ts` | 42 | OG/Twitter metadata + JSON-LD. **Hard-codes `siteOrigin` at line 5** |

**Presentation (client).**

| File | Lines | Responsibility |
|---|---|---|
| `app/site.tsx` | 122 | `AcademicSite` — the whole public page, all six sections |
| `app/achievements.tsx` | 125 | Highlights gallery carousel + media lightbox |
| `app/publications.tsx` | 74 | Publication archive with search/year/topic/sort |
| `app/research-section.tsx` | 43 | Research theme spreads + related-paper counts |
| `app/updates.tsx` | 29 | News carousel |
| `app/scene.tsx` | 142 | 3D cover; gates and lazily imports the WebGL renderer |
| `app/nano-renderer.ts` | 129 | three.js renderer. **Builds to a 560,248-byte client chunk** |
| `app/scene-performance.ts` | 16 | `shouldLoadResearchScene` — motion/save-data gate |
| `app/responsive-image.tsx` | 31 | `srcset` builder with per-source URL sanitisation |
| `app/color-mode.tsx` | 19 | next-themes provider + toggle |
| `app/publication-utils.ts` | 50 | Filter/sort/anchor/URL logic for publications |
| `app/use-section-carousel.ts` | 43 | Shared carousel state, reduced-motion handling, arrow keys |

**Editor (client).**

| File | Lines | Bytes | Responsibility |
|---|---|---|---|
| `app/edit/editor.tsx` | 99 | 34,555 | The whole 10-tab editor. Largest file in `app/` |
| `app/edit/editor-workflow.ts` | 78 | 9,831 | `useDraftWorkflow` — save, autosave, recovery, conflict state |
| `app/edit/upload-field.tsx` | 126 | 9,791 | XHR upload with progress, abort, retry |
| `app/edit/draft-preview.tsx` | 12 | 2,861 | In-editor preview overlay |
| `app/edit/preview/preview-client.tsx` | 13 | 1,913 | Standalone draft preview page body |
| `app/image-processing.ts` | 48 | 2,308 | **Browser-side** canvas WebP variant generation |

### Import graph

Computed by resolving every `import`/`require`/dynamic-`import` specifier against the
tree (script: `/private/tmp/.../scratchpad/reach.mjs`).

**`app/` → `db/`.** Exactly four files import `@/db`:
`app/content-persistence.ts`, `app/server.ts`, `app/api/upload/route.ts`,
`app/api/media/[key]/route.ts`. All four use the raw `D1Database`/`R2Bucket` handles.

**`app/` → `components/ui/`.** Eleven components, from ten `app/` files. Full edge list:

```
alert-dialog  <- app/edit/editor.tsx
carousel      <- app/achievements.tsx, app/updates.tsx, app/use-section-carousel.ts
collapsible   <- app/publications.tsx, app/research-section.tsx, app/scene.tsx
dialog        <- app/achievements.tsx
progress      <- app/edit/upload-field.tsx
radio-group   <- app/edit/editor.tsx
select        <- app/edit/editor.tsx, app/publications.tsx
slider        <- app/edit/editor.tsx
switch        <- app/edit/editor.tsx
tabs          <- app/edit/editor.tsx, app/scene.tsx
toggle        <- app/color-mode.tsx
```

**`app/` → `lib/`: zero edges.** `lib/utils.ts` is imported by **57 of the 61**
`components/ui/` files and by **no `app/` file at all**. It exists solely to serve the
vendored component library.

**`app/` → `hooks/`: zero edges.** `hooks/use-mobile.ts` is imported only by
`components/ui/sidebar.tsx`, which is itself never imported. Both are dead.

**`db/schema.ts` is not in the runtime graph.** This is the finding most likely to
mislead a migration. Reachability analysis from the ten Next.js entry points reaches **52
files**, and `db/schema.ts` is not one of them. It is imported only by
`drizzle.config.ts`, which exists to run `drizzle-kit generate`. Grepping for `drizzle`
across `app/` and `db/` returns exactly one hit: the import on line 1 of `db/schema.ts`.

So **drizzle-orm is not the runtime data layer.** Every query in this application is a
hand-written SQL string passed to `db.prepare(...)`. Drizzle is a build-time schema-authoring
and migration-generation tool only. Describing this system as "using an ORM" would be wrong.

**Internal `app/` clusters.**

- *Schema cluster*: `content.ts` ← `site-copy.ts`, `research-identity.ts`,
  `scene-content.ts`. Imported by both server routes and browser editor. This is the
  module that straddles the boundary.
- *Persistence cluster*: `content-persistence.ts` → `db/index.ts` + `content.ts`.
  `server.ts` re-exports `readContentState` as `readContent`, so route handlers and page
  components import persistence *through* `server.ts`.
- *Editor cluster*: `editor.tsx` → `editor-workflow.ts` → `content.ts`;
  `editor.tsx` → `upload-field.tsx` → `image-processing.ts`.
- *Public-site cluster*: `site.tsx` → `achievements`, `publications`, `research-section`,
  `updates`, `scene`, `responsive-image`, `color-mode`.

**External packages imported outside `components/ui/`** (10 only):
`react`, `next`, `zod`, `three`, `lucide-react`, `next-themes`, `clsx`, `tailwind-merge`,
`cloudflare:workers`, `drizzle-orm`. Everything else in `dependencies` is reached only
through vendored UI components, or not at all.

### Seams a migration would cut along

Ranked by how cleanly the code already separates.

1. **`db/index.ts` (3 lines) — the cleanest seam in the repository.** Two functions
   returning two bindings. Every storage access in the application passes through them.
   Replace these two functions and the storage backend changes, provided callers stop
   using D1-specific APIs (`.prepare/.bind/.first/.all/.batch`) and R2-specific ones
   (`.head/.get/.put/.delete`, `httpEtag`, `range`).

2. **`app/content.ts` — schema versus seed.** The file holds two independent things: the
   validation schema (lines 1–24) and the `initialContent` seed data (lines 25–66). The
   schema must be re-expressed in the target language; the seed is pure data and can be
   serialised across unchanged. They are cleanly separable, and separating them is the
   first move.

3. **`app/server.ts` (16 lines) — the authorization seam.** `isEditor` is the only
   authorisation predicate and has exactly seven call sites (listed under
   `## architecture`). Authentication (`chatgpt-auth.ts`) sits behind it and is entirely
   replaceable without touching `isEditor`'s shape.

4. **`app/content-persistence.ts` — the transactional seam.** All content SQL is in one
   58-line file, and `contentWriteStatements()` is deliberately factored as a *pure
   function returning statements* separately from `writeContent()` which executes them.
   That factoring is the single best thing about this codebase's structure — it makes the
   transaction inspectable. It is also the riskiest thing to re-express; see
   `## code-quality-assessment` → *the seven-statement batch*.

5. **The four route handlers — the HTTP seam.** 131 lines total. Each is
   self-contained: guard, validate, act, respond. No shared middleware, no framework
   plumbing to unwind.

6. **`app/image-processing.ts` — a seam that currently runs on the wrong side.** The
   browser generates WebP variants and the Worker then re-verifies them
   (`app/api/upload/route.ts:26-47`). This is a validation burden that exists *only*
   because the work happens client-side.

**Seams that do not exist and would have to be cut, not followed:**

- **No service layer.** Route handlers call persistence functions directly. There is no
  place where "business rules" live apart from HTTP and SQL.
- **No repository interface.** `content-persistence.ts` is simultaneously the domain
  operations and the SQL.
- **No shared error type.** Each route hand-writes its own `{error: '...'}` literals.
- **`app/content.ts` deliberately straddles the client/server line.** Splitting it is the
  point at which client and server validation can silently diverge.
- **`app/edit/editor.tsx` is one 34.5 KB file** holding all ten tabs and seven
  components. There is no per-tab seam to cut along.

---

## api-documentation

Four route files, 131 lines total, all `export const dynamic = 'force-dynamic'`.

Three shared guards:

- **`editorAccess()`** — `app/server.ts:15`. Detailed under `## architecture`.
- **`sameOrigin(request)`** — `app/server.ts:16`.
  `const origin = request.headers.get('origin'); return !!origin && origin === new URL(request.url).origin;`
  A **missing** `Origin` header fails this check. Applied to `PUT /api/content` and
  `POST /api/upload` only. This is the only CSRF defence in the application; there is no
  token.
- **`reply(body, status)`** — defined identically but separately in
  `app/api/content/route.ts:5` and `app/api/history/route.ts:14`:
  `Response.json(body, {status, headers: {'Cache-Control': 'no-store'}})`.

---

### `GET /api/content`

**Auth:** editor required. **Same-origin:** not checked. **Request:** no body, no params.

| Status | Condition | Body |
|---|---|---|
| 200 | Editor | Full `ContentState` |
| 403 | `editorAccess()` false | `{error: 'Please sign in with the website owner's account.'}` |
| 503 | Any thrown exception | `{error: 'Unable to load your draft. Please try again.'}` |

200 body shape (`app/content-persistence.ts:5-6`):

```ts
{ draft: Content, published: Content, revision: number,
  updatedAt: string|null, publishedAt: string|null, hasUnpublishedChanges: boolean }
```

`hasUnpublishedChanges` is computed, not stored:
`JSON.stringify(draft) !== JSON.stringify(published)` (`content-persistence.ts:16`).

When no row exists, `readContentState()` synthesises
`{draft: initialContent, published: initialContent, revision: 0, updatedAt: null, publishedAt: null, hasUnpublishedChanges: false}`
without writing anything (`content-persistence.ts:20`).

**503 causes include a zod failure**, because `normalizeStoredContent` parses both stored
columns on every read. A stored document that no longer satisfies the schema produces 503,
not 200-with-warnings.

---

### `PUT /api/content`

**Auth:** editor required. **Same-origin:** required. **Content-Type:** not checked.

Request body:

```ts
{ content: Content,            // validated by contentSchema
  revision: number,            // the revision the editor loaded
  action: 'draft' | 'publish',
  autosave?: boolean }         // optional; only legal when action === 'draft'
```

Checks run **strictly in this order** — the order determines which status code a
multiply-invalid request receives:

| # | Line | Check | On failure |
|---|---|---|---|
| 1 | `:9` | `sameOrigin(request)` | **403** `'This request could not be verified. Refresh and try again.'` |
| 2 | `:10` | `editorAccess()` | **403** `'Please sign in with the website owner's account.'` |
| 3 | `:11` | `bodyText.length > 1500000` | **413** `'This update is too large.'` |
| 4 | `:12` | `JSON.parse` throws | **400** `'The update could not be read.'` |
| 5 | `:13` | Body falsy, non-object, or an array | **400** `'Invalid save request.'` |
| 6 | `:14-15` | `contentSchema.safeParse(body.content)` | **400** `'Please check the highlighted fields before saving.'` + `issues[]` |
| 7 | `:16` | Envelope validation (below) | **400** `'Invalid save request.'` |
| 8 | `:17-18` | `writeContent()` returns `null` | **409** conflict + latest metadata |
| — | `:19` | Success | **200** |
| — | `:20` | Any throw | **503** `'Your changes could not be saved...'` |

Step 7 rejects unless **all** hold (single expression at line 16):
`Number.isSafeInteger(body.revision)` · `body.revision >= 0` ·
`body.revision < Number.MAX_SAFE_INTEGER` · `body.action` is `'draft'` or `'publish'` ·
`body.autosave` is `undefined` or boolean · not (`autosave === true` && `action !== 'draft'`).

> **Migration hazard — step ordering.** Content validation (6) runs **before** envelope
> validation (7). A request with both a malformed `content` and a bad `revision` returns
> the *content* 400 with `issues[]`, not the envelope 400. Reordering these silently
> changes the error the editor displays.

> **Migration hazard — the 413 cap is characters, not bytes.** `request.text()` returns a
> JavaScript string; `.length` counts UTF-16 code units. The cap is **1,500,000
> characters**. A document of 1.5 M non-ASCII characters can be 3–4 MB of UTF-8. A Python
> implementation capping at 1,500,000 *bytes* rejects documents this implementation
> accepts. Note also that the full body is read into memory at line 11 *before* the check,
> so the cap limits document size, not memory use.

**200 body:** `{...ContentMetadata, published: boolean}` — that is `revision`, `updatedAt`,
`publishedAt`, `hasUnpublishedChanges`, plus `published: body.action === 'publish'`.

**409 body:** `{error: 'This draft changed in another tab. Your edits are still here. Review the latest saved draft before saving again.', revision, updatedAt, publishedAt, hasUnpublishedChanges}`
— the error string **plus the current server metadata**, fetched by a second read at line 18
so the editor can show what it is now up against.

**The optimistic-concurrency path.** `writeContent()` returns `null` exactly when
`results[3]?.results?.[0]` is undefined — i.e. when the `UPDATE ... WHERE id = 1 AND
revision = ?` matched no row. Full analysis in `## code-quality-assessment` → *the
seven-statement batch*.

---

### `GET /api/history`

**Auth:** editor required. **Same-origin:** not checked.

Two modes, selected by the presence of `?id=`:

| Condition | Status | Body |
|---|---|---|
| `editorAccess()` false | 403 | `{error: 'Please sign in with the website owner's account.'}` |
| `id` param absent (`=== null`) | 200 | `{revisions: RevisionSummary[]}` |
| `id` empty, `> 100` chars, or fails `/^[a-zA-Z0-9-]+$/` | 400 | `{error: 'Choose a saved version from the history list.'}` |
| `id` valid, row found with content | 200 | `RevisionSummary & {content: Content}` |
| `id` valid, no row (or row has no content) | 404 | `{error: 'This version is no longer in the recent history. Your current draft is unchanged.'}` |
| Any throw | 503 | `{error: 'Version history is temporarily unavailable. Your current edits are safe.'}` |

Note the distinction at line 9: `id === null` (absent) means *list*. `?id=` (present but
empty) falls through to line 10 and is a **400**, not a list.

`RevisionSummary` = `{id, revision, action: 'draft'|'publish', createdAt, baseline: boolean}`.

List query (`content-persistence.ts:52`):
`SELECT id, revision, action, created_at, baseline FROM content_revisions ORDER BY revision DESC, baseline ASC, action DESC LIMIT 52`.
The three-part sort is load-bearing for display order: newest revision first; within a
revision non-baselines before baselines; then `'publish'` before `'draft'` (descending
string order).

`baseline` is stored as SQLite integer and coerced with `!!row.baseline`
(`content-persistence.ts:49`).

> **Migration note.** The 52 limit is not a page size — there is no pagination. Retention
> keeps at most 30 drafts + 20 publishes + 2 baselines = 52. The limit and the retention
> policy are the same number by construction.

---

### `POST /api/upload`

**Auth:** editor required. **Same-origin:** required. Both are checked in one combined
condition at line 17, so both failures yield the same 403.

Request: `multipart/form-data` with fields
`file` (required, `File`), `kind` (optional; `'captions'` selects the VTT path),
`variants` (0–2 `File`s), `optimized` (`'true'` to declare browser-prepared variants).

Accepted MIME → extension map (lines 6–9):
`image/jpeg`→`jpg`, `image/png`→`png`, `image/webp`→`webp`, `application/pdf`→`pdf`,
`video/mp4`→`mp4`, `video/webm`→`webm`, `text/vtt`→`vtt`.

Checks in order:

| # | Line | Check | On failure |
|---|---|---|---|
| 1 | `:17` | `sameOrigin` **and** `editorAccess` | **403** |
| 2 | `:18` | `request.signal.aborted` | **499** (via `checkCancelled`) |
| 3 | `:19` | `Number(content-length ?? 0) > 51 MB` | **413** |
| 4 | `:22` | `file` not a `File`, or `file.size === 0` | **400** `'Choose a non-empty file.'` |
| 5 | `:25` | `mime` not in the map, or captions-kind with non-VTT mime | **400** format message |
| 6 | `:28` | Variant envelope invalid (below) | **400** `'The prepared image sizes could not be verified...'` |
| 7 | `:31` | Sum of all file sizes > per-kind limit | **413** `` `Choose files totaling less than ${limit} MB.` `` |
| 8 | `:35` | A variant's type is not `image/webp` | **400** `'Prepared photo sizes must use WebP.'` |
| 9 | `:40-41` | Magic-byte validation fails | **400** format or VTT message |
| 10 | `:42` | `optimized` and any dimension > 1600 px | **400** `'Prepared photo sizes must be no larger than 1600 pixels.'` |
| 11 | `:43-47` | Variant larger than original, or aspect mismatch | **400** `'Prepared photo sizes must match the original framing.'` |
| — | `:62` | Success | **200** |
| — | `:71` | `AbortError` | **499** `'Upload cancelled. Your previous file is unchanged.'` |
| — | `:73` | Anything else | **503** `'Upload failed. Please try again; your form changes are safe.'` |

**Captions MIME coercion (line 24).** If `kind === 'captions'` **and** the filename ends
`.vtt` **and** `file.type` is empty or one of `text/vtt`, `text/plain`,
`application/octet-stream`, the mime is forced to `text/vtt`. Otherwise `file.type` is
used as-is. This exists because browsers rarely set `text/vtt`.

**Variant envelope (line 28)** rejects if: more than 2 variants · any variant is not a
`File` or is empty · variants present without `optimized === 'true'` · `optimized` true
while the main file's mime is not `image/webp`.

**Size caps (line 30):** `video/*` → 50 MB · `text/vtt` → 1 MB · everything else → 10 MB.
The cap at line 31 applies to the **sum** of the original and its variants, not per file.
`MB = 1024 * 1024` (line 5), so these are mebibytes.

> **Migration hazard — the 51 MB pre-check is advisory only.** Line 19 reads the
> `content-length` header; a request without one yields `Number(null || 0) === 0` and
> passes. The authoritative cap is the post-parse sum at line 31. Reproducing only the
> header check would leave the cap unenforced; reproducing only the sum check changes
> when the rejection happens (after buffering rather than before).

**How many bytes are read for validation (line 36).** For images and VTT, the **entire
file** is read into a `Uint8Array`. For PDF, MP4 and WebM, only `entry.slice(0, 32)`.
This matters for memory: a 10 MB image is fully buffered; a 50 MB video is not.

**Magic-byte dispatch (line 40)**, where `head` is the UTF-8 decode of the first 12 bytes:

| Type | Test |
|---|---|
| `image/*` | `imageDimensions(bytes, mime)` returns non-null |
| `text/vtt` | `validCaptions(bytes)` |
| `video/mp4` | `head.slice(4, 8) === 'ftyp'` |
| `video/webm` | `bytes[0..3] === 0x1a 0x45 0xdf 0xa3` (EBML) |
| `application/pdf` | `head.startsWith('%PDF-')` |

**Aspect-ratio tolerance (line 45–46).** A variant is rejected if it is wider or taller
than the original, or if
`|w_v/h_v − w_o/h_o| > 2 / min(h_v, h_o)`.
The tolerance scales with the smaller height, permitting the rounding error a downscale
introduces. This exact formula must be reproduced or legitimate variants start failing.

**Write sequence per entry (lines 51–60).** For each of the 1–3 files: generate
`` `${crypto.randomUUID()}.${ext}` ``, push to `written[]`, `bucket().put(key, file, {httpMetadata: {contentType}})`,
then `INSERT INTO assets (key, filename, mime, size, created_at)` with the filename
truncated to 200 characters (`entry.file.name.slice(0, 200)`). `checkCancelled()` runs
between every step.

**These are two separate non-transactional writes.** R2 and D1 have no shared transaction.
A failure between them leaves an orphan.

**Cleanup (lines 64–70).** On *any* exception, every key in `written[]` is deleted from
both R2 and D1 under `Promise.allSettled`, so a partial failure does not leave orphans —
*provided the handler runs to the catch block*. It is explicitly documented as best-effort.

**200 body:**
`{url: '/api/media/<first-key>', filename: file.name, sources: [{src, width, height}, ...]}`
with `sources` sorted ascending by width, and **populated only when `optimized` is true**
(line 59). Non-optimised uploads return `sources: []`.

> **Migration hazard.** `sources` is empty for any upload the browser did not pre-process.
> Moving variant generation server-side changes this response for every upload.

---

### `GET` and `HEAD /api/media/[key]`

Both methods are the same function (`app/api/media/[key]/route.ts:20-21`).

**Auth:** conditional — see below. **Same-origin:** not checked.

| # | Line | Check | On failure |
|---|---|---|---|
| 1 | `:6` | `key` matches `/^[a-f0-9-]+\.(jpg|png|webp|pdf|mp4|webm|vtt)$/` | **404** `'Not found'` |
| 2 | `:7-8` | Not public **and** not an editor | **404** `'Not found'` |
| 3 | `:9` | No `assets` row for `key` | **404** `'Not found'` |
| 4 | `:10` | `storage.head(key)` returns nothing | **404** `'Not found'` |
| 5 | `:12` | `method === 'HEAD'` | **200**, headers only, null body |
| 6 | `:15` | `parseByteRange(...) === 'invalid'` | **416** |
| 7 | `:16` | `storage.get` returns nothing | **404** |
| 8 | `:18` | Range present | **206** |
| 9 | `:18` | No range | **200** |
| — | `:19` | Any throw | **503** `'File temporarily unavailable'` |

Every denial is a **404**, never a 403 — the route does not distinguish "no such asset"
from "not permitted", which avoids confirming the existence of unpublished media.

**Response headers (line 11), set for every success:**

```
Content-Type: <assets.mime>            (from D1, not from R2)
Cache-Control: private, no-cache
X-Content-Type-Options: nosniff
Content-Security-Policy: default-src 'none'; sandbox
Accept-Ranges: bytes
ETag: <R2 metadata.httpEtag>
Content-Length: <R2 metadata.size>
```

`Content-Type` comes from the **D1 `assets` row**, not from R2's stored metadata. Those
are written from the same value at upload time, so they agree today — but they are two
independent stores and a migration that syncs only one will serve mismatched types.

**HEAD behaviour.** Returns 200 with the *full* `Content-Length` and never inspects
`Range`. It therefore never returns 206 or 416, even when the equivalent GET would. This
is a deliberate early return at line 12.

**Conditional-request support.** `If-Range` is honoured. `If-None-Match` is **not** —
there is no 304 path at all, so despite emitting an `ETag` the route always transfers the
full selected byte range. Combined with `Cache-Control: private, no-cache`, every media
request is a full transfer through the Worker.

**Byte-range handling (lines 13–17).**

```ts
const ifRange = request.headers.get('if-range');
const range = parseByteRange(
  !ifRange || ifRange === metadata.httpEtag ? request.headers.get('range') : null,
  metadata.size);
```

If `If-Range` is present and does **not** equal the ETag, the `Range` header is discarded
and a full 200 is served — correct RFC 9110 behaviour. Comparison is exact string equality
against R2's `httpEtag`.

On 416 (line 15) the route sets `Content-Range: bytes */<size>` and `Content-Length: 0`,
and returns a null body — but **retains** all the headers from line 11, including the
original `Content-Length` before it is overwritten and the `ETag`. Note the 416 response
still carries `Content-Type`.

On 206 (line 17): `Content-Range: bytes <offset>-<offset+length-1>/<size>` and
`Content-Length: <length>`.

**`parseByteRange(header, size)` — `app/media-utils.ts:15-21`.** Returns `null` (no range),
`'invalid'` (→ 416), or `{offset, length}`.

| Input | Result | Why |
|---|---|---|
| Header absent/empty | `null` | Line 16; full 200 |
| Fails `/^bytes=(\d*)-(\d*)$/` on the trimmed value | `'invalid'` | Line 17 |
| **Multi-range**, e.g. `bytes=0-1,5-6` | `'invalid'` → **416** | Fails the single-range regex |
| `bytes=-` (both groups empty) | `'invalid'` | Line 17 |
| `size` not a safe integer, or `size < 1` | `'invalid'` | Line 17 — **a 0-byte object + any Range is always 416** |
| `bytes=-N` (suffix) | `N` must be a safe integer `> 0`; `start = max(0, size − N)`, `end = size − 1` | Line 19. `N > size` yields the whole file as a **206** |
| `bytes=S-` | `end = size − 1` | Line 20 |
| `bytes=S-E` | Rejects `start >= size` or `end < start`; then `end = min(end, size − 1)` | Line 20 |

Returns `{offset: start, length: end − start + 1}`.

> **Migration hazard.** Four behaviours here deviate from what a naive reimplementation
> produces: multi-range → 416 (not 200 or multipart); zero-length object + Range → 416;
> suffix range larger than the file → 206 for the whole file (not 200); and `start >= size`
> → 416 while `end > size` is silently clamped. Each is a distinct branch that needs its
> own test.

---

### The public-access rule — `JSON.stringify(published).includes('/api/media/' + key)`

`app/api/media/[key]/route.ts:7`:

```ts
const {published} = await readContent();
const isPublic = JSON.stringify(published).includes(`/api/media/${key}`);
```

**What it means, plainly.** An asset is publicly readable if and only if the literal
string `/api/media/<key>` appears **anywhere** in the serialised published document. Not
"is referenced by the `photo` field" or "appears in a known image slot" — anywhere at all,
including inside free prose.

**What it costs, per request.** `readContent()` is `readContentState()`
(`content-persistence.ts:18`), which:

1. Runs `SELECT draft, published, revision, updated_at, published_at FROM site_content WHERE id = 1`
   — fetching **both** ~15 KB documents.
2. Calls `normalizeStoredContent` on **each**, i.e. `JSON.parse` + a full
   `contentSchema.parse` (with every refinement and transform) **twice**.
3. Computes `hasUnpublishedChanges` with two more `JSON.stringify` calls and a full
   string comparison (line 16) — a value this route never uses.
4. Then line 7 performs a **third** `JSON.stringify` of `published` and an O(n) substring scan.

That is one D1 row read, two full schema validations and three serialisations of a 15 KB
document **for every media byte served** — and because `Cache-Control` is
`private, no-cache` with no 304 path, nothing is cached. A page with N images costs N
repetitions. A video streamed in byte ranges repeats the whole thing for **every range
request**.

**Failure modes.**

1. **Over-permission through prose.** Any field that can hold free text will make an asset
   public if the URL is typed into it — `transcript` (up to 60,000 chars), `description`,
   `bio`, `intro`, `notice`, any of the nine copy blocks. Pasting a draft-only image URL
   into a caption transcript publishes that image.
2. **Publication is indiscriminate.** Publishing makes public *every* asset URL anywhere
   in the document, including ones in fields that are not rendered — e.g. an item in a
   collection whose section is toggled off via `sections.*`. The visibility toggle hides
   the section from the page; it does **not** make its media private.
3. **No revocation and no cleanup.** Removing a reference makes the asset non-public again
   on the next request, but neither the R2 object nor the `assets` row is ever deleted.
   There is no orphan collection anywhere in the codebase. Storage grows monotonically.
4. **Total coupling of the media path to schema health.** Because the check calls
   `readContent()`, which parses stored content, a stored document that fails validation
   throws — caught at line 19 — and **every media request returns 503**, simultaneously
   with `/` and `/api/content`. One bad document takes down images, the page and the editor.
5. **Substring rather than structural matching.** I checked for prefix collisions and
   found none: the key regex forces a `.`-extension suffix, and a match requires
   `/api/media/` immediately followed by the full key, so `/api/media/0.webp` cannot match
   inside `/api/media/1230.webp`. JSON escaping is also not a problem —
   `JSON.stringify` does not escape `/`. The mechanism is not *wrong*, but it is
   positional-string-based rather than semantic, so it silently changes meaning if the
   URL format ever changes (e.g. adding a query string or a CDN prefix).
6. **Timing.** `isPublic` is evaluated before `editorAccess()` (line 8 short-circuits on
   `!isPublic`). So for public assets, no authorisation lookup happens at all — good. But
   for **every non-public asset request**, the full content read happens *and then* a D1
   `editors` lookup.

> **Migration hazard.** This is the second-highest-risk piece after the write batch. A
> reimplementation that computes public-ness from structured fields only (photo, item
> images, imageSources) will make strictly *fewer* assets public than today, and images
> referenced from prose will 404 for visitors. A reimplementation that caches the
> published document will change failure mode 3's timing. Both are behaviour changes, and
> both are silent.

---

### Content schema — every field and constraint

`app/content.ts`. This is the specification the target-language model must match exactly.

**Shared building blocks (lines 5–9):**

| Name | Definition |
|---|---|
| `text` | `z.string().max(10000)` |
| `url` | `z.string().max(2000)` + refinement: passes if empty, **or** matches `/^https?:\/\/[^\s]+$/i`, **or** matches `/^\/api\/media\/[a-zA-Z0-9.-]+$/`. Message: `'Use a full https:// link.'` |
| `citationCount` | `z.string().trim().max(9)` + refinement `v === '' \|\| /^\d+$/.test(v)`. **`.default('')`**. Message: `'Use a whole, non-negative citation count, or leave it blank.'` |
| `citationDate` | `z.string().max(10)` + refinement: empty, **or** all three of `/^\d{4}-\d{2}-\d{2}$/`, `!Number.isNaN(Date.parse(v))`, and `new Date(v).toISOString().slice(0,10) === v`. **`.default('')`**. Message: `'Use a valid snapshot date.'` |
| `imageSourceSchema` | `{src: url, width: int 1..16000, height: int 1..16000}` |

> The `citationDate` round-trip check is the interesting one: it rejects `2026-02-30`
> (which `Date.parse` accepts and normalises to March 2) by requiring the ISO round-trip
> to be identical. Note `.trim()` is applied to `citationCount` but **not** to `citationDate`.

**`item` (lines 11–17)** — the shape shared by all five collections:

| Field | Constraint | Default |
|---|---|---|
| `id` | `z.string().max(100)` | — (required) |
| `title` | `z.string().trim().min(1, 'Add a title before saving.').max(1000)` | — (required, non-empty after trim) |
| `subtitle` | `text` (max 10000) | — |
| `description` | `text` | — |
| `year` | `z.string().max(40)` | — |
| `image` | `url` | — |
| `imageAlt` | `text` | — |
| `imageSources` | `z.array(imageSourceSchema).max(4)` | `[]` |
| `focalX` | `z.number().min(0).max(100)` | `50` |
| `focalY` | `z.number().min(0).max(100)` | `50` |
| `link`, `code`, `dataset`, `video` | `url` | — |
| `captions` | `url` | `''` |
| `transcript` | `z.string().max(60000)` | `''` |
| `featured` | `z.boolean()` | — (required) |
| `citations` | `citationCount` | `''` |
| `citationsAsOf` | `citationDate` | `''` |
| `researchTopic` | `z.enum(['materials','ultrasound','photoacoustic','general']).optional()` | — |
| `researchIds` | `z.array(z.string().max(100)).max(100).optional()` | — |
| `contribution`, `approach`, `outcome` | `text` | `''` |

**Then a `.transform()` on line 17** — this runs on *every* parse, including reads from D1:

```ts
.transform(row => ({...row,
  researchTopic: researchIdentity(row),
  researchIds: row.researchIds ?? initialResearchLinks.get(row.id) ?? []}))
```

See `## code-quality-assessment` → *back-compat shims* for what this does and why.

**Top-level `contentSchema` (line 20):**

| Field | Constraint | Default |
|---|---|---|
| `name` | `z.string().trim().min(1).max(100)` | — (required) |
| `role`, `affiliation`, `location` | `z.string().max(200)` | — |
| `headline` | `z.string().max(240)` | — |
| `intro`, `bio` | `text` (max 10000) | — |
| `email` | `z.string().max(200)` + refinement empty or `/^[^\s@]+@[^\s@]+\.[^\s@]+$/`, message `'Enter a valid email.'` | — |
| `photo` | `url` | — |
| `photoAlt` | `text` | — |
| `photoSources` | `z.array(imageSourceSchema).max(4)` | `[]` |
| `photoFocalX` | `z.number().min(0).max(100)` | `50` |
| `photoFocalY` | `z.number().min(0).max(100)` | **`35`** (not 50 — deliberate for portraits) |
| `copy` | `copySchema` | `initialCopy` |
| `cv`, `scholar`, `orcid`, `github`, `linkedin` | `url` | — |
| `accent` | `z.enum(['blue','burgundy','forest'])` | — (required) |
| `motion` | `z.boolean()` | `true` |
| `scene` | `sceneSchema` | `initialScene` |
| `scholarHighlights` | object (below) | all-empty object with `visible: false` |
| `showNotice` | `z.boolean()` | — (required) |
| `notice` | `text` | — |
| `sections` | object of 6 booleans | `achievements` defaults `true`; the other five are **required** |
| `achievements` | `z.array(item).max(60)` | `[]` |
| `research` | `z.array(item).max(100)` | — (required) |
| `publications` | `z.array(item).max(500)` | — (required) |
| `journey` | `z.array(item).max(100)` | — (required) |
| `news` | `z.array(item).max(100)` | — (required) |

> Note the asymmetry: `achievements` has `.default([])` and `sections.achievements` has
> `.default(true)`; the other four collections and five toggles do not. That is a
> back-compat artefact of achievements being added later. A Python model that gives all
> five collections a default is *more* permissive than the original.

**`scholarHighlights` (line 18):** `{visible: boolean, citations: max 20, hIndex: max 20, i10Index: max 20, asOf: max 100, affiliation: max 200, interests: max 1000}`, all strings, no refinements. Default
`{visible: false, citations: '', hIndex: '', i10Index: '', asOf: '', affiliation: '', interests: ''}`.

**`sceneStory` (line 19):** `{title: max 150, description: max 600, link: url}`.

**`sceneSchema` (line 21):** `{offerTour: boolean default true, initialView: z.enum(['delivery','photoacoustic','ultrasound']), delivery: sceneStory, photoacoustic: sceneStory, ultrasound: sceneStory}`. The comment on line 20 records that a legacy `autoTour` field was deliberately retired.

**`copySchema` (`app/site-copy.ts:22-32`):** nine groups, every field defaulted from
`initialCopy`, and the whole object `.default(initialCopy)`.

- `label(fallback)` = `z.string().trim().min(1, 'Add a label.').max(80).default(fallback)`
- `section(value)` = `{title: trim().min(1,'Add a heading.').max(200).default(value.title), description: max(1000).default(value.description), navigation: label(value.navigation)}`, itself `.default(value)`
- `hero`: `{researchAction: label, scholarAction: label, discover: label, topics: max(200).default}`
- `achievements`, `research`, `publications`, `journey`, `news`, `contact`: `section(...)`
- `scholar`: `{title: trim().min(1).max(200).default, profileAction: label}`
- `footer`: `{tagline: max(200).default}`

> **Migration hazard.** There are **25** leaf defaults in `initialCopy`, of which 23 are
> non-empty (`journey.description` and `news.description` default to `''`). Nearly every one
> is a *different* string. These defaults are content, not boilerplate — they are the site's
> actual wording. A Pydantic
> model must carry all 25 of them verbatim, and the nested `.default()` at three levels
> (field, group, whole object) means an absent `copy` key, an absent `copy.research` key
> and an absent `copy.research.title` key must each produce different but correct results.

---

## component-inventory

### React components in `app/` — 36 total

Enumerated by grepping declaration forms across all 16 `app/**/*.tsx` files.
**All 36 are used**; none is orphaned.

**Route components (4)** — invoked by the framework, not imported:

| Component | File:line |
|---|---|
| `Home` | `app/page.tsx:6` |
| `RootLayout` | `app/layout.tsx:13` |
| `EditPage` | `app/edit/page.tsx:6` |
| `PreviewPage` | `app/edit/preview/page.tsx:6` |

**Exported components (13)** — imported by other modules:

| Component | File:line | Used by |
|---|---|---|
| `ColorModeProvider` | `app/color-mode.tsx:7` | `layout.tsx` |
| `ColorModeToggle` | `app/color-mode.tsx:11` | `site.tsx` |
| `AcademicSite` | `app/site.tsx:32` | `page.tsx`, `draft-preview.tsx`, `preview-client.tsx` |
| `Achievements` | `app/achievements.tsx:72` | `site.tsx` |
| `Publications` | `app/publications.tsx:31` | `site.tsx` |
| `ResearchSection` | `app/research-section.tsx:40` | `site.tsx` |
| `Updates` | `app/updates.tsx:18` | `site.tsx` |
| `ResearchScene` | `app/scene.tsx:43` | `site.tsx` |
| `ResponsiveImage` | `app/responsive-image.tsx:21` | `site.tsx`, `achievements.tsx`, others |
| `Editor` | `app/edit/editor.tsx:66` | `edit/page.tsx` |
| `UploadField` | `app/edit/upload-field.tsx:46` | `editor.tsx` |
| `DraftPreview` | `app/edit/draft-preview.tsx:5` | `editor.tsx` |
| `PreviewClient` | `app/edit/preview/preview-client.tsx:5` | `edit/preview/page.tsx` |

**Module-private components (19)** — declared and used within one file:

| File | Components |
|---|---|
| `app/achievements.tsx` | `MomentPreview` (:16), `MomentCard` (:22), `AchievementShowcaseCard` (:37), `CaptionLoadError` (:52), `ViewerMedia` (:56) |
| `app/edit/editor.tsx` | `Field` (:30), `MediaField` (:35), `CropControl` (:39), `ToggleField` (:43), `CollectionFields` (:44), `RevisionHistory` (:59) |
| `app/site.tsx` | `External` (:14), `Label` (:17), `ProfilePortrait` (:20) |
| `app/research-section.tsx` | `RelatedPapers` (:13), `ResearchCard` (:20) |
| `app/publications.tsx` | `PaperRow` (:12) |
| `app/scene.tsx` | `SceneSteps` (:37) |
| `app/updates.tsx` | `UpdateCard` (:9) |

Split: 4 route + 13 exported + 19 private = **36**.

### `components/ui/` — 61 files, 7,334 lines

The used/unused split, computed by resolving every import specifier in the tree.

| Category | Count | Lines |
|---|---|---|
| **Imported by `app/` code** | **11** | 1,131 |
| Reachable only transitively from those 11 | **1** (`button.tsx`) | 64 |
| **Reachable in total** | **12** | **1,195** |
| **Never reachable from any entry point** | **49** | **6,139** |
| Total | **61** | **7,334** |

So **84% of the vendored component library by line count is unreachable code**.

**The 11 imported directly by `app/`:** `alert-dialog`, `carousel`, `collapsible`,
`dialog`, `progress`, `radio-group`, `select`, `slider`, `switch`, `tabs`, `toggle`.
(Full edge list under `## code-structure` → *Import graph*.)

**Transitive reachability.** Starting from the ten Next.js entry points, exactly **12**
`components/ui` files are reachable: the 11 above plus `button.tsx`, pulled in by
`alert-dialog.tsx`, `carousel.tsx` and `dialog.tsx`.

**The 49 unreachable files:**

```
accordion, alert, aspect-ratio, attachment, avatar, badge, breadcrumb, bubble,
button-group, calendar, card, chart, checkbox, combobox, command, context-menu,
direction, drawer, dropdown-menu, empty, field, form, hover-card, input-group,
input-otp, input, item, kbd, label, marker, menubar, message-scroller, message,
native-select, navigation-menu, pagination, popover, resizable, scroll-area,
separator, sheet, sidebar, skeleton, sonner, spinner, table, textarea,
toggle-group, tooltip
```

Eight of these (`input-group`, `input`, `label`, `separator`, `sheet`, `skeleton`,
`textarea`, `tooltip`) *are* imported — but only by other unused components
(`combobox`, `field`, `form`, `sidebar`, `button-group`, `item`). They form a dead
subgraph: real edges, no root.

> Discovery reported 55 files and ~44 unused. The measured figures are **61 files** and
> **49 unreachable**. I am recording the measured numbers; the discrepancy is noted rather
> than silently corrected.

### Other non-`app/` modules

| File | Lines | Status |
|---|---|---|
| `lib/utils.ts` | 6 | **Used, but only by `components/ui/`** — 57 of 61 import it. Zero `app/` imports |
| `hooks/use-mobile.ts` | 19 | **Dead.** Imported only by `components/ui/sidebar.tsx:8`, itself unreachable |
| `db/index.ts` | 3 | Used by 4 `app/` files |
| `db/schema.ts` | 7 | **Not in the runtime graph.** Build-time only (see `## code-structure`) |

### CSS — 9 application files, 1,124 lines (+629 vendored)

All nine are imported, in this exact order, by `app/layout.tsx:2-10`. Order matters:
`globals.css` establishes the design tokens the other eight consume.

| File | Lines | Styles |
|---|---|---|
| `app/globals.css` | 169 | **Entry point.** `@import "tailwindcss"`, `@import "tw-animate-css"`, `@import "../vendor/shadcn-tailwind-4.13.0.css"`; the `@font-face` for self-hosted Inter Variable (line 6); the `:root` design-token palette; the `@theme inline` Tailwind token bridge |
| `app/color-mode.css` | 594 | **Largest by far.** Light/dark palettes, accent variants (blue/burgundy/forest), and the bulk of the editorial page styling |
| `app/gallery.css` | 115 | Achievements gallery, showcase cards, media lightbox |
| `app/editor-workflow.css` | 99 | Editor shell, save bar, recovery notice, validation summary, undo notice, revision history |
| `app/research-navigation.css` | 71 | Research theme spreads and topic navigation |
| `app/scene-guide.css` | 28 | 3D scene tour guide overlay |
| `app/media-upload.css` | 20 | Upload field, progress bar, retry controls |
| `app/updates.css` | 17 | News carousel cards |
| `app/site-navigation.css` | 11 | Section index / sticky nav |
| `vendor/shadcn-tailwind-4.13.0.css` | 629 | Vendored shadcn base layer (MIT, © 2023 shadcn) |

No CSS modules, no CSS-in-JS. The application mixes Tailwind utility classes (mostly
inside `components/ui/`) with hand-written semantic class names (mostly in `app/`).

### `public/` — 6 files

| File | Status |
|---|---|
| `public/favicon.svg` | Used — `layout.tsx:12` |
| `public/images/academic-flow.webp` | Used — the decorative cover artwork |
| `public/fonts/inter-latin-variable.woff2` | Used — `globals.css:6` |
| `public/file.svg`, `public/globe.svg`, `public/window.svg` | **Unused** — Next.js starter leftovers |

---

## technology-stack

Versions are the pinned values in `madhavi-tripathi/package.json`. The disposition column
records what the migration's already-settled decisions imply for each item; where no
decision has been recorded I say so rather than guess.

### Runtime platform — all Cloudflare/OpenAI-Sites-specific, all retired

| Technology | Version | Used for | Disposition |
|---|---|---|---|
| **Cloudflare Workers** | runtime | The entire application process | **Retired** — the target is a container/Cloud Run topology |
| **`vinext`** | `1.0.0-beta.5` | Vite-based Next.js-compatible runtime for Workers | **Retired** — a beta-versioned runtime shim with no role off Workers |
| **Cloudflare D1** | via `env.DB` | `site_content`, `content_revisions`, `editors`, `assets` | **Replaced** — SQLite-on-volume (default) or Firestore (Cloud Run path) |
| **Cloudflare R2** | via `env.BUCKET` | Uploaded media objects | **Replaced** — filesystem volume (default) or GCS (Cloud Run path) |
| **ChatGPT platform auth** | headers | The *only* identity source (`oai-authenticated-*`) | **Retired** — replaced by password + session cookie. See `## architecture` |
| **`wrangler`** | `4.92.0` | Local Miniflare dev server; `pnpm start` | **Retired** |
| **`@cloudflare/vite-plugin`** | `1.37.1` | Binds D1/R2 into the Vite dev server | **Retired** |
| **`@cloudflare/workers-types`** | `4.20260515.1` | `D1Database`, `R2Bucket` ambient types | **Retired** |
| **`cloudflare:workers`** | built-in | `import { env }` in `db/index.ts:1` | **Retired** |
| **`.openai/hosting.json`** | — | Declares the logical `DB`/`BUCKET` binding names | **Retired** |
| **`build/sites-vite-plugin.ts`** | vendored 0.2.0 | Local auth-header mocking; Sites build integration | **Retired** |
| **`scripts/*`** (10 files, 1,089 lines) | — | pnpm/npm installer shims, execution-profile detection, Sites env | **Retired** |
| **`cloudflare-env.d.ts`** | — | Ambient binding types | **Retired** |

### Application framework and UI

| Technology | Version | Used for | Disposition |
|---|---|---|---|
| **Next.js** | `16.3.4` | App Router, RSC, route handlers, metadata, sitemap/robots | **Survives** — but the *runtime* changes from vinext-on-Workers to standard Next.js. Route handlers move to Python; pages remain |
| **React** / **React DOM** | `19.2.6` | All UI | **Survives** |
| **TypeScript** | `5.9.3` | Whole codebase, `strict: true` | **Survives** — version selection already decided elsewhere; not re-litigated here |
| **Tailwind CSS** | `4.2.1` | Utility classes, design tokens via `@theme inline` | **Survives** |
| **`@tailwindcss/postcss`** | `4.2.1` | PostCSS integration (`postcss.config.mjs`) | **Survives** |
| **`tw-animate-css`** | `^1.4.0` | Animation utilities; imported by `globals.css:2` | **Survives** |
| **shadcn/ui** | vendored `4.17.0` | 61 components under `components/ui/` | **Survives, heavily reduced** — 12 of 61 reachable |
| **`radix-ui`** | `^1.6.7` | Primitives behind 37 `components/ui` files | **Survives** for the retained components only |
| **`@base-ui/react`** | `^1.7.0` | Primitive for 1 `components/ui` file | **Verify** — reachability shows no `app/` path to it |
| **`lucide-react`** | `^1.31.0` | Icons. 10 `app/` files + 23 `components/ui` files | **Survives** |
| **`next-themes`** | `^0.4.6` | Light/dark switching (`app/color-mode.tsx`) | **Survives** |
| **`embla-carousel-react`** | `^8.6.0` | Engine behind `components/ui/carousel.tsx` | **Survives** — carousel is used by achievements + updates |
| **`class-variance-authority`** | `0.7.1` | Variant props in 16 `components/ui` files | **Survives** with the retained components |
| **`clsx`** + **`tailwind-merge`** | `2.1.1` / `3.6.0` | `lib/utils.ts` `cn()` helper | **Survives** with the retained components |
| **`@fontsource-variable/inter`** | `^5.3.0` | **Nothing** — declared but never imported; the font is self-hosted from `public/fonts/` via `globals.css:6` | **Retired** — dead dependency |
| **three.js** | `^0.186.0` | `app/nano-renderer.ts` WebGL cover scene | **Survives** — but see the 560 KB chunk in `## code-quality-assessment` |
| **`@types/three`** | `^0.186.0` | three.js types | **Survives** |

### Validation and data

| Technology | Version | Used for | Disposition |
|---|---|---|---|
| **zod** | `3.25.76` | `contentSchema` — **the** validation schema, run client *and* server | **Replaced on the server; disposition on the client is a decision, not a finding.** The settled architecture records Pydantic as the only authoritative schema and zod dropped from the frontend |
| **drizzle-orm** | `0.45.2` | **Schema authoring only.** Not in the runtime graph (see `## code-structure`) | **Replaced** — by whatever authors the target schema |
| **drizzle-kit** | `0.31.10` | `pnpm db:generate` → `drizzle/*.sql` | **Replaced** — by the target migration tool |

> Recording this precisely matters: the phrase "replace the ORM" would misdescribe the
> work. There is no ORM at runtime to replace. What must be replaced is (a) 11 hand-written
> SQL strings and (b) a schema-authoring tool.

### Build and quality tooling

| Technology | Version | Used for | Disposition |
|---|---|---|---|
| **Vite** | `8.0.13` | Bundler, via `vinext` | **Retired** — standard Next.js tooling replaces it |
| **`@vitejs/plugin-react`** | `6.0.2` | React transform | **Retired** |
| **`@vitejs/plugin-rsc`** | `0.5.26` | RSC support in Vite | **Retired** |
| **`react-server-dom-webpack`** | `19.2.6` | RSC wire format | **Retired** |
| **ESLint** | `9.39.4` | `pnpm lint`; flat config in `eslint.config.mjs` | **Survives** |
| **`eslint-config-next`** | `16.3.4` | core-web-vitals + typescript rulesets | **Survives** |
| **pnpm** | `11.25.0` (declared); host has 10.30.3 | Package manager; `pnpm-workspace.yaml` sets a 7-day `minimumReleaseAge` and `strictDepBuilds` | **Decision not recorded here** — note the declared/host version mismatch |
| **Node.js** | `engines: >=22.13.0`; host runs v24.13.0 | Build tooling | **Survives** |
| **Test framework** | **none** | — | **N/A — nothing to migrate.** See `## code-quality-assessment` |
| **Formatter** | **none configured** | No `.prettierrc`, no Prettier dependency | **Absent** — the org rule defers to project config, and there is none |
| **CI configuration** | **none found** | No workflow files in the scanned tree | **Absent** |

### Summary by disposition

- **Retired (Cloudflare / OpenAI-Sites / vinext coupling), 18 items:** Workers, vinext,
  wrangler, `@cloudflare/vite-plugin`, `@cloudflare/workers-types`, `cloudflare:workers`,
  `.openai/hosting.json`, `build/sites-vite-plugin.ts`, the 10 `scripts/` files,
  `cloudflare-env.d.ts`, ChatGPT header auth, Vite, `@vitejs/plugin-react`,
  `@vitejs/plugin-rsc`, `react-server-dom-webpack`, `@fontsource-variable/inter`.
- **Replaced (function survives, technology does not), 4:** D1 → SQLite/Firestore;
  R2 → volume/GCS; drizzle-orm → target schema tool; drizzle-kit → target migration tool.
- **Survives, 17:** Next.js, React, React DOM, TypeScript, Tailwind, `@tailwindcss/postcss`,
  `tw-animate-css`, shadcn (reduced), radix-ui, lucide-react, next-themes,
  embla-carousel-react, cva, clsx, tailwind-merge, three.js, ESLint + `eslint-config-next`.
- **Server-side replaced, client-side disposition is a recorded decision not a finding, 1:** zod.
- **Absent today, 3:** test framework, formatter, CI.

---

## dependencies

`madhavi-tripathi/package.json`: **26 production**, **19 dev**. Every "imported by" column
below was produced by resolving import specifiers across the tree, not by inspection.

### Production dependencies

| Package | Pinned | Imported by | Status |
|---|---|---|---|
| `@base-ui/react` | `^1.7.0` | 1 `components/ui` file | Unreachable from `app/` |
| `@fontsource-variable/inter` | `^5.3.0` | **nothing** | **Unimported** — font is self-hosted |
| `@hookform/resolvers` | `^5.7.1` | **nothing** | **Unimported** — zero occurrences in the tree |
| `@shadcn/react` | `^0.3.0` | 1 `components/ui` file | Unreachable from `app/` |
| `class-variance-authority` | `0.7.1` | 16 `components/ui` files | Used (transitively) |
| `clsx` | `2.1.1` | `lib/utils.ts` | Used (transitively) |
| `cmdk` | `^1.1.1` | `components/ui/command.tsx` | Unreachable from `app/` |
| `date-fns` | `^4.4.0` | **nothing** | **Unimported** — zero occurrences |
| `drizzle-orm` | `0.45.2` | `db/schema.ts` only | **Build-time only**, not in runtime graph |
| `embla-carousel-react` | `^8.6.0` | `components/ui/carousel.tsx` | **Used** — carousel is reachable |
| `input-otp` | `^1.4.2` | `components/ui/input-otp.tsx` | Unreachable from `app/` |
| `lucide-react` | `^1.31.0` | 33 files (10 in `app/`) | **Used directly** |
| `next` | `16.3.4` | 6 files (`chatgpt-auth`, `layout`, `robots`, `site-metadata`, `sitemap`, `next.config`) | **Used directly** |
| `next-themes` | `^0.4.6` | `app/color-mode.tsx` + 1 ui file | **Used directly** |
| `radix-ui` | `^1.6.7` | 37 `components/ui` files | Used (transitively) |
| `react` | `19.2.6` | 66 files (14 in `app/`) | **Used directly** |
| `react-day-picker` | `^10.0.1` | `components/ui/calendar.tsx` | Unreachable from `app/` |
| `react-dom` | `19.2.6` | (framework) | **Used** |
| `react-hook-form` | `^7.85.0` | `components/ui/form.tsx` | Unreachable from `app/` |
| `react-resizable-panels` | `^4.12.2` | `components/ui/resizable.tsx` | Unreachable from `app/` |
| `recharts` | `^3.8.0` | `components/ui/chart.tsx` | Unreachable from `app/` |
| `sonner` | `^2.0.8` | `components/ui/sonner.tsx` | Unreachable from `app/` |
| `tailwind-merge` | `3.6.0` | `lib/utils.ts` | Used (transitively) |
| `three` | `^0.186.0` | `app/nano-renderer.ts` | **Used directly** |
| `vaul` | `^1.1.2` | `components/ui/drawer.tsx` | Unreachable from `app/` |
| `zod` | `^3.25.76` | `app/content.ts`, `app/site-copy.ts` | **Used directly — the schema** |

**Summary of the 26.** 7 are imported directly by `app/` code (`lucide-react`, `next`,
`next-themes`, `react`, `react-dom`, `three`, `zod`). 5 more are reachable transitively
through the 12 live `components/ui` files (`class-variance-authority`, `clsx`, `radix-ui`,
`tailwind-merge`, `embla-carousel-react`). 1 is build-time only (`drizzle-orm`).
**10 are reachable only through unused UI components** (`@base-ui/react`, `@shadcn/react`,
`cmdk`, `input-otp`, `react-day-picker`, `react-hook-form`, `react-resizable-panels`,
`recharts`, `sonner`, `vaul`), and **3 are imported nowhere at all**
(`@fontsource-variable/inter`, `@hookform/resolvers`, `date-fns`). 7 + 5 + 1 + 10 + 3 = 26.

> Discovery listed 11 unused production deps. I measure **13** with no path from any entry
> point (the 10 + the 3), of which 3 have no import anywhere in the tree. The two additions
> beyond discovery's list are `@fontsource-variable/inter` and `@base-ui/react`.
> `drizzle-orm` is excluded from that 13 because it does have a path — a build-time one.

### Dev dependencies

| Package | Pinned | Purpose | Status |
|---|---|---|---|
| `@cloudflare/vite-plugin` | `1.37.1` | `vite.config.ts` | Cloudflare-specific |
| `@cloudflare/workers-types` | `4.20260515.1` | `tsconfig.json` `types` | Cloudflare-specific |
| `@tailwindcss/postcss` | `4.2.1` | `postcss.config.mjs` | Used |
| `@types/node` | `22.19.19` | Types | Used |
| `@types/react` | `19.2.14` | Types | Used |
| `@types/react-dom` | `19.2.3` | Types | Used |
| `@types/three` | `^0.186.0` | Types | Used |
| `@vitejs/plugin-react` | `6.0.2` | Vite React transform | vinext-specific |
| `@vitejs/plugin-rsc` | `0.5.26` | Vite RSC | vinext-specific |
| `drizzle-kit` | `0.31.10` | `drizzle.config.ts`, `pnpm db:generate` | Build-time |
| `eslint` | `9.39.4` | `pnpm lint` | Used |
| `eslint-config-next` | `16.3.4` | Flat config presets | Used |
| `react-server-dom-webpack` | `19.2.6` | RSC wire format | vinext-specific |
| `tailwindcss` | `4.2.1` | CSS framework | Used |
| `tw-animate-css` | `^1.4.0` | `globals.css:2` | Used |
| `typescript` | `5.9.3` | Compiler | Used |
| `vinext` | `1.0.0-beta.5` | Runtime | Platform-specific |
| `vite` | `8.0.13` | Bundler | Platform-specific |
| `wrangler` | `4.92.0` | Local Workers dev | Cloudflare-specific |

Plus `overrides: {miniflare: {sharp: "0.35.4"}}` — a transitive pin for the local emulator.

### Licence obligations

All licences found in the tree are **MIT**, which requires the copyright notice and
permission text be preserved in redistributions. Two are **vendored into the source tree**
rather than installed, so the obligation travels with the files themselves and is easy to
lose in a copy-forward:

| Vendored artefact | Notice file | Copyright |
|---|---|---|
| `build/sites-vite-plugin.ts` (from `@openai/sites-vite-plugin` 0.2.0, openai/sites#9) | `build/sites-vite-plugin.LICENSE` | MIT, © 2026 OpenAI |
| `vendor/shadcn-tailwind-4.13.0.css` | `vendor/shadcn-tailwind-4.13.0.LICENSE.md` | MIT, © 2023 shadcn |

The 61 `components/ui/*.tsx` files are also vendored shadcn source (registry 4.17.0), as
`eslint.config.mjs` states explicitly when it disables three lint rules for them. They
carry no per-file licence header; the `vendor/` notice is what covers them.

> **Obligation if components are carried forward.** If any of the 12 live `components/ui`
> files moves into the new codebase, the shadcn MIT notice must move with it. Dropping
> `vendor/` while keeping `components/ui/` would strip the notice from code it covers. The
> OpenAI notice can be dropped only together with `build/sites-vite-plugin.ts`.

I did not attempt a full transitive licence audit of `node_modules/` — that is outside a
source scan, and I am recording the limit rather than implying coverage.

### Maintenance concerns

1. **`vinext@1.0.0-beta.5` — a pre-release runtime.** The entire application executes
   through it. Beta versioning means no stability guarantee, and it is the least
   substitutable dependency in the tree.
2. **`zod@3.25.76` — a transition release.** The 3.25.x line ships both the v3 API (at the
   package root) and the v4 API (at `zod/v4`). `app/content.ts:1` imports from the root and
   therefore gets **v3** semantics. I verified this by resolving the entry point and
   enumerating `ZodIssueCode`. The codebase contains at least one place that assumes v4
   naming — see `## code-quality-assessment` → *the `invalid_format` allowlist entry*.
3. **Declared vs installed package manager.** `packageManager: pnpm@11.25.0`; the host has
   pnpm 10.30.3. Not an error, but any exact-reproduction step will hit it.
4. **`pnpm-workspace.yaml` sets `minimumReleaseAge: 10080`** (7 days) and
   `trustLockfile: false`, `strictDepBuilds: true`. A fresh install refuses packages
   published in the last week — worth knowing before anyone debugs a "missing version".
5. **Caret ranges on 19 of 26 production dependencies**, with exact pins on the remaining 7
   (`class-variance-authority`, `clsx`, `drizzle-orm`, `next`, `react`, `react-dom`,
   `tailwind-merge`). The mixture means `pnpm-lock.yaml` (344 KB) is the only complete record
   of what actually resolves.
6. **10 production dependencies exist solely to support unused UI components**, and 3 more are
   imported nowhere. That is 13 of 26 — half the production dependency surface, and half the
   audit surface, carrying no function.

---

## code-quality-assessment

An honest read. I have tried to separate "unusual but deliberate" from "defective", and to
say which is which with evidence.

### The dense single-line style — deliberate house style, not a defect

**The observation.** `app/` files report tiny line counts against substantial byte counts.
Measured, per file:

| File | Lines | Bytes | Longest line | Bytes/line |
|---|---|---|---|---|
| `app/edit/editor.tsx` | 99 | 34,555 | **3,969** | 349 |
| `app/content.ts` | 66 | 12,484 | **1,189** | 189 |
| `app/achievements.tsx` | 125 | 17,052 | 1,151 | 136 |
| `app/edit/draft-preview.tsx` | 12 | 2,861 | **1,574** | 238 |
| `app/publications.tsx` | 74 | 13,751 | 733 | 186 |
| `app/edit/upload-field.tsx` | 126 | 9,791 | 742 | 78 |
| `app/upload-validation.ts` | 68 | 3,895 | 202 | 57 |
| `app/chatgpt-auth.ts` | 90 | 2,550 | 79 | 28 |

`app/content.ts` holds the **entire** top-level schema — all **31** fields, with their
refinements, defaults and nested objects — on a **single 1,189-character line** (line 20).
`app/edit/editor.tsx` has a 3,969-character line.

**Is it a defect or a house style?** It is a **deliberate, consistently applied house
style**, on this evidence:

1. **It is not uniform — it tracks authorship.** `app/chatgpt-auth.ts` (28 bytes/line,
   longest line 79) and `build/sites-vite-plugin.ts` are conventionally formatted with
   multi-line signatures and blank lines. Both are **vendored/platform-supplied** files.
   Every file written for *this* application is dense. A formatter or an accident would not
   respect that boundary.
2. **Within dense files, formatting is still deliberate.** `app/upload-validation.ts` and
   `app/api/upload/route.ts` use conventional 2-space multi-line formatting — they are the
   files with real branching logic. The dense files are the ones dominated by JSX and
   object literals. Someone was choosing per-file.
3. **No formatter is configured.** No `.prettierrc`, no Prettier dependency, no `format`
   script. The style is not the output of a tool and was not going to be reformatted.
4. **Comments are present and purposeful.** Dense code that had been minified or generated
   would not carry prose comments like `app/content-persistence.ts:23-27` (the batch
   rationale), `app/media-utils.ts:1`, `app/edit/editor-workflow.ts:18-19` and `:24-25`, or
   `app/content.ts:20`'s note on the retired `autoTour` field. These are explanations
   written for a reader.
5. **`eslint.config.mjs` applies the strict ruleset to `app/`** and relaxes three rules
   only for `components/ui/**` and `hooks/use-mobile.ts`, with a comment saying those are
   "vendored verbatim from shadcn@4.17.0". The author distinguished their own code from
   vendored code deliberately and held their own to the stricter standard.

**So: a house style.** But it carries real, recordable costs the architect should weigh:

- **Line-based tooling degrades.** Diffs, blame, and coverage reports are line-granular. A
  one-character change inside a 3,969-character line shows as that whole line changing.
- **Line numbers are nearly useless as references.** Saying "`content.ts:20`" locates a
  1,189-character region, not a statement. Every reference in this document that points
  into `content.ts` or `editor.tsx` has this limitation, and I have described *what* to look
  for rather than relying on the number alone.
- **The line counts understate the work by roughly 3–5×.** Anyone sizing this migration
  from `wc -l` (1,819 lines in `app/`) will underestimate. Bytes are the honest measure:
  ~200 KB of application TypeScript.
- **Review is harder.** A 3,969-character line cannot be read in a side-by-side diff.

> **Recorded as a hazard, not a recommendation.** The new codebase will have its own
> formatter and style. The hazard is *translation*: dense code hides branches, and a
> reviewer skimming `content.ts:20` can miss a `.default()` or a `.refine()` in the middle
> of a 1,189-character line. Every constraint has been enumerated in
> `## api-documentation` → *Content schema* precisely so that no one has to read that line
> again to get it right.

### Testing — total absence

I searched the whole tree (excluding generated directories) for `*.test.*`, `*.spec.*`,
`*.cy.*`, `vitest.config.*`, `jest.config.*`, `playwright.config.*`, `__tests__/` and
`tests/`. **Zero results.** `package.json` has no `test` script and no testing dependency —
no vitest, no jest, no playwright, no testing-library.

**There is no test of any kind in this repository.** Not one unit test, not one integration
test, not one end-to-end test.

The only quality gates that exist are `tsc` (`strict: true`) and `pnpm lint`. The README
records what was verified by hand: *"TypeScript, the production build, content validation,
and SQL save/publish/conflict checks passed"* — a manual pass, not an automated suite.

**Why this matters more than usual here.** The pieces most at risk in this migration are
exactly the pieces with the most intricate branching and the least observability:

- the seven-statement concurrency batch,
- three hand-written binary header parsers,
- a WebVTT grammar validator,
- a byte-range parser with six distinct rejection branches,
- a six-flag editor state machine.

**Every one of them is currently unverified by any automated check.** There is no
characterisation suite to port, and no oracle to diff the new implementation against.
Behavioural equivalence cannot be demonstrated by running the old tests, because there are
none. Any claim of "behaviour preserved" will rest on reading this document and the source.

> This is the single largest quality gap in the codebase, and it is a gap in the
> *migration's* safety net, not just the product's.

### Error handling at boundaries

**Consistent and, on the whole, good.** Every one of the four route handlers wraps its body
in `try/catch` and returns a structured JSON error. No exception escapes to a framework
error page. Nothing is swallowed silently: every catch either logs (`console.error`) or
returns a message, and most do both.

Observed patterns:

- **Uniform status vocabulary** across routes: 403 auth/origin, 400 malformed, 413 too
  large, 409 conflict, 404 not found, 499 client abort, 503 unexpected.
- **User-facing messages are genuinely good.** Every error tells the owner what happened
  *and what is safe*: `'Your changes could not be saved. They are still in the form.'`,
  `'Upload cancelled. Your previous file is unchanged.'`, `'Version history is temporarily
  unavailable. Your current edits are safe.'`. This is a real strength and is worth
  preserving verbatim.
- **Abort handling is explicit.** `app/api/upload/route.ts` checks `request.signal.aborted`
  at seven points (lines 18, 21, 37, 52, 56, 58, 61) and maps `AbortError` to 499.
- **Compensating cleanup on failure.** The upload catch block deletes every already-written
  R2 object and `assets` row under `Promise.allSettled` (lines 65–70), so a mid-upload
  failure does not orphan. Explicitly documented as best-effort.
- **Render-time degradation.** `app/page.tsx:8` catches and renders a "temporarily
  unavailable" page rather than failing; `app/page.tsx:5` catches inside `generateMetadata`
  and falls back to a static title. `app/edit/page.tsx:10` does the same for the editor.

Weaknesses:

1. **Everything unexpected is a 503.** A schema-validation failure on *stored* content, a
   D1 outage and a genuine code bug are indistinguishable to the caller and to logs. There
   is no error taxonomy and no error identifier.
2. **`console.error` is the entire observability story.** No structured logging, no request
   id, no correlation between the three routes that would fail together.
3. **Error message strings are duplicated as literals** across route files with no shared
   constant, so the client cannot branch on anything but the status code.
4. **The `reply()` helper is defined twice**, identically, in `app/api/content/route.ts:5`
   and `app/api/history/route.ts:4`. `/api/upload` and `/api/media` use neither — so upload
   error responses carry **no `Cache-Control: no-store`** at all, unlike content and history
   errors. Minor, but it is a real inconsistency at a boundary.
5. **Two independent stores, no transaction.** The upload path writes R2 then D1. The
   cleanup block is the only thing keeping them consistent, and it only runs if the handler
   reaches its catch.

### Input validation coverage

**Strong where it exists, and the coverage is genuinely broad:**

| Boundary | Validation |
|---|---|
| Content body | Full zod schema + envelope checks + 1.5 M cap |
| History id | Length ≤ 100 and `/^[a-zA-Z0-9-]+$/` before it reaches SQL |
| Media key | `/^[a-f0-9-]+\.(jpg\|png\|webp\|pdf\|mp4\|webm\|vtt)$/` |
| Upload | MIME allowlist, magic bytes, per-kind size caps, dimension and aspect checks |
| Range header | Strict regex + safe-integer and bounds checks |
| Video URLs | Host allowlist (`app/media-utils.ts:2-13`) — YouTube/Vimeo only, 11-char id regex, never an arbitrary iframe src |
| Image srcset | Per-source re-validation client-side (`app/responsive-image.tsx:10-19`), rejecting control characters and non-http(s) protocols, and percent-encoding commas so a URL cannot forge a srcset candidate |
| Return paths | `safeRelativeReturnPath` (`app/chatgpt-auth.ts:61-74`) rejects `//`-prefixed and absolute URLs and reserved auth paths — an open-redirect defence |
| JSON-LD injection | `app/page.tsx:7` escapes `<` to `<` before `dangerouslySetInnerHTML` |
| SQL | **Every** query uses `.bind(...)` parameters. I found no string-concatenated SQL anywhere |

**Gaps:**

1. **`Content-Type` is never checked** on `PUT /api/content`. The body is parsed as JSON
   regardless of what the client declares.
2. **`sameOrigin` is the only CSRF defence** and it fails open on shape: it *requires* an
   `Origin` header, so it is not bypassable by omission — but it is a single check with no
   token backing it, applied to only 2 of the 6 endpoint/method pairs.
3. **`GET /api/content` and `GET /api/history` have no same-origin check.** They are
   protected only by being non-simple JSON GETs with no CORS headers, i.e. by the browser.
4. **The 51 MB upload pre-check is bypassable** (no `content-length` → passes). The real
   cap is the post-buffer sum.
5. **No rate limiting anywhere.** Not on upload, not on save, not on media.
6. **The 1.5 M body cap is applied after full buffering** and counts characters, not bytes.

### Security posture — the upload path

**Defences present, and they are better than typical:**

- Editor + same-origin required before anything is read.
- MIME allowlist of exactly 7 types; extension derived from the *validated* MIME, never
  from the user's filename.
- **Magic-byte verification for every accepted type** — the client-declared MIME is never
  trusted on its own.
- Stored keys are `crypto.randomUUID()` + a derived extension, so a user-supplied filename
  can never influence the storage key or path. The original name is kept only as metadata,
  truncated to 200 chars.
- Dimension caps (`≤ 40000` per side, `≤ 100,000,000` pixels) reject decompression-bomb
  geometry **without decoding pixels** — headers only.
- Per-kind size caps, applied to the summed upload.
- Cleanup on failure.

**Concerns:**

1. **Images and VTT are fully buffered in memory** (`route.ts:36` reads the whole file for
   `image/*` and `text/vtt`). A 10 MB image is entirely resident. Videos are not — only
   32 bytes are read.
2. **No content scanning beyond structure.** A file with a valid PNG header and arbitrary
   trailing bytes passes. A polyglot is not detected. The `nosniff` + `sandbox` +
   `default-src 'none'` headers on the serving side are what actually contain this, and
   they are correctly applied — the defence is at read time, not write time.
3. **PDF validation is `head.startsWith('%PDF-')` only** — 5 bytes. Any file beginning
   `%PDF-` is accepted as a PDF, and PDFs are the richest attack format in the allowlist.
   The serving CSP is again what contains it.
4. **No virus/malware scanning**, which is a reasonable choice for a single-owner site but
   should be recorded rather than assumed.
5. **No quota.** Unlimited uploads, and no orphan collection anywhere, so storage grows
   without bound (see the media rule's failure mode 3).

### Security posture — the media path

**Defences present:**

- The key regex confines lookups to a UUID-plus-known-extension shape; no traversal is
  expressible.
- **Every denial is a 404**, never a 403 — existence of non-public assets is not confirmed.
- `Content-Security-Policy: default-src 'none'; sandbox` neutralises active content in a
  served file. This is the control that makes the weak PDF check tolerable.
- `X-Content-Type-Options: nosniff` prevents MIME confusion.
- `Cache-Control: private, no-cache` keeps authorised bytes out of shared caches — correct,
  given the same URL can be public or private depending on document content.
- `Content-Type` comes from the `assets` row, not from anything in the request.

**Concerns:**

1. **The `includes()` access rule.** Fully analysed in `## api-documentation`. Its security
   consequence is that *any* free-text field becomes an access-control surface: typing a
   media URL into a transcript, bio or notice publishes that asset.
2. **Unbounded cost per request** — a full content read, two schema parses and three
   serialisations per media byte served, with no caching. That is a denial-of-service
   amplifier: a cheap range request forces expensive work, and there is no rate limit.
3. **HEAD ignores `Range`**, so HEAD and GET disagree about what they would return.
4. **No 304 path** despite emitting `ETag`.
5. **`Content-Type` and R2's stored content type are two independent records** that happen
   to agree today.

### The two known defects — confirmed, with measurements

**1. Carousel arrow buttons use native `disabled` (accessibility).**
`components/ui/carousel.tsx:194` (`disabled={!canScrollPrev}`) and `:224`
(`disabled={!canScrollNext}`). A disabled button is removed from the tab order, so when the
carousel reaches an endpoint the focused control disappears and focus falls to `<body>`,
breaking keyboard navigation mid-interaction. This affects both live carousels: achievements
(`app/achievements.tsx`) and updates (`app/updates.tsx`).

Two aggravating details: this is **vendored shadcn source**, which `eslint.config.mjs`
deliberately exempts from three lint rules to keep the registry copy verbatim — so fixing it
means forking the vendored file. And `app/use-section-carousel.ts:38` routes arrow keys
through `closest('[data-slot="carousel-previous"],[data-slot="carousel-next"]')`, i.e. the
keyboard handler depends on focus being *on* a button that `disabled` has just removed.
Confirmed as pre-existing; **not** a migration regression.

**2. Oversized client chunk (performance).** Measured from the existing build:

```
560,248 bytes  dist/client/_next/static/chunks/nano-renderer-DnAj1dia.js
560,140 bytes  dist/server/ssr/_next/static/nano-renderer-WQUhoSTV.js
195,917 bytes  dist/client/_next/static/chunks/index--4o58axH.js
190,152 bytes  dist/client/_next/static/chunks/framework-D_rUT4EX.js
100,209 bytes  dist/client/_next/static/chunks/research-identity-CieCsVSF.js
```

The three.js renderer is **547 KB uncompressed**, above the 500 KB warning threshold.

**Mitigation already present, and it is good.** `app/scene.tsx:85` imports the renderer
**dynamically** (`await import('./nano-renderer')`), gated by
`shouldLoadResearchScene(motion, preferences, requested)`
(`app/scene-performance.ts:9-16`), which requires preferences to be **known**, motion
enabled, `prefers-reduced-motion` not set, and either save-data off or an explicit request.
So the 547 KB is never on the critical path and never loads for a reduced-motion or
save-data visitor. The chunk is large; the loading strategy is careful. Confirmed
pre-existing.

### Findings beyond what discovery recorded

**A. The `invalid_format` allowlist entry is dead code, and enum errors discard drafts.**

`app/edit/editor-workflow.ts:20` decides whether a recovered localStorage draft is salvageable:

```ts
if(!parsed.success && parsed.error.issues.some(
     issue => !['too_small','too_big','custom','invalid_format'].includes(issue.code)))
  return null;
```

`invalid_format` is a **zod v4** issue code. `app/content.ts:1` imports from the `zod`
package root, which in 3.25.76 resolves to the **v3** API. I verified this empirically by
running the resolved package:

```
Is "invalid_format" a valid zod-v3 issue code?  false
v3 codes: invalid_type, invalid_literal, custom, invalid_union,
          invalid_union_discriminator, invalid_enum_value, unrecognized_keys,
          invalid_arguments, invalid_return_type, invalid_date, invalid_string,
          too_small, too_big, invalid_intersection_types, not_multiple_of, not_finite
```

So the fourth allowlist entry can never match. More consequentially, **`invalid_enum_value`
is not in the allowlist**. Measured behaviour against an equivalent schema:

| Draft defect | zod v3 code | `parseRecovery` outcome |
|---|---|---|
| Empty required title | `too_small` | **KEEP** the draft |
| Over-length field | `too_big` | **KEEP** |
| Malformed email (a `.refine`) | `custom` | **KEEP** |
| **Bad enum** (`accent`, `initialView`, `researchTopic`) | `invalid_enum_value` | **DISCARD the entire draft** |
| Wrong field type | `invalid_type` | **DISCARD** |
| Missing required key | `invalid_type` | **DISCARD** |

The comment on lines 18–19 states the intent: *"Locally authored drafts can contain a
temporarily empty title or invalid link. Retain these recoverable edits, but reject
malformed field types or shapes."* A bad enum value is a *value* problem, not a shape
problem — the stated intent says keep it, and the code discards it silently, along with
every other unsaved edit in that recovery record.

Whether this bites in practice depends on whether the editor can produce an out-of-range
enum. The three enum fields are edited through `Select` and `RadioGroup` controls, so in
normal use it should not arise — but a draft written by an **older schema version** (a
retired enum member) or by the WebMCP tool path is exactly the case recovery exists for.
I am recording this as a latent defect with a proven mechanism, not a confirmed
user-visible failure, because I could not exercise the editor in this environment.

> **Migration relevance.** If draft recovery is reimplemented against a Python validator,
> this allowlist has to be re-expressed in terms of *that* library's error taxonomy. Copying
> the four strings across would carry the bug forward and add a second one, since Pydantic's
> codes share no names with either zod version.

**B. `db/schema.ts` is not in the runtime graph.** Covered in `## code-structure`. Recording
it here because "the app uses an ORM" is the kind of assumption that silently shapes a
migration plan. It does not. It uses 11 hand-written SQL strings.

**C. `results[3]` is a hard-coded positional index.** `app/content-persistence.ts:44` reads
the CAS `UPDATE`'s result by numeric index into the batch array:

```ts
const saved = results[3]?.results?.[0];
```

Statement 3 is the `UPDATE`. Insert a statement anywhere before it and `writeContent()`
silently reads the wrong result — most likely returning `undefined`, which the route
interprets as **409 conflict**. So a refactor of the batch produces spurious "this draft
changed in another tab" errors rather than a crash. There is no comment marking index 3 as
load-bearing, and no test to catch it.

**D. `siteOrigin` is hard-coded in source.** `app/site-metadata.ts:5`:
`export const siteOrigin = 'https://madhavi-tripathi.madhavi-tri16.chatgpt.site';`
It feeds `metadataBase`, the canonical link, OG `url`, `siteName`, the JSON-LD `url` and
`@id`, and `robots.ts`'s sitemap URL. There is no environment variable. Deploying anywhere
else without changing this emits wrong canonical URLs and wrong structured data.

**E. `OWNER_EMAIL` is hard-coded in source.** `app/server.ts:5`. A personal email address
committed to the repository, functioning as the authorization root of trust.

**F. `lib/utils.ts` and `hooks/use-mobile.ts` have zero `app/` consumers.** `lib/utils.ts`
is imported by 57 of 61 `components/ui` files and by no application file.
`hooks/use-mobile.ts` is imported only by the unreachable `sidebar.tsx`. Both travel with
the UI library, not with the application — relevant to any "keep `lib/` and `hooks/`"
instruction.

**G. `readContentState()` does unnecessary work on every read.** It parses **both** the
draft and the published document and computes `hasUnpublishedChanges` via two
`JSON.stringify` calls, regardless of caller. `/api/media/[key]` needs only `published`.
`app/page.tsx` needs only `published`. `app/sitemap.ts` needs only `publishedAt`. Three of
the five call sites pay for the draft parse and the comparison and use neither.

**H. Two independent stores with no transaction across them.** Noted under error handling;
recording it as a structural property: R2 and D1 writes in the upload path can diverge, and
only the best-effort catch block reconciles them.

**I. Draft recovery is suppressed while a recovery offer is pending.**
`app/edit/editor-workflow.ts:50` returns early when `recovery` is non-null, so **no
localStorage backup is written while the owner is deciding** whether to recover. Edits made
during that window are protected only by the `beforeunload` warning.

**J. The recovery size cap exceeds the server's body cap.** `parseRecovery` accepts records
up to **6,000,000** characters (`editor-workflow.ts:15`); `PUT /api/content` rejects bodies
over **1,500,000** characters. A recovered draft between those bounds is restorable into the
editor but unsavable — it would fail with 413 on every attempt. An edge case, but the two
numbers were chosen independently and do not agree.

**K. The localStorage recovery scan is capped at 500 keys.**
`Math.min(localStorage.length, 500)` (`editor-workflow.ts:45`). With more than 500 keys in
the origin's storage, recovery records beyond index 499 are not seen.

---

### The seven-statement D1 batch — precise behaviour

`app/content-persistence.ts:28-40`. This is the highest-risk piece of behavioural drift in
the migration, so it is documented statement by statement. All seven run in **one D1
`batch()`**, which D1 executes as a single implicit transaction. The in-code comment
(lines 23–27) states the design intent:

> *"All statements run in one D1 batch transaction. The random mutation token gates history
> and retention after the optimistic revision guard. A stale request can therefore neither
> modify content nor add misleading history entries."*

Inputs (line 28): `{content, revision, action, now, mutationId}`.
Derived (line 29): `serialized = JSON.stringify(content)`, `initial = JSON.stringify(initialContent)`,
`publish = action === 'publish' ? 1 : 0`, `nextRevision = revision + 1`.
`mutationId` is a fresh `crypto.randomUUID()` per call (line 43).

**Statement 0 — bootstrap the singleton row.**

```sql
INSERT INTO site_content (id, draft, published, revision, updated_at)
SELECT 1, ?, ?, 0, ? WHERE ? = 0
ON CONFLICT(id) DO NOTHING
```
Binds `(initial, initial, now, revision)`.

Creates row `id = 1` seeded with `initialContent` in **both** columns at revision 0. Two
guards: `WHERE ? = 0` means it only fires when the caller claims revision 0, so a client at
revision 5 can never resurrect a deleted row; `ON CONFLICT DO NOTHING` makes a concurrent
bootstrap harmless. Note `published_at` is left NULL — the seed is not "published".

**Statements 1 and 2 — capture permanent baselines, once, ever.**

```sql
INSERT OR IGNORE INTO content_revisions (id, revision, action, content, created_at, baseline)
SELECT 'starting-published', revision, 'publish', published, ?, 1
  FROM site_content WHERE id = 1 AND revision = ?
```
and the same with `'starting-draft'`, `'draft'`, `draft`.
Both bind `(now, revision)`.

Fixed primary keys (`'starting-published'`, `'starting-draft'`) plus `INSERT OR IGNORE`
means each can succeed **at most once in the row's lifetime**. They capture the
*pre-existing* content — the state before this write — as `baseline = 1`, which the
retention deletes below explicitly never touch. `created_at` is the current time, not a
guessed original date; the comment on line 32 says so: *"Capture starting versions once,
without guessing their original publication date."* The `revision = ?` guard means a stale
writer captures nothing.

**Statement 3 — the compare-and-set. This is the concurrency control.**

```sql
UPDATE site_content SET
  draft = ?,
  published = CASE WHEN ? = 1 THEN ? ELSE published END,
  revision = revision + 1,
  updated_at = ?,
  published_at = CASE WHEN ? = 1 THEN ? ELSE published_at END,
  last_mutation = ?
WHERE id = 1 AND revision = ?
RETURNING draft, published, revision, updated_at, published_at
```
Binds `(serialized, publish, serialized, now, publish, now, mutationId, revision)`.

- `draft` is **always** overwritten.
- `published` and `published_at` change **only** when `action === 'publish'` — the two
  `CASE` expressions are how "publish" is expressed.
- `revision` increments unconditionally, for drafts as well as publishes.
- `last_mutation` is stamped with this call's random token.
- **`WHERE ... AND revision = ?` is the optimistic-concurrency guard.** If the caller's
  revision is stale, zero rows match, `RETURNING` yields nothing, `results[3]?.results?.[0]`
  is `undefined`, `writeContent` returns `null`, and `app/api/content/route.ts:18` returns
  **409**.

**Statement 4 — the history insert, gated on the token.**

```sql
INSERT INTO content_revisions (id, revision, action, content, created_at, baseline)
SELECT ?, revision, ?, draft, updated_at, 0
  FROM site_content WHERE id = 1 AND revision = ? AND last_mutation = ?
```
Binds `(mutationId, action, nextRevision, mutationId)`.

The history row's **id is the mutation token**. Its `content` is read back from the row's
`draft` column and its `created_at` from `updated_at`, so the history entry is guaranteed
byte-identical to what statement 3 just wrote — not to what the caller sent. (For a publish,
`draft` and `published` are equal, so storing `draft` is correct for both actions.)

**Statements 5 and 6 — retention, gated on the same token.**

```sql
DELETE FROM content_revisions
WHERE action = 'draft' AND baseline = 0
  AND id NOT IN (SELECT id FROM content_revisions
                 WHERE action = 'draft' AND baseline = 0
                 ORDER BY revision DESC LIMIT 30)
  AND EXISTS (SELECT 1 FROM site_content
              WHERE id = 1 AND revision = ? AND last_mutation = ?)
```
and the same for `action = 'publish'` with `LIMIT 20`.
Both bind `(nextRevision, mutationId)`.

Keep the 30 newest non-baseline drafts and the 20 newest non-baseline publishes. `baseline = 0`
excludes the two starting records from deletion permanently. 30 + 20 + 2 = **52**, which is
exactly the `LIMIT 52` on the history listing.

### Why `last_mutation` exists alongside the `revision` CAS

They defend different things, and the second is not redundant.

- **`revision` (statement 3) protects the content write.** It answers *"is the caller's view
  of the document still current?"* If not, nothing is written and the caller gets 409.
- **`last_mutation` (statements 4, 5, 6) protects the side effects.** It answers *"is the row
  in its current state because **I** put it there?"*

The distinction matters because statements 4–6 are guarded on `revision = nextRevision` —
a value that is *not unique to this writer*. Concretely:

> Row sits at revision 5. Writer A and writer B both load revision 5.
> B's batch commits first: the row advances to revision 6, stamped with B's token.
> A's batch now runs. A's statement 3 (`WHERE revision = 5`) matches nothing — the CAS
> correctly fails, and A will get a 409.
> But A's statements 4–6 test `revision = 6`, because A's `nextRevision` is also 6.
> **Without the token, that guard would be satisfied by B's write.**

The consequences, precisely:

- **Statement 4** would insert a history row keyed by *A's* mutation id, carrying *B's*
  content (it selects `draft` from the row), labelled with *A's* action. A phantom revision
  that no one ever saved — exactly the *"misleading history entries"* the comment names.
- **Statements 5 and 6** would run A's retention pass off the back of B's write, pruning
  history A had no right to prune, potentially deleting a revision B had just created.

Adding `AND last_mutation = ?` with a fresh random token per call makes all three guards
test identity rather than position. A stale writer's `nextRevision` may collide with the
winner's `revision`; its random UUID will not.

This is a classic **ABA defence**: the revision counter alone cannot distinguish "unchanged"
from "changed to a coincidentally equal value by someone else", and the random token supplies
the missing identity.

**Secondary benefit.** Even if a future runtime executed the batch with weaker isolation than
D1's implicit transaction, the token keeps statements 4–6 correct. The guard does not depend
on transactional isolation to hold.

### Migration hazards in the batch — enumerate before reimplementing

1. **The token is not optional.** Re-expressing this as "CAS on revision, then insert
   history, then prune" without the token reintroduces the phantom-history and wrongful-prune
   bugs. They are timing-dependent and will not appear in single-user testing.
2. **All seven statements must share one transaction.** Splitting them across separate
   transactions breaks both guards.
3. **`results[3]` is positional** (finding C). Any reordering silently turns successful
   writes into 409s.
4. **The retention numbers are coupled to the listing limit.** 30 + 20 + 2 = 52.
5. **Baselines are `baseline = 1` and must never be pruned**, and `INSERT OR IGNORE` on a
   fixed primary key is what makes them once-only. A target database without
   `INSERT OR IGNORE` semantics needs an equivalent that is genuinely idempotent under
   concurrency.
6. **`revision` increments on drafts too**, not only publishes.
7. **`published_at` stays NULL until the first publish.** The local emulator row confirms
   this: revision 4, `published_at` empty, both documents 15,423 bytes — four draft saves,
   never published.
8. **History content is read back from the row, not taken from the request.** A
   reimplementation that inserts the caller's payload directly will diverge whenever
   validation transforms or defaults change the stored value — which, given the
   `.transform()` on `item` and the many `.default()`s, is most of the time.
9. **`ORDER BY revision DESC` in the retention subquery is not a tiebreak-stable order.**
   Multiple rows can share a revision (a baseline pair plus a normal entry). Which row
   survives at the boundary is unspecified. The behaviour is the same in any faithful port
   only if the same ordering is used.

### The hand-written image header parsers

`app/upload-validation.ts:5-43`, `imageDimensions(bytes, mime)`. Returns `{width, height}`
or `null`. **`null` is a rejection** — `app/api/upload/route.ts:40` treats `!!dimensions` as
the validity test for every `image/*` upload. So these parsers are simultaneously the
dimension extractor and the format validator, and Python must reproduce the same accept/reject
decision, not merely the same dimensions.

A `DataView` is created over the array (line 6). **`view.getUint32(n)` and `view.getUint16(n)`
default to big-endian**; `getUint32(n, true)` / `getUint16(n, true)` are little-endian. Both
appear below and the distinction is load-bearing.

**PNG (lines 8–10).**

Rejects unless **all** hold:
- `bytes.length >= 33`
- bytes 0–7 exactly `137 80 78 71 13 10 26 10` (the PNG signature, `\x89PNG\r\n\x1a\n`)
- bytes 12–15 decode to `IHDR`

Then:
- `width  = view.getUint32(16)` — **big-endian**, bytes 16–19
- `height = view.getUint32(20)` — **big-endian**, bytes 20–23

Bytes 8–11 (the IHDR chunk length) are never checked. Anything after byte 23 is ignored.

**WebP (lines 11–23).**

Rejects unless **all** hold:
- `bytes.length >= 30`
- bytes 0–3 decode to `RIFF`
- bytes 8–11 decode to `WEBP`
- `view.getUint32(4, true) + 8 <= bytes.length` — **little-endian** RIFF size field, plus the
  8-byte RIFF header, must not exceed the actual buffer. This rejects truncated files.

Then bytes 12–15 select one of three sub-formats. **Anything else leaves `width`/`height` at
0, which becomes a rejection at line 42.**

*`VP8X` (extended, lines 14–16)* — 24-bit little-endian canvas dimensions, minus-one encoded:
- `width  = 1 + bytes[24] + (bytes[25] << 8) + (bytes[26] << 16)`
- `height = 1 + bytes[27] + (bytes[28] << 8) + (bytes[29] << 16)`

*`VP8L` (lossless, lines 17–19)* — requires `bytes[20] === 0x2f` (the VP8L signature byte),
then a packed 14-bit-each layout:
- `width  = 1 + bytes[21] + ((bytes[22] & 0x3f) << 8)`
- `height = 1 + (bytes[22] >> 6) + (bytes[23] << 2) + ((bytes[24] & 0x0f) << 10)`

*`VP8 ` (lossy, note the trailing space, lines 20–22)* — requires the 3-byte start code
`bytes[23] === 0x9d && bytes[24] === 0x01 && bytes[25] === 0x2a`, then:
- `width  = view.getUint16(26, true) & 0x3fff` — little-endian, low 14 bits
- `height = view.getUint16(28, true) & 0x3fff` — little-endian, low 14 bits

The `& 0x3fff` masks off the 2-bit scaling field in each 16-bit value.

**JPEG (lines 24–40).** A real marker-segment walk, not a fixed offset read.

Rejects immediately unless `bytes.length >= 4` and `bytes[0] === 0xff && bytes[1] === 0xd8`
(SOI).

Then from `position = 2`:

1. If `bytes[position++] !== 0xff` → **return null** (marker desynchronised).
2. Skip fill bytes: `while (bytes[position] === 0xff) position++`.
3. `marker = bytes[position++]`.
4. If `marker === 0xd9` (EOI) or `marker === 0xda` (SOS) or `position + 2 > bytes.length`
   → **break** out of the loop (not a rejection; falls through to the final check).
5. If `marker === 0x01` (TEM) or `0xd0 <= marker <= 0xd7` (RST0–RST7) → `continue` —
   these are standalone markers with no length field.
6. `length = view.getUint16(position)` — **big-endian**.
7. If `length < 2` or `position + length > bytes.length` → **return null** (malformed or
   truncated segment).
8. If `marker` is one of the SOF markers
   `0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf`:
   - if `length < 8` → **return null**
   - `height = view.getUint16(position + 3)` — **big-endian**
   - `width  = view.getUint16(position + 5)` — **big-endian**
   - **break**
9. Otherwise `position += length` and loop, while `position + 3 < bytes.length`.

Note the SOF list deliberately **excludes** `0xc4` (DHT), `0xc8` (JPG) and `0xcc` (DAC),
which share the `0xcN` range but are not frame headers. Note also that **height precedes
width** in a SOF segment — a transposition here is a silent bug that only shows on
non-square images.

**The final gate (line 42), applied to all three formats:**

```ts
return width > 0 && height > 0 && width <= 40000 && height <= 40000
    && width * height <= 100000000 ? {width, height} : null;
```

Both dimensions positive, each at most 40,000, and at most 100,000,000 total pixels. This is
the decompression-bomb defence, and it is reached without decoding a single pixel.

> **Migration hazards.**
> 1. **Endianness is mixed**: PNG and JPEG are big-endian; every WebP field is little-endian.
> 2. **Python's `int.from_bytes` requires an explicit byteorder** — there is no default to
>    inherit, so each read must be transcribed individually.
> 3. **JPEG stores height before width.**
> 4. Using Pillow instead of a hand-written parser will produce a **different accept/reject
>    set**: Pillow accepts formats this code rejects (GIF, BMP, TIFF, AVIF — though the MIME
>    allowlist would catch those first) and, more importantly, may *accept* malformed files
>    this walker rejects at steps 1 and 7, and *reject* unusual-but-valid files this walker
>    accepts. The pixel caps must also be enforced from header data *before* any decode, or
>    the bomb defence is lost.
> 5. The `>= 33` / `>= 30` / `>= 4` minimum-length checks are part of the contract.
> 6. WebP sub-formats other than `VP8X`, `VP8L`, `VP8 ` are **rejected**.

### The WebVTT validator

`app/upload-validation.ts:45-67`. `validCaptions(bytes)` → boolean.

**Decode (line 54).** `new TextDecoder('utf-8', {fatal: true})` — invalid UTF-8 **throws**
and the function returns `false`. Then a leading `﻿` BOM is stripped and all `\r\n` and
bare `\r` are normalised to `\n`.

**Header and safety gate (line 55).** Returns `false` unless all hold:
- `/^WEBVTT(?:[ \t][^\n]*)?\n/` — the literal `WEBVTT`, optionally followed by a space or tab
  and trailing text, then a newline. **A file consisting of only `WEBVTT` with no trailing
  newline fails.**
- No `\u0000` anywhere.
- No match for `/<(?:script|iframe|object|embed|svg|style)\b/i` — a markup blocklist applied
  to the whole file.

**Block split (line 56).** `text.trim().split(/\n[ \t]*\n/)` — blank-line separated, tolerating
whitespace on the "blank" line.

**Line 57.** Returns `false` if there are no blocks, or if `blocks[0]` contains `-->` (the
header block must not itself be a cue).

**Per block, from index 1 (lines 59–65):**
- `/^NOTE(?:[ \t\n]|$)/` → skipped entirely (comments).
- `index = lines[0].includes('-->') ? 0 : 1` — so a cue identifier line is allowed before the
  timing line, and the timing line is expected at 0 or 1.
- The timing line must match:
  ```
  /^((?:\d{2,}:)?\d{2}:\d{2}\.\d{3})[ \t]+-->[ \t]+((?:\d{2,}:)?\d{2}:\d{2}\.\d{3})(?:[ \t]+.*)?$/
  ```
  i.e. optional `HH:` (two **or more** digits), then `MM:SS.mmm`, exactly three decimal
  places, separated by `-->` with at least one space or tab on each side, with optional
  trailing settings.
- `cueTime(end) > cueTime(start)` must hold — **strictly** greater; a zero-duration cue is
  rejected.
- `lines.slice(index + 1).join('\n').trim()` must be non-empty — a cue with no payload text
  is rejected.
- Any block failing any of these → `false` for the whole file.

**`cueTime` (lines 45–49).** Splits on `:`, pops seconds, then minutes, then hours
(defaulting to `0`). Returns `hours*3600 + minutes*60 + seconds` only if
`Number.isFinite(hours) && seconds < 60 && minutes < 60`, else `NaN`. Since the comparison is
`end > start`, any `NaN` makes the comparison false and rejects the file.

**Line 67.** `return cues > 0` — a file with a valid header but **no cues at all is rejected**.

> **Migration hazards.** Strict-UTF-8 decoding (not lenient), the required trailing newline
> after the header, the markup blocklist, the NOTE skip, the identifier-line tolerance, the
> strictly-increasing timing requirement, the non-empty-payload requirement, and the
> at-least-one-cue requirement are eight independent reject conditions. Python's `codecs`
> strict mode covers the first; the rest must be written by hand. A permissive VTT library
> will accept files this rejects.

### The editor state machine

`app/edit/editor-workflow.ts`, `useDraftWorkflow(initial, initialState)`.

**Storage keys.**
- Legacy singleton: `'academic-site:draft-recovery:v1'` (exported as `recoveryKey`, line 12).
- Per-instance: `` `${recoveryKey}:${crypto.randomUUID()}` `` (line 32), generated once per
  hook instance via lazy `useState`.

Because the UUID is regenerated on every mount, a tab that reloads gets a new key and its
*previous* record becomes "another session's" — which is precisely what makes same-tab crash
recovery work. The comment on lines 42–44 states the intent: *"Each mounted editor owns its
own recovery record. A clean second tab must never clear another tab's unfinished work."*

**Mount scan (lines 40–49).** Collects the legacy key plus every key starting with
`` `${recoveryKey}:` `` found in the first `Math.min(localStorage.length, 500)` indices.
Skips its own key. For each, runs `parseRecovery`; keeps candidates whose content differs from
the server's `initial`; picks the one with the greatest `Date.parse(savedAt)`. On success,
`setRecovery(latest)` with `storageKey` attached. Any throw sets `storageWarning`.
`setRecoveryReady(true)` runs unconditionally, including after a throw.

**Persistence effect (line 50).** No-op while `!recoveryReady || recovery`. Otherwise: if
`dirty`, write `{content, revision, savedAt}` under the own key; if clean, remove it. Throws
set `storageWarning`.

**Autosave effect (line 69).** Arms a **1,500 ms** `setTimeout` calling `save('draft', true)`
only when **all** of: `dirty`, `recoveryReady`, `!recovery`, `!busy`, `!uploads`, `!paused`,
`!conflict`. The timer is cleared and re-armed on every content change, so it fires 1.5 s after
typing *stops*.

**States** — six independent flags, not an enum:

| Flag | Type | Meaning |
|---|---|---|
| `recoveryReady` | boolean | Mount scan finished |
| `recovery` | `DraftRecovery \| null` | A recovery choice is pending |
| `busy` | `'draft' \| 'publish' \| null` | A save is in flight |
| `uploads` | number | Count of in-flight uploads |
| `conflict` | boolean | Server reported 409 |
| `paused` | boolean | Autosave suspended |

Derived: `dirty = JSON.stringify(content) !== saved`.

**Named states:**

| State | Condition | Autosave | Manual save |
|---|---|---|---|
| INITIALISING | `!recoveryReady` | no | yes |
| CLEAN | `dirty === false` | n/a | yes (no-op for autosave) |
| DIRTY | `dirty`, all blockers clear | **armed, 1.5 s** | yes |
| SAVING | `busy !== null` | no | **blocked** |
| UPLOADING | `uploads > 0` | no | **blocked** |
| RECOVERY-OFFERED | `recovery !== null` | no | **blocked** |
| CONFLICT | `conflict === true` (implies `paused`) | no | **blocked** |
| PAUSED | `paused === true`, no conflict | no | **yes** |

> The PAUSED/CONFLICT distinction is easy to miss and easy to get wrong. `save()`'s guard
> (line 53) is `busyRef || uploadRef || recoveryRef || conflictRef` — **`paused` is not in
> it**. So PAUSED suppresses *automatic* saving only; the owner can still press *Save draft*.
> CONFLICT blocks both. A reimplementation that treats them as one state either strands the
> owner (blocking manual save while paused) or lets them overwrite a conflicting revision.

**Transitions.**

*`edit(updater)` (line 70)* — sets content, clears `message` and `issues`. Usually
CLEAN → DIRTY.

*`save(action, automatic)` (lines 52–68):*
1. Guard `busyRef || uploadRef || recoveryRef || conflictRef` → return `false`, no state change.
2. `contentSchema.safeParse(snapshot)`. On failure: `setIssues`; if manual, `setError`;
   return `false`. **Does not set `paused`.**
3. If `automatic && serialized === savedRef` → return `true` without a request.
4. Enter SAVING: `busyRef = true`, `setBusy(action)`, clear `error`/`issues`, clear `message`
   if manual.
5. `PUT /api/content` with `{content: validation.data, revision: stateRef.revision, action, autosave: automatic}`.
   Note it sends `validation.data` — the **transformed and defaulted** document, not the raw
   form state.
6. **409** → `setConflict(true)`, `conflictRef = true`, `setPaused(true)`, throw → caught →
   `setError(...)`, `setPaused(true)`, return `false`. → CONFLICT.
7. **Other non-OK** → if `result.issues` is an array, `setIssues`; throw `result.error` →
   `setError`, `setPaused(true)`, return `false`. → PAUSED.
8. **OK** → adopt the new state; `savedRef = JSON.stringify(validation.data)`;
   `setPaused(false)`; then line 64:
   ```ts
   setContent(latest => JSON.stringify(latest) === serialized ? validation.data : latest);
   ```
   The canonical server-shaped document replaces the form state **only if the owner has not
   typed since the request began** — the comment on line 63 explains it: *"New keystrokes
   during this request belong to the next draft, never this response."* Then `setMessage(...)`,
   return `true`. → CLEAN (or DIRTY if the owner kept typing).
9. `finally` → `busyRef = false`, `setBusy(null)`.

*`chooseRecovery(restore)` (line 71):*
- If `restore` and `recovery` → `setContent(recovery.content)`.
- `setRecovery(null)`, `recoveryRef.current = null`.
- **`setPaused(restore)`** — restoring **pauses** autosave (so the owner must deliberately
  save over the server draft); declining resumes it.
- Best-effort `localStorage.removeItem(recovery.storageKey)`.
→ PAUSED if restoring, DIRTY/CLEAN if declining.

*`reloadLatest()` (lines 72–76)* — the only exit from CONFLICT:
- Guard `busyRef || uploadRef` → return.
- Enter SAVING (`setBusy('draft')`), clear error.
- `GET /api/content` with `cache: 'no-store'`; `contentSchema.safeParse(result.draft)`.
- On failure → `setError`; **`conflict` and `paused` are left unchanged**, so the editor
  stays in CONFLICT.
- On success → **`setRecovery({content: current.current, revision: stateRef.revision, savedAt: now, storageKey: ownRecoveryKey})`**
  — the owner's *local edits* are converted into a recovery offer — then `setContent(server draft)`,
  `setSaved`, `setState`, `setConflict(false)`, `conflictRef = false`, `setPaused(false)`.
→ RECOVERY-OFFERED. Saving remains blocked until `chooseRecovery` is called.

So the conflict resolution path is a two-step, deliberately:
**CONFLICT → (reloadLatest) → RECOVERY-OFFERED → (chooseRecovery) → PAUSED or CLEAN.**
There is no path from CONFLICT directly back to saving.

**`parseRecovery(raw)` (lines 14–30)** — returns `DraftRecovery | null`:
1. `null` if `raw` is falsy or `raw.length > 6_000_000`.
2. `JSON.parse` inside try/catch; any throw → `null`.
3. `null` unless `Number.isInteger(value.revision)`, `typeof value.savedAt === 'string'`,
   and `Number.isFinite(Date.parse(value.savedAt))`.
4. `contentSchema.safeParse(value.content)`.
5. If it failed **and** any issue code is outside `['too_small','too_big','custom','invalid_format']`
   → `null`. (See finding A — this allowlist has a dead entry and omits `invalid_enum_value`.)
6. If it succeeded → use `parsed.data`.
7. Otherwise **reconstruct** (line 26), merging the raw value over `initialContent`:
   - shallow spread of `initialContent` then `raw`
   - `scene`, `scholarHighlights`, `sections`: one-level merge over the `initialContent` value
   - `copy`: per-group merge — each of the nine groups merged field-by-field
   - each of the five collections (line 27): `(raw[group] ?? initialContent[group])` mapped to
     `{...newItem(), ...item, researchTopic: researchIdentity(item), researchIds: item.researchIds ?? initialResearchLinks.get(item.id) ?? []}`
   The comment (lines 24–25) gives the intent: *"Validation errors must not discard freshly
   added schema defaults. Invalid text remains editable, while legacy local records receive
   the same new fields."* This is a **forward-migration path for locally-stored drafts written
   by an older schema.**
8. Returns `{content, revision, savedAt}` — note `storageKey` is attached by the *caller*
   (line 47), not here.

> Step 7 is the subtlest part of the whole module: it is how an old local draft acquires
> fields the schema has since gained. `{...newItem(), ...item}` generates a fresh UUID that is
> then overwritten by `item.id` when present — so items keep their identity, and only items
> genuinely lacking an id get a new one.

**`fieldId(path)` (line 13).** `` `edit-${path.join('-').replace(/[^a-zA-Z0-9_-]/g,'-')}` `` —
maps a validation-issue path to a DOM id so the validation summary can focus the offending
field. `app/edit/upload-field.tsx:51` **re-implements the same expression inline** rather than
importing `fieldId`. Two copies of one rule; they agree today.

### The `researchIdentity` / `initialResearchLinks` back-compat shims

Two small maps that carry real product behaviour.

**`researchIdentity` — `app/research-identity.ts:11-18`:**

```ts
const originalTopics = new Map<string, ResearchTopic>([
  ['nano-materials',     'materials'],
  ['ultrasound-imaging', 'ultrasound'],
  ['photoacoustics',     'photoacoustic'],
]);
export function researchIdentity(item: {id: string; researchTopic?: ResearchTopic}): ResearchTopic {
  return item.researchTopic ?? originalTopics.get(item.id) ?? 'general';
}
```

**Why it exists.** The comment on line 10 says it: *"Existing published cards acquire a stable
identity without changing their text or order."* The `researchTopic` field was **added after**
the three original research cards were already published. Those cards' stored documents have no
`researchTopic`. Rather than a data migration, the id is used to infer it. Precedence is
explicit: an explicit value always wins; the legacy id map is the fallback; `'general'` is the
floor.

**`initialResearchLinks` — `app/site-copy.ts:37-43`:**

```ts
export const initialResearchLinks = new Map<string, string[]>([
  ['breast-imaging-2026',       ['photoacoustics']],
  ['ultrasound-coherence-2025', ['ultrasound-imaging']],
  ['mucin-cus-2025',            ['nano-materials', 'photoacoustics']],
  ['nanoflakes-2024',           ['nano-materials']],
  ['nanohybrids-2023',          ['nano-materials', 'photoacoustics']],
]);
```

**Why it exists.** Same reason, for a different field: `researchIds` — the many-to-many link
from a publication to the research themes it supports — was added after those five
publications were published. The map supplies the original editorial linkage keyed by
publication id. Note the **values are research-card ids** (`nano-materials`,
`ultrasound-imaging`, `photoacoustics`), the same ids `originalTopics` keys on.

**Where they are applied** — four places, which is itself a hazard:

1. `app/content.ts:17` — the `.transform()` on `item`. **Runs on every parse**, which includes
   every read out of D1 via `normalizeStoredContent`.
2. `app/content.ts:26` — `record()`, the seed-data constructor, materialises both into
   `initialContent`.
3. `app/edit/editor-workflow.ts:27` — the draft-recovery reconstruction path.
4. `app/research-section.tsx:22` — `ResearchCard` calls `researchIdentity(item)` **again at
   render time**, even though the schema transform has already set the field.

**What breaks if they are dropped.**

*Dropping `researchIdentity`:* the three original research cards fall back to `'general'`.
Consumers:
- `app/research-section.tsx:22` — `const topic = researchIdentity(item), Icon = researchIcons[topic]`.
  All three cards lose their distinct icon and colour and render identically as slate.
  `researchTopicLabels` (`research-identity.ts:3-8`) maps the four topics to
  "Nanomaterials · blue", "Ultrasound · violet", "Photoacoustic · teal", "General research ·
  slate" — the visual identity of the research section collapses to one colour.
- `app/edit/editor.tsx:47` — the "Card identity" `Select` shows `'general'` as the current
  value for cards the owner never set, silently rewriting their identity on the next save.

*Dropping `initialResearchLinks`:* the five seeded publications get `researchIds: []`.
Consumers:
- `app/publication-utils.ts:21` — `const matchesTopic = topic === 'all' || paper.researchIds?.includes(topic)`.
  The publications topic filter returns **zero results** for every theme.
- `app/research-section.tsx:23` — `const related = papers.filter(paper => paper.researchIds?.includes(item.id))`,
  rendered by `RelatedPapers` (line 13). Every research card shows **0 related papers**.

Both failures are **silent**. Nothing errors, nothing logs; the page renders with grey cards
and empty filters. There is no test that would catch it.

**The subtlety that makes this dangerous in migration.** Because the transform runs on every
parse *and* the editor sends `validation.data` back on save (line 58), the derived values get
**materialised into storage** on the first save after the field was added. So for a
long-running instance the shims may already be redundant. But:

- The **seed** (`initialContent`) depends on them at construction time (`record()`), so a
  fresh install is entirely dependent on them.
- `docs/DESKTOP-START-HERE.md` establishes `initialContent` as the canonical starting content,
  and the local emulator row is that seed at revision 4 — so **the migration's starting data
  is exactly the case that needs the shims**.
- `??` (not `||`) is used in both, so an explicit `[]` is preserved and never re-populated
  from the map. A reimplementation using `or`/falsy semantics would resurrect links the owner
  deliberately cleared.

> **Migration hazard.** A Pydantic model that declares `research_topic: Topic | None = None`
> and `research_ids: list[str] = []` is *type-correct* and *behaviourally wrong*: it produces
> `None` where the original produces `'general'`, and `[]` where the original produces the
> seeded links. The four application sites listed above then quietly degrade. The transform is
> not a validator — it is a **defaulting rule that carries content**, and it must be ported as
> logic, not as a field default.

### The WebMCP `stage_academic_profile` tool

`app/edit/editor.tsx`, in the `useEffect` at line 81 (the file's dense formatting means the
whole registration is one statement on that line).

**Registration.** Reads `(document as {modelContext?: {registerTool?: Function}}).modelContext`.
If absent or without `registerTool`, the effect returns immediately — so this is entirely
optional and inert in an ordinary browser. An `AbortController` is created per mount and its
signal passed as `registerTool(tool, {signal})`; the cleanup returns `lifecycle.abort()`, so the
tool is unregistered when the editor unmounts. The whole call is wrapped in `try {} catch {}`
**and** `.catch(() => {})` on the returned promise — registration failure is silently ignored
by design.

**Declared tool:**

| Property | Value |
|---|---|
| `name` | `stage_academic_profile` |
| `title` | `Stage profile changes` |
| `description` | `Stage profile fields in the owner editor. Valid edits autosave as a draft; publishing is a separate owner action.` |
| `annotations` | `{readOnlyHint: false, untrustedContentHint: false}` |

**Input schema** — built programmatically from the six-key list:

```json
{ "type": "object",
  "properties": { "name":        {"type": "string"},
                  "role":        {"type": "string"},
                  "affiliation": {"type": "string"},
                  "headline":    {"type": "string"},
                  "intro":       {"type": "string"},
                  "bio":         {"type": "string"} },
  "additionalProperties": false }
```

No `required` array — every field is optional, and a call with an empty object is accepted.

**`execute(input)` validation** — re-checked in code, not trusted to the schema:
1. `if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('Expected profile fields')`
2. For every `[key, value]` entry: throw `new Error('Invalid profile field')` unless the key is
   one of the six **and** `typeof value === 'string'` **and** `value.length <= 10000`.

The 10,000 cap matches the `text` schema for `intro` and `bio` — but **not** `name` (max 100),
`role` (max 200), `affiliation` (max 200) or `headline` (max 240). So the tool accepts values
the content schema will later reject.

**What it does on success:**
- `edit(old => ({...old, ...input}))` — merges the fields into the editor's form state.
- `setTab('profile')` — switches the visible tab.
- `setMessage('Profile fields staged as a draft. Review before publishing.')`
- Returns `{staged: Object.keys(input), published: false}`.

**What it does not do:**
- It does **not** call `save()`. It does not write to the server.
- It does **not** publish. `published: false` is returned literally.
- It does not touch any of the five collections, appearance, copy, scene, or Scholar fields.
- It has no privileged access of any kind: it manipulates React state in a page the owner is
  already authenticated on. It cannot be reached by anyone who could not already type into the
  form.

**The one indirect effect worth recording.** Because `edit()` marks the document dirty, the
**1.5 s autosave timer arms**. So a staged change *will* be written to the server as a **draft**
1.5 s later, without further human action — provided the document validates and no blocker
(recovery, conflict, upload, paused) is active. The tool description states this accurately
("Valid edits autosave as a draft"), and it remains true that nothing is published. But "stages
only, never saves" is not quite right at the system level: it stages, and the surrounding
autosave then persists the draft.

**And the over-long-value interaction.** A 10,000-character `name` is accepted by `execute`,
merged into the form, and then fails `contentSchema` at `save()` step 2 — which sets `issues`
and returns `false` without setting `paused`. The autosave timer re-arms on the next content
change, so the editor sits with an unsaveable draft and a validation summary until the owner
fixes it. Not a security problem; a usability one, and a divergence between two validation
layers that the migration should not widen.

> **Migration note.** This is frontend-only with no server component. If the editor is ported
> as-is, the tool ports with it unchanged. Its only coupling to the backend is the autosave it
> indirectly triggers.

### What is genuinely good here

Recording this because an assessment that only lists problems misleads a reader about how much
care to take.

- **The concurrency design is sophisticated and correct.** The revision CAS plus random-token
  gating is a real ABA defence, correctly applied to exactly the statements that need it. Most
  codebases of this size do not have optimistic concurrency at all.
- **The batch is factored for inspection.** `contentWriteStatements()` is a pure function
  returning statements, separate from the executor. That is a deliberate testability affordance
   — unused, but present.
- **Error messages are written for a human under stress.** Nearly every one tells the owner
  what is *safe* as well as what failed. That is unusual and worth preserving verbatim.
- **Security headers on the media path are correct and complete** — `nosniff`, `sandbox`,
  `default-src 'none'`, `private, no-cache` — and they are what make the weaker upload-side
  checks tolerable.
- **Every SQL statement is parameterised.** I found no string-concatenated SQL anywhere.
- **Uniform denial as 404** on the media route avoids confirming the existence of private assets.
- **Comments explain *why*, not *what*.** The batch rationale, the retired `autoTour` field,
  the "keystrokes during this request belong to the next draft" note, the back-compat shim
  comments — these are the notes of someone thinking about the next reader.
- **Content provenance is documented** to an unusual standard in `docs/CONTENT-SOURCES.md`,
  with a stated rule that missing facts stay blank rather than being invented.

---

## reverse-engineering-timestamp

**Scan performed:** 2026-09-24T14:48:17Z (UTC).

**Workspace:** `/Users/praka/Workspace/Projects/Chiku_website`
**Git:** repository root is the workspace root; branch `main`; HEAD
`50856def65ec53e843e2e47aff571c564402f9d0` (`50856de`, *"Ideation closed: GO to Inception"*).

> **Correction to the discovery report.** Discovery recorded *"NOT a git repository"*. That is
> no longer true — `git rev-parse --show-toplevel` returns the workspace root and there are
> four commits, the earliest being `367b9c3` *"Baseline: AI-DLC workspace + madhavi-tripathi
> reference tree"*. 158 files under `madhavi-tripathi/` are tracked. The discovery report was
> presumably written before the repository was initialised. Recording the correction here
> rather than silently using the new fact.

**Source provenance of the scanned application.** `madhavi-tripathi/SOURCE-MANIFEST.json`
records upstream commit `161690d54eb79c3245419676006e08bf8755e5da`, committed
2026-09-23T17:10:42-05:00, 155 source files, each with a SHA-256 digest. It lists
`tsconfig.tsbuildinfo` as an omitted generated file and `DESKTOP-START-HERE.md`,
`CHATGPT-DESKTOP-PROMPT.txt` and `SOURCE-MANIFEST.json` as archive-only additions. I did not
re-verify the digests in this session — a prior session did, and re-running the verification
was not part of this brief. Recording that limit rather than implying coverage.

### What was scanned

All **157** non-generated files under `madhavi-tripathi/`:

| Area | Files | Depth |
|---|---|---|
| `app/` | 47 | **Every file read in full.** 22 `.ts`, 16 `.tsx`, 9 `.css` |
| `components/ui/` | 61 | Import graph resolved for all 61; `carousel.tsx` read for the known defect |
| `db/` | 2 | Both read in full |
| `drizzle/` | 5 | Both `.sql` migrations read in full; `meta/` inspected |
| `hooks/`, `lib/` | 2 | Both read; import graph resolved |
| `public/` | 6 | Enumerated and usage-traced |
| `scripts/` | 10 | Enumerated with line counts; not read line-by-line (all retired) |
| `build/` | 2 | Plugin head read for the local-auth mechanism; licence read |
| `vendor/` | 2 | Line-counted; licence read |
| `docs/` | 1 | Read in full |
| root configs | 18 | `package.json`, `tsconfig.json`, `next.config.ts`, `vite.config.ts`, `eslint.config.mjs`, `postcss.config.mjs`, `components.json`, `drizzle.config.ts`, `.openai/hosting.json`, `pnpm-workspace.yaml`, `.npmrc`, `README.md`, `SOURCE-MANIFEST.json` read in full |

**Measurements taken, not estimated:**

- Per-file line, byte and maximum-line-length counts across all 39 `app/` `.ts`/`.tsx` files.
- A full import graph, built by resolving every `import` / `require` / dynamic-`import`
  specifier against the tree with the `@/*` → `./*` path alias from `tsconfig.json`
  (`/private/tmp/.../scratchpad/graph.mjs`, `reach.mjs`).
- Transitive reachability from the ten Next.js entry points → 52 reachable files.
- `components/ui` usage census → 11 app-imported, 12 transitively reachable, 49 unreachable.
- Built chunk sizes from the existing `dist/` output (nano-renderer = 560,248 bytes).
- Local Miniflare D1 contents via `sqlite3`: 1 `site_content` row (revision 4, `published_at`
  NULL, both documents 15,423 bytes), 6 `content_revisions`, 1 `editors`, 3 `assets`.
- An empirical zod issue-code test executed against the installed `zod@3.25.76`, confirming
  `invalid_format` is not a v3 code and that `invalid_enum_value` causes `parseRecovery` to
  discard a draft.
- Confirmation by exhaustive search that the tree contains **zero** test files and **zero**
  test-framework dependencies.

### What was deliberately excluded, and why

| Excluded | Reason |
|---|---|
| `.claude/`, `aidlc/` | AI-DLC framework shell and workflow record — not application code. Excluded from every count and assessment per the scan brief |
| `chiku-website/` | **Does not exist.** Greenfield destination; nothing to scan and nothing invented |
| `node_modules/` | Installed dependencies. Consulted only to resolve `zod`'s entry point and enumerate its issue codes for finding A |
| `.next/`, `.vinext/` | Framework build output |
| `dist/` | Build output. **Partially used**: chunk file sizes were measured to quantify the known performance defect. No source was read from it |
| `.wrangler/` | Local Miniflare state. **Partially used**: the D1 SQLite file was queried for row counts and the content size, which are facts about the emulator's contents, not source |
| `.sites-runtime/` | pnpm store and local runtime scratch |
| `outputs/` | Generated output |
| `examples/` | An unrelated `d1` sample project bundled with the starter; also excluded by `tsconfig.json`'s `exclude` array |
| `madhavi-tripathi/.claude/` | Present but **empty** — contains no files |
| `pnpm-lock.yaml` | 344 KB resolution record. Declared versions were read from `package.json`; the lockfile was not parsed |

### Limits of this scan — stated plainly

1. **Nothing was executed.** No dev server, no build, no request. Every behavioural claim is
   derived from reading source, except the four measured items noted above (chunk sizes, D1
   contents, the zod issue-code test, the import graph).
2. **No hosted data was available.** The production D1 and R2 at
   `madhavi-tripathi.madhavi-tri16.chatgpt.site` are not in this export. The local emulator
   holds prior-session test data only. Claims about production content volume cannot be made.
3. **Runtime behaviour of the 3D scene, video playback, captions, touch interaction and the
   WebMCP tool was not observed** — only read. The README records that browser and WebMCP
   validation were unavailable in the originating session too.
4. **No accessibility audit was run.** The carousel defect is reported because it is visible in
   source; absence of other findings is not evidence of their absence.
5. **No transitive dependency licence audit** was performed over `node_modules/`. Licence
   findings cover only what is present in the source tree.
6. **The `invalid_format` finding is a proven mechanism, not an observed failure.** I
   demonstrated the issue-code mismatch empirically but could not exercise the editor to
   confirm a user-visible consequence. It is labelled as latent throughout.
7. **`SOURCE-MANIFEST.json` digests were not re-verified** in this session.

### Scan artefacts

Intermediate scripts and data, retained in the session scratchpad:

- `/private/tmp/claude-501/-Users-praka-Workspace-Projects-Chiku-website/252bae3e-1f47-4da7-99d5-f5d725d19282/scratchpad/graph.mjs` — import extraction and `components/ui` census
- `.../scratchpad/reach.mjs` — entry-point reachability and external-package attribution
- `.../scratchpad/graph.json`, `.../scratchpad/deps.json` — resolved graph data
- `.../scratchpad/zodtest.mjs` — the zod issue-code experiment

Nothing was written under `aidlc/spaces/default/codekb/`. This file is the sole output of link 1.
