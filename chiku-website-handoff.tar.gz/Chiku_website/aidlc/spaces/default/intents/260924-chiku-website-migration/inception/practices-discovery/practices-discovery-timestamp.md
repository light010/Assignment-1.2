Discovered: 2026-09-24T16:05:37Z at commit d7f1859
