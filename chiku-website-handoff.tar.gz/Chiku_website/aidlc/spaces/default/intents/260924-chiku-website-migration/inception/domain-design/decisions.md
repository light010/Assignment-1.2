# Architecture Decision Record — Domain Design

**Upstream:** `inception/requirements-analysis/requirements.md`,
`codekb/Chiku_website/architecture.md`,
`inception/practices-discovery/team-practices.md`.

Decisions taken at this stage. Choices already settled upstream — the language
boundary, password authentication, the parity rule, plan-only cloud — are
constraints here, not decisions, and are not re-recorded.

---

## ADR-001 — Three storage ports, not one and not six

**Status:** Accepted at the domain-design gate, 2026-09-24. [Q1]

**Context.** Six kinds of state need persisting behind a port so SQLite can be
the locally verified implementation while Firestore is the cloud one: the content
document, the revision ledger, the owner account, sessions, login-attempt
counters, and asset metadata. Asset *bytes* are separate in every option, because
a blob and a row are not the same shape and their cloud services are unrelated.
The affirmed practices require ports named for real things and forbid a generic
repository abstraction. The affirmed testing posture requires each port's
conformance suite to run against both a real adapter and an in-memory fake, so
each additional port costs two adapters and one suite.

**Decision.** Three ports: `ContentStore` (content document, revision ledger,
asset metadata), `IdentityStore` (owner account, sessions, attempt counters),
`AssetStore` (asset bytes, including ranged reads).

**Consequences.**

*Positive.* Each port has one reason to change; a change to session handling
never edits the file that writes content. The identity port could later move to a
different backing store without touching content. `AssetStore`'s ranged read stays
in the port, which is what stops `MediaDelivery` loading a whole video to serve
one range.

*Negative.* Three conformance suites rather than one, and six row-shaped adapters
plus two blob adapters. `MediaDelivery` depends on two stores because metadata
and bytes are split.

*Neutral but load-bearing, and now resolved.* `ContentStore` exposes the content
write, the revision entry and the retention prune as **one atomic operation made by
one caller**. The first draft of this design had `ContentAuthority` delegate the
revision write to `RevisionLedger`, which made its own store call; review finding
R-02 showed that this would have required threading a transaction context across a
component boundary — a leaking contract for a port meant to be proven by a
conformance suite — or `ContentAuthority` writing rows `RevisionLedger` exclusively
owns. Resolved by redrawing rather than deferring: `ContentAuthority` performs the
single combined write using the retention policy `RevisionLedger` supplies, and
`RevisionLedger`'s own store access is read-only. Both components survive, because
a retention policy that is read and applied elsewhere is still a policy with one
owner.

**Security and compliance.** Splitting identity from content is also a blast-radius
boundary, not only a change-rate one: the credential hash and session records are the
highest-value data in the system, and a defect in a content query cannot reach them
through a port that does not expose them. No regulated data class is involved — the
site holds one owner's credential and public academic content — so no compliance
regime applies beyond the secret-handling rules already affirmed in `team.md`.

**Alternatives rejected.**

- *One store for everything.* Two adapters and one suite, but one interface
  spanning content, identity and blobs. Rejected: the coupling it creates is
  exactly the coupling this migration exists to remove.
- *One port per owning component (six).* Perfectly aligned with entity ownership,
  and twelve adapters for a single-owner website. Rejected: it is the generic
  repository the practices forbid, arrived at from the opposite direction.

---

## ADR-002 — `ContentAuthority` owns the published-document cache

**Status:** Accepted at the domain-design gate, 2026-09-24. [Q2]

**Context.** The media access rule is preserved exactly: an asset is public if and
only if its path appears anywhere in the serialised published document. The
existing implementation pays one storage read, two full validations and three
serialisations of the document *per media byte served*, repeated for every range
request while a video streams. A short-lived cache was confirmed at requirements
as the way to collapse that cost without changing which assets are public. The
question was which component owns it.

**Decision.** `ContentAuthority` owns the cache and invalidates it on publish.
`MediaDelivery` asks it for the current published document and applies the
visibility rule itself.

**Consequences.**

*Positive.* Invalidation is a local call inside the component that owns the
document and is the only one that knows a publish happened — no cross-component
signal to forget. Any future reader of the published document gets the same
benefit. The visibility *rule* stays in `MediaDelivery`, which owns access
decisions, while the *document access* stays with its owner.

*Negative.* A caching concern now lives inside the component that owns business
rules. The cache interval is not set here; it trades staleness against cost and
belongs to NFR design.

*Risk.* A cache whose invalidation is missed would serve a stale document to the
visibility test, which could make a newly-unreferenced asset public for the cache
interval. The invalidation path therefore needs its own test, not just coverage.

**Security and compliance.** This is the ADR with the most direct security
consequence on the list: the cached document is the input to an **access-control
decision**, so a stale cache is an authorization defect, not a performance one. The
failure is bounded and one-directional — an asset the owner has just unreferenced
stays public for at most the cache interval; nothing private becomes public that was
never public. NFR design must therefore choose the interval as a security parameter
rather than a tuning one.

**Alternatives rejected.**

- *Cache in `MediaDelivery`.* Puts the remedy where the cost is, but invalidation
  must cross a boundary on publish and a second reader would silently miss it.
- *No cache.* Truest to the original including its cost, and it would reverse a
  decision already taken at requirements.

---

## ADR-003 — One `HttpApi`, not a public/owner split

**Status:** Accepted at the domain-design gate, 2026-09-24. [Q3]

**Context.** The FastAPI routing layer is where the language boundary physically
sits. Splitting it into a public surface and an owner surface would make the
protected routes structurally obvious.

**Decision.** One `HttpApi` component carrying every route, one error envelope,
one OpenAPI document. Authorization is enforced per operation inside the
components behind it, never by the routing layer's shape.

**Consequences.**

*Positive.* One envelope and one generated client. This matters more than it
looks: the frontend's types are generated from that document, and the editor
branches on the conflict status and reads field-level issues, so a second document
would mean a second client and a second chance to diverge.

*Negative.* "Is this route protected?" is answered per route rather than by which
module it lives in. Mitigated by the requirement that authorization is enforced at
the operation boundary and by the tests that call the API directly, bypassing the
frontend.

**Security and compliance.** The rejected split would have offered *structural*
assurance that a route is protected; this decision trades that for *behavioural*
assurance instead. That trade is only sound because NFR2 requires every protected
operation to authorise itself and the test suite calls the API directly with no
session — so a route accidentally left unprotected fails a test rather than merely
looking wrong in review. If that test discipline ever lapses, this ADR should be
revisited.

**Alternatives rejected.**

- *Split `PublicApi` and `OwnerApi`.* Rejected on a concrete case rather than a
  general preference: the media route is public when its asset is referenced by
  published content and owner-only otherwise, so it belongs to both surfaces. The
  split fails exactly where the protected/unprotected distinction is hardest, which
  is the one place it was supposed to help.

---

## ADR-004 — `MediaIntake` and `MediaDelivery` are separate components

**Status:** Accepted, 2026-09-24. Not put to the human; recorded because it is a
boundary decision and the alternative is the obvious one.

**Context.** The existing system has one media concern split across two route
handlers. The natural port is a single `Media` component.

**Decision.** Two components: `MediaIntake` owns what may enter, `MediaDelivery`
owns what may leave and to whom.

**Consequences.**

*Positive.* Intake is input validation over the system's largest untrusted-input
surface; delivery is access control. These fail differently, are tested
differently, and change for different reasons. Keeping them apart means the
asset-visibility rule is not sitting in the same module as the byte-signature
parsers.

*Negative.* Both components depend on both `AssetStore` and `ContentStore`, so the
dependency graph is slightly wider than a merged component would produce.

**Security and compliance.** Both halves are security surfaces and they are
different ones. Intake is the system's largest untrusted-input surface — arbitrary
bytes from the network, parsed by hand-written signature readers. Delivery is an
access-control surface. Merging them would put "may this file exist?" and "may this
person see it?" in one module, so a defect in either would be reviewed in the same
breath as the other. No regulated data class is involved.

**Alternatives rejected.**

- *One `Media` component.* Fewer edges, but it would place an access-control rule
  and an input-validation rule in one module with no boundary between them, and
  both are hazard-marked requirements.

---

## ADR-005 — The frontend is two components plus a client, not one

**Status:** Accepted, 2026-09-24. Not put to the human.

**Context.** `PublicSite` and `OwnerEditor` share a design system, CSS and many
presentation components. A single `Frontend` component would reflect that sharing.

**Decision.** Three: `PublicSite`, `OwnerEditor`, and `ApiClient` as the single
crossing point of the language boundary.

**Consequences.**

*Positive.* The two surfaces have genuinely different lifecycles — one changes for
design reasons, the other when editing capability changes — and only one of them
mutates anything. Isolating `ApiClient` is what makes "nothing else crosses the
boundary" a checkable claim rather than an assertion: the gate can assert that no
other frontend module performs a backend call.

*Negative.* Shared presentation code belongs to neither component cleanly. Units
Generation will have to decide where it lives.

**Security and compliance.** Isolating `ApiClient` is what makes the language
boundary *checkable* rather than asserted, and the language boundary is a security
control: it is the reason no storage credential, no signing key and no authorization
decision can exist in code that ships to a browser. Merging the frontend would not
by itself create a vulnerability, but it would remove the ability to prove the
absence of one.

**Alternatives rejected.**

- *One `Frontend` component.* Matches the shared code, but would make the
  boundary claim unverifiable and would merge a read-only surface with the only
  mutating one.

---

## Assumptions & Open Questions

- **[assumption]** No decision here introduces a background worker, scheduler or
  queue. Retention runs inside the write that triggers it, as it does today.
- **[closed]** Whether `ContentStore` can express the content write, revision entry
  and retention prune as one atomic operation. Closed by redrawing the call graph at
  review: one caller, one combined operation, no transaction context crossing a
  component boundary. See ADR-001.
- **[open, owner `nfr-design`]** The published-document cache interval (ADR-002).
- **[open, owner `functional-design`]** Whether any part of the editor's save
  state machine is a rule rather than presentation state, which would move it
  across the boundary. The draft-recovery classification, which sat in the same
  grey area, is now closed: it is a correctness rule and lives behind
  `ContentAuthority` (ADR-006).

---

## ADR-006 — The draft-recovery classification is a backend rule

**Status:** Accepted after review finding R-01, 2026-09-24.

**Context.** FR8.3 is hazard-marked. It requires a recovered draft carrying a
validation problem to be classified as recoverable — offer it to the owner — or
corrupt — discard it. The previous system got this wrong, discarding an entire
recovered draft when one enumerated value was invalid, because its allowlist named
a validation code its validator never emits. The first draft of this design placed
that classification in `OwnerEditor`, reasoning that it operates on browser-local
state that never reaches the backend.

**Decision.** The classification is a **backend rule**. `ContentAuthority` exposes an
inspect operation over a candidate document that returns the normalised document plus
each issue classified as recoverable or corrupting. `OwnerEditor` submits the
recovered draft and renders the verdict.

**Consequences.**

*Positive.* The rule lives with the component that already owns authoritative
validation and the issue list, so there is exactly one definition of what a
recoverable field problem is. It becomes testable in Python, under the 100% hazard
coverage floor, without a browser. And it stops being an exception to NFR1 that would
have been cited later to justify the next one.

*Negative.* Draft recovery now requires a network round trip before the owner is
offered their work back. Acceptable: recovery happens once per editor load at most,
and it is already the slowest path in the editor.

*Risk.* If the backend is unreachable at recovery time, the editor cannot classify.
It must then hold the draft and say so, never silently discard it — which is the
failure this ADR exists to prevent.

**Security and compliance.** Neutral. The recovered draft is the owner's own content
travelling to a backend that already holds it; no new data crosses a boundary. The
inspect operation is owner-authenticated like every other content operation, so it
does not widen the unauthenticated surface.

**Alternatives rejected.**

- *Keep the classification in `OwnerEditor` with a justification.* Rejected: the rule
  encodes which validator outcomes are survivable, which is a correctness decision, and
  the previous system's bug is the proof that it is subtle enough to get wrong.
- *Generate the classification into the frontend from the OpenAPI document.* Rejected:
  the schema document describes shapes, not which failures are survivable, so this
  would have been a hand-written rule wearing a generated rule's clothes.
