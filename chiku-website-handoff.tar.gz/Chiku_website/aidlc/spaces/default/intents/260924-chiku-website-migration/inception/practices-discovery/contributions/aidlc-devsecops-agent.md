**Collaborator:** aidlc-devsecops-agent

## Contribution

Scope of this review: lint/format **enforcement**, static analysis, secret handling, dependency
and supply-chain controls. Testing volume and code style belong to others; where I touch them it
is only where a security control rides on them.

**A placement note the lead needs before integrating any wording below.** `team-practices.md`
mirrors the five H2 sections `practices-promote` writes into `team.md`. A new `## Security` H2
would be written here and then dropped at promotion. Every proposed block below is therefore
placed inside an existing section: gate commands into `## Testing Posture`, secrets and container
configuration into `## Deployment`, the `ruff` ruleset into `## Code Style` → Python, and the
port obligations into `## Way of Working`.

### 1. Secret handling — the draft says nothing, and silence defaults to the worst option

`team-practices.md` does not contain the word "secret", "key" or "environment variable". It makes
Docker Compose the verification vehicle and specifies two runtimes, and never says how the
session signing key comes into existence, where it lives, or what happens when it is absent.

This project has **no practice to inherit**: the source uses `process.env` in build scripts only
and nowhere in `app/`. `siteOrigin` and `OWNER_EMAIL` are source literals (`code-quality-assessment.md`
findings D and E), and `OWNER_EMAIL` is a personal address committed to the repository acting as
the authorization root of trust. The port introduces a configuration surface for the first time.
An unspecified signing key becomes a module-level default or a per-process random value, and the
per-process value is the worse of the two because it looks like it works.

Proposed new bullets under `## Deployment`, after the "Docker Compose is the verification
vehicle" bullet:

> - **Configuration and secrets.** Two secrets exist: the session signing key and the
>   initial-owner bootstrap secret. Both reach the process as **environment variables read at
>   startup**. Neither is ever a literal in a source file, and neither is ever baked into an image.
> - **The signing key is generated, never chosen.** Generate once per environment with
>   `python -c "import secrets; print(secrets.token_urlsafe(64))"` and keep it outside the
>   repository. In development it lives in an uncommitted `.env` that Compose loads via
>   `env_file:`; in a container it is injected at run time.
> - **A missing key is a boot failure.** If `SESSION_SIGNING_KEY` is unset, empty, or under 32
>   bytes, the backend raises during startup with a message naming the variable and exits
>   non-zero. There is **no default value, no fallback, and no auto-generated per-process key** —
>   an auto-generated key silently invalidates every session on restart and hides the
>   misconfiguration. The same rule holds for every required setting: fail at boot, not at first
>   request.
> - **Nothing secret crosses the image boundary.** No `ARG` or `ENV` in either `Dockerfile`
>   carries a secret value. A build-time credential, if one is ever needed, uses a BuildKit secret
>   mount (`RUN --mount=type=secret,id=...`) so the value never lands in a layer. `docker history`
>   on both images shows no secret value; this is checked once, at the skeleton gate.
> - **`.env` discipline.** A committed `.env.example` lists every variable the system reads, with
>   empty values and a one-line comment each; real `.env` files are never committed. The
>   workspace `.gitignore` already enforces the split (`.env`, `.env.*`, `!.env.example`,
>   `!.env.*.example`). No `.env.example` exists yet — creating it is a Bolt 1 deliverable, since
>   it is the only place a reader learns what configuration the system needs.
> - **`NEXT_PUBLIC_*` is public forever.** Next.js inlines any `NEXT_PUBLIC_`-prefixed value into
>   the client bundle at build time. It is readable by every visitor, it is baked into the built
>   image, and it cannot be rotated without a rebuild. Only the public backend base URL and the
>   site origin — the replacements for the hard-coded `siteOrigin` — may carry that prefix. No
>   key, token, hash or address goes there; in particular `OWNER_EMAIL` becomes backend-only
>   configuration and must never reappear as `NEXT_PUBLIC_OWNER_EMAIL`.

### 2. Initial-owner provisioning — making the `NEVER` rule checkable

`discovered-rules.md` already states this correctly as a `NEVER` (`NEVER ship a default, seeded,
sample or hard-coded credential…`), and it is correctly attributed to a confirmed human answer.
My objection is not to the rule but to its testability: "supplied at runtime through
configuration" does not say what a fresh `docker compose up` against an empty volume actually
does, so no reviewer can fail a Bolt against it.

The mechanism below is **my proposal and belongs in `team-practices.md`, not in
`discovered-rules.md`** — the human stated the prohibition, not the mechanism. Proposed for
`## Deployment`:

> - **Initial-owner provisioning.** The backend ships no owner row and no seed SQL that creates
>   one. On startup, when no owner record exists **and** `ADMIN_BOOTSTRAP_SECRET` is set, the
>   backend enables a single one-shot provisioning route that requires that secret, accepts the
>   owner's chosen password, stores only its argon2id hash, and is refused permanently once an
>   owner row exists. The gate condition is "an owner row exists", not a consumed flag, so
>   restarting the container cannot re-open the route. When the secret is unset and no owner
>   exists, the service starts and refuses every login rather than creating an account. The
>   acceptance test for the no-default-credential rule is exactly this: **a fresh
>   `docker compose up` against an empty volume has no account anyone can log into.**

### 3. Dependency and supply-chain controls — free, local, and gate-executable

All of the following run on the developer machine with no account, no subscription and no CI.

**Mandatory — add to the `## Testing Posture` merge gate:**

| Control | Command | Why it is mandatory |
|---|---|---|
| Python advisories | `uv export --frozen --no-dev --no-emit-project -o .audit/requirements.txt` then `uvx pip-audit -r .audit/requirements.txt` | The backend owns the whole security surface. `uvx` runs `pip-audit` ephemerally, so it is not a project dependency |
| Node advisories | `pnpm audit --prod --audit-level high` | The frontend ships to browsers |
| Lockfile integrity | `uv sync --frozen` and `pnpm install --frozen-lockfile` are the **only** install commands used at the gate and in both `Dockerfile`s | A non-frozen install lets the verified tree and the built tree differ silently, and with no CI nothing else notices |
| Base image pinning | `FROM python:3.14-slim@sha256:…` and the Node equivalent — **digest, never a floating tag** | A floating tag makes today's verified build and tomorrow's build different software under the same name. Digests are bumped deliberately, in their own commit, with the audits re-run |
| Non-root container user | A user created in each image; the persistent volume owned by that uid | The backend writes uploaded files. The source's PDF check is five bytes (`%PDF-`) with no polyglot detection, and the serving CSP is what contains that — an upload path running as root removes the last margin |

I have not executed these against the installed `uv` 0.10.0 and `pnpm`; **pin the exact flag
spelling once, in Bolt 1, and record it.** What is being affirmed here is the gate entry, not the
flag string.

**Advisory handling.** An advisory with no fix available does not silently pass. It is recorded
with the package, the advisory id, the reason it cannot be fixed, and the named Bolt that owns it
— consistent with the correction already in `project.md` about findings carried past a gate
needing a named owner.

**Optional, and I do not propose mandating them:** SBOM generation (`syft`) — free, but nothing
in a plan-only, nothing-deployed workflow consumes it; `gitleaks` as a pre-commit secret scan —
useful, but it is a new binary to install, and with only two secrets and both of them backend
Python the `ruff` `S` ruleset in §4 covers the same class at zero marginal cost; `uv`'s
`--exclude-newer` — it takes a fixed timestamp rather than a rolling window, so it needs manual
bumping and will rot.

**Two supply-chain facts the draft inherits without deciding:**

- `madhavi-tripathi/.npmrc` sets `audit=false`. Whatever else is copied forward, that line is not.
- `madhavi-tripathi/pnpm-workspace.yaml` sets `minimumReleaseAge: 10080`. `evidence.md` records
  this only as friction ("a fresh install refuses packages published in the last week"). **It is a
  supply-chain control** — a seven-day cooldown is the cheapest available defence against a
  compromised fresh release, and it costs nothing. Keep it in the ported workspace file; if it is
  removed, remove it knowingly. There is no rolling-cooldown equivalent in `uv`, so the Python
  side's defence is the committed lockfile plus `pip-audit`, and that asymmetry should be stated
  rather than left to be discovered.

### 4. Static analysis — enable `ruff`'s `S` ruleset, and widen D9

The draft puts `ruff check` on the merge gate and never says which rules it selects. D9 asks the
human about line length and `mypy` strictness and does not ask about rule selection — which is
the security-relevant half of the same decision.

**Position: `S` (flake8-bandit) is enabled, and this is not a close call.** It ships inside a
tool already on the gate, adds no dependency, costs nothing, and is the only static security
analysis this project will ever have. Proposed replacement for the Python **Linter** bullet in
`## Code Style`:

> - **Linter**: `ruff check`, configured in `pyproject.toml`, with `select` including at minimum
>   `E`, `F`, `I`, `UP` and **`S` (flake8-bandit)**. `S` is this project's entire static security
>   analysis: `S105`/`S106`/`S107` catch a credential written as a literal — the exact failure the
>   no-default-credential rule forbids — and `S324` (weak hash), `S501`/`S506`,
>   `S602`–`S607` (shell-injection shapes) and `S608` (string-built SQL) cover the rest of what
>   matters for a password-authenticating upload service. `S101` (bare `assert`) is ignored under
>   `tests/` through `per-file-ignores`. Nothing else in `S` is disabled without a written reason
>   at the line.

Proposed replacement for D9:

> **OPEN (D9).** `ruff` and `mypy` configuration: line length, whether `mypy` runs `strict`, and
> **which `ruff` rule families are selected** — specifically whether `S` (flake8-bandit) is in the
> set. `S` is the only static security analysis available at zero cost, so this is not a
> formatting detail.

### 5. Port obligations — the attribution the copy-forward loses

`dependencies.md` carries an explicit warning that the vendored MIT notices are easy to lose in a
copy-forward, and the draft's port practice does not mention them. Proposed new bullets under
`## Way of Working`:

> - **A vendored file's notice travels with it.** If any of the 12 live `components/ui/*.tsx`
>   files moves into the new tree, `vendor/shadcn-tailwind-4.13.0.LICENSE.md` moves with it — those
>   61 files carry no per-file header, and the `vendor/` notice is what covers them.
>   `build/sites-vite-plugin.LICENSE` may be dropped only together with
>   `build/sites-vite-plugin.ts`. Both are MIT with an attribution obligation.
> - **The port drops the 13 production dependencies with no path from any entry point** (the 10
>   reachable only through unused UI components plus the 3 imported nowhere). Carrying them
>   forward carries half the audit surface for no function; not carrying them is the cheapest
>   supply-chain control available on this project.
> - **Reuse-first and supply chain are in tension by construction.** The mandated
>   "prefer a maintained public library over custom code" adds an audited dependency with every
>   application. The tie-break: prefer the library, and record the addition — the gate audits it
>   from then on. State it once here rather than letting the two rules collide mid-Bolt.

### 6. What belongs in `discovered-rules.md` versus `team-practices.md`

`discovered-rules.md` is disciplined in my lane and I am not asking for additions on my own
authority. Three observations:

- **Nothing of mine goes in the rules file.** The provisioning mechanism (§2), the `S` ruleset
  (§4), the audit commands and digest pinning (§3) are all agent proposals. They belong in
  `team-practices.md` and must not be promoted as `ALWAYS`/`NEVER` rules.
- **One possible omission, for the human to settle at the gate.** The constraint that *no secret
  crosses the image boundary through Docker `ARG`/`ENV`, and build-time secrets use a supported
  secret mount* reached this stage as an established fact in a dispatch brief. I cannot tell from
  here whether the human stated it or whether an agent framed it. **Ask.** If the human stated it,
  it is a hard constraint and belongs under `## Forbidden` as
  `NEVER pass a secret into a container image through Docker ARG or ENV; build-time secrets use a
  BuildKit secret mount.` If it is an agent framing, it stays in `team-practices.md` as the §1
  bullet. Do not promote it on my say-so.
- **No misfiling in the other direction.** The no-default-credential `NEVER`, the zero-cost
  `NEVER`, and the no-GCP-resource `NEVER` all trace to confirmed human answers and are correctly
  shaped as prohibitions.

### 7. The largest security gap in the draft

**The merge gate is this project's only enforcement point, and not one item on it is a security
check.**

The gate is `ruff check`, `ruff format --check`, `mypy`, `pytest`, `tsc --noEmit`, `pnpm lint`,
and the Compose run. There is no CI, no remote, no pull request and no reviewer — the draft says
so itself. So that list is the complete set of things that will ever be true of code before it
lands on `main`. Nothing on it looks at a dependency advisory, a committed secret, a container
running as root, or a dangerous code pattern. A vulnerable transitive package, a signing key
pasted into a settings module, and a root-owned upload directory all merge clean today.

Everything else in this review is a symptom of that one omission: nobody proposed that the gate
should look at security, so it does not. The concrete casualty is the session signing key — the
root of trust for the entire authenticated surface, currently unspecified in a document that
otherwise specifies the exact `pytest` coverage exclusions.

## Positions

- AGREE: `ruff` and `mypy` gating new Python from day one — the "no legacy, therefore no
  trade-off" argument is correct, and it is exactly what makes a security ruleset free to add.
- AGREE: writing the local merge gate down as an explicit command list rather than leaving the
  skipped `ci-pipeline` as an implied hole — with no remote there is no other enforcement point,
  and an unwritten gate is no gate.
- AGREE: per-branch tests on the hazard-ranked behaviours instead of a coverage percentage — the
  media access rule is access-control code and the image header parsers are input validation, and
  a percentage cannot distinguish "ported" from "ported correctly".
- AGREE: leaving ported frontend bytes unformatted (D4). Not my lane on style grounds, but it
  carries a security benefit the draft does not claim: a line-granular diff is the only way a
  reviewer will notice a validation branch or a response security header quietly vanishing during
  the port, and `app/api/media/[key]/route.ts` is one of the dense files.
- AGREE: recording that no org scope floor reaches a custom scope rather than silently inheriting
  80% — the same reasoning applies to the security controls above, none of which arrive
  automatically either.
- OBJECT: the merge gate carries no security check of any kind. See §7; this is the finding.
- OBJECT: `team-practices.md` never mentions the session signing key, `.env` discipline, or the
  `NEXT_PUBLIC_*` build-time inlining hazard, while making Compose the verification vehicle. The
  configuration surface is new to this project — the source has zero `process.env` uses in `app/`
  and hard-codes `siteOrigin` and `OWNER_EMAIL` — so there is no practice to inherit and silence
  resolves to the worst available default.
- OBJECT: D9 scopes Python tool configuration to line length and `mypy` strictness. Ruleset
  selection is the security-relevant half of that decision and no one will currently be asked
  about it.
- OBJECT: the `NEVER ship a default credential` rule has no specified provisioning mechanism, so
  it cannot be failed against. A rule a reviewer cannot check is documentation, not a control.
- OBJECT: `## Deployment` specifies two container images and says nothing about base-image
  pinning or a non-root user. Building an image is a supply-chain act even when nothing ships it.
- OBJECT: `evidence.md` classifies `minimumReleaseAge: 10080` as a maintenance annoyance. It is a
  supply-chain control and should be reclassified before someone removes it to make an install
  faster.
- OBJECT: the two vendored MIT notices appear in `dependencies.md` with an explicit warning that a
  copy-forward loses them, and appear nowhere in the draft's port practice.
- OBJECT: `madhavi-tripathi/.npmrc` carries `audit=false`. The draft's port practice does not
  distinguish files that are copied from files that are re-decided, so a suppression can be
  inherited by accident.
