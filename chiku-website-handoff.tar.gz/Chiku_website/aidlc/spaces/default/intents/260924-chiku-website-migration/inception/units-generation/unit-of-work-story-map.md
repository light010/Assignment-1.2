# Unit Story Map — chiku-website runtime-split migration

**Upstream:** `inception/units-generation/unit-of-work.md`,
`inception/units-generation/unit-of-work-dependency.md`,
`inception/requirements-analysis/requirements.md`.

> **Sensor note.** The `traceability` sensor's unit-mapping check searches this
> file for identifiers matching `USx.y`. Because `user-stories` was skipped, no
> such identifier exists anywhere in this workflow, so that check reports
> `failed` for this stage and structurally cannot pass. The sensor is advisory
> and does not block the gate. The mapping below is complete against the
> identifiers this workflow actually produced; no story IDs were invented to
> satisfy a grep.

`user-stories` was marked SKIP by the composed scope — two personas, both
unchanged from the current site and neither in conflict, so the acceptance
criteria landed in requirements analysis instead. There are therefore no `USx.y`
identifiers to map. **This map uses the `FR` identifiers in their place**, which
are the only upstream identifiers this workflow produced.

## Requirement to unit

One row per upstream identifier, so the mapping is machine-readable as well as
readable. Grouping and rationale follow in the sections below.

| ID | Unit | Directory |
|---|---|---|
| FR1 | U8 | `u8-public-site` |
| FR1.1 | U8 | `u8-public-site` |
| FR1.2 | U8 | `u8-public-site` |
| FR1.3 | U8 | `u8-public-site` |
| FR1.4 | U8 | `u8-public-site` |
| FR1.5 | U8 | `u8-public-site` |
| FR1.6 | U8 | `u8-public-site` |
| FR1.7 | U8 | `u8-public-site` |
| FR1.8 | U8 | `u8-public-site` |
| FR2 | U8 | `u8-public-site` |
| FR2.1 | U8 | `u8-public-site` |
| FR2.2 | U8 | `u8-public-site` |
| FR2.3 | U8 | `u8-public-site` |
| FR2.4 | U8 | `u8-public-site` |
| FR2.5 | U8 | `u8-public-site` |
| FR2.6 | U8 | `u8-public-site` |
| FR3 | U3 | `u3-identity-and-session` |
| FR3.1 | U3 | `u3-identity-and-session` |
| FR3.2 | U3 | `u3-identity-and-session` |
| FR3.3 | U3 | `u3-identity-and-session` |
| FR3.4 | U3 | `u3-identity-and-session` |
| FR3.5 | U3 | `u3-identity-and-session` |
| FR3.6 | U3 | `u3-identity-and-session` |
| FR3.7 | U3 | `u3-identity-and-session` |
| FR3.8 | U6 | `u6-http-api` |
| FR4 | U4 | `u4-content-core` |
| FR4.1 | U4 | `u4-content-core` |
| FR4.2 | U4 | `u4-content-core` |
| FR4.3 | U4 | `u4-content-core` |
| FR4.4 | U4 | `u4-content-core` |
| FR4.5 | U4 | `u4-content-core` |
| FR4.6 | U4 | `u4-content-core` |
| FR4.7 | U4 | `u4-content-core` |
| FR5 | U4 | `u4-content-core` |
| FR5.1 | U4 | `u4-content-core` |
| FR5.2 | U4 | `u4-content-core` |
| FR5.3 | U4 | `u4-content-core` |
| FR5.4 | U4 | `u4-content-core` |
| FR6 | U5 | `u5-media` |
| FR6.1 | U5 | `u5-media` |
| FR6.2 | U5 | `u5-media` |
| FR6.3 | U5 | `u5-media` |
| FR6.4 | U5 | `u5-media` |
| FR6.5 | U5 | `u5-media` |
| FR6.6 | U5 | `u5-media` |
| FR6.7 | U5 | `u5-media` |
| FR7 | U5 | `u5-media` |
| FR7.1 | U5 | `u5-media` |
| FR7.2 | U5 | `u5-media` |
| FR7.3 | U5 | `u5-media` |
| FR7.4 | U5 | `u5-media` |
| FR7.5 | U5 | `u5-media` |
| FR7.6 | U4 | `u4-content-core` |
| FR8 | U9 | `u9-owner-editor` |
| FR8.1 | U9 | `u9-owner-editor` |
| FR8.2 | U9 | `u9-owner-editor` |
| FR8.3 | U4 | `u4-content-core` |
| FR8.3.1 | U4 | `u4-content-core` |
| FR8.3.2 | U4 | `u4-content-core` |
| FR8.3.3 | U4 | `u4-content-core` |
| FR8.3.4 | U9 | `u9-owner-editor` |
| FR8.4 | U9 | `u9-owner-editor` |
| FR8.5 | U9 | `u9-owner-editor` |
| FR8.6 | U9 | `u9-owner-editor` |
| FR8.7 | U9 | `u9-owner-editor` |
| FR8.8 | U9 | `u9-owner-editor` |
| FR8.9 | U7 | `u7-api-client` |
| FR9 | U4 | `u4-content-core` |
| FR9.1 | U4 | `u4-content-core` |
| FR9.2 | U4 | `u4-content-core` |
| FR9.3 | U4 | `u4-content-core` |
| FR9.4 | U4 | `u4-content-core` |
| FR10 | U6 | `u6-http-api` |
| FR10.1 | U6 | `u6-http-api` |
| FR10.2 | U8 | `u8-public-site` |
| FR10.3 | U6 | `u6-http-api` |

## Requirements that span more than one unit

Four requirements are genuinely cross-cutting. Each is listed against its
**owning** unit above; this section records the other units that must cooperate,
so a Bolt does not assume a requirement is wholly its own.

| Requirement | Owning unit | Also implicates | Why |
|---|---|---|---|
| FR8.3 — Draft recovery | U4 content-core (the rule) | U9 owner-editor | The classification is a backend rule under ADR-006; the editor holds the bytes, submits them, renders the verdict, and owns the third unreachable-backend state. Neither half is complete alone. |
| FR7.2 — Asset visibility | U5 media (the rule) | U4 content-core | The rule is a substring test over the published document, which U4 owns and caches. A stale cache here is an authorization defect, not a performance one. |
| FR3.8 — Per-operation authorization | U6 http-api (the surface) | U3, U4, U5 | The routing layer enforces nothing structurally; each operation authorises itself. A route added without its check fails a test that calls the API directly rather than failing review. |
| FR10.1 — Error envelope | U6 http-api (the shape) | U9 owner-editor | The editor branches on the conflict status and reads field-level issues. The envelope is only correct if both ends agree, so it cannot be verified inside U6 alone. |

## Units with no requirement of their own

Four units realise non-functional requirements or exist to enable others, and
map to no `FR`. They are listed so their absence from the table above reads as
deliberate.

| Unit | What it realises |
|---|---|
| U1 source-fixtures | NFR10. The oracle every behaviour-preservation claim rests on. Expires when the source is retired. |
| U2 storage-ports | NFR3, and the persistence half of FR4–FR7. Owns no requirement because it owns no rule. |
| U10 containers | NFR4, and the container half of NFR3 and NFR5. |
| U11 cloud-adapters | The cloud half of NFR3; supports NFR6. Shipped unverified against real services. |
| U12 deployment-plan | NFR6 and success condition S4. |

## Assumptions & Open Questions

- **[assumption]** Using `FR` identifiers in place of `USx.y` is faithful to the
  stage's intent rather than a workaround: the stage maps the upstream acceptance
  identifiers to units, and in this workflow those are the requirement IDs. A
  reader expecting story IDs should look here.
- **[assumption]** The four cross-cutting requirements are listed against one
  owning unit each so that no requirement has two owners. The cooperating unit
  carries no independent acceptance for that requirement; it is verified at the
  boundary between them, which is what the containerised end-to-end run exists to
  cover.
