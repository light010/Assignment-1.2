# Domain Design — Questions

Upstream: `inception/requirements-analysis/requirements.md`,
`codekb/Chiku_website/architecture.md`, `…/component-inventory.md`,
`inception/practices-discovery/team-practices.md`.

Most of the decomposition is forced rather than chosen. The language boundary
fixes where the frontend ends and Python begins; the affirmed practices fix that
ports are named for real things and that a layer exists only when it has a job;
and the requirements fix which behaviours must be separable for testing. Those
parts are recorded in `components.md` without being asked about.

Three boundaries have more than one viable answer, and each has a real cost on
both sides.

---

## Q1. One storage port, or one per concern?

Persistence must sit behind a port so SQLite can be the verified local
implementation while Firestore is the cloud one. The open question is how many
ports there are.

Six kinds of state exist: the content document, the revision ledger, the owner
account, sessions, login-attempt counters, and asset metadata. (Asset *bytes*
are separate in every option — they always go to a dedicated `AssetStore`,
because a file blob and a row are not the same kind of thing.)

**Option A — one `ContentStore` for all six kinds.** One interface, one SQLite
adapter, one Firestore adapter, one contract test suite run against both.
*Pro:* the adapter count stays at two, and the conformance suite that proves the
port is honest is written once. *Con:* one interface with methods spanning
unrelated concerns; a change to session handling touches the same file as
content writes.

**Option B — three ports: `ContentStore` (document + revisions), `IdentityStore`
(owner + sessions + login counters), `AssetStore` (metadata + bytes).** Each is
named for a real thing and each has a single reason to change.
*Pro:* boundaries follow the concerns; the identity port could later move to a
different backing store without touching content. *Con:* three interfaces, six
adapters, and the contract suite must be written three times — against a
requirement that already demands each suite run over both a real adapter and an
in-memory fake.

**Option C — one port per owning component (six).** Maximum separation.
*Pro:* perfectly aligned with entity ownership. *Con:* twelve adapters for a
single-owner website; this is the "generic repository" shape the affirmed
practices explicitly forbid, arrived at from the other direction.

A. Option A — one `ContentStore` plus `AssetStore`.
B. Option B — three ports: content, identity, assets.
C. Option C — one port per owning component.
D. Not yet defined.
X. Other (please specify)

[Answer]: B. Option B — three ports: content, identity, assets.

---

## Q2. Where does the published-document cache live?

You confirmed that the media access rule is preserved exactly — an asset is
public if and only if its path appears anywhere in the serialised published
document — and that a short-lived cache collapses the per-byte cost. The
question is which component owns that cache.

**Option A — `ContentAuthority` owns it.** It already owns the content document
and is the only component that knows when a publish happens, so invalidation is
a local call with no cross-component signalling. Media serving asks it for the
current published document.
*Pro:* one owner, exact invalidation, and any future reader benefits.
*Con:* a caching concern lands inside the component that owns business rules.

**Option B — `MediaDelivery` owns it.** The cache lives next to the only code
that currently suffers the cost.
*Pro:* the cost and its remedy sit together. *Con:* invalidation now needs a
publish signal to cross a component boundary, and a second reader of the
published document would need its own cache or would silently miss this one.

**Option C — no cache; re-read every time.** Truest to the original, including
its cost.
*Pro:* nothing to invalidate, nothing to get wrong. *Con:* rejects the answer
already given at requirements, where you chose preserve-plus-cache.

A. Option A — `ContentAuthority` owns the cache and invalidates on publish.
B. Option B — `MediaDelivery` owns it.
C. Option C — no cache after all.
D. Not yet defined.
X. Other (please specify)

[Answer]: A. Option A — `ContentAuthority` owns the cache and invalidates on publish.

---

## Q3. One HTTP surface, or split public and owner?

The FastAPI routing layer is where the language boundary physically is. It can
be one component or two.

**Option A — one `HttpApi`.** All routes, one error envelope, one OpenAPI
document, with authorization enforced per operation inside the components behind
it.
*Pro:* one envelope and one generated client, which matters because the
frontend's types are generated from that document and the editor depends on the
exact error shape. *Con:* public and owner-only routes live in one module tree,
so the "is this route protected?" question is answered per route rather than
structurally.

**Option B — `PublicApi` and `OwnerApi` as separate components.** Public reads
in one, everything requiring a session in the other.
*Pro:* the protected surface is structurally obvious, and a route added to the
wrong one is visible in review. *Con:* two OpenAPI documents or one merged one;
the media route belongs to *both* (it serves publicly when published and
owner-only otherwise), so the split does not cleanly hold where it matters most.

A. Option A — one `HttpApi`, with authorization enforced per operation behind it.
B. Option B — split `PublicApi` and `OwnerApi`.
C. Not yet defined.
X. Other (please specify)

[Answer]: A. Option A — one `HttpApi`, with authorization enforced per operation behind it.

---

## Consolidated Summary Confirmation

- Q1 — Three storage ports: `ContentStore` (content document + revision ledger), `IdentityStore` (owner account + sessions + login counters), `AssetStore` (asset metadata + bytes). Each named for a real thing with one reason to change. Each gets a conformance suite run over a real adapter and an in-memory fake.
- Q2 — `ContentAuthority` owns the published-document cache and invalidates it on publish, because it owns the document and is the only component that knows when a publish happens.
- Q3 — One `HttpApi` component carrying every route, one error envelope and one OpenAPI document, with authorization enforced per operation inside the components behind it.

Does this all look correct before I generate the artifact?

- Looks correct
- Request changes

[Answer]: Looks correct
