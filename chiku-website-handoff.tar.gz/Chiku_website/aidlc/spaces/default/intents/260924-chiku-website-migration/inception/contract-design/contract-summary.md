# Contract Summary — chiku-website runtime-split migration

**Upstream:** `inception/units-generation/unit-of-work.md`,
`inception/units-generation/unit-of-work-dependency.md`,
`inception/domain-design/components.md`,
`inception/requirements-analysis/requirements.md`.

Four contract surfaces. One is external and synchronous over HTTP; three are
in-process interfaces with two adapter families each.

## Contracts

| # | Provider Unit | Consumer | Mechanism | Owner |
|---|---|---|---|---|
| C1 | U6 http-api | External: public web (browser, and the Next.js renderer server-side) | Synchronous REST/HTTP, same origin | U6 |
| C2 | U2 storage-ports → `ContentStore` | U4 content-core, U5 media | In-process interface; adapters in U2 (SQLite) and U11 (Firestore) | U2 |
| C3 | U2 storage-ports → `IdentityStore` | U3 identity-and-session | In-process interface; adapters in U2 and U11 | U2 |
| C4 | U2 storage-ports → `AssetStore` | U5 media | In-process interface; adapters in U2 (volume) and U11 (Cloud Storage) | U2 |

`U7 api-client` is not a contract surface: it is generated output of C1,
regenerated at the merge gate, and the gate fails if the committed output is dirty.

---

## C1 — the HTTP surface

Shape only. Field-level schemas come from the Pydantic models and are published as
the generated OpenAPI document; this block fixes the operations, the status codes
and the envelope, which are the parts that must be **ported rather than designed**.

```yaml
openapi: 3.1.0
info:
  title: chiku-website API
  version: "1.0.0"
  description: >
    The single application surface. Every authorization decision is made in the
    operation behind the route, never by the route's placement, so a request that
    bypasses the frontend is rejected identically to one that does not.

components:
  securitySchemes:
    ownerSession:
      type: apiKey
      in: cookie
      name: session
      description: >
        Signed, HttpOnly, Secure, SameSite=Lax. Expires 8h idle (sliding) /
        7d absolute. Revoked server-side on sign-out. Mutations additionally
        require the paired CSRF token as a request header (double-submit).
  schemas:
    Error:
      type: object
      required: [error]
      properties:
        error: { type: string, description: One human sentence. Product copy; falls under the parity rule. }
        issues:
          type: array
          description: Present only on validation failure. Field-level, consumed by the editor.
          items:
            type: object
            required: [path, message]
            properties:
              path: { type: array, items: { oneOf: [{type: string}, {type: integer}] } }
              message: { type: string }
    ContentState:
      type: object
      required: [draft, published, revision, hasUnpublishedChanges]
      properties:
        draft: { $ref: '#/components/schemas/Content' }
        published: { $ref: '#/components/schemas/Content' }
        revision: { type: integer }
        updatedAt: { type: string, nullable: true }
        publishedAt: { type: string, nullable: true }
        hasUnpublishedChanges: { type: boolean }
    Content:
      type: object
      description: >
        Generated from the Pydantic model. camelCase on the wire and FROZEN - the
        ported components read this shape directly and the persisted draft and
        published columns hold this exact JSON, so a rename is also a data
        migration. Conversion happens in exactly one place: a shared Pydantic base
        with alias_generator=to_camel and populate_by_name=True.

paths:
  /api/public/content:
    get:
      summary: The published content document. Unauthenticated.
      responses:
        "200": { description: The published document }
        "503": { description: Storage unavailable or the stored document failed validation }

  /api/auth/session:
    get:
      summary: Whether the caller holds a valid session. Drives the footer edit link only.
      responses:
        "200": { description: "{ signedIn: boolean }" }

  /api/auth/login:
    post:
      summary: Verify credentials and issue a session.
      responses:
        "200": { description: Session issued; sets the cookie and returns the CSRF token }
        "400": { description: Malformed request }
        "403": { description: Rejected. Identical body whether the account is unknown, the password is wrong, or the rate limit is reached - no enumeration }

  /api/auth/logout:
    post:
      security: [{ ownerSession: [] }]
      summary: Revoke the session server-side.
      responses:
        "204": { description: Revoked }

  /api/content:
    get:
      security: [{ ownerSession: [] }]
      summary: Full content state for the editor, and the source for the private draft preview (FR8.6).
      description: >
        Backs both the editor and the private draft preview. The preview needs no
        operation of its own - it renders the draft this already returns, in an
        isolated frame, using the visitor's presentation. Stated explicitly (R-02)
        because leaving it implicit invites a redundant endpoint.
      responses:
        "200": { description: ContentState }
        "403": { description: Not the owner }
        "503": { description: Storage unavailable }
    put:
      security: [{ ownerSession: [] }]
      summary: Save a draft or publish, under optimistic concurrency.
      description: >
        Body carries content, the caller's base revision, action (draft|publish)
        and an optional autosave flag which is valid only with action=draft.
      responses:
        "200": { description: Written. Returns the new revision and timestamps }
        "400": { description: Invalid request, or validation failure carrying issues[] }
        "403": { description: Not the owner, or the request origin does not match }
        "409": { description: Base revision no longer current. Caller's edits are preserved; current state returned so the caller can reconcile }
        "413": { description: Body exceeds 1,500,000 CHARACTERS of decoded text - characters, not bytes }
        "503": { description: Storage unavailable }

  /api/content/inspect:
    post:
      security: [{ ownerSession: [] }]
      summary: Classify a recovered draft. The rule lives here, not in the editor (ADR-006).
      description: >
        Returns the normalised document plus each issue classified as recoverable
        or corrupting. A recoverable issue is one an owner produces by typing - a
        value present and correctly typed but outside its permitted set or range,
        INCLUDING an out-of-set enumerated value. A corrupting issue is a malformed
        record - wrong shape, wrong type, or unparseable.
      responses:
        "200": { description: "{ normalised, issues: [{path, message, recoverable}] }" }
        "400": { description: Body unparseable at all }
        "403": { description: Not the owner }

  /api/history:
    get:
      security: [{ ownerSession: [] }]
      summary: List revisions, or fetch one by id.
      description: >
        Without id, returns summaries ordered revision DESC, baseline ASC,
        action DESC - a three-part sort that is load-bearing for display order -
        capped at the current limit. With id, returns that revision's full content.
      responses:
        "200": { description: Summaries, or one revision }
        "400": { description: id present but malformed }
        "403": { description: Not the owner }
        "404": { description: Absent or no longer retained. Body states the current draft is unaffected }
        "503": { description: Storage unavailable }

  /api/upload:
    post:
      security: [{ ownerSession: [] }]
      summary: Upload one file. Type determined by inspecting bytes, never by declared type or extension.
      responses:
        "200": { description: "{ url, filename, sources[] } - variants generated server-side" }
        "400": { description: Empty, unsupported kind, or failed signature/caption validation }
        "403": { description: Not the owner, or the request origin does not match }
        "413": { description: Over the per-kind ceiling - 50 MB video, 10 MB image/PDF, 1 MB captions }
        "499": { description: Cancelled by the client. Best-effort cleanup leaves no orphan }
        "503": { description: Storage unavailable }

  /api/media/{key}:
    parameters:
      - name: key
        in: path
        required: true
        schema: { type: string, pattern: '^[a-f0-9-]+\.(jpg|png|webp|pdf|mp4|webm|vtt)$' }
    get:
      summary: Serve an asset.
      description: >
        PUBLIC if and only if the literal media path for this key appears ANYWHERE
        in the serialised published document - including inside a transcript, the
        biography, any description, the notice, or any editable copy block.
        Otherwise owner-only, and reported as 404 rather than 403 so the response
        does not disclose that the key exists. Range semantics are ported branch
        for branch: multi-range -> 416; any range on a zero-byte object -> 416;
        an oversized suffix range -> 206 for the whole object; start >= size ->
        416 while end > size is SILENTLY CLAMPED. If-Range honoured.
        There is deliberately NO 304 path despite an ETag being emitted.
      responses:
        "200": { description: Whole object }
        "206": { description: Partial content }
        "404": { description: Not found, or not public and the caller is not the owner }
        "416": { description: Range not satisfiable; carries the total size }
        "503": { description: Storage unavailable }
    head:
      summary: Metadata only.
      description: >
        ALWAYS 200 with the full Content-Length. NEVER inspects the Range header
        and never returns 206 or 416, even where the equivalent GET would.
        HEAD and GET must not share range logic.
      responses:
        "200": { description: Headers only }
        "404": { description: Not found or not permitted }

  /sitemap.xml:
    get: { summary: Single canonical URL with lastModified when a publication time exists, responses: { "200": { description: XML } } }
  /robots.txt:
    get: { summary: Allow /, disallow /edit and /api/, link the sitemap, responses: { "200": { description: Text } } }
```

---

## C2 — `ContentStore`

```yaml
contract: ContentStore
kind: in-process interface
owner: U2 storage-ports
consumers: [U4 content-core, U5 media]
adapters:
  - sqlite      # U2, the verified implementation
  - firestore   # U11, shipped unverified against the real service
operations:
  read_state:
    returns: draft, published, revision, updated_at, published_at
    notes: Returns the seeded document when no row exists, rather than empty.

  commit:
    summary: >
      THE combined write. One call, one caller, one transaction. Carries the
      content update, the revision entry AND the retention prune together.
      Splitting these across calls is what FR4.5 exists to prevent.
    arguments:
      content: the validated document
      base_revision: the caller's revision, compared and set
      action: draft | publish
      mutation_token: unique per request - guards the SIDE EFFECTS, whose guard
        condition is NOT unique to the writer, which is why the revision alone
        is insufficient
      retention: the policy supplied by RevisionLedger - how many of each action
        survive, and which entries are permanent
    returns: the new state, or a conflict signal when base_revision no longer matches
    atomicity: REQUIRED. All three effects commit together or none does.
    prune_shape: >
      Expressed as read-the-survivors-then-delete-the-rest INSIDE the
      transaction. NOT as a SQL predicate - Firestore has no
      DELETE ... WHERE id NOT IN (subquery), and a SQL-shaped prune would be
      satisfiable by only one adapter.
    bounds: >
      At most 1 content document + 1 revision entry + the pruned set. Retention
      keeps this well inside Firestore's per-transaction document limit.
    payload_size: >
      REAL INCOMPATIBILITY, found at review (R-01) and resolved here. FR4.6
      requires this port to accept a content document up to 1,500,000 decoded
      CHARACTERS, which in UTF-8 can exceed 4 MB. Firestore's per-document limit
      is 1,048,576 bytes, and a revision entry stores the full content - so a save
      this port MUST accept cannot fit in one Firestore document. SQLite has no
      such limit, so the verified adapter is unaffected.
      RESOLUTION: the Firestore adapter stores any serialised payload over a safe
      threshold as a content-addressed object in Cloud Storage and keeps only the
      key in the Firestore document. Ordering is load-bearing - the blob is
      written FIRST, before the transaction. Because the key is a hash of the
      content the write is idempotent, so a transaction that then fails leaves an
      orphaned blob, which is reclaimable garbage, rather than a dangling
      reference, which is corruption. The reverse ordering is forbidden.
      COST, stated plainly: on the cloud path the guarantee weakens from
      'everything commits in one transaction' to 'the transaction is atomic, and
      the blob write precedes it and is idempotent'. That weakening does not
      exist on the verified SQLite path. It is an obligation on U11, which already
      ships unverified against the real service.

  list_revisions:
    returns: summaries ordered revision DESC, baseline ASC, action DESC
    notes: >
      The three-part order is load-bearing for display. The Firestore adapter
      REQUIRES a declared composite index for it; the deployment plan must carry
      that index definition, and the conformance suite must assert the order so a
      missing index fails a test rather than silently reordering the list.

  read_revision: { arguments: [id], returns: the entry with its content, or absent }

  asset_metadata:
    operations: [register, remove, read]
    notes: Row-shaped, so it lives here rather than in AssetStore.

conformance:
  suite: one adapter-parameterised suite
  run_against: [the real adapter, an in-memory fake]
  rationale: >
    Two implementations is the minimum that proves the suite tests the PORT
    rather than SQLite, and that is the whole argument for having a port.
```

---

## C3 — `IdentityStore`

```yaml
contract: IdentityStore
kind: in-process interface
owner: U2 storage-ports
consumers: [U3 identity-and-session]
adapters: [sqlite, firestore]
operations:
  owner_record: { operations: [read, create_if_absent], notes: "create_if_absent is the one-shot provisioning gate. The gate condition is the record's existence, not a consumed flag, so a restart cannot reopen it." }
  session: { operations: [create, read, touch, revoke], notes: "touch advances the idle window without extending the absolute expiry. revoke is server-side - a revoked session stops working, it does not merely vanish from one browser." }
  login_attempts: { operations: [record_failure, count_in_window, clear], notes: "Counted per account and per source address independently. Persisted so a restart does not reset the window." }
separation_rationale: >
  Separate from ContentStore because identity has a different reason to change and
  a different blast radius: the credential hash and session records are the
  highest-value data in the system, and a defect in a content query cannot reach
  them through a port that does not expose them.
```

---

## C4 — `AssetStore`

```yaml
contract: AssetStore
kind: in-process interface
owner: U2 storage-ports
consumers: [U5 media]
adapters:
  - filesystem      # U2, a mounted volume, durable across container recreation
  - cloud-storage   # U11, shipped unverified
operations:
  put:    { arguments: [key, bytes, media_type], notes: Original and each derived variant }
  get:    { arguments: [key], returns: bytes }
  get_range: { arguments: [key, offset, length], returns: bytes, notes: "IN THE PORT, not above it. Loading a whole video to serve one range is precisely what this port exists to avoid." }
  head:   { arguments: [key], returns: size, etag, media_type }
  delete: { arguments: [key], notes: Used by best-effort cleanup on a failed or cancelled upload }
separation_rationale: >
  A blob is not a row, and the cloud implementations are entirely different
  services with different consistency and pricing models.
```

---

## Contract ownership rules

- **The provider owns the spec.** `U6` owns C1; `U2` owns C2, C3 and C4. `U11`
  implements C2–C4 and may not change them — if an adapter cannot satisfy a port,
  the port is wrong and changes at its owner, not at the adapter.
- **C1's document is generated, never hand-maintained.** It is produced from the
  Pydantic models, and `U7`'s TypeScript types are generated from it and committed.
  The merge gate regenerates and **fails if the committed output is dirty**.
- **Breaking changes are caught, not negotiated.** There is no independently
  deployed consumer: one owner, one browser, one deployment, no remote. A backend
  rename breaks `tsc --noEmit` at the same gate, with a file and a line. No URL
  versioning, no deprecation window, no parallel schema support.
- **Additive changes stay safe** by the ordinary rule: consumers ignore unknown
  fields. The generated types make an addition visible without making it breaking.
- **The error envelope is a contract, not a convention.** It is ported, not
  designed, and `U9` depends on its exact shape.

## Open questions

| Contract | Question | Blocks |
|---|---|---|
| C2 | The Firestore composite index for the three-part revision order must be declared as a deployment artifact. Where does that definition live so it is not lost between the adapter and the plan? | U11, U12 |
| C2 | The Firestore large-payload path needs a size threshold and an orphan-sweep decision | U11 |
| C2 | The published-document cache interval — a **security** parameter, since a stale cache is an authorization defect for C1's media route rather than a performance issue | U4 (owner: `nfr-design`) |
| C1 | Whether the editor's multi-flag save state machine contains a rule rather than presentation state. If it does, part of it crosses into C1 as an operation | U9 (owner: `functional-design`) |

## Assumptions & Open Questions

- **[resolved, after a correction]** Whether the port contracts assume relational
  semantics Firestore lacks. Cross-document transactions, compare-and-set and
  multi-key ordering are all expressible; three obligations follow — keep the
  prune bounded, declare the composite index, and specify the prune as
  read-then-delete rather than as a SQL-shaped predicate.
  **The first version of this analysis wrongly concluded "no conflict"
  unconditionally.** Review finding R-01 identified a fourth, real
  incompatibility it had missed — Firestore's 1,048,576-byte per-document limit
  against FR4.6's 1,500,000-character ceiling — now resolved in C2 under
  `payload_size`. Recorded here rather than quietly amended: an analysis that
  concluded "no conflict" and was believed is worse than one never run.
- **[assumption]** Same-origin routing via a Next.js `rewrites()` entry is
  declarative configuration rather than a JavaScript backend-for-frontend, and is
  therefore permitted by the language boundary. Chosen because a cross-site
  session cookie is unreliable under third-party-cookie restrictions.
- **[assumption]** C1's field-level schemas are omitted here deliberately: they are
  generated from the Pydantic models, and duplicating them in this document would
  create a second definition that can drift from the authoritative one.
