# Discovered rules — chiku-website runtime-split migration

> **Admission standard for this file.** Only **hard constraints the human stated** appear here.
> Every rule below traces to the confirmed project description, a confirmed answer in an earlier
> stage, the composed scope file that the human approved, or a ruling the human gave at this
> stage's interview. Nothing in this file is an agent preference; preferences live in
> `team-practices.md`.
>
> That line is what keeps the two files apart, and it is load-bearing for the two rules added at
> the interview: the human ruled on the *prohibition* in each case, so the prohibition is here
> while the *mechanism* that satisfies it stays in `team-practices.md`.
>
> The `(affirmed <date>)` stamp is applied by `practices-promote` when the human affirms at the
> gate, so the rules are written bare here.

## Mandated

- ALWAYS keep every application decision in the Python FastAPI backend — authentication,
  authorization, authoritative validation, business rules, persistence, uploads and publishing all
  belong to the backend. [desc]
- ALWAYS reproduce the existing site's layout and content as-is when porting a page; accessibility
  and semantic markup may improve only where nothing moves visually. [Q — confirmed parity rule]
- ALWAYS preserve, in the new system, all public routes, the full owner editor
  (draft/publish, revision history, uploads, preview), seed content, branding, SEO metadata,
  JSON-LD, sitemap and robots, and the existing WebMCP `stage_academic_profile` browser tool.
  [desc]
- ALWAYS authenticate the site owner with a password verified against an argon2id hash, in a
  Python-owned session, replacing the ChatGPT platform header auth entirely. [desc]
- ALWAYS reach persistence through the narrow ContentStore / AssetStore port — SQLite plus a
  volume is the locally verified implementation; Firestore and GCS adapters are written against
  the same port. [desc]
- ALWAYS prefer a maintained public library over custom code (reuse-first). [desc]
- ALWAYS deliver a Dockerfile for each runtime plus a Compose file, and verify the containerised
  flow end to end. [desc]
- ALWAYS sequence Bolts dependency-first. [Q — confirmed]
- ALWAYS run the walking-skeleton Bolt first and gate it on explicit human approval before any
  remaining Bolt runs. [Q — confirmed; `skeleton: on` in the approved scope file]
- ALWAYS hold total recurring cost at zero. [Q — confirmed hard target]

## Forbidden

- NEVER place application logic in the Next.js frontend. It renders; it decides nothing. [desc]
- NEVER ship a default, seeded, sample or hard-coded credential. The site owner's credential is
  supplied at runtime through configuration and exists nowhere in the source tree. [Q — confirmed]
- NEVER provision a Google Cloud resource in this piece of work. Cloud work is plan-only: no
  project, no service, no bucket, no credential. [Q — confirmed; also recorded in the approved
  scope file as the reason the operation phase is skipped]
- NEVER introduce a paid, metered or otherwise recurring-cost component. [Q — confirmed, follows
  from the zero-cost target]
- NEVER change the visual layout or the content of an existing page while porting it. [Q —
  confirmed parity rule, stated as a prohibition because that is how it will be applied in review]
- NEVER hand-write a client-side validation rule, or a TypeScript type that mirrors a backend
  model. The browser may hold a mirror of the validation rules **only** when that mirror is
  generated from Python's OpenAPI document, so drift is impossible by construction; Python remains
  the authoritative validator in every case. [Q4 — confirmed at practices-discovery]
- NEVER carry a secret value through a Docker `ARG` or `ENV` instruction, and never bake one into
  an image layer. A build-time credential, if one is ever needed, uses a supported build secret
  mount so the value never lands in a layer. [desc — stated verbatim in the original brief]

## Sources

- `[desc]` — the verbatim project description recorded in
  `aidlc/spaces/default/intents/260924-chiku-website-migration/aidlc-state.md` → `**Project**`,
  which the human authored and confirmed at intent capture.
- `[Q — confirmed]` — answers the human gave and confirmed in `intent-capture` and
  `scope-definition`, carried into this stage's dispatch brief as established fact.
- `[Q4 — confirmed at practices-discovery]` — the numbered ruling the human gave in
  `practices-discovery-questions.md` at this stage's interview.
- `.claude/scopes/aidlc-runtime-split-migration.md` — the composed scope the human approved;
  authoritative for `skeleton: on`, `change_control: strict`, and the recorded reason the
  operation phase and `ci-pipeline` are skipped.

## Assumptions & Open Questions

- The zero recurring-cost target was stated for this project. It is recorded here as a project
  constraint; whether it generalises to every future intent in this space is **not** assumed. The
  interview did not put that question, so it remains open and the rule stays project-scoped —
  `project.md` rather than `team.md`.
- Rules already recorded in `aidlc/spaces/default/memory/project.md` are **deliberately not
  repeated** here, to avoid a duplicate at promotion. Specifically, the single-site-owner rule
  ("exactly one site owner edits chiku-website; do not reintroduce multi-editor accounts or tiered
  editor/publisher permissions") is already on disk under `## Corrections` and remains in force.
- The other seven interview rulings are **not** admitted to this file. They settle how this team
  works — methodology, coverage instrument and floors, parity verification, gate composition,
  advisory severity, when normalisation happens, and whether a remote exists — which is exactly
  what the five promoted sections of `team-practices.md` carry. Admitting them here would write
  team practice into `project.md`'s constraint lists and duplicate it.
- No rule in this file was derived from the existing code. Source-code observations are practice
  evidence, not human-stated constraints, and are recorded in `evidence.md`.
- Affirmed by the site owner at the practices-discovery gate on 2026-09-24, alongside
  `team-practices.md`. Promotion writes these two lists into
  `aidlc/spaces/default/memory/project.md` under `## Mandated` and `## Forbidden`.
