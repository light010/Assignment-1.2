# Unit Dependency Topology — chiku-website runtime-split migration

**Upstream:** `inception/units-generation/unit-of-work.md`,
`inception/domain-design/components.md`.

Topology only. This artifact names no build order and no critical path — those
are economic decisions made in Delivery Planning using this DAG as input.

## Edge block

```yaml
units:
  - name: source-fixtures
    kind: spec
    depends_on: []
  - name: storage-ports
    kind: library
    depends_on: []
  - name: identity-and-session
    kind: library
    depends_on: [storage-ports]
  - name: content-core
    kind: library
    depends_on: [storage-ports, source-fixtures]
  - name: media
    kind: library
    depends_on: [storage-ports, content-core, source-fixtures]
  - name: http-api
    kind: service
    depends_on: [identity-and-session, content-core, media, source-fixtures]
  - name: api-client
    kind: library
    depends_on: [http-api]
  - name: public-site
    kind: ui
    depends_on: [api-client, source-fixtures]
  - name: owner-editor
    kind: ui
    depends_on: [api-client, source-fixtures]
  - name: containers
    kind: packaging
    depends_on: [http-api, public-site, owner-editor]
  - name: cloud-adapters
    kind: library
    depends_on: [storage-ports]
  - name: deployment-plan
    kind: spec
    depends_on: [containers, cloud-adapters]
```

## Dependency graph

```mermaid
graph TD
  source-fixtures --> content-core
  source-fixtures --> media
  source-fixtures --> http-api
  source-fixtures --> public-site
  source-fixtures --> owner-editor
  storage-ports --> identity-and-session
  storage-ports --> content-core
  storage-ports --> media
  storage-ports --> cloud-adapters
  content-core --> media
  content-core --> http-api
  identity-and-session --> http-api
  media --> http-api
  http-api --> api-client
  http-api --> containers
  api-client --> public-site
  api-client --> owner-editor
  public-site --> containers
  owner-editor --> containers
  containers --> deployment-plan
  cloud-adapters --> deployment-plan
```

Text fallback: two units have no dependencies — `source-fixtures` and
`storage-ports`. `storage-ports` feeds the three backend libraries and the cloud
adapters. `source-fixtures` feeds everything whose correctness is defined by the
old system's behaviour. `http-api` sits above the three libraries and below the
generated client; the client feeds both frontends; `containers` needs the
service and both frontends; `deployment-plan` needs the containers (for measured
image sizes) and the cloud adapters. Twenty-one edges, no cycles.

## Why the fixture edges exist

Five units depend on `source-fixtures` even though the dependency is on **data**
rather than on code. [Q2] The reason is that this unit's capability expires: once
the source application is retired, its responses cannot be recorded again. Making
it a graph edge means a scheduler cannot place a characterization test before its
oracle exists — the constraint is enforced by topology rather than remembered from
a document.

`identity-and-session` deliberately does **not** depend on it: authentication is
entirely new, there is no prior behaviour to preserve, and a false edge would
misstate why the unit exists.

## Integration points

| From | To | Integration | Shape |
|---|---|---|---|
| identity-and-session, content-core, media | storage-ports | Three port interfaces | In-process calls against an interface, two adapter families behind it |
| content-core | storage-ports | The single combined compare-and-set write carrying content, revision entry and retention prune | One call, one transaction, one caller |
| media | content-core | Current published document for the asset-visibility test | In-process read, served from the cache content-core owns |
| http-api | identity-and-session, content-core, media | Every operation | Thin route handlers calling service operations; no store import |
| api-client | http-api | The OpenAPI document | Generated types, committed and regenerated at the gate |
| public-site, owner-editor | api-client | Typed operations over HTTP, same origin | Credentials and CSRF token attached by the client |
| containers | http-api, public-site, owner-editor | Two images and a Compose file | Frozen installs, digest-pinned bases, a named volume |
| cloud-adapters | storage-ports | The same three port interfaces | The same conformance suites, run against cloud implementations |
| deployment-plan | containers | Measured image sizes | Read from the built images, never estimated |

## Parallel development opportunities

Sets with no dependency between their members:

1. **`source-fixtures` ∥ `storage-ports`.** Both have no dependencies. They are
   also the two most different kinds of work — driving a legacy application
   versus designing an interface — so parallelism here is real rather than
   nominal.
2. **`identity-and-session` ∥ `content-core`** once `storage-ports` lands. They
   share only the port.
3. **`cloud-adapters` ∥ everything after `storage-ports`.** It depends on nothing
   else and nothing depends on it until `deployment-plan`. It can be built at any
   point or deferred to last without blocking anything.
4. **`public-site` ∥ `owner-editor`** once `api-client` lands. Both consume the
   same generated client and share presentation code, so this parallelism is real
   only if the shared code is settled first — noted as an assumption in
   `unit-of-work.md`.

More than one valid topological ordering exists. Choosing among them is Delivery
Planning's decision.

## Verification

Checked mechanically over the edge block: twelve units declared, each named once;
every name in a `depends_on` list is a declared unit; no unit depends on itself;
no cycles; every `kind` is one of the five permitted values. Twenty-one edges in
the block, twenty-one in the diagram.

## Assumptions & Open Questions

- **[assumption]** `cloud-adapters` depends only on `storage-ports`. If Contract
  Design finds the ports assume relational semantics Firestore does not offer,
  this unit gains a dependency on whatever resolves that — which is exactly why
  the question is raised before the adapters are written.
- **[assumption]** `deployment-plan` depends on `containers` for measured image
  sizes. If the Docker daemon were unavailable, the plan could still be written
  with its cost line explicitly marked unmeasured, but it would not satisfy NFR6.
- **[open, owner `delivery-planning`]** Which slice of which units the
  walking-skeleton Bolt cuts. The scope requires it to cross both runtimes and the
  container boundary; the depth of each slice is a sequencing decision.
