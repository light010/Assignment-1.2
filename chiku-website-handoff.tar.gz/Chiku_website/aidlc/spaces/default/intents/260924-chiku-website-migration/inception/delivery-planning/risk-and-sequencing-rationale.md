# Risk and Sequencing Rationale — chiku-website runtime-split migration

**Upstream:** `inception/delivery-planning/bolt-plan.md`,
`inception/units-generation/unit-of-work-dependency.md`,
`ideation/approval-handoff/initiative-brief.md`,
`inception/requirements-analysis/requirements.md`.

## The sequencing decision in one paragraph

Dependency-first, confirmed at scope definition. Within that constraint the order
is driven by one thing: **isolating silent failures**. Seven requirements are
hazard-marked — each fails with no error, no log and no failing check — and five of
them sit in two units. Putting those units in separate build passes means a failure
touches one gate rather than five behaviours at once.

## What each Bolt is really buying down

| Bolt | Risk it retires | If it fails |
|---|---|---|
| B1 skeleton | That the whole architecture is wrong — the language boundary, the session contract, the storage port, or the containers | Cheapest possible moment to find out. Nothing is built on it yet |
| B1 fixtures | That every parity claim rests on a human's reading of a document | **Unrecoverable if deferred.** The source app is retired eventually and its responses cannot be recorded again |
| B2 ports | That the port is really just SQLite with extra steps | Two implementations against one suite is what falsifies that |
| B3 auth | That the replacement for platform auth has a hole | Found before any content operation depends on it |
| B4 content | FR4.5 — a losing writer corrupting history; FR9.2 — a type-correct default breaking three features silently | Both are invisible to single-user testing and to coverage percentages |
| B5 media | FR6.2 — a parser accepting or rejecting the wrong bytes; FR7.2 — a "sensible" access rule 404-ing images referenced from prose | Both change visitor-visible behaviour without erroring |
| B6 API | FR10.1 — FastAPI's default error shape breaking the editor **while appearing to work** | Highest-probability silent regression in the migration |
| B7 public site | Visual and structural parity | DOM diff against B1's fixtures catches what eyes miss |
| B8 editor | That the owner loses a capability, or unsaved work | The third unreachable-backend state is the one nobody would have specified without ADR-006 |
| B9 containers | That it only runs on a developer's machine | No source mounts, no dev servers, durability across container recreation |
| B10 cloud | That the cost target is unprovable | Measured image sizes, every line traced to a current source |

## Risks carried into Construction

All eight risks from the initiative brief were accepted **with active mitigation**.
Where each now lands:

| # | Risk | Mitigated by |
|---|---|---|
| RK1 | Authentication is newly built | B3, with tests that call the API directly and bypass the frontend entirely |
| RK2 | Cloud adapters ship unverified | B10, labelled unverified in the README and the plan, held to the same conformance suites |
| RK3 | Zero-cost target unproven | B9 produces the images; B10 **measures** them. The rule that figures are measured and never estimated is already in `project.md` after an earlier estimate was wrong in exactly that way |
| RK4 | The cost condition was unmeasurable | Closed at requirements: NFR6 makes it a property of the plan document |
| RK5 | Parity across a double change — framework **and** runtime | B1's fixtures plus B7's DOM diff plus a human page-by-page pass |
| RK6 | No production content exists | Closed: the seed in `app/content.ts` is canonical per the original handoff, so no data migration is owed |
| RK7 | The upload and media path is intricate | B5, per-rule tests including the negative cases |
| RK8 | Container verification depends on the Docker daemon | Daemon is up. If it stops, B9's checks are reported **blocked**, never skipped |

## New risks this plan introduces

| Risk | Why it exists | Response |
|---|---|---|
| **B1 is load-bearing and large.** It touches eight units and carries four separate deliverables (fixtures, `.env.example`, pinned gate flags, the image-layer secret check) | A skeleton that proves the architecture must cross every layer, and the fixtures expire | Keep every slice genuinely thin. B1 completes no unit — if it starts completing one, it has stopped being a skeleton |
| **The merge-gate flag spellings are unverified.** None was executed | The gate was written, not run | B1 runs each one and pins the exact spelling. What was affirmed is the gate *entry*, not the flag string |
| **Nine gates carry verbatim output nobody independently checks** | Solo, no CI, no second reviewer | Accepted. It is the honest consequence of staying local, and it is why the output is pasted rather than asserted |
| **A Playwright dependency may appear late** | If the editor's multi-flag save state machine turns out to hold a rule rather than presentation state, a browser check becomes the only way to verify it | Owned by `functional-design`. Deciding it there, before B8, is what keeps it from being a surprise |

## What would change the sequence

- **A deadline.** There is none. One would push toward value-first and a
  deliberately thinner first cut.
- **A second person.** Opportunity 1 from `team-allocation.md` splits first.
- **`functional-design` moving editor state behind the API.** That would enlarge
  B6 and shrink B8.
- **A failing skeleton.** If B1 shows the boundary or the port is wrong, the
  remaining sequence is re-planned rather than continued.

## Assumptions & Open Questions

- **[assumption]** Hazard isolation is worth more than Bolt count here. With no
  deadline, the cost of ten passes instead of six is time; the cost of a shared
  gate is a silent defect reaching the owner's live site.
- **[assumption]** B1's fixtures can actually be recorded — the source application
  has not yet been booted in this workflow. If it cannot run, RK5's mitigation
  weakens to the written knowledge base and every parity claim weakens with it.
  This is the single largest unverified assumption in the plan.
