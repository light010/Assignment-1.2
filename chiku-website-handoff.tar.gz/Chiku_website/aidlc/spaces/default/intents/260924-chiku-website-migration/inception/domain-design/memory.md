<!-- INVARIANT: examples are single-line HTML comments so a fresh template parses to total=0 (MEMORY_EMPTY). Do NOT un-comment or split across lines. t100 guards this. -->
> This file is kept up to date automatically while the stage runs. Add observations at the review step, not by editing here directly.

## Interpretations
<!-- example: 2026-05-29T10:14:32Z — chose REST over GraphQL; the consuming team only needs CRUD, revisit if subscriptions land -->

- 2026-09-24T17:05:30Z — modelled the three storage ports as components with `entities: []` rather than as external_dependencies. The stage prose says infrastructure and databases are external dependencies and never components, and SQLite and Firestore are recorded exactly that way; but the port itself is application code with a contract and a conformance suite, so it is a component that has those databases as its external dependencies. Treating the port as infrastructure would have hidden the one interface the whole adapter strategy rests on.
## Deviations
<!-- example: 2026-05-29T10:14:32Z — skipped the optional caching layer the stage prose suggested; the dataset is small enough that it adds risk -->

- 2026-09-24T17:05:30Z — ADR-004 and ADR-005 were decided without putting them to the human, while ADR-001 to ADR-003 were asked. The line I drew: a boundary with two genuinely viable answers and a real cost on each side goes to the human; a boundary where the alternative loses on a concrete stated ground goes in the ADR with its rejection recorded. Splitting media intake from delivery loses because it would put an access-control rule and an input-validation rule in one module and both are hazard-marked; merging the frontend loses because it would make the boundary claim unverifiable.
## Tradeoffs
<!-- example: 2026-05-29T10:14:32Z — picked TDD over BDD this run; the team is unit-first and the domain is well-understood -->

- 2026-09-24T17:05:30Z — the atomicity of the content write plus its revision entry plus its retention prune is the design's weakest joint. ContentAuthority calls RevisionLedger, and both reach ContentStore, so a transaction has to span two components without either reaching into the other's persistence. ADR-001 records the fallback explicitly - if Contract Design cannot express that atomicity in the port signature, the two components merge rather than the guarantee weakening. Recording the fallback rather than pre-emptively merging keeps the boundary that testing wants, while making the failure mode a decision rather than a discovery.
- 2026-09-24T17:05:30Z — placed FR8.3's draft-recovery classification in OwnerEditor, a frontend component, even though it is a hazard requirement with a correctness rule. The justification is that it operates on browser-local state that never reaches the backend, so it is presentation state; the risk is that it reads as application logic on the wrong side of NFR1's boundary. Flagged to the reviewer as the single most important question in the review rather than asserted.
## Open questions
<!-- example: 2026-05-29T10:14:32Z — confirm the retention window with compliance before the next stage hardens the schema -->

- 2026-09-24T17:05:30Z — whether anything in the three port contracts assumes relational semantics Firestore does not offer: a transaction spanning documents, compare-and-set, or ordered pagination with multi-key tie-breaks. RevisionLedger's three-part sort is the specific worry. Owner: contract-design.