<!-- INVARIANT: examples are single-line HTML comments so a fresh template parses to total=0 (MEMORY_EMPTY). Do NOT un-comment or split across lines. t100 guards this. -->
> This file is kept up to date automatically while the stage runs. Add observations at the review step, not by editing here directly.

## Interpretations
<!-- example: 2026-05-29T10:14:32Z — chose REST over GraphQL; the consuming team only needs CRUD, revisit if subscriptions land -->

- 2026-09-24T16:00:39Z — six of the reviewers' recommendations had independent agreement from two or three of them (dense style left unformatted, Python strict from day one, no frontend coverage percentage, branch rather than line coverage, ports named for real things, the ruff security ruleset), so I adopted them and recorded the adoption in a visible table in the questions file instead of asking. Putting a converged expert recommendation to the human as an open choice is ceremony, but hiding that it was ever a choice is worse, so the table names each one and who agreed.
## Deviations
<!-- example: 2026-05-29T10:14:32Z — skipped the optional caching layer the stage prose suggested; the dataset is small enough that it adds risk -->

- 2026-09-24T16:00:39Z — I killed a working integration dispatch. My progress signal was artifact line counts, which cannot move for an agent that reads all its inputs before writing any output; after roughly thirty unchanged polls I concluded it was stuck and stopped it, and its final recorded thought was "Now I have everything. Writing the integrated team-practices.md." The wasted budget was mine, not the agent's. RULE: for a read-heavy dispatch, either brief it to write incrementally so file size becomes a real progress signal, or accept that no signal exists and wait for the completion notification rather than inventing one.
## Tradeoffs
<!-- example: 2026-05-29T10:14:32Z — picked TDD over BDD this run; the team is unit-first and the domain is well-understood -->

- 2026-09-24T16:00:39Z — briefed the three spokes to stay strictly in their own lane (testing, code style, security tooling) and told each one explicitly which areas belonged to the others. The cost is that no single reviewer formed a whole-document view; the benefit is that all three returned deep, specific, non-overlapping objections rather than three shallow passes over the same surface. The quality reviewer's demonstration that a type-correct hazard-3 port passes ruff, mypy, tsc, the Compose run AND 100% line coverage while shipping a broken site would not have emerged from a generalist review.
## Open questions
<!-- example: 2026-05-29T10:14:32Z — confirm the retention window with compliance before the next stage hardens the schema -->
