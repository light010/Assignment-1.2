# Practices Discovery — Interview

Upstream: the lead's draft (`team-practices.md`, `discovered-rules.md`,
`evidence.md`) and three independent blind reviews under `contributions/`.

## Adopted without asking — the three reviewers converged

These are recorded here so the silence is visible. Each was a real choice; each
had independent agreement from two or three reviewers, so asking would have been
ceremony rather than a decision.

| Choice | Adopted position | Who agreed |
|---|---|---|
| Dense house style on ported frontend files | Leave ported files byte-identical; write new code conventionally; no Prettier in this workflow | lead, developer, devsecops |
| Python style | `ruff format` + `ruff check` + `mypy` gating from day one — no legacy, so no trade-off | lead, developer, devsecops |
| Frontend coverage percentage | None. A percentage over a render-only layer measures JSX traversal, not behaviour | lead, quality |
| Coverage instrument | **Branch** coverage, not line — all three hazards are branches or `??` fallback chains that line coverage marks covered when only one side runs | quality, devsecops |
| Ports named for real things | `ContentStore`, `AssetStore` — never a generic repository abstraction | lead, developer |
| `ruff` security ruleset (`S`, flake8-bandit) | Enabled. Free, local, and this backend is the product's entire security surface | devsecops |

## Adopted from a reviewer objection, not from the draft

| Change | Raised by | Why adopted without asking |
|---|---|---|
| The merge gate must carry the **verbatim run output** — exit status, pytest summary, both coverage totals, Compose health — and gate approval is refused without it | quality | With no CI and no pull request, an unwitnessed gate is an assertion, not a check |
| The language boundary needs an **enforcement mechanism**, not an assertion: generated OpenAPI types, no storage credential in the frontend container, and a grep at the gate | developer | A rule nobody can check is a wish |
| FastAPI's default error shape (`{"detail": ...}`, Pydantic `loc`/`msg`) **silently breaks** the editor's field highlighting and conflict recovery while appearing to work | developer | This is a behavioural defect, not a preference |
| The four source routes' user-facing error strings are **product copy** and fall under the parity rule | developer | The draft treated parity as layout-and-content only, so nothing stopped the port rewriting them |
| The `camelCase` wire format is **fixed**, not chosen — by the ported components that read it and by JSON already persisted in the content columns | developer | A factual constraint, not a decision |
| `async` vs sync must be decided for a FastAPI backend wrapping a synchronous SQLite driver | developer | Event-loop blocking is invisible to every check on the gate list |
| Base-image digest pinning and a non-root container user | devsecops | Building an image is a supply-chain act even when nothing ships |
| `.npmrc`'s `audit=false` must not be inherited by accident during the port | devsecops | A suppression copied forward is a suppression nobody chose |
| The two vendored MIT notices must travel with the copied component files | devsecops | Attribution obligation |

---

## Q1. May I drive the OLD site and record its real responses as test fixtures, before writing any Python?

This is the one decision on this page with an expiry date.

Every "does the new system match the old one?" check currently rests on a human
reading a description of the old behaviour. The alternative is to run
`madhavi-tripathi/` locally, drive it over HTTP, and record what it actually
returns — routes, status codes, the 413 boundary, byte-range responses, and the
stored database state after save / publish / conflict — as golden fixtures the
Python tests assert against.

Cost: installing and booting the legacy Cloudflare-Workers app (pnpm install,
apply both SQL migrations to a local emulator database, run the dev server). It
uses a disposable local database and a test identity; nothing hosted is touched.

Once the old app is retired, this option is gone.

A. Yes — record golden fixtures from the running source app first. Spend the setup cost.
B. No — use the reverse-engineering knowledge base as the written oracle and skip the setup.
C. Yes, but only for the highest-risk surfaces (the API status codes, the 413 boundary, byte ranges, and the save/publish/conflict row state), not the whole site.
D. Not yet defined.
X. Other (please specify)

[Answer]: A. Yes — record golden fixtures from the running source app first. Spend the setup cost.

---

## Q2. Testing methodology — `test-after`, or `custom`?

The draft picked `test-after`, the framework default when nothing is affirmed.
The quality reviewer objected: the oracle predates the code here, so test-after
lets a misread source produce a matching implementation **and** a matching test
that both look right and are both wrong.

A. `custom` — characterization tests written FIRST for the hazard register and the storage port; test-after everywhere else.
B. `test-after` — implement, then write and run that layer's tests. Simpler to follow, one rule.
C. `tdd` — tests first everywhere.
D. Not yet defined.
X. Other (please specify)

[Answer]: A. `custom` — characterization tests written FIRST for the hazard register and the storage port; test-after everywhere else.

---

## Q3. How is "it still looks the same" actually verified?

The parity rule is a confirmed hard constraint with **no verification mechanism
attached**, which makes it currently unfalsifiable — a Bolt could be declared
parity-preserving on nobody's evidence. The lead called this the largest gap in
the draft; the quality reviewer recommends a normalised DOM-structure diff and
explicitly rejects pixel screenshots.

A. Normalised DOM-structure diff against recorded source HTML. Machine-checkable, ignores cosmetic noise, catches a dropped section or a changed heading level.
B. Per-route screenshot comparison against the running source app. Catches visual drift a DOM diff misses; brittle against fonts, antialiasing and animation.
C. Explicit page-by-page human review at the gate, recorded as a checklist.
D. Both A and C — machine diff plus a human pass at the end.
X. Other (please specify)

[Answer]: D. Both A and C — normalised DOM-structure diff against recorded source HTML, plus an explicit page-by-page human review at the end.

---

## Q4. May the frontend keep a non-authoritative copy of the validation rules?

The source runs one `zod` schema in **both** the browser and the server. The
language boundary says Python owns authoritative validation — but it does not say
whether the browser may keep a *mirror* purely for editor responsiveness.

Forbidding it means a network round trip to discover that a title is empty, and
an editor measurably worse than the one being replaced. Allowing it means two
definitions that can drift, and a boundary rule with an exception that will be
cited later to justify the next one.

A. Allow a generated mirror only — types and basic constraints generated from Python's OpenAPI document, never hand-written, so drift is impossible by construction.
B. Forbid any client-side validation. Python answers every validation question; the editor shows server-returned field errors.
C. Allow a hand-written client mirror for UX, documented as non-authoritative.
D. Not yet defined.
X. Other (please specify)

[Answer]: A. Allow a generated mirror only — types and basic constraints generated from Python's OpenAPI document, never hand-written, so drift is impossible by construction.

---

## Q5. Backend coverage floor and when the container end-to-end run happens

Two linked gate questions. `org.md`'s 80% floor is scoped to named stock scopes
and does **not** reach this custom scope, so there is no inherited number.

A. 80% branch coverage on the backend, plus a second scoped report requiring 100% on the hazard modules; Compose end-to-end on every Bolt merge.
B. 80% branch coverage plus the hazard report; Compose end-to-end only at the skeleton gate and at the end.
C. No percentage at all — per-branch tests on the hazard register only; Compose end-to-end on every Bolt merge.
D. Not yet defined.
X. Other (please specify)

[Answer]: A. 80% branch coverage on the backend, plus a second scoped report requiring 100% on the hazard modules; Compose end-to-end on every Bolt merge.

---

## Q6. Git remote — stay local, or push somewhere?

The workspace became a git repository today. It has `main`, no remote, and no
forge. `ci-pipeline` is skipped precisely because there is nowhere to run one.

A. Stay local. No remote, no pull-request gate, no off-machine backup. Nothing changes.
B. Add a remote. Off-machine backup and a pull-request gate become possible, and `ci-pipeline` becomes un-skippable later. A free private repository stays inside the zero-cost target.
C. Not yet defined.
X. Other (please specify)

[Answer]: A. Stay local. No remote, no pull-request gate, no off-machine backup.

---

## Q7. After parity is signed off, should the frontend be reformatted at all — or is the dense style permanent?

Raised by the developer reviewer, who read the actual files before judging.

The code scan adjudicated the extremely dense single-line style as **deliberate
house style, not defect**. The draft nonetheless pre-commits to normalising it in
one mechanical commit once parity is proven. That is a decision made by omission
about a style someone chose on purpose.

A. Keep the dense house style permanently. No later normalisation commit, no Prettier ever. "Two styles in one tree" is the settled end state, not a temporary cost.
B. Normalise after parity sign-off, as drafted — one mechanical formatting commit once tests exist to prove it changed nothing.
C. Normalise now, during the port. Accepts that a reformatted diff hides exactly the branches most worth checking.
D. Not yet defined.
X. Other (please specify)

[Answer]: B. Normalise after parity sign-off, as drafted — one mechanical formatting commit once tests exist to prove it changed nothing.

---

## Q8. Should the merge gate block on dependency advisories, and at what severity?

Raised by the security reviewer as the genuine fork for a solo developer with no
CI: a blocking High/Critical gate stops all work the day an unfixable transitive
advisory lands, while a non-blocking one becomes a notification nobody reads.

A. Block at High and above. An advisory with no fix available is recorded — package, advisory id, reason, and a named owning Bolt — and the gate proceeds on that record.
B. Block at High and above with no exception path. An unfixable advisory stops work until it is resolved or the dependency is replaced.
C. Advisory only — run the audit, print the result, never block.
D. Not yet defined.
X. Other (please specify)

[Answer]: A. Block at High and above. An advisory with no fix available is recorded — package, advisory id, reason, and a named owning Bolt — and the gate proceeds on that record.

---

## Consolidated Summary Confirmation

- Looks correct
- Request changes

[Answer]: Looks correct
