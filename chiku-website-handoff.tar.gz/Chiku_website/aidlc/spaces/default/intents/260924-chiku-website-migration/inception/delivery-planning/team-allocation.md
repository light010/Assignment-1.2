# Team Allocation — chiku-website runtime-split migration

**Upstream:** `inception/delivery-planning/bolt-plan.md`,
`inception/units-generation/unit-of-work.md`,
`ideation/intent-capture/stakeholder-map.md`.

## The team

**One person.** `team-formation` was marked SKIP by the composed scope for exactly
this reason: there is no team composition, capacity or mob plan to decide.

| Role | Who | Scope |
|---|---|---|
| Decision-maker | The workflow decision-maker | Sole authority over scope and priority, including content and branding. Reporting at approval gates only |
| Builder | The same person | Every Bolt |
| Site owner | The person whose content and identity the site carries | Uses the management interface. No approval authority over this work was established |

## Allocation

Every Bolt is allocated to the same person, executed **serially**. There is no
allocation decision to make; this document records that plainly rather than
manufacturing a matrix.

## Parallelism, recorded but unused

The dependency graph offers four genuine parallel opportunities. None is available
with one person, but they are the first thing that would change if a second joined,
so they are kept here rather than lost:

| Opportunity | Units | Why it is real |
|---|---|---|
| 1 | `source-fixtures` ∥ `storage-ports` | Both have no dependencies, and they are the two most different kinds of work — driving a legacy application versus designing an interface |
| 2 | `identity-and-session` ∥ `content-core` | After the ports land, these share only the port |
| 3 | `cloud-adapters` ∥ everything after `storage-ports` | Depends on nothing else; nothing depends on it until the deployment plan |
| 4 | `public-site` ∥ `owner-editor` | After the generated client lands — **but only if the shared presentation code is settled first**, which the Bolt plan resolves by sequencing the public site ahead of the editor rather than by running them together |

If a second person joined, opportunity 1 is the one to take first: it is the
largest genuine split and the two halves need almost no coordination.

## Capacity and cadence

No deadline was set, and correctness is preferred to speed at every decision
point. There is no sprint, no velocity target and no capacity model, because
none of them would be measuring anything.

## Assumptions & Open Questions

- **[assumption]** The workflow decision-maker and the site owner may be different
  people. It matters only if content or branding decisions later need a second
  party's approval, and the confirmed reporting answer says they do not.
- **[assumption]** Serial execution is a consequence of team size, not a
  preference. If that changes, the four opportunities above are the plan.
