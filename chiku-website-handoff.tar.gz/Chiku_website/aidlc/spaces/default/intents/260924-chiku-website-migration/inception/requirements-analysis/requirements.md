# Requirements — chiku-website runtime-split migration

**Upstream:** `ideation/intent-capture/intent-statement.md`,
`ideation/scope-definition/scope-document.md`,
`codekb/Chiku_website/business-overview.md`, `…/architecture.md`,
`…/code-structure.md`, `inception/practices-discovery/team-practices.md`.

## How to read this document

This is the **test oracle** for the migration. It is not a design and it does
not decide how anything is built.

Most requirements here are not new decisions. The parity rule — layout and
content reproduce as-is while accessibility and semantics may improve without
moving anything visually — means the existing system's behaviour *is* the
requirement. Where that is the case, the requirement states the behaviour and
cites the knowledge-base file that establishes it. Where a requirement could not
be read off the existing system, it is marked **[new]** and cites the confirmed
answer that decided it.

**Seven requirements are marked [hazard]**: FR4.5, FR6.2, FR7.2, FR7.4, FR8.3,
FR9.2 and FR10.1. Each is documented in
`codekb/Chiku_website/code-quality-assessment.md` § *Hazard index* as a
behaviour whose loss would ship a silent defect — no error, no log, no failing
check. Every hazard requirement carries a test per enumerated branch and falls
inside the 100% scoped coverage floor, per the affirmed testing posture. That
list is the definition of the floor's scope, so it is stated here explicitly
rather than left to be counted.

**FR4.4 is deliberately *not* a hazard.** Rejecting a write whose base revision
no longer matches is ordinary optimistic concurrency: it fails loudly, with a
conflict status the editor already handles. The silent risk lives one level
down, in the side-effect guard, which is why FR4.5 carries the marker and FR4.4
does not. Diluting the label would enlarge the coverage floor's scope without
enlarging the risk it exists to cover.

## Intent analysis

The goal is not a new website. It is the **same website, owned differently**:
portable off a single host, with every application decision made in Python so
later backend, worker and agent work has one home. A visitor should be unable to
tell the migration happened. The owner should lose no capability.

Success is the four conditions in the intent statement — behavioural parity, a
clean language boundary, containers proven end to end, and a reviewed cloud plan
with nothing deployed — plus the hard zero recurring-cost target.

## Functional requirements

### FR1 — Public website

- **FR1.1** `GET /` renders the published content. Server-rendered, not a client
  fetch, because metadata and structured data derive from the content.
- **FR1.2** The page renders every section the content enables, honouring the six
  section visibility toggles and hiding the news section when it has no items.
- **FR1.3** The hero, achievements, research, publications, journey, news,
  contact, Scholar-highlights and footer areas render with the same structure,
  ordering and text as the current system, from the same content document.
- **FR1.4** The three-dimensional research illustration renders, honours the
  content's `motion` flag, and offers its guided tour only after visitor input —
  never automatically.
- **FR1.5** Publication search, year filtering, sort (newest / oldest /
  most-cited / title) and the reset control behave as they do today, including
  the documented tie-breaks: missing citation counts sort last, ties break by
  newest year, and a selection with no recorded counts falls back to newest
  first. Filter state continues to appear in the URL.
- **FR1.6** The achievements and updates carousels behave as today, **except**
  that reaching an endpoint no longer drops keyboard focus to the document body.
  This is the one agreed user-visible behavioural change. [Q8 @ intent-capture]
- **FR1.7** Light and dark appearance follow the system preference until the
  visitor chooses, then persist that choice per device, resolve before first
  paint, and fall back correctly when storage is unavailable.
- **FR1.8** A content document that fails validation renders the existing
  "temporarily unavailable" page rather than an error.

### FR2 — Discoverability and metadata

- **FR2.1** Page title, description, canonical URL, Open Graph and Twitter card
  metadata are derived from the published content, as today.
- **FR2.2** A `ProfilePage` JSON-LD block is emitted, with `dateModified` when a
  publication date exists, and `<` escaped in the serialised output.
- **FR2.3** `GET /sitemap.xml` returns the single canonical URL with
  `lastModified` set to the publication timestamp when one exists.
- **FR2.4** `GET /robots.txt` allows `/` and disallows `/edit` and `/api/`, and
  links the sitemap.
- **FR2.5** The site origin used in canonical URLs, Open Graph and the sitemap is
  **configuration, not a source literal**. The current system hard-codes it.
  **[new]** — required by the construction rule against hard-coded
  environment-dependent values.
- **FR2.6** Management pages are excluded from indexing, and that exclusion is
  never the only thing protecting them. Access is enforced independently in
  Python.

### FR3 — Authentication and session

- **FR3.1** The owner signs in with an email and password. The password is
  verified against an **argon2id** hash. **[new]** — replaces platform header
  identity, which does not exist off the original host.
- **FR3.2** A successful sign-in issues a signed session cookie with `HttpOnly`,
  `Secure` and `SameSite=Lax`. **[new]**
- **FR3.3** The session expires after **8 hours idle**, sliding within that
  window, and **7 days absolute** regardless of activity. **[new, Q2]**
- **FR3.4** Sign-out invalidates the session server-side, not only in the browser.
- **FR3.5** Failed sign-in is rate limited to **5 attempts per account per 15
  minutes** and **20 per IP per 15 minutes**. The failure message is generic and
  reveals nothing about whether an account exists. **[new, Q5]**
- **FR3.6** Exactly one owner account exists. No multi-editor accounts, no tiered
  editor/publisher roles. [project.md § Corrections]
- **FR3.7** The initial owner is provisioned at runtime through configuration.
  **No default, seeded, sample or hard-coded credential exists anywhere in the
  source tree.** A fresh start against empty storage has no account anyone can
  sign in to. [discovered-rules.md § Forbidden]
- **FR3.8** Every protected read and every mutation is authorised in Python at
  its own operation boundary. A hidden button, a protected layout or a frontend
  route rule is never the enforcement. A request that bypasses the frontend
  entirely is rejected identically.

### FR4 — Content read and write

- **FR4.1** The authenticated owner can read the full content state: the draft,
  the published document, the current revision number, the update and publication
  timestamps, and whether unpublished changes exist.
- **FR4.2** The owner can save a draft, and can publish, which sets the published
  document to the saved content.
- **FR4.3** Every write is validated authoritatively in Python before it is
  persisted. Validation failure returns the field-level issues the editor
  displays, not a generic message.
- **FR4.4** Writes use optimistic concurrency on the revision number. A write
  whose base revision no longer matches is rejected with a conflict, the caller's
  edits are preserved, and the current state is returned so the caller can
  reconcile. *(Not a hazard: this failure is loud and the editor already handles
  it. See the hazard note above.)*
- **FR4.5** **[hazard]** The conflict guard protects the **side effects** as well
  as the content write. The history insert and both retention deletes are gated
  on a token unique to the writing request, not on the resulting revision number
  — because the resulting revision number is *not* unique to the writer. Without
  this, a losing writer inserts a history row carrying the winner's content under
  its own action, and prunes revisions it had no right to prune. This failure is
  timing-dependent and invisible to single-user testing.
- **FR4.6** A save request whose body exceeds **1,500,000 characters** of decoded
  text is rejected with the existing too-large response. The limit counts
  characters, not bytes, matching the original exactly so that no document the
  current system accepts is rejected. [Q3]
- **FR4.7** An unparseable or malformed request body is rejected as a bad
  request, distinctly from a validation failure.

### FR5 — Revision history

- **FR5.1** The owner can list recent revisions — id, revision number, action
  (draft or publish), creation time, and whether the entry is a starting
  baseline — capped at the current limit. The ordering is a **three-part sort**,
  not simply "newest first", and the tie-breaks are load-bearing for what the
  owner sees: revision number descending, then non-baseline entries before
  baseline entries, then publish entries before draft entries. A port that
  sorted on revision number alone would list a tied revision in a different
  order while passing any test written from a looser wording.
- **FR5.2** The owner can fetch one revision's full content by id, and restore it
  into the editor for review. Restoring does not publish.
- **FR5.3** Retention is preserved exactly: the most recent 30 draft entries and
  20 publish entries are kept, and the two starting baselines are kept
  permanently.
- **FR5.4** A revision id that is absent or no longer retained returns a
  not-found response that states the current draft is unaffected.

### FR6 — Uploads

- **FR6.1** The owner can upload JPEG, PNG, WebP, PDF, MP4, WebM and WebVTT
  files. No other type is accepted.
- **FR6.2** **[hazard]** Type is determined by inspecting the file's own bytes,
  not by its declared type or extension. The accept/reject decision for each
  format must match the current system's, including its endianness handling —
  PNG and JPEG are big-endian, every WebP field is little-endian, and JPEG stores
  height before width.
- **FR6.3** Size limits are preserved: 50 MB for video, 10 MB for images and
  PDFs, 1 MB for caption files, with the existing pre-check on the declared
  content length.
- **FR6.4** A WebVTT upload must be valid UTF-8, begin with the `WEBVTT` header,
  contain at least one well-formed timed cue with end after start, and contain no
  embedded markup of the blocked kinds.
- **FR6.5** Responsive image variants are generated **server-side in Python**
  from the uploaded original. The browser no longer prepares variants.
  **[new]** — moves image processing across the language boundary and removes the
  "verify the browser's prepared variants" surface entirely.
- **FR6.6** A failed or cancelled upload leaves no orphaned stored object and no
  orphaned record. Cleanup is best-effort and never masks the original error.
- **FR6.7** Upload requires both an authenticated owner and a matching request
  origin.

### FR7 — Media serving

- **FR7.1** Media is addressed by an opaque key matching the existing pattern.
  A key that does not match is not found.
- **FR7.2** **[hazard]** An asset is publicly readable **if and only if** the
  literal media path for its key appears anywhere in the serialised published
  document — including inside a transcript, the biography, any description, the
  notice, or any editable copy block. This is preserved exactly; a structured
  field check would make strictly fewer assets public and would 404 images
  referenced from prose. [Q4]
- **FR7.3** A non-public asset is served only to the authenticated owner, and is
  reported as not found rather than forbidden, so the response does not reveal
  that the key exists.
- **FR7.4** **[hazard]** Range handling is preserved branch for branch. The
  standards-compliant implementation is *not* the requirement; the existing one
  is. Specifically:
  - **FR7.4.1** A `HEAD` request **always** returns 200 with the full content
    length and **never inspects the range header**. It never returns partial
    content or range-not-satisfiable, even where the equivalent `GET` would.
    `HEAD` and `GET` must not share range logic.
  - **FR7.4.2** Conditional-range handling is honoured: a conditional range whose
    validator does not match the current entity causes the range to be ignored
    and the whole entity returned.
  - **FR7.4.3** There is **no** not-modified path. An entity tag is emitted, but
    a matching conditional-get request is **not** answered with 304 — every
    request is a full transfer. This is a deliberate preserved behaviour, not an
    omission to be corrected.
  - **FR7.4.4** A range header requesting **more than one range** is rejected as
    not satisfiable. It is neither answered with the whole entity nor with a
    multipart response.
  - **FR7.4.5** Any range against a **zero-byte** object is rejected as not
    satisfiable.
  - **FR7.4.6** A **suffix range larger than the object** returns partial content
    for the whole object, not the whole object as a 200.
  - **FR7.4.7** A range whose **start is at or beyond the object size** is
    rejected as not satisfiable, while a range whose **end exceeds the object
    size is silently clamped** to the last byte and served as partial content.
    The asymmetry is intentional and must be reproduced.

  A port that added a not-modified path, or let `HEAD` reuse `GET`'s range
  logic, would satisfy the phrase "existing semantics" while silently changing
  what visitors and video players receive. That is why this is enumerated rather
  than summarised.
- **FR7.5** Responses carry the existing protective headers: no content-type
  sniffing, a restrictive content policy, and private cache control.
- **FR7.6** The published document consulted by FR7.2 may be cached in-process
  for a short interval. The cache changes **which requests hit storage**, never
  **which assets are public**, and a publish invalidates it. [Q4]

### FR8 — The owner editor

- **FR8.1** Every editing surface that exists today exists after the migration:
  profile, highlights, research, publications, journey, notes and news, the
  three-dimensional story, Scholar highlights, website text, and appearance.
- **FR8.2** Drafts autosave after a short idle period, and autosave is suspended
  while an upload is in flight, while a conflict is unresolved, and while a
  recovered draft is awaiting the owner's decision.
- **FR8.3** **[hazard]** Unsaved work is kept in browser storage per editor tab,
  under a key unique to that tab, so a second tab opened cleanly never clears
  another tab's unfinished work. On restore, the recovered draft is classified
  by the **kind** of validation problem it carries:
  - **FR8.3.1 Recoverable — offer the draft to the owner.** A value that is
    present and of the right type but outside its permitted set or range: a
    string shorter or longer than allowed, a number out of range, a value
    failing a format or custom check, **and a value outside an enumerated set**
    (accent colour, research topic, the 3D scene's initial view). These are
    exactly the states an owner produces by typing, so the draft is kept,
    repaired against schema defaults, and presented for review.
  - **FR8.3.2 Not recoverable — discard the draft.** A malformed record: wrong
    JSON shape, a field of the wrong type, a missing required structure, or a
    stored blob that is not parseable at all. These indicate corruption rather
    than in-progress editing.
  - **FR8.3.3** The current implementation misclassifies the enumerated-value
    case as not recoverable — its allowlist names a validation code the installed
    validator never emits, and omits the one it does — so a single bad enum
    discards the owner's entire recovered draft. **The port implements FR8.3.1
    and FR8.3.2 as written above, not the current behaviour.** [Q1]
  - **FR8.3.4** Restoring a recovered draft pauses autosave until the owner
    explicitly saves, so recovery never silently overwrites the stored draft.
- **FR8.4** The owner is warned before leaving with unsaved changes, an upload in
  flight, or a save in progress.
- **FR8.5** A conflict pauses autosave, preserves the owner's edits, and offers
  loading the latest draft and then choosing whether to restore the local edits.
- **FR8.6** A private draft preview renders the unsaved draft using the visitor's
  presentation, in an isolated frame, and is never indexed.
- **FR8.7** Image focal-point controls, alternative text, captions and transcripts
  are editable as today, including their keyboard operation.
- **FR8.8** The existing browser tool integration is preserved: when the browser
  exposes the capability, the editor registers a tool that stages the six profile
  text fields into the form. It validates field names and lengths, **never saves
  and never publishes**, and its results surface in the editor UI.
- **FR8.9** Client-side validation exists for responsiveness only, is **generated
  from the backend's schema document**, and is never hand-written. Python remains
  the authoritative validator for every request. [discovered-rules.md § Forbidden]

### FR9 — Content model

- **FR9.1** The content document preserves every field, constraint, default,
  maximum length and refinement of the current schema. The knowledge base's
  schema section is the authoritative enumeration.
- **FR9.2** **[hazard]** Two fields are **content-carrying defaults, not empty
  defaults**. A research item with no explicit topic resolves through the
  original topic map and otherwise to the general topic; an item with no explicit
  research links resolves through the seeded link map. A type-correct port that
  defaults these to null and an empty list is behaviourally wrong and silently
  breaks research card identity, related-paper counts and the publications topic
  filter. An explicitly emptied list must be preserved as empty, not re-filled.
- **FR9.3** The seeded content is carried across byte-for-byte in meaning: five
  publications, three research themes, three achievements, four journey entries,
  four news items, the Scholar highlights, and all nine editable copy blocks.
- **FR9.4** The wire format stays `camelCase`. This is inherited, not chosen:
  ported components read it directly and the persisted content *is* that JSON, so
  renaming it would also be a data migration. Conversion happens in exactly one
  place in Python.

### FR10 — Errors

- **FR10.1** **[hazard]** The API's error envelope is preserved exactly: a single
  message field, plus field-level issues on validation failure, across the
  existing status codes. The editor branches on the conflict status and reads the
  issues array; a different shape breaks field highlighting and conflict recovery
  **while appearing to work**.
- **FR10.2** The user-facing error strings are **product copy** and fall under the
  parity rule. A port that rewrites an error sentence has changed what the owner
  sees.
- **FR10.3** Errors at integration boundaries are surfaced or logged, never
  swallowed, and recoverable is distinguished from fatal at the wire level.

## Non-functional requirements

- **NFR1 — Language boundary.** No application logic in the frontend: no server
  actions, no API route handlers, no authentication middleware, no direct
  storage or provider access. Enforced by generated types, a gate check for
  forbidden constructs, and a test asserting route modules never import a store.
- **NFR2 — Authorisation independence.** Every protected operation authorises
  itself. Verified by tests that call the API directly, bypassing the frontend.
- **NFR3 — Durability.** Content, revisions, accounts and media survive container
  recreation. Verified by recreating the runtime container and re-reading.
- **NFR4 — Containers.** Both images build and run non-root, with locked
  dependencies, health checks, graceful termination, configurable listen address
  and port, and no development server. Verified without source mounts.
- **NFR5 — Secrets.** No secret in the source tree, in an image layer, or in a
  build argument. A missing session signing key is a startup failure with a named
  variable, never a default and never an auto-generated per-process value.
- **NFR6 — Cost.** Zero recurring infrastructure charges. Because nothing is
  deployed in this scope, this is verified as a property of the **plan**: every
  line item traces to a current official free-tier source, and the architecture
  requires no paid storage. Container image sizes are **measured**, never
  estimated. *(This closes reviewer finding R-02 from intent capture.)*
- **NFR7 — Accessibility.** Keyboard navigation, visible focus, semantic markup,
  labels, contrast and reduced-motion support on every changed interface.
  Improvements are permitted only where nothing moves visually. No conformance
  claim is made beyond what is tested.
- **NFR8 — Content freshness.** A publish becomes visible to a visitor without a
  rebuild and without a manual step. Any caching introduced has an explicit
  invalidation path.
- **NFR9 — Testability.** Characterization tests precede implementation for every
  hazard requirement and for the storage port. 80% branch coverage on the backend;
  100% scoped coverage over the hazard modules; a test per enumerated branch.
- **NFR10 — Parity evidence.** Parity is demonstrated by a normalised
  DOM-structure diff against recorded source responses, plus a page-by-page human
  review. Recording those responses from the running source system is a
  prerequisite and **expires when that system is retired**.
- **NFR11 — Privacy of the private.** No draft content, no unpublished media and
  no account data appears in any public response or in any public build output.

## Constraints

- **C1** Next.js renders only; a single cohesive Python backend owns everything
  else. Not two backends, not microservices.
- **C2** Google Cloud is plan-only. No provisioning, no deployment, no billing
  change.
- **C3** `madhavi-tripathi/` stays intact as reference and rollback baseline, and
  nothing in the new system imports from it at runtime.
- **C4** Reuse before building: maintained libraries over custom infrastructure,
  with custom work reserved for the content model, business rules, branding and
  integration gaps.
- **C5** No git remote. The local merge gate is the only enforcement point.
- **C6** Frontend files port byte-identical except imports and the rewired data
  call, or are listed as modified and reformatted wholesale.

## Traceability

| Success condition | Requirements |
|---|---|
| S1 Behavioural parity | FR1, FR2, FR4–FR10, NFR7, NFR8, NFR10 |
| S1 — the owner's half: "can still edit and publish everything she can edit and publish today" | FR3.1–FR3.7 (sign-in is a precondition of every editing capability: without password auth, session issuance and expiry, sign-out invalidation, rate limiting, the single-owner constraint and initial-owner provisioning, there is no owner to edit at all), FR8 |
| S2 Clean language boundary | FR3.8, FR4.3, FR8.9, NFR1, NFR2 |
| S3 Containers proven end to end | NFR3, NFR4, NFR5 |
| S4 Reviewed cloud plan, nothing deployed | NFR6, C2 |
| Hard zero recurring cost | NFR6 |

FR3.1–FR3.7 are the only requirements that are wholly **[new]** rather than
preserved, because the system being replaced had no authentication of its own —
it read an identity the host injected. They trace to S1 as its precondition
rather than to a condition of their own.

## Assumptions & Open Questions

- **[assumption]** The knowledge base's enumeration of the content schema is
  complete. It was derived from a single dense source file, and a missed
  constraint becomes a silent behaviour change. The recorded source responses
  (NFR10) are the safety net.
- **[assumption]** Recording responses from the running source system is possible
  — it has not yet been booted. If it cannot run, FR9.1 and NFR10 fall back to the
  written knowledge base and every parity claim weakens accordingly.
- **[open, owner `domain-design`]** Whether the editor's multi-flag save state
  machine lands in the frontend or the backend. If frontend, a browser-driven
  check becomes the only possible verification of FR8.2 and FR8.5.
- **[open]** FR7.6's cache interval is unset. It trades staleness for cost and
  belongs to `nfr-design`.
- **[assumption]** Reviewer findings R-01, R-03, R-04 and R-05 from intent
  capture were accepted unfixed. R-03's substance — that parity must name the
  metadata, structured data, sitemap, robots and browser-tool targets — is
  addressed here by FR2 and FR8.8. R-01, R-04 and R-05 remain open against the
  intent statement and still have no owner stage.
