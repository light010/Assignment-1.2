**Collaborator:** aidlc-developer-agent

## Contribution

I read the draft, `evidence.md`, `code-structure.md`, and then opened
`app/content-persistence.ts`, `app/site.tsx`, `app/edit/editor.tsx`, `app/server.ts`,
`app/api/content/route.ts`, `app/edit/editor-workflow.ts` and `app/edit/upload-field.tsx`
directly, because the dense-style question cannot be judged from a description of the style.

The draft's `## Code Style` section is the strongest reasoning in the document and the weakest
on mechanism. Every rule in it is stated as an intention that no command can check. Four things
are missing outright: how the language boundary is enforced, what the error envelope is, where
`snake_case` becomes `camelCase`, and what a Python module actually contains. Below, in the
order the section should read.

### 1. The dense-style call is right; the rule as written cannot be checked

The lead picked option three — leave ported code as-is, write new code to the new standard,
normalise later in one mechanical commit. **That is the correct call and I would defend it.**
The evidence is stronger than the draft claims, because the draft argues it from byte counts and
the real argument is positional. `content-persistence.ts:35` is one line holding the optimistic
UPDATE with two `CASE WHEN` branches and **eight positional bind parameters**:

```
.bind(serialized,publish,serialized,input.now,publish,input.now,input.mutationId,input.revision)
```

Translating that to a parameterised Python statement is an exercise in getting eight positions
right, and a line-for-line diff against the original is the only cheap way to check it. Reformat
that line into eleven and the check becomes a reading exercise. Same at `site.tsx:27`, where a
whole conditional `ResponsiveImage` render with eleven props plus its fallback branch sits on
one line: reformatting produces a diff that is 100% noise for a file that should be 0% change.

What does not work is the boundary rule:

> Where a ported file must be edited […] the edited region is written conventionally and the
> untouched regions are left alone.

This mandates **intra-file** style mixing, which is worse than the inter-file mixing the draft
accepts, and "untouched region" is not a property any tool can evaluate. Nobody can review it
and nobody can check it. Make the **file** the unit and make the invariant executable — the
source tree stays in the repository, so `git diff --no-index` is available at zero setup cost:

> **Proposed replacement for that bullet.** A ported frontend file is in one of exactly two
> states. **Unmodified**: byte-identical to its `madhavi-tripathi/` original except for import
> specifiers and the rewired data-access call, and it keeps the dense style entirely.
> **Modified**: listed in `chiku-website/frontend/PORTED-MODIFIED.md` with one line saying what
> changed and why, and the whole file is then formatted conventionally — not the edited region.
> The merge gate runs `git diff --no-index madhavi-tripathi/app/<f> chiku-website/frontend/app/<f>`
> for every file **not** on that list and fails if any hunk is not an import or a data-access
> call. New frontend files and all Python are conventional from the first line.

This converts the whole of D4 from a promise into a command, and it shrinks D8 as a side effect:
a byte-identical render component given the same props cannot render differently, so visual
parity risk concentrates in the modified list plus the CSS, which is a page set small enough for
a human to review by eye. I am not proposing a verification mechanism for D8 — only noting that
this rule makes the D8 surface a listed set rather than the whole frontend.

One caveat the draft should absorb: two files **cannot** be unmodified. `server.ts:5` hard-codes
`OWNER_EMAIL='madhavi.tri16@gmail.com'` and `site-metadata.ts:5` hard-codes `siteOrigin`. Both
are environment-dependent literals in source; the construction-phase rules forbid carrying that
pattern into the new backend. They go on the modified list on day one.

### 2. One mechanism that enforces the boundary and settles naming at once

The draft asserts the boundary ("the frontend must contain no application logic") and never says
what stops it. A rule nobody can check is a wish. Three mechanisms, cheapest first:

1. **Generate the frontend's types from the backend's OpenAPI schema.** `openapi-typescript`
   against the running backend's `/openapi.json`, output committed, regenerated in the merge
   gate and the gate fails if the output is dirty. This makes the wire contract single-authored
   (the Pydantic models), and it makes the boundary **type-checked rather than asserted** — a
   backend field rename fails `tsc --noEmit` in the frontend, at the gate, with a file and a
   line. It is also the answer to naming: see below.
2. **The frontend container gets no storage credential.** Not a code rule — an environment fact.
   The frontend image's environment contains the backend base URL and nothing else. A boundary
   enforced by the absence of a secret cannot be violated by accident, and this one costs
   nothing to implement because the Compose file has to be written anyway.
3. **A grep in the merge gate**, three lines, no dependency: fail if `chiku-website/frontend`
   contains any `'use server'` directive, any `app/**/route.ts`, or any `middleware.ts`. An
   ESLint `no-restricted-syntax` rule is a nicer editor experience but the grep is the one that
   is certain, so make the grep the gate and treat ESLint as optional.

On the Python side the equivalent is a boundary test, not a tool: one pytest that walks the AST
of `routers/` modules and asserts none of them imports a `store` module or `sqlite3`. Ten lines,
no new dependency, and it fails on the commit that breaks the layering rather than at review.
`import-linter` with a layers contract does the same job more generally if the team prefers a
dedicated tool; I would start with the pytest.

### 3. Naming across the boundary — currently absent, and the wire format is not a free choice

The draft says "`camelCase` for values" for TypeScript and "PEP 8 `snake_case`" for Python, and
stops there. That leaves the most consequential naming decision in the migration unstated, and a
developer reading only this document would reasonably ship `snake_case` JSON.

The JSON wire format is **frozen**, for two independent reasons. First, ported components read
it directly and unchanged — `site.tsx` reads `c.scholarHighlights`, `c.publications[].featured`,
`focalX`/`focalY`; the editor reads the same shape. `snake_case` JSON turns "components port
largely unchanged" into a rename sweep across the entire frontend, which voids §1 for every file
it touches. Second, the persisted content **is** that JSON: `normalizeStoredContent()` parses the
stored `draft`/`published` columns through the same schema, so a wire rename is also a data
migration. The existing code already performs exactly one conversion, in one place — `stateFromRow()`
maps `row.updated_at` → `updatedAt`, `row.published_at` → `publishedAt` — and the port should
reproduce that discipline rather than rediscover it.

> **Proposed new bullet under `### Python (backend)`.** **Naming across the boundary.** Python
> identifiers are `snake_case` everywhere, including storage columns. The JSON wire format is
> `camelCase` and is **inherited, not chosen** — it is the shape ported frontend components read
> and the shape already persisted in the content columns. Conversion happens in exactly one
> place: a shared Pydantic `BaseModel` with `alias_generator=to_camel` and
> `populate_by_name=True`, from which every request and response model inherits. No hand-written
> mapping, no `camelCase` identifier in Python, no `snake_case` key on the wire. The frontend's
> TypeScript types for these payloads are generated from the backend's OpenAPI schema and
> committed; hand-writing a type that mirrors a backend model is forbidden, because a
> hand-written mirror is the only way this can drift.

That last clause is also the answer to `evidence.md`'s client-side-validation question: a
generated mirror cannot drift, a hand-maintained one will. Note that the source already returns
per-field errors from the server (`result.issues` → `setIssues` in `editor-workflow.ts:60`), so
the "every field error needs a round trip" cost described there is smaller than stated — that
path exists and works today.

### 4. Error handling — a subsection the draft does not have

Neither runtime has a stated error rule, and the FastAPI defaults are actively wrong here. All
four source routes share one envelope — `{error: '<sentence>'}`, plus `issues: [{path, message}]`
on validation failures — with statuses 400 / 403 / 409 / 413 / 503. The frontend is built on that
envelope: `editor-workflow.ts` branches on `409` to enter conflict recovery, reads `result.issues`
to highlight fields, and falls back to `result.error` for the message.

FastAPI's defaults return `{"detail": ...}`, and Pydantic's validation errors use `loc`/`msg`
rather than `path`/`message`. Ship the defaults and the editor still "works": every error
collapses to the generic fallback string, field highlighting stops, and conflict recovery is
never entered. Nothing fails loudly. This is the highest-probability silent regression in the
migration and it is a five-line fix if it is written down now.

A further point the draft misses: **those error strings are product copy, not developer strings.**
"Your changes could not be saved. They are still in the form." — "Your current draft is
unchanged." — "Upload failed. Please try again; your form changes are safe." They are
user-visible content, so the parity rule covers them. A Python port that writes its own error
text changes content the human said reproduces as-is.

> **Proposed new subsection, `### Error handling (both runtimes)`.**
>
> - **One envelope, one author.** Every non-2xx backend response is
>   `{"error": "<one user-facing sentence>"}`, optionally with
>   `"issues": [{"path": [...], "message": "..."}]`. It is produced by exception handlers
>   registered on the app in `main.py` — never assembled inside a route handler. FastAPI's
>   default `HTTPException` and `RequestValidationError` handlers are **both overridden**;
>   leaving either in place ships `{"detail": ...}` and silently breaks the editor's field
>   errors and its conflict recovery.
> - **Error text is ported, not rewritten.** The user-facing sentences in the four source route
>   handlers are content under the parity rule. Port them verbatim, one table, reviewed once.
> - **A four-member taxonomy, mapped once.** `NotAuthorized` → 403, `Conflict` → 409,
>   `TooLarge` → 413, `Invalid` → 400 (carries `issues`); anything else → 503 with
>   `logger.exception()`. 503 rather than 500 matches the source. Services raise these; routers
>   never construct a status code.
> - **Recoverable versus fatal is a wire-level distinction.** 409 and 400-with-issues are
>   recoverable and the frontend must keep its specific handling for each; 503 is retryable with
>   the user's edits preserved. An HTTP client that collapses these into one thrown `Error`
>   deletes the conflict-recovery UX without failing any check — so it is named here as a rule.
> - **Swallowing is a lint failure, not a review comment.** `except Exception` is permitted in
>   exactly one place, the handler in `main.py`, and must log. Everywhere else, ruff `BLE001`
>   and `S110` are on and blocking. Never log content bodies or the owner's identity.
> - **The frontend calls `fetch` in exactly one module** (`lib/api-client.ts`), which returns
>   either data or a typed failure carrying `status` and the envelope — it never throws a bare
>   network error, and callers branch on the status. **Exception**: media upload keeps
>   `XMLHttpRequest` (`upload-field.tsx`), because upload progress and mid-flight abort are
>   load-bearing UX and are not expressible through the shared client. Say so explicitly, or an
>   over-literal reading of the one-client rule will delete the progress bar.

### 5. Python conventions — D9 is not low stakes, and the draft contradicts itself

The draft states that for Python "we take the strictest reasonable defaults from day one and
there is nothing to trade off", then defers strictness to D9 and calls it "low stakes". Both
cannot be true. As written, two developers do not produce the same Python: ruff's default
`check` select list is `E4,E7,E9,F`, which is close to nothing; **import sorting is not on by
default** (`I` must be selected), so "import ordering" is literally unspecified and will differ
per file; `mypy` without `strict` leaves untyped function bodies unchecked, which on a
new-code-only backend is a choice nobody would defend if asked.

> **Proposed replacement for the `### Python (backend)` bullet list.**
>
> - **Formatter**: `ruff format`, line length **100**, enforced by `ruff format --check`.
>   (`org.md` names Black as the Python default but explicitly defers to project configuration;
>   `ruff format` is Black-compatible output from the tool already in the gate, so this is a
>   project configuration under that deferral, not a departure from it. 100 rather than the
>   default 88 because parameterised SQL strings and FastAPI signatures wrap badly at 88.)
> - **Linter**: `ruff check`, configured in `pyproject.toml`, `select = ["E","F","I","UP","B",
>   "ASYNC","S","BLE","A","C4","SIM","TID","RUF"]`, no blanket per-file ignores. `I` gives one
>   import order with no argument; `ASYNC` and `BLE` are the two that catch real defects here.
> - **Types**: `mypy --strict`, no `ignore_missing_imports` blanket. Decide it now, not at D9 —
>   the draft's own reasoning ("no legacy, no parity obligation") is the argument for strict, and
>   retrofitting strict later costs far more than starting with it.
> - **Python 3.14 idiom**: built-in generics and `X | None`, never `typing.Optional`/`List`;
>   `from __future__ import annotations` is unnecessary and should not appear. (`UP` enforces.)
> - **`async` is the default for every route handler and every adapter method.** This is a
>   correctness rule, not a taste one: a blocking call inside `async def` blocks the event loop
>   for every concurrent request, and nothing reports it. Where the driver is synchronous
>   (`sqlite3`), the **adapter** wraps it in `anyio.to_thread.run_sync`; a handler or service
>   never calls a blocking API directly. A handler written `def` instead of `async def` is a
>   deliberate, commented exception.
> - **Configuration**: exactly one module (`settings.py`, `pydantic-settings`) reads the
>   environment. No other module touches `os.environ`. `OWNER_EMAIL` and `siteOrigin`, both
>   hard-coded literals in the source, become settings here — that is the rule's first job.
> - **Naming across the boundary**: as §3 above.

### 6. File organisation — the draft's one line risks exactly what the brief warns against

The whole of the backend's structural guidance is: "route handlers stay thin; application
decisions live in service modules behind the route layer; persistence lives behind the
ContentStore / AssetStore ports." Read literally, that mandates a service module per route. The
source has **four route handlers totalling 131 lines** and, per `code-structure.md`, no service
layer and no repository interface — and the same file calls `contentWriteStatements()`'s
pure/execute split "the single best thing about this codebase's structure". A blanket
service-per-route rule produces pass-through modules for `robots`, `sitemap`, `history` and
`media` that forward one call and decide nothing. That is the empty layer the brief warns about.
The named ports (`ContentStore`, `AssetStore`) are fine — they are two concrete ports named
after real things — but nothing yet says what belongs in them, which is where a generic
repository creeps in.

> **Proposed replacement.** **Where code goes.** Feature modules own their own data access;
> there is no `repositories/` package and no generic `Repository[T]`. Each feature's store
> speaks its own nouns (`read_content_state()`, `write_content()`, `put_asset()`), never
> `get(id)` / `save(obj)`.
>
> ```
> backend/app/
>   main.py            app factory, router registration, exception handlers, lifespan
>   settings.py        the only module that reads the environment
>   errors.py          the four domain errors and the envelope they map to
>   auth.py            owner identity, session, the single is_editor predicate
>   content/           router.py  models.py  service.py  store.py
>   media/             router.py  models.py  service.py  store.py
> ```
>
> - **`router.py`** — parse the request, authorize, call one service function, map the result to
>   a response. No SQL, no storage import, no business rule, no branching on domain state.
> - **`service.py`** — the decisions: the revision guard, draft-versus-publish, retention,
>   upload validation, the media access rule. Raises the domain errors. Knows nothing about HTTP.
> - **`store.py`** — the port `Protocol` and its concrete implementation. Owns transactions and
>   the wrapping of blocking drivers.
> - **`models.py`** — the wire contract. These models are the OpenAPI schema the frontend's
>   types are generated from, so a change here is a change to the frontend's build.
> - **A layer exists only when it has a job.** If a feature's service would only forward a call,
>   the router calls the store directly and no service module is created. No module is written to
>   satisfy the shape of the layering.
> - **The pure/execute split survives the port.** The seven-statement batch is ported as a pure
>   function returning statements plus a thin executor, exactly as `contentWriteStatements()` /
>   `writeContent()` are factored today. That factoring is what makes the batch inspectable and
>   testable statement by statement; collapsing it into one method loses the property the scan
>   ranks highest in this codebase.

### 7. Two defects to fix before the interview

- **`D10` names two different decisions.** `team-practices.md` uses D10 for "leave deployment
  hooks in place"; `evidence.md` item 10 is "client-side validation and the language boundary" —
  and the deployment-hooks decision appears nowhere in `evidence.md`'s list. The human will be
  interviewed against these identifiers; a collision means one of the two is answered and the
  other silently disappears. Renumber the validation question to D11 and give the deployment-hook
  question an entry of its own.
- **D5 understates its own risk.** The danger is not a deliberate `prettier --write`. It is a
  `.prettierrc` at the repository root, which every editor's format-on-save picks up silently,
  reformatting ported files one at a time as they are opened. If Prettier is introduced at all it
  must be scoped by path **and** the merge-gate diff check from §1 must be in place first —
  otherwise the erosion is invisible until D4's evidence is already gone.

## Positions

- AGREE: Governing the two runtimes separately is correct — only the frontend carries a parity obligation, and a single shared style rule would have to be wrong for one of them.
- AGREE: Leave ported frontend files in the dense house style. I verified the argument on the files themselves; the eight positional binds on `content-persistence.ts:35` are exactly the kind of thing a line-for-line diff catches and a reformatted diff hides.
- AGREE: No Prettier in the frontend in this workflow — with the §7 caveat that the real risk is an editor picking up a root config, not a deliberate formatter run.
- AGREE: Python takes strict defaults from day one, with `ruff format`, `ruff check` and `mypy` all at the merge gate; there is no legacy to accommodate.
- AGREE: Ports named after real things (`ContentStore`, `AssetStore`) rather than a generic repository abstraction, and handlers that do not hold SQL.
- OBJECT: The dense-style rule's unit is the edited *region*, which mandates intra-file style mixing and cannot be checked by any command; make the file the unit, add a modified-file manifest and the `git diff --no-index` gate check in §1.
- OBJECT: Nothing in the draft enforces the language boundary — it is asserted only. Name a mechanism: generated OpenAPI types, no storage credential in the frontend container, and a three-line grep at the gate.
- OBJECT: There is no error-handling rule for either runtime, and FastAPI's defaults (`{"detail": ...}`, Pydantic `loc`/`msg`) silently break the editor's field highlighting and conflict recovery while appearing to work.
- OBJECT: The user-facing error strings in the four source routes are product copy and fall under the parity rule; the draft treats parity as a layout-and-content matter only, so nothing currently stops the port rewriting them.
- OBJECT: Naming across the boundary is unstated, and the `camelCase` wire format is not actually a free choice — it is fixed by the ported components that read it and by the JSON already persisted in the content columns.
- OBJECT: D9 is mis-framed as low stakes, and it contradicts the draft's own "strictest reasonable defaults" claim; as written, ruff selects almost no rules, import ordering is undefined, and `mypy` strictness is undecided, so two developers will not produce the same code.
- OBJECT: `async` versus sync is unaddressed for a FastAPI backend that will wrap a synchronous SQLite driver — the resulting event-loop blocking is invisible to every check in the merge gate.
- OBJECT: "Application decisions live in service modules" read literally mandates a service per route, which for 131 lines of source handlers produces pass-through layers; add the "a layer exists only when it has a job" clause and the explicit pure/execute preservation rule.
- OBJECT: `D10` identifies two different decisions across the two artifacts, and one of them has no entry in `evidence.md` at all.
