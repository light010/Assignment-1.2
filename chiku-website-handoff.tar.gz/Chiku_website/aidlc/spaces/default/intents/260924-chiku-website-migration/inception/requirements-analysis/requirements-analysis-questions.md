# Requirements Analysis — Questions

Upstream: `ideation/intent-capture/intent-statement.md`,
`ideation/scope-definition/scope-document.md`,
`codekb/Chiku_website/{business-overview,architecture,code-structure}.md`,
`inception/practices-discovery/team-practices.md`.

Most functional requirements are already determined: the CodeKB documents every
route, status code, constraint and behaviour of the system being preserved, and
the parity rule says they are reproduced. Those are written up directly rather
than asked about.

Five questions remain, and each is a place where "preserve exactly" and "build
something defensible" pull in different directions. Answering them is what turns
the parity rule into something a test can check.

---

## Q1. A third pre-existing defect. In or out?

At intent capture you ruled on two known defects: fix the carousel keyboard
focus, leave the 560 kB bundle. The deeper code scan then found a third, which
you have not ruled on.

`app/edit/editor-workflow.ts:20` lists which validation-error codes are
recoverable when restoring a draft from browser storage. The list contains
`invalid_format` — a **zod v4** code that can never match under the installed
zod v3 — and omits `invalid_enum_value`, which is the code v3 actually emits.
The effect: if a recovered draft contains one bad enum value (an accent colour,
a research topic, the 3D scene's initial view), the **entire recovered draft is
discarded**, which is the opposite of the stated intent in the comment two lines
above it.

The scan labelled this "latent, not observed" — it is reachable but nobody has
reported hitting it.

A. Fix it. The port reproduces the *intent* of that comment, not the bug: a recoverable field error keeps the draft.
B. Preserve it exactly. Parity means parity, including this. Record it as a known issue.
C. Fix it, and also audit the rest of the recovery state machine for the same class of mistake.
D. Not yet defined.
X. Other (please specify)

[Answer]: A. Fix it. The port reproduces the *intent* of that comment, not the bug: a recoverable field error keeps the draft.

---

## Q2. How long should a signed-in session last?

The system being replaced never had to answer this: ChatGPT's platform owned the
session and the app only read headers. The new backend issues its own session
cookie, so a lifetime has to be chosen. There is no precedent to preserve.

A. 7 days, sliding — each authenticated request extends it. Sign in roughly weekly under normal use.
B. 24 hours, fixed — sign in daily. Shortest exposure if a cookie leaks.
C. 30 days, sliding, plus an explicit "sign out everywhere" that invalidates existing sessions.
D. Not yet defined.
X. Other (please specify)

[Answer]: A. 8 hours idle / 7 days absolute, sliding within the idle window. Confirmed after clarifying that the new session is entirely standard and carries no ChatGPT dependency — argon2id password hash, signed HttpOnly/Secure/SameSite=Lax cookie issued and verified by the Python backend, CSRF double-submit, rate-limited login.

---

## Q3. The 1.5 MB save limit counts characters, not bytes. Which should the port use?

`PUT /api/content` rejects a body over 1,500,000 with HTTP 413. The check is
`bodyText.length`, which in JavaScript counts **UTF-16 code units, not bytes**.
A document of 1.5 M characters can be 4 MB or more of UTF-8 — so a Python
implementation that caps at 1,500,000 **bytes** would reject documents the
current system accepts.

This matters in practice because the content document holds transcripts of up to
60,000 characters each, and non-ASCII characters (curly quotes, em dashes,
accented names — all present in the seeded content) cost more than one byte.

A. Match the original exactly — cap at 1,500,000 characters of the decoded body, so every document the old system accepted is still accepted.
B. Cap at 1,500,000 bytes. Simpler and safer against memory use, but it silently rejects large documents the old system took.
C. Cap at 1,500,000 characters AND add a separate, higher byte ceiling as a memory guard.
D. Not yet defined.
X. Other (please specify)

[Answer]: A. Match the original exactly — cap at 1,500,000 characters of the decoded body, so every document the old system accepted is still accepted.

---

## Q4. The media access rule: preserve the substring scan, or implement a structured equivalent?

An uploaded file is served publicly if, and only if, the literal string
`/api/media/<key>` appears **anywhere** in the serialised published document —
including inside a 60,000-character transcript, the biography, any description,
the notice, or any of the nine editable copy blocks.

Two consequences, both real:

- **Any structured reimplementation is a behaviour change.** Checking only the
  known image and file fields makes strictly *fewer* assets public, so an image
  referenced from prose starts returning 404 to visitors.
- **The current cost is high.** Every media byte served triggers one database
  read, **two** full schema validations and **three** serialisations of a ~15 KB
  document, with `Cache-Control: private, no-cache` and no 304 path — repeated
  for every byte-range request while a video is streaming. And because it loads
  the whole document, one unparseable stored document returns 503 for every
  image, the public page and the editor simultaneously.

A. Preserve the substring scan exactly, and add a short-lived in-process cache of the published document so the cost per byte collapses without changing which assets are public.
B. Preserve the substring scan exactly, with no caching. Truest to the original, including its cost.
C. Implement a structured check over known media fields. Faster and clearer, and accepts that an asset referenced only from prose becomes non-public.
D. Not yet defined.
X. Other (please specify)

[Answer]: A. Preserve the substring scan exactly, and add a short-lived in-process cache of the published document so the cost per byte collapses without changing which assets are public.

---

## Q5. Login rate limiting — what should the threshold be?

Also new: the old system had no login to protect. Practices affirmed that login
rate limiting exists; the numbers were never set. This is a single-owner site,
so a limit tight enough to frustrate an attacker costs the legitimate user very
little.

A. 5 failed attempts per account per 15 minutes, and 20 per IP per 15 minutes, with a plain lockout message and no account enumeration.
B. 10 failed attempts per account per hour, with exponential backoff on repeated failures.
C. 3 failed attempts, then a 15-minute lockout. Strictest; a fat-fingered owner waits.
D. Not yet defined.
X. Other (please specify)

[Answer]: A. 5 failed attempts per account per 15 minutes, and 20 per IP per 15 minutes, with a plain lockout message and no account enumeration.

---

## Consolidated Summary Confirmation

- Q1 — Fix the third pre-existing defect: a recoverable field error keeps the recovered draft, reproducing the stated intent rather than the bug.
- Q2 — Session lifetime 8 hours idle / 7 days absolute, sliding within the idle window. The session mechanism is standard and carries no ChatGPT dependency of any kind.
- Q3 — The 1.5 MB save cap counts characters, matching the original exactly, so no document the old system accepted is rejected.
- Q4 — Preserve the media access substring scan exactly, and add a short-lived in-process cache of the published document so the per-byte cost collapses without changing which assets are public.
- Q5 — Login rate limiting at 5 failed attempts per account per 15 minutes and 20 per IP per 15 minutes, with a generic failure message and no account enumeration.

Does this all look correct before I generate the requirements artifact?

- Looks correct
- Request changes

[Answer]: Looks correct
