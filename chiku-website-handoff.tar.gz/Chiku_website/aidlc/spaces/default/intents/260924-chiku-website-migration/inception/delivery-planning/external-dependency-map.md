# External Dependency Map — chiku-website runtime-split migration

**Upstream:** `inception/delivery-planning/bolt-plan.md`,
`inception/domain-design/components.md`,
`inception/contract-design/contract-summary.md`,
`codekb/Chiku_website/dependencies.md`.

What this delivery depends on that is **not** built here, which Bolt first needs
it, and what happens if it is unavailable.

## Runtime and tooling dependencies

| Dependency | Version | First needed | If unavailable |
|---|---|---|---|
| Node.js | 24.x (image `node:24-alpine3.24`, pinned by digest) | B1 | Blocks everything. Present on the host at 24.13.0 |
| Python | 3.14 (image `python:3.14-slim-trixie`, pinned by digest) | B1 | Blocks everything. Present at 3.14.3. All binary deps publish cp314 manylinux wheels for x86_64 **and** aarch64, so no compiler is needed in the image |
| pnpm | 10.30.3 | B1 | Frontend install blocked. Note the source declares `packageManager: pnpm@11.25.0`; the destination pins its own |
| uv | 0.10.0 | B1 | Python resolution blocked |
| Docker daemon + Compose | 29.4.2 / v5.1.3 | B1 (the skeleton runs **inside** Compose) | B1's definition of done cannot be met. Container checks are reported **blocked**, never skipped, and every non-container check still runs |
| `git` | present | B1 | Worktree-per-Bolt and the `git diff --no-index` parity check both blocked |

## Product dependencies (shipped in an image)

| Dependency | Version | Unit | Why |
|---|---|---|---|
| fastapi | 0.141.1 | U6 | The HTTP surface and the OpenAPI document |
| pydantic | 2.13.5 | U4 | **The** authoritative schema. Not a validation helper — the single source of truth |
| uvicorn | 0.53.0 | U6 | ASGI server, production mode, no reload |
| sqlalchemy + alembic | 2.0.54 / 1.20.0 | U2 | SQLite adapter and its migrations |
| argon2-cffi | 25.1.0 | U3 | Password hashing |
| itsdangerous | 2.2.0 | U3 | Cookie signing |
| python-multipart | 0.0.32 | U5 | Multipart upload parsing |
| pillow | 12.3.0 | U5 | Image decoding and server-side variant generation |
| next / react / react-dom | 16.3.6 / 19.3.0 | U8, U9 | The render layer |
| three | 0.186.0 | U8 | The research illustration. Unchanged from source |
| tailwindcss | 4.3.3 | U8 | Styling |
| radix-ui / @base-ui/react + 11 vendored components | as source | U8 | Carried across; 49 unreachable component files are **not** |
| google-cloud-firestore | 2.31.0 | U11 | Cloud adapter. **Never imported on the verified path** |
| google-cloud-storage | 3.14.1 | U11 | Cloud adapter. Same |

**Deliberately not carried across:** 13 production dependencies with no import
path from any entry point, plus `drizzle-orm` and `drizzle-kit` — the scan
established drizzle is **not in the request path at all**; every query in the
source is a hand-written SQL string, so there is no ORM to replace.

## Dev dependencies

| Dependency | Version | Purpose |
|---|---|---|
| pytest | 9.1.1 | Backend tests, with `--cov --cov-branch` |
| httpx | 0.28.1 | Transport-level API tests **and** recording B1's fixtures from the running source app |
| ruff | 0.16.8 | Format and lint, including the `S` security ruleset |
| mypy | 2.3.1 | `--strict` |
| typescript | 6.0.3 | `--noEmit`. Note 7.0.2 exists but `typescript-eslint@8` peers `<6.1.0` |
| eslint + eslint-config-next | 9 / 16.3.6 | Carried from source with its scoped relaxations |
| openapi-typescript | current | Generates U7's types from U6's document |
| pip-audit, pnpm audit | — | Advisory gate, blocking at High |

## External services

| Service | Needed for | Status |
|---|---|---|
| **None at runtime on the verified path** | — | The verified system depends on no external service. Content and media are local; auth is local; there is no third-party API, no model provider, no analytics, no CDN |
| Google Cloud Run, Firestore, Cloud Storage, Artifact Registry | U12's plan only | **Nothing is provisioned.** No project, no credential, no billing change. `gcloud` is not installed and is not needed |

## The one dependency that expires

**`madhavi-tripathi/` must still be runnable when B1 executes.** B1 records its
real HTTP responses as the oracle every parity claim rests on. Booting it needs
`pnpm install --frozen-lockfile`, both SQL migrations applied to a disposable
local emulator database, and the dev server — all local, nothing hosted touched.

This is the only dependency in this table with a **deadline imposed by physics
rather than by choice**, and it is why five units carry a dependency edge on it
rather than a note in a plan. It has not yet been booted in this workflow; that
is the largest unverified assumption in the delivery plan.

## Licence obligations that travel with copied files

| Obligation | Applies to |
|---|---|
| `vendor/shadcn-tailwind-4.13.0.LICENSE.md` | Must travel with any of the 11 vendored `components/ui/*.tsx` files carried across — they have no per-file header |
| `build/sites-vite-plugin.LICENSE` | Only if that `.ts` file is carried. It is **not** — it is Cloudflare/OpenAI-Sites-specific and retired |

## Assumptions & Open Questions

- **[assumption]** Every pinned version was registry-verified on 2026-09-24 and is
  installable. B1 is the first Bolt that actually resolves them; a resolution
  failure there is cheap and early.
- **[assumption]** `madhavi-tripathi/` still boots. **Untested.** If it does not,
  B1's fixtures cannot be recorded and every parity claim falls back to the
  written knowledge base.
- **[open]** `pnpm-workspace.yaml`'s `minimumReleaseAge: 10080` is a supply-chain
  control, not friction, and carries across. Whether it applies to the destination
  workspace's own file is settled at B1 when that file is written.
