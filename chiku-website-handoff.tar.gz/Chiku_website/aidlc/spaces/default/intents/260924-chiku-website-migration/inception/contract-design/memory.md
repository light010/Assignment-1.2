<!-- INVARIANT: examples are single-line HTML comments so a fresh template parses to total=0 (MEMORY_EMPTY). Do NOT un-comment or split across lines. t100 guards this. -->
> This file is kept up to date automatically while the stage runs. Add observations at the review step, not by editing here directly.

## Interpretations
<!-- example: 2026-05-29T10:14:32Z — chose REST over GraphQL; the consuming team only needs CRUD, revisit if subscriptions land -->

- 2026-09-24T17:43:07Z — resolved the carried-forward Firestore question by analysis rather than deferring it again. All three recorded worries are expressible: cross-document transactions cover the bounded combined write, read-then-assert inside a transaction reproduces compare-and-set, and composite ordering exists but REQUIRES a declared index. Found a fourth asymmetry nobody had listed: Firestore has no DELETE WHERE id NOT IN (subquery), so the port must specify the prune as read-then-delete or it would be satisfiable by only one adapter.
- 2026-09-24T17:43:07Z — deliberately omitted field-level schemas from the C1 OpenAPI block. They are generated from the Pydantic models, and writing them out here would create a second definition that can drift from the authoritative one. The block fixes operations, status codes and the envelope - the parts that are ported rather than designed and would otherwise be lost.
## Deviations
<!-- example: 2026-05-29T10:14:32Z — skipped the optional caching layer the stage prose suggested; the dataset is small enough that it adds risk -->

- 2026-09-24T17:43:07Z — asked the human nothing at this stage. They instructed that the design stages be batched with one consolidated approval before code generation, so the questions file records each question answered from an already-confirmed decision or resolved by analysis with its evidence, and explicitly states that none was put to them interactively. Turned summary-confirmation off for the batch and will turn it back on before code-generation; leaving it on would have stopped at a receipt per stage, which is not batching.
## Tradeoffs
<!-- example: 2026-05-29T10:14:32Z — picked TDD over BDD this run; the team is unit-first and the domain is well-understood -->

- 2026-09-24T17:43:07Z — recorded that there is NO versioning scheme, rather than inventing one. With one owner, one browser, one deployment and no remote, a backend rename fails the frontend type check at the same merge gate with a file and a line. Adding URL versioning or a deprecation window would be ceremony protecting a consumer that does not exist.
## Open questions
<!-- example: 2026-05-29T10:14:32Z — confirm the retention window with compliance before the next stage hardens the schema -->
