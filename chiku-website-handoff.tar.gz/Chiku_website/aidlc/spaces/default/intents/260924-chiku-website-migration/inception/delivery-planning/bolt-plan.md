# Bolt Plan — chiku-website runtime-split migration

**Upstream:** `inception/units-generation/unit-of-work.md`,
`inception/units-generation/unit-of-work-dependency.md`,
`inception/units-generation/unit-of-work-story-map.md`,
`inception/domain-design/components.md`,
`inception/contract-design/contract-summary.md`,
`inception/requirements-analysis/requirements.md`,
`inception/practices-discovery/team-practices.md` (the affirmed way of working,
walking-skeleton stance, testing posture and deployment stance this plan applies),
`aidlc/spaces/default/memory/team.md`.

Ten build passes — a **Bolt** being one build pass over a piece of the work,
ending in something that runs. Sequencing is dependency-first, so nothing is built
on a boundary that later moves.

## Way of working

Trunk-based on `main`. Each Bolt runs in its own short-lived worktree branch based
on `main` and squash-merges back as one commit named for the Bolt. No remote and
no pull-request gate, so the **local merge gate is the only enforcement point**,
and its verbatim output — exit status, pytest summary, both coverage totals,
Compose health — is pasted into each Bolt's approval. Approval is refused without
it. Execution is **serial**: the work is solo, so the graph's parallelism is
recorded but unused.

## Sequence

| Bolt | Units | Kind | Definition of Done | Confidence hypothesis |
|---|---|---|---|---|
| **B1** | U1 + a thin slice of U2, U3, U4, U6, U7, U8, U9, U10 | **Walking skeleton — solo, gated** | Recorded fixtures exist. Sign in → edit one field → save → publish → see it on the public page, **inside `docker compose up`**, not against hand-started processes. `.env.example` committed. Merge-gate flag spellings pinned by running each one. `docker history` on both images shows no secret in a layer. | The language boundary, the session contract and the storage port all hold when a real request crosses them in containers. If this is wrong, it is wrong now, on a thin slice, rather than after eight Bolts of work rest on it. |
| **B2** | U2 storage-ports | library | Three ports, SQLite adapters, an in-memory fake per port, and one adapter-parameterised conformance suite per port run over **both** implementations. The combined write is one atomic call. | Two implementations passing the same suite proves the suite tests the *port* rather than SQLite — which is the entire argument for having a port. |
| **B3** | U3 identity-and-session | library | Password sign-in, session issue/verify/revoke with 8h idle and 7d absolute expiry, CSRF token, rate limiting at 5/account and 20/IP per 15 min, one-shot provisioning. A fresh start against empty storage has **no account anyone can sign in to**. | Authentication is enforceable with no frontend present at all: direct API calls with no session, a forged cookie, and a stale session are each rejected. |
| **B4** | U4 content-core | library | The content schema, validation, the combined write with both guards, revisions and retention, the published-document cache, and the inspect classification. **Three hazards** — FR4.5, FR9.2, FR8.3.1–.3 — each with a test per enumerated branch and 100% scoped coverage. | The concurrency guard survives a *concurrent* writer, not just a sequential one. A test that only ever runs one writer proves nothing about FR4.5. |
| **B5** | U5 media | library | Byte-signature typing, size ceilings, caption validation, server-side variants, orphan-free failure, the asset-visibility rule, and all seven range branches. **Two hazards** — FR6.2, FR7.2 — plus FR7.4. | The range branches behave as the recorded fixtures say, including the four non-obvious ones and the HEAD/GET divergence. These are the behaviours nobody would guess. |
| **B6** | U6 http-api + U7 api-client | service + library | Every route, one error envelope from a four-member taxonomy, origin and CSRF middleware, the OpenAPI document, and TypeScript types generated from it and committed. **One hazard** — FR10.1. Boundary checks on the gate: the grep, the AST test, and the dirty-regeneration check. | A backend field rename fails `tsc --noEmit` with a file and a line, rather than surfacing as a runtime error in the editor three Bolts later. |
| **B7** | U8 public-site | ui | Every public route and section, the 3D scene, the SEO surface, **and the shared presentation code the editor will consume**. Parity by normalised DOM diff against B1's fixtures. | Ported components render identically given identical props — which is what makes the byte-identical file rule worth its cost. |
| **B8** | U9 owner-editor | ui | Every editing surface, autosave and its suspensions, per-tab recovery including the third unreachable-backend state, conflict handling, preview, the browser tool. **One hazard** — FR8.3.4 and the editor half of FR8.3. | The owner can do everything she can do today, and unsaved work survives every failure path — including the one where the backend cannot be reached to classify it. |
| **B9** | U10 containers | packaging | Two images, Compose, non-root, digest-pinned bases, frozen installs, health checks, graceful shutdown, a named volume. Verified with **no source mounts and no dev servers**; durability proven by recreating the runtime container and re-reading. | The system runs from images alone, and content survives the container that wrote it being destroyed. |
| **B10** | U11 cloud-adapters + U12 deployment-plan | library + spec | Firestore and Cloud Storage adapters against the same conformance suites, labelled unverified. The costed plan with **measured** image sizes, every line traced to a current official source. | The zero recurring-cost target is provable as a property of the plan — which is the only way it can be proved while nothing is deployed. |

## Why this order and not another

**Dependency-first** was confirmed at scope definition. Beyond that constraint,
three choices were made here:

1. **Each hazard-heavy unit gets its own Bolt.** U4 carries three hazards and U5
   carries two. Grouping them would mean one gate covering five silent-failure
   behaviours, and a failure anywhere blocks all five. Separate Bolts isolate them.
2. **`public-site` before `owner-editor`** — this resolves units-generation
   finding R-03, where the shared presentation code had an owner but no dependency
   edge. The public site carries it, because it exercises those components on the
   parity-critical surface where a mistake is caught by a DOM diff rather than by
   eye.
3. **Cloud adapters last, with the plan.** They depend only on the ports, so they
   could run any time after B2. Placing them last keeps every earlier gate free of
   a component that cannot be verified against its real service.

**No scoring model is used.** Weighted Shortest Job First and its relatives rank
work by value and urgency over size; here there is one owner, no deadline, no
external users, and nothing that ships before the whole thing does. The inputs
that would differentiate options do not exist, so a score would be arbitrary
numbers presented as analysis.

## After the skeleton

Once B1 ships, the ladder prompt asks whether the remaining Bolts run
autonomously or each gate individually. That choice belongs to the human at that
moment and is **not** pre-committed here.

## Assumptions & Open Questions

- **[assumption]** Ten Bolts is the count that falls out of dependency-first plus
  hazard isolation. If the ladder prompt selects autonomous execution, the count
  matters less than the isolation.
- **[assumption]** B1's thin slice touches eight units but completes none. Each is
  revisited in full by its own Bolt. A skeleton that completed a unit would not be
  a skeleton.
- **[open]** Whether B10's two units should split into separate Bolts. They are
  grouped because the plan needs the adapters' existence and the containers'
  measured sizes, and neither is verifiable here. Splitting adds a gate that
  checks nothing new.
