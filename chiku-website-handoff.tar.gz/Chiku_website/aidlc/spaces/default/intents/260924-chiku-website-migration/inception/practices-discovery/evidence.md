# Practices-discovery evidence — chiku-website runtime-split migration

What was inspected, what each conclusion rests on, and — stated plainly — which parts of
`team-practices.md` are **observations of an existing practice** and which are **proposals with no
precedent in this codebase**.

The headline finding of this stage: **most of the Testing Posture and all of the Deployment
section are proposals, not discoveries.** The source project has zero tests, no test framework, no
formatter configuration and no CI. There is nothing to discover about how this team tests or
deploys, because on the evidence available this team has never done either in an automated way.
`aidlc/spaces/default/memory/team.md` is empty, so there is also no prior affirmation to preserve.

> **This file is not promoted.** `practices-promote` writes only the five H2 sections of
> `team-practices.md` into `team.md`, and only `discovered-rules.md`'s two lists into `project.md`.
> Anything here that a future reader would need in order to apply a rule correctly has been
> restated in `team-practices.md` — including the one-sentence marker at the head of
> `## Testing Posture` recording that the posture is largely proposal rather than discovered
> practice.

## What was inspected

| Source | What was taken from it |
|---|---|
| `aidlc/spaces/default/codekb/Chiku_website/technology-stack.md` | Every pinned version; the platform-coupling split; the three recorded absences (test framework, formatter, CI); the two surviving automated gates (`tsc` strict, `pnpm lint`); `eslint.config.mjs`'s scoped relaxations for vendored code |
| `aidlc/spaces/default/codekb/Chiku_website/code-quality-assessment.md` § *Hazard index* | The three ranked hazards and four runners-up that the backend port must reproduce branch-for-branch |
| same § *The dense single-line style* | The per-file byte/line measurements and the five-point adjudication that the density is deliberate house style |
| same § *Testing — total absence* | The exhaustive negative search (no `*.test.*`, `*.spec.*`, `vitest.config.*`, `jest.config.*`, `playwright.config.*`, `__tests__/`, `tests/`; no `test` script; no testing dependency) and the list of five intricate behaviours that are currently unverified |
| `.claude/scopes/aidlc-runtime-split-migration.md` | `skeleton: on`; `change_control: strict`; `depth: Standard`; the recorded reasons the operation phase and `ci-pipeline` are skipped; the walking-skeleton shape |
| `aidlc/spaces/default/intents/.../aidlc-state.md` | The verbatim project description; `Scope: runtime-split-migration`; `Test Strategy: Standard` |
| `aidlc/spaces/default/memory/org.md` | The five default practice sections and the exact wording of the scope-conditional 80% floor |
| `aidlc/spaces/default/memory/team.md` | Confirmed empty — no baseline to preserve |
| `contributions/aidlc-quality-agent.md` | The branch-vs-line coverage argument; the four defects in the Ordering sentence; the six test families and which are mandatory; the normalised DOM-diff recommendation and the explicit rejection of pixel comparison; the verbatim-gate-output requirement; the hazard-by-hazard coverage analysis |
| `contributions/aidlc-developer-agent.md` | The file-as-unit replacement for the edited-region rule and its `git diff --no-index` check; the two files that cannot be unmodified; the three boundary-enforcement mechanisms and the `routers/` AST test; the frozen `camelCase` wire format and the single conversion point; the error-envelope regression and its four-member taxonomy; `async` by default; "a layer exists only when it has a job"; the concrete `ruff`/`mypy` configuration |
| `contributions/aidlc-devsecops-agent.md` | The secret-handling rules and boot-failure requirement; the `NEXT_PUBLIC_*` inlining hazard; the initial-owner provisioning mechanism; the supply-chain control table (frozen installs, digest pinning, non-root user, the two audit commands); the `minimumReleaseAge` reclassification; the `.npmrc` `audit=false` inheritance; the two vendored MIT notices; the `S` ruleset argument |
| `practices-discovery-questions.md` | The human's eight rulings, and the two tables recording what was adopted from reviewers without asking |
| `git rev-parse --short HEAD`, `date -u` | The stamp in `practices-discovery-timestamp.md` |

`madhavi-tripathi/` source files were **not** re-read in this stage. The two knowledge-base files
above are the adjudicated record of that scan, and re-deriving their findings was explicitly out
of scope for this turn. The developer reviewer did read the source files directly, which is why
their file-level claims (byte counts, `server.ts:5`, `site-metadata.ts:5`, `editor-workflow.ts:60`)
carry weight the lead's draft could not supply.

## Discovered vs. proposed, section by section

Status reflects the **final** text of `team-practices.md`, after the interview and the accepted
reviewer objections.

| Section | Status | Basis |
|---|---|---|
| Way of Working — trunk-based, squash-merge | **Inherited, unchallenged** | `org.md` default. Nothing in the project argues against it |
| Way of Working — "no PR, so the stage gate is the review gate" | **Observed, then human-affirmed** | Repository has `main`, five commits, no remote, no forge. Q6 confirmed it stays that way, which turns an observation into a settled practice |
| Way of Working — the gate carries verbatim run output | **Proposed by the quality reviewer, adopted without asking** | With no CI and no pull request, an unwitnessed gate is an assertion rather than a check. No reviewer disagreed and no cost was identified, so it was not worth an interview slot |
| Way of Working — dependency-first Bolt sequencing | **Human-stated** | Confirmed by the site owner before this stage |
| Walking Skeleton — runs first, solo, gated | **Human-stated and scope-declared** | Confirmed, and `skeleton: on` in the approved scope file |
| Walking Skeleton — must cross both runtimes *and* the container boundary | **Proposed** | An agent judgement about what makes a skeleton meaningful here. The scope file says the first Bolt "carries one end-to-end public and management flow through both runtimes"; the requirement that it run **inside Compose** is our addition |
| Walking Skeleton — the four Bolt 1 deliverables | **Mixed** | The fixtures are human-ruled (Q1); `.env.example`, the `docker history` check and the pinned flag spellings are reviewer proposals adopted without asking |
| Testing — methodology `custom` | **Human-ruled (Q2)** | The draft's `test-after` was a default, not an observation. The quality reviewer's objection — that test-after lets a misread source produce a matching implementation *and* a matching test — was put to the human, who chose `custom` |
| Testing — the Ordering sentence | **Proposed, rewritten after review** | The draft's sentence carried two sequencing axes in one word, left frontend-only and non-enumerated units undefined, and defined "done" a second time in conflict with the merge gate. Rewritten to one axis, with both undefined cases named and the "done" clause deleted — `org.md` requires Code Generation to resolve `Ordering` independently of the gate |
| Testing — golden fixtures recorded from the running source | **Human-ruled (Q1)** | The one decision in this stage with an expiry date. Without it every parity assertion rests on a human's reading of a document |
| Testing — **branch** coverage rather than line | **Proposed by two reviewers, adopted without asking** | Every high-risk behaviour is a branch or a `??` fallback chain, which line coverage marks covered when only one side runs. It costs one flag and no one argued against it |
| Testing — 80% backend floor | **Human-ruled (Q5), and it had to be chosen rather than inherited** | `org.md`'s 80% floor is scoped to `mvp`, `enterprise`, `feature`, `infra`, `classic`. This workflow runs the custom scope `runtime-split-migration`, which is in none of those lists — and in none of the other lists either. **No org scope floor reaches this workflow.** Absent this ruling the project would have had no numeric floor at all |
| Testing — 100% scoped floor on the hazard modules | **Human-ruled (Q5)** | An aggregate percentage cannot distinguish "exercised" from "ported correctly"; the second scoped report is what removes the room |
| Testing — no frontend coverage floor | **Proposed, two-reviewer agreement** | Follows from the language-boundary constraint: a percentage over a render-only layer measures JSX traversal |
| Testing — per-branch tests for hazard-ranked behaviours | **Proposed, strongly evidenced** | `code-quality-assessment.md` names five behaviours with intricate branching and zero automated verification, and states plainly that behavioural equivalence "cannot be demonstrated by running the old tests, because there are none" |
| Testing — "existing suite remains green" is inapplicable | **Observed** | Exhaustive negative search recorded in the knowledge base |
| Testing — the six test families | **Proposed by the quality reviewer** | Including two non-obvious calls: the storage-port suite is parameterized over the real adapter **and** an in-memory fake, and API contract tests assert the generated OpenAPI against the hand-written `contract-design` contract rather than against itself, which would be circular |
| Testing — Compose end-to-end on every Bolt merge | **Human-ruled (Q5)** | With no CI, the per-merge run *is* the CI |
| Testing — parity verified by normalised DOM diff plus a final human page-by-page review | **Human-ruled (Q3)** | This closes what the draft itself called its largest gap. Pixel comparison was explicitly rejected, not deferred |
| Testing — boundary enforcement (generated types, gate grep, `routers/` AST test) | **Proposed by the developer reviewer, adopted without asking** | The draft asserted the boundary and named nothing that would stop a violation. A rule nobody can check is a wish |
| Testing — Python tooling versions | **Given** | Supplied as registry-verified in the dispatch brief; not independently re-verified in this stage |
| Testing — the merge gate command list | **Proposed** | Constructed to substitute for the skipped `ci-pipeline`, then extended with the reviewers' checks. The flag spellings are unverified — pinning them is a Bolt 1 deliverable |
| Testing — advisories block at High and above, with a recorded exception | **Human-ruled (Q8)** | The fork the security reviewer identified for a solo developer with no CI: a no-exception block stops all work the day an unfixable transitive advisory lands; an advisory-only run becomes a notification nobody reads |
| Deployment — the whole section | **Proposed / negative** | Nothing deploys. Every statement is either a human-stated constraint (plan-only cloud, zero cost), a record of what the composed scope removed, or a security control the devsecops reviewer proposed |
| Deployment — secrets, boot failure, `NEXT_PUBLIC_*`, initial-owner provisioning | **Proposed by the devsecops reviewer** | The prohibitions were already human-stated; these are the **mechanisms** that make them checkable, which is why they sit here and not in `discovered-rules.md` |
| Deployment — supply chain (frozen installs, digest pinning, non-root user, audits) | **Proposed by the devsecops reviewer, adopted without asking** | Building an image is a supply-chain act even when nothing ships |
| Code Style — frontend linter and type check | **Observed** | `eslint.config.mjs`, `tsconfig.json` (`strict: true`) as recorded in `technology-stack.md` |
| Code Style — no frontend formatter | **Observed** | No `.prettierrc`, no Prettier dependency, no `format` script anywhere in the tree |
| Code Style — dense style is house style, not defect | **Observed and adjudicated** | Five-point argument in `code-quality-assessment.md`: the density tracks authorship (vendored files are conventionally formatted, authored files are dense); within dense files the branching-heavy ones are conventionally formatted; no formatter is configured; purposeful prose comments survive; the ESLint config distinguishes authored from vendored code and holds authored code stricter |
| Code Style — **what to do about it** | **Proposed, replaced after review, then human-ruled (Q7)** | The draft's edited-region rule was withdrawn in favour of file-as-unit; the timing of normalisation went to the human |
| Code Style — frozen `camelCase` wire format | **Observed, not chosen** | Ported components read the shape directly and the persisted content *is* that JSON, so a rename is simultaneously a frontend sweep and a data migration. The single conversion point is the proposal; the constraint is a fact |
| Code Style — the error envelope | **Observed, and the highest-probability silent regression in the migration** | Four source routes, one envelope, five statuses, and `editor-workflow.ts` branching on 409 and reading `result.issues`. FastAPI's defaults break field highlighting and conflict recovery *while appearing to work* |
| Code Style — `async` by default, `anyio.to_thread.run_sync` in the adapter | **Proposed by the developer reviewer** | Event-loop blocking is invisible to every check on the gate list, so it has to be a rule rather than something a gate catches |
| Code Style — Python `ruff`/`mypy` configuration | **Proposed, made concrete after review** | The draft claimed "strictest reasonable defaults" and then deferred the specifics. `ruff`'s default select list is close to nothing, import sorting is off unless `I` is selected, and `mypy` without `strict` leaves untyped bodies unchecked — so the claim and the deferral contradicted each other |

## Why the dense-style position is what it is, and what it costs

The knowledge base establishes the *fact* (deliberate house style) but takes no position on the
*action*. The position in `team-practices.md` — leave ported code as-is, write new code to the new
standard — rests on one asymmetry:

**With zero tests in the source, a line-granular diff against the original is the only cheap
parity evidence that exists.** A formatter run voids it for precisely the files that carry the
most hidden branches — `app/content.ts`'s single 1,189-character line holds all 31 schema fields
with their refinements and defaults, and the knowledge base explicitly flags "a reviewer skimming
`content.ts:20` can miss a `.default()` or a `.refine()`" as the translation hazard.

Cost of the position taken: two styles in one tree, harder review, and a newcomer who sees an
inconsistent frontend. Cost of the alternative (reformat on port): parity evidence is destroyed at
exactly the moment it is most needed, and a formatting run and a behaviour change become
indistinguishable in the same diff.

**What changed after review.** The draft's boundary rule made the *edited region* the unit. The
developer reviewer's objection was decisive on two grounds: it mandates intra-file style mixing,
which is worse than the inter-file mixing we already accept; and "untouched region" is not a
property any tool can evaluate, so nobody can review it and nobody can check it. The replacement
makes the **file** the unit and the invariant a command — the source tree stays in the repository,
so `git diff --no-index` costs nothing to run. This converts the whole style position from a
promise into a gate check, and it shrinks the parity surface as a side effect: a byte-identical
render component given the same props cannot render differently, so parity risk concentrates in
`PORTED-MODIFIED.md` plus the CSS, which is a small enough page set for the Q3 human review to
cover by eye.

The human ruled on timing (Q7): **normalise after parity sign-off**, one mechanical commit once
tests prove it changed nothing. Keeping the dense style permanently was a live option and was not
chosen; reformatting during the port was rejected for the reason above.

## Decisions the human made

Each was a genuine fork with a real cost on both sides. All eight are now settled; the costs
accepted are recorded here because they do not survive into `team.md`.

1. **Q1 — Golden fixtures: yes.** Drive the running `madhavi-tripathi/` app over HTTP and record
   its real responses before any Python is written. *Cost accepted:* installing and booting the
   legacy Cloudflare-Workers app — pnpm install, both SQL migrations applied to a local emulator
   database, the dev server run — roughly half a day. *What it buys:* every parity assertion in the
   project moves from "a human's reading of a document" to "data recorded from the system".
   *Rejected:* using the reverse-engineering knowledge base alone as the written oracle, and the
   narrower highest-risk-surfaces-only variant. **This is the only decision here with an expiry
   date** — once the source app is retired, the option is gone and cannot be recreated.
2. **Q2 — Methodology `custom`.** Characterization tests first for the hazard register and the
   storage port; test-after elsewhere. *Cost accepted:* two rules instead of one, and the discipline
   of watching a test fail before the code exists. *Rejected:* `test-after` (a misread source
   produces a matching implementation and a matching test, both green, both wrong — and every gate
   in this document passes on that build); `tdd` everywhere (most of the ported render layer has no
   enumerated oracle, so failing render assertions written first are waste).
3. **Q3 — Parity verification: DOM diff plus a final human pass.** *Cost accepted:* building a
   normalisation step (strip volatile attributes, build hashes, whitespace) and a page-by-page
   human review at the end. *Rejected, explicitly and not deferred:* per-route pixel screenshot
   comparison — brittle against fonts, antialiasing and animation, with a setup cost several times
   the DOM diff's. This closes the draft's largest gap: before it, a Bolt could be declared
   parity-preserving on nobody's evidence.
4. **Q4 — Client-side validation: generated mirror only.** *Cost accepted:* a generation step in
   the build and at the gate. *What it buys:* editor responsiveness without a round trip per field,
   and drift that is impossible by construction rather than forbidden by policy. *Rejected:*
   forbidding client validation outright (an editor measurably worse than the one being replaced);
   a hand-written mirror documented as non-authoritative (two definitions that can drift, and a
   boundary rule with an exception that would be cited to justify the next one). The prohibition on
   hand-written mirrors is recorded in `discovered-rules.md`; the generation mechanism is in
   `team-practices.md`.
5. **Q5 — 80% branch coverage, a scoped 100% on the hazard modules, and Compose end-to-end on
   every Bolt merge.** *Cost accepted:* every merge pays a container build and boot. *Rejected:*
   running Compose only at the skeleton gate and at the end (a container-level regression would
   surface many Bolts after the one that caused it, with no bisect signal and nobody watching a
   dashboard); dropping the percentage entirely in favour of hazard-module tests alone (nothing
   would then stop coverage drifting toward zero on the modules nobody finds interesting).
6. **Q6 — Stay local.** No remote, no pull-request gate, no off-machine backup. *Cost accepted:*
   the work exists on one machine, and the local merge gate is the only enforcement point the
   project has — which is precisely why the gate must carry verbatim output. *Rejected:* adding a
   free private remote, which would have un-skipped `ci-pipeline` and moved the gate off the
   developer machine.
7. **Q7 — Normalise after parity sign-off.** See the section above.
8. **Q8 — Advisories block at High and above, with a recorded exception.** *Cost accepted:* a
   recorded exception is a real judgement call each time it is used, and a lazy one weakens the
   gate. *What it buys:* work does not stop the day an unfixable transitive advisory lands, and the
   exception leaves a trace — package, advisory id, reason, owning Bolt — consistent with the
   `project.md` correction that any finding carried past a gate needs a named owner. *Rejected:*
   blocking with no exception path (stops all work on an advisory nobody can fix); advisory-only
   (becomes a notification nobody reads).

## Reviewer objections adopted without asking

Sixteen positions were taken from the three blind reviews without putting them to the human. The
two tables at the head of `practices-discovery-questions.md` are the record; the admission test
applied was the same in every case: **two or three reviewers converged, or no cost was identified
on the other side, so asking would have been ceremony rather than a decision.**

Two are worth calling out because they changed a claim rather than adding one:

- **The error envelope** is not a preference. The four source routes share `{error: '<sentence>'}`
  plus `issues: [{path, message}]`, with statuses 400/403/409/413/503, and `editor-workflow.ts`
  branches on 409 and reads `result.issues`. Adopting FastAPI's defaults produces a system that
  passes every check on the gate list while field highlighting and conflict recovery are quietly
  broken. It is the highest-probability silent regression in this migration, and the draft did not
  mention it.
- **The `camelCase` wire format was presented as a choice and is not one.** It is fixed by the
  ported components that read it and by JSON already persisted in the content columns.

One objection was adopted with a scope correction: the devsecops reviewer proposed the
initial-owner provisioning mechanism and correctly noted it belongs in `team-practices.md` rather
than `discovered-rules.md`, because the human stated the *prohibition* (no default credential) and
not the *mechanism*. That distinction is applied throughout: the "no secret through Docker
`ARG`/`ENV`" constraint went to `discovered-rules.md` § `## Forbidden` because it was stated
verbatim in the original brief, while the BuildKit secret-mount mechanism that satisfies it stayed
in `team-practices.md`.

**No reviewer objection was rejected.** Where two reviewers overlapped (the coverage instrument,
the gate composition, the `S` ruleset) the stronger formulation was taken. The single-owner rule
remains deliberately absent from `discovered-rules.md`: it is already on disk in `project.md`
under `## Corrections` and repeating it would duplicate at promotion.

## Sources

- `aidlc/spaces/default/codekb/Chiku_website/technology-stack.md`
- `aidlc/spaces/default/codekb/Chiku_website/code-quality-assessment.md` (§ *Hazard index*,
  § *The dense single-line style*, § *Testing — total absence*)
- `.claude/scopes/aidlc-runtime-split-migration.md`
- `aidlc/spaces/default/intents/260924-chiku-website-migration/aidlc-state.md`
- `aidlc/spaces/default/memory/org.md`, `aidlc/spaces/default/memory/team.md` (empty),
  `aidlc/spaces/default/memory/project.md`
- `contributions/aidlc-quality-agent.md`, `contributions/aidlc-developer-agent.md`,
  `contributions/aidlc-devsecops-agent.md` — three independent blind reviews of the draft
- `practices-discovery-questions.md` — the human interview and its eight rulings
- The dispatch brief for this stage, for the established facts recorded as given: brownfield
  status, the two-runtime target, the registry-verified Python tool versions, the git state, the
  `ci-pipeline` skip, and the four human confirmations (dependency-first sequencing, gated
  skeleton, no deadline, zero recurring cost, parity rule).

## Assumptions & Open Questions

- **Assumed:** the registry-verified versions supplied in the brief (pytest 9.1.1, httpx 0.28.1,
  ruff 0.16.8, mypy 2.3.1, uv 0.10.0, Next.js 16.3.6, React 19.3.0, Python 3.14) are current and
  installable. They were taken as given and not re-verified in this stage.
- **Assumed:** the `madhavi-tripathi/` findings in the two knowledge-base files still hold at
  commit `d7f1859`. The scan was taken at `50856de` on the same day; no application code has been
  written since.
- **Assumed:** the exact flag spellings in the merge-gate command list (`uv export` options,
  `pip-audit`, `pnpm audit --prod --audit-level high`) are correct. None was executed in this
  stage. Pinning them is a named Bolt 1 deliverable, and what was affirmed is the gate entry, not
  the flag string.
- **Closed:** all ten decisions the draft left open (D1–D10). Eight were ruled on by the human at
  the interview; D4's unit was replaced by the accepted file-as-unit objection before the question
  reached the human; D9 was settled by the concrete `ruff`/`mypy` configuration two reviewers
  supplied, since the draft's own "strictest reasonable defaults" claim already answered it.
- **Open, with a named owner:** whether the six-flag editor state machine lands in the frontend or
  the backend. If it lands in the frontend, a browser check (Playwright) becomes the only possible
  verification of it and moves from optional to mandatory. Owner: `domain-design`.
- **Open:** whether the zero recurring-cost rule and the parity rule bind only this project or
  every future intent in this space. Both are written as project-scoped (`discovered-rules.md` →
  `project.md`). The interview did not put the question.
- **Open:** whether `change_control: strict` implies any practice this stage should record
  explicitly. `team.md` carries a `## Change Control` heading that this stage was not asked to
  fill, and `practices-promote` replaces only the five sections `team-practices.md` carries, so it
  has been left alone.
- **Recorded at the gate:** the site owner affirmed all four artifacts on 2026-09-24. The
  orchestrator invalidated two earlier summary receipts before this one — once by re-saving an
  artifact in a later turn than the receipt, and once by writing the confirmation answer twice into
  the same slot — so the same confirmation was put to the human three times. Neither fault changed
  any content; both are recorded so the repetition in the audit trail reads as a tooling error
  rather than as a reopened decision.
