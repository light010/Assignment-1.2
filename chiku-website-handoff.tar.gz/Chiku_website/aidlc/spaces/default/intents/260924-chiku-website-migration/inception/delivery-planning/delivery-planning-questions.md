# Delivery Planning — Questions

Upstream: `inception/units-generation/unit-of-work.md`, `…/unit-of-work-dependency.md`,
`inception/contract-design/contract-summary.md`,
`inception/requirements-analysis/requirements.md`,
`aidlc/spaces/default/memory/{team,project,org}.md`.

The human asked for the design stages to be batched with one consolidated
approval before code generation, so nothing here was put to them interactively.
Each answer is drawn from an already-confirmed decision or from an affirmed
practice, with its source named.

---

## Q1. Way of working — branch and merge strategy for Construction

**Resolved from `team.md` § Way of Working.** Trunk-based on `main`. Each build
pass runs in its own short-lived worktree branch based on `main` and squash-merges
back as a single commit named for that pass. No remote, no pull-request gate —
the local merge gate is the only enforcement point that will exist, and its
verbatim output is pasted into each approval.

[Answer]: Resolved from affirmed practice — trunk-based, worktree per pass, squash-merge to `main`, local gate only.

---

## Q2. Does the first build pass run as a walking skeleton?

**Resolved.** Yes. The active scope declares `skeleton: on`, and `team.md`
requires the first pass to be solo, gated, and explicitly approved before any
other runs. It must cross **both runtimes and the container boundary** — proving
the language boundary, the session contract and the storage port on a thin slice,
because those three are the things most likely to be wrong and cheapest to correct
early.

[Answer]: Resolved — yes, gated and solo, and it must run inside Compose rather than against hand-started processes.

---

## Q3. Sequencing model

**Resolved from the confirmed answer at scope definition.** Dependency-first:
follow the technical graph so nothing is built on a boundary that later moves.

A scoring model such as WSJF — which ranks work by value and urgency divided by
size — was considered and is **not** used. It needs value and time-criticality
inputs to differentiate options, and here there are none: one owner, no deadline,
no external users, and no feature that ships before the whole thing does. Applying
it would produce arbitrary numbers dressed as analysis.

[Answer]: Resolved — dependency-first. No scoring model; the inputs one would need do not exist here.

---

## Q4. Parallel or serial execution?

**Resolved.** Serial. The work is solo, so the four parallel opportunities the
dependency graph offers are real topologically but not available in practice.
They are recorded anyway, because they are what would change first if a second
person joined.

[Answer]: Resolved — serial, because there is one person. The graph's parallelism is recorded but unused.

---

## Q5. Approval gates after the skeleton

**Resolved from `team.md` § Walking Skeleton.** After the first pass ships, the
orchestrator fires the ladder prompt and the human chooses whether the remaining
passes run autonomously or each gate individually. That choice is theirs to make
at that moment and is deliberately **not** pre-committed here.

[Answer]: Resolved — not decided here. The ladder prompt after pass 1 is the human's choice.

---

## Q6. How is the shared frontend code ordering resolved?

**This stage owns it.** Units-generation finding R-03 recorded that shared
presentation code — the design system, the CSS, the eleven used vendored
components — is carried by whichever of `public-site` or `owner-editor` lands
first, with **no dependency edge encoding that**, so nothing in the topology
prevented a collision.

**Resolved by sequencing rather than by a new unit:** `public-site` is scheduled
**before** `owner-editor`, and carries the shared presentation code. The editor
consumes it. The public site is the better carrier because it exercises the shared
components on the parity-critical surface, where a mistake is caught by the DOM
diff against recorded fixtures rather than by eye.

[Answer]: Resolved — `public-site` before `owner-editor`; the public site carries the shared code. No thirteenth unit.
