# Initiative Brief — chiku-website migration

**Upstream:** `ideation/intent-capture/intent-statement.md`,
`ideation/intent-capture/stakeholder-map.md`,
`ideation/scope-definition/scope-document.md`,
`ideation/scope-definition/intent-backlog.md`.

**Recommendation: GO.** Close Ideation, open Inception. [Q2]

## Intent and problem

An existing academic website cannot run anywhere but its current host, and its
sign-in, content and uploaded media all depend on a third party's account system.
At the same time, the application's logic needs to live in Python so future
backend work, workers and agent capabilities have one home. Both halves are the
problem; the site is being moved off its current host for a concrete reason.
[intent-statement § Problem Statement, § Initiative Trigger]

## Who it is for

Public visitors read the site and must perceive no change. Exactly one person —
the site owner — edits it, and must lose no editing capability. The content,
title and visual identity belong to Madhavi Tripathi and stay exactly as they
are; `chiku` names the project folder, not a rebrand.
[intent-statement § Target Customer, stakeholder-map]

## Market validation

Not applicable and not performed. `market-research` was marked SKIP by the
composed scope: this is one person's existing website being rebuilt, not a
product entering a market.

## Scope boundary

Rebuild across a strict language boundary, containerise, verify locally, and
produce a costed cloud plan — with nothing deployed. Fifteen in-scope
capabilities (I1–I15) and nine explicit exclusions (O1–O9) are enumerated in the
scope document. Sequencing is dependency-first, behind a gated walking-skeleton
Bolt. There is no deadline. [scope-document]

The parity rule is what makes the headline success condition checkable: layout
and content reproduce as they are today, while accessibility and semantics may
improve freely without moving anything visually.
[scope-document § The parity rule]

## Feasibility and risk

`feasibility` was marked SKIP: the approach is a standard pattern and every
dependency version was registry-verified before the workflow started. The one
genuine viability question — whether the topology fits Google Cloud's free tier —
is plan-only and belongs to infrastructure-design, which carries an un-skip
trigger if the envelope does not fit.

Eight risks are recorded, and **all eight are to be actively mitigated** rather
than accepted. [Q1]

| # | Risk | Mitigation |
|---|---|---|
| RK1 | Authentication is newly built; the replaced platform auth cannot be fallen back on. | Maintained libraries only; explicit tests that a direct unauthenticated API call is rejected, including CSRF and session-forgery cases. |
| RK2 | Cloud adapters ship unverified against real Google services. | Same contract suite as SQLite; labelled unverified in the README and the deployment plan. |
| RK3 | The hard zero-cost target is unproven until images exist. | Measure compressed image sizes at build-and-test; image cleanup policy; serve static assets and media from Cloud Storage, not through Cloud Run. |
| RK4 | Reviewer finding R-02 is open: the zero-cost condition is unmeasurable while nothing is deployed. | Close it at nfr-requirements and infrastructure-design as a checkable property of the plan. |
| RK5 | Parity across a double change — framework and runtime both change at once. | Route-and-behaviour parity checklist built from the discovery inventory, verified in-browser at desktop and mobile. |
| RK6 | No production content exists; hosted D1 and R2 are not in the export. | Treat the seed as canonical per the original handoff document; record that no data migration is owed. |
| RK7 | The upload and media path is intricate. | Port against focused per-rule tests including negative cases. |
| RK8 | Container verification depends on the Docker daemon. | Daemon is currently up; if it stops, report container checks as blocked, never as skipped, and complete everything else. |

## Concept visuals

None produced. `rough-mockups` and `refined-mockups` were both marked SKIP: the
existing interface is being preserved, so the running site is the design spec.

## Team plan

`team-formation` was marked SKIP. Solo delivery; the workflow decision-maker is
the sole authority over scope and priority, and reporting happens at approval
gates only. [stakeholder-map § Communication Requirements]

## Go / no-go

**GO.** [Q2] Every Ideation deliverable is complete and approved, the scope
boundary is explicit, the sequencing is settled, and all eight known risks carry
mitigations. Nothing is blocked. The one open reviewer finding (R-02) has a named
owner stage rather than being left to drift.

## Assumptions & Open Questions

- The reason for leaving the current host is confirmed but undescribed, so no
  shutdown date can be planned against; recorded as no deadline. [assumption]
- The zero recurring-cost target remains unproven and will stay so until images
  are built and measured. [assumption]
- The Firestore and Cloud Storage adapters will be delivered unverified against
  real Google services by explicit choice. [assumption]
