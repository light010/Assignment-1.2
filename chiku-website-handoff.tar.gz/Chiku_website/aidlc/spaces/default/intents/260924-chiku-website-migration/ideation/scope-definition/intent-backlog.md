# Intent Backlog — chiku-website migration

**Upstream:** `ideation/intent-capture/intent-statement.md` and
`ideation/scope-definition/scope-document.md`. Every item below traces to an
in-scope capability (I1–I15) in the scope document.

Prioritised with **MoSCoW**. Ordering within Must-have follows the confirmed
dependency-first sequence. [Q1] These are proto-Units: `units-generation` owns
the authoritative decomposition and may split or merge them.

## Must have

| ID | Proto-Unit | Delivers | Depends on | Why Must |
|---|---|---|---|---|
| B0 | Walking skeleton | One thin end-to-end slice through both runtimes: sign in → edit one field → save → publish → visible on the public page. Deliberately shallow in every dimension. | — | The scope declares `skeleton: on`. Proves the language boundary, the session contract and the storage port on a thin slice before anything is built on them. Solo and gated. |
| B1 | Storage port + SQLite adapter | `ContentStore`, `AssetStore` and the admin-account store, with SQLite behind them. Optimistic-concurrency write, revision retention (30 draft / 20 publish, baselines kept), durable across container recreation. | B0 | I1. Everything else reads or writes through it, so its shape must settle first. |
| B2 | Authentication and sessions | Argon2id password hashing, signed HttpOnly session cookie, CSRF double-submit, login rate limiting, `create-admin` CLI. No default credentials. | B1 | I2. Every protected operation depends on it, and it is the single most security-sensitive surface. |
| B3 | Content schema and API | Pydantic content model as the sole authoritative schema plus the seeded content; read, draft save, publish, 409 conflict, revision history and restore. Frontend types generated from the OpenAPI document. | B1, B2 | I3, I4, I5. The contract the whole frontend consumes. |
| B4 | Uploads and media serving | Magic-byte validation for the seven accepted types, per-type size caps, server-side responsive image variants, byte-range responses, and the published-only media access rule. | B1, B2, B3 | I6. Carries real attack surface and the most intricate preserved logic. |
| B5 | Public frontend | All public routes and sections, the 3D scene, server-side rendering fed by the Python API, plus metadata, Open Graph, JSON-LD, sitemap and robots. | B3 | I7, I9. The half of the product visitors actually see. |
| B6 | Owner editor | Every existing editor tab, draft autosave, local draft recovery, revision history, private preview, publish, and the existing WebMCP `stage_academic_profile` tool. | B3, B4 | I8, I10. The management capability the owner must not lose. |
| B7 | Containers and Compose | Two images (Next.js, FastAPI), non-root, locked dependencies, health checks, graceful shutdown, named volume for content and media, no source mounts, no development servers. | B5, B6 | I11 and success condition S3. |

## Should have

| ID | Proto-Unit | Delivers | Depends on | Why Should |
|---|---|---|---|---|
| B8 | Firestore and Cloud Storage adapters | Both adapters implemented behind the existing port and run against the same contract test suite as SQLite. Shipped code-complete and marked unverified against real Google services. | B1 | I12. Confirmed in scope, but nothing in this piece of work executes them against a real backend, so they cannot block the verified deliverable. |
| B9 | Google Cloud deployment plan | Chosen topology, region, usage assumptions, a costed table whose every line traces to a current official free-tier source, prerequisites, deploy and rollback commands. | B7, B8 | I13 and success condition S4. Needs B7 first so image sizes are measured, not estimated. Closes reviewer finding R-02. |
| B10 | Dead-code removal | The 44 unimported `components/ui/*` files and the 11 unimported dependencies do not cross into `chiku-website/`. | B5, B6 | I14. Naturally a consequence of only porting what is imported, rather than a separate deletion pass. |

## Could have

| ID | Proto-Unit | Delivers | Depends on | Why Could |
|---|---|---|---|---|
| B11 | Carousel keyboard-focus fix | Replace native `disabled` on the achievement and update carousel controls with guarded `aria-disabled`, so focus is not dropped to the page body at an endpoint. | B5 | I15. Agreed at intent capture and small, but it is the only user-visible behavioural change in the whole migration, so it is isolated rather than folded into B5. |
| B12 | Accessibility and semantics improvements | Heading order, labels, focus handling, contrast and reduced-motion support corrected wherever they fall short, without moving anything visually. | B5, B6 | Authorised by the parity rule at Q6, but unbounded by nature — it is taken where it is cheap and correct, never at the cost of parity. |

## Won't have (this time)

| ID | Item | Recorded because |
|---|---|---|
| B13 | Deploying to Google Cloud | O1. The plan is the deliverable; the deployment is not. |
| B14 | Bundle-size work on the ~560 kB three.js chunk | O5. Pre-existing and explicitly left alone. |
| B15 | Internationalisation | O6. |
| B16 | Multi-editor accounts or tiered permissions | O7. Exactly one owner edits. |
| B17 | A CI/CD pipeline | O4. `ci-pipeline` is skipped while the project has no remote. |

## Value stream

```
                     ┌──────────────────────────────────────────┐
  owner edits  ──▶   │  B6 editor (Next.js, renders only)       │
                     └───────────────────┬──────────────────────┘
                                         │ HTTP, same origin
                     ┌───────────────────▼──────────────────────┐
                     │  B2 auth · B3 content API · B4 uploads   │
                     │  (Python — every application decision)   │
                     └───────────────────┬──────────────────────┘
                                         │
                     ┌───────────────────▼──────────────────────┐
                     │  B1 storage port → SQLite (B8: cloud)    │
                     └───────────────────┬──────────────────────┘
                                         │ published content
                     ┌───────────────────▼──────────────────────┐
  visitor reads ◀──  │  B5 public frontend (SSR from the API)   │
                     └──────────────────────────────────────────┘
                       all of it packaged by B7, costed by B9
```

The value only reaches a visitor when an owner's edit travels the full loop, which
is exactly why B0 exercises that loop end to end before anything is built deeply.

## Assumptions & Open Questions

- B8 is classified Should rather than Must because it is confirmed in scope yet
  cannot be verified against a real backend in this piece of work. If that
  classification is wrong, it changes nothing about whether it gets built — only
  what happens if time runs short, and there is no deadline. [assumption]
- B12 has no natural completion criterion. It is bounded here by "cheap, correct,
  and visually invisible" rather than by a WCAG conformance claim, because
  conformance cannot be asserted without an audit that is not in scope.
  [assumption]
- The split between B5 and B6 assumes the public site and the editor can be built
  against the same generated API client without one blocking the other.
  `units-generation` will confirm or redraw that line. [assumption]
