# Intent Statement — chiku-website migration

## Problem Statement

The existing academic website cannot run anywhere other than its current host, and
its sign-in, its content and its uploaded media all depend on a third party's
account system. [Q1]

Separately and at the same time, the application's logic needs to move to Python,
so that future backend work, background workers and agent capabilities have a
single home rather than being spread across two languages. [Q1]

Both of these are the problem: portability and control on one side, architectural
direction on the other. Neither alone would justify the work. [Q1]

Concretely, the current implementation reaches the user through a Next.js
front end whose server layer also owns authentication, validation, persistence
and uploads; the migration is to a front end that renders only, and a single
Python service that owns every application decision. [desc]

## Target Customer

**Public visitors** read the website. They are the larger audience and the group
whose experience must not regress. [Q2]

**The site owner** is the only person who edits the website. There is exactly one
editor; there are no additional editors and no tiered editor-versus-publisher
permission levels in scope. [Q2]

The website's content, title and visual identity belong to Madhavi Tripathi and
stay exactly as they are; `chiku` names the project folder, not a rebrand. [Q7]

The pain being relieved is different for each group. Visitors get no new
capability at all — for them, success is that nothing they can perceive changes.
The owner gets the same editing capability she has today, but resting on
infrastructure that is not tied to one host's account system. [Q1] [Q2] [Q3]

## Success Metrics

Success is defined by four conditions, all of which must hold. [Q3]

| # | Condition | How it is measured | Source |
|---|---|---|---|
| S1 | Behavioural parity | Every public route and every owner-editable field that exists today still exists and still behaves the same; the owner can edit and publish everything she can edit and publish today. | [Q3] |
| S2 | Clean language boundary | No application logic remains in the front-end layer: authentication, authorization, authoritative validation, persistence and uploads are all enforced in Python, and a request that bypasses the front end is still rejected. | [Q3] [desc] |
| S3 | Containers proven end to end | Both container images build, and the complete flow is exercised through them with no source mounts and no development servers. | [Q3] [desc] |
| S4 | Reviewed cloud plan, nothing deployed | A Google Cloud deployment plan exists, its free-tier figures are verified against current official sources, and no resource is provisioned and nothing is deployed. | [Q3] [desc] |

A fifth condition governs cost. The target is **zero recurring infrastructure
charges**, held as a hard target rather than a near-zero one. [Q4]

Two items are explicitly not success metrics. The accessibility defect in the
achievement and update carousels is to be fixed as part of this work, and is
therefore a deliverable rather than a measure. The oversized illustration bundle
is to be left alone and recorded as a known issue. [Q8]

## Initiative Trigger

The website is being moved off its current host for a concrete reason. [Q5]

This is not an exploratory exercise and not an open-ended modernisation: there is
a real reason to leave, which makes portability the binding constraint rather
than a nice-to-have. [Q5] [Q1]

## Initial Scope Signal

**Workflow-selected scope:** `runtime-split-migration`. [scope]

**User-confirmed product boundary:** rebuild the existing website across a
language boundary, containerise it, verify it locally, and produce a cloud
deployment plan — with nothing deployed, no new product features, and no
continuous-integration or delivery platform built. The user confirmed this is
exactly the intended boundary. [Q9]

The workflow-selected scope and the user-confirmed boundary agree. [scope] [Q9]

## Decision Authority and Reporting

The user is the sole decision-maker for scope and priority, and reporting happens
at each approval gate only, with no separate status updates. [Q6]

## Assumptions & Open Questions

- The reason for leaving the current host was confirmed as concrete but was not
  itself described, so no deadline, cost ceiling or platform-shutdown date is
  known. If one exists it would change how thoroughness is traded against speed.
  [assumption]
- The relationship between the workflow's decision-maker and the site owner is
  not established. The decision-maker decides everything including content and
  branding, so no separate content sign-off step is planned. [assumption]
- Whether the hard zero recurring-cost target is achievable has not been proven.
  The supporting cost estimate available at intent time was corrected once
  already for using uncompressed image sizes and ignoring image-layer
  deduplication. Actual figures must be measured, not estimated, before this
  target can be reported as met. [assumption]
