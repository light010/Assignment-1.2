# Intent Capture — Questions

## Sources

- [desc] Initial description: "Migrate the existing Next.js/Cloudflare-Workers academic website in madhavi-tripathi/ into a new chiku-website/ with a strict language boundary: Next.js (React/TypeScript) is frontend-only; a single cohesive Python FastAPI backend owns ALL application logic \u2014 authentication, authorization, authoritative validation, business rules, persistence, uploads, publishing. Replace ChatGPT platform header auth with password+argon2id sessions in Python. Replace Cloudflare D1/R2 with a narrow ContentStore/AssetStore port: SQLite+volume verified locally, Firestore+GCS adapters for a future Google Cloud Run free-tier deployment (plan only, no provisioning). Preserve all public routes, the full owner editor (draft/publish, revision history, uploads, preview), seed content, branding, SEO metadata/JSON-LD/sitemap/robots, and the existing WebMCP stage_academic_profile browser tool. Deliver Dockerfiles for both runtimes plus a compose file and verify the containerized flow end to end. Reuse-first: prefer maintained public libraries over custom code. Discovery is already complete \u2014 full inventory, route/data/content model, dead-code findings, pre-existing defects, host tooling and registry-verified dependency versions are at /private/tmp/claude-501/-Users-praka-Workspace-Projects-Chiku-website/252bae3e-1f47-4da7-99d5-f5d725d19282/scratchpad/discovery.md. Read that file first; do not re-run discovery."
- [scope] Workflow-selected scope: `runtime-split-migration`.

---

## Q1. What is the business problem this migration solves?

The current site is tied to one hosting platform: it executes on Cloudflare Workers
through `vinext`, stores content in Cloudflare D1, stores media in Cloudflare R2,
and — critically — gets the signed-in owner's identity from HTTP headers that only
ChatGPT's site hosting injects. Which of these best describes why that is worth
fixing now?

A. Portability and control — the site cannot run anywhere but its current host, and sign-in, content and media all depend on a third party's account system.
B. Architecture direction — application logic must live in Python so future backend, worker and agent work has one home.
C. Both A and B.
D. Not yet defined — the migration is exploratory and the problem statement can stay broad.
X. Other (please specify)

[Answer]: C. Both A and B.

---

## Q2. Who uses this website, and who administers it?

This decides how much the management side must handle — one owner editing her own
profile is a very different design from several editors with different permissions.

A. Public visitors read it; exactly one person (the site owner) edits it.
B. Public visitors read it; two or three trusted people edit it, all with equal rights.
C. Public visitors read it; several editors with different permission levels (e.g. editor vs publisher).
D. Not yet defined — assume one owner for now and revisit if that changes.
X. Other (please specify)

[Answer]: A. Public visitors read it; exactly one person (the site owner) edits it.

---

## Q3. What does success look like for this piece of work? (select all that apply)

A. The migrated site looks and behaves the same as today for a public visitor, and the owner can still edit and publish everything she can edit today.
B. No application logic remains in the Next.js layer — authentication, validation, persistence and uploads are all enforced in Python.
C. Both containers build and the whole flow is proven end to end locally, with no source mounts and no development servers.
D. A reviewed Google Cloud deployment plan exists with verified free-tier figures — but nothing is deployed.
X. Other (please specify)

[Answer]: A, B, C, D

---

## Q4. Verified cost finding: "zero recurring charges" is not achievable as specified. How should that target be restated?

Your brief set a target of **zero** recurring Google Cloud charges. I verified the
current official allowances today, and one line item defeats that target regardless
of how the code is written: **Artifact Registry gives 0.5 GB of free storage per
billing account**, and two container images plus retained rollback images
realistically exceed it. Expected cost is roughly **$0.10–$0.30/month** — mostly
Artifact Registry storage, plus a possible small Cloud Run egress overage, because
Cloud Run's free internet egress is only **1 GiB/month** (Cloud Storage gets 100 GB).
Everything else — Cloud Run compute, Firestore, Cloud Storage, Cloud Build, Logging,
Secret Manager — fits comfortably inside always-free allowances at the expected traffic.

A. Accept a near-zero target (under about $1/month) and optimise image size and image retention to keep it as low as possible.
B. Hold the hard zero target — investigate avoiding Artifact Registry entirely, even if that constrains the deployment approach.
C. Accept near-zero, and additionally require a documented budget-alert / spend-cap setup in the plan so a surprise bill is caught early.
D. Not yet defined — record the finding and decide when the deployment plan is actually reviewed.
X. Other (please specify)

[Answer]: B. Hold the hard zero target — investigate avoiding Artifact Registry entirely, even if that constrains the deployment approach.

---

## Q5. What triggered this initiative now?

A. The site is being moved off its current host for a concrete reason (cost, control, a platform change, or the host going away).
B. Groundwork — the architecture needs to be Python-first before further features or agent capabilities are built.
C. A learning / modernisation exercise with no external deadline.
D. Not yet defined.
X. Other (please specify)

[Answer]: A. The site is being moved off its current host for a concrete reason (cost, control, a platform change, or the host going away).

---

## Q6. Who decides scope and priority, and how do you want to be kept informed?

A. You decide everything; report at each approval gate only — no separate status updates.
B. You decide everything; also give a short written progress summary at the end of each phase.
C. Someone else (for example the site's owner) must sign off on content, branding or user-visible changes before they land.
D. Not yet defined.
X. Other (please specify)

[Answer]: A. You decide everything; report at each approval gate only — no separate status updates.

---

## Q7. Is "chiku" a rebrand, or just the new project folder name?

The destination folder is `chiku-website/`, but every piece of content, the site
title, the header monogram and all metadata belong to **Madhavi Tripathi**. I do
not want to guess at this.

A. Just the folder / project name — the site's public branding, title and content stay exactly as they are today.
B. It is a rebrand — the public site should be renamed, and I will supply the new branding.
C. Not yet defined — keep the existing branding for now and treat a rename as separate future work.
X. Other (please specify)

[Answer]: A. Just the folder / project name — the site's public branding, title and content stay exactly as they are today.

---

## Q8. Two defects already exist in the current site. Fix them, or preserve them as-is?

Both were documented by a previous inspection of the *existing* site, so neither is
caused by this migration:
1. **Keyboard accessibility** — the achievements and updates carousels use native
   `disabled` on their Next/Previous buttons, so on reaching the last item keyboard
   focus drops to the page body and arrow-key navigation stops working.
2. **Bundle size** — the production build emits a chunk over 500 kB; the minified
   three.js illustration renderer is roughly 560 kB before compression.

A. Fix the keyboard accessibility defect as part of this work; leave the bundle size alone.
B. Fix both.
C. Fix neither — preserve current behaviour exactly and record both as known issues for later.
D. Not yet defined.
X. Other (please specify)

[Answer]: A. Fix the keyboard accessibility defect as part of this work; leave the bundle size alone.

---

## Q9. Does the workflow-selected scope match your intended product boundary?

The workflow is running under the scope `runtime-split-migration`, which treats this
as: rebuild the existing site across a language boundary, containerise it, verify it
locally, and produce a cloud deployment *plan* — with nothing deployed, no new
product features, and no CI/CD platform built.

A. Yes — that is exactly the boundary. Confirm it.
B. Mostly, but the boundary should also include something I will specify.
C. No — the intended boundary is different; I will describe it.
D. Not yet defined.
X. Other (please specify)

[Answer]: A. Yes — that is exactly the boundary. Confirm it.

---

## Consolidated Summary Confirmation

- Looks correct
- Request changes

[Answer]: Looks correct

---

## Assumption Confirmation

Both deliverables carry assumptions that could not be grounded in a confirmed
answer. They are listed here in full:

1. **No deadline or cost ceiling is recorded.** The trigger was confirmed as a
   concrete reason to leave the current host, but the reason itself was not
   described, so no shutdown date, deadline or cost ceiling is known. If one
   exists, it would change how thoroughness is traded against speed.
2. **The decision-maker and the site owner may or may not be the same person.**
   The editing role and the branding ownership were confirmed through different
   questions. This matters only if content or branding decisions later need a
   second party's approval — and the confirmed reporting answer says they do not.
3. **The hard zero recurring-cost target is not yet proven achievable.** The
   supporting estimate was already corrected once for using uncompressed image
   sizes and ignoring image-layer deduplication. Real figures must be measured
   before this target can be reported as met.
4. **No escalation path is recorded**, because no question elicited one.
5. **No traffic figures, geography or device mix are known** for public
   visitors. These feed the cost plan, where they must appear as stated
   assumptions rather than as measurements.

A. Accept assumptions
B. Convert to follow-up questions

[Answer]: A. Accept assumptions
