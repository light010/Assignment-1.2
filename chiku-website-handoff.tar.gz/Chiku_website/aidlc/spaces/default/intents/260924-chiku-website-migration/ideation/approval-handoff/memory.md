<!-- INVARIANT: examples are single-line HTML comments so a fresh template parses to total=0 (MEMORY_EMPTY). Do NOT un-comment or split across lines. t100 guards this. -->
> This file is kept up to date automatically while the stage runs. Add observations at the review step, not by editing here directly.

## Interpretations
<!-- example: 2026-05-29T10:14:32Z — chose REST over GraphQL; the consuming team only needs CRUD, revisit if subscriptions land -->

- 2026-09-24T14:38:56Z — the stage prose asks about market validation, mob staffing, budget commitment and mockup fidelity, all of which belong to stages this composed scope marked SKIP. Rather than asking dead questions or silently dropping the topics, the initiative brief states for each one why it is absent and which composer decision removed it, so a reader can tell an intentional omission from an oversight.
## Deviations
<!-- example: 2026-05-29T10:14:32Z — skipped the optional caching layer the stage prose suggested; the dataset is small enough that it adds risk -->

- 2026-09-24T14:38:56Z — asked 2 questions instead of the Standard depth band's 5-8. The stage's other topics were already settled (sole decision-maker, hence stakeholder agreement) or inapplicable (skipped stages), and stage-protocol.md forbids re-asking an answered question. Depth bands are explicitly guidelines, not caps, and padding would have been noise.
- 2026-09-24T14:38:56Z — the phase-boundary check records three PASS WITH CAVEAT results rather than forcing a binary. Two of the three (the unmeasurable cost condition, the unowned reviewer findings) are real gaps the human accepted at Gate 1, and flattening them to PASS would have erased the evidence that they were chosen rather than missed.
## Tradeoffs
<!-- example: 2026-05-29T10:14:32Z — picked TDD over BDD this run; the team is unit-first and the domain is well-understood -->

- 2026-09-24T14:38:56Z — recorded in the decision log which reviewer findings have a named owner stage and which do not. R-02 goes to nfr-requirements and infrastructure-design; R-01, R-04, R-05 and the nine claim-sources findings have no owner and will not close on their own. Naming that explicitly makes their persistence a visible choice instead of drift.
## Open questions
<!-- example: 2026-05-29T10:14:32Z — confirm the retention window with compliance before the next stage hardens the schema -->
