# Scope Definition — Questions

Upstream: `ideation/intent-capture/intent-statement.md` (confirmed problem, four
success conditions, hard zero-cost target, and the confirmed product boundary).

Questions already answered at intent-capture are not re-asked here. The confirmed
boundary — rebuild across the language boundary, containerise, verify locally,
produce a cloud plan only — is taken as settled.

---

## Q1. After the walking-skeleton Bolt, how should the remaining work be sequenced?

The scope runs with `skeleton: on`, so Bolt 1 is a thin end-to-end slice through
both runtimes (sign in → edit one field → save → publish → see it on the public
page) before anything else. That much is fixed. The question is how to order what
follows.

A. Risk-first — take the scariest things next: authentication hardening, upload validation, the optimistic-concurrency conflict path. Failures surface early when they are cheap to fix.
B. Value-first — get the public site fully correct next (all sections, SEO, the 3D scene), then complete the editor. The visible half is done sooner.
C. Dependency-first — follow the technical graph: storage port → auth → API surface → public frontend → editor → containers. Least rework, least dramatic progress.
D. Not yet defined — decide at delivery-planning once the units are known.
X. Other (please specify)

[Answer]: C. Dependency-first — storage port → auth → API surface → public frontend → editor → containers.

---

## Q2. Is there a hard deadline or a date the current host stops working?

Intent capture recorded that the move off the current host has a concrete reason,
but the reason itself was never described, so no date is on record. This directly
changes sequencing: a fixed date argues for value-first and a deliberately thin
first cut.

A. No deadline — take the time needed to do it properly.
B. There is a date, and I will tell you what it is.
C. No fixed date, but sooner is materially better — bias toward shipping a working site early.
D. Not yet defined.
X. Other (please specify)

[Answer]: A. No deadline — take the time needed to do it properly.

---

## Q3. How far should the Firestore and Cloud Storage adapters go in THIS piece of work?

You chose a narrow storage port with SQLite as the verified local default and
Firestore + Cloud Storage as the Cloud Run path. Since nothing is deployed in this
scope, there is a real question about how much of the cloud half to build now.
Note that verifying Firestore locally needs Google's official emulator image
(~1 GB, Java-based), which makes the test suite noticeably heavier.

A. Implement both adapters and verify them against the Firestore emulator and a fake Cloud Storage server, so the cloud path is proven before it is ever deployed.
B. Implement both adapters and cover them with the same contract test suite as SQLite, but skip the emulator — the adapters ship code-complete and honestly marked as unverified against real services.
C. Design the port now and implement only SQLite; write the cloud adapters in the future intent that actually deploys.
D. Not yet defined.
X. Other (please specify)

[Answer]: B. Implement both adapters against the shared contract test suite, no emulator; ship code-complete and honestly marked unverified against real Google services.

---

## Q4. Should the unused starter code be deleted, or carried across?

Discovery found that only 11 of the 55 `components/ui/*` files are imported by
application code — roughly 44 files and 5,000 lines are unused scaffolding from
the original starter template — along with 11 npm dependencies that nothing
imports (recharts, cmdk, date-fns, react-day-picker, input-otp,
react-resizable-panels, vaul, sonner, react-hook-form, @hookform/resolvers,
@shadcn/react).

A. Delete them — carry across only what the application actually imports. Smaller install, smaller image, less to audit.
B. Carry everything across unchanged — keep the migration diff purely structural and delete later as separate work.
C. Delete the unused dependencies but keep all the component files, in case they are wanted later.
D. Not yet defined.
X. Other (please specify)

[Answer]: A. Delete both the unused component files and the unused dependencies.

---

## Q5. Is there anything you want recorded as explicitly OUT of scope?

The scope document's job is partly to stop creep later. Beyond what is already
excluded (deployment, provisioning, new product features, a CI/CD platform, the
560 kB bundle defect), select anything else that should be written down as out of
scope (select all that apply).

A. Any change to the public visual design — no redesign, no new sections, no layout changes beyond what the migration forces.
B. Any change to the seeded content itself — no new publications, no rewritten copy, no updated citation counts.
C. Multi-language / internationalisation of the site.
D. Nothing further — what is already excluded is enough.
X. Other (please specify)

[Answer]: C. Multi-language / internationalisation of the site.

---

## Q6. Follow-up — contradiction to resolve: does "preserve" mean pixel-identical, or is measured improvement in scope?

Two confirmed inputs pull in different directions, and the scope document cannot
be written until this is settled.

- The approved intent statement makes **S1 behavioural parity** a success
  condition: "Every public route and every owner-editable field that exists today
  still exists and still behaves the same."
- The original request separately asks to "improve clutter through clear
  information hierarchy, reusable layouts, consistent typography, spacing, colour
  and interaction patterns", to target WCAG 2.2 AA on changed interfaces, and to
  "optimise images, fonts, client JavaScript and data access based on measured
  behaviour".
- At Q5 above, "no visual redesign" was offered as an exclusion and was **not**
  selected — so redesign is not ruled out, but nothing positively authorises it
  either.

A. Parity is the rule. Reproduce today's interface as-is. The only user-visible change is the carousel keyboard-focus fix already agreed at intent capture. Any redesign is separate future work.
B. Parity for layout and content, but accessibility and semantics may improve freely — correct heading order, labels, focus handling, contrast and reduced-motion support wherever they fall short, without moving anything visually.
C. Parity is a floor, not a ceiling. Improve hierarchy, spacing, typography and performance where there is a measured reason, and tell me what changed. Accepts that "same behaviour" becomes a judgement call at verification time.
D. Not yet defined.
X. Other (please specify)

[Answer]: B. Parity for layout and content, but accessibility and semantics may improve freely — correct heading order, labels, focus handling, contrast and reduced-motion support wherever they fall short, without moving anything visually.

---

## Consolidated Summary Confirmation

- Looks correct
- Request changes

[Answer]: Looks correct
