# Decision Log — Ideation

**Upstream:** `ideation/intent-capture/intent-statement.md`,
`ideation/intent-capture/stakeholder-map.md`,
`ideation/scope-definition/scope-document.md`,
`ideation/scope-definition/intent-backlog.md`.

Every decision taken during Ideation, in the order it was taken. Pre-workflow
decisions are included because they shaped the composed scope itself.

## Pre-workflow (before the intent record existed)

| # | Decision | Rationale | Consequence |
|---|---|---|---|
| D1 | Run `/aidlc compose` rather than the full 33-stage `feature` scope | Discovery was already complete and four design questions were already settled, so ~14 stages would only have restated the brief | Custom scope `runtime-split-migration`: 19 EXECUTE, 14 SKIP, 16 gates |
| D2 | Admin auth is password + argon2id + signed HttpOnly session cookie + CSRF double-submit + login rate limiting; first admin via CLI | Fully verifiable locally with no external dependency or cost, unlike OAuth which cannot be exercised without client credentials | Google OIDC becomes a documented extension point, not a deliverable |
| D3 | Narrow storage port: SQLite verified locally, Firestore + Cloud Storage for Cloud Run | Cloud Run has no durable disk, and neither D1 nor R2 exists on Google Cloud | Two adapter families behind one port; contract tests prove the port, not the services |
| D4 | Google Cloud is plan-only | Explicit user constraint; `gcloud` is not installed | No provisioning, no deployment, no billing change |
| D5 | Initialise git and commit a baseline before any migration work | The workspace had no version control at all | `madhavi-tripathi/` preserved as reference and rollback baseline at commit `367b9c3` |

## Intent Capture (stage 1.1)

| # | Decision | Source | Rationale |
|---|---|---|---|
| D6 | The problem is both portability/control and Python-first architecture | Q1 | Neither half alone was selected |
| D7 | Exactly one site owner edits; no tiered permissions | Q2 | Supersedes the brief's looser "a few administrators" |
| D8 | Four success conditions: parity, clean language boundary, containers proven end to end, reviewed cloud plan | Q3 | All four selected |
| D9 | Hold a **hard** zero recurring-cost target | Q4 | Chosen over a near-zero target, after being told the supporting estimate was pessimistic |
| D10 | The trigger is leaving the current host for a concrete reason | Q5 | Makes portability binding rather than optional |
| D11 | Sole decision-maker; report at approval gates only | Q6 | No separate status updates, no second-party content sign-off |
| D12 | `chiku` is the folder name; public branding is unchanged | Q7 | Content, title, monogram and metadata stay as they are |
| D13 | Fix the carousel keyboard-focus defect; leave the ~560 kB three.js chunk | Q8 | The only agreed user-visible behavioural change |
| D14 | The `runtime-split-migration` boundary is confirmed | Q9 | Workflow-selected scope and user-confirmed boundary agree |
| D15 | Accept five ungrounded assumptions as labelled assumptions | Assumption Confirmation | None of them blocks progress; none is promoted to fact |
| D16 | Approve the stage with 5 reviewer findings and 9 sensor findings unfixed | Gate 1 | Recorded as accepted risk; R-02 carried forward to a stage that can close it |

## Scope Definition (stage 1.4)

| # | Decision | Source | Rationale |
|---|---|---|---|
| D17 | Dependency-first sequencing after the walking skeleton | Q1 | Nothing gets built on a boundary that later moves |
| D18 | No deadline | Q2 | Correctness preferred to speed at every decision point |
| D19 | Implement both cloud adapters against the shared contract suite; no emulator | Q3 | Keeps the cloud path credible without a 1 GB Java dependency in the test loop; adapters ship honestly marked unverified |
| D20 | Delete the 44 unimported component files and 11 unimported dependencies | Q4 | Smaller install and image; directly serves the zero-cost target |
| D21 | Internationalisation is explicitly out of scope | Q5 | Selected; visual redesign and content change were offered and **not** selected, so neither is recorded as excluded or as permitted |
| D22 | Parity for layout and content; accessibility and semantics may improve without moving anything visually | Q6 | Resolves the contradiction between success condition S1 and the original request's improvement goals |

## Approval & Handoff (stage 1.7)

| # | Decision | Source | Rationale |
|---|---|---|---|
| D23 | Actively mitigate all eight recorded risks rather than accepting any | Q1 | Each mitigation is cheap and most are work that would happen anyway; there is no deadline pressure to accept risk |
| D24 | GO — close Ideation, open Inception | Q2 | Every Ideation deliverable is complete and approved; nothing is blocked |

## Decisions deliberately NOT taken in Ideation

| Deferred decision | Owner stage |
|---|---|
| Unit decomposition and their dependency graph | `units-generation` |
| The API contract surface and the storage port signatures | `contract-design` |
| Measurable security, size and free-tier targets | `nfr-requirements` |
| How the zero-cost condition is verified (reviewer finding R-02) | `nfr-requirements`, `infrastructure-design` |
| Container topology, base images, volume layout, cloud region | `infrastructure-design` |
| Test methodology and ordering | `practices-discovery` |

## Assumptions & Open Questions

- D9's hard zero-cost target rests on figures that are still estimates. It cannot
  be confirmed or refuted until container images are built and measured.
  [assumption]
- D21 records a deliberate silence: two exclusions were offered and declined, and
  that decision is not read as permission in either direction. [assumption]
- D16 leaves five reviewer findings unfixed by explicit choice. Only R-02 has a
  named owner stage; R-01, R-03, R-04 and R-05 remain open against the intent
  statement. [assumption]
