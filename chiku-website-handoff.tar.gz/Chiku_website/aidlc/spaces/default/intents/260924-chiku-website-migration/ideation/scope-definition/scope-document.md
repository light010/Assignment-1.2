# Scope Document — chiku-website migration

**Upstream:** `ideation/intent-capture/intent-statement.md` — its four success
conditions (S1 parity, S2 clean language boundary, S3 containers proven end to
end, S4 reviewed cloud plan with nothing deployed) and its hard zero recurring-cost
condition are the acceptance frame for everything below.

## The boundary in one sentence

Rebuild the existing academic website in `chiku-website/` so that Next.js renders
and nothing else, a single Python service owns every application decision, both
run as containers verified locally, and a costed Google Cloud plan exists on
paper — with nothing deployed. [Q9 @ intent-capture]

## In scope

### Delivered and verified in this piece of work

| # | Capability | Note |
|---|---|---|
| I1 | A narrow storage port with a SQLite adapter | The verified default. Durable across container recreation via a named volume. |
| I2 | Password authentication in Python | Argon2id, signed HttpOnly session cookie, CSRF double-submit, login rate limiting, first admin via CLI. No default credentials. |
| I3 | Authorization enforced at every protected Python operation | Including direct API calls that never touch the frontend. |
| I4 | The full content API | Read, draft save, publish, optimistic-concurrency conflict handling, revision history with the existing retention behaviour. |
| I5 | Authoritative validation in Pydantic | The single source of truth for the content schema; frontend types generated from the resulting OpenAPI document. |
| I6 | Uploads and media serving in Python | Magic-byte checks, per-type size caps, server-side responsive image variants, byte-range support, and the existing rule that media is public only while it is referenced by published content. |
| I7 | The public website in Next.js | All existing routes and sections, the 3D scene, and the existing seeded content. |
| I8 | The owner editor in Next.js | Every tab that exists today, draft autosave, local draft recovery, revision history, private preview, publish. |
| I9 | SEO surface preserved | Content-derived metadata, Open Graph, `ProfilePage` JSON-LD, `sitemap.xml`, `robots.txt`, and management pages kept out of indexing. |
| I10 | The existing WebMCP browser tool | `stage_academic_profile` continues to stage profile fields into the editor form, and continues never to save or publish by itself. |
| I11 | Two container images and a Compose file | Non-root, locked dependencies, health checks, graceful shutdown, no source mounts, no development servers. |
| I12 | Firestore and Cloud Storage adapters | Implemented and run against the same contract test suite as SQLite. [Q3] |
| I13 | A costed Google Cloud deployment plan | Every line item traced to a current official free-tier source, with the architecture requiring no paid storage. Carried forward from reviewer finding R-02. |
| I14 | Deletion of unused starter code | The 44 unimported `components/ui/*` files and the 11 unimported npm dependencies do not cross into `chiku-website/`. [Q4] |
| I15 | The carousel keyboard-focus fix | The one agreed user-visible behavioural change. [Q8 @ intent-capture] |

### The parity rule

Layout and content reproduce as they are today. Accessibility and semantics may
improve freely — heading order, labels, focus handling, contrast, reduced-motion
support — **without moving anything visually**. [Q6]

This is what makes S1 checkable: a change that alters what a sighted visitor sees
is a parity breach; a change that only improves how the page is announced,
labelled or navigated is not. The carousel focus fix (I15) is the one agreed
exception that is both.

## Out of scope

| # | Excluded | Why |
|---|---|---|
| O1 | Deploying anything to Google Cloud | The confirmed boundary is plan-only. No provisioning, no image publishing, no billing changes. [Q9 @ intent-capture] |
| O2 | Provisioning any cloud resource | Same. `gcloud` is not installed on this machine. |
| O3 | New product features | Nothing the current site cannot already do. |
| O4 | A CI/CD platform | `ci-pipeline` is skipped; the containerised Compose run is the verification vehicle. |
| O5 | Fixing the >500 kB bundle / ~560 kB three.js chunk | Pre-existing, explicitly left alone. [Q8 @ intent-capture] |
| O6 | Internationalisation | No multi-language support for the public site or the editor. [Q5] |
| O7 | Multi-editor accounts or tiered editor/publisher permissions | Exactly one site owner edits. [Q2 @ intent-capture] |
| O8 | Any Node backend, Server Action, Route Handler or JS backend-for-frontend | Forbidden by the language boundary; a Next.js `rewrites()` entry is routing configuration, not application code. |
| O9 | Retaining any dependency on `madhavi-tripathi/` at runtime | It stays intact as the reference and rollback baseline and is never imported from. |

Neither a visual redesign nor a content change was selected as an exclusion at
Q5, and neither is recorded here as one. Both are nonetheless bounded by the
parity rule above and by the confirmed answer that public branding, title and
content stay exactly as they are. [Q7 @ intent-capture]

## Sequencing

Dependency-first. [Q1] The technical graph is followed so that nothing is built
on a boundary that later moves:

```
storage port → auth → API surface → public frontend → editor → containers
```

Two things sit outside that spine: the cloud adapters (I12) can be written any
time after the port exists, and the deployment plan (I13) needs the containers to
exist before its image-size figures can be measured rather than estimated.

A walking-skeleton Bolt runs first regardless of sequencing, because the scope
declares `skeleton: on`: one thin end-to-end slice — sign in, edit one field,
save, publish, see it on the public page — through both runtimes, gated, before
the remaining Bolts run.

## Timeline

No deadline. [Q2] Nothing in this scope is date-driven, so correctness is
preferred to speed at every decision point.

## Assumptions & Open Questions

- The reason for leaving the current host remains undescribed, so no shutdown
  date can be planned against. Recorded as no deadline on the strength of Q2.
  [assumption]
- The Firestore and Cloud Storage adapters (I12) will be delivered **unverified
  against real Google services**, by explicit choice. Contract tests prove they
  satisfy the port; they do not prove they work against Firestore. [Q3]
- Whether the hard zero recurring-cost target is achievable is still unproven and
  will remain so until container images are built and their compressed sizes
  measured. [assumption]
