<!-- INVARIANT: examples are single-line HTML comments so a fresh template parses to total=0 (MEMORY_EMPTY). Do NOT un-comment or split across lines. t100 guards this. -->
> This file is kept up to date automatically while the stage runs. Add observations at the review step, not by editing here directly.

## Interpretations
<!-- example: 2026-05-29T10:14:32Z — chose REST over GraphQL; the consuming team only needs CRUD, revisit if subscriptions land -->

- 2026-09-24T14:32:43Z — Q5 offered "no visual redesign" and "no content changes" as exclusions and the user selected neither, so the scope document records neither as excluded AND neither as permitted; the grounding rule forbids turning an unselected option into a requirement or an exclusion. Both remain bounded by the Q6 parity rule and by the confirmed answer that branding, title and content stay exactly as they are.
## Deviations
<!-- example: 2026-05-29T10:14:32Z — skipped the optional caching layer the stage prose suggested; the dataset is small enough that it adds risk -->

- 2026-09-24T14:32:43Z — raised follow-up Q6 rather than writing the scope boundary, because intent-statement S1 ("still behaves the same") contradicts the original request's explicit goals of improving clutter, hierarchy, typography and WCAG 2.2 AA conformance, and Q5 declined to exclude redesign. stage-protocol.md makes contradiction resolution mandatory at every depth; writing an in/out boundary over an unresolved contradiction would have hidden it rather than settled it. Resolved as parity for layout and content with accessibility free to improve invisibly.
## Tradeoffs
<!-- example: 2026-05-29T10:14:32Z — picked TDD over BDD this run; the team is unit-first and the domain is well-understood -->

- 2026-09-24T14:32:43Z — classified the Firestore and Cloud Storage adapters (B8) as Should rather than Must even though they are confirmed in scope, because nothing in this piece of work executes them against a real backend, so they cannot gate a verified deliverable. With no deadline the classification changes nothing about whether they get built; it only decides what would yield if time ran short.
- 2026-09-24T14:32:43Z — isolated the carousel keyboard-focus fix as its own proto-unit (B11) instead of folding it into the public frontend unit, so the single agreed user-visible behavioural change stays separately auditable against the parity condition rather than hiding inside a large port.
## Open questions
<!-- example: 2026-05-29T10:14:32Z — confirm the retention window with compliance before the next stage hardens the schema -->
