# Approval & Handoff — Questions

Upstream: `ideation/intent-capture/intent-statement.md`,
`ideation/intent-capture/stakeholder-map.md`,
`ideation/scope-definition/scope-document.md`,
`ideation/scope-definition/intent-backlog.md`.

Most of this stage's standard questions do not apply and are not asked:
market research and feasibility were skipped by the composed scope, there is no
mob to staff (solo), and no budget commitment exists beyond the hard zero
recurring-cost target already confirmed. Stakeholder agreement is likewise already
settled — the confirmed answer is that you are the sole decision-maker.

---

## Q1. Eight risks are on the table going into Inception. Which do you want actively mitigated, rather than simply accepted? (select all that apply)

| # | Risk | Proposed mitigation if selected |
|---|---|---|
| RK1 | **Authentication is newly built.** The platform auth being replaced cannot be fallen back on; a defect here exposes the management surface. | Build on maintained libraries only (argon2-cffi, itsdangerous); add explicit tests that a direct, unauthenticated API call is rejected, including CSRF and session-forgery cases. |
| RK2 | **Cloud adapters ship unverified** against real Google services, by your choice at Q3. | Hold them to the same contract test suite as SQLite and label them unverified in the README and the deployment plan, so nobody mistakes them for proven. |
| RK3 | **The hard zero-cost target is unproven** until container images exist and are measured. | Measure compressed image sizes at build-and-test and report the measured figure; add an image cleanup policy to the plan; serve static assets and media from Cloud Storage rather than through Cloud Run. |
| RK4 | **Reviewer finding R-02 is still open** — the zero-cost success condition is unmeasurable while nothing is deployed. | Close it at nfr-requirements and infrastructure-design by making it a checkable property of the plan rather than of a running system. |
| RK5 | **Behavioural parity across a double change.** Both the framework (vinext to standard Next.js) and the runtime (Cloudflare Workers to Node) change at once, so subtle rendering or routing differences are plausible. | Build an explicit route-and-behaviour parity checklist from the discovery inventory and verify each row in a browser, desktop and mobile. |
| RK6 | **No production content is available.** Hosted D1 and R2 are not in the export, so the seeded content in `app/content.ts` is all there is. | Treat the seed as canonical, as the original handoff document states; confirm no data migration is owed and record that decision. |
| RK7 | **The upload and media path is intricate** — magic-byte checks, per-type caps, byte-range responses, and the rule that media is public only while published content references it. | Port it against focused tests per rule rather than as one block, including the negative cases (unpublished media, malformed range, wrong magic bytes). |
| RK8 | **Container verification depends on the Docker daemon**, which is outside the workflow's control. | The daemon is currently up. If it stops, report the container checks as blocked rather than skipped, and complete everything else. |

A. Mitigate all eight.
B. Mitigate the security and correctness ones only (RK1, RK5, RK7), and accept the rest as recorded risks.
C. Mitigate the ones that threaten a confirmed success condition (RK1, RK3, RK4, RK5), and accept the rest.
D. Accept all eight as recorded risks with no specific mitigation work.
X. Other (please specify)

[Answer]: A. Mitigate all eight.

---

## Q2. Go / no-go: does Ideation close and Inception open?

Ideation produced a confirmed problem and customer, four success conditions plus
a cost condition, a stakeholder map, an in/out scope boundary with a parity rule,
and an 18-item prioritised backlog. Nothing in it has changed since you approved
the two preceding gates.

A. Go — close Ideation and open Inception.
B. Go, but I want something added to the initiative brief first; I will say what.
C. No-go — stop the workflow here.
D. Not yet defined.
X. Other (please specify)

[Answer]: A. Go — close Ideation and open Inception.

---

## Consolidated Summary Confirmation

- Looks correct
- Request changes

[Answer]: Looks correct
