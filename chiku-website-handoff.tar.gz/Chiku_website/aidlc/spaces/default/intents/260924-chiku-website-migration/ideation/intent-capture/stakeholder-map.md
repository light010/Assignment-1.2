# Stakeholder Map — chiku-website migration

## Key Stakeholders and Their Interests

| Stakeholder | Interest | Source |
|---|---|---|
| Public visitors | Read the website. Their interest is that nothing they can perceive regresses: the same pages, the same content, the same behaviour. | [Q2] [Q3] |
| Site owner (sole editor) | Edits the website. Exactly one person holds this role. Her interest is retaining every editing and publishing capability she has today, on infrastructure that does not depend on a third party's account system. | [Q2] [Q1] |
| Madhavi Tripathi (identity owner) | The website's content, title and visual identity are hers and stay exactly as they are. Her interest is that the migration changes the project's folder name only, not the public brand. | [Q7] |
| Workflow decision-maker | Decides scope and priority for this piece of work, including content and branding. Interest is a portable, Python-first system delivered inside the confirmed boundary at zero recurring cost. | [Q6] [Q9] [Q4] |

The site owner and the identity owner are listed separately because the
confirmed answers establish the editing role and the branding ownership through
different questions; whether they are the same person is not established.
Unknown (open question) [assumption]

## Decision-Makers vs. Influencers

| Role | Party | Authority | Source |
|---|---|---|---|
| Decision-maker | Workflow decision-maker | Sole authority over scope and priority. Explicitly includes content, branding and user-visible changes: no separate content sign-off by another party is required. | [Q6] |
| Influencer | Site owner | Uses the management interface and is the party whose existing capability must be preserved, but no approval authority over this work was established. Unknown (open question) [assumption] | [Q2] |
| Influenced party | Public visitors | No authority. Affected by every user-visible outcome; their interest is represented through the behavioural-parity success condition rather than through participation. | [Q2] [Q3] |

## Communication Requirements

| Requirement | Detail | Source |
|---|---|---|
| Reporting cadence | At each approval gate only. No separate status updates between gates. | [Q6] |
| Escalation | Not established. Unknown (open question) [assumption] | [assumption] |
| Content sign-off | Not required. The decision-maker holds authority over content and branding directly. | [Q6] |

## Assumptions & Open Questions

- Whether the workflow decision-maker and the site owner are the same person is
  not established. The distinction matters only if content or branding decisions
  later need a second party's approval; the confirmed reporting answer says they
  do not. [assumption]
- No escalation path or deadline was established, because no question elicited
  one. If the move off the current host is time-boxed, that constraint is not
  yet recorded anywhere. [assumption]
- Public visitors are described by role only. No traffic figures, geographic
  distribution or device mix were supplied, and none were invented. These matter
  to the cost plan, where they must be entered as stated assumptions rather than
  as measurements. [assumption]
