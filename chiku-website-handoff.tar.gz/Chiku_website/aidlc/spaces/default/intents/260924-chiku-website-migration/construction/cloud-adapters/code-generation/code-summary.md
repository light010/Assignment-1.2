# Code Summary — U11 `cloud-adapters`

> ## These adapters are code-complete and UNVERIFIED against the real services
>
> No code in `chiku-website/backend/app/cloud/` has ever executed against Firestore or
> Cloud Storage. Nothing was provisioned: no Google Cloud project, no database, no bucket,
> no service account, no credential, no billing change. **No network call is made, in code
> or in tests.** No cloud SDK was installed.
>
> What the suite proves is that these adapters satisfy the three storage ports' contract
> **as `tests/conformance/` expresses it**, against an in-process fake, and that they obey
> three documented Firestore constraints **as that fake models them**. It does not prove
> they work against the services. Every statement in the code about service behaviour comes
> from published documentation, and the structural `Protocol`s in `app/cloud/clients.py`
> are a claim about an API that has not been contacted.
>
> That is a deliberate scope decision, not an oversight: verifying them would require
> provisioning, and this workflow provisions nothing. BR31.5 requires the status to be
> impossible to miss, so it is stated here, in every adapter module's docstring, in
> `app/cloud/INDEXES.md`, and in the conformance suite's own conftest.

## What was built

Three adapters implementing U2's three ports against Google Cloud, plus the client surface
they are written against and the substitution that makes an oversized save storable.

| File | What it is |
|---|---|
| `chiku-website/backend/app/cloud/clients.py` | `FirestoreLike` / `TransactionLike` / `BucketLike` and their sub-protocols; the published document-size model; the error-status match; the document-name encoder |
| `chiku-website/backend/app/cloud/blobs.py` | Content-addressed substitution: threshold, ordering, tie-break, reversal |
| `chiku-website/backend/app/cloud/content_firestore.py` | **Hazard module** — `ContentStore`, carrying the combined write |
| `chiku-website/backend/app/cloud/identity_firestore.py` | `IdentityStore` |
| `chiku-website/backend/app/cloud/assets_gcs.py` | `AssetStore` |
| `chiku-website/backend/app/cloud/INDEXES.md` | The one declared composite index, as a deployment deliverable |

### No cloud SDK dependency, and the four things that buys

The adapters are written against structural `Protocol`s describing only the client surface
they use, not against `google-cloud-firestore` and `google-cloud-storage` imports. The
alternative loses all four at once: the backend image does not grow (measured size feeds
the zero-recurring-cost target); `mypy --strict` stays clean with no blanket
`ignore_missing_imports`, which is exactly the suppression `team.md` forbids; the
conformance suite can run at all, against an in-process fake; and a real client is a
constructor argument rather than a rewrite.

`grep -rn "google.cloud\|google-cloud" app tests pyproject.toml` returns twelve lines, all
docstrings naming the API being modelled. No import, no dependency, no installed package.

## Ordering — the approved Testing Contract was followed, not converted

Methodology `custom`. `team.md` § *Testing Posture*: the characterization tests for a
unit's hazard-register behaviours **and for the storage port** are written and observed to
fail before the implementation exists. The combined write on Firestore is a hazard-register
module and every operation here is a storage port, so the clause applied in full.

Step 4 wrote the tests and ran them. With only signature-carrying skeletons in place,
**15 of this unit's 16 tests failed and 23 conformance runs against the cloud adapters
failed** — 38 failures, with all 365 pre-existing tests still passing. The one test that
passed at that point,
`test_a_filtered_survivor_read_is_refused_for_want_of_a_declared_index`, exercises the fake
rather than an adapter, and it is recorded as passing rather than presented as a Red.

Step 5 then implemented to Green. The steps were not merged and the ordering was not
converted into layer-local TDD.

## The combined write, step by step

The spec's order is literal and both of its orderings are load-bearing and independent.

**Before the transaction** — `FirestoreContentStore._prepare`. Serialise; decide which
fields are substituted; write every blob and await each. BR31.2: a failed transaction then
leaves an **orphaned blob**, which is reclaimable garbage because the key is a hash of the
content, rather than a document referencing a blob that never landed, which is corruption.

**Inside the transaction** — `_run_combined_write`:

1. `_read_content` — the compare-and-set guard. A mismatch raises `_StaleWrite` **here**,
   before any write, so the abort costs nothing and nothing has to be undone.
2. `_read_revisions` — **one unfiltered `revision DESC` read** of the bounded set.
   `select_pruned` partitions by action **in memory** and the baselines' existence is read
   off the same result, so the whole write phase needs no further lookup.
3. `_write_revision` for each absent baseline — effects 1 and 2, capture-if-absent.
4. `_write_content` — effects 0 and 3.
5. `_write_revision` for the new entry — effect 4.
6. `_delete_revisions` — effects 5 and 6, the delete **naming** the doomed ids.
7. Commit, as the context manager's clean exit.

So: **read-content, read-survivors, write-content, write-revision, delete-pruned, commit.**

The survivor set is computable in the read phase because the new entry ranks first for its
own action under `revision DESC` — its number is `base_revision + 1`, necessarily the
highest — and its action is a caller argument. It is therefore always a survivor and never
decides which *existing* entry falls outside the cap. That is why R-05's fix was pure
resequencing and changed no prune logic; `select_pruned` gives the new entry one slot of its
own action's allowance and is otherwise identical in effect to the SQLite adapter's prune.

**Bootstrap is a value, not a write.** In SQLite, effect 0 is an insert at revision 0 that
the compare-and-set then updates. Here there is one write per document, so
`_seeded_document` is the *base* the compare-and-set runs against. BR4.8's two guards
survive intact: the base carries revision 0, the guard is an equality, and a client at
revision 5 against an absent document finds `0 != 5` and cannot resurrect a deleted
document. `test_a_commit_against_an_absent_document_at_a_non_zero_base_revision_conflicts`
asserts exactly that, including that nothing at all was written.

## Does the suite actually bite?

The fakes **enforce** rather than permit, and both enforcements were checked by mutating
the real adapter — not the test doubles — and watching the suite go red.

**Mutation A — the pre-R-05 order.** Moving `_read_revisions` after `_write_content` and
`_write_revision` in `content_firestore.py` took the suite to **14 failures**, including
six conformance runs. The refusal:

```
cloud.fake_firestore.ReadAfterWriteError: a Firestore transaction rejects a read issued
after a write (BR31.3)
```

Note *which* conformance tests failed — `test_the_two_retention_counts_are_independent`,
`test_both_baselines_survive_a_prune_that_ordering_alone_would_not_have_spared`,
`test_a_content_payload_round_trips_byte_identically`. The defect fires on an ordinary save,
which is the point the finding made.

**Mutation B — the pre-R-01 algorithm.** Forcing `revision_chosen = ()` so the content
document is substituted and the revision entry is written inline took the suite to **3
failures**, one of them the shared conformance round-trip:

```
cloud.fake_firestore.DocumentTooLargeError: revisions/d3JpdGUtMQ: 3429695 bytes exceeds
the 1048576-byte limit
```

3,429,695 bytes is the conformance suite's 1,500,000-character payload in UTF-8 — the
save FR4.6 requires the port to accept. Both mutations were reverted and the suite is green.

**A third enforcement, demonstrated rather than mutated.** The fake refuses a query needing
an undeclared composite index. The adapters cannot issue the filtered survivor read at all,
because `QueryLike` carries no `where` — so
`test_a_filtered_survivor_read_is_refused_for_want_of_a_declared_index` reaches past the
Protocol straight at the fake to show the refusal is real, and
`test_the_listing_depends_on_the_one_declared_composite_index` builds a second harness with
nothing declared to show the listing genuinely depends on the definition shipping.

## Coverage — both floors met, neither relaxed

```
app/cloud/assets_gcs.py              43      0      8      0   100%
app/cloud/blobs.py                   52      0     10      0   100%
app/cloud/clients.py                108      0     20      0   100%
app/cloud/content_firestore.py      153      0     26      0   100%
app/cloud/identity_firestore.py      98      0     14      0   100%
TOTAL                              1096      7    164      0    99%
```

* **80% branch over the backend** — 99%, with **zero partial branches** anywhere.
* **100% branch on the hazard modules**, now including `app/cloud/content_firestore.py`
  alongside `app/content/store_sqlite.py` and `app/auth/store_sqlite.py` — 100%, 0 missed.

No threshold was edited, no `omit` added and no `--include` narrowed. The only
`pyproject.toml` change is an isort classification (see *Deviations*).

Two branches were **removed rather than left unasserted**, because an unreachable branch
cannot carry a 100% floor and pretending otherwise is how a floor stops meaning anything:
the `datetime` arm of `value_bytes` (this package stores every instant as text, so a
datetime reaching it is a mistake and the `TypeError` is how it surfaces), and a redundant
`base_revision != 0` guard that the compare-and-set already subsumes.

## Gaps surfaced, not closed

### 1. `entities.md` says an expired session is deleted on read; the port forbids it

`entities.md` § *Firestore mapping* notes for `Session`: *"An expired session is deleted
when read, rather than swept on a schedule."* That is a **rule**, and BR22.14 says this port
evaluates no expiry — `session_read` returns a record past either bound exactly as stored,
and `tests/conformance/test_identity_store.py::test_session_read_evaluates_no_expiry_and_returns_the_record_as_stored`
asserts it against every implementation.

BR31.1 settles it: the port is the contract and an adapter never negotiates it. The adapter
therefore evaluates nothing, and the note is **not implemented**. If the deletion is wanted
it is a deployment-side sweep or a change at the port's owner (U2), not an adapter
behaviour. **Owner: U2 `storage-ports` if the port is ever changed; otherwise the
deployment plan (U12).** Recording it rather than quietly implementing one of the two is
the point: two expiry evaluations with no test comparing them is how they drift.

### 2. Nothing reclaims orphaned payload blobs

Carried from `entities.md` unchanged. A transaction that fails after its blobs landed leaves
them. They are harmless by construction — content-addressed, so a retry collides with the
identical object — but no sweep exists and none was written here. **Owner: U12
`deployment-plan`.** It is also stated in `app/cloud/INDEXES.md`, where a deployer will be
standing when the storage bill is the thing they are looking at.

### 3. The fake enforces the size limit with the adapter's own size function

`tests/cloud/fake_firestore.py` calls `app.cloud.clients.estimate_document_bytes` to decide
whether a document is too large — the same function `plan_substitution` budgets against. So
the fake catches a **missing or mis-ordered** substitution, which is what R-01 was, and
cannot catch a **mis-measured** one. Two independently written size functions would have
caught that third case and would have disagreed constantly about where the boundary is.
Sharing one is the honest trade; this is the disclosure, and it is also in the fake's
docstring. The size model reproduces Firestore's published accounting table rather than
approximating it, which is the best available mitigation and is itself unverified.

### 4. The transaction lock models Firestore's *outcome*, not its mechanism

The fake serialises transactions with a lock. Firestore reaches the same observable outcome
— serializable isolation — by optimistic concurrency with automatic retry. Every conflict
decision in the adapter is taken inside the transaction from a read issued in its read
phase, so it is correct under either mechanism; but the suite's concurrency evidence is
evidence about the model, not about the service. Under a real client a losing writer may see
a retry before it sees a conflict, and it will then re-read and return the same conflict.

### 5. One Protocol member is *shaped* rather than *copied*

The published async Firestore client drives begin/commit/rollback through the
`@firestore.async_transactional` decorator. A decorator is not a member of a client object,
so it cannot appear in a client Protocol at all, and `TransactionLike` spells the lifecycle
as an async context manager instead. **Wiring a real client therefore needs one small shim
class implementing `FirestoreLike.transaction()` over `async_transactional`; no adapter
logic changes.** Everything else in `clients.py` is the published spelling. Stated here
because the plan's claim that "a real SDK client satisfies the Protocol structurally" is
true of the other twelve members and not of this one.

### 6. Two reads the cloud path pays that the SQLite path does not

Both are consequences of the design, not defects, and both are measurable rather than
hypothetical:

* **One extra document read per save.** `_prepare` reads the content document *outside* the
  transaction, because the spec's step 1 says *serialise the content document* and on a
  draft write the document's `published` field is the existing value — which only a read
  supplies. It is safe because the compare-and-set inside the transaction is what certifies
  it: if the document moves in between, its revision moves too, the write is refused, and
  nothing survives but an orphan blob.
* **One payload download per draft save whose `published` is oversized.** `commit` returns
  the new `ContentState`, whose `published` is the document's *text*, not its storage
  representation. `test_an_existing_published_blob_is_carried_forward_rather_than_rewritten`
  asserts the exact count rather than omitting the check, so the cost stays visible — and
  asserts zero uploads, because re-uploading a carried payload would be invisible (the key
  would be identical) and would cost a full transfer each way.

## Deviations from the design artifacts

### 1. The large-payload threshold is set here, closing an open question

`entities.md` and `functional-spec.md` both carry *"the threshold is unset"* as an open
question. `blobs.LARGE_PAYLOAD_THRESHOLD_BYTES` is now `FIRESTORE_DOCUMENT_LIMIT_BYTES // 2`
= **524,288**, derived rather than chosen, and the half is load-bearing in both directions.
Above half, step 1 could leave two surviving fields whose sum exceeds the limit by an
unbounded amount, so the largest-first loop would be doing the real work and the threshold
would be decoration. Below half, two surviving fields can never collide, so the
largest-first branch becomes **unreachable** — and an unreachable branch cannot carry the
100% floor this module is measured against. At exactly half the collision is possible and
bounded, which is the only setting where both rules mean something.

### 2. A substituted field moves to a different field name

`<name>_blob` holds the key; the original field is absent. A sentinel *inside* the original
field would be a value the port is forbidden to invent and would be indistinguishable from
content that happened to look like one. The three storable shapes are therefore
`draft`/`draft_blob`, `published`/`published_blob`, `content`/`content_blob`, exactly one of
each pair present. This is what makes *"assert which blobs exist"* a sentence with a meaning.

### 3. Instants are stored as ISO-8601 text, although Firestore has a timestamp type

The native type normalises to UTC and truncates to microseconds, so an offset-bearing value
would come back **changed** — which is the one thing this port is not allowed to do
(BR22.5, BR22.6). `datetime.isoformat` and `datetime.fromisoformat` are exact inverses
including the offset. `app/sqlite.py` stores them the same way for the same reason, which
also keeps the two adapters comparable.

### 4. Caller-supplied keys are encoded into document and object names

Revision ids, session ids, attempt window keys and asset keys reach storage as URL-safe
base64. The ports **validate nothing** (BR22.6), so an adapter cannot reject a key
containing `/`, `..`, `__x__` or a line break — and must not be broken by one either. The
encoding is total, lossless and reversible, which is the representation conversion BR22.6
permits, and it is the same move `app/assets/store_volume.py` makes to keep a key off the
filesystem. **Identity is never read back out of a name**: every shape stores its own id as
a field, exactly as it is a column in the SQLite schema. The two ids this package chose
itself — the content document and the owner document — are used verbatim.

### 5. Three test files beyond the plan's list

`tests/cloud/journal.py` holds the shared timeline both fakes append to: BR31.2 is an
ordering obligation **across two services**, and a per-service log shows two orderings that
cannot be compared. `tests/cloud/harness.py` holds the harness builders and the declared
index, because a `conftest.py` is a pytest hook file rather than an importable API and both
suites need them. `tests/cloud/test_client_surface.py` covers four claims `clients.py` makes
that neither planned module is about — chiefly *nothing but the named status is swallowed*,
which is the sentence standing between a permissions failure and a silent no-op.

`tests/cloud/__init__.py` is there for the same mechanical reason as
`tests/conformance/__init__.py`: without it, pytest's prepend import mode gives two
`conftest` modules the same top-level name and the four pre-existing suites fail to collect.

### 6. `pyproject.toml` gained an isort classification

`[tool.ruff.lint.isort] known-first-party = ["app", "cloud", "conformance"]`. `cloud` and
`conformance` are packages under `tests/`, not under the project root, so without it
import-classification depended on which file was being sorted and the two test packages
sorted differently in different files. **No coverage threshold, `omit` or `include` was
touched, and no dependency was added.**

### 7. Three field-name constants are named for what they hold

`STORED_HASH_FIELD`, `HASH_UPDATED_AT_FIELD` and `CSRF_PAIRING_FIELD` name the fields
`password_hash`, `password_updated_at` and `csrf_token`. A constant name carrying "password"
or "token" beside a string literal is what the hardcoded-credential lint rule looks for; the
stored field names are unchanged, and renaming the constant is cheaper and more honest than
suppressing the rule. **There is no `# noqa` and no `# type: ignore` anywhere in this unit.**

### 8. `TransactionLike.__aexit__` takes a traceback, not `object`

Parameter types are contravariant, so a member declared `object` could not be satisfied by
any real implementation. `TracebackType | None` is both accurate and satisfiable.

### 9. Blob writes are de-duplicated by key within one save

A draft save of an oversized payload substitutes the same text twice — as the document's
`draft` and as the revision entry's `content` — and content-addressing makes those the same
object. Writing it once is the same result for half the transfer.

### 10. The transaction's document budget is unchanged, and the extra read sits outside it

`entities.md` § `transaction_scope` states 53 reads, 3 writes, 54 distinct documents against
Firestore's documented 500-document transaction limit. That holds as written: the
transaction issues one content read plus at most 52 revision reads, and the `_prepare` read
of deviation 6 is **outside** the transaction and does not count against the bound. Worst
case is unchanged and comfortably inside the limit. Unverified by execution, like the rest.

## Security

* **No credential, key, project id, bucket name or region is hardcoded** — not in code, not
  in a test, not in a docstring. Configuration arrives at runtime; the adapters take a
  client and a bucket as constructor arguments and know nothing about how either was built.
* **No owner record, seed credential or sample password exists anywhere in this unit.** The
  `owner` collection starts empty and its emptiness is the one-shot provisioning gate, whose
  condition is the record's **existence** — so a restart cannot reopen it. A fresh database
  has no account anyone can sign in to.
* **The credential hash is never touched** (BR3.6): stored verbatim, returned to the
  verifying component only, never parsed, compared, derived from or logged. No logging call
  exists in any of these modules.
* **`tolerate` swallows exactly one status and re-raises everything else**, so a permissions
  failure, a quota refusal or an outage reaches the consumer and becomes a 503 rather than
  disappearing into a "not found". `test_only_the_named_status_is_tolerated` asserts the
  re-raise for a 403, for a 409, for an unrelated `ValueError` and for a decoy exception
  carrying a non-integer `code`.
* **Nothing can incur a charge.** No provisioning, no network call, no metered component.

## Boundary discipline

The adapters implement ports and own no rule. They evaluate no expiry, compare against no
threshold, apply no default, validate no value, derive no key or media type, and reconcile
nothing: `ObjectHead.media_type` and `AssetMetadataRecord.media_type` are held independently
and no code path reads one from the other (BR7.18, BR22.12). Retention counts, the seed, the
listing cap, the substitution threshold and the document limit all arrive as arguments —
`plan_substitution` takes its threshold and limit from its caller for the same reason
`commit` takes its retention policy from one.

The synchronous Cloud Storage client is confined behind `anyio.to_thread.run_sync` in
`assets_gcs.py` and `blobs.py`; nothing else in the tree calls it. Event-loop blocking is
invisible to every check on the merge gate, which is why confinement is a rule.

## Verification

Run from `chiku-website/backend/`. Every command below was executed and its verbatim output
is in the dispatch report.

```
uv run pytest tests/cloud                     16 passed
uv run pytest                                 408 passed  (365 pre-existing, all green)
uv run pytest --cov --cov-branch              TOTAL 99%, 0 partial branches
uv run coverage report --fail-under=80        pass
uv run coverage report --fail-under=100 --include="app/cloud/content_firestore.py,app/content/store_sqlite.py,app/auth/store_sqlite.py"
                                              100%, 0 missed
uv run ruff check                             All checks passed!
uv run ruff format --check                    44 files already formatted
uv run mypy --strict app tests                Success: no issues found in 44 source files
grep -rn "google.cloud\|google-cloud" app tests pyproject.toml
                                              12 docstring lines, no import
```

Not run, and not applicable to this unit: `tsc --noEmit`, `pnpm lint`, the ported-file diff,
the boundary grep over `chiku-website/frontend`, the `openapi-typescript` regeneration, and
`docker compose up`. This unit touches no frontend file, adds no HTTP route and changes no
OpenAPI document. They belong to the Bolt merge gate, which is where the full ordered list
in `team.md` § *Testing Posture* is run and pasted.

## Sources

- `construction/cloud-adapters/functional-design/functional-spec.md` — § *The combined
  write, on Firestore* (the nine steps, the R-01 and R-05 corrections quoted in full),
  § *Revision listing*, § *What "unverified" means precisely*.
- `construction/cloud-adapters/functional-design/entities.md` — the storage mapping, the
  `firestore_document_size` and `transaction_scope` constraints, the 52-entry invariant.
- `construction/cloud-adapters/functional-design/rules.md` — BR31.1 to BR31.6.
- `construction/cloud-adapters/code-generation/code-generation-plan.md` and its embedded
  Testing Contract (`sha256:6b84da29d5313b29b3058ef863280c58a9f6f401f244363de9431d8063261179`),
  and `unit-test-instructions.md`.
- `inception/contract-design/contract-summary.md` — §§ C2 (`payload_size`, `prune_shape`,
  `bounds`), C3, C4.
- `inception/units-generation/unit-of-work.md` § U11.
- `inception/requirements-analysis/requirements.md` — NFR3, NFR6; FR4.6 as the requirement
  that motivates BR31.2 without being discharged by it.
- `aidlc/spaces/default/memory/team.md` — § *Testing Posture* (methodology `custom`, both
  coverage floors, the merge gate), § *Code Style* → *Python (backend)*, § *Deployment*.
- `aidlc/spaces/default/memory/project.md` — the `## Forbidden` and `## Mandated` rules on
  provisioning, cost, credentials and the storage port.
- The existing implementation: `app/content/store.py`, `app/auth/store.py`,
  `app/assets/store.py`, the six local adapters, `app/sqlite.py`, and
  `tests/conformance/` — which arbitrates every port question this unit could have had.
- Google Cloud published documentation for Firestore and Cloud Storage, for every statement
  about service behaviour. **Documentation, not execution** — see the header.
