# Frontend Components — U9 `owner-editor`

**Unit:** `u9-owner-editor` · **Kind:** `ui` · **Component:** `OwnerEditor`

**Upstream:** `construction/functional-design/frontend-components.md` § *U9 —
owner-editor* (**extended and scoped here, not contradicted** — with one correction,
recorded below), companion artifact `functional-spec.md` (**authoritative for every
workflow and state machine referenced here**),
`codekb/Chiku_website/component-inventory.md`,
`inception/domain-design/decisions.md` ADR-005, ADR-006,
`inception/units-generation/unit-of-work.md` § *U9 — owner-editor*,
`aidlc/spaces/default/memory/team.md` § *Code Style* → *TypeScript / React*.

## How to read this document

This is the **component-level** view of `owner-editor`: which files cross, in what
state, what each is responsible for, and what goes on `PORTED-MODIFIED.md`.

**It specifies no workflow and no state machine.** Those are in this unit's
`functional-spec.md`, which is the source of truth for them. Where a component's
behaviour is a state transition, this file names it and points there. Duplicating a
state machine across two files is how the two versions diverge.

**This unit owns no entity and authors no business rule** — kind `ui` produces neither
`entities.md` nor `rules.md`. Every `BR` id referenced here is owned elsewhere.

**`OwnerEditor` decides nothing.** Every component below renders, holds local
presentation state, or transports. Where a reader might think otherwise, this document
says so explicitly.

---

## The file-as-unit rule

Every ported file is in exactly one of two states, and **the file is the unit** — not
the edited region, because "untouched region" is not a property any tool can evaluate.

- **Unmodified** — byte-identical to its `madhavi-tripathi/` original **except** import
  specifiers and the rewired data-access call. Keeps the dense house style entirely.
- **Modified** — listed in `chiku-website/frontend/PORTED-MODIFIED.md` with **one line**
  saying what changed and why, and then the **whole file** is formatted conventionally.

The merge gate runs `git diff --no-index` for every file **not** on that list and fails
if any hunk is neither an import nor a data-access call. The source tree stays in the
repository, so this costs nothing to run.

**Why the dense style is kept, and what it costs.** The code scan adjudicated the
extremely dense single-line style as **deliberate, consistently applied house style
rather than defect**. With zero tests in the source, a line-granular diff of a ported
file against its original is the **only cheap parity evidence** there is, and a
formatter destroys that evidence for exactly the files that hide the most branches.
The cost is **two styles in one tree** for the duration. Normalisation happens **once,
after parity is signed off**, in a single mechanical commit — not during the port.

**This unit has an unusually high modified ratio.** Five of its seven ported files are
rewired or modified, because every one of them either called the database directly or
performed validation that has moved to Python. That is expected and is the point of the
migration; it also means **this unit carries most of the parity risk that the DOM diff
must catch**, since a modified file gets no line-granular diff.

---

## Components

| Component | Source | State | Responsibility |
|---|---|---|---|
| `app/edit/page.tsx` | route | **Rewired** | Becomes a **client shell**. No server-side auth gate; the browser fetches with credentials and a **401/403 redirects to sign-in** |
| `app/edit/editor.tsx` | the editor | **Modified** | Tab set, fields and layout **byte-identical**; the `/api/history` call goes through the generated client. Hosts the browser-tool registration |
| `app/edit/editor-workflow.ts` | state machine | **Modified** | The save/recovery/conflict machine. **Specified in `functional-spec.md`**, not here |
| `app/edit/upload-field.tsx` | uploads | **Modified** | **No longer prepares WebP variants in the browser**; uploads the original and lets Python derive variants |
| `app/edit/draft-preview.tsx` | preview | **Byte-identical** | Renders the held draft |
| `app/edit/preview/page.tsx`, `preview-client.tsx` | preview route | **Rewired** | Client shell; the **`postMessage` protocol, origin check and 6,000,000 bound are unchanged**; the frame's schema parse becomes `POST /api/content/inspect` |
| `app/login/page.tsx` | sign-in | **New file**, conventional style | Email + password, posts to `/api/auth/login`, stores nothing |

### `app/edit/page.tsx` — the client shell

**The server-side auth gate is removed**, and that is a **strengthening**, not a
relaxation. Under the language boundary the frontend may not authenticate (NFR1), and
under BR3.1 **every operation authorises itself** regardless of how the request
arrived — so a route-level gate was never the enforcement and its removal takes nothing
away.

The shell fetches with credentials; **a 401/403 redirects to sign-in**. A visitor who
navigates straight to `/edit` without a session sees the sign-in redirect, and a
visitor who bypasses the frontend entirely is rejected identically by the backend.

`robots.txt` disallows `/edit` (FR2.4), **and that exclusion is never the only thing
protecting it** (FR2.6).

### `app/edit/editor.tsx` — tabs, fields, layout

**Tab set, fields and layout are byte-identical.** Every editing surface that exists
today exists after the migration (FR8.1): profile, highlights, research, publications,
journey, notes and news, the three-dimensional story, Scholar highlights, website text,
and appearance.

Two changes only: the `/api/history` call goes through the generated client, and this
file hosts the **browser-tool registration** (see below).

**Focal-point, alternative-text, caption and transcript controls are unchanged**,
including their keyboard operation (FR8.7) — which is a tested property, not an assumed
one, because NFR7 requires keyboard operation on every changed interface.

### `app/edit/editor-workflow.ts` — the state machine

**Modified.** This file holds the save, recovery and conflict machine.

**It is specified in this unit's `functional-spec.md`** — **fourteen states across five
orthogonal regions** (`Recovery` 5, `Uploads` 2, `Concurrency` 2, `Pause` 2, `Write` 3),
the **four** autosave suspensions and the `unsuspended` predicate that composes them, the
three recovery outcomes, `latestLoaded`'s effect in **all five** `Recovery` states, the
explicit-save refusal table, the `saveInvalid` / `saveFailed` split, and the
**base-revision advance rule**. It is not restated here. **The text of that section is
authoritative; its diagram is illustrative** — a reversal of the previous draft, recorded
there.

**This file also raises the oversize-draft warning.** `chooseRecovery`
(`editor-workflow.ts:71`) shows
`This recovered draft is too large to save. Your edits are here; shorten the draft before saving.`
when the restored draft's save payload would exceed the save cap. **It is the only new
user-facing string this unit adds**, it warns without blocking, and it exists because the
site owner decided at the gate to preserve all three size bounds rather than lower any of
them. Trigger, measured subject and the constant-drift risk are in `functional-spec.md`
§ *The oversize-draft warning at restore*.

One component-level fact belongs here: **`contentSchema.safeParse` leaves this unit
entirely**, and with it the last frontend dependency on `zod`. **There are seven call
sites, not three** — the earlier three-item list omitted four of them, and two of the
omitted four carry product copy:

| # | Call site | What it does today | What it becomes |
|---|---|---|---|
| 1 | `editor-workflow.ts:17` `parseRecovery` | classifies the recovered draft | **`POST /api/content/inspect`** (ADR-006) |
| 2 | `editor-workflow.ts:54` `save` | pre-save validation | the backend's `issues[]`, which the editor already renders |
| 3 | `editor-workflow.ts:73` `reloadLatest` | parses the draft the backend **just returned** | the branch collapses to `!response.ok`; the sentence `The latest draft could not be loaded. Your edits remain here.` is preserved |
| 4 | `editor.tsx:62` `select` | parses a revision fetched from `/api/history` | as above; the sentence `This revision could not be loaded.` is preserved |
| 5 | `editor.tsx:74` `manualSave` | a **second** pre-save gate with its **own** sentence | the backend's `issues[]`, arriving as **`saveInvalid`**; the sentence `Check these fields before saving. Your edits are kept in this browser.` is preserved **and its trigger is specified** in `functional-spec.md` § *A validation rejection is not a failed write* |
| 6 | `editor.tsx:75` `startPreview` | gates whether the preview opens at all | **`POST /api/content/inspect`**; the sentence `Check the highlighted fields before opening the preview.` is preserved |
| 7 | `preview/preview-client.tsx:9` | bounds at 6,000,000 and parses the posted draft | the bound **stays**; the parse becomes **`POST /api/content/inspect`**; the sentence `This draft contains a field that needs attention. Return to the editor to review it.` is preserved |

**Sites 2 and 5 carry a consequence beyond the sentences, and it is specified in
`functional-spec.md`, not here.** Both were **pre-flight gates that returned before
dispatching**, so a schema-invalid save was never a *failed* write in the source and never
set the `paused` flag. Routing them to the backend's `issues[]` would, under one
undifferentiated rejection event, add a suspension the source did not have for the
commonest owner error. The save outcome is therefore **two** events — `saveInvalid` (a
`400` with `issues[]`, consumed by the `Write` region only) and `saveFailed` (everything
else, consumed by `Write` **and** `Pause`). See `functional-spec.md` § *A validation
rejection is not a failed write*; it is not restated here.

**Sites 3 and 4 lose only half a branch.** `!response.ok || !parsed.success` becomes
`!response.ok`: a document the backend itself just normalised and returned cannot fail
the backend's own schema, so the second half has no reachable case. **Both sentences
survive**, because the `!response.ok` half is what raises them.

**Sites 2 and 5 are a parity trap and are called out for that reason.** They carry two
sentences that differ by one word — `Check the highlighted fields before saving. Your
edits are kept in this browser.` (site 2) and `Check these fields before saving. Your
edits are kept in this browser.` (site 5) — and **site 2's appears to be unreachable**:
`save()` has exactly two callers, `manualSave` (which gates first, so site 5 fires) and
the autosave effect (which passes `automatic = true`, and site 2 sets its error only when
`!automatic`). **Both strings still port character-exact**, and the unreachability is
recorded as a claim for the U1 fixtures to confirm rather than as licence to drop one.

**No hand-written mirror replaces any of these.** Sites 1, 6 and 7 move the decision to
Python; the rest read the backend's own answer. **`zod` leaves the frontend dependency
list**, and only **generated** constraints may inform client-side UX (BR8.9).

### `app/edit/upload-field.tsx` — uploads

**Modified.** The browser **no longer prepares WebP variants**. It uploads the original;
Python derives the variants with Pillow (FR6.5, D24).

This removes the entire browser-side image-processing path — `image-processing.ts` and
`upload-validation.ts` are **retired**, and the four error strings that verified
browser-prepared variants are **deliberately retired** with them (BR10.9, owned by
`u6-http-api`). **Do not re-create the checks in order to keep the strings alive.**

**The upload response's `sources[]` changes for every upload**, not only for images the
browser would have pre-processed (BR6.23, owned by `u5-media`). This component must
therefore not assume an empty `sources[]` means "unprocessed".

While an upload is in flight this component's state feeds the `Uploading` suspension
and the leave warning — both specified in `functional-spec.md`.

### `app/edit/draft-preview.tsx` and the preview route

`draft-preview.tsx` is **byte-identical** — it is the parent side of the protocol and
nothing in it changes: the `send()` on `academic-preview-ready` and on `onLoad`, the
re-send on `[theme, content, ready]`, the ten-second watchdog with
`The preview is taking longer than expected. Your draft is still in the editor.` and its
`Reload preview` control all carry over untouched. **That watchdog is load-bearing in the
new design** — it is the existing copy that surfaces a preview which did not come back —
so it must not be trimmed as dead code.

The route components are **rewired** to client shells.

**The `postMessage` protocol and its origin check are unchanged.** The editor posts the
held draft into an isolated frame; the frame accepts a message only when the origin, the
source and the message type all match. An unchecked origin would let any embedding page
inject content into a surface the owner reads as their own.

**`preview-client.tsx` keeps its 6,000,000-character bound and replaces its
`contentSchema.safeParse` with `POST /api/content/inspect`**, rendering the returned
`normalised` document. **`functional-spec.md` § *The private draft preview* is
authoritative** for the full message-handling contract — what is ignored silently, which
outcomes show `This draft contains a field that needs attention. Return to the editor to
review it.`, which leave the parent's watchdog to speak, and **when an identical payload
may reuse a cached verdict and when it must re-issue**. It is not restated here.

**One component-level consequence of the reuse rule belongs here**, because it is the
reason `draft-preview.tsx`'s watchdog stays load-bearing: the frame caches **only**
verdicts it actually received (`200` or `400`), so a `Reload preview` after a `503`, a
`403` or a network failure **always issues a fresh request**. A cache that also remembered
failures would silence the one control the design relies on to recover from them.

**`editor.tsx`'s `startPreview` becomes asynchronous** and calls the same operation, so
that an invalid draft still never opens the preview and still reports
`Check the highlighted fields before opening the preview.`

**The preview still needs no backend operation of its own** — `GET /api/content` already
returns the draft, stated explicitly in `contract-summary.md` § C1 (R-02) *"because
leaving it implicit invites a redundant endpoint"*, and `POST /api/content/inspect` is an
**existing** C1 operation rather than a preview-specific endpoint.

**`preview/page.tsx`'s server-side gate carries three strings that the client shell
retires** — `Private draft preview`, `Sign in as the website owner to preview a draft.`
and `Open the editor` — replaced by the sign-in redirect every other `401`/`403` in this
unit takes, to the same destination that copy's link offered. Recorded so the loss is a
visible consequence of the rewire rather than an oversight.

### `app/login/page.tsx` — new

**New file, conventional style from the first line** (no parity obligation — there is
nothing to be byte-identical to).

Email and password, posted to `POST /api/auth/login`. **It stores no credential, holds
no token in JavaScript-reachable storage, and renders the backend's 403 sentence
unchanged** — one sentence whether the account is unknown, the password is wrong, or
the rate limit was reached (BR3.20, owned by `u3-identity-and-session`). **No "too many
attempts" message and no `Retry-After`** — either one enumerates.

The CSRF token returned in the body is held in memory and attached to mutations by
`u7-api-client`.

---

## The browser tool — component-level notes

`stage_academic_profile` is registered from `app/edit/editor.tsx` inside a `useEffect`
with an **empty dependency array**, so it registers **once per mount** and its
`AbortController.abort()` is the effect's cleanup.

**The full registration, `execute` behaviour, product-copy literals, the
silent-registration-failure behaviour and the verified cap defect are in
`functional-spec.md`** § *The browser tool*, **including the two changes the site owner
decided at the functional-design gate**: the field-length check is **removed** (the
backend rejects over-long input at save, asynchronously — an accepted parity change), and
`untrustedContentHint` is **flipped to `true`**. Everything else in the registration is
character-exact. Two component-level consequences:

- **It calls `edit(...)`, `setTab('profile')` and `setMessage(...)` — three of this
  file's own state setters.** It is not a separate surface; it is a second way to drive
  the same form state, which is exactly why it needs no save path of its own.
- **Registration failure is swallowed and the editor renders normally.** So the tool's
  presence is **not** a precondition of this component mounting, and `editor.tsx` must
  not be written as though it were.

---

## Shared code, and where it lives

**The 11 vendored `components/ui/*` are carried by `U8 public-site`** and **consumed**
by this unit. Their MIT notice travels with them.

This is the disposition of the open item `ADR-005` left for units generation —
*"shared presentation code belongs to neither component cleanly"* — and it creates a
**build-order dependency without a DAG edge**: this unit cannot type-check before U8
has landed those files. `delivery-planning` owns the sequencing. **This unit must not
vendor its own copy** to break the dependency; two copies of a design system is how the
two surfaces drift apart.

**49 vendored components (6,139 lines) do not cross at all** (D22), and neither do the
13 unimported dependencies.

---

## Accessibility (NFR7)

Permitted **only where nothing moves visually**: heading order, labels, ARIA
attributes, focus handling, contrast tokens, reduced-motion support. **Every such change
puts the file on `PORTED-MODIFIED.md` with its reason.** No conformance claim is made
beyond what is tested.

**The one agreed user-visible behavioural change is not in this unit** — the carousel
keyboard-focus fix belongs to `U8 public-site`. This unit's accessibility obligation is
the **keyboard operation of the focal-point and caption controls** (FR8.7), which is
preserved rather than changed.

---

## Parity verification for this unit

**A byte-identical component given identical props cannot render differently**, so the
parity surface concentrates in `PORTED-MODIFIED.md` plus the CSS.

**For this unit that surface is large** — five of seven files are modified or rewired —
so the two mechanisms are:

1. **The normalised DOM-structure diff** against the fixtures recorded in U1: strip
   volatile attributes, build hashes and whitespace, then diff the element tree and
   text content per route. **Pixel screenshot comparison was considered and rejected**,
   not deferred: brittle against fonts, antialiasing and animation.
2. **The page-by-page human review at the end**, recorded as a checklist.

**And, for this unit only, a third:** the **mandatory browser check**. The DOM diff
compares rendered output; it cannot observe *when* an autosave fires, whether a
suspension held, or whether a base revision advanced. See `functional-spec.md`
§ *The consequence for verification* for why this is mandatory and what it must cover.

---

## `PORTED-MODIFIED.md` entries this unit contributes

| File | One-line reason |
|---|---|
| `app/edit/page.tsx` | Client shell; server-side auth gate removed — authorization is per operation in Python (NFR1, BR3.1) |
| `app/edit/editor.tsx` | `/api/history` call routed through the generated client; `startPreview` now validates via `POST /api/content/inspect`; browser-tool registration retained, with its field-length check removed and `untrustedContentHint` set to `true` (gate decisions) |
| `app/edit/editor-workflow.ts` | `contentSchema.safeParse` removed; recovery classification delegated to `POST /api/content/inspect` (ADR-006); save outcome split into `saveInvalid` / `saveFailed` so a validation rejection no longer pauses autosave; oversize-draft warning added at restore (gate decision) |
| `app/edit/upload-field.tsx` | Browser-side WebP variant preparation removed; Python derives variants (FR6.5, D24) |
| `app/edit/preview/page.tsx`, `preview-client.tsx` | Client shells; `postMessage` protocol, origin check and 6,000,000 bound unchanged; the frame's schema parse delegated to `POST /api/content/inspect` |

`app/edit/draft-preview.tsx` is **not** on the list — it stays unmodified and is checked
by `git diff --no-index` at the gate. `app/login/page.tsx` is **new** and has no
original to diff against.

---

## Assumptions & Open Questions

- **[CORRECTION to the workflow-level artifact]**
  `construction/functional-design/frontend-components.md` § *Assumptions & Open
  Questions* records the state-machine question with the position *"it is presentation
  state"* — **which this unit confirms** — but states its consequence **backwards**:
  *"If that is wrong, the part that is a rule **crosses to Python**, and a browser-driven
  check becomes the only possible verification of it."* **A rule that crosses to Python
  becomes testable without a browser**, which ADR-006 states verbatim about the one rule
  that did cross. The condition that makes a browser check mandatory is **the machine
  staying in the frontend** — as `team.md` § *Testing Posture*, `WORKING-RECORD.md` § 9
  and `construction/functional-design/rules.md` § *Assumptions* all state correctly.
  **The position is confirmed; the conditional is corrected.** Full reasoning in
  `functional-spec.md` § *The consequence for verification*. The workflow-level file is
  **not edited by this unit**.
- **[CLOSED, this stage]** The open item this unit was assigned — whether any part of
  the multi-flag save state machine is a rule — is **closed as presentation state**,
  with three named carve-outs. See `functional-spec.md` § *The save state machine — the
  adjudication*. **Playwright moves from optional to mandatory** as a direct consequence.
- **[CORRECTION, this iteration]** An earlier draft of this file listed **three**
  `contentSchema.safeParse` call sites and described the preview's as *"removed; the
  preview renders what the editor holds, and the backend validated it at save"*. **There
  are seven sites**, and that justification is false for the preview — FR8.6 renders the
  **unsaved** draft, which nothing has validated. The table in § *`editor-workflow.ts`*
  above replaces the list; the preview's validation moves to `POST /api/content/inspect`
  rather than disappearing, and every sentence it raised is preserved.
- **[DECIDED at the functional-design gate — two changes to the preserved browser tool]**
  Both are recorded in full in `functional-spec.md` § *The browser tool* and
  § *Assumptions & Open Questions*. **(1) The field-length check is removed**: the tool
  stages the input and the backend rejects at save with `issues[]`, so a field longer than
  10,000 characters is now rejected **at save rather than synchronously in the browser**.
  That is a parity change and it was accepted as one; it contradicts FR8.8's *"validates
  field names **and lengths**"* and is recorded as a requirements amendment. **No
  generated runtime validator is provisioned** — the surface `u7-api-client` provisions is
  `openapi-typescript`'s compile-time types, which cannot enforce a runtime `maxLength` —
  and **no hand-written cap is added**, which `project.md` § *Forbidden* prohibits
  outright. The earlier *"use the generated mirror"* recommendation is **withdrawn and
  removed**, not restated as an option. **(2) `untrustedContentHint` is flipped to
  `true`**, which changes no behaviour and costs nothing.
- **[note — an architectural property, not a gap]** **There is no browser-side runtime
  validation anywhere in this corpus.** `zod` leaves the frontend, the generated surface
  is compile-time only, and hand-writing one is forbidden — so every runtime validation
  decision is Python's, reached over HTTP. Stated once, with the four places that would
  otherwise each read as a missing check, in `functional-spec.md` § *There is no
  browser-side runtime validation anywhere in this corpus, by design*.
- **[open, OWNER `contract-design` / `u6-http-api`]** **Whether `POST
  /api/content/inspect` counts as a mutation for the double-submit CSRF requirement.**
  The preview frame is a separate browsing context holding no in-memory token, so the
  answer decides whether it can call the operation itself. Position and fallback are in
  `functional-spec.md` § *The private draft preview*; **the decision is not this unit's
  to take and this iteration does not take it.** One consequence is now spelled out
  there rather than left implicit: under the fallback, `startPreview` posts `normalised`
  instead of the form content, **superseding** the decision recorded in § *The editor's
  gate*, and the frame renders the document the editor normalised rather than one it
  normalised itself.
- **[open, owner `delivery-planning`]** **Shared frontend code has no DAG edge.** The 11
  vendored components are carried by U8 and consumed by this unit, so this unit cannot
  type-check before U8 lands them. Recorded in `WORKING-RECORD.md` § 9 as owned by
  `delivery-planning`; unchanged here. **This unit must not resolve it by vendoring its
  own copy.**
- **[DECIDED at the functional-design gate — the three size bounds]** The
  **6,000,000-versus-1,500,000** mismatch lands in this unit **twice**:
  `editor-workflow.ts:15` (the recovery bound, over the whole stored record) and
  `preview-client.tsx:9` (the preview bound, over `content` alone), against the save cap
  at `app/api/content/route.ts:11` (over the whole request body). **All three are
  preserved — nothing is lowered — and the owner is warned at restore** when a recovered
  draft's save payload would exceed the save cap. The warning is new copy and therefore a
  parity change, accepted for that reason. **`POST /api/content/inspect`'s body cap is set
  to match the recovery bound**, so a draft that is recoverable is always inspectable;
  **that cap is `contract-design` / `u6-http-api`'s and is being changed in parallel —
  this unit depends on it and does not specify it.** Full decision in `functional-spec.md`
  § *Assumptions & Open Questions*, warning behaviour in § *The oversize-draft warning at
  restore*.
- **[open, carried to `code-generation`, OWNER `u6-http-api`]** **The warning's threshold
  is a backend-owned number held in the browser.** If `PUT /api/content`'s body cap
  changes and the frontend constant does not, the warning misfires or goes silent, and
  **no merge-gate check catches it**: the generated `openapi-typescript` surface carries
  no body-size cap, so the gate's dirty-check has nothing to compare. Recorded with a
  named owner rather than left as drift.
- **[assumption, carried]** The **11 vendored components carried by U8 are exactly the
  imported set.** The count comes from the scan; **a missed import surfaces at
  `tsc --noEmit`, cheaply**.
- **[assumption, carried]** Removing browser-side variant preparation changes no
  visitor-visible behaviour, because the same variant sizes are produced — just in
  Python. **If Pillow's output differs perceptibly from Canvas's, that is a parity
  question the DOM diff will not catch and the human pass must.**
- **[assumption, this unit]** `app/edit/editor.tsx` is listed as **Modified** rather than
  Unmodified because it hosts the rewired `/api/history` call. Under the file-as-unit
  rule that means the **whole file** is reformatted conventionally — and it is this
  unit's largest file. **The parity cost is real**: it loses its line-granular diff, and
  its tab set, fields and layout are then evidenced only by the DOM diff and the human
  pass. Recorded because the workflow-level artifact describes it as *"tab set, fields
  and layout byte-identical"*, which is true of the **rendered output** and not of the
  **file**.
- **[note]** This unit produces **no `entities.md` and no `rules.md`** — kind `ui` is
  absent from both `produces_kinds` lists. That is a property of the unit, not of the
  packaging: `OwnerEditor` owns no persisted entity and authors no business rule. The
  three rules that govern it — **BR8.6, BR8.7, BR8.8** — are owned by `OwnerEditor` but
  **declared once**, in `construction/functional-design/rules.md`.

## Sources

- `construction/functional-design/frontend-components.md` §§ *What carries across, and
  in what state*, *The file-as-unit rule*, *U9 — owner-editor*, *The recovery flow*,
  *Client-side validation*, *The browser tool*, *Accessibility*, *Parity verification* —
  **extended and scoped here**, with the one conditional corrected above.
- `construction/owner-editor/functional-design/functional-spec.md` — **authoritative for
  every workflow and state machine this file references**, and for the verified
  browser-tool detail.
- `construction/functional-design/rules.md` § `OwnerEditor` (BR8.6–BR8.8); § `HttpApi`
  BR3.20 (the non-enumerating sign-in refusal), BR10.9 (the four retired strings).
- `aidlc/spaces/default/codekb/Chiku_website/component-inventory.md` — the file
  inventory, the 11-of-61 vendored split, the 49 unreachable components.
- `inception/domain-design/decisions.md` **ADR-005** (the frontend is two components
  plus a client; shared presentation code belongs to neither cleanly), **ADR-006** (the
  classification is a backend rule).
- `inception/contract-design/contract-summary.md` § C1 — `GET /api/content` backing the
  private draft preview (R-02), `POST /api/content/inspect`.
- `inception/requirements-analysis/requirements.md` FR2.4, FR2.6, FR6.5, FR8.1–FR8.9,
  NFR1, NFR7, NFR10.
- `inception/units-generation/unit-of-work.md` § *U9 — owner-editor*.
- `aidlc/spaces/default/memory/team.md` §§ *Code Style* → *TypeScript / React* (the
  file-as-unit rule, the two states, why the dense style is kept, the vendored MIT
  notices), *Testing Posture* (the DOM diff, the rejection of pixel comparison, the
  Playwright condition); `aidlc/spaces/default/memory/project.md` §§ *Forbidden*, 
  *Mandated*.
- `WORKING-RECORD.md` §§ 2 (D9, D18, D20, D22, D24), 5 (the ported-file rule), 9 (the
  shared-frontend-code item, the state-machine item, the unassigned latent defect).
- `scratchpad/webmcp-tool-verified.md` — the verified browser-tool registration and the
  cap defect.
- **The source files themselves, read directly for this iteration** — the seven
  `contentSchema.safeParse` call sites and their surrounding copy are quoted from
  `madhavi-tripathi/app/edit/editor-workflow.ts` (`:17`, `:54`, `:73`),
  `madhavi-tripathi/app/edit/editor.tsx` (`:62`, `:74`, `:75`),
  `madhavi-tripathi/app/edit/preview/preview-client.tsx:9`,
  `madhavi-tripathi/app/edit/draft-preview.tsx` (the parent protocol and its watchdog)
  and `madhavi-tripathi/app/edit/preview/page.tsx` (the retired sign-in copy).
- `construction/api-client/functional-design/entities.md` § *generated_surface* — the one
  sanctioned sibling spot-check, which establishes that the generated frontend surface is
  `openapi-typescript`'s **compile-time types** and therefore cannot carry a runtime cap.
