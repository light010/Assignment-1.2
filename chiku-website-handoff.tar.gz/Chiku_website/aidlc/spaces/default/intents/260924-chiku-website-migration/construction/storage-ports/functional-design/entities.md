# Entities — U2 `storage-ports`

**Unit:** `storage-ports` · **Kind:** `library`

**Upstream:** `construction/functional-design/entities.md` (the six entity
schemas), `inception/contract-design/contract-summary.md` §§ C2, C3, C4 (the port
operations), `inception/units-generation/unit-of-work.md` § U2,
`WORKING-RECORD.md` §§ 2 (D4), 5.

---

## This unit owns no entity. Say it plainly.

**Every one of the six entities is owned by another unit.** `storage-ports`
defines and implements *persistence*; it owns no business rule and no entity.
Stated in the unit's own words: *"it does not know what a revision means, only how
to store one."*

| Entity | Owning component | Owning unit | Persisted through |
|---|---|---|---|
| `OwnerAccount` | `OwnerIdentity` | U3 `identity-and-session` | `IdentityStore.owner_record` |
| `Session` | `SessionAuthority` | U3 `identity-and-session` | `IdentityStore.session` |
| `LoginAttemptWindow` | `LoginGuard` | U3 `identity-and-session` | `IdentityStore.login_attempts` |
| `ContentDocument` | `ContentAuthority` | U4 `content-core` | `ContentStore.read_state` / `ContentStore.commit` |
| `ContentRevision` | `RevisionLedger` (written by `ContentAuthority`) | U4 `content-core` | `ContentStore.commit` / `list_revisions` / `read_revision` |
| `Asset` | `MediaIntake` | U5 `media` | bytes → `AssetStore`; the metadata row → `ContentStore.asset_metadata` |

## Source of truth — the persisted shapes

The block below is **authoritative for this unit**; the prose that follows it is
the human-readable summary. Every record is a *persisted shape*, not an entity
this unit owns — `owned_by` on each names the component that does own it, and
`owning_unit` names the unit that specifies its meaning.

```yaml
source_of_truth: entities
stage: functional-design
unit: u2-storage-ports
kind: library
kind_note: >
  U2 storage-ports is a LIBRARY. U6 http-api is the only unit declaring service -
  there is exactly one deployed Python executable. The three ports, their adapters
  and their fakes are embedded in it.
authority: >
  This block is the source of truth and governs. The prose below carries the
  summary, the rationale and the failure mode for each shape, and must not
  contradict it.
components: [ContentStore, IdentityStore, AssetStore]
owns_entities: none
owns_entities_note: >
  Every one of the six system entities is owned by another unit. What this unit
  specifies is the PERSISTED SHAPE each port stores - the record and object layout -
  so an adapter author can implement from this file alone. Each shape names its
  owning component and owning unit.
persisted_shapes:

  - name: ContentDocumentRecord
    port: ContentStore
    owned_by: ContentAuthority
    owning_unit: U4 content-core
    cardinality: singleton
    description: >
      The one content document. Holds the draft and published payloads opaquely,
      the monotonic revision, both timestamps, and the mutation token that guards
      the combined write's side effects. Never more than one record exists.
    attributes:
      - { name: id, type: fixed-key, required: true, unique: true, constraints: "A constant, not a generated identifier. Not a collection key." }
      - { name: draft, type: serialised-payload, required: true, constraints: "Opaque. Round-trips byte-identically. Overwritten by every accepted write, publishes included." }
      - { name: published, type: serialised-payload, required: true, constraints: "Opaque. Round-trips byte-identically. Moved only by a publish write." }
      - { name: revision, type: integer, required: true, default: 0, min: 0, constraints: "Monotonic; +1 per accepted write. Must hold values up to the platform's largest safe integer." }
      - { name: updated_at, type: instant-iso8601-utc, required: true, constraints: "Set on every accepted write. Supplied by the caller, not read from an adapter clock." }
      - { name: published_at, type: instant-iso8601-utc, required: false, default: null, constraints: "Null until the first publish. The seeded document is not published." }
      - { name: last_mutation, type: opaque-token, required: false, default: null, constraints: "The token stamped by the most recent accepted write. The ABA guard for BR4.11 and BR4.12. Omitting this column silently removes a concurrency defence." }
    entity_constraints:
      - "hasUnpublishedChanges has no column; it is computed by the consumer on every read."
      - "Creation happens only inside the combined write's bootstrap step, and only when the caller claims revision 0. The read path never creates it."
      - "At bootstrap the seed payload is written to BOTH payload columns, revision 0, published_at null."
    relationships:
      - { to: ContentRevisionRecord, cardinality: "1 : 0..52 visible / unbounded-then-pruned", direction: "a revision entry records a past state of this record" }

  - name: ContentRevisionRecord
    port: ContentStore
    owned_by: RevisionLedger
    written_by: ContentAuthority
    owning_unit: U4 content-core
    cardinality: collection
    description: >
      One past state of the content document. Two permanent baselines plus the
      retained normal entries. Written only inside the combined write; read by
      the listing and by single-entry fetch.
    attributes:
      - { name: id, type: text, required: true, unique: true, constraints: "The write's mutation token for a normal entry; the fixed literals 'starting-published' or 'starting-draft' for the two baselines. Two value shapes, one identity column." }
      - { name: revision, type: integer, required: true, unique: false, constraints: "NOT unique - a baseline pair and a normal entry can share one. An adapter must not add a uniqueness constraint." }
      - { name: action, type: enum, required: true, allowed_values: [draft, publish] }
      - { name: content, type: serialised-payload, required: true, constraints: "The document AS WRITTEN, read back from the record's draft column by the write itself - not the caller's argument." }
      - { name: created_at, type: instant-iso8601-utc, required: true, constraints: "Read back from the record's updated_at for a normal entry. For a baseline, the time of capture - never a guessed original publication date." }
      - { name: baseline, type: boolean, required: true, default: false, constraints: "True only for the two starting entries. Stored as an integer by the verified adapter and coerced on read. Baselines are never pruned." }
    entity_constraints:
      - "Listing order is revision DESC, then baseline ASC, then action DESC - all three parts, capped at 52, no pagination."
      - "Retention selection orders by revision DESC alone and is NOT tiebreak-stable; the indeterminacy is inherited and must not be fixed."
      - "The two baselines are captured at most once in the document's lifetime, under fixed identities and insert-if-absent semantics."
    relationships:
      - { to: ContentDocumentRecord, cardinality: "0..n : 1", direction: "each entry belongs to the one content document" }

  - name: AssetMetadataRecord
    port: ContentStore
    owned_by: MediaIntake
    owning_unit: U5 media
    cardinality: collection
    description: >
      The row half of an asset. Row-shaped, so it lives in ContentStore rather
      than in AssetStore. Holds the display filename, the validated media type
      and the optional image dimensions.
    attributes:
      - { name: key, type: text, required: true, unique: true, constraints: "Of the form <uuid4>.<ext>. The same key addresses the bytes in AssetStore." }
      - { name: filename, type: text, required: true, max: 200, constraints: "The user's original filename, already truncated by the consumer. Display only; the store derives nothing from it." }
      - { name: media_type, type: enum, required: true, allowed_values: ["image/jpeg", "image/png", "image/webp", "application/pdf", "video/mp4", "video/webm", "text/vtt"], constraints: "The VALIDATED type. The store records it and validates nothing." }
      - { name: byte_size, type: integer, required: true, min: 1 }
      - { name: width, type: integer, required: false, default: null, constraints: "Images only; null otherwise." }
      - { name: height, type: integer, required: false, default: null, constraints: "Images only; null otherwise." }
      - { name: created_at, type: instant-iso8601-utc, required: true }
      - { name: derived_from, type: text, required: false, default: null, references: AssetMetadataRecord.key, constraints: "The key of the original this variant came from; null for an original." }
    entity_constraints:
      - "This record's media_type is what the serving response carries - NOT AssetStore.head's. The two stores hold it independently."
      - "No ordinary deletion path exists; remove() serves the best-effort cleanup of a failed or cancelled upload only."
    relationships:
      - { to: AssetObject, cardinality: "1 : 1", direction: "addresses the same key, across two stores with NO shared transaction" }
      - { to: AssetMetadataRecord, cardinality: "0..1 : 0..n", direction: "derived_from points a variant at its original" }

  - name: OwnerRecord
    port: IdentityStore
    owned_by: OwnerIdentity
    owning_unit: U3 identity-and-session
    cardinality: singleton
    description: >
      The single site owner and the argon2id hash of their password. Exactly one
      ever exists; the store ships none and seeds none.
    attributes:
      - { name: owner_id, type: text, required: true, unique: true, constraints: "Opaque; never derived from the email." }
      - { name: email, type: text, required: true, max: 200 }
      - { name: password_hash, type: text, required: true, constraints: "An argon2id PHC-encoded string, stored verbatim. Never parsed, compared or logged by the store." }
      - { name: created_at, type: instant-iso8601-utc, required: true }
      - { name: password_updated_at, type: instant-iso8601-utc, required: false, default: null }
    entity_constraints:
      - "create_if_absent is the one-shot provisioning gate; the gate condition is the record's existence, not a consumed flag."
      - "create_if_absent must be atomic against a concurrent caller: one record, one refusal."
      - "No default, seeded, sample or hard-coded credential exists in the adapter, its schema setup, or its fixtures."
    relationships:
      - { to: SessionRecord, cardinality: "1 : 0..n", direction: "each session belongs to the one owner" }

  - name: SessionRecord
    port: IdentityStore
    owned_by: SessionAuthority
    owning_unit: U3 identity-and-session
    cardinality: collection
    description: >
      One issued session. Stores both expiry bounds separately so that the idle
      window can slide without extending the absolute one.
    attributes:
      - { name: session_id, type: text, required: true, unique: true, constraints: "Opaque and unguessable. The store generates nothing." }
      - { name: owner_id, type: text, required: true, references: OwnerRecord.owner_id }
      - { name: issued_at, type: instant-iso8601-utc, required: true, constraints: "Set once, never changed." }
      - { name: last_seen_at, type: instant-iso8601-utc, required: true, constraints: "Advanced by touch()." }
      - { name: absolute_expires_at, type: instant-iso8601-utc, required: true, constraints: "Computed once at issue and NEVER extended - not by touch(), not by anything." }
      - { name: revoked_at, type: instant-iso8601-utc, required: false, default: null, constraints: "Non-null means revoked server-side." }
      - { name: csrf_token, type: text, required: true, constraints: "Paired 1:1 with this session." }
    entity_constraints:
      - "read() evaluates NO expiry. The record is returned as stored; the consumer applies both bounds."
      - "touch() advances last_seen_at and must not touch absolute_expires_at."
      - "revoke() is a stored state change, not a cookie deletion; a revoked session must fail the very next read()."
    relationships:
      - { to: OwnerRecord, cardinality: "0..n : 1", direction: "belongs to" }

  - name: LoginAttemptWindowRecord
    port: IdentityStore
    owned_by: LoginGuard
    owning_unit: U3 identity-and-session
    cardinality: collection
    description: >
      One rolling failure window for one counted subject in one scope. Account
      and address are separate records, not two counters on one record.
    attributes:
      - { name: window_key, type: text, required: true, constraints: "Identity together with scope. The counted subject within its scope." }
      - { name: scope, type: enum, required: true, allowed_values: [account, ip], constraints: "Identity together with window_key." }
      - { name: failure_count, type: integer, required: true, default: 0, min: 0 }
      - { name: window_started_at, type: instant-iso8601-utc, required: true }
    entity_constraints:
      - "Persisted, so a process restart does not reset a window. An in-memory counter is not an acceptable real adapter."
      - "count_in_window compares against NO threshold; 5 and 20 are the consumer's numbers."
    relationships:
      - { to: OwnerRecord, cardinality: "0..n : 0..1", direction: "an account-scoped window may key on an account that does not exist" }

  - name: AssetObject
    port: AssetStore
    owned_by: MediaIntake
    owning_unit: U5 media
    cardinality: collection
    description: >
      The byte half of an asset, addressed by key. Holds no user-facing metadata
      row - that is AssetMetadataRecord, in the other store.
    attributes:
      - { name: key, type: text, required: true, unique: true, constraints: "Identical to AssetMetadataRecord.key." }
      - { name: bytes, type: opaque-bytes, required: true, constraints: "Stored and returned unchanged. No transcoding, re-encoding or normalisation." }
      - { name: size, type: integer, required: true, constraints: "Returned by head(); the exact stored length." }
      - { name: etag, type: text, required: true, constraints: "Returned by head() and emitted verbatim by the serving path. MUST be stable for unchanged bytes - the conditional-range comparison is exact string equality." }
      - { name: media_type, type: text, required: true, constraints: "Held INDEPENDENTLY of AssetMetadataRecord.media_type. The port does not reconcile them." }
    entity_constraints:
      - "get_range(key, offset, length) is a first-class operation: transfer only the requested bytes, never whole-object-then-slice."
      - "delete(key) is idempotent; deleting an absent key succeeds."
    relationships:
      - { to: AssetMetadataRecord, cardinality: "1 : 1", direction: "same key, two stores, NO shared transaction - a failure between the two writes leaves an orphan" }
```

**What this document is instead.** It is the **persisted shape** — the record and
object layout each port stores — written so that **an adapter author implements a
new adapter from this file alone**, without opening the workflow-level
`entities.md` and without opening any consumer unit. The field-level *validation*
of those values is the consumer's business and is deliberately absent here: a
store that re-validates content is a store that can disagree with its owner.

**The three separation lines, stated because an adapter author will be tempted to
cross them.**

1. `IdentityStore` is separate from `ContentStore` **because identity has a
   different reason to change and a different blast radius**: the credential hash
   and the session records are the highest-value data in the system, and a defect
   in a content query cannot reach them through a port that does not expose them.
2. `AssetStore` is separate from both **because a blob is not a row**, and the
   two cloud implementations are entirely different services with different
   consistency and pricing models.
3. The asset **metadata** row lives in `ContentStore`, not in `AssetStore`, for
   exactly one reason: it is row-shaped. The bytes and the row are therefore
   **two separate stores with no shared transaction** — see § *The one split that
   is not transactional*.

---

## The content blob is opaque, and it round-trips byte-identically

Every store below that holds a content document holds it as **one serialised
payload**, and the adapter's only obligation to it is that **what is read back is
byte-identical to what was written**. Three consequences, each of which has broken
a port before:

- **The adapter never re-serialises.** It does not re-order keys, does not
  re-encode, does not pretty-print, does not strip or add whitespace. The frozen
  wire format is an externally visible contract and the persisted content **is**
  that wire format; a store that normalises it has performed an undeclared data
  migration.
- **The adapter never applies a default and never runs the parse transform.**
  The content-carrying defaults (the research-topic and research-link maps) run in
  the consumer on every parse. A store that materialised them would produce values
  the owner never wrote, in a place nobody is looking.
- **The history entry's content is read back out of the stored column** by the
  combined write itself (see `rules.md` BR4.11), not taken from the caller's
  argument. A store whose read path differs from its write path by even one byte
  makes the revision entry disagree with the document it records.

The payload is **not size-bounded by this port at the shape level**: it must
accept a content document of up to **1,500,000 decoded characters**, which in
UTF-8 can exceed 4 MB. See § *The large-payload obligation*.

---

## `ContentStore` — three persisted record shapes

### 1. The content document record — a singleton

**Exactly one record ever exists**, under a fixed identity. It is not a
collection, and an adapter must not model it as one.

| Field | Type | Nullable | At bootstrap | Notes |
|---|---|---|---|---|
| `id` | fixed singleton key | no | the one record | A constant, not a generated identifier. |
| `draft` | serialised content payload | no | the seed document | Overwritten by **every** accepted write, publishes included. |
| `published` | serialised content payload | no | the seed document | Moved only by a publish write. |
| `revision` | integer | no | `0` | Monotonic, increments by exactly 1 per accepted write. Must hold values up to the platform's largest safe integer. |
| `updated_at` | instant (ISO-8601 UTC text) | no | the bootstrap instant | Set on every accepted write. |
| `published_at` | instant (ISO-8601 UTC text) | **yes** | **null** | Stays null until the first publish. The seeded document is **not** "published". |
| `last_mutation` | opaque token text | **yes** | **null** at bootstrap | The token stamped by the write that most recently touched this record. **Not a convenience field** — it is the ABA guard the combined write's side effects are gated on (`rules.md` BR4.8–BR4.19). An adapter that omits this column silently removes a concurrency defence. |

**`hasUnpublishedChanges` has no column and never will.** It is computed by the
consumer on every read as a comparison of `draft` against `published`. An adapter
that stores it as a flag has invented state the write path does not maintain.

**When no record exists, `read_state` returns the seeded document rather than
emptiness**, and **writes nothing**. The read path must never create the record —
creation happens only inside the combined write's bootstrap step, and only when
the caller claims revision 0.

### 2. The revision entry record — a collection

| Field | Type | Nullable | Notes |
|---|---|---|---|
| `id` | text, primary identity | no | For a normal entry this is **the write's mutation token**. For the two permanent baselines it is the fixed literal `starting-published` or `starting-draft`. Two value shapes, one identity column — deliberate, reproduced rather than tidied. |
| `revision` | integer | no | The revision this entry records. **Not unique**: a baseline pair and a normal entry can share one. An adapter must not add a uniqueness constraint here. |
| `action` | text, one of `draft` / `publish` | no | |
| `content` | serialised content payload | no | The document **as written**, read back from the record's `draft` column by the write itself. |
| `created_at` | instant (ISO-8601 UTC text) | no | For a normal entry, read back from the record's `updated_at` so entry and document agree exactly. For a baseline, the time of capture — **not a guessed original publication date**. |
| `baseline` | boolean | no | `true` only for the two starting entries. The locally verified adapter stores it as an integer and coerces it on read with a truthiness test; an adapter with a native boolean type uses that. Baselines are **never pruned**. |

**Ordering is part of the shape, not part of the query.** Listing order is
`revision` descending, then `baseline` ascending, then `action` descending, and
all three parts are load-bearing. See `rules.md` BR5.1–BR5.4 and the indexing
obligation below.

### 3. The asset metadata record — a collection

Row-shaped, therefore it lives in `ContentStore` rather than in `AssetStore`.

| Field | Type | Nullable | Notes |
|---|---|---|---|
| `key` | text, primary identity | no | The object key, of the form `<uuid4>.<ext>`. The same key addresses the bytes in `AssetStore`. |
| `filename` | text | no | The user's original filename, already truncated to its first 200 characters by the consumer. Display only. The store never derives anything from it. |
| `media_type` | text, one of seven values | no | The **validated** type. The store records what it is given and validates nothing. |
| `byte_size` | integer | no | `>= 1`. |
| `width` | integer | **yes** | Images only; null for the non-image types. |
| `height` | integer | **yes** | Images only; null for the non-image types. |
| `created_at` | instant (ISO-8601 UTC text) | no | |
| `derived_from` | text | **yes** | The key of the original this variant was generated from; null for an original. |

**The media type is held independently here and in `AssetStore`**, and the two
agree only because they are written from the same value at upload time. **Anything
that syncs only one will serve mismatched types.** An adapter must not try to
reconcile them; the serving rule reads this row's value deliberately.

**There is no deletion path for an asset in ordinary operation and no orphan
collection anywhere.** `remove` exists on this operation solely for the
best-effort cleanup of a failed or cancelled upload. Storage grows monotonically.
This is preserved behaviour, not an oversight for an adapter to fix.

---

## `IdentityStore` — three persisted record shapes

### 1. The owner record — a singleton

**Exactly one ever exists.** Do not model a collection; there is no multi-editor
account and no tiered role.

| Field | Type | Nullable | Notes |
|---|---|---|---|
| `owner_id` | text, primary identity | no | Opaque, generated at provisioning, **never derived from the email**. |
| `email` | text | no | At most 200 characters. |
| `password_hash` | text | no | An argon2id PHC-encoded hash string, **stored verbatim**. The store never parses it, never compares it, never logs it, and never returns it through any operation that is not the credential read. |
| `created_at` | instant (ISO-8601 UTC text) | no | |
| `password_updated_at` | instant (ISO-8601 UTC text) | **yes** | Null until the password is first changed after provisioning. |

**The store ships no record and no seed that creates one.** There is no default,
seeded, sample or hard-coded credential anywhere in the adapter, its migrations,
or its fixtures. The acceptance test is exactly: a fresh start against empty
storage has **no account anyone can sign in to**.

**`create_if_absent` is the one-shot provisioning gate**, and its gate condition
is **the record's existence** — not a consumed flag, not a marker file, not an
environment variable. A restart therefore cannot reopen it. The operation must be
**atomic against a concurrent caller**: two simultaneous provisioning attempts
must produce one record and one refusal, never two records and never a lost one.

### 2. The session record — a collection

| Field | Type | Nullable | Notes |
|---|---|---|---|
| `session_id` | text, primary identity | no | Opaque and unguessable. The store generates nothing; it records what it is given. |
| `owner_id` | text | no | Reference to the owner record. |
| `issued_at` | instant (ISO-8601 UTC text) | no | Set once at issue, **never changed**. |
| `last_seen_at` | instant (ISO-8601 UTC text) | no | Advanced by `touch`. |
| `absolute_expires_at` | instant (ISO-8601 UTC text) | no | Computed once at issue and **never extended**. |
| `revoked_at` | instant (ISO-8601 UTC text) | **yes** | Null means live. Non-null means revoked server-side. |
| `csrf_token` | text | no | Paired 1:1 with this session. |

**`touch` advances `last_seen_at` and must not touch `absolute_expires_at`.** That
asymmetry is the entire reason both timestamps are stored, and an adapter that
"helpfully" refreshes both destroys the 7-day absolute bound while every test that
only checks idle expiry still passes.

**`revoke` is a server-side state change on this record**, not a cookie deletion.
A revoked session must fail verification on the next read.

### 3. The login-attempt window record — a collection

Two independent counters exist per failed sign-in — one keyed by account, one
keyed by source address. They are **separate records with separate scopes**, not
one record with two counters.

| Field | Type | Nullable | Notes |
|---|---|---|---|
| `window_key` | text | no | The counted subject within its scope. Part of the record's identity together with `scope`. |
| `scope` | text, one of `account` / `ip` | no | |
| `failure_count` | integer | no | `>= 0`. |
| `window_started_at` | instant (ISO-8601 UTC text) | no | When the current rolling window began. |

**These records are persisted, so a process restart does not reset a window.** An
in-memory counter is not an acceptable implementation of this shape — including in
the in-memory fake, whose obligation is to behave identically *within a process
lifetime* and whose conformance suite therefore does not restart it.

---

## `AssetStore` — objects, not records

`AssetStore` holds **bytes addressed by key**. It stores no user-facing metadata
row: that is the asset metadata record in `ContentStore`, above.

| Held value | Type | Notes |
|---|---|---|
| key | text | `<uuid4>.<ext>`, identical to the metadata record's key. |
| bytes | opaque byte sequence | Stored and returned unchanged. No transcoding, no re-encoding, no normalisation. |
| size | integer | Returned by `head`. Must be the exact stored length. |
| entity tag | text | Returned by `head`, and emitted verbatim by the serving path. Must be **stable for unchanged bytes** — the serving path's conditional-range comparison is exact string equality against it. |
| media type | text | Returned by `head`. Held independently of the metadata record; see the warning above. |

**The ranged read lives in this port** — see `functional-spec.md` § `AssetStore`
and `rules.md` BR7.17. An adapter that implements `get_range` by fetching the
whole object and slicing it satisfies the signature and defeats the port's
purpose.

---

## The one split that is not transactional

**Asset bytes and asset metadata are two separate stores with no shared
transaction.** This is a property of the design, not an adapter shortcoming:
`AssetStore` holds the bytes, `ContentStore.asset_metadata` holds the row, and no
port operation spans them.

A failure between the two writes therefore leaves an **orphan**, and the consumer
reconciles it with a best-effort cleanup path that deletes every key written so
far from **both** stores. `AssetStore.delete` and `asset_metadata.remove` exist
for that path and for no other purpose.

**Do not attempt to fix this in an adapter** by making one store call the other.
Two stores that call each other are one store with a hidden dependency, and the
separation rationale above is what would be lost.

---

## Bootstrap and seeding

- **The content document is seeded**, with the seed payload in **both** the
  `draft` and `published` columns, at revision `0`, with `published_at` **null**.
  The seeding happens inside the combined write's bootstrap step under two guards
  (`rules.md` BR4.8), not as a migration side effect.
- **The two revision baselines are captured once ever**, by the combined write,
  under fixed identities. They are not seeded by a migration and they are never
  pruned.
- **Nothing else is seeded.** Specifically: **no owner record**, ever.

---

## Indexing and ordering obligations

- The revision listing's three-part order (`revision` DESC, `baseline` ASC,
  `action` DESC) is an obligation on the adapter, not on the caller. On a
  document-store adapter it **requires a declared composite index**; the
  deployment plan carries that index definition, and the conformance suite asserts
  the order, **so a missing index fails a test rather than silently reordering the
  list**.
- The retention selection's ordering is `revision` descending **alone**, and it is
  **not tiebreak-stable**. Which entry survives at the boundary is unspecified.
  An adapter must not add a tie-break to make its own results deterministic — see
  `rules.md` BR4.19.

---

## The large-payload obligation

This port must accept a content document of up to **1,500,000 decoded characters**
(the consumer's cap), which in UTF-8 can exceed 4 MB, and a revision entry stores
the **full** content. The locally verified relational adapter has no relevant
limit and is unaffected.

A document-store adapter whose per-document ceiling is smaller **cannot store such
a save in one document**. The recorded resolution: store any serialised payload
over a safe threshold as a **content-addressed object** in the blob service and
keep only the key in the document. **Ordering is load-bearing** — the blob is
written **first, before the transaction**. Because the key is a hash of the
content, the write is idempotent, so a transaction that then fails leaves an
**orphaned blob, which is reclaimable garbage**, rather than a **dangling
reference, which is corruption**. The reverse ordering is forbidden.

**The cost, stated plainly rather than hidden:** on that path the guarantee
weakens from "everything commits in one transaction" to "the transaction is
atomic, and the blob write precedes it and is idempotent". **That weakening does
not exist on the locally verified path.** The threshold itself and the
orphan-sweep decision are still open — see § *Assumptions & Open Questions*.

---

## The in-memory fake holds the same shapes

Each port ships an in-memory fake alongside its real adapter, and the fake is not
a convenience: it is **the second implementation that proves the conformance suite
tests the port rather than the storage engine**. Its records carry the same
fields, the same nullability, the same identity columns and the same ordering
guarantees as the tables above. The only permitted difference is durability across
a process boundary.

---

## Assumptions & Open Questions

- **[assumption]** Field names in the tables above are given in their
  **storage-level** spelling. The externally visible wire spelling of the same
  values is the frozen `camelCase` form, and conversion happens in exactly one
  place in the consumer — never in an adapter. An adapter that renames on the way
  in or out has created a second conversion point that can drift.
- **[assumption]** `Asset.width` / `Asset.height` are persisted here although the
  original system stored no dimensions at all — it used the parse result for
  validation and for the upload response and then discarded it. Persisting them is
  a small addition that server-side variant generation makes useful. **If a
  reviewer prefers strict parity, dropping both fields changes no rule in this
  unit's `rules.md`.**
- **[assumption]** `last_mutation` is recorded as nullable because the bootstrap
  step writes the record without one. Every subsequent accepted write stamps it.
  No rule reads it as null; the guards compare it for equality against a freshly
  generated token, which a null can never satisfy.
- **[open, carried from `contract-design`, owner U11]** The document-store
  adapter's large-payload path needs **a size threshold** and **an orphan-sweep
  decision**. Neither is fixed. Carried as open rather than defaulted, because a
  threshold guessed here would be indistinguishable from one that was measured.
- **[open, carried from `contract-design`, owner U11 / U12]** Where the
  document-store composite index definition lives, so that it is not lost between
  the adapter and the deployment plan.
- **[carried hedge]** The cloud adapters are, by confirmed decision, **implemented
  and contract-tested but shipped unverified against the real services**. Every
  obligation in this document that applies only to them is therefore stated as an
  obligation, not as an observation.
- **[note]** The field-level validation of every value above — maximum lengths,
  patterns, enumerated sets, numeric bounds — is deliberately **not** repeated
  here. It belongs to the owning unit, and a second copy inside the store would be
  a second definition that can drift from the authoritative one.

## Sources

- `construction/functional-design/entities.md` — ENT-1 to ENT-6, their fields,
  nullability, defaults and the persistence note on each.
- `inception/contract-design/contract-summary.md` §§ C2 (`ContentStore`, including
  `prune_shape`, `atomicity`, `payload_size` and `conformance`), C3
  (`IdentityStore` and its separation rationale), C4 (`AssetStore` and its
  separation rationale), *Contract ownership rules*, *Open questions*.
- `inception/units-generation/unit-of-work.md` § U2 — what this unit owns,
  delivers and is bounded by.
- `WORKING-RECORD.md` § 2 (D4 — three ports, the verified and unverified
  adapters), § 5 (wire format frozen; a layer exists only when it has a job).
- `construction/storage-ports/functional-design/rules.md` — the port contracts
  expressed as rules, companion to this document.
