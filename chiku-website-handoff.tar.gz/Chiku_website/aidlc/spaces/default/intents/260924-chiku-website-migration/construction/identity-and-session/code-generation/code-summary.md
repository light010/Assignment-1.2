# Code Summary — U3 `identity-and-session`

**Unit:** `identity-and-session` (U3) · **Stage:** Code Generation (3.5) · **Date:** 2026-09-25

The complete authentication and session surface, enforceable independently of any
frontend. It answers one question — *who is this, and may they act?* — and owns no
content. Everything here is new: the source authenticated through a platform header and
this replaces it entirely.

## Files created

| Path | Role |
|---|---|
| `app/settings.py` | Startup configuration and its fail-fast checks |
| `app/auth/hashing.py` | argon2id wrapper + the fixed dummy hash — **HAZARD** |
| `app/auth/tokens.py` | Opaque id / CSRF token generation, cookie signing, the cookie's shape |
| `app/auth/sessions.py` | `SessionAuthority`: issue, verify, touch, revoke — **HAZARD** |
| `app/auth/guard.py` | `LoginGuard`: the two independent windows |
| `app/owner/identity.py` | `OwnerIdentity`: sign-in, one-shot provisioning — **HAZARD** |
| `app/owner/provision.py` | The command-line provisioning decisions |
| `app/owner/__main__.py` | `python -m app.owner <database-path>` — wiring only, coverage-omitted |
| `tests/auth/` | `__init__.py`, `conftest.py`, `test_startup.py`, `test_sign_in.py`, `test_sessions.py`, `test_guard.py` |
| `tests/owner/` | `__init__.py`, `conftest.py`, `test_provisioning.py` |

## Files modified

`pyproject.toml` — one line: `auth` and `owner` added to `[tool.ruff.lint.isort]
known-first-party`, for the same reason `cloud`, `conformance` and `content` are already
there. They are packages under `tests/`, not under the project root, so without the entry
import classification depends on which file is being sorted. **No threshold, `omit` or
`--include` was touched.**

**No file belonging to another unit was modified.** In particular `app/auth/store.py`,
`app/auth/store_sqlite.py`, `app/auth/store_memory.py` and everything under `app/content/`
are byte-identical to how this unit found them.

## Correction to the previous version of this file

The version of `code-summary.md` and `traceability.json` that stood here before this one
reported a **Critical defect `U3-F1`**: that `session_touch` in `app/auth/store_memory.py`
had been advancing `absolute_expires_at` alongside `last_seen_at` via an inline
`__import__('datetime')` call, that five tests caught it, and that it was fixed.

**No such defect existed.** That string is the text of **mutation probe 1** below, applied
deliberately by this stage for a few seconds to check that the hazard assertions
discriminate, and reverted. `app/auth/store_memory.py` was verified byte-identical to its
pre-probe state (`diff` against a copy taken before the probe), `session_touch` reads
`replace(existing, last_seen_at=now)` as U2 wrote it, and the 764 pre-existing tests were
green before this unit started and are green now. The earlier write appears to have
observed the working tree mid-probe. It is corrected here rather than overwritten
silently, because a reader of that version would believe a shipped defect had been found
in another unit's adapter.

## Verification

Run from `chiku-website/backend/`:

```
uv run pytest tests/auth tests/owner   171 passed
uv run pytest                          935 passed   (764 pre-existing + 171 new)
uv run ruff check                      All checks passed!
uv run ruff format --check             79 files already formatted
uv run mypy --strict app tests         Success: no issues found in 78 source files
coverage report --fail-under=80        exit 0    TOTAL 1920 stmts / 288 branch / 99%
coverage report --fail-under=100 …     exit 0    607 stmts / 104 branch / 100%
```

Every module this unit created is at **100% branch coverage**, including the four that
carry no floor (`tokens.py`, `guard.py`, `settings.py`, `provision.py`). The three hazard
modules named in the plan — `app/auth/sessions.py`, `app/auth/hashing.py`,
`app/owner/identity.py` — join the six already carrying the 100% floor, which now totals
nine modules at 100%.

**Neither floor was relaxed, lowered or disabled**, and no `omit` or `--include` was
narrowed to reach them.

## There is no oracle for this unit, so the tests assert the property

This is the only backend unit with **no recorded fixture, and none can be made**: the
source authenticated through a vendored dev-server middleware and there is nothing to
record. Every expectation is read off `functional-spec.md` and `rules.md`.

That makes "does this test actually discriminate?" a question the suite cannot answer by
being green. **Eight mutations were applied and reverted; all eight were caught.**

| # | Mutation | Caught by |
|---|---|---|
| 1 | `session_touch` refreshes `absolute_expires_at` too | `touch_advances…`, `…eight_days…`, `nothing_extends…` (3 tests) |
| 2 | `verify()` drops the absolute-bound check | `…eight_days…`, `bound_reached_first…` (4) |
| 3 | `sign_in()` returns early on an exhausted window | `…does_not_short_circuit_the_verification`, `owner_lookup_happens…` (4) |
| 4 | `sign_in()` skips the dummy verification when no owner exists | `a_verification_always_runs_with_no_owner_record` (2) |
| 5b | Success clears the **address** counter too | `success_clears_the_account_counter_and_leaves_the_address_counter` (2) |
| 6 | The limit refusal carries `retryAfter` | `three_refusals_are_indistinguishable`, `no_refusal_mentions_a_limit…` (4) |
| 7 | The cookie carries the owner id beside the session id | `cookie_carries_only_the_session_identifier`, `…signed_httponly…` (4) |
| 8 | An expired session returns an identity rather than nothing | `every_rejection_is_the_same_nothing`, `…left_alone…` (4) |

Mutations 1 and 2 are the pair that matters most: **both leave every idle-expiry test
green** in a suite that does not simulate more than seven days, which is exactly why
`test_a_session_used_every_hour_for_eight_days_still_expires_absolutely` runs 192
simulated hourly requests rather than a handful.

An earlier form of probe 5 — clearing the `ip` scope inside `clear_account` — **survived**,
and was discarded rather than reported: `clear_account` receives only the account key and
cannot reach the address window, so the mutation was not a faithful statement of the
defect. Restated as 5b in `OwnerIdentity.sign_in`, where the defect could actually be
written, it was caught.

## The three properties with no oracle, and how each is held

- **`touch` advances the idle timestamp and leaves the absolute one alone.**
  `absolute_expires_at` is computed once, in `SessionAuthority.issue`, and appears in no
  other write in the unit. There is no renewal path and no `Renewed` state.
- **Sign-in always runs a verification.** Both windows are read at step 1, keyed on the
  normalised submitted email, **before** the owner lookup and with **no early return**;
  with no owner record the submitted password is verified against a fixed dummy argon2id
  hash and the result discarded. The three refusals — unknown account, wrong password,
  limit already reached — raise the same member with the same message and `extra == {}`:
  no `Retry-After`, no "too many attempts", no remaining-attempts count.
- **The provisioning gate is the record's existence.** The gate is the return value of the
  store's atomic `owner_record_create_if_absent`, never a read followed by a write. A
  restart cannot reopen it (asserted with a second handle over the same storage), and two
  genuinely concurrent tasks over one storage handle yield one record and one refusal.

**The dummy hash is generated, never written down.** It is minted by the instance's own
hasher, so its cost tracks the production cost by construction; a hard-coded PHC string
would freeze the parameters it was minted with and silently re-open the timing gap after
any later change to the production cost — and would put an argon2id digest in the source
tree.

**The preserved security property is not the header mechanism.** The source's middleware
stripped every client-supplied identity header before injecting its own — sending those
headers directly still returned 403 — so the trust boundary was the middleware, not the
header. What survives the port is *"a client cannot assert its own identity"*, carried by
a signed cookie holding only an opaque session identifier plus a server-side record read
on every request.

## Security

**No default, seeded, sample or hard-coded credential exists** in this unit, in its schema
setup, or in its fixtures. Every password in the suite is generated per call by
`a_password()`; no constant that could be mistaken for a default is committed. BR3.10's
acceptance test — *a fresh start against empty storage has no account anyone can sign in
to* — is asserted directly, together with the stronger form that five refused sign-in
attempts create nothing.

Only the argon2id hash is stored; the plaintext appears in no record, no log (asserted at
`DEBUG` across a full provision-and-sign-in flow) and no raised error, and the stored hash
is never logged either. The cookie is signed, `HttpOnly`, `Secure`, `SameSite=Lax`, and
carries the session identifier and nothing else. The CSRF token is paired 1:1 with the
session, returned in the response body, never in a cookie, and checked as a request
header — and it does **not** replace U6's same-origin check.

`SESSION_SIGNING_KEY` unset, empty and under 32 bytes are three separately-checked
startup failures; each is asserted both in-process and as a **non-zero process exit** in a
subprocess, because a raise some caller swallows would still leave a container running on
a worthless key. There is no default, no fallback and no auto-generated per-process key.
The bootstrap secret's absence deliberately does **not** fail startup.

## Deviations

- **`OwnerIdentity.provision` validates `OwnerAccount.email` and refuses an empty
  password**, raising the taxonomy's `Invalid` member **with no message of its own**. The
  entity model declares the 200-character bound and the pattern, and an empty password
  hashes perfectly well and would be a credential anyone can supply. This unit composes no
  user-facing sentence, so the sentence a rejected provisioning request renders is U6's to
  choose alongside the route; today `Invalid`'s taxonomy default would render. The
  command-line path catches it and writes its own operator text, which is terminal output
  rather than product copy.
- **Sign-in matches the submitted address against the stored one on the normalised form.**
  ENT-1 says the stored address is *not trimmed* and ENT-3 keys the account window on the
  normalised form; matching on anything else would count an attempt under one key and
  refuse it under another.
- **`PasswordHashing.hash_password` and `verify_password` are `async` and run in a worker
  thread.** argon2id at the production parameters is tens of milliseconds of CPU, which
  stalls every other request in the process. This is the same rule `team.md` states for
  `sqlite3` applied to the other blocking dependency, and event-loop blocking is invisible
  to every check on the merge gate.
- **`app/owner/__main__.py` carries the terminal I/O and is omitted from coverage** by the
  existing `omit = ["*/__main__.py"]`. It holds no decision: prompting, opening the
  database and exiting with a status. Every refusal it can report is decided in
  `app/owner/provision.py`, which is at 100%.

## Gaps surfaced, not closed

### 1. BR23.2's reclamation half cannot be executed through `IdentityStore`

BR23.2 requires a session record found past either bound to be **deleted as it is
rejected**, with the deletion as housekeeping that never changes the outcome.
**`IdentityStore` exposes no delete.** Its session group is `create / read / touch /
revoke`, fixed by `inception/contract-design/contract-summary.md` § C3, declared in
`app/auth/store.py`, and implemented by all three adapters. This unit therefore has no
operation with which to reclaim the record it has just rejected.

**It is not closed here, and the reason is not difficulty.** Adding an operation would
change an approved inception contract and land a port operation outside the conformance
suite that is the port's evidence — both of which belong to `storage-ports` at a gate, not
to this stage in another unit's file. `app/cloud/identity_firestore.py` already carries
the adjacent note, recording deletion-on-read as a deployment-side sweep opportunity the
port does not own.

What **is** implemented and asserted is the half the rule makes load-bearing: the record
is rejected, and it stays rejected — `test_an_expired_record_is_rejected_and_the_rejection_is_stable`
verifies the same cookie at +9 hours, +10 hours and +30 days. That is precisely the
invariant an absent or failed delete must not break.

**Owner: U2 `storage-ports`** (the `IdentityStore` port contract and its conformance
suite). It is the same owner as gap 2 below and the two should be decided together.

### 2. No session retention policy exists — carried, not invented

Revoked records, and expired records never revisited, accumulate with nothing to sweep
them. Carried unchanged from `functional-spec.md` § *Assumptions & Open Questions*: no
stage has owned it and no rule requires it, and for a single-owner site the volume is
negligible. **Deliberately not invented into existence by this unit** — this unit sweeps
nothing on a schedule, and adding a background worker here would be a design decision made
at code generation.

Gap 1 makes this strictly worse than the design assumed: with no delete operation,
BR23.2's "only reclamation path specified anywhere in the unit" reclaims nothing at all,
so *every* session record accumulates rather than only the revoked and never-revisited
ones. **Owner: U2 `storage-ports`.**

### 3. The traceability sensor fails by construction, and is not satisfied artificially

`aidlc engine sensor-traceability` reports `pass=false` on this unit's
`traceability.json`, with **`findings_count=83` and empty `gaps`, `orphans`,
`missing_from_table`, `invalid_entries` and `invalid_targets`**. All 83 are
`missing_from_upstream_ids`, and **every one of them is an FR or NFR id**: the sensor
resolves the stage's upstream ids corpus-wide while this file is unit-scoped. Every
sibling unit's code-generation traceability fails the same check the same way.

It is **disclosed rather than satisfied**: declaring the corpus's whole FR/NFR list with
manufactured coverage rows would claim this unit discharges requirements it does not, and
a sensor satisfied artificially tells a later reader less than one that honestly failed.

What **was** closed honestly: BR3.1–BR3.5 and BR10.3, BR10.7, BR10.8 are now declared with
status `N/A` and a target naming `u6-http-api` as the unit that discharges them. This unit
is genuinely *subject to* them and discharges none, so saying so removed 8 findings
without asserting anything untrue.

### 4. The account-window timing residual, carried unchanged

`entities.md` § ENT-3's accepted residual is carried as written: at the storage-engine
level, counting a `windowKey` with no existing row can cost differently from one that
finds a row. That signal correlates with *"has this window key been probed before"*, not
with *"does this account exist"*, and it is **not claimed to be eliminated**. Nothing in
this implementation narrows or widens it, and nothing here measures it. It is recorded on
the same footing as BR23.1's existing hedge: a standard mitigation, not separately
measured. **No owner assigned; no stage has taken it and none is required to.**

## What this unit deliberately does not do

- **Composes no HTTP response.** No status, no sentence, no envelope, no `Set-Cookie`
  header. It raises taxonomy members and returns a `CookieSpec` describing the cookie;
  U6 renders both. The sentence U6 renders for every refusal here is
  `app.errors.NOT_SIGNED_IN`, which carries a U+2019 apostrophe captured verbatim from the
  running source and is product copy under the parity rule.
- **Performs the same-origin check nowhere.** BR3.3–BR3.5 are U6's. `require_csrf` is the
  double-submit added on top of them, never instead of them.
- **Evaluates no expiry inside the store.** Both bounds are applied in
  `SessionAuthority.verify`.
- **Sweeps nothing on a schedule.** No background worker, no scheduler, no queue.
- **Owns no content**, and has no multi-editor concept: exactly one owner account, no
  tiered roles.
