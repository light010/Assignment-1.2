# Code Generation Plan — U11 `cloud-adapters`

## Unit scope

Three adapters implementing the three ports against Google Cloud — Firestore for
`ContentStore` and `IdentityStore`, Cloud Storage for `AssetStore` — run over the **same
conformance suites** as the local adapters.

**Shipped code-complete and unverified against the real services, by explicit design
choice** (`functional-spec.md` § *What "unverified" means precisely*). Verifying them
would require provisioning cloud resources, and this workflow provisions nothing:
`project.md` forbids creating a project, a service, a bucket or a credential, and the
zero-recurring-cost target is a hard one.

This unit therefore **provisions nothing, issues no credential, and makes no network
call**. Nothing it produces can incur a charge.

## The decision that shapes everything below: no cloud SDK dependency

The adapters are written against **structural `Protocol`s describing the client surface
they use** — `FirestoreLike`, `TransactionLike`, `BucketLike` — not against
`google-cloud-firestore` and `google-cloud-storage` imports.

This is not indirection for its own sake. It buys four things at once, and the
alternative loses all four:

1. **No dependency is added**, so the backend image does not grow. Measured image size
   feeds the zero-cost target directly (`project.md`: Artifact Registry storage under
   0.5 GB, compressed and layer-deduplicated).
2. **`mypy --strict` stays clean** with no blanket `ignore_missing_imports`. Adding an
   unstubbed SDK would force exactly the suppression `team.md` forbids.
3. **The conformance suite can run**, against an in-process fake client. Without this
   the adapters would ship with no executable evidence at all.
4. **The real SDK client satisfies the Protocol structurally at runtime**, so wiring one
   up later is a constructor argument and not a rewrite.

The trade-off is stated rather than hidden: a Protocol can only describe the surface as
this design understands it from published documentation. If the real SDK differs, the
adapters fail at first contact with the service. **That is the same exposure the unit
already carries as "unverified" and this decision does not widen it** — but it does mean
the Protocols are a claim about an API, and they are marked as such in the code.

## The fake client is where the real evidence is

The fake Firestore client is not a convenience. It **enforces the two constraints that
make the algorithm correct**, and it is the only thing in this workflow that can:

- **A read issued after a write inside a transaction raises.** This is Firestore's actual
  rule (BR31.3) and it is what the R-05 Critical review finding was about — the earlier
  algorithm read survivors *after* two writes, and by this design's own pruning invariant
  that fires on **every** save once the cap is reached. A fake that permits read-after-write
  makes the corrected ordering untestable and the regression invisible.
- **A document larger than 1,048,576 bytes raises.** This is what forces the blob
  substitution, and it is what the R-01 Critical finding was about — the revision entry,
  not the content document, is the shape that cannot fit.

A test that passes against a permissive fake proves nothing about either finding. Both
limits are therefore asserted directly: a test that removes the read/write split must
fail, and a test that removes substitution on `ContentRevision.content` must fail.

## Module layout

```
app/cloud/__init__.py
app/cloud/clients.py          FirestoreLike / TransactionLike / BucketLike Protocols
app/cloud/blobs.py            content-addressed substitution: threshold, ordering, reversal
app/cloud/content_firestore.py   ContentStore on Firestore   [HAZARD — the combined write]
app/cloud/identity_firestore.py  IdentityStore on Firestore
app/cloud/assets_gcs.py          AssetStore on Cloud Storage
app/cloud/INDEXES.md             the one declared composite index (BR31.4)
tests/cloud/fake_firestore.py    the limit-enforcing fake
tests/cloud/fake_gcs.py
tests/cloud/conftest.py          registers the cloud adapters into the conformance suite
```

`app/cloud/` is named for the thing it owns, not for a layer: these are the Google Cloud
implementations and nothing else lives there.

## Ordering — the contract's `custom` methodology

`team.md` § *Testing Posture*: the characterization tests for a unit's hazard-register
behaviours **and for the storage port** are written and observed to fail before the
implementation exists. The combined write on Firestore is a hazard-register module, and
every operation here is a storage port. **Step 4 writes the tests and observes them fail;
Step 5 implements.** They are not to be merged or converted into layer-local TDD.

## Steps

- [x] **Step 1 — Verify the test runner and record the exact unit-scoped command.**
      `pytest` 9.1.1 under `chiku-website/backend/`, resolved by `uv`. Confirm
      `uv run pytest --version` succeeds and record the unit-scoped command in
      `unit-test-instructions.md`. Runner readiness precedes every test step.

- [x] **Step 2 — The client Protocols.** `FirestoreLike`, `TransactionLike`, `BucketLike`,
      describing only the surface these adapters use. Each carries a comment naming the
      published API it models and stating that it is unverified against the real SDK.

- [x] **Step 3 — The limit-enforcing fakes.** `fake_firestore.py` raises on a read issued
      after a write within a transaction, and on a document exceeding 1,048,576 bytes.
      `fake_gcs.py` stores objects and supports ranged reads. These are test doubles that
      **enforce the service's documented constraints**, which is what makes the suite able
      to catch R-01 and R-05.

- [x] **Step 4 — Tests, written and observed to FAIL.** Register the three cloud adapters
      into the existing `tests/conformance` parameterisation so the whole contract runs
      against them unchanged, plus `tests/cloud/` tests for what is specific to this unit:
      the per-field substitution rule and its deterministic largest-first ordering with
      `draft` before `published` on a tie; transparent reversal on read; blob writes
      landing **before** the transaction opens; the unfiltered single `revision DESC`
      survivor read; and the read/write split itself. Run; paste the failing output.

- [x] **Step 5 — The three adapters, to Green.** The combined write follows the spec's
      nine steps exactly: **read-content, read-survivors, write-content, write-revision,
      delete-pruned, commit**, with the blob writes complete *before* the transaction
      opens (BR31.2 — orphan garbage is preferable to a dangling reference). Survivors are
      partitioned by action **in memory**, never by a filtered query, because a filtered
      query needs a second composite index that nothing declares and an undeclared index
      fails at runtime (BR31.4).

- [x] **Step 6 — The declared index, the unverified marking, and traceability.**
      `app/cloud/INDEXES.md` names the one composite index —
      `[revision DESC, baseline ASC, action DESC]` — as a deployment deliverable.
      **BR31.5 requires the unverified status to be impossible to miss**: it goes in every
      adapter module's docstring, in `INDEXES.md`, and in `code-summary.md`. Then
      `code-summary.md`, `source-manifest.json`, `traceability.json`.

## Test files this plan produces

- `tests/cloud/fake_firestore.py`, `tests/cloud/fake_gcs.py` — the limit-enforcing doubles.
- `tests/cloud/conftest.py` — registers the cloud adapters into the shared conformance
  parameterisation. The existing `tests/conformance/` suites then run against them
  unchanged, which is the point: **the same suite, a third and fourth implementation.**
- `tests/cloud/test_blob_substitution.py` — per-field threshold, largest-first ordering,
  the `draft`-before-`published` tie-break, transparent reversal, and the
  `ContentRevision.content` case that R-01 was about.
- `tests/cloud/test_transaction_ordering.py` — every read precedes every write; the blob
  writes land before the transaction opens; the survivor read is one unfiltered
  `revision DESC` read. This is the R-05 regression test.

No new test framework and no new dependency.

## Coverage

`app/cloud/content_firestore.py` is a hazard-register module (the combined write) and
carries the **100% branch** floor alongside the two existing hazard modules. The 80%
branch floor over `chiku-website/backend/` continues to apply. Neither is relaxed; a
shortfall is surfaced, not configured away.

## What this unit deliberately does not do

- **No provisioning.** No project, no service, no bucket, no credential, no billing
  change. Nothing here can incur a charge.
- **No network call**, in code or in tests.
- **No dependency added**, for the four reasons above.
- **No claim of verification.** BR31.5: the unverified status is stated in every adapter
  docstring and in the summary. An adapter that reads as production-ready would be the
  defect this rule exists to prevent.
- **No second composite index** (BR31.4), and no region choice made here — BR31.6's
  single-region constraint is a deployment decision recorded in `INDEXES.md`, not a
  literal in code.

## Traceability — plan step to rule

| Step | Realises |
|---|---|
| 2 | BR31.1 |
| 3 | BR31.3 |
| 4 | BR31.1, BR31.3 |
| 5 | BR31.2, BR31.3 |
| 6 | BR31.4, BR31.5, BR31.6 |

All six `BR31.x` ids carry `source: NFR3` / `NFR6` and are reported accordingly; this unit
discharges no FR.

## Carried finding this plan answers

`UNITS.md` records that `cloud-adapters` ended functional-design **terminal NOT-READY** on
a real Firestore transaction-ordering finding — all reads must precede any write in a
transaction — and that the finding must be answered before any Firestore adapter is
written. **It is answered in the design itself** (R-05, quoted in `functional-spec.md`
§ *The combined write, on Firestore*), which resequenced the algorithm to
read-content, read-survivors, write-content, write-revision, delete-pruned, commit. This
plan implements that corrected order and, in Step 3, builds the fake that **fails the
build if it is ever undone**. That is the difference between answering a finding and
noting it.
## Testing Contract

```json
{
  "version": 1,
  "methodology": "custom",
  "source": "team",
  "ordering": "Within each unit, the characterization tests for that unit's hazard-register",
  "scope": "runtime-split-migration",
  "test_strategy": "standard",
  "project_type": "brownfield",
  "applicable_notes": [
    {
      "layer": "org",
      "text": "We treat tests as a first-class deliverable in every Bolt. The specific\nmethodology (TDD, BDD, ATDD, or classic test-after) is affirmed at\npractices-discovery and recorded in `team.md` under this heading with explicit\n`Methodology` and `Ordering` fields; Code Generation resolves those fields\nindependently from coverage, tooling, and scope notes.\n\nWhen no posture has been affirmed, our default per scope is:\n- **Methodology**: test-after\n- **Ordering**: implement each applicable testable layer, then write and run\n  that layer's tests.\n- `mvp`, `enterprise`, `feature`, `infra`, `classic` add an 80% line-coverage\n  floor and CI execution before merge.\n- `bugfix`, `security-patch` add a targeted regression for the specific\n  bug/vulnerability and require the existing suite to remain green.\n- `express` uses the Minimal strategy: requirement-driven unit tests (one per\n  requirement, with a happy-path floor per component); existing tests remain\n  green.\n- `poc`, `refactor`, `workshop` add no extra new-test floor and require the\n  existing suite to remain green.\n\nThe active `Test Strategy` still applies in every scope and determines test\nvolume/types. Scope floors are additive; they never reduce or replace the\nselected strategy.\n\nBuild and Test verifies defined coverage floors and affirmed quality targets;\nthey may not be weakened to make a step pass.\n\nAffirm a stricter posture in `team.md` if the team commits to one."
    },
    {
      "layer": "team",
      "text": "> **Read this section as a proposal we have adopted, not as practice we observed.** The source\n> project contains zero test files, zero testing dependencies and no `test` script, so there was no\n> prior testing practice to discover — every item below was chosen at the practices-discovery gate\n> on 2026-09-24 and affirmed by the site owner, rather than read off how this team already works.\n\n- **Methodology**: custom\n- **Ordering**: Within each unit, the characterization tests for that unit's hazard-register\n  behaviours and for the storage port are written and observed to fail before the Python\n  implementation of that behaviour exists; every other backend test is written immediately after\n  the code it covers; that unit's frontend render layer is ported only once its backend tests\n  pass; a unit with no backend surface begins at the frontend step; and a unit whose behaviour is\n  not enumerated in the hazard register takes the recorded source fixtures as its oracle, falling\n  back to the reverse-engineering knowledge base where no fixture exists.\n- **What `custom` means, and why it is not `test-after`.** Under test-after, a developer who\n  misreads a dense source line implements from the misreading and then writes the test from the\n  same misreading: the test is green, coverage is satisfied, and the defect ships. That is not\n  hypothetical here — a port declaring `research_topic: Topic | None = None` passes `ruff`,\n  `mypy --strict`, `tsc`, the Compose end-to-end flow and 100% line coverage while rendering three\n  identical research cards and returning zero publications for every topic filter. Only a test\n  whose assertion came from the *source* behaviour catches it. `tdd` everywhere is equally wrong:\n  most of the ported render layer has no enumerated oracle, and writing failing render assertions\n  first for ported JSX is waste. Note this is **characterization** testing, not TDD — the test is\n  written from the recorded behaviour of the source, which is why the fixtures below matter.\n- **Recorded source-behaviour fixtures come first, before any Python is written.** Drive the\n  running `madhavi-tripathi/` app over HTTP with `httpx` once and record as golden fixtures: every\n  public route's rendered HTML, `GET /api/content`, the media route's status codes across public /\n  draft-only / missing keys, the 413 boundary in both characters and UTF-8 bytes, byte-range\n  responses across all six rejection branches, and the stored-row state after a save / publish /\n  conflict sequence. It uses a disposable local database and a test identity; nothing hosted is\n  touched. Until these exist, every parity assertion in this project rests on a human's reading of\n  a document; after they exist, they assert against the system. **This capability expires when the\n  source app is retired** — a fixture not recorded before then cannot be recovered.\n- **Coverage floor — backend**: **80% branch coverage** over `chiku-website/backend/`, measured by\n  `pytest --cov --cov-branch` and `coverage report --fail-under=80`, with generated migration\n  files and `__main__` entry points excluded. Branch, not line, is deliberate and costs one flag:\n  every high-risk behaviour in this port is a branch or a `??` fallback chain, and line coverage\n  marks those covered when only one side ever runs. This is a **new floor we are choosing**, not\n  an inherited one — `org.md`'s 80% floor is written for the named stock scopes (`mvp`,\n  `enterprise`, `feature`, `infra`, `classic`) and this workflow runs the custom scope\n  `runtime-split-migration`, which appears in none of them. Absent this affirmation there would be\n  no numeric floor at all. The active `Test Strategy` is **Standard** and continues to govern test\n  volume and type independently of this number.\n- **Coverage floor — hazard modules**: a second, scoped\n  `coverage report --fail-under=100 --include=<hazard module globs>`. The hazard modules are the\n  ports of the behaviours ranked in `code-quality-assessment.md` § *Hazard index* — the\n  seven-statement concurrency batch and its `last_mutation` ABA defence, the media access rule, the\n  `researchIdentity` back-compat shims, the request-size cap, the three hand-written image header\n  parsers, the WebVTT validator, the byte-range parser and the editor state machine. Each carries a\n  test per enumerated branch. An aggregate percentage cannot distinguish \"this branch is exercised\"\n  from \"this branch was ported correctly\"; these are precisely the branches whose silent loss ships\n  a defect, so they get both the per-branch tests and a floor that leaves no room.\n- **Coverage floor — frontend**: none. The Next.js frontend renders only and owns no application\n  decision, so a line-coverage number on it would measure JSX traversal rather than behaviour.\n- **The test families, and which are mandatory.** Mandatory: the recorded fixtures above; backend\n  unit tests for branch-level behaviour of ported logic; **storage-port contract tests written as\n  an adapter-parameterized conformance suite and run against both the real SQLite adapter and an\n  in-memory fake** (two implementations is the minimum that proves the suite tests the port\n  contract rather than SQLite, and it is the whole argument for having a port); API contract tests\n  in the non-circular form — assert the **generated** OpenAPI document against the **hand-written**\n  contract from `contract-design`, and commit the generated `openapi.json` as a snapshot so an\n  unintended contract change surfaces as a gate diff rather than as a frontend 422 three Bolts\n  later; and the Compose end-to-end flow. Frontend render checks are mandatory but add **no\n  frontend test framework**: assert against the HTML the composed stack returns, using the recorded\n  fixtures, and make the assertions named rather than \"landmarks present\" — each of the three\n  research cards has a distinct topic class and icon, the publications topic filter returns\n  non-zero for each seeded theme, each research card shows non-zero related papers. Browser checks\n  (Playwright) are optional today with one condition that flips them: **if the six-flag editor\n  state machine lands in the frontend rather than the backend, a browser check becomes the only\n  possible verification of it and becomes mandatory.** Flag that as a dependency on `domain-design`.\n- **Compose end-to-end runs on every Bolt merge**, not only at the skeleton gate and at the end.\n  With no CI, the per-merge run *is* the CI, and the alternative is a container-level regression\n  surfacing many Bolts after the one that caused it, with no bisect signal and nobody watching a\n  dashboard. Keep the cost bounded by keeping the flow small and fixed — the skeleton's two paths\n  plus one auth-failure path — so it stays inside a few minutes on cached layers.\n- **Parity is verified two ways, and pixel comparison is rejected.** (1) A **normalised\n  DOM-structure diff** against the recorded source HTML: strip volatile attributes, build hashes\n  and whitespace, then diff the element tree plus text content per route. It catches what actually\n  breaks in a port — a dropped section, a wrong class, a missing copy default among the 25 leaf\n  defaults — at a fraction of the setup cost of pixel screenshots and without their flakiness.\n  (2) An explicit **page-by-page human review at the end**, recorded as a checklist. Per-route\n  screenshot comparison was considered and **rejected**: it is brittle against fonts, antialiasing\n  and animation, and it is not a live option to be reopened later. Until the DOM diff exists, the\n  parity rule is an unfalsifiable claim, which is what this closes.\n- **Boundary enforcement is a command, not an assertion.** A rule nobody can check is a wish. Three\n  checks, all on the gate: the frontend's TypeScript types for backend payloads are **generated**\n  from the backend's `/openapi.json` with `openapi-typescript`, committed, regenerated at the gate,\n  and the gate fails if the output is dirty — which makes the boundary type-checked rather than\n  asserted, since a backend field rename then fails `tsc --noEmit` with a file and a line; a\n  three-line grep fails the gate if `chiku-website/frontend` contains any `'use server'` directive,\n  any `app/**/route.ts`, or any `middleware.ts` (an ESLint `no-restricted-syntax` rule is a nicer\n  editor experience, but the grep is the one that is certain); and one pytest walks the AST of\n  `routers/` modules and asserts none of them imports a `store` module or `sqlite3`.\n- **The source has no suite to keep green.** The org rules for several scopes say \"the existing\n  suite remains green\". There is none — the scan found zero test files, zero testing dependencies\n  and no `test` script anywhere in `madhavi-tripathi/`. Every test in this project is a new test.\n  The only inherited automated checks are `tsc --noEmit` (strict) and `pnpm lint`.\n- **Tooling**: backend — pytest 9.1.1 with `httpx` 0.28.1 for FastAPI transport-level tests,\n  `ruff` 0.16.8 and `mypy` 2.3.1 as gating checks, dependencies resolved by `uv` 0.10.0. Frontend\n  — `tsc --noEmit` and ESLint 9 with `eslint-config-next`, unchanged from the source project.\n- **The merge gate.** A Bolt may squash-merge to `main` only when every one of these passes on the\n  developer machine, in this order, with the **verbatim output pasted into the gate approval**:\n\n  ```\n  ruff check\n  ruff format --check\n  mypy --strict\n  pytest --cov --cov-branch\n  coverage report --fail-under=80\n  coverage report --fail-under=100 --include=<hazard module globs>\n  tsc --noEmit\n  pnpm lint\n  git diff --no-index madhavi-tripathi/app/<f> chiku-website/frontend/app/<f>   # per unmodified ported file\n  <boundary grep: 'use server' / app/**/route.ts / middleware.ts>\n  <openapi-typescript regeneration — gate fails if the committed output is dirty>\n  uv export --frozen --no-dev --no-emit-project -o .audit/requirements.txt && uvx pip-audit -r .audit/requirements.txt\n  pnpm audit --prod --audit-level high\n  docker compose up  +  the end-to-end flow\n  ```\n\n  **Dependency advisories block at High and above.** An advisory with no fix available does not\n  silently pass and does not silently block: it is recorded with the **package, the advisory id,\n  the reason it cannot be fixed, and the named Bolt that owns it**, and the gate then proceeds on\n  that record. This is consistent with the correction already in `project.md` that any finding\n  carried past a gate needs a named owner.\n\n  Gates protect the parity guarantee; weakening one to make a Bolt pass is an incident, not a\n  shortcut."
    }
  ],
  "obligations": {
    "strategy": "standard",
    "strategy_volume": [
      "Five to eight tests per component.",
      "Unit tests plus integration tests for key boundaries.",
      "Add E2E, performance, or security tests when requirements demand them."
    ],
    "scope_floor": [
      "Keep the existing test suite green.",
      "This scope adds no extra new-test floor beyond the selected test strategy."
    ],
    "combination_rule": "Apply every selected-strategy obligation and every scope-floor obligation; neither replaces the other, and a targeted scope regression may add the narrowest necessary test type beyond the strategy default."
  },
  "plan_profile": {
    "methodology": "custom",
    "runner_step": "Verify the existing test runner/configuration and record the exact unit-scoped command.",
    "runner_ready_before_first_test": true,
    "testable_layers": [
      "Data model / database behavior",
      "Repository / data access",
      "Business logic",
      "API / endpoint",
      "Frontend behavior"
    ],
    "steps": [
      "Project structure and production configuration skeleton.",
      "Verify the existing test runner/configuration and record the exact unit-scoped command.",
      "Custom ordering - Within each unit, the characterization tests for that unit's hazard-register",
      "Implementation and tests - preserve that exact ordering; do not convert it to layer-local TDD.",
      "Environment/build configuration.",
      "Documentation and traceability."
    ]
  },
  "input_sha256": "sha256:ae7fe698329b9815a1e703cfb6f92beeb23e35c6e2f83768ad7ab02dffb4a262",
  "contract_sha256": "sha256:6b84da29d5313b29b3058ef863280c58a9f6f401f244363de9431d8063261179"
}
```
