# Rules — U12 `deployment-plan`

**Upstream:** `inception/requirements-analysis/requirements.md` (NFR6, C4, S4),
`inception/units-generation/unit-of-work.md`,
`aidlc/spaces/default/memory/phases/operation.md`,
`scratchpad/gcp-free-tier-verified.md` (all figures, fetched 2026-09-24).

These carry `BR32.x` ids. Group 32 is U12's unit-scoped group under the corpus
scheme: FR-derived groups are `BR3.x`–`BR10.x` and keep the numbers the
workflow-level `rules.md` gave them; a rule that realises only an NFR or a
constraint takes a unit-scoped group at **unit number + 20**, so groups 21–32 are
one per unit and groups 1, 2 and 11–20 stay unused.

Every rule here decides whether the plan is acceptable, so they are genuine
business rules — but they trace to **NFR6** and **C4** rather than to any `FR`.
The `reverse` array in `traceability.json` records that explicitly, which is the
framework's sanctioned way to say a rule intentionally has no acceptance
criterion rather than letting it be derived as an orphan.

The yaml below is in id order, BR32.1 through BR32.24.

```yaml
rules:
  - id: BR32.1
    statement: Every cost line cites a current official source with the date it was fetched.
    category: constraint
    applies_to: CostLine
    trigger: Writing or revising any row of the cost table.
    logic: >
      IF a cost line lacks source_url OR lacks source_date
      THEN the plan is incomplete and must not be presented as verifying NFR6.
    violation: The line is rejected. An undated figure is not evidence.
    source: NFR6, S4
    note: >
      Google reserves the right to change free-tier allowances with 30 days'
      notice, and Cloud Build's allowance is additionally labelled promotional.
      The date is what lets a later reader tell a stale figure from a current one.

  - id: BR32.2
    statement: Container image sizes are measured from real built images, never estimated.
    category: constraint
    applies_to: CostLine
    trigger: Filling the Artifact Registry cost line.
    logic: >
      IF the image-size figure has not been read off images U10 actually built
      THEN the line stays marked pending and the plan is not complete.
    violation: The plan cannot be approved with an estimated image size.
    source: NFR6
    note: >
      This rule exists because an earlier estimate in this workflow was wrong by
      roughly an order of magnitude — it used uncompressed sizes and ignored layer
      deduplication, while Artifact Registry bills compressed, content-addressed,
      deduplicated layer blobs. The corrected reasoning put the total inside the
      0.5 GB allowance rather than over it. It is already persisted in project.md.
      BR32.19 puts a SECOND figure under this rule: the per-render bytes that
      leave Cloud Run after BR32.6 has moved static output and media to Cloud
      Storage. That figure sets the site's entire capacity and is not measured
      either, so it is carried as pending rather than guessed.

  - id: BR32.3
    statement: Both runtime services and every storage service they use are deployed in the same region.
    category: constraint
    applies_to: ConfigurationSetting
    trigger: Choosing the deployment region.
    logic: >
      IF any two components are placed in different regions
      THEN service-to-service traffic becomes chargeable and the egress line stops being zero.
    violation: The zero-cost claim fails. Not a performance trade — a billing one.
    source: NFR6
    note: >
      Same-region traffic is free verbatim per the Cloud Run pricing page, and
      stays free even over the public run.app endpoint because it does not leave
      Google's network. Cross-region is not. This rule is also what keeps
      Firestore's 10 GiB monthly egress allowance entirely unconsumed: reads
      travel Firestore to Cloud Run inside one region, and same-region data
      transfer is free.

  - id: BR32.4
    statement: The Cloud Storage bucket is in us-west1, us-central1 or us-east1, and nowhere else.
    category: constraint
    applies_to: ConfigurationSetting
    trigger: Creating the bucket.
    logic: >
      IF the bucket is created in the US multi-region or any other location
      THEN it receives NO Cloud Storage free tier at all — not a reduced one.
    violation: Storage and its 100 GB egress allowance both become chargeable from the first byte.
    source: NFR6
    note: >
      The US multi-region is a common console default, which is what makes this a
      rule rather than a note. The three eligible regions share one aggregated
      allowance. Location is only half the condition — BR32.24 carries the other
      half, the storage class.

  - id: BR32.5
    statement: min-instances stays at 0 on every Cloud Run service.
    category: constraint
    applies_to: ConfigurationSetting
    trigger: Configuring a service, or later tuning cold-start latency.
    logic: >
      IF min-instances is raised above 0
      THEN one always-warm 1 vCPU instance consumes roughly 2.59M vCPU-seconds per
      month against a 180,000 vCPU-second monthly pool — about fourteen times the
      entire allowance — at roughly 9 to 10 US dollars a month.
    violation: The free tier is destroyed by a single setting. Cold starts are accepted instead.
    source: NFR6, C4

  - id: BR32.6
    statement: Static assets and uploaded media are served from Cloud Storage, never proxied through Cloud Run.
    category: policy
    applies_to: CostLine
    trigger: Designing the request topology.
    logic: >
      IF media or build output is served through the Cloud Run container
      THEN those bytes are charged against Cloud Run's 1 GiB monthly North America
      egress allowance instead of Cloud Storage's 100 GB — a hundredfold smaller pool.
    violation: A handful of video views exhausts the month's egress.
    source: NFR6
    note: >
      Cloud Run's internet egress allowance is the tightest number in the entire
      topology and, per BR32.19, the meter that sets the site's capacity. At the
      evidence file's 400 KB per render it is 2,684 renders a month. Moving bytes
      out of that pool is the single highest-leverage cost decision, and it is
      also the one that RAISES the capacity ceiling — by an amount nobody has
      measured yet.

  - id: BR32.7
    statement: The published content document is cached in the backend process rather than read from Firestore per render.
    category: policy
    applies_to: CostLine
    trigger: Sizing the Firestore read line.
    logic: >
      IF every public render performs a Firestore read
      THEN roughly 12,500 renders in ONE DAY exhausts the 50,000 daily read quota,
      which does not roll over and resets around midnight Pacific.
    violation: A single crawler day takes the site to paid reads or to quota errors.
    source: NFR6
    note: >
      The cache already exists for a different reason — ContentAuthority owns it,
      and its interval is a security parameter because the media route's public
      check reads through it. What this rule originally claimed — that the cache
      is what stands between one crawler and the daily quota — is withdrawn by
      BR32.20: the crawler day it describes is not reachable inside this free
      tier, because egress and vCPU-seconds both run out first. The cache's live
      job is narrower and still worth a rule: it makes the Firestore read count
      independent of the render count, which is the premise BR32.17 and BR32.21
      both compute against.

  - id: BR32.8
    statement: Exactly one Firestore database per project, and it is the default unnamed one.
    category: constraint
    applies_to: ConfigurationSetting
    trigger: Creating the database.
    logic: >
      IF a named (non-default) database is created
      THEN it requires billing and does not qualify for free quota at all.
    violation: Every read, write and delete is chargeable from the first operation.
    source: NFR6
    note: >
      Firestore allows exactly ONE free database per project, so creating it
      spends a slot the project has only once. That is why the runbook lists it
      among the steps with no clean reversal.

  - id: BR32.9
    statement: A budget alert is documented as an alert, never as a spending cap.
    category: policy
    applies_to: DeploymentStep
    trigger: Writing the cost-control section.
    logic: >
      IF the plan describes an ordinary budget as preventing spend
      THEN it misrepresents the control — ordinary budgets do not prevent the use
      or billing of services. Spend-cap budgets (Preview) do pause usage but cover
      Cloud Run ONLY; Firestore, Cloud Storage, Artifact Registry, Cloud Build,
      Logging and Secret Manager are all ineligible, enforcement is not instant,
      overages are billed as normal, and restoring service needs a manual lift.
    violation: The operator believes they have a hard stop that does not exist.
    source: NFR6, C4
    note: >
      The only true hard stop is budget to Pub/Sub to a function that disables
      billing, which Google warns may irretrievably delete resources and still does
      not guarantee staying under budget. It is documented with that warning intact,
      and recommending it is a judgement the operator makes, not this plan.

  - id: BR32.10
    statement: Every deployment step carries its own rollback.
    category: constraint
    applies_to: DeploymentStep
    trigger: Writing the runbook.
    logic: >
      IF a step has no stated reversal
      THEN the runbook does not meet the operation-phase guardrail and the plan is incomplete.
    violation: The step is rejected, or it states explicitly that it is irreversible and why.
    source: NFR6
    note: Required by aidlc/spaces/default/memory/phases/operation.md, not invented here.

  - id: BR32.11
    statement: No secret value appears anywhere in this document.
    category: constraint
    applies_to: DeploymentStep
    trigger: Writing any step that references a credential.
    logic: >
      IF a step needs a secret
      THEN it names the Secret Manager secret and the environment variable, and
      shows the command that reads it — never a value, never a placeholder shaped
      like a real key.
    violation: The step is rewritten. A committed document is a published document.
    source: C4
    note: >
      The constraint here is disclosure, not cost — but the cost line is sized
      rather than asserted, because the earlier word "comfortably" was neither.
      ACTIVE versions: two secrets under automatic replication (BR32.14) are 2 of
      6. Superseded versions are DESTROYED at rotation, destroyed versions are
      free and do not count as active, so the active count returns to 2 after
      every rotation — 6 is a ceiling on concurrently-active versions, not a
      budget of "two rotations". ACCESS operations: the meter is secrets mounted
      per instance times backend instance starts per month, because BR32.5 pins
      min-instances at 0 and every cold start re-reads what it mounts. With both
      secrets mounted, the worst case under BR32.19's egress-bounded ceiling —
      one cold start per render, 2,684 renders — is 2 x 2,684 = 5,368 of 10,000,
      or 54 percent. It fits, and it is not comfortable: it scales with instance
      CHURN rather than with traffic, so it is the one line here that a quieter
      site does not automatically improve.

  - id: BR32.12
    statement: The plan provisions nothing, deploys nothing and changes no billing.
    category: authorization
    applies_to: DeploymentStep
    trigger: Any temptation to verify a step by running it.
    logic: >
      IF executing a step would create a resource, publish an image or attach a
      billing account THEN it is written down and not run.
    violation: Out of scope and unauthorised. Cloud deployment is explicitly future work.
    source: C4
    note: >
      This is why the runbook is untested. That is a real limitation of this unit
      and it is stated in the plan itself rather than left for a reader to discover.

  - id: BR32.13
    statement: Each cost line states whether its allowance is daily or monthly, and how it aggregates.
    category: validation
    applies_to: CostLine
    trigger: Writing any cost line.
    logic: >
      IF the period or the aggregation scope is omitted
      THEN the reader will assume monthly and per-project, which is wrong for
      Firestore (daily, no rollover) and wrong for almost everything else
      (aggregated per billing account, so a second project buys nothing).
    violation: The line is incomplete.
    source: NFR6

  - id: BR32.14
    statement: Both secrets use automatic replication, never user-managed.
    category: constraint
    applies_to: ConfigurationSetting
    trigger: Creating either Secret Manager secret.
    logic: >
      IF a secret is created with user-managed replication into N locations
      THEN it consumes N of the 6 free active versions instead of 1. Two secrets
      pinned to three locations consume the entire allowance on creation day, and
      the first rotation of either is billable.
    violation: The zero-cost target fails on the first credential rotation.
    source: NFR6, C4
    note: >
      This is the same shape as BR32.4 — a plausible-looking choice that silently
      removes the free tier — and this plan makes it MORE likely, not less:
      BR32.3 requires one region for everything, so the operator is already
      thinking in explicit regions when the replication policy is picked.

  - id: BR32.15
    statement: Cloud Run services use request-based billing; instance-based billing is forbidden.
    category: constraint
    applies_to: ConfigurationSetting
    trigger: Creating or updating a service, or mitigating cold starts.
    logic: >
      IF CPU allocation is set to "always allocated" (instance-based billing)
      THEN the free tier becomes 240,000 vCPU-s and 450,000 GiB-s with NO FREE
      REQUESTS AT ALL, billed from the first request. The quoted 180,000 /
      360,000 / 2,000,000 figures are the request-based numbers and do not apply.
    violation: The 2,000,000-request allowance disappears and every request is chargeable.
    source: NFR6, C4
    note: >
      Third occurrence of the BR32.14 collision shape, and the sharpest: BR32.5
      pins min-instances at 0 and accepts cold starts, and "CPU always allocated"
      is the documented cold-start mitigation an operator reaches for next. The
      setting that looks like the fix for the cost this plan accepted is the one
      that removes the allowance this plan depends on. Slightly MORE free compute
      is the bait; no free requests is the trade. This rule has a second
      consequence the plan did not state until BR32.21: request-based billing
      means CPU is allocated ONLY during request processing, which decides
      whether a background refresh timer can be relied on to run at all.

  - id: BR32.16
    statement: No Cloud Build. Images are built on the developer machine and pushed.
    category: constraint
    applies_to: CostLine
    trigger: Choosing how images reach Artifact Registry.
    logic: >
      IF the plan routes builds through Cloud Build
      THEN its line reads zero only because of the 2,500 build-minute allowance,
      which Google labels PROMOTIONAL and which the site owner's confirmed
      constraint explicitly excludes. A zero that depends on an excluded allowance
      is not a zero.
    violation: >
      The NFR6 claim — the conjunction of every cost line reading zero — silently
      rests on an offer the owner ruled out. Priced without the promotion at
      $0.006/min on e2-standard-2, the line is not zero.
    source: NFR6, C4
    note: >
      Marking the row "documented (promotional)" disclosed the dependency without
      removing it. This project has no CI and no remote (team.md § Way of Working),
      so there is no build trigger to host and nothing is lost by building locally.
      Cloud Build therefore has NO CostLine at all — a service the plan does not
      use is not a row of the cost table — and its absence is recorded in § 7.
      What replaces it is an operator responsibility, which the runbook now
      carries as an explicit build-and-push step.

  - id: BR32.17
    statement: >
      max-instances is 2. The number is forced arithmetic — but what it protects is
      the vCPU-second burn rate, not the Firestore daily read quota.
    category: constraint
    applies_to: ConfigurationSetting
    trigger: Configuring autoscaling, or raising the ceiling under load.
    logic: >
      IF max-instances exceeds 2
      THEN two separate things happen, and only the second one binds.
      (1) The worst-case daily Firestore read count exceeds the 50,000 free quota.
      The published-document cache is IN-PROCESS, so each instance holds its own
      and re-reads at most once per cache interval. BR24.1 fixes that interval at
      5 seconds as a SECURITY maximum (it is the publish-visibility exposure
      window), so it cannot be lengthened to buy headroom. One saturated instance
      performs at most 86,400 / 5 = 17,280 reads per day. Two instances = 34,560.
      THREE instances = 51,840, which exceeds the daily quota on its own.
      (2) The vCPU-second burn rate rises past what the monthly pool can sustain:
      two saturated 1-vCPU instances consume 2 x 86,400 = 172,800 vCPU-seconds in
      ONE DAY, which is 96 percent of the entire 180,000 MONTHLY pool. Three
      consume 259,200, or 144 percent of the month, in a day.
      Leg (2) is reached first and by a wide margin, which is why BR32.20 rather
      than this rule names the binding meter.
    violation: >
      The vCPU-second pool is exhausted in under two days of saturation and Cloud
      Run compute becomes chargeable. The Firestore leg, taken alone, would mean
      chargeable reads or quota errors on a daily quota that does not roll over
      and resets around midnight Pacific — but see the note.
    source: NFR6
    note: >
      The arithmetic in leg (1) is correct and has been recomputed twice. What
      changed is the claim built on top of it. Sustaining three instances for a
      whole day — the event leg (1) prices — costs 144 percent of the monthly
      vCPU pool, so the free tier is already gone before the Firestore quota is
      reached; and under BR32.21's lazy refresh, reads are additionally bounded by
      request count, which BR32.19 caps far below 50,000 a day. The Firestore
      daily read quota is therefore NOT reachable inside this free tier. Keeping
      max-instances at 2 is still right and still forced — it is the only
      ConfigurationSetting that bounds a binding meter at all — but a reader must
      not take it as the thing protecting the zero. The honest statement: this cap
      bounds concurrency, concurrency bounds the vCPU-second burn rate, and
      nothing in Cloud Run's settings bounds egress, which is what actually binds.

  - id: BR32.18
    statement: There is no data-state rollback, and the plan says so rather than implying one.
    category: constraint
    applies_to: DeploymentStep
    trigger: Writing any step that mutates stored content, and the rollback section.
    logic: >
      IF a step writes Firestore documents or Cloud Storage objects
      THEN revision rollback does NOT reverse it. Cloud Run's revision model
      reverses code and nothing else. The Google-native mechanisms that would give
      a data rollback — PITR, Backup, Restore, Clone — have NO FREE USAGE AT ALL,
      so under the zero-cost target they are unavailable, and every such step is
      declared irreversible under BR32.10's escape clause.
    violation: >
      A reader of the runbook is otherwise entitled to believe rollback is
      complete. It reverses half the system.
    source: NFR6, C4
    note: >
      The honest statement is that this topology has code rollback and no data
      rollback, and that buying data rollback means leaving the free tier. The
      runbook has exactly one content-mutating step — the one-shot owner bootstrap
      — and it is marked irreversible under this rule. A step being hard to undo
      is not the same as a step being irreversible: attaching a billing account
      is reversible (disabling billing is the reversal, and it is the same action
      the hard-stop pattern in § 6 automates), and it is no longer listed as
      one-way.

  - id: BR32.19
    statement: >
      Cloud Run internet egress is the binding capacity meter, and any capacity
      figure the plan states is the figure for that meter, with its per-render
      byte assumption attached.
    category: constraint
    applies_to: CostLine
    trigger: >
      Stating what the site can serve, or proposing to return anything new through
      a Cloud Run response body.
    logic: >
      IF the plan states a capacity figure taken from any meter other than Cloud
      Run internet egress THEN it overstates the site's real ceiling. The egress
      allowance is 1 GiB per month to North America on Premium Tier
      (BR32.23): 1,073,741,824 bytes / 400,000 bytes per render = 2,684 renders
      per month. The request meter gives 2,000,000 / 2 requests per render =
      1,000,000 renders, which is 372 times larger and is NOT the ceiling.
      A capacity figure without its bytes-per-render assumption cannot be
      re-checked when the page weight changes, so the assumption travels with it.
    violation: >
      A reader plans against a number three orders of magnitude above the real
      one. This is not a rounding error in a footnote — it is the difference
      between a site that stays free and a site that does not.
    source: NFR6
    note: >
      NO ConfigurationSetting bounds this meter. Cloud Run has no egress-byte
      setting, so unlike every other risk in this plan there is no value to get
      right. The only two mechanisms that touch it are BR32.6, which keeps large
      objects in Cloud Storage's 100 GB pool instead, and the Cloud Run spend-cap
      budget (Preview), which BR32.9 requires be described with its caveats
      intact — not instant, overages billed as normal, manual lift to restore.
      The 400 KB per render is the evidence file's figure for a render BEFORE
      BR32.6 moves static output and media to Cloud Storage; the bytes that leave
      Cloud Run afterwards are the HTML document alone and are NOT MEASURED, so
      the true ceiling is higher by an unmeasured factor. The plan states 2,684
      because it is the conservative figure and the only one with a source, and
      carries the measurement as an open item under BR32.2.

  - id: BR32.20
    statement: >
      vCPU-seconds is the second binding meter, and the monthly pool is worth
      about two saturated instance-days.
    category: constraint
    applies_to: CostLine
    trigger: >
      Sizing Cloud Run compute, raising max-instances, or reasoning about whether
      any daily quota can be reached.
    logic: >
      The request-based pool is 180,000 vCPU-seconds per month (BR32.15).
      180,000 / 86,400 seconds per day = 2.08 saturated 1-vCPU instance-days per
      MONTH. IF max-instances is 2, the worst-case burn is 172,800 vCPU-seconds
      in one day — 96 percent of the month. IF max-instances 2 is applied to BOTH
      services, four saturated instances exhaust the monthly pool in 12.5 hours.
      GiB-seconds is a parallel meter at 360,000 per month: at any memory setting
      BELOW 2 GiB per vCPU, vCPU-seconds runs out first; at exactly 2 GiB they
      run out together; above it, memory binds first.
    violation: >
      Cloud Run compute becomes chargeable, and it can happen in a day rather than
      over a month — which is what makes this meter different from the request
      meter in kind and not only in size.
    source: NFR6
    note: >
      This is the meter that makes the Firestore daily read quota unreachable, by
      two independent routes. (1) Reaching 50,000 reads in a day needs three
      backend instances sustained for that day, and three saturated instances cost
      259,200 vCPU-seconds, 144 percent of the monthly pool. (2) Under BR32.21's
      lazy refresh, reads never exceed backend requests, so 50,000 reads in a day
      needs 50,000 renders in a day — and at any per-render Cloud Run egress above
      1,073,741,824 / 50,000 = about 21 KB, that single day alone exceeds the
      month's entire 1 GiB egress allowance. Under request-based billing an idle
      instance is not burning vCPU-seconds, so 172,800 a day is a worst-case bound
      on a saturated instance, not an expected consumption. Every figure here is
      per 1 vCPU, and BR32.25 is what holds that. max-instances (BR32.17) bounds
      the burn RATE and not the total; BR32.26 records why no per-service setting
      can bound the total at all.

  - id: BR32.21
    statement: >
      This plan's Firestore read arithmetic is valid only if the published-document
      cache refreshes lazily on request and synchronously; the plan states that as
      a dependency on u4-content-core rather than deciding it.
    category: constraint
    applies_to: CostLine
    trigger: >
      Computing any Firestore read figure, and handing this plan to the unit that
      owns the cache.
    logic: >
      IF the refresh is TIMER-DRIVEN then, under the request-based billing BR32.15
      mandates, CPU is allocated only during request processing and a background
      timer cannot be relied on to fire between requests. Two things then fail at
      once: the read model here (at most one read per interval per instance)
      stops being a bound, and BR24.1's 5-second publish-visibility window stops
      bounding what is actually SERVED.
      IF the refresh is LAZY-ON-REQUEST AND SYNCHRONOUS — the request that finds
      the entry older than the interval re-reads BEFORE it serves — THEN reads are
      additionally bounded by request count (reads <= requests), 17,280 per
      instance per day becomes a ceiling rather than a floor, and no response is
      ever served from an entry more than 5 seconds stale.
      Stale-while-revalidate is a third model and is NOT acceptable: it serves the
      stale entry and refreshes behind it, which satisfies the cost leg and breaks
      the security leg silently.
    violation: >
      Two rules resting on opposite unstated assumptions. The cost leg errs in the
      safe direction — a timer that does not fire performs FEWER reads — so the
      zero survives either way. The security leg does not err safely: an entry
      that goes stale for an unbounded wall-clock period keeps serving content the
      owner has unpublished, and keeps passing the media route's public check on
      an asset that is no longer public.
    source: NFR6
    note: >
      The cache and BR24.1 both belong to u4-content-core. This plan does not
      change either and has no authority to. What it owns, and what this rule
      exists to record, is the deployment constraint that unit's owner must be
      told: on Cloud Run under request-based billing, CPU between requests is not
      guaranteed, so a background timer is not a reliable refresh mechanism, and
      BR24.1's interval means "5 seconds of staleness in what is served" only if
      the refresh is synchronous on the request path. Handed to u4-content-core as
      a named dependency, with the decision left there.

  - id: BR32.22
    statement: Cloud Logging retention stays at the 30-day default.
    category: constraint
    applies_to: ConfigurationSetting
    trigger: >
      Configuring log buckets, or wanting a longer audit trail on a site that has
      no other observability.
    logic: >
      IF retention on any log bucket is raised above the default 30 days
      THEN retained logs are billed at $0.01 per GiB per month. Logs kept for the
      default retention period incur no retention cost; only the _Required bucket
      is exempt from storage and retention charges outright.
    violation: >
      A recurring monthly charge, small in dollars and fatal to a HARD zero
      target, created by a setting that looks like diligence.
    source: NFR6
    note: >
      The same shape as BR32.4, BR32.14, BR32.15, BR32.17, BR32.23 and BR32.24 —
      a plausible-looking change that silently leaves the free tier — and this
      plan makes it more likely than most, because it deliberately provisions no
      observability (the operation phase is skipped) and a longer log retention is
      the obvious thing an operator reaches for to compensate. The 50 GiB monthly
      ingestion allowance is per PROJECT and is unaffected by this rule; retention
      is a separate meter from ingestion.

  - id: BR32.23
    statement: Cloud Run stays on Premium network tier. Standard Tier is not a cost-reduction option.
    category: constraint
    applies_to: ConfigurationSetting
    trigger: Looking for a way to reduce egress cost.
    logic: >
      IF the network tier is switched to Standard
      THEN the 1 GiB North America egress allowance does not apply at all —
      "Always Free usage limits do not apply to Standard Tier" — and Standard's
      200 GiB per month is a separate PAID tier, not a larger free one.
    violation: >
      The one allowance that sets this site's capacity disappears, in exchange for
      a tier whose headline number is 200 times larger and entirely billable.
    source: NFR6
    note: >
      Premium is the default, so this rule protects a default rather than changing
      one — which is exactly the case entities.md's ConfigurationSetting
      constraint now admits. It is also the sharpest instance of the family shape:
      the operator is looking at BR32.19's 2,684-render ceiling when they go
      hunting for more egress, and Standard Tier is what they will find.

  - id: BR32.24
    statement: The Cloud Storage bucket uses the Standard storage class.
    category: constraint
    applies_to: ConfigurationSetting
    trigger: Creating the bucket, or choosing a class for media.
    logic: >
      IF the bucket is created in any class other than Standard
      THEN the 5 GB-month allowance does not apply — it is 5 GB-months of STANDARD
      storage specifically. Rapid Storage class and tag operations are excluded
      from the free tier outright.
    violation: Storage becomes chargeable at about $0.020 per GiB-month from the first byte.
    source: NFR6
    note: >
      Independent of BR32.4: a bucket in one of the three eligible REGIONS but in
      the wrong CLASS still loses the allowance, so both conditions have to hold
      and only one of them was previously written down. Rapid Storage is the trap
      here — it is the newer, faster option a media-serving bucket looks like it
      wants.

  - id: BR32.25
    statement: Cloud Run instances are 1 vCPU, on both services.
    category: constraint
    applies_to: ConfigurationSetting
    trigger: >
      Creating or updating a service, or chasing cold-start and request latency
      after BR32.5 has already accepted cold starts.
    logic: >
      IF the CPU size is raised above 1 vCPU
      THEN every vCPU-second figure in BR32.20, BR32.17 and the plan's derivation
      tables divides by the multiplier, silently, because nothing re-derives them.
      At 2 vCPU the 180,000 monthly pool is worth 1.04 saturated instance-days
      instead of 2.08; ONE saturated instance exhausts the entire month in 1.04
      days; two exhaust it in 12.5 hours; and two saturated instances consume
      345,600 vCPU-seconds in a day, 192 percent of the month.
      The GiB-second crossover moves with it: at 1 vCPU, vCPU-seconds binds first
      below 2 GiB of memory per instance, and that threshold halves per vCPU added.
    violation: >
      Every compute figure in this plan becomes wrong by the CPU multiplier while
      still reading as verified, and the meter that was two days from exhaustion
      is one.
    source: NFR6
    note: >
      The eighth member of the BR32.4 / BR32.14 / BR32.15 / BR32.17 family, and it
      arrives by the same door as BR32.15: an operator chasing cold-start or
      request latency. BR32.5 has already accepted cold starts as the price of the
      free tier, so the operator is primed to fix the symptom, and CPU size and
      CPU ALLOCATION MODE are two different settings reached for the same felt
      problem — one halves the runway, the other removes the request allowance.
      Cloud Run's own default CPU size is NOT carried by the evidence file, so
      this rule pins a value rather than defending a default, and the
      ConfigurationSetting row records the default as unverified rather than
      asserting it from memory.

  - id: BR32.26
    statement: >
      The vCPU-second allowance is bounded by TOTAL saturated instance-days across
      both services, and no per-service setting bounds it.
    category: constraint
    applies_to: CostLine
    trigger: >
      Raising max-instances on either service, or reasoning about whether the vCPU
      pool is protected by anything.
    logic: >
      The 180,000 vCPU-second pool is shared by both Cloud Run services and
      aggregated per BILLING ACCOUNT. It is consumed by the TOTAL of saturated
      instance-days — about 2.08 per month at 1 vCPU (BR32.25) — and a
      per-service max-instances CANNOT enforce that total, because the cap bounds
      a RATE and the allowance is a SUM. max-instances 2 on each service bounds
      the burn rate and nothing else: four saturated instances exhaust the month
      in 12.5 hours, whichever services they belong to.
      IF either cap is ever raised THEN what must be re-checked is the SUM across
      both services, not the arithmetic of the service being changed.
    violation: >
      An operator raises one service's ceiling, checks that service's arithmetic,
      is entirely correct about it, and empties the shared pool anyway.
    source: NFR6
    note: >
      Same honest shape as BR32.19 — name the meter, name that nothing bounds it,
      say which mechanism actually reaches it. NO CAP IS INVENTED HERE: a cap that
      cannot be enforced is worse than a stated gap, because it is believed.
      What makes 2 + 2 safe in practice is not a setting. It is that egress binds
      three orders of magnitude earlier (2,684 renders a month, BR32.19), so
      ordinary traffic cannot reach the vCPU ceiling at all. What CAN reach it is
      not traffic in that sense: a runaway loop, a retry storm, or a crawler
      hitting an uncached path. Those consume instance-seconds without consuming
      renders, which is precisely why the egress ceiling does not protect against
      them and why this gap is worth writing down.
```

## Rules summary

| id | Category | What it protects | Source |
|---|---|---|---|
| BR32.1 | constraint | Every figure is dated and sourced | NFR6, S4 |
| BR32.2 | constraint | Image sizes measured, never estimated | NFR6 |
| BR32.3 | constraint | Single region across all components | NFR6 |
| BR32.4 | constraint | Bucket in one of three eligible regions | NFR6 |
| BR32.5 | constraint | `min-instances` stays 0 | NFR6, C4 |
| BR32.6 | policy | Media and static assets bypass Cloud Run egress | NFR6 |
| BR32.7 | policy | Published document cached, not read per render | NFR6 |
| BR32.8 | constraint | Default Firestore database only | NFR6 |
| BR32.9 | policy | Budgets described honestly as alerts | NFR6, C4 |
| BR32.10 | constraint | Per-step rollback | NFR6 |
| BR32.11 | constraint | No secret values; access ops sized against cold starts | C4 |
| BR32.12 | authorization | Nothing is provisioned or deployed | C4 |
| BR32.13 | validation | Allowance period and aggregation stated | NFR6 |
| BR32.14 | constraint | Automatic secret replication — user-managed burns the whole allowance | NFR6, C4 |
| BR32.15 | constraint | Request-based billing — instance-based removes the free requests entirely | NFR6, C4 |
| BR32.16 | constraint | No Cloud Build; its zero depends on an excluded promotional allowance | NFR6, C4 |
| BR32.17 | constraint | `max-instances` = 2 — bounds the vCPU-second burn rate, not the Firestore quota | NFR6 |
| BR32.18 | constraint | No data-state rollback exists under the zero-cost topology; say so | NFR6, C4 |
| BR32.19 | constraint | Cloud Run egress is the binding capacity meter — 2,684 renders/month, and no setting bounds it | NFR6 |
| BR32.20 | constraint | vCPU-seconds is the second binding meter — ~2 saturated instance-days a month | NFR6 |
| BR32.21 | constraint | The cache refresh must be lazy and synchronous; dependency handed to `u4-content-core` | NFR6 |
| BR32.22 | constraint | Cloud Logging retention stays at the 30-day default | NFR6 |
| BR32.23 | constraint | Premium network tier — Standard carries no free allowance | NFR6 |
| BR32.24 | constraint | Standard storage class — Rapid Storage and tag ops are excluded | NFR6 |
| BR32.25 | constraint | 1 vCPU per instance — at 2 vCPU every figure in BR32.20 halves | NFR6 |
| BR32.26 | constraint | The vCPU pool is a **sum** across both services; no per-service setting bounds it | NFR6 |

## Assumptions & Open Questions

- **[assumption]** The figures behind these rules, fetched 2026-09-24, are current
  at the time the plan is read. BR32.1 is what makes that checkable rather than
  assumed — a reader compares `source_date` against today.
- **[assumption]** Several pricing figures were extracted from raw HTML because the
  fetch tool truncated long pricing pages. There is a small transcription risk on
  long numeric SKU values; the allowance figures that these rules turn on are short
  and were cross-read.
- **[resolved]** Cloud Run instances run at 1 vCPU. This was carried as a bare
  assumption under every vCPU figure in the plan; it is now **BR32.25**, with a
  `ConfigurationSetting` row and the numeric consequence of raising it.
- **[open]** The bytes that leave Cloud Run per render AFTER BR32.6 has moved
  static output and media to Cloud Storage. This single number sets the site's
  entire capacity (BR32.19) and is not measured. It is owned by U10 alongside the
  image sizes, under BR32.2. Until it exists, 2,684 renders a month is the
  conservative sourced figure and the plan uses no other.
- **[open]** Whether a Cloud Run spend-cap budget should be recommended at all. It
  covers the one service most likely to run away, and BR32.19 now makes it the
  only mechanism of any kind that touches the binding meter — but it is Preview,
  needs a manual lift to restore, and covers nothing else. BR32.9 requires
  documenting it accurately; it deliberately does not require recommending it.
- **[resolved, as a stated gap]** Whether `max-instances` 2 applies to the frontend
  as well as the backend. It does, and BR32.17's derivation is backend-only (the
  frontend performs no Firestore read), so the second application rests on
  BR32.20. But the question behind it — does 2 + 2 bound the shared pool? — is
  answered **no**, and **BR32.26** now states that as an unbounded-by-construction
  finding rather than pretending a per-service cap closes it. No cap was invented,
  because none can be enforced.
- **[unverified]** That a Secret Manager replication policy cannot be changed after
  the secret is created. The plan states it and builds the "no undo" advice in § 2
  on it, but the evidence file does not carry that line — it records only how
  replication counts against the active-version allowance. Treated the same way as
  the Firestore region question: stated, flagged, not relied on for a zero.
  **How it got here matters as much as whether it is true.** It entered § 2 as an
  undated assertion written from the author's memory, not as a figure read off a
  source — in a document whose own BR32.1 requires every figure to carry a
  `source_url` and a `source_date`. It is probably correct, and that is exactly
  why it slipped: a rule that every figure be dated is worth nothing if the author
  exempts the ones they feel sure about. A later reader needs to know which of the
  two kinds of statement this is, so the kind is recorded and not just the doubt.
