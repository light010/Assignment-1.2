# Code Summary — U1 `source-fixtures`

**Unit:** `source-fixtures` (U1) · **Stage:** Code Generation (3.5) · **Date:** 2026-09-25

U1 ships no application feature. It produces the recorded source-behaviour fixtures —
the golden HTTP and stored-state evidence captured from the running `madhavi-tripathi/`
app — which are the oracle five other units test against. It is the only unit in the
project whose capability **expires**: once the source app is retired, a fixture that was
not recorded cannot be recovered.

All six plan steps executed in order and ticked. **Two expiring evidence gaps that the
first pass could only report were then closed**, on the site owner's explicit decision,
while the source app could still be booted.

## Files created

| Path | What it is |
|---|---|
| `chiku-website/fixtures/record.py` | The recorder, moved in from the session scratchpad with its corrective pass folded into a single run, then extended with the upload family. |
| `chiku-website/fixtures/README.md` | Recording procedure, the three preconditions, the deliberate defects, the three caveat classes, the family → `BR21.x` → requirement map, the spec-to-disk prefix mapping, and the remaining gaps. |
| `chiku-website/backend/tests/test_fixture_set.py` | 13 test functions, 277 parametrized cases — set-level characterization of the fixture set. |

## Files modified

| Path | Change |
|---|---|
| `chiku-website/fixtures/MANIFEST.json`, `http/`, `db/` | Fully re-recorded: **91 fixtures** (85 HTTP + 6 stored-state), up from 57. Six corrective findings, up from four. |
| `.../source-fixtures/code-generation/code-generation-plan.md` | The six `- [ ]` → `- [x]` task markers only. Task markers are excluded from the approval fingerprint. |
| `madhavi-tripathi/.wrangler/state` | Local dev database and object store only — never the source tree. One asset uploaded and published through the app's own routes, then the recording run itself. Backed up before the first write. |

## Key implementation decisions

**The recorder became one file with preconditions in code, not in comments.** Paths derive
from `__file__` — no `/Users/praka` is hardcoded — and the D1 SQLite file is globbed rather
than named by hash. Object size is taken from the recorded body (`len(full.content)`) and
never from `Content-Length`, which the dev server strips; that single line is what turned
three "boundary" ranges into real boundary ranges. Astral padding uses `ensure_ascii=False`.

**Three preconditions are enforced in code**, each raising `Blocked` → exit 2 with nothing
written, which is `BR21.5`:

1. The base host must be literally `localhost` — the dev server binds `[::1]` only.
2. The `editors` row must exist, checked structurally **and** behaviourally via
   `GET /api/content` returning 200, with the remedy SQL printed. `isEditor()` grants
   access only via an existing row or an email equal to `OWNER_EMAIL`, so on an empty
   database every owner-identity fixture would record 404 — the inverse of the oracle.
3. One asset must be in the database and absent from the published document, which is the
   condition `FR7.2`'s draft-only oracle depends on.

`.wrangler/state` is copied to a disposable backup before the first write and the run
aborts if that copy fails. `--check-only` runs the preconditions and writes nothing.

**Upload probe files are constructed byte by byte in the recorder**, with the validator line
each byte satisfies named in a comment, rather than read from opaque sample binaries. The
point of an upload fixture is the *header* a validator inspects, and a binary blob on disk
hides which byte decides the branch. Multipart bodies use a **fixed boundary**, so a
re-record with no behaviour change produces no diff — `httpx`'s own encoder picks a random
boundary per call, and a fixture that changes when nothing changed is not evidence.

**Three facts are now pinned from the recorded bytes**, each stated wrongly or not at all in
the design corpus:

- The 1,500,000 request-body cap counts **UTF-16 code units**.
  `F6-size-astral-under-in-units` → 200 at 1,400,000 units / 2,783,379 UTF-8 bytes (a byte
  cap would reject it); `F6-size-astral-over-in-units` → 413 at 1,600,000 units / 808,326
  codepoints (a character cap would accept it).
- The media route diverges by **publication, not identity**: `F7-draftonly-anon` → 404 (9
  bytes, `Not found`) against `F7-draftonly-owner` → 200 (188,618 bytes), while
  `F7-published-anon` and `F7-published-owner` are both 200 with byte-identical bodies.
- The four conditions on the upload route's prepared-variant check all return **one
  identical message**, so a port implementing any one of them passes a test written against
  any single fixture.

## The two expiring gaps, and how they were closed

**U1-F1 — the ordinary visitor's media read path had no oracle.** The published document
contained zero `/api/media/` references, so `isPublic` was false for every asset and the
`isPublic == true` branch was unreachable. Closed by uploading an asset through
`POST /api/upload` and referencing it from `photoSources`, then saving and publishing
through `PUT /api/content` — the application's own routes throughout, **never a direct
database write** — followed by a full re-record.

**U1-F2 — no upload fixtures existed.** Closed by a new `record_uploads()` pass producing
31 fixtures: one success per accepted MIME type (jpeg, mp4, pdf, png, vtt, webm, webp), six
header-parser rejects, five `validCaptions()` branch rejects, the authorization and origin
refusals, the empty/missing-file and unsupported-type branches, and six prepared-variant
rules. `functional-design/traceability.json`'s FR6 `OK` row is now backed by fixtures.

**One defect found and fixed during this work.** The first VP8L WebP encoder packed the
14-bit height field starting at the wrong byte. It produced files the source parser
*accepted*, with the wrong dimensions — `_webp(128, 96)` decoded as 128×7937 — which
silently sent three variant fixtures into the >1600-pixel branch instead of the branches
they were written for. Caught by reading the recorded bodies rather than the statuses: all
three returned 400, and only the message showed the wrong branch. The corrected encoder
round-trips for 1×1, 64×48, 128×96, 2000×1500 and 16383×16383.

**Two new findings recorded in `MANIFEST.json`.** FIX-5: the 1 MB caption limit is refused
by the dev server before `route.ts` line 31 runs, so the status is source-accurate but the
body is not — the fixture carries a caveat naming the sentence the route would have
produced. FIX-6: the four line-28 variant conditions share one message.

## Test coverage summary

13 test functions / 277 parametrized cases in this unit's file, against the Standard
strategy's 5–8-tests-per-component band for the one component this unit has. No network
calls; the tests read recorded bytes from disk. No mocks — introducing one here would
replace the evidence with a belief about the evidence.

| Test | Asserts |
|---|---|
| `test_every_manifest_fixture_has_its_files_on_disk` | Every manifest-named fixture has metadata and, for HTTP, a body file |
| `test_every_fixture_carries_provenance` | Non-empty `sourceCommit` and `recordedAt` on all 91 (`BR21.2`) |
| `test_manifest_agrees_with_what_is_on_disk` | Manifest counts match disk, for HTTP and DB |
| `test_recorded_bytes_match_the_manifest_digest` | All 85 bodies re-hash to the recorded digest (`BR21.1`) |
| `test_deliberate_defects_are_recorded_and_annotated` | Every `deliberateDefect` names the preserved behaviour; all three present (`BR21.3`) |
| `test_recorder_caveats_name_the_recording_environment` | Every `recorderCaveat` names a dev-server artifact, not source behaviour (`BR21.5`) |
| `test_media_key_cases_record_branches_not_statuses` | The full identity matrix: draft-only diverges, published does not (`BR21.7`) |
| `test_size_cap_family_settles_the_units_question` | UTF-16 units, codepoints and UTF-8 bytes on every size-cap entry (`BR21.6`) |
| `test_upload_family_records_every_accepted_type` | One success per MIME type in `types`, asserted whole rather than sampled |
| `test_upload_rejects_cover_every_validator` | Each header parser and each `validCaptions()` branch refuses, with its exact copy |
| `test_upload_refuses_before_it_reads_anything` | Authorization precedes parsing; the cross-origin caveat stays flagged |
| `test_upload_variant_conditions_share_one_reply` | The three recorded line-28 causes are byte-identical; the three later rules are distinct |
| `test_upload_size_limit_is_recorded_as_unreachable_through_the_dev_server` | FIX-5: the unreachable branch is recorded **with** its caveat rather than omitted |

This unit adds no backend application module, so it contributes nothing to the 80% branch
floor or the 100% hazard-module floor. **No threshold was relaxed, lowered, or disabled.**

The assertions were mutation-checked rather than assumed: flipping
`F7-published-anon`'s recorded status from 200 to 404 fails
`test_media_key_cases_record_branches_not_statuses` with `assert 404 == 200`. The fixture
was restored and the suite re-run green.

### Verification output (verbatim)

```
$ uv run pytest
325 passed in 0.18s

$ uv run ruff check
All checks passed!

$ uv run ruff format --check
14 files already formatted

$ uv run mypy --strict app tests
Success: no issues found in 14 source files

$ uv run ruff check ../fixtures/record.py
All checks passed!

$ uv run ruff format --check ../fixtures/record.py
1 file already formatted

$ uv run mypy --strict ../fixtures/record.py
Success: no issues found in 1 source file
```

325 = 48 pre-existing + 277 in this unit's file. No `# noqa` and no `# type: ignore`
anywhere in the tree.

## Deviations from the plan

**One, recorded in the plan itself and carried forward.** `team.md` requires recording
against a *disposable local* database. That was not possible as written: on an empty
database the local mock identity is not an editor, so every owner-identity fixture would
have recorded 404. The recording used the existing local dev database — still local, still
touching nothing hosted — and `.wrangler/state` was backed up first. The precondition is
enforced in `record.py` so a re-record cannot repeat the mistake.

**Two additions beyond the plan text**, both authorised by the site owner's decision to
close the expiring gaps rather than carry them: the third precondition (an asset present in
the database and absent from the published document), and the `record_uploads()` pass.

## Gaps still open

Full detail with severity, owner, expiry and mitigation is in `traceability.json` →
`open_findings`.

- **U1-F7 (Major, expiring).** Upload cancellation cannot be recorded over HTTP — the two
  cancellation literals and the best-effort cleanup path are reached only by aborting
  mid-flight. Port from `route.ts`'s six `checkCancelled()` call sites; a port placing
  fewer loses cleanup coverage for keys written after the one it kept. Owner: U5.
- **U1-F8 (Minor, expiring).** The 51 MB `content-length` pre-check is unrecorded, and the
  1 MB caption limit is recorded only as a framework rejection. Owner: U5.
- **U1-F9 (Major).** One of the four prepared-variant conditions is not expressible over a
  multipart wire body; the other three are recorded and asserted together. Owner: U5.
- **U1-F4 (Minor).** Fixture prefixes diverge from the spec's numbering from F7 onward;
  mapping table in the README.
- **U1-F6 (Major, process).** The merge-gate command `mypy --strict` as written in
  `team.md` **does not run** — `pyproject.toml` sets no target, so it exits with
  `Missing target module, package, files, or command`. Verified here as
  `uv run mypy --strict app tests`. The configuration was deliberately **not** reshaped to
  make the gate command pass; Build and Test owns the fix.
