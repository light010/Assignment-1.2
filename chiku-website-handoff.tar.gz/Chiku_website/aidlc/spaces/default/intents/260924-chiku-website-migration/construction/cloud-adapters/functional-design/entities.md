# Entities — U11 `cloud-adapters`

**Upstream:** `inception/units-generation/unit-of-work.md`,
`inception/domain-design/components.md`,
`inception/contract-design/contract-summary.md`,
`inception/requirements-analysis/requirements.md`.

**This unit owns no entity.** It implements the three ports U2 defines, against
Google Cloud services, and stores exactly the shapes U2 specifies. An adapter that
introduced an entity of its own would have stopped being an adapter.

What it does own is the **storage mapping** — how each shape lands in Firestore or
Cloud Storage — because that mapping is where the two adapter families genuinely
differ.

```yaml
entities: []
# This unit owns no entity. It implements the three ports U2 defines, against
# Google Cloud services, and stores exactly the shapes U2 specifies. An adapter
# that introduced an entity of its own would have stopped being an adapter
# (BR31.1). What it owns is the STORAGE MAPPING below — how each of U2's shapes
# lands in Firestore or Cloud Storage — because that mapping is where the two
# adapter families genuinely differ.

storage_mapping:
  firestore:
    - shape: ContentDocument
      owner: U4 content-core
      collection: content
      document_id: fixed single id
      note: One document. Draft and published are fields on it.
    - shape: ContentRevision
      owner: U4 content-core
      collection: revisions
      document_id: the revision entry id
      requires_composite_index: true
      composite_index_count: 1
      index_order: [revision DESC, baseline ASC, action DESC]
      note: >
        SQLite will scan for this three-part order; Firestore REQUIRES an
        explicitly declared composite index. Without it the query fails at
        runtime rather than returning a differently ordered list — the better
        failure, but only if the definition travels with the deployment plan
        (BR31.4).
      survivor_read: >
        EXACTLY ONE composite index, on purpose. The retention prune's survivor
        read does NOT get its own: it is a single UNFILTERED revision DESC read of
        the bounded set, partitioned by action IN MEMORY. A filtered read -
        equality on action plus orderBy revision DESC - would require a composite
        index on (action, revision DESC) that nothing here declares, and an
        undeclared composite index fails at RUNTIME, which is the very failure
        BR31.4 exists to prevent. The unfiltered read needs no index beyond what
        exists: an ordering on one field is served by the automatic single-field
        indexes, and the index above covers that ordering as its prefix. Decided
        at the R-05 fix; the three reasons are in functional-spec.md.
    - shape: OwnerAccount
      owner: U3 identity-and-session
      collection: owner
      document_id: fixed single id
      note: One document, or absent. Absence is what gates the bootstrap route.
    - shape: Session
      owner: U3 identity-and-session
      collection: sessions
      document_id: the session id
      note: An expired session is deleted when read, rather than swept on a schedule.
    - shape: LoginAttemptWindow
      owner: U3 identity-and-session
      collection: attempts
      document_id: the window key
      note: Short-lived.
    - shape: Asset metadata
      owner: U5 media
      collection: assets
      document_id: the asset key
      note: Row-shaped, so it lives here and not in the object store.
  cloud_storage:
    - shape: Asset bytes
      owner: U5 media
      path: object under the asset key
      note: >
        Ranged reads use the service's native range support. The port's ranged
        read exists precisely so an adapter never loads a whole video to serve
        one range.
    - shape: Oversized serialised content payload
      owner: U4 content-core
      path: content-addressed object, key is a hash of the content
      applies_to_fields: [ContentDocument.draft, ContentDocument.published, ContentRevision.content]
      note: >
        PER FIELD, not per write - corrected at review (R-01). Each of the three
        fields that can carry a full content document is checked and substituted
        independently, and ContentRevision.content is the one the conflict is
        really about: a revision entry stores FULL content, which is what
        contract-summary C2 payload_size names. An earlier version substituted
        only the content document and would have written an oversized revision
        entry inline. Where no field individually exceeds the threshold but their
        SUM still does not fit - reachable only for ContentDocument, which carries
        two full-content fields on one document - further fields are substituted
        LARGEST-FIRST, rechecking after each, ties broken draft before published
        (tie-break added at the R-05 fix, closing an unspecified branch in a
        module with a 100% branch-coverage floor). All substitutions are written
        BEFORE the transaction (BR31.2); only keys go in the Firestore document.
        Reads reverse it transparently, so a caller cannot tell a substituted
        field from an inline one.

constraints:
  - name: firestore_document_size
    limit_bytes: 1048576
    conflicts_with: FR4.6 (1,500,000 decoded characters, which in UTF-8 can exceed 4 MB)
    affects: >
      ContentDocument.draft, ContentDocument.published AND ContentRevision.content
      - every field that can carry a full content document, matching
      storage_mapping.cloud_storage.applies_to_fields exactly. ContentRevision is
      the shape the conflict is really about, because a revision entry stores FULL
      content, but it is not the only affected shape: ContentDocument holds draft
      and published as fields on ONE document, so either alone can reach the
      ceiling and their sum can exceed the limit even when neither does. This field
      named ContentRevision alone until review (R-01), which under-stated the
      resolution's actual coverage.
    resolution: >
      A serialised payload over a safe threshold is stored as a content-addressed
      object in Cloud Storage with only the key in the Firestore document. SQLite
      is unaffected. The threshold is unset — see open questions.
  - name: transaction_scope
    bound: content document + one revision entry + the pruned set (retention caps at 52)
    shape: >
      TWO PHASES, NOT AN INTERLEAVING - corrected at review (R-05). A Firestore
      transaction is a sequence of reads followed by a sequence of writes and
      REJECTS a read issued after a write, so this transaction is:
      READ PHASE - read the content document (the conflict check), then read the
      existing revision entries as ONE UNFILTERED revision DESC read of the bounded
      set and compute the survivor set, partitioning by action in memory (see
      storage_mapping.firestore.survivor_read for why it is unfiltered);
      WRITE PHASE - write the content update, write the new revision entry, delete
      the existing entries that fell outside the survivor set, commit.
      Read-content, read-survivors, write-content, write-revision, delete-pruned,
      commit. An earlier version placed the survivor read AFTER the content and
      revision writes, which the invariant below shows would have failed on every
      save once the cap was reached. The survivor set is computable in the read
      phase because the new entry ranks first under revision DESC (its number is
      base_revision + 1) and its action is a caller argument - so it is always a
      survivor and never changes which EXISTING entry falls outside the cap. Pure
      resequencing; the prune logic is unchanged (BR31.3).
    invariant: >
      The bound holds because EVERY combined write prunes, so the stored revision
      count never exceeds the retention cap. At the start of any write there are at
      most 52 entries; the write adds one, making 53; the prune removes the excess
      and restores 52. The survivor-determination read is therefore bounded - at 52
      existing entries, since after the resequencing the new entry is computed
      rather than read - and can never grow with the document's age or edit
      history, which is what makes the transaction size a constant rather than a
      function of use.
    worst_case_reads: 53
    worst_case_writes: 3
    worst_case_documents: 54
    note: >
      53 reads = 1 content document + at most 52 existing revision entries.
      3 writes = 1 content update + 1 new revision entry + the pruned set, which
      the invariant holds at one entry per write once the cap is reached. 54
      distinct documents touched, against Firestore's documented 500-document
      transaction limit. Comfortably inside it, and the invariant above is what
      makes that checkable rather than asserted. Added at review (R-04), which
      correctly noted the bound was stated without the invariant that keeps it
      true. RESTATED at R-05: the earlier figure (55 = 1 content + 53 revision
      reads + 1 new-entry write) counted the new entry inside the read set, which
      only made sense under the illegal interleaved order, and counted no deletes
      at all. Both are corrected above. Unverified by execution.
```

## Firestore mapping

| Shape | Collection | Document id | Note |
|---|---|---|---|
| `ContentDocument` | `content` | fixed single id | One document. Draft and published are fields on it |
| `ContentRevision` | `revisions` | the revision entry id | Requires **exactly one declared composite index**, for the three-part order — see below |
| `OwnerAccount` | `owner` | fixed single id | One document, or absent |
| `Session` | `sessions` | the session id | Expired sessions are deleted on read rather than swept |
| `LoginAttemptWindow` | `attempts` | the window key | Short-lived |
| `Asset` metadata | `assets` | the asset key | Row-shaped, so it lives here and not in the object store |

## The two asymmetries that are not incidental

**1. The composite index is a deployment artifact, and there is exactly one.** The
revision listing orders by revision descending, then non-baseline before baseline,
then publish before draft. SQLite will scan for that; Firestore **requires an
explicitly declared composite index**. Without it the query fails at runtime rather
than returning a differently ordered list — which is the better failure, but only if
the index definition travels with the deployment plan. It is recorded as an
obligation on U12.

**One** is a deliberate count, not a coincidence (BR31.4). The retention prune's
survivor read is shaped to need no index of its own — a single **unfiltered**
`revision DESC` read of the bounded set, partitioned by action in memory. The
filtered form would require a second composite index on `(action, revision DESC)`,
and an undeclared composite index fails at runtime, which is the same failure this
asymmetry exists to flag. Stating the count makes it a claim a deployer can check
instead of an assumption a later query can quietly break.

**2. The 1 MiB per-document limit is a real conflict, already resolved.** FR4.6
requires the port to accept a content document up to **1,500,000 decoded
characters**, which in UTF-8 can exceed 4 MB. Firestore's per-document limit is
**1,048,576 bytes**, and a revision entry stores the full content — so a save the
port **must** accept cannot fit in one Firestore document. SQLite is unaffected.

Resolution, from the contract: a serialised payload over a safe threshold is stored
as a **content-addressed object in Cloud Storage**, with only the key in the
Firestore document. The check is applied **per field, not per write** —
`ContentDocument.draft`, `ContentDocument.published` and `ContentRevision.content`
are each checked and substituted independently, because `ContentDocument` carries
draft and published on one document and either alone can reach the ceiling. The
blob is written **before** the transaction, because the key is a hash of the
content, so the write is idempotent and a failed transaction leaves reclaimable
garbage rather than a dangling reference. The reverse ordering is forbidden.

That before-the-transaction position also keeps the transaction's own read/write
split clean: the blob writes are Cloud Storage operations that complete before the
transaction opens, so they are never the Firestore transaction's first write. See
`transaction_scope.shape` above and BR31.3.

## Cloud Storage mapping

Asset bytes map to objects under their asset key. Ranged reads use the service's
native range support; the port's ranged read exists precisely so an adapter never
loads a whole video to serve one range.

## Assumptions & Open Questions

- **[open]** The large-payload threshold is unset. It must be below Firestore's
  limit with margin for the document's other fields, and it is a correctness
  boundary rather than a tuning knob — below it, one storage path; above it, two.
- **[open]** No orphan sweep is specified for blobs left by failed transactions.
  They are reclaimable by construction (content-addressed, so a retry collides
  harmlessly) but nothing currently reclaims them.
- **[assumption, load-bearing]** **Everything here is unverified against the real
  services.** By explicit choice, this unit ships code-complete and labelled. The
  conformance suite proves the adapters satisfy the port; it does not prove they
  work against Firestore or Cloud Storage. Every claim in this file about Firestore
  behaviour comes from its published documentation, not from execution.
