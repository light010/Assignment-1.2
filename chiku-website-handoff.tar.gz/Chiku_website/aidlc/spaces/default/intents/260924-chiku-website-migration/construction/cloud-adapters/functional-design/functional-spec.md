# Functional Spec — U11 `cloud-adapters`

**Upstream:** `inception/contract-design/contract-summary.md`,
`inception/units-generation/unit-of-work.md`,
`inception/domain-design/components.md`,
`inception/requirements-analysis/requirements.md`,
`construction/cloud-adapters/functional-design/entities.md`,
`construction/cloud-adapters/functional-design/rules.md`.

Three adapters implementing the three ports against Google Cloud, run over the
**same conformance suites** as the local adapters. Shipped code-complete and
**unverified against the real services**, by explicit choice.

## Entity relationships (derived view — `entities.md` is source of truth)

`entities.md` declares `entities: []` — this unit owns no entity and stores exactly
the shapes U2 specifies. The derived view is therefore the **storage mapping**:

```mermaid
flowchart TB
    subgraph U2["U2 storage-ports"]
        CS["ContentStore"]
        IS["IdentityStore"]
        AS["AssetStore"]
    end
    subgraph FS["Firestore (default database)"]
        C["content"]
        R["revisions<br/>composite index required"]
        O["owner"]
        SE["sessions"]
        AT["attempts"]
        AM["assets"]
    end
    subgraph GCS["Cloud Storage (same region)"]
        AB["asset bytes"]
        BL["oversized payload blob<br/>content-addressed"]
    end
    CS --> C
    CS --> R
    CS --> AM
    CS -.->|over threshold| BL
    IS --> O
    IS --> SE
    IS --> AT
    AS --> AB
```

*Text fallback:* `ContentStore` maps to the `content`, `revisions` and `assets`
collections, and to a content-addressed Cloud Storage blob when a payload exceeds
the threshold. `IdentityStore` maps to `owner`, `sessions` and `attempts`.
`AssetStore` maps to Cloud Storage objects. The `revisions` collection requires a
declared composite index.

## Rules summary (derived view — `rules.md` is source of truth)

The port is the contract and an adapter never negotiates it (BR31.1); the
oversized-payload blob is written before the transaction (BR31.2); the retention
prune is read-then-delete rather than a predicate, **and every read the
transaction needs is gathered before its first write** (BR31.3); **exactly one**
composite index is required and it travels with the deployment artifacts (BR31.4);
the unverified status is stated
everywhere a reader can reach these adapters (BR31.5); everything is in one region
(BR31.6).

## What "unverified" means precisely

The conformance suite proves these adapters satisfy the port's contract as the
suite expresses it. It does **not** prove they work against Firestore or Cloud
Storage, because nothing in this workflow executes them against either. Every
statement here about service behaviour comes from published documentation.

That is a deliberate scope decision, not an oversight: verifying them would require
provisioning cloud resources, and this workflow provisions nothing.

## The combined write, on Firestore

> **Corrected at review (R-01, Critical).** An earlier version of this algorithm
> applied blob substitution to the content document only, and wrote the revision
> entry inline. That resolved the size conflict **for the wrong object.**
> `entities.md` says *"a revision entry stores full content"* and
> `contract-summary.md` C2 `payload_size` says it outright: *"a revision entry
> stores the full content — so a save this port MUST accept cannot fit in one
> Firestore document."* The revision entry is the shape that cannot fit. A
> developer implementing the old steps would have shipped code that fails at
> runtime on exactly the large save this design claims to have resolved. That fix
> stands, and the per-field substitution below is it.

> **Corrected again at review (R-05, Critical).** Fixing R-01 exposed a worse
> defect in the same algorithm: the steps were ordered *read content, write
> content, write revision, **read** the survivors, delete the rest.* A Firestore
> transaction executes as a sequence of reads followed by a sequence of writes;
> **a read issued after a write in the same transaction is rejected at runtime.**
> The survivor-determination read sat after two writes. And by this design's own
> pruning invariant (`entities.md` § `transaction_scope`) the prune fires on
> **every** combined write once the cap is reached — so this was not an edge case,
> it was every save. Both defects are the same mistake: a SQL-shaped mental model
> applied to an API that does not accept that shape, which is precisely what
> BR31.3 already warned about for the prune's *expression* and now also governs
> its *placement*. The fix is **pure resequencing — no prune logic changes**, for
> the reason recorded at step 5 below.

**Substitution is per stored field, not per write.** Every field that can carry a
full content document is independently checked and independently substituted:
`ContentDocument.draft`, `ContentDocument.published`, and
`ContentRevision.content`. This matters because `ContentDocument` holds **both**
`draft` and `published` as fields on **one** Firestore document, and either alone
can reach FR4.6's 1,500,000-character ceiling — so a per-document check that
passed on each field separately could still exceed the 1,048,576-byte limit on
their sum. The rule is therefore: **substitute any field whose serialised size
exceeds the threshold, and additionally substitute whatever else is needed for the
whole document to fit.**

**The order is largest-first, and it is deterministic** (the R-01 tie-break,
applied at the R-05 fix). "Whatever else is needed" was an unspecified branch, and
this is a hazard-register module carrying a 100% branch-coverage floor at the merge
gate — a branch whose outcome is unspecified cannot be asserted by the test that
floor requires. So, precisely:

1. Substitute every field whose **own** serialised size exceeds the threshold.
2. If the document still does not fit, substitute the remaining candidate fields
   **in descending order of serialised size**, one at a time, rechecking after
   each, until it fits.
3. Ties are broken by a fixed field order: **`draft` before `published`.**

This terminates by construction — substituting every field leaves only small keys,
which always fits — and only `ContentDocument` can reach step 2 at all, since it is
the one document carrying two full-content fields (`ContentRevision` carries one, so
the per-field check in step 1 settles it). The choice is invisible through the port
either way, because reads reverse substitution transparently; what it buys is a
**single** predictable stored state, so the conformance suite can assert *which*
blobs exist rather than merely that the save succeeded.

**Every read comes before every write.** The algorithm has three phases, and the
boundary between the second and the third is not a stylistic preference — it is
what makes the transaction legal (BR31.3).

**Before the transaction — the blob writes:**

1. Serialise the content document and the revision entry's content.
2. For **each** field that exceeds the large-payload threshold — the draft, the
   published document, the revision entry's content — write it as a
   content-addressed object to Cloud Storage **and wait for every such write to
   land**. All of them are written before the transaction opens.

These are Cloud Storage writes, not Firestore operations, and they are **complete
before the transaction exists**. So they are not the transaction's first write, and
the transaction still opens on a clean read phase. This ordering was already right
for its own reason (BR31.2: a failed transaction leaves reclaimable orphan garbage
rather than a dangling reference) and it is also what keeps the read/write split
below clean. Doing the blob writes inside the transaction window would break both.

**Inside the transaction — the read phase, before any write is issued:**

3. Open a transaction.
4. **Read the content document.** If its revision does not match the caller's base
   revision, abort and report a conflict. No write has been issued at this point,
   so the abort costs nothing and nothing has to be undone. This read is also
   where the facts the step 7 mutation-token guard tests are obtained — the guard
   is a precondition established here, not a lookup performed at write time; if an
   implementation needs any further lookup to evaluate it, that lookup belongs in
   this phase too.
5. **Read the existing revision entries** as a **single unfiltered `revision DESC`
   read of the whole bounded set**, and **compute the survivor set now**, before
   anything is written — partitioning by action **in memory**, not by querying per
   action. The new entry is included in that computation from the write's own
   arguments rather than from storage: its revision number is the caller's
   `base_revision` plus one, so it is necessarily the highest and ranks first under
   `revision DESC` — trivially always a survivor, and never the reason an *existing*
   entry falls outside the cap. Its `action` (draft or publish), which the
   per-action retention policy keys on, is a caller argument and is known here.
   **The survivor computation therefore needs no fact that exists only once the new
   entry is persisted**, which is why this is a resequencing and not a change to
   the prune logic.

**Why the survivor read is unfiltered — decided here, not left to the
implementer.** Retention is per action (FR5.3: the most recent 30 draft entries and
20 publish entries, plus the two starting baselines permanently). The obvious
alternative is a *filtered* query — equality on `action` plus `orderBy revision
DESC`, one per action — and it is the wrong choice for three reasons:

1. **It needs no second index.** A filtered query of that shape requires a
   composite index on `(action, revision DESC)` that **nothing in this design
   declares**, and an undeclared composite index fails the query **at runtime** —
   the exact failure mode BR31.4 exists to prevent. A rule that prevents a class of
   failure must not itself depend on a second instance of that class being
   remembered. The unfiltered read needs no index beyond what already exists: an
   ordering on one field is served by Firestore's automatic single-field indexes,
   and the declared `[revision DESC, baseline ASC, action DESC]` listing index
   covers that ordering as its prefix in any case.
2. **The invariant makes it free.** The set is capped at 52 entries
   (`entities.md` § `transaction_scope`), so reading the whole thing costs no more
   than the filtered reads it replaces — and it is **one** round trip rather than
   one per action.
3. **It makes the baseline exemption trivially checkable.** The two permanent
   baselines survive regardless of action counts. In memory that is a filter any
   reader can see and any test can assert; in the filtered form it needs either a
   separate query or an extra index term — more machinery guarding a smaller rule.

**Inside the transaction — the write phase, after which no read is issued:**

6. Write the content update, each oversized field carried **as a blob key** and the
   rest inline.
7. Write the revision entry, guarded by the caller's unique mutation token, with
   its content **inline or as a blob key by the same rule** (the R-01 correction).
8. Delete the existing entries that fell outside the survivor set **computed at
   step 5** — read-the-survivors-then-delete-the-rest, exactly as C2's
   `prune_shape` requires, with the read now gathered up front.
9. Commit.

So the order is: **read-content, read-survivors, write-content, write-revision,
delete-pruned, commit.** Steps 3 through 9 are one transaction; step 2 is
deliberately outside it. Both orderings are load-bearing, and they are independent
of each other — step 2's position is a corruption argument, the read/write split is
an API-legality one.

**Reads reverse it transparently.** A caller never sees a blob key: any field
holding one is fetched from Cloud Storage and returned as content, so the port's
callers cannot tell a substituted field from an inline one. The conformance suite
covers both, which is what makes the substitution invisible rather than merely
intended.

## Revision listing

Ordered revision descending, then non-baseline before baseline, then publish before
draft. **Requires a declared composite index — and it is the only one this unit
needs** (BR31.4). The conformance suite asserts the order, so a missing index
surfaces as a failing test rather than as a list that is quietly in a different
order. The retention prune's survivor read deliberately reuses this ordering rather
than introducing a filtered query that would demand a second index.

## Session and attempt storage

Sessions are documents keyed by session id; an expired session is deleted when
read. Attempt windows are short-lived documents keyed by window key. Neither needs
a composite index.

## Asset bytes

Objects under the asset key. Ranged reads use the service's native range support.

## Assumptions & Open Questions

- **[assumption, load-bearing]** Everything in this file is derived from
  documentation rather than execution. The first time these adapters run against a
  real service will be the first time any claim here is tested.
- **[open]** The large-payload threshold and the orphan-blob sweep, both from
  `entities.md`.
- **[open]** Whether Firestore's emulator would have been worth adding to make this
  unit verifiable. It was considered and declined at practices discovery for the
  weight it adds to the test loop; that trade is what this unit's unverified status
  buys.
