# Functional Spec — U12 `deployment-plan`

**Upstream:** `inception/units-generation/unit-of-work.md`,
`inception/requirements-analysis/requirements.md` (NFR6, C4, S4),
`inception/domain-design/components.md`,
`construction/deployment-plan/functional-design/entities.md`,
`construction/deployment-plan/functional-design/rules.md`,
`scratchpad/gcp-free-tier-verified.md`.

This unit delivers **one reviewed document**, `docs/deployment-plan.md`. It
provisions nothing, deploys nothing, publishes no image and attaches no billing
account (BR32.12). Cloud deployment is explicitly future work.

## Entity relationships (derived view — `entities.md` is source of truth)

```mermaid
erDiagram
    COST_LINE ||--o{ CONFIGURATION_SETTING : "zero depends on"
    DEPLOYMENT_STEP }o--o{ CONFIGURATION_SETTING : applies
    COST_LINE {
        string service
        string expected_usage
        string free_allowance
        enum allowance_period
        enum allowance_aggregation
        string expected_charge
        string overage_trigger
        string source_url
        date source_date
        enum verification
    }
    DEPLOYMENT_STEP {
        int sequence
        string action
        string verification
        string rollback
        string cost_impact
    }
    CONFIGURATION_SETTING {
        string setting
        string required_value
        string default_value
        string consequence_if_wrong
    }
```

*Text fallback:* a `CostLine`'s zero depends on one or more
`ConfigurationSetting`s holding it there; `DeploymentStep`s apply
`ConfigurationSetting`s, many to many.

## Rules summary (derived view — `rules.md` is source of truth)

Dated sources on every line (BR32.1); measured image sizes (BR32.2); one region
(BR32.3); bucket in one of three eligible regions (BR32.4); `min-instances` at 0
(BR32.5); media off the Cloud Run egress path (BR32.6); published document cached
rather than read per render (BR32.7); default Firestore database only (BR32.8);
budgets described as alerts, not caps (BR32.9); per-step rollback (BR32.10); no
secret values, and the access-operation line sized rather than asserted (BR32.11);
nothing provisioned (BR32.12); allowance period and aggregation stated (BR32.13);
automatic secret replication (BR32.14); request-based Cloud Run billing (BR32.15);
no Cloud Build (BR32.16); `max-instances` at 2, protecting the vCPU-second burn
rate (BR32.17); no data-state rollback, stated (BR32.18); Cloud Run egress named
as the binding capacity meter at 2,684 renders/month (BR32.19); vCPU-seconds as
the second binding meter at ~2 saturated instance-days/month (BR32.20); the cache
refresh required to be lazy and synchronous, handed to `u4-content-core` as a
dependency (BR32.21); Cloud Logging retention at the 30-day default (BR32.22);
Premium network tier (BR32.23); Standard storage class (BR32.24); 1 vCPU per
instance (BR32.25); and the vCPU pool named as a **sum across both services** that
no per-service setting bounds (BR32.26).

**Eight of the twenty-six are the same shape, and it is worth naming.** BR32.4,
BR32.14, BR32.15, BR32.17, BR32.22, BR32.23, BR32.24 and BR32.25 each forbid a
setting that looks *more* correct than the one required — a bucket in the US
multi-region, user-managed replication pinned to the same region everything else
uses, "CPU always allocated" as the cold-start fix, a higher instance ceiling under
load, longer log retention on a site with no other observability, Standard network
tier as the answer to a tight egress allowance, Rapid Storage for a media bucket, a
larger CPU to make requests faster. Most of them are made **more** likely by this
plan's own other rules. A free-tier plan's real failure mode is not ignorance; it
is a plausible-looking choice.

**Two of the twenty-six have the opposite shape: they name a meter that nothing
bounds.** BR32.19 (egress) and BR32.26 (the shared vCPU pool) record gaps rather
than values. Neither invents a control, because a control that cannot be enforced
is worse than a stated gap — it gets believed.

## Document structure

### 1. Topology

Two Cloud Run services — the Next.js renderer and the Python API — in **one
region**, both at `min-instances: 0`. Firestore (default database) and one Cloud
Storage bucket in the **same region**. Images in Artifact Registry in that region,
so the pull is a same-location transfer and therefore free.

Static build output and uploaded media are served **from Cloud Storage**, not
through either container (BR32.6). This is the shape of the topology rather than an
optimisation of it: routing media through Cloud Run moves video and PDF bytes from
a 100 GB allowance into a 1 GiB one — and that 1 GiB is what sets the site's entire
capacity (BR32.19).

The region choice must satisfy three constraints at once — a Cloud Run Tier 1
region (the free-tier discount is applied at Tier 1 pricing, so a Tier 2 region
buys fewer seconds for the same dollar discount), one of the three Cloud Storage
free-tier regions, and North America for the egress allowance. **`us-central1`,
`us-east1` and `us-west1` are the three that satisfy all three.**

### 2. Cost table

One `CostLine` per service, in the shape `entities.md` defines. Every line reads
zero or the plan has not met NFR6. Present state from the verified figures:

| Service | Allowance | Period | Aggregation | Status |
|---|---|---|---|---|
| Cloud Run | 180,000 vCPU-s · 360,000 GiB-s · 2M requests — **request-based billing only** | monthly | per-billing-account | documented (BR32.15) |
| Firestore | 1 GiB · 50k reads · 20k writes · 20k deletes · **10 GiB egress/month** | **daily** (egress monthly) | per-project (one free DB) | documented |
| Cloud Storage | 5 GB **Standard** · 5k Class A · 50k Class B · 100 GB NA egress | monthly | per-region-group (3 regions, aggregated) | documented (BR32.24) |
| Artifact Registry | 0.5 GB | monthly | per-billing-account | **measured — pending U10** |
| Cloud Logging | 50 GiB ingestion · 30-day retention included | monthly | per-project | documented (BR32.22) |
| Secret Manager | 6 **active** versions · 10k access ops | monthly | per-billing-account | documented — see the replication trap below |
| Cloud Run egress | **1 GiB to North America, Premium Tier** | monthly | per-billing-account | documented (BR32.23) — **this is the binding meter** |

**Cloud Build has no row, and its absence is the decision.** BR32.16 removed it;
a service the plan does not use is not a line of the cost table, and giving it a
row forced `—` into `allowance_period` and `allowance_aggregation`, which
`entities.md` marks required enums. The removal itself is recorded in § 7 so a
reader can tell a deliberate omission from an oversight.

**Sources, dates, usage and overage triggers — BR32.1 and BR32.13 applied to this
table.** The rule requires every line to carry `source_url` and `source_date`, and
`entities.md` gives `CostLine` an `expected_usage`, an `expected_charge` and an
`overage_trigger`. All figures below were fetched **2026-09-24**.

Every `expected_usage` rests on **one stated traffic assumption**, because a number
without its assumption cannot be re-checked: **the site is bounded by Cloud Run
egress at no more than 2,684 renders a month (BR32.19), plus the single site
owner's editor sessions.** That is roughly 89 renders a day. Where a figure cannot
be derived from that assumption because nothing has been built or run yet, the line
says `pending` rather than carrying an estimate (BR32.2).

| Service | `expected_usage` (from the stated assumption) | `expected_charge` | `overage_trigger` | `source_url` |
|---|---|---|---|---|
| Cloud Run | ≤5,368 requests/month (2,684 renders × 2 requests) = **0.27% of 2M**. vCPU-s and GiB-s per render **pending measurement**; bounded above by `max-instances` 2 at 172,800 vCPU-s/day worst case (BR32.20) | $0 | >180,000 vCPU-s, >360,000 GiB-s or >2M requests in a month; **or** switching to instance-based billing (BR32.15) | `cloud.google.com/run/pricing` |
| Firestore | Reads ≤1 per backend request under BR32.21's lazy refresh, so ≤2,684/month ≈ **≤89/day against a 50,000/day quota**. Writes: one owner's save/publish actions, far below 20,000/day. Storage **pending**. Egress **0 of 10 GiB** — reads travel to Cloud Run in the same region and same-region transfer is free (BR32.3) | $0 | >50,000 reads, >20,000 writes or >20,000 deletes **in one day**; >1 GiB stored; >10 GiB egress in a month; a named database (BR32.8) | `cloud.google.com/firestore/pricing` |
| Cloud Storage | Stored bytes **pending U10** (static build output + uploaded media). Class A: owner uploads only. Class B: every static and media fetch — the quietest path, see the assumption below. Egress ≤100 GB NA and this is where BR32.6 puts the large objects | $0 | >5 GB stored, >5,000 Class A, >50,000 Class B, >100 GB NA egress monthly; a bucket outside the three eligible regions (BR32.4); **or a non-Standard class, or tag operations (BR32.24)** | `cloud.google.com/storage/pricing` |
| Artifact Registry | **pending U10** — compressed, deduplicated layer blobs for two images plus retained rollback versions | **pending U10** | >0.5 GB compressed, deduplicated, aggregated across every repository on the billing account | `cloud.google.com/artifact-registry/pricing` |
| Cloud Logging | Ingestion **pending** (no observability is provisioned — the operation phase is skipped), against 50 GiB/project/month. Retention held at the 30-day default (BR32.22) | $0 | >50 GiB ingestion monthly; **or retention raised above 30 days, at $0.01/GiB/month (BR32.22)**; vended network logs at $0.25/GiB with no free allotment, unreachable absent a VPC connector | `cloud.google.com/stackdriver/pricing` |
| Secret Manager | **2 active versions of 6** under automatic replication (BR32.14), returning to 2 after each rotation because destroyed versions are free and do not count. Access ops = secrets mounted × backend instance starts; worst case one cold start per render = 2 × 2,684 = **5,368 of 10,000, 54%** | $0 | >6 **active** versions — user-managed replication into N locations counts as N (BR32.14); >10,000 access operations, which scales with instance **churn**, not traffic | `cloud.google.com/secret-manager/pricing` |
| Cloud Run egress | **This is the meter that sets every other line's usage.** 1 GiB ÷ 400 KB/render = 2,684 renders/month. The frontend→backend hop is same-region and free; only browser-facing bytes count | $0 | >1 GiB to North America monthly; media served through Cloud Run instead of Cloud Storage (BR32.6); **or Standard network tier, which carries no free allowance at all (BR32.23)** | `cloud.google.com/run/pricing` |

Every `expected_charge` above is $0 **without relying on any promotional,
introductory or trial allowance**, which is the form the site owner's constraint
actually requires. The one open figure is Artifact Registry, and BR32.2 keeps it
open rather than guessed.

#### Which meter actually binds, and at what number

The earlier version of this section stated the site's capacity as "about 1M
renders". That is the figure for the **request** meter, and it is **372 times
larger than the real ceiling**. The meters bind in this order:

| Meter | Allowance | Ceiling it sets | Bounded by a setting? |
|---|---|---|---|
| **Cloud Run internet egress (NA)** | 1 GiB/month, Premium Tier | **2,684 renders/month** — 1,073,741,824 ÷ 400,000 bytes | **No. None exists.** |
| **Cloud Run vCPU-seconds** | 180,000/month | **2.08 saturated 1-vCPU instance-days/month** — 180,000 ÷ 86,400 | Partly — `max-instances` bounds the *rate*, not the total |
| Cloud Run requests | 2,000,000/month | ~1,000,000 renders, at 2 requests each | Not needed; 372× above the binding one |
| Firestore reads | 50,000/**day** | **Not reachable inside the free tier** | `max-instances` 2 bounds it at 34,560/day anyway |

**Egress is the ceiling, and nothing in Cloud Run's settings bounds it.** This is
the one risk in this plan with no value to get right — there is no egress-byte
setting to set. The only two mechanisms that touch the meter are BR32.6, which
keeps the large objects in Cloud Storage's hundredfold-larger pool, and the Cloud
Run spend-cap budget (Preview), which § 6 describes with its caveats intact. An
operator who wants more headroom than 2,684 renders has exactly one free move —
take more bytes out of the Cloud Run response — and one paid one.

**The 400 KB is a conservative figure, and the honest one is not measured.** The
evidence file's 400 KB per render is a render *before* BR32.6 moves
`/_next/static/*` and uploaded media to Cloud Storage. Afterwards the bytes leaving
Cloud Run are the HTML document alone, so the true ceiling is higher by a factor
nobody has measured. The plan states 2,684 because it is the conservative number
and the only one with a source; measuring the post-BR32.6 per-render bytes is an
open item owned by U10 under BR32.2, alongside the image sizes. Stating the
unmeasured larger number would repeat exactly the mistake BR32.2 exists to prevent.

**vCPU-seconds is the second meter, and it is different in kind.** The monthly pool
is worth 2.08 saturated 1-vCPU instance-days. Two saturated instances consume
172,800 vCPU-seconds — **96% of the month — in a single day**; if `max-instances`
2 is applied to both services, four saturated instances exhaust the month in 12.5
hours. Under request-based billing (BR32.15) an idle instance burns nothing, so
these are worst-case bounds on saturation rather than expected consumption. GiB-
seconds runs in parallel at 360,000/month: below 2 GiB of memory per vCPU, vCPU
binds first; above it, memory does.

**The Firestore daily read quota cannot be reached inside this free tier**, by two
independent routes. (1) Reaching 50,000 reads in a day needs three backend
instances sustained for that day, and three saturated instances cost 259,200
vCPU-seconds — **144% of the monthly pool, in one day**. (2) Under BR32.21's lazy
refresh, reads never exceed backend requests, so 50,000 reads in a day needs 50,000
renders in a day; at any per-render Cloud Run egress above 1,073,741,824 ÷ 50,000 ≈
**21 KB**, that one day alone exceeds the month's entire egress allowance. This is
why BR32.17 keeps its value of 2 but no longer claims to be what protects the zero.

**Every public render costs two requests**, browser to frontend and frontend to
backend, and burns CPU-seconds on both services against one shared pool. The
frontend-to-backend hop is same-region and therefore free of egress charge, but it
still consumes a request and the callee's vCPU- and GiB-seconds. The request meter
alone would allow about 1M renders; it is not the constraint and the plan no longer
presents it as one.

**The Secret Manager replication trap — and this plan's own region rule walks into
it.** The free allowance is 6 **active** versions per billing account, and
**user-managed replication into N locations counts as N versions; automatic
replication counts as 1.** This project holds two secrets — the session signing key
and the initial-owner bootstrap secret. Under automatic replication that is 2 of 6,
and it returns to 2 after every rotation, because superseded versions are destroyed
and destroyed versions are free and do not count as active. Under user-managed
replication pinned to three locations it is **6 of 6 on the day the secrets are
created**, and the first rotation of either one is billable.

The reason this needs stating rather than assuming: **BR32.3 requires every
component in one region**, so an operator following this plan is already thinking
in explicit regions when the replication policy is chosen, and "user-managed, same
region as everything else" is the natural-looking pick. It is the expensive one.
Choose **automatic** replication for both secrets. The plan further states that the
policy is fixed at secret creation and that the only remedy is a new secret and a
migration — but **that sentence entered this document as an undated assertion
written from memory, not as a figure read off a source**, which is the one thing
BR32.1 exists to prevent. It is probably true. That is why it slipped: a rule that
every figure be dated is worth nothing if the author exempts the ones they feel
sure about. It stays, flagged `[unverified]` in § 7 with its provenance, so a
reader can tell a sourced figure from a confident one.

**The access-operation line is sized, not asserted.** BR32.5 pins `min-instances`
at 0, so every cold start re-reads whatever secrets the instance mounts. The meter
is therefore *secrets mounted × backend instance starts per month*, not a function
of traffic volume. With both secrets mounted and the worst case of one cold start
per render, the egress-bounded ceiling of 2,684 renders gives 5,368 access
operations — **54% of the 10,000 allowance**. It fits. It is not comfortable, and
it is the one line here that a quieter site does not automatically improve, because
it scales with instance churn.

**Cloud Build is removed, not annotated.** Its allowance is labelled
**promotional** on Google's own page, and the site owner's constraint excludes
promotional offers — so a line reading zero *because of it* made the NFR6 claim,
which `entities.md` defines as the conjunction of every line being zero, rest on an
allowance the owner ruled out. Marking the row "documented (promotional)" disclosed
that dependency without removing it. This project has no CI and no remote
(`team.md` § *Way of Working*), so there is no build trigger to host: **images are
built on the developer machine and pushed.** Priced without the promotion it would
have been $0.006/min on e2-standard-2 — not zero. Removing the line is strictly
better than qualifying it, and § 5 now carries the operator step that replaced it.

One entry is deliberately not clean. Artifact Registry is **pending** until U10
builds real images (BR32.2) — an earlier estimate of this line was wrong by close
to an order of magnitude and the rule exists because of it. **If the measured size
lands above 0.5 GB**, this line is not zero and the plan does not silently absorb
it: the cleanup policy below is applied first, the size is re-measured, and if it
is still over, the overage (~$0.10/GiB-month, on an allowance aggregated across
every repository on the billing account) is reported to the site owner as a breach
of the hard target rather than accepted.

### 3. Configuration settings that are not preferences

| Setting | Required | Default | Consequence at the default |
|---|---|---|---|
| `min-instances` | `0` | `0` | Raising it: ~2.59M vCPU-s/month against a 180,000 pool, ~$9–10/month |
| Bucket location | `us-central1` \| `us-east1` \| `us-west1` | `US` multi-region | **No Cloud Storage free tier at all** |
| Bucket storage class | **`STANDARD`** | `STANDARD` | The 5 GB-month allowance is Standard-only; Rapid Storage and tag operations are excluded outright (BR32.24) |
| Firestore database | default, unnamed | none — no database exists until one is created | A named database gets no free quota, and the project has only one free slot (BR32.8) |
| Region (both services) | one, shared | per-service | Cross-region service traffic becomes chargeable |
| `max-instances` | **`2`** | `100` | At 3+, two saturated instances already burn 96% of the monthly vCPU-second pool in a day and three burn 144% (BR32.20); the Firestore read leg that originally produced the number is at 34,560/50,000 (BR32.17) |
| CPU allocation / billing mode | **request-based** ("CPU only allocated during request processing") | request-based | Instance-based gives 240,000 vCPU-s and 450,000 GiB-s but **no free requests at all** — billed $0.40/1M from the first request (BR32.15) |
| CPU size (both services) | **1 vCPU** | **unverified** — the evidence file does not state Cloud Run's default CPU size | At 2 vCPU the 180,000 pool is worth **1.04** saturated instance-days instead of 2.08; one saturated instance exhausts the month in 1.04 days, two in 12.5 hours, and every vCPU figure in this plan halves without being re-derived (BR32.25) |
| Network tier (Cloud Run) | **Premium** | Premium | Standard Tier carries **no Always Free allowance**; its 200 GiB is a separate paid tier, so it is not a cost reduction (BR32.23) |
| Log bucket retention | **30 days** | 30 days | Above the default, retained logs bill at $0.01/GiB/month; only `_Required` is exempt (BR32.22) |
| Secret replication policy | **automatic** | — (chosen at creation) | User-managed into N locations counts as N of the 6 active versions (BR32.14) |
| Vulnerability scanning | not enabled | opt-in | One of Artifact Registry's three billable items |

**Four of these rows have a required value equal to the default**, and they are in
the table for exactly that reason: `min-instances`, CPU allocation, network tier
and log retention are all correct out of the box and all four are things an
operator is actively pushed to change — by cold-start latency, by the documented
cold-start fix, by a 2,684-render egress ceiling, and by wanting an audit trail on
a site with no other observability. `entities.md`'s constraint on this shape was
rewritten to say so.

#### The binding meters and what bounds them

| Binding meter | What bounds it | Is it a `ConfigurationSetting`? |
|---|---|---|
| Cloud Run internet egress (1 GiB/month) | BR32.6 (keep large objects in Cloud Storage); Cloud Run spend-cap budget (Preview) | **No — Cloud Run has no egress-byte setting.** Stated rather than left as an apparent omission |
| Cloud Run vCPU-seconds (180,000/month) | `max-instances` = 2 per service bounds the burn **rate** at 172,800/day; BR32.15's request-based billing, under which idle time is not billed; BR32.25 fixes the per-instance multiplier at 1 vCPU | **No — not the total.** See below: the allowance is a sum across both services and no per-service setting reaches it (BR32.26) |

**The vCPU pool is a sum, and nothing bounds the sum (BR32.26).** The 180,000
vCPU-seconds are shared by both Cloud Run services and aggregated per billing
account. What consumes them is the **total saturated instance-days across both
services — about 2.08 a month at 1 vCPU** — and **no per-service `max-instances`
can enforce a monthly total**, because the cap bounds a *rate* and the allowance is
a *sum*. `max-instances` = 2 on each service bounds the burn rate and nothing else:
four saturated instances exhaust the month in **12.5 hours**, whichever services
they belong to.

What makes 2 + 2 safe in practice is therefore not a setting. It is that **egress
binds three orders of magnitude earlier** — 2,684 renders a month (BR32.19) — so
ordinary traffic cannot reach the vCPU ceiling at all. What *can* reach it is not
traffic in that sense: **a runaway loop, a retry storm, or a crawler hitting an
uncached path**, each of which burns instance-seconds without producing renders,
which is exactly why the egress ceiling does not protect against them.

**If either cap is ever raised, the sum across both services is what must be
re-checked** — not the arithmetic of the service being changed. This plan invents
no cap here, because none can be enforced, and a control that cannot be enforced is
worse than a stated gap: it gets believed.

**`max-instances` = 2 is forced arithmetic, and it is worth being precise about
what it buys.** The published-document cache is **in-process**, so every instance
holds its own and re-reads at most once per cache interval. `BR24.1` (owned by
`u4-content-core`) fixes that interval at **5 seconds as a security maximum** — it
is the publish-visibility exposure window — so it cannot be lengthened to buy read
headroom. One saturated instance therefore performs at most `86,400 / 5 = 17,280`
reads per day:

| instances | worst-case reads/day | against the 50,000 daily quota | vCPU-seconds that day, against a 180,000 **monthly** pool |
|---|---|---|---|
| 1 | 17,280 | 35% | 86,400 — 48% of the month |
| **2** | **34,560** | **69%** | **172,800 — 96% of the month** |
| 3 | 51,840 | breached | 259,200 — **144% of the month** |

Read the two right-hand columns together and the point of the cap changes. The
Firestore column is correct arithmetic, but the row that breaches it costs 144% of
the *monthly* vCPU pool in a *single day* — so an operator never arrives at a
Firestore overage with the free tier intact. **What `max-instances` = 2 actually
protects is the vCPU-second burn rate.** It remains the right value, and it is the
only setting in this plan that bounds a binding meter at all; it is not what holds
the zero-cost claim up, and presenting it that way would read as due diligence
while the real ceiling sat far below.

**The 15,440-read remainder is now a budget, not slack.** Under BR32.21's lazy
refresh a read buys 5 seconds of instance life, so total daily reads are bounded by
`(instance-seconds per day) / 5 + (cold starts per day)` — at `max-instances` 2
that is `34,560 + starts`. The 15,440 head-room therefore funds **15,440 cold
starts a day, one every 5.6 seconds**, which is far beyond anything this topology
can reach: each of those starts also burns CPU against the same 180,000-second
pool, and BR32.19 caps renders at about 89 a day. The earlier table presented
15,440 as an unmodelled remainder; it is a computed cold-start budget.

### 4. Prerequisites

A billing account (always-free requires one, has no end date, and is calculated per
billing account), the required APIs enabled, an IAM service account per service with
least privilege, and the session signing key plus any adapter credentials in Secret
Manager — referenced by name only (BR32.11).

**Judge cost behaviour against paid-account rules from the start.** On a Free Trial
account the $300 credit silently absorbs every overage, so the project reads "$0 due"
for 90 days and then bills for real on conversion. A plan validated against trial
behaviour has validated nothing.

### 5. Deploy and rollback runbook

Numbered `DeploymentStep`s, each with its verification, **its own rollback**
(BR32.10) and its cost impact. Cloud Run's revision model is what makes per-step
rollback honest for the service steps: the previous revision remains addressable and
traffic is shifted back to it.

**Revision rollback reverses code. It reverses no data, and under this topology
nothing else does either (BR32.18).** A newer revision that wrote Firestore
documents or Cloud Storage objects leaves those writes in place when traffic shifts
back; the old code then runs against the new data. The Google-native mechanisms
that would give a data rollback — **PITR, Backup, Restore and Clone — have no free
usage at all**, so they are unavailable under the hard zero-cost target and appear
in § 7 as an explicitly excluded capability rather than in the cost table.

The consequence, stated rather than implied: **every step that mutates stored
content is irreversible**, and is marked so under BR32.10's escape clause. A reader
of a runbook whose service steps all carry a rollback is otherwise entitled to
believe rollback is complete. It covers half the system. Buying the other half
means leaving the free tier — a trade the site owner may want to make later, and
not one this plan can make silently.

**Build and push the images — the step that replaced Cloud Build.** BR32.16 moved
image production onto the developer machine, and that is an operator
responsibility, so it is a numbered step rather than an assumption.

- *Action:* build both images locally per `team.md` § *Deployment* — `uv sync
  --frozen` and `pnpm install --frozen-lockfile` only, base images pinned by
  digest, a non-root user in each — then authenticate Docker to the regional
  Artifact Registry host and push both tags.
- *Prerequisites:* a local Docker daemon; `gcloud` authenticated; Docker
  credential configuration for the regional AR host; the repository created in the
  **same region** as the services (BR32.3), so the Cloud Run pull is a same-location
  transfer and free.
- *IAM:* the pushing principal needs **Artifact Registry Writer**
  (`roles/artifactregistry.writer`) on that repository. Nothing broader; the push
  identity is not the runtime service account.
- *Verification:* the pushed digests are listed in the repository, the deployed
  revision references a **digest** rather than a floating tag, and `docker history`
  on both images confirms no secret landed in a layer — the once-per-skeleton check
  `team.md` requires, and the project-level prohibition on secrets in `ARG`/`ENV`.
- *Rollback:* delete the pushed tag or digest from the repository. This is a real
  reversal, not an escape-clause case — the registry is not stored application
  content and BR32.18 does not reach it.
- *Cost impact:* **none for the transfer** — data into Google Cloud is free, and
  same-location pulls are free. The pushed layers are what consume the Artifact
  Registry storage allowance, so this is the step that fills the one `pending` line
  in § 2, and it is where U10's measured figure comes from (BR32.2).

**Apply the composite index** U11 requires for the revision listing. Without it
that query fails at runtime rather than returning a differently ordered list. The
definition ships as part of this artifact set (CA-4), because a missing index is
only a loud failure if someone has the definition to apply. *Rollback:* delete the
index. *Cost impact:* index storage counts against the 1 GiB Firestore allowance.

**Provision the first owner — and this step is irreversible (BR32.18).** Secure
first-owner provisioning in a container with no interactive shell: the one-shot
bootstrap route, enabled only while no owner record exists and
`ADMIN_BOOTSTRAP_SECRET` is set. The gate is the record's existence, not a consumed
flag, so a restart cannot reopen it. No default credentials, no bypass.

This is the **only content-mutating step in the runbook**, and it is irreversible
in the strongest sense this plan describes: the write closes the route permanently,
and undoing it means deleting the owner document — itself an unreversible data
mutation, with no PITR, Backup, Restore or Clone available to take it back. *Cost
impact:* one Firestore write. *Rollback:* **none. Marked irreversible under
BR32.10's escape clause.** Re-opening provisioning means deleting the owner record
by hand, which is a second irreversible mutation rather than a reversal of the
first.

**Steps that genuinely have no clean reversal:**

- **The one-shot owner bootstrap**, above.
- **Creating the Firestore database.** Firestore allows exactly **one free database
  per project** (BR32.8), so creating it spends a slot the project has only once,
  and a second, named database would get no free quota at all. The database's
  **location** is chosen at this moment; the plan does not claim on its own
  authority that the location is immutable, because the evidence file does not
  carry that line — § 7 records it as unverified.
- **Creating each Secret Manager secret**, whose replication policy is chosen at
  creation (BR32.14). The same caveat applies: the policy's immutability is stated
  in § 2 and flagged unverified in § 7.

**Attaching a billing account is *not* on that list, and the earlier version of
this section was wrong to put it there.** Billing can be disabled on a project;
nothing in the evidence file calls the attachment one-way. It is in fact the
*reversal* that § 6's hard-stop pattern automates — budget to Pub/Sub to a function
that disables billing — so calling it irreversible contradicted this document's own
cost-control section two pages later.

### 6. Cost controls, described accurately

An ordinary budget is an **alert**. It does not prevent the use or billing of
services. A spend-cap budget (Preview) does pause usage but covers **Cloud Run
only**; Firestore, Cloud Storage, Artifact Registry, Cloud Build, Logging and Secret
Manager are ineligible, enforcement is not instant, overages are billed as normal,
persistent resources keep accruing regardless, and restoring service requires a
manual lift. The budget-to-Pub/Sub-to-disable-billing pattern is the only true hard
stop, and Google's own warning — resources "might be irretrievably deleted", "no
guarantee of service recovery", and it still does not guarantee staying under
budget — travels with it (BR32.9).

One consequence is worth stating here rather than leaving to § 2: the Cloud Run
spend-cap budget is the **only mechanism of any kind that touches the binding
meter**. Egress has no setting (BR32.19), so an operator who wants a stop rather
than an alert on the one number that caps this site has this Preview feature and
nothing else. Whether to use it stays the operator's judgement; BR32.9 requires it
be described accurately, not that it be recommended.

An Artifact Registry cleanup policy is documented regardless of where the measured
image size lands. Cleanup policies are not among Artifact Registry's three
enumerated billable items; that is an inference from the enumeration rather than a
stated exclusion, and it is recorded as an inference.

### 7. What this plan does not establish

Stated in the document itself, not left for a reader to find:

- **No step has been executed.** The runbook is untested by construction (BR32.12).
- **The site's real capacity ceiling is not measured.** 2,684 renders a month is
  derived from the evidence file's 400 KB per render, which is a render *before*
  BR32.6 moves static output and media to Cloud Storage. The post-BR32.6 figure —
  the bytes the HTML document alone costs — is unmeasured and is an open item owned
  by U10 under BR32.2. The plan uses the conservative number and no other.
- **The Firestore and Cloud Storage adapters have never run against the real
  services** (CA-5). They pass the port conformance suite, which proves they satisfy
  the port, not that they work.
- **Firestore's free quota has no stated region restriction** on current pages,
  unlike Cloud Storage's. That absence was not affirmatively confirmed for non-US
  locations and is treated as unverified.
- **That a Secret Manager replication policy cannot be changed after creation is
  unverified**, and it reached this document as an **undated assertion written from
  memory rather than a figure read off a source** — in a document whose own BR32.1
  requires a `source_url` and `source_date` on every figure. § 2 builds its "no
  undo" advice on it; the evidence file records only how replication counts against
  the active-version allowance. Flagged, with its provenance, rather than relied on
  for a zero.
- **Cloud Run's default CPU size is not carried by the evidence file.** BR32.25
  therefore *pins* 1 vCPU rather than defending a default, and § 3's row records the
  default as unverified instead of asserting it — the same discipline, applied
  immediately rather than after the fact.
- **No data-state rollback, and the free tier cannot supply one (BR32.18).**
  Firestore **PITR, Backup, Restore and Clone** have **no free usage at all**, so
  they are excluded by the hard zero-cost target rather than merely unconfigured.
  This topology has code rollback and no data rollback. Anyone who needs the
  second must decide to leave the free tier; it is a priced capability, and the
  price is the whole of what is being traded away here.
- **No Cloud Build, and therefore no Cloud Build cost line.** Removed rather than
  annotated, because its zero depended on a promotional allowance the site owner's
  constraint excludes (BR32.16). Images are built on the developer machine and
  pushed, which § 5 now carries as a numbered step with its IAM role and its
  verification.
- **No observability is provisioned.** The operation phase is skipped in this
  workflow's composed scope, so the Cloud Logging line covers the default log sink
  only, and BR32.22 exists to stop an operator buying an audit trail by raising
  retention.
- **The cache refresh model is a dependency, not a decision made here.** BR32.21
  records what this plan's Firestore arithmetic requires and hands it to
  `u4-content-core`; this unit does not change BR24.1 or the cache.
- Figures were fetched **2026-09-24**; Google may change allowances with 30 days'
  notice.

## Assumptions & Open Questions

- **[open]** Which of the three eligible regions to use. All three satisfy every
  constraint; the choice is a latency preference and is left to the operator rather
  than decided here.
- **[open]** The Artifact Registry line stays `pending` until U10 builds. The plan
  is not complete while it is unfilled (BR32.2).
- **[open]** The post-BR32.6 bytes per render, which set the capacity ceiling in
  BR32.19. Owned by U10 under the same rule as the image sizes.
- **[resolved, as a stated gap]** Whether `max-instances` 2 applies to the frontend
  as well as the backend. It does, and the second application rests on BR32.20
  rather than BR32.17. The question behind it — whether 2 + 2 bounds the shared pool
  — is answered **no** by BR32.26: the allowance is a sum and the cap is a rate. The
  gap is stated; no unenforceable cap was invented to cover it.
- **[resolved]** Cloud Run instances run at 1 vCPU. Formerly a bare assumption under
  every vCPU figure in this document; now **BR32.25**, with a `ConfigurationSetting`
  row and the numeric consequence of raising it.
- **[assumption]** Class B operations (50,000/month) will not be the binding
  constraint. HTML5 video range requests each count as a separate Class B operation,
  so a single video view can cost many. At the expected traffic this holds; it is the
  quietest overage path in the topology and it is named here for that reason.
- **[assumption]** The published-document cache refresh is **lazy on request and
  synchronous** (BR32.21). Every Firestore read figure in this document depends on
  it, and so does whether BR24.1's 5-second publish-visibility window bounds what is
  actually served. It is stated as an assumption because the cache belongs to
  `u4-content-core`; the dependency is handed over rather than decided.
