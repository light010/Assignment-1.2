# Functional Specification — U5 `media`

**Unit:** `u5-media` · **Kind:** `library` · **Components:** `MediaIntake`, `MediaDelivery`

**Upstream:** `construction/functional-design/functional-spec.md` (the end-to-end flows
this unit participates in), companion artifacts `entities.md` and `rules.md`,
`inception/contract-design/contract-summary.md` §§ C1, C2, C4,
`inception/units-generation/unit-of-work.md` § *U5 — media*,
`inception/domain-design/decisions.md` ADR-002, ADR-004.

How each of this unit's operations behaves end to end. Entity shapes are in
`entities.md`; business rules carry `BR` ids in `rules.md`; this document is the flow
that binds them.

**The standard these three files must meet:** a developer implements this unit from
them without re-reading `madhavi-tripathi/`. Every point where a reader would have to
go back is a defect.

## What this unit is, and what it is not

`MediaIntake` decides **what may enter**. `MediaDelivery` decides **what may leave, and
to whom**. They are one unit because they share `AssetStore` and the asset metadata
shape; they are two components because one is input validation over the system's
largest untrusted-input surface and the other is access control (ADR-004).

This unit is a **library**. It owns no route, no middleware, no error envelope and no
HTTP status construction. `U6 http-api` mounts the routes, runs the origin and CSRF
middleware ahead of the upload operation, and maps this unit's raised exceptions to
statuses through the single four-member taxonomy. This unit **raises**; it does not
respond.

**Acknowledged trade-off, carried from `unit-of-work.md`.** ADR-004 separated the two
components partly so a defect in one would not be reviewed in the same breath as the
other. Grouping them into one unit preserves the component boundary but **not** that
review-cadence separation: both hazard surfaces land and pass a merge gate together.
Accepted deliberately. The mitigation is that each hazard keeps its own per-branch
tests and its own 100% scoped coverage floor, so the gate still distinguishes them even
though the review does not.

## Cross-cutting behaviour inherited by this unit

**Error taxonomy.** This unit raises `Invalid` (→ 400, carrying `issues` when it has
field-level detail), `TooLarge` (→ 413), `NotAuthorized` (→ 403) and `Conflict`
(→ 409, unused on these paths). Anything else becomes **503, not 500**, with
`logger.exception()`. The envelope is produced by `U6 http-api`'s exception handlers,
**never constructed here**. Cancellation is the one status outside the taxonomy — see
§ *Cancellation and the 499*.

**Async.** Operations are `async`. The SQLite and filesystem adapters wrap their
synchronous drivers in `anyio.to_thread.run_sync` **inside the adapter**; nothing in
this unit calls a blocking driver directly. Two places in this unit are CPU-bound
rather than I/O-bound — the header parsers (BR6.4–BR6.6) over a buffered image, and
Pillow's variant generation (BR6.23) — and both must be kept off the event loop by the
same mechanism, because event-loop blocking is invisible to every check on the merge
gate.

**Wire format.** `camelCase`, frozen. One conversion point: the shared Pydantic base
with `alias_generator=to_camel` and `populate_by_name=True`.

**No cache lives here.** See `rules.md` § *Consumed from `ContentAuthority`*. The
published document this unit reads on every non-public request is served from
`ContentAuthority`'s cache (BR7.1, BR7.2). A second cache in this unit would miss the
publish invalidation and leave an unreferenced asset public — an authorization defect.

## Ports this unit uses

| Port | Contract | Operations used | Notes |
|---|---|---|---|
| `AssetStore` | C4, owned by U2 | `put`, `get`, `get_range`, `head`, `delete` | `get_range` is **in** the port. Loading a whole video to serve one range is precisely what the port exists to avoid |
| `ContentStore.asset_metadata` | C2, owned by U2 | `register`, `remove`, `read` | Row-shaped, which is why it lives in `ContentStore` |
| `ContentAuthority` published read | U4 `content-core` | published document, serialised | Served from **its** short-lived cache. This unit does not cache |

---

## Derived views

**These two sections are derived, not authoritative.** The entity relationships are
derived from `entities.md` § *Source of truth*; the rules summary is derived from
`rules.md` § *Source of truth*. Where a derived view and its source disagree, **the
source governs** and the disagreement is a defect in this file.

### Entity relationships (derived from `entities.md`)

```mermaid
erDiagram
    ASSET {
        string  assetKey    PK "uuid4 dot ext; same pattern gates the serving route"
        string  filename       "user filename, truncated to 200 chars, display only"
        enum    mediaType      "one of seven; VALIDATED from bytes, not declared"
        integer byteSize       "at least 1; this object only, not the ceiling sum"
        integer width          "nullable; images only; 1 to 40000"
        integer height         "nullable; images only; 1 to 40000"
        string  createdAt      "ISO-8601 UTC instant"
        string  derivedFrom FK "nullable; assetKey of the original; null for an original"
    }
    ASSET_OBJECT {
        string  key         PK "AssetStore; holds the bytes"
        integer size           "returned by head; drives Content-Length"
        string  etag           "returned by head; emitted, but no 304 path"
        enum    mediaType      "held independently; NOT authoritative for the response"
    }
    CONTENT_DOCUMENT {
        string documentId   PK "singleton; owned by u4-content-core"
        string published       "the serialised published document scanned by BR7.4"
        string draft           "never scanned; scanning it would be an authz defect"
    }
    ASSET   ||--o{ ASSET            : "variant_of, via derivedFrom"
    ASSET   |o--o| ASSET_OBJECT     : "bytes_of, two stores, no shared transaction"
    CONTENT_DOCUMENT }o--o{ ASSET   : "referenced_by, literal substring, unenforced"
```

**Text fallback, in case the diagram does not render.** Three boxes and three edges.

- **`ASSET`** — this unit's own entity (ENT-6), the metadata row in
  `ContentStore.asset_metadata`. Key `assetKey`. Eight fields: `assetKey` (PK),
  `filename`, `mediaType`, `byteSize`, `width`, `height`, `createdAt`, `derivedFrom`
  (FK to `ASSET.assetKey`).
- **`ASSET_OBJECT`** — the bytes in `AssetStore`, keyed by the same string. Carries
  `size`, `etag` and its **own** copy of the media type.
- **`CONTENT_DOCUMENT`** — the singleton owned by `u4-content-core`. Only its
  `published` side is ever scanned.

Edges:

1. **`ASSET` → `ASSET`, many-to-one, via `derivedFrom`.** A variant points at its
   original; an original points at nothing. **Depth is exactly one** — a variant is
   never itself a parent.
2. **`ASSET` ↔ `ASSET_OBJECT`, zero-or-one to zero-or-one, via the key.** Deliberately
   **not** one-to-one: they are two stores with **no shared transaction**, so either
   side can exist without the other, and that state is an orphan (BR6.24). The media
   type is held on **both** sides and **only the `ASSET` side is authoritative** for the
   served `Content-Type` (BR7.18).
3. **`CONTENT_DOCUMENT` ↔ `ASSET`, many-to-many, optional, unenforced.** The link is a
   **literal substring** — `/api/media/<assetKey>` appearing anywhere in the serialised
   **published** document (BR7.4). It is **not a foreign key in either direction**: a
   document may legally reference a key no `ASSET` has, and an `ASSET` may be referenced
   by nothing. **This edge is the entire public-access decision.**

### Rules summary (derived from `rules.md`)

| Rules | Subject | Component | Requirement | Hazard |
|---|---|---|---|---|
| BR6.1–BR6.3 | What is accepted; the type→extension map; key derivation | `MediaIntake` | FR6.1 | — |
| **BR6.4–BR6.10** | **Byte-signature typing, endianness and field order** | `MediaIntake` | **FR6.2** | **yes** |
| BR6.11–BR6.13 | Per-kind ceilings; the advisory 51 MB pre-check; zero-byte rejection | `MediaIntake` | FR6.3 | — |
| BR6.14–BR6.22 | The WebVTT validator, eight reject conditions | `MediaIntake` | FR6.4 | — |
| BR6.23 | Server-side variant generation; the retired verification surface | `MediaIntake` | FR6.5 | — |
| BR6.24–BR6.25 | Orphan-free failure; cleanup never masks; seven cancellation points → 499 | `MediaIntake` | FR6.6 | — |
| *BR7.1–BR7.2* | *The published-document cache — **consumed**; declared and owned by `ContentAuthority` in U4* | *`ContentAuthority`* | *FR7.6 → discharged by U4* | — |
| BR7.3 | Key validation, checked first, before any storage access | `MediaDelivery` | FR7.1 | — |
| **BR7.4–BR7.7** | **Asset visibility: the substring rule and its three preserved consequences** | `MediaDelivery` | **FR7.2** | **yes** |
| BR7.8 | Every denial is 404, never 403 | `MediaDelivery` | FR7.3 | — |
| **BR7.9–BR7.17** | **Range handling, all seven branches, plus the 416 and 206 shapes** | `MediaDelivery` | **FR7.4** | **yes** |
| BR7.18 | The seven protective headers; `Content-Type` from the metadata row | `MediaDelivery` | FR7.5 | — |
| BR25.1 | This unit holds no cache of its own | `MediaDelivery` | **no FR** (NFR8) | — |
| BR25.2 | CPU-bound parsing and variant generation stay off the event loop | `MediaIntake` | **no FR** (`team.md`) | — |

**43 rules declared. 20 are hazard rules** — `BR6.4–BR6.10` (7), `BR7.4–BR7.7` (4)
and `BR7.9–BR7.17` (9), the three rows marked **yes** above — each needs a test per
enumerated branch and falls inside the 100% scoped coverage floor. **BR25.1 and
BR25.2 trace to no FR** and belong in the traceability `reverse` array, not in
`coverage`. **`BR7.1`–`BR7.2` are shown above but are NOT declared here**: they are
declared and owned by `ContentAuthority` in U4, this unit consumes the cache they
describe, and this unit claims no part of `FR7.6`.

> **Corrected at review (R-01).** This derived view said **26**, as did `rules.md`
> in two places; the yaml source of truth carries `hazard: true` on exactly
> **20** rules. The number decides what the merge gate demands, because `team.md`
> § *Testing Posture* puts a 100% branch-coverage floor on hazard modules.

---

# `MediaIntake` — the upload operation

`POST /api/upload`. Origin and owner session are enforced by `U6 http-api` ahead of
this operation (BR3.1, BR3.3–BR3.5, FR6.7); this unit begins with an authenticated
owner and a verified origin.

## The ordered admission sequence

The order determines which status a multiply-invalid upload receives, so it is
specified rather than implied.

| # | Check | On failure | Rule |
|---|---|---|---|
| 1 | Declared `content-length` over the pre-check ceiling — **51 MB (53,477,376 bytes)**. **A request with no `content-length` header yields 0 and passes** | `TooLarge` → **413** | **BR6.12** |
| 2 | Read the multipart body | — | — |
| 3 | Missing file, non-file field, or **zero-byte** file | `Invalid` → **400** | **BR6.13** |
| 4 | Captions MIME coercion, if it applies | *(not a rejection)* | **BR6.2** |
| 5 | Determine the kind **from the file's own bytes** | `Invalid` → **400** | **BR6.4–BR6.10** |
| 6 | The resulting type is one of the seven accepted | `Invalid` → **400** | **BR6.1** |
| 7 | Per-kind ceiling, applied to the **sum** of the original and every derived file | `TooLarge` → **413** | **BR6.11** |
| 8 | For `text/vtt`, the eight WebVTT reject conditions | `Invalid` → **400** | **BR6.14–BR6.22** |
| 9 | Generate responsive variants **in Python** | — | **BR6.23** |
| 10 | Write the original and each variant through `AssetStore` | *(failure → cleanup)* | **BR6.24** |
| 11 | Register metadata through `ContentStore.asset_metadata` | *(failure → cleanup)* | **BR6.24** |
| 12 | Return `{url, filename, sources[]}` | — | **BR6.23** |

**Step 1 is advisory and step 7 is authoritative (BR6.12).** Both are required.
Reproducing only step 1 leaves the cap unenforced; reproducing only step 7 changes
*when* the rejection happens — after buffering rather than before. The two numbers do
not agree and are preserved as they are: see `rules.md` § *The 51 MB / 50-10-1 MB
inconsistency*.

**Step 4 happens before step 5, and does not decide acceptance.** The coercion
(BR6.2) only rewrites a *declared* type so that a browser-supplied `text/plain` or
`application/octet-stream` reaches the VTT validator instead of failing at BR6.1. The
bytes still decide (step 5 / step 8); the coercion decides only *which validator the
bytes are shown to*.

**Step 7's ceiling is a sum, not a per-file limit.** `video/*` → 50 MB, `text/vtt` →
1 MB, everything else → 10 MB, where `MB = 1024 * 1024` — so 52,428,800 / 1,048,576 /
10,485,760 bytes (BR6.11). Because it is a sum, and because step 9 now runs
server-side, **variants count against it**: an original at 9.8 MB whose variants add
0.4 MB is rejected at 10 MB where, in the source, only the 9.8 MB original was ever
weighed. This is a real consequence of FR6.5 and is stated here rather than discovered
at the gate.

## Byte-signature typing — the decision procedure (FR6.2, hazard)

> **Normative text is `rules.md` BR6.4–BR6.10.** The procedure below restates it as a
> flow. Where the two could be read differently, `rules.md` governs.

The three image parsers are **simultaneously the dimension extractor and the format
validator**. Returning no dimensions **is** a rejection. A port must reproduce the same
**accept/reject decision**, not merely the same dimensions on files that are accepted.

> **PNG and JPEG are big-endian. EVERY WebP field is little-endian. JPEG stores HEIGHT
> BEFORE WIDTH.** The source inherits big-endian defaults from JavaScript's
> `DataView`. Python's `int.from_bytes` has **no default to inherit**, so **every read
> must be transcribed individually with its byteorder stated**.

### How many bytes are read is itself a rule (BR6.9)

| Kind | Bytes read into memory |
|---|---|
| `image/png`, `image/jpeg`, `image/webp` | **the ENTIRE file** |
| `text/vtt` | **the ENTIRE file** |
| `application/pdf`, `video/mp4`, `video/webm` | **the first 32 bytes only** |

A 10 MB image is fully buffered; a 50 MB video is not. This is why the per-kind
ceiling for video can be five times the image ceiling without a five-times memory cost.

### PNG (BR6.4) — reject unless all hold

1. length **>= 33** bytes;
2. bytes **0–7** are exactly `137 80 78 71 13 10 26 10` (`\x89PNG\r\n\x1a\n`);
3. bytes **12–15** decode to `IHDR`.

Then:

| Quantity | Bytes | Read | Byte order |
|---|---|---|---|
| `width` | **16–19** | unsigned 32-bit | **BIG-ENDIAN** |
| `height` | **20–23** | unsigned 32-bit | **BIG-ENDIAN** |

Bytes **8–11** — the IHDR chunk length — are **never checked**. Everything after byte
23 is ignored.

### WebP (BR6.5) — reject unless all hold

1. length **>= 30** bytes;
2. bytes **0–3** decode to `RIFF`;
3. bytes **8–11** decode to `WEBP`;
4. `uint32_le(bytes[4:8]) + 8 <= len(bytes)` — the **LITTLE-ENDIAN** RIFF size field
   plus the 8-byte RIFF header must not exceed the actual buffer. **This is the check
   that rejects truncated files.**

Bytes **12–15** then select one of exactly three sub-formats. **Anything else leaves
width and height at 0, which is a rejection at BR6.7** — there is no fourth branch and
no fallthrough that accepts.

| Sub-format | Precondition | `width` | `height` |
|---|---|---|---|
| **`VP8X`** (extended) | — | `1 + bytes[24] + (bytes[25] << 8) + (bytes[26] << 16)` — 24-bit **LITTLE-ENDIAN**, **minus-one encoded** | `1 + bytes[27] + (bytes[28] << 8) + (bytes[29] << 16)` — same |
| **`VP8L`** (lossless) | `bytes[20] == 0x2f` (the VP8L signature byte) | `1 + bytes[21] + ((bytes[22] & 0x3f) << 8)` — packed 14-bit | `1 + (bytes[22] >> 6) + (bytes[23] << 2) + ((bytes[24] & 0x0f) << 10)` — packed 14-bit |
| **`VP8 `** (lossy — **trailing SPACE in the four-character code**) | `bytes[23] == 0x9d && bytes[24] == 0x01 && bytes[25] == 0x2a` (3-byte start code) | `uint16_le(bytes[26:28]) & 0x3fff` — **LITTLE-ENDIAN**, low 14 bits | `uint16_le(bytes[28:30]) & 0x3fff` — **LITTLE-ENDIAN**, low 14 bits |

The `& 0x3fff` masks off the 2-bit scaling field in each 16-bit value. The `VP8 `
four-character code's trailing space is part of the code — comparing against `VP8`
matches nothing, and comparing with a strip or a prefix test matches `VP8L` and `VP8X`
as well, which selects the wrong branch on a valid file.

### JPEG (BR6.6) — a marker-segment walk, not a fixed-offset read

Reject immediately unless length **>= 4** and `bytes[0] == 0xff && bytes[1] == 0xd8`
(SOI). Then from `position = 2`:

| Step | Condition | Action |
|---|---|---|
| 1 | `bytes[position++] != 0xff` | **reject** — marker desynchronised |
| 2 | `bytes[position] == 0xff` | skip fill bytes: `position += 1`, repeat |
| 3 | — | `marker = bytes[position++]` |
| 4 | `marker == 0xd9` (EOI) **or** `marker == 0xda` (SOS) **or** `position + 2 > len(bytes)` | **break** — **not a rejection**; falls through to the final gate |
| 5 | `marker == 0x01` (TEM) **or** `0xd0 <= marker <= 0xd7` (RST0–RST7) | **continue** — standalone markers, no length field |
| 6 | — | `length = uint16_be(bytes[position:position+2])` — **BIG-ENDIAN** |
| 7 | `length < 2` **or** `position + length > len(bytes)` | **reject** — malformed or truncated segment |
| 8 | `marker` ∈ `{0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf}` | if `length < 8` → **reject**; else **`height = uint16_be(bytes[position+3 : position+5])`**, **`width = uint16_be(bytes[position+5 : position+7])`**, both **BIG-ENDIAN**, then **break** |
| 9 | otherwise | `position += length`, loop while `position + 3 < len(bytes)` |

Two traps, both silent:

- **The SOF list deliberately EXCLUDES `0xc4` (DHT), `0xc8` (JPG) and `0xcc` (DAC).**
  They share the `0xcN` range and are not frame headers. Including them reads a
  Huffman table as if it were a frame header and produces arbitrary dimensions.
- **Height is at offset +3, width at offset +5.** A transposition here is a silent bug
  that shows only on non-square images — every square test fixture passes.

Step 4 ending the walk is **not** a rejection: a file whose markers run out before a
SOF is reached leaves width and height at 0, and BR6.7 is what rejects it. The
distinction matters because it is the difference between one rejection path and two.

### Non-image signatures (BR6.9)

| Kind | Check |
|---|---|
| `video/mp4` | bytes **4–7** decode to `ftyp` |
| `video/webm` | bytes **0–3** are `0x1a 0x45 0xdf 0xa3` (EBML) |
| `application/pdf` | the file begins with `%PDF-` |
| `text/vtt` | the eight reject conditions, BR6.14–BR6.22 |

The PDF check is **five bytes** and there is **no polyglot detection**. That is
preserved behaviour; the serving CSP (BR7.18 —
`Content-Security-Policy: default-src 'none'; sandbox`) plus the non-root container
user is what contains it, which is why both are practice rather than preference.

### The final gate (BR6.7) — applied identically to all three image formats

Accept only if **all** hold: `width > 0`; `height > 0`; `width <= 40000`;
`height <= 40000`; `width * height <= 100000000`. Otherwise **reject**.

This is the **decompression-bomb defence**, and it is reached **without decoding a
single pixel**. The pixel caps must be enforced from **header data before any decode**,
or the defence is lost. In particular it must run **before** step 9's Pillow call: the
whole point is that a 50,000 × 50,000 PNG never reaches a decoder.

### Do not substitute an imaging library (BR6.10)

A library produces a **different accept/reject set**. It accepts formats this code
rejects; more importantly it may **accept malformed files this walker rejects** at
steps 1 and 7, and **reject unusual-but-valid files this walker accepts**. Pillow is
used for **variant generation** (BR6.23), *after* acceptance; it is not the acceptance
test. This is the one place where the project's reuse-first rule (C4) is deliberately
not applied, and the reason is recorded so it is not "corrected" later.

## WebVTT validation (BR6.14–BR6.22)

Eight independent reject conditions, each needing its own test. The full text is in
`rules.md`; the flow is:

1. **Strict UTF-8 decode.** Invalid UTF-8 throws → reject. Not lenient, no replacement
   characters (BR6.14).
2. **Normalise** — strip a leading BOM, convert `\r\n` and bare `\r` to `\n` (BR6.14).
   Everything below operates on the normalised text.
3. **Header gate** — `/^WEBVTT(?:[ \t][^\n]*)?\n/`. **A file that is exactly `WEBVTT`
   with no trailing newline FAILS** (BR6.15).
4. **Whole-file scans** — reject on any `\u0000` (BR6.16); reject on any match of
   `/<(?:script|iframe|object|embed|svg|style)\b/i` (BR6.17). Both apply to the whole
   file, not to cue payloads only.
5. **Block split** on `/\n[ \t]*\n/` after trimming. Reject if there are no blocks, or
   if **block 0 contains `-->`** (BR6.18).
6. **Per block from index 1** — a block matching `/^NOTE(?:[ \t\n]|$)/` is **skipped
   entirely**. Otherwise the timing line is at index `0 if '-->' in lines[0] else 1`:
   **a cue identifier line is allowed before the timing line, and nowhere else**
   (BR6.19).
7. **Timing line must match exactly** (BR6.20):
   ```
   /^((?:\d{2,}:)?\d{2}:\d{2}\.\d{3})[ \t]+-->[ \t]+((?:\d{2,}:)?\d{2}:\d{2}\.\d{3})(?:[ \t]+.*)?$/
   ```
   An optional `HH:` of **two or more** digits, `MM:SS.mmm` with **exactly three**
   decimal places, `-->` with **at least one space or tab on each side**, optional
   trailing cue settings.
8. **`end > start` strictly** (BR6.21). Times parse by splitting on `:` and taking
   seconds, then minutes, then hours (hours defaulting to 0); the parse yields a value
   only if hours is finite **and** `seconds < 60` **and** `minutes < 60`, otherwise
   **not-a-number**. Because the comparison is `end > start`, **a not-a-number on
   either side makes the comparison false and rejects the file** — the error path and
   the zero-duration path are the same branch. A **zero-duration cue is rejected**.
   Every cue's payload — `lines[index+1:]` joined and trimmed — must be **non-empty**.
9. **At least one cue** (BR6.22). A valid header with no cues at all is rejected. **Any
   single block failing any condition rejects the whole file.**

The not-a-number behaviour in step 8 is the one that a "cleaner" port loses: an
implementation that validates the time components separately and raises on an
out-of-range minute produces a *different* error at a *different* point, and one that
coerces them silently accepts `99:99.999`.

## Variant generation (BR6.23, FR6.5, D24)

Responsive image variants are generated **server-side in Python** from the uploaded
original, using Pillow, **after** acceptance. The browser no longer prepares them.

**The entire "verify the browser's prepared variants" surface disappears** rather than
being ported: the variant envelope check, the WebP-only rule, the 1600-pixel ceiling
and the aspect-ratio tolerance formula. Their four error strings are recorded as
**deliberately retired** in BR10.9 — `The prepared image sizes could not be verified.
Please choose the photo again.`, `Prepared photo sizes must use WebP.`, `Prepared photo
sizes must be no larger than 1600 pixels.`, `Prepared photo sizes must match the
original framing.`. **Do not re-create the checks in order to keep the strings alive.**

Three properties this unit must hold:

- **Each variant is a full `Asset` in its own right** — its own `<uuid4>.<ext>` key,
  its own metadata row, its own `byteSize`, with `derivedFrom` set to the original's
  `assetKey` (`entities.md` § ENT-6).
- **Variant dimensions must satisfy `imageSource`'s `1..16000`**, not only BR6.7's
  `1..40000`, because the variants are written into the upload response's `sources[]`
  and from there into the content document. Targets at or below **1600 pixels** — the
  source's own retired ceiling — keep them well inside. See `entities.md` § *Assumptions*
  for the open note on the two bound-sets.
- **The sum of the original and every variant is what BR6.11's ceiling weighs**
  (step 7 above).

**The response changes for every upload.** BR6.23: `sources[]` is populated only when
variants exist, and in the source it was **empty for any upload the browser did not
pre-process**. Moving generation server-side changes that response for **every**
upload. A recorded U1 fixture of the source's `sources[]` is therefore **not** a parity
target for the ported response; every other field of the upload response still is.

## Orphan-free failure (BR6.24, BR6.25, FR6.6)

**Bytes and metadata are two separate non-transactional writes.** There is no
transaction covering an `Asset` and none can be manufactured: `AssetStore` and
`ContentStore` are different stores with different adapters (`entities.md` § *The two
stores*).

The obligation is therefore a **compensating** one, and it is explicit about its own
limits:

1. **Track every key written so far** — each `AssetStore.put` and each
   `asset_metadata.register`, in order, as the sequence proceeds.
2. **On any exception**, delete every tracked key from **both** stores.
3. **Use a gather-all-results primitive**, so **one failed delete does not abort the
   rest**. A sequential loop that raises on the first failed delete leaves the
   remainder orphaned, which is the defect this rule exists to prevent.
4. **Cleanup is explicitly best-effort.** It holds only while the handler reaches its
   cleanup path. A process kill between the two writes leaves an orphan, and **nothing
   reclaims it** — there is no orphan collection anywhere (BR7.7c). Stated plainly so
   a reader does not mistake best-effort for guaranteed.
5. **Cleanup never masks the original error** (BR6.25). The response reports why the
   **upload** failed, not why the **cleanup** did. A cleanup failure is logged; it never
   becomes the raised exception and never rewrites the status.

## Cancellation and the 499

**Cancellation is checked at seven points through the write sequence and maps to 499**
(BR6.25). The seven checkpoints bracket the expensive and the irreversible steps: the
work is abandoned as early as the client's disconnect is observable, and every key
written before the abandonment goes through the same cleanup path as a failure.

499 is **outside** the four-member exception taxonomy (BR10.4). It is not a
`NotAuthorized`, a `Conflict`, a `TooLarge` or an `Invalid`, and it must not fall
through to the 503 catch-all. `U6 http-api` maps it explicitly; this unit signals it.

> **[carried hedge]** The source contains **two** cancellation literals —
> `Upload cancelled.` and `Upload cancelled. Your previous file is unchanged.` The
> knowledge base documents only the longer one, attached to the `AbortError` catch; the
> shorter appears to belong to the early `checkCancelled()` path. **Which 499 carries
> which sentence is unconfirmed**, and BR6.25 does not say the sentence is the same at
> all seven checkpoints. Resolve against the recorded source fixtures (**U1**) before
> asserting either in a parity test.

## Error strings this unit's conditions trigger

The strings are **product copy** and fall under the parity rule (FR10.2). They are
owned by `HttpApi` (BR10.7) and composed there; this unit raises the condition. They
are reproduced here so an implementer of this unit can see what each rejection
produces, **verbatim**:

| Situation | Status | String |
|---|---|---|
| Media denied or missing | 404 | `Not found` |
| Media read threw | 503 | `File temporarily unavailable` |
| Upload: missing or zero-byte file | 400 | `Choose a non-empty file.` |
| Upload: unsupported or unverifiable format | 400 | `The file format could not be verified. Please choose another file.` |
| Upload: caption file invalid | 400 | `Choose a UTF-8 .vtt file beginning with WEBVTT and containing valid timed captions.` |
| Upload: declared length over the pre-check | 413 | `Choose a video smaller than 50 MB, a photo / PDF smaller than 10 MB, or captions smaller than 1 MB.` |
| Upload: measured sum over the per-kind cap | 413 | `Choose files totaling less than ${limit} MB.` — interpolated with the numeric cap |
| Upload cancelled | 499 | `Upload cancelled. Your previous file is unchanged.` |
| Upload threw | 503 | `Upload failed. Please try again; your form changes are safe.` |

Two things to notice. **The unverifiable-format string is one string for three
different failures** — an unsupported type (BR6.1), a failed signature walk
(BR6.4–BR6.6) and a failed final gate (BR6.7) are indistinguishable to the owner, which
is why a big-endian WebP read looks to her exactly like a corrupt file. And **`Not
found` and `File temporarily unavailable` carry no trailing full stop** while every
other string does; that is the source's inconsistency and it is preserved.

---

# `MediaDelivery` — the serving operation

`GET | HEAD /api/media/{key}`. Unauthenticated at the transport layer; this unit makes
the access decision itself (BR3.1 — every operation authorises itself).

## The ordered sequence

| # | Step | Outcome | Rule |
|---|---|---|---|
| 1 | Key must match `/^[a-f0-9-]+\.(jpg\|png\|webp\|pdf\|mp4\|webm\|vtt)$/` | no match → **404**, **before any storage access** | **BR7.3** |
| 2 | Obtain the serialised published document from `ContentAuthority` (served from **its** cache) | — | **BR7.1, BR7.2** |
| 3 | **Public iff the literal `/api/media/<key>` appears ANYWHERE in it** | public → skip step 4 entirely | **BR7.4** |
| 4 | Not public → identity lookup. Not the owner → **404, never 403** | — | **BR7.6, BR7.8** |
| 5 | Read the metadata row and the object's `head` (size, etag) | absent → **404** | **BR7.8, BR7.18** |
| 6 | `HEAD` → **200 with the full `Content-Length`**, returning **before any range parsing** | — | **BR7.9** |
| 7 | `GET` → the seven range branches | 200 / 206 / 416 | **BR7.10–BR7.17** |
| 8 | Emit the protective headers on every successful response | — | **BR7.18** |

**Step 3 before step 4 is load-bearing** (BR7.6). Public-ness is evaluated first and
the owner check is **short-circuited** when the asset is public, so a public asset
costs **no authorization lookup at all**, while every non-public request costs the full
published-document read *and then* an identity lookup. Reversing the order changes the
cost profile of the system's hottest path.

**Step 1 before step 2 is also load-bearing**, for a different reason: the key pattern
is the path-traversal defence as well as a well-formedness check, and the content
schema's `url` form is **more permissive** than it (`entities.md` § *Cross-unit shape
1*). A schema-valid `/api/media/../secret` must die at step 1, before any store sees
the string.

## The asset-visibility rule (FR7.2, hazard)

**An asset is publicly readable if and only if the literal string `/api/media/<key>`
appears ANYWHERE in the serialised published document** (BR7.4). Not "is referenced by
the `photo` field", not "appears in a known image slot" — **anywhere at all, including
inside free prose**: a `transcript` (up to 60,000 characters), a `description`, the
`bio`, the `intro`, the `notice`, or any of the nine editable copy blocks. The test is
a **substring scan over the serialised published document**.

### Why a structured field check is not equivalent

Every structured field that can hold a media reference is *itself part of the
serialised document*, so every reference a structured check finds, the substring scan
also finds. Writing **P** for the substring rule's public set and **S** for a
structured check's:

> **S ⊆ P, always. The inclusion is strict whenever any reference lives in prose.**

**A structured field check makes strictly fewer assets public.** Every image the owner
referenced from prose — a figure linked inside a description, an image embedded in a
transcript — **starts returning 404 to visitors**, on a site that renders normally in
every other respect.

The direction of that error is what makes it silent. Wrongly-private raises no security
alarm, writes no log line and fails no authorization test. The symptom is a 404 on one
image for one visitor on an otherwise perfect page, and the affected set is **exactly
the set nobody enumerated** — enumerating it is precisely what the structured check
declined to do. **A structured-field port passes every test written against the
structured fields**, serves the site correctly on every page a reviewer opens, and 404s
only those images.

The rule is **not elegant**; it is **the rule**. It is positional-string-based rather
than semantic, which means it silently changes meaning if the URL format ever changes —
a query string, a CDN prefix. **Do not "improve" it.**

Two properties were verified by the scan and need not be re-derived (BR7.5):

- **Prefix collisions are impossible.** The key pattern forces a `.`-extension suffix
  and a match requires `/api/media/` immediately followed by the *full* key, so
  `/api/media/0.webp` cannot match inside `/api/media/1230.webp`.
- **JSON escaping is not a problem.** Serialisation does not escape `/`. This is the
  one property of the serialised form this unit depends on; if it ever changed, **every
  asset in the system would become non-public simultaneously and silently**.

### Three consequences preserved, not fixed (BR7.7)

1. **Over-permission through prose** — pasting a draft-only image URL into a caption
   transcript publishes that image.
2. **Publication is indiscriminate** — publishing makes public *every* asset URL
   anywhere in the document, **including ones in sections toggled off** via
   `sections.*`. The visibility toggle hides the section from the page; it does **not**
   make its media private.
3. **No revocation and no cleanup** — removing a reference makes the asset non-public
   again on the next request, but neither the bytes nor the metadata row is ever
   deleted, and there is no orphan collection anywhere.

### Denial discloses nothing (BR7.8, FR7.3)

**Every denial is a 404, never a 403.** A malformed key, a missing metadata row,
missing bytes, and "exists but not public and you are not the owner" are
**indistinguishable** in the response. The route does not confirm the existence of
unpublished media. **A 403 anywhere on this path is a defect.**

## Range handling — all seven branches (FR7.4, hazard)

**The standards-compliant implementation is not the requirement; the existing one is.**
Each branch needs its own test.

### Branch 0 — `HEAD` (BR7.9, FR7.4.1)

`HEAD` **always** returns **200** with the **full** `Content-Length`, and **never**
returns 206 or 416 — **even where the equivalent `GET` would**. This is a deliberate
early return **before any range parsing**.

**`HEAD` and `GET` must not share range logic**, even though the source routes them to
the same function. The early return must be **structural** rather than incidental: an
HTTP framework that serves `HEAD` by running the `GET` handler and dropping the body
reproduces `GET`'s 206 and 416 exactly, which is the defect.

### The decision table for `GET`

Evaluated in this order. `size` is the object's byte length; `etag` is the object's
entity tag.

| # | Condition | Result | Rule |
|---|---|---|---|
| 1 | `If-Range` present and **not exactly equal** to `etag` | **Discard `Range`. Serve a full 200.** Exact string equality | **BR7.11** (FR7.4.2) |
| 2 | `Range` header absent or empty | Full **200** | **BR7.15**, final sentence |
| 3 | Trimmed value fails `/^bytes=(\d*)-(\d*)$/` — including any multi-range such as `bytes=0-1,5-6`, and including `bytes=-` with both groups empty | **416** | **BR7.12** (FR7.4.4) |
| 4 | `size` is not a safe integer, **or** `size < 1` — **any** range at all | **416** | **BR7.13** (FR7.4.5) |
| 5 | Suffix form `bytes=-N`: `N` must be a safe integer **> 0**; then `start = max(0, size - N)`, `end = size - 1`. **`N > size` yields the whole object as a 206 — not a 200** | **206** | **BR7.14** (FR7.4.6) |
| 6 | Explicit form `bytes=S-E`: **`start >= size` → 416**; **`end < start` → 416** | **416** | **BR7.15** (FR7.4.7) |
| 7 | Explicit form, otherwise: **`end = min(end, size - 1)` — an end beyond the object is SILENTLY CLAMPED** and served as 206. For `bytes=S-`, `end = size - 1` | **206** | **BR7.15** (FR7.4.7) |

The parser returns `{offset: start, length: end - start + 1}`.

**There is NO 304 path** (BR7.10, FR7.4.3). An `ETag` **is** emitted and
`If-None-Match` is **not honoured**. Every request is a **full transfer of the selected
byte range**, and combined with `Cache-Control: private, no-cache` nothing is cached.
**This is a deliberately preserved behaviour, not an omission to correct.** Adding a
304 path would satisfy the phrase "existing semantics" while silently changing what
visitors and video players receive. Note the asymmetry: `If-Range` **is** honoured
(branch 1) while `If-None-Match` is **not** — two conditional headers, two different
answers, and a port that handles "conditional requests" uniformly gets one of them
wrong.

**The asymmetry in branches 6 and 7 is intentional and must be reproduced:** a start
past the end is an error, an end past the end is not.

### Response shapes

| Status | Shape | Rule |
|---|---|---|
| **200** | Whole object. `Content-Length: <size>` | **BR7.18** |
| **206** | `Content-Range: bytes <offset>-<offset+length-1>/<size>`, `Content-Length: <length>`. Bytes read via **`AssetStore.get_range`**, never by loading the whole object and slicing | **BR7.17** |
| **416** | `Content-Range: bytes */<size>`, `Content-Length: 0`, null body — **but every other header from the success path is retained, including `Content-Type` and `ETag`**. It is not a bare error response | **BR7.16** |
| **404** | Denial, indistinguishable across all four denial causes | **BR7.8** |
| **503** | Storage unavailable. `File temporarily unavailable` | **BR10.7** |

**Ranged reads go through the port** (BR7.17, C4). `AssetStore.get_range(key, offset,
length)` exists precisely so that serving one range of a 50 MB video does not load
50 MB. An implementation that calls `get` and slices passes every correctness test and
fails the only property the port was created for.

### What breaks silently

A standards-correct range implementation is *more* correct and *differently* behaved.
**Video players change their buffering strategy when a 416 becomes a 200, or when a 304
appears where a full transfer was expected.** Nothing errors; playback just behaves
differently, on a device nobody tested.

## Protective headers (BR7.18, FR7.5)

Every successful media response carries, verbatim:

| Header | Value |
|---|---|
| `Content-Type` | **the metadata row's media type** — from the metadata store, **not** from the object store |
| `Cache-Control` | `private, no-cache` |
| `X-Content-Type-Options` | `nosniff` |
| `Content-Security-Policy` | `default-src 'none'; sandbox` |
| `Accept-Ranges` | `bytes` |
| `ETag` | the object's entity tag |
| `Content-Length` | the object's size |

**The two stores hold the media type independently** and agree only because they are
written from the same value at upload time. **Anything that syncs only one will serve
mismatched types.** `AssetStore.head` returns a `media_type` and this unit **discards
it** (`entities.md` § *Cross-unit shape 3*) — reading it would pass every test in which
the two agree, which is every test that does not deliberately desync them.

The CSP and `nosniff` are the containment for the five-byte PDF check with no polyglot
detection. They are not decoration.

---

## Testing obligations for this unit

Stated here because this unit carries three of the seven hazards and the coverage
floors differ by module.

- **Characterization tests come first for every hazard behaviour** and for the storage
  port: written from the **recorded source behaviour** (U1 fixtures) and observed to
  fail before the Python implementation of that behaviour exists. This is the affirmed
  `custom` methodology, and it is the only thing that catches a defect implemented from
  a misreading — a test written after the code from the same misreading is green.
- **U1 fixtures this unit depends on**, recorded from the running source app **before
  any Python is written** and **unrecoverable once it is retired**: the media route's
  status codes across public / draft-only / missing keys, and **byte-range responses
  across all six rejection branches**. This unit has a real dependency edge on U1, not a
  reference.
- **A test per enumerated branch**, under the **100% scoped coverage floor** for the
  hazard modules: 12 endianness reads (`rules.md` § *Endianness, restated as a per-read
  checklist*), 8 WebVTT reject conditions, 7 range branches plus the `HEAD` early return
  and the two response shapes, and the visibility rule's public/non-public/owner/
  non-owner matrix.
- **Named assertions, not landmarks.** A JPEG test that uses only square images cannot
  detect the height/width transposition; a WebP test that uses only `VP8X` cannot detect
  a `VP8 ` four-character-code comparison that strips the trailing space. Fixtures must
  be chosen against the branch, not against the format.
- **The gap tests.** Two behaviours are preserved *because* they are odd, and each needs
  a test that asserts the oddity so a later reader cannot mistake it for a bug: the
  51 MB pre-check against the 50/10/1 MB message (a 50.5 MB video must reach BR6.11, not
  BR6.12), and the absence of a 304 path (an `If-None-Match` matching the emitted `ETag`
  must produce a **full transfer**, not a 304).

## Assumptions & Open Questions

- **[disposition — the 51 MB open item, owned by this unit]** Preserved exactly, both
  numbers, with a test asserting the gap. Full reasoning in `rules.md` § *The 51 MB /
  50-10-1 MB inconsistency* and § *Assumptions & Open Questions*. Closed as
  **preserved**, not as **resolved**.
- **[open, owner U1 `source-fixtures`]** Which of the two cancellation literals each of
  the seven 499 checkpoints carries. Until the fixtures resolve it, no parity assertion
  on the cancellation sentence may be written as settled.
- **[CLOSED, owner U4 `content-core` — re-homed by `WORKING-RECORD.md` § 10a,
  Condition 1]** The published-document cache interval (BR7.2) is **set by U4 as
  `BR24.1`: 5 seconds, as a maximum** — a deployment may choose lower, never higher.
  It is a **security** parameter, not a tuning one, **because of this unit**: a
  stale cache means an asset the owner has just unreferenced **stays public for the
  cache lifetime**, which is an authorization defect on this unit's hottest path.
  This unit must not compensate by caching locally (`BR25.1`). `BR7.1` and `BR7.2`
  themselves are now **declared by U4** as well as owned there.
- **[assumption, this unit]** Variant target sizes stay at or below **1600 pixels**, so
  every generated variant satisfies `imageSource`'s `1..16000` as well as BR6.7's
  `1..40000`. The two bound-sets and the gap between them are recorded in `entities.md`
  § *Assumptions & Open Questions*; nothing outside this unit enforces the choice and no
  gate check asserts it.
- **[assumption, this unit]** Keeping the CPU-bound header parse and the Pillow variant
  generation off the event loop uses the **same** `anyio.to_thread.run_sync` mechanism
  the adapters use for blocking drivers. The team rule names the mechanism for
  *synchronous dependencies*; applying it to *CPU-bound own code* is an extension of it,
  recorded rather than assumed silently. Event-loop blocking is invisible to every check
  on the merge gate.
- **[assumption, carried from `frontend-components.md`]** Removing browser-side variant
  preparation changes no visitor-visible behaviour, because the same variant sizes are
  produced — just in Python. **If Pillow's output differs perceptibly from Canvas's,
  that is a parity question the DOM diff will not catch and the human pass must.** Stated
  again here because this unit is where the substitution happens.
- **[note]** `U6 http-api` maps **499** explicitly. It is outside the four-member
  taxonomy and must not fall through to the 503 catch-all. Flagged here because this unit
  is the only source of a 499 in the system.
- **[note]** Nothing in this unit requires a background worker, scheduler or queue
  consumer. Variant generation and failure cleanup both run inside the request that
  triggers them, and there is no orphan sweep because there is no deletion path.

## Sources

- `construction/functional-design/functional-spec.md` §§ *Upload — `POST /api/upload`*,
  *Serve media — `GET|HEAD /api/media/{key}`*, *Cross-cutting behaviour* — this unit's
  flows are the same flows, scoped and enumerated.
- `construction/media/functional-design/rules.md` — **normative for every `BR` id cited
  above**; the procedures here restate it and are subordinate to it.
- `construction/media/functional-design/entities.md` §§ *ENT-6 `Asset`*, *Cross-unit
  shape 1* (the `url` permissiveness asymmetry), *Cross-unit shape 3* (`AssetStore.head`
  returns a media type this unit discards), *Cross-unit shape 4* (the published document
  as one serialised string).
- `construction/functional-design/rules.md` § `HttpApi` BR10.4 (the four-member
  taxonomy), BR10.7 (the verbatim error strings), BR10.9 (the four retired strings).
- `inception/contract-design/contract-summary.md` §§ C1 (`/api/upload` and
  `/api/media/{key}` statuses and descriptions), C2 (`asset_metadata`), C4 (`AssetStore`,
  `get_range` **in** the port).
- `inception/requirements-analysis/requirements.md` FR6.1–FR6.7, FR7.1–FR7.5 (including
  FR7.4.1–FR7.4.7), NFR9, NFR11.
- `inception/domain-design/decisions.md` ADR-002 (the cache lives in `ContentAuthority`),
  ADR-004 (intake and delivery are separate components).
- `inception/units-generation/unit-of-work.md` § *U5 — media* — boundary, constraints,
  the acknowledged review-cadence trade-off, and `Realises: FR6, FR7.1–FR7.5, NFR11`.
- `aidlc/spaces/default/memory/team.md` §§ *Testing Posture* (the `custom` methodology,
  the recorded fixtures, the 100% hazard floor, the named-assertion rule), *Deployment*
  (the non-root user and the five-byte PDF check).
- `WORKING-RECORD.md` §§ 2 (D12, D24), 3 (FR6.2, FR7.2, FR7.4), 9 (the 51 MB item and
  the cancellation-literal item), 10a (Condition 1).
