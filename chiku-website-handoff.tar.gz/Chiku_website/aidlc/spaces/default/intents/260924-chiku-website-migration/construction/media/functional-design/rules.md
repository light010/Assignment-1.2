# Business Rules — U5 `media`

**Unit:** `u5-media` · **Kind:** `library` · **Components:** `MediaIntake`, `MediaDelivery`

**Upstream:** `construction/functional-design/rules.md` (the rule ids and their text),
`inception/requirements-analysis/requirements.md` FR6.1–FR6.7, FR7.1–FR7.6,
`inception/domain-design/components.md` (rule ownership),
`inception/contract-design/contract-summary.md` §§ C1 `/api/upload` and
`/api/media/{key}`, C2 `asset_metadata`, C4 `AssetStore`,
companion artifacts `entities.md` and `functional-spec.md`.

## How to read this document

Every rule here is something **an implementation could get wrong**. Rules the type
system already enforces are deliberately absent: "`mediaType` must be one of seven
values" is a schema constraint and lives in `entities.md`, not here.

`BR{n}.{m}` ids are **stable and unchanged**. The major number tracks the requirement
family — `BR6.*` are FR6 rules, `BR7.*` are FR7 rules. Ids are assigned once and do
not move; nothing in this unit-scoped file renumbers, merges or splits a rule from
`construction/functional-design/rules.md`.

**43 rules declared, of which 20 are hazard rules.** This is the densest unit in the
system and it carries **three** of the seven hazards:

| Rules | Hazard | Requirement | Hazard rules |
|---|---|---|---|
| **BR6.4–BR6.10** | Byte-signature typing | **FR6.2** | **7** |
| **BR7.4–BR7.7** | The asset-visibility rule | **FR7.2** | **4** |
| **BR7.9–BR7.17** | Range handling, branch for branch | **FR7.4** | **9** |
| | | **Total** | **20** |

> **Corrected at review (R-01): the count was stated as 26 in three places and is
> 20.** The three ranges above are the whole hazard set — 7 + 4 + 9 — and they are
> exactly the twenty rules carrying `hazard: true` in the yaml source of truth
> below. The count is load-bearing rather than cosmetic: `team.md` §
> *Testing Posture* puts a **100% branch-coverage floor** on hazard modules, so a
> developer sizing that floor against "26" would go looking for six hazard rules
> that do not exist. Only the three hazards this unit *owns* are counted — the
> WebVTT validator and the size ceilings are demanding, but they realise `FR6.4`
> and `FR6.3`, which are not `[hazard]` requirements.

Each hazard is specified **branch by branch** and carries an explicit **"What breaks
silently"** note, because by definition none of them fails loudly. Every hazard rule
needs a test per enumerated branch and falls inside the **100% scoped coverage floor**.

**Nothing here is designed.** Every rule is either preserved behaviour from
`madhavi-tripathi/` or a decision already recorded in the requirements, the component
catalogue, an ADR or `WORKING-RECORD.md` § 2.

**Rule index for this unit**

| Component | Rules | Count | Of which hazard |
|---|---|---|---|
| `MediaIntake` | BR6.1–BR6.25 | 25 | **BR6.4–BR6.10** (FR6.2) |
| `MediaDelivery` | BR7.3–BR7.18 | 16 | **BR7.4–BR7.7** (FR7.2), **BR7.9–BR7.17** (FR7.4) |
| *Subject to — consumed, declared by `ContentAuthority` (U4)* | *BR7.1–BR7.2* | *2, not counted above* | — |
| Unit-scoped, **trace to no FR** | BR25.1–BR25.2 | 2 | — |

**On ids.** Every `BR6.x` and `BR7.x` id is carried **verbatim** from
`construction/functional-design/rules.md`, which was written at workflow level to be
split per unit. This file is that split, not a rewrite: no id is renumbered, merged,
split or reused for a different rule. The `BR25.x` group is the unit-scoped allocation
(**U5 + 20**) reserved for rules that realise only an NFR or a team constraint and
**trace to no FR**; there are two, and both are listed in the traceability `reverse`
array with their reasons.

**Rules this unit is subject to but does not own.** BR3.3–BR3.5 (same-origin and CSRF
on mutations) discharge **FR6.7**, which `units-generation/traceability.json` assigns
to this unit, but they are owned by `HttpApi` and specified in
`construction/http-api/functional-design/rules.md`. This unit's upload operation is
enforced by them; it does not implement them. See `## Assumptions & Open Questions`.

**Structure of this document.** The fenced `yaml` block below is the **source of
truth**: it governs, and it is what downstream stages read. Each hazard rule's
`statement` carries its **full text**, branch by branch, because a hazard specified
branch by branch cannot be abbreviated without losing the branch and the branches are
the requirement. The prose sections after it carry the **rationale and the failure
mode** for each rule. **The prose must not contradict the block; where it appears to,
the block wins and the prose is a defect.**

---

## Source of truth

```yaml
source_of_truth: rules
stage: functional-design
unit: u5-media
kind: library
kind_note: >
  U5 media is a LIBRARY, not a service. U6 http-api is the only unit declaring
  service - there is exactly one deployed Python executable. media is embedded in it
  and is not independently deployable.
components: [MediaIntake, MediaDelivery]
rule_count: 43
authority: >
  This block is the source of truth and governs. Each hazard rule statement carries
  its FULL text, branch by branch. The prose sections below carry the rationale and
  the failure mode for each rule and must not contradict this block.
id_format: 'BR{group}.{seq}; source ids are FR{n} / FR{n}.{m} / NFR{n} as spelled in requirements-analysis'
hazards:
  - { requirement: FR6.2, rules: 'BR6.4-BR6.10', subject: byte-signature typing }
  - { requirement: FR7.2, rules: 'BR7.4-BR7.7',  subject: the asset-visibility rule }
  - { requirement: FR7.4, rules: 'BR7.9-BR7.17', subject: range handling, branch for branch }

rules:
  - id: BR6.1
    statement: 'Exactly seven media types are accepted, under one fixed, total type-to-extension map.'
    category: validation
    applies_to: MediaIntake
    trigger: 'An upload whose type has been determined from its bytes'
    logic: 'IF the validated type is not one of the seven THEN reject; ELSE store under the mapped extension'
    violation: 'Invalid -> 400, "The file format could not be verified. Please choose another file."'
    source: FR6.1
  - id: BR6.2
    statement: 'Captions MIME coercion: a declared captions upload with a .vtt filename and an empty or generic declared type is forced to text/vtt.'
    category: validation
    applies_to: MediaIntake
    trigger: 'Before byte inspection, on an upload declaring kind = captions'
    logic: 'IF kind = captions AND filename ends .vtt AND declared type is empty or one of text/vtt, text/plain, application/octet-stream THEN force text/vtt; ELSE use the declared type as-is'
    violation: 'None directly. Dropping the coercion makes most caption uploads fail at BR6.1'
    source: FR6.1
  - id: BR6.3
    statement: 'The stored extension derives from the validated media type, never from the filename; the key is <uuid4>.<ext>; the filename is kept for display, truncated to 200 characters.'
    category: calculation
    applies_to: MediaIntake
    trigger: 'On accepting an upload, and on creating each generated variant'
    logic: 'IF a type has been validated THEN ext := map[type], key := uuid4() + "." + ext, filename := user filename truncated to 200'
    violation: 'A filename-derived extension yields an unservable key; every request for it 404s with no error at write time'
    source: FR6.1
  - id: BR6.4
    statement: |
      PNG. Reject unless ALL hold: length >= 33 bytes; bytes 0-7 are exactly
      137 80 78 71 13 10 26 10 (\x89PNG\r\n\x1a\n); bytes 12-15 decode to IHDR. Then:
        width  = bytes 16-19, unsigned 32-bit, BIG-ENDIAN
        height = bytes 20-23, unsigned 32-bit, BIG-ENDIAN
      Bytes 8-11 (the IHDR chunk length) are NEVER checked. Everything after byte 23
      is ignored.
    category: validation
    applies_to: MediaIntake
    trigger: 'Byte-signature typing of an uploaded file'
    logic: 'IF any precondition fails THEN reject; ELSE read the two BIG-ENDIAN uint32s. Bytes 8-11 are never checked; everything after byte 23 is ignored'
    violation: 'Invalid -> 400. A wrong byteorder yields a huge number that then trips BR6.7'
    source: FR6.2
    hazard: true
  - id: BR6.5
    statement: |
      WebP. Reject unless ALL hold: length >= 30 bytes; bytes 0-3 decode to RIFF;
      bytes 8-11 decode to WEBP; and uint32_le(bytes[4:8]) + 8 <= len(bytes) - the
      LITTLE-ENDIAN RIFF size field plus the 8-byte RIFF header must not exceed the
      actual buffer (this is what rejects truncated files). Bytes 12-15 then select
      one of exactly three sub-formats; ANYTHING ELSE leaves width/height at 0 and is
      a rejection at BR6.7.

      VP8X (extended) - 24-bit LITTLE-ENDIAN canvas dimensions, MINUS-ONE encoded:
        width  = 1 + bytes[24] + (bytes[25] << 8) + (bytes[26] << 16)
        height = 1 + bytes[27] + (bytes[28] << 8) + (bytes[29] << 16)

      VP8L (lossless) - requires bytes[20] == 0x2f (the VP8L signature byte), then a
      packed 14-bit-each layout:
        width  = 1 + bytes[21] + ((bytes[22] & 0x3f) << 8)
        height = 1 + (bytes[22] >> 6) + (bytes[23] << 2) + ((bytes[24] & 0x0f) << 10)

      "VP8 " (lossy - NOTE THE TRAILING SPACE in the four-character code) - requires
      the 3-byte start code bytes[23] == 0x9d && bytes[24] == 0x01 && bytes[25] ==
      0x2a, then:
        width  = uint16_le(bytes[26:28]) & 0x3fff - LITTLE-ENDIAN, low 14 bits
        height = uint16_le(bytes[28:30]) & 0x3fff - LITTLE-ENDIAN, low 14 bits
      The & 0x3fff masks off the 2-bit scaling field in each 16-bit value.
    category: validation
    applies_to: MediaIntake
    trigger: 'Byte-signature typing of an uploaded file'
    logic: 'IF a precondition fails THEN reject. IF the four-character code is VP8X THEN 24-bit minus-one-encoded LE canvas dims; IF VP8L THEN require byte 20 = 0x2f then packed 14-bit; IF "VP8 " (trailing SPACE) THEN require the 0x9d 0x01 0x2a start code then two LE uint16 masked & 0x3fff; ELSE leave width and height at 0, which BR6.7 rejects'
    violation: 'Invalid -> 400. EVERY WebP field is little-endian; a big-endian read rejects a valid file as unverifiable'
    source: FR6.2
    hazard: true
  - id: BR6.6
    statement: |
      JPEG. A real MARKER-SEGMENT WALK, not a fixed-offset read. Reject immediately
      unless length >= 4 and bytes[0] == 0xff && bytes[1] == 0xd8 (SOI). Then from
      position = 2, loop:
        1. If bytes[position++] != 0xff -> REJECT (marker desynchronised).
        2. Skip fill bytes: while bytes[position] == 0xff: position += 1.
        3. marker = bytes[position++].
        4. If marker == 0xd9 (EOI) OR marker == 0xda (SOS) OR
           position + 2 > len(bytes) -> BREAK the loop. THIS IS NOT A REJECTION; it
           falls through to the final gate.
        5. If marker == 0x01 (TEM) OR 0xd0 <= marker <= 0xd7 (RST0-RST7) -> CONTINUE
           - standalone markers with no length field.
        6. length = uint16_be(bytes[position:position+2]) - BIG-ENDIAN.
        7. If length < 2 OR position + length > len(bytes) -> REJECT (malformed or
           truncated segment).
        8. If marker is one of the SOF markers 0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6,
           0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf:
             - if length < 8 -> REJECT
             - height = uint16_be(bytes[position+3 : position+5]) - BIG-ENDIAN
             - width  = uint16_be(bytes[position+5 : position+7]) - BIG-ENDIAN
             - BREAK
        9. Otherwise position += length and loop while position + 3 < len(bytes).
      The SOF list deliberately EXCLUDES 0xc4 (DHT), 0xc8 (JPG) and 0xcc (DAC) - they
      share the 0xcN range but are not frame headers. And HEIGHT IS AT OFFSET +3,
      WIDTH AT OFFSET +5: a transposition here is a silent bug that shows only on
      non-square images.
    category: validation
    applies_to: MediaIntake
    trigger: 'Byte-signature typing of an uploaded file'
    logic: 'IF length < 4 or bytes 0-1 are not SOI THEN reject. LOOP: a non-0xff lead byte rejects; fill bytes are skipped; EOI, SOS or a short buffer BREAKS without rejecting; TEM and RST0-RST7 continue; a BIG-ENDIAN uint16 length under 2 or overrunning the buffer rejects; a SOF marker with length >= 8 yields height at +3 and width at +5 and breaks; otherwise advance by length'
    violation: 'Invalid -> 400, or silently wrong dimensions. The SOF list EXCLUDES 0xc4, 0xc8 and 0xcc. Height before width: a transposition shows only on non-square images'
    source: FR6.2
    hazard: true
  - id: BR6.7
    statement: 'The final gate, identical for all three image formats: width > 0, height > 0, width <= 40000, height <= 40000, width * height <= 100000000.'
    category: validation
    applies_to: MediaIntake
    trigger: 'After any image header parse, before any decode'
    logic: 'IF all five hold THEN accept; ELSE reject'
    violation: 'Invalid -> 400. This is the decompression-bomb defence and it must run from header data BEFORE any decode, or the defence is lost'
    source: FR6.2
    hazard: true
  - id: BR6.8
    statement: 'The minimum-length checks are part of the contract, not defensive padding: >= 33 PNG, >= 30 WebP, >= 4 JPEG.'
    category: constraint
    applies_to: MediaIntake
    trigger: 'Entry to each image parser'
    logic: 'IF the buffer is shorter than the format minimum THEN reject before reading any field'
    violation: 'Invalid -> 400. Omitting them turns a short file into an out-of-range read rather than a rejection'
    source: FR6.2
    hazard: true
  - id: BR6.9
    statement: |
      Non-image signature checks. video/mp4: bytes 4-7 decode to ftyp. video/webm:
      bytes 0-3 are 0x1a 0x45 0xdf 0xa3 (EBML). application/pdf: the file begins with
      %PDF-. text/vtt: BR6.14-BR6.22.
      HOW MANY BYTES ARE READ IS ITSELF A RULE: for IMAGES and VTT the ENTIRE FILE is
      read into memory; for PDF, MP4 and WebM only the FIRST 32 BYTES. A 10 MB image
      is fully buffered; a 50 MB video is not.
    category: validation
    applies_to: MediaIntake
    trigger: 'Byte-signature typing of a non-image upload'
    logic: 'IF the kind is pdf, mp4 or webm THEN read 32 bytes and test the prefix; IF image or vtt THEN buffer the whole file'
    violation: 'Invalid -> 400. Buffering a 50 MB video would cost five times the memory the ceilings imply'
    source: FR6.2
    hazard: true
  - id: BR6.10
    statement: |
      DO NOT substitute an imaging library for the hand-written walk. A library
      produces a DIFFERENT accept/reject set: it accepts formats this code rejects,
      and - more importantly - may ACCEPT MALFORMED FILES THIS WALKER REJECTS at
      steps 1 and 7, and REJECT UNUSUAL-BUT-VALID FILES THIS WALKER ACCEPTS. Pillow
      is used for VARIANT GENERATION (BR6.23), AFTER acceptance; it is not the
      acceptance test. This is the one place where the project reuse-first rule is
      deliberately not applied, and the reason is recorded here so it is not
      "corrected" later.
    category: policy
    applies_to: MediaIntake
    trigger: 'Any proposal to replace the parsers with a library'
    logic: 'IF the decision is what may be ACCEPTED THEN use the hand-written walk; IF the decision is how to GENERATE a variant THEN a library is correct'
    violation: 'A different accept/reject set: malformed files accepted, unusual-but-valid files rejected. The one deliberate exception to reuse-first (C4)'
    source: FR6.2
    hazard: true
  - id: BR6.11
    statement: 'Per-kind ceilings applied to the SUM of the original and any derived files: video 50 MB, text/vtt 1 MB, everything else 10 MB, with MB = 1024 * 1024.'
    category: constraint
    applies_to: MediaIntake
    trigger: 'After the kind is known, before the writes'
    logic: 'IF sum(original, variants) > the ceiling for the kind THEN reject. 52428800 / 1048576 / 10485760 bytes'
    violation: 'TooLarge -> 413, "Choose files totaling less than ${limit} MB."'
    source: FR6.3
  - id: BR6.12
    statement: 'The declared-length pre-check is advisory only: content-length is tested against 51 MB, and a request without that header yields 0 and passes. Both it and BR6.11 are required.'
    category: validation
    applies_to: MediaIntake
    trigger: 'Before reading the multipart body'
    logic: 'IF content-length > 53477376 THEN reject; IF the header is absent THEN the value is 0 and the check passes'
    violation: 'TooLarge -> 413. Reproducing only this leaves the cap unenforced; reproducing only BR6.11 changes WHEN the rejection happens'
    source: FR6.3
    note: 'PRESERVED INCONSISTENCY: this tests 51 MB while its own message enumerates 50/10/1 MB. See the call-out under BR6.13'
  - id: BR6.13
    statement: 'A missing file, a non-file field, or a zero-byte file is rejected before any signature work.'
    category: validation
    applies_to: MediaIntake
    trigger: 'Immediately after reading the multipart body'
    logic: 'IF the file part is absent, is not a file, or has length 0 THEN reject'
    violation: 'Invalid -> 400, "Choose a non-empty file."'
    source: FR6.3
  - id: BR6.14
    statement: 'WebVTT decoding is strict UTF-8; invalid UTF-8 throws and rejects. Then a leading BOM is stripped and CRLF and bare CR are normalised to LF.'
    category: validation
    applies_to: MediaIntake
    trigger: 'A text/vtt upload'
    logic: 'IF strict decode throws THEN reject; ELSE normalise before every later condition'
    violation: 'Invalid -> 400. Lenient decoding or replacement characters accept files the source rejects'
    source: FR6.4
  - id: BR6.15
    statement: 'Header gate: reject unless the text matches the WEBVTT header pattern ending in a newline. A file of exactly WEBVTT with no trailing newline FAILS.'
    category: validation
    applies_to: MediaIntake
    trigger: 'After normalisation'
    logic: 'IF not match ''^WEBVTT(?:[ \t][^\n]*)?\n'' THEN reject'
    violation: 'Invalid -> 400'
    source: FR6.4
  - id: BR6.16
    statement: 'Reject if any NUL character appears anywhere in the file.'
    category: validation
    applies_to: MediaIntake
    trigger: 'After normalisation'
    logic: 'IF \u0000 appears anywhere THEN reject'
    violation: 'Invalid -> 400'
    source: FR6.4
  - id: BR6.17
    statement: 'Markup blocklist applied to the WHOLE file: reject on any match of script, iframe, object, embed, svg or style as an opening tag, case-insensitive.'
    category: validation
    applies_to: MediaIntake
    trigger: 'After normalisation'
    logic: 'IF ''<(?:script|iframe|object|embed|svg|style)\b'' matches anywhere, case-insensitively, THEN reject'
    violation: 'Invalid -> 400. Whole file, not cue payloads only'
    source: FR6.4
  - id: BR6.18
    statement: 'Block split on a blank line tolerating whitespace. Reject if there are no blocks, or if block 0 contains an arrow.'
    category: validation
    applies_to: MediaIntake
    trigger: 'After the whole-file scans'
    logic: 'IF blocks is empty OR block 0 contains "-->" THEN reject'
    violation: 'Invalid -> 400. The header block must not itself be a cue'
    source: FR6.4
  - id: BR6.19
    statement: 'Per block from index 1: a NOTE block is skipped entirely; otherwise the timing line is at index 0 if the first line contains an arrow, else index 1 - a cue identifier is allowed there and nowhere else.'
    category: validation
    applies_to: MediaIntake
    trigger: 'Per block, from index 1'
    logic: 'IF the block matches ''^NOTE(?:[ \t\n]|$)'' THEN skip; ELSE timing_index := 0 if "-->" in lines[0] else 1'
    violation: 'Invalid -> 400 when the resulting line is not a timing line'
    source: FR6.4
  - id: BR6.20
    statement: 'The timing line must match the pattern exactly: an optional HH: of two or more digits, MM:SS.mmm with exactly three decimals, an arrow with at least one space or tab on each side, optional trailing cue settings.'
    category: validation
    applies_to: MediaIntake
    trigger: 'Per non-NOTE block'
    logic: 'IF the timing line does not match the pattern THEN reject the whole file'
    violation: 'Invalid -> 400'
    source: FR6.4
  - id: BR6.21
    statement: 'end > start strictly, where a time parses to a value only if hours is finite and seconds < 60 and minutes < 60, otherwise not-a-number; a not-a-number on either side makes the comparison false and rejects. Zero-duration cues are rejected and every cue payload must be non-empty.'
    category: validation
    applies_to: MediaIntake
    trigger: 'Per cue'
    logic: 'IF NOT (end > start) THEN reject - which covers not-a-number and zero duration in one branch. IF the joined trimmed payload is empty THEN reject'
    violation: 'Invalid -> 400. A port that validates components separately raises a different error at a different point'
    source: FR6.4
  - id: BR6.22
    statement: 'At least one cue. A valid header with no cues at all is rejected, and any single failing block rejects the whole file.'
    category: validation
    applies_to: MediaIntake
    trigger: 'After all blocks are walked'
    logic: 'IF cue_count = 0 THEN reject; IF any block failed any condition THEN reject the whole file'
    violation: 'Invalid -> 400, "Choose a UTF-8 .vtt file beginning with WEBVTT and containing valid timed captions."'
    source: FR6.4
  - id: BR6.23
    statement: 'Responsive image variants are generated server-side in Python from the original; the whole browser-prepared-variant verification surface disappears rather than being ported, and the upload response sources[] therefore changes for EVERY upload.'
    category: policy
    applies_to: MediaIntake
    trigger: 'After acceptance of an image upload'
    logic: 'IF the accepted kind is an image THEN generate variants server-side and populate sources[]; the envelope check, WebP-only rule, 1600-pixel ceiling and aspect-ratio tolerance are NOT ported'
    violation: 'Re-creating the retired checks to keep their error strings alive (BR10.9) is explicitly forbidden'
    source: FR6.5
  - id: BR6.24
    statement: 'Bytes and metadata are two separate non-transactional writes; on any exception every key written so far is deleted from both stores under a gather-all-results primitive, best-effort.'
    category: policy
    applies_to: MediaIntake
    trigger: 'Any exception during the write sequence'
    logic: 'IF an exception occurs THEN delete every tracked key from both stores, gathering all results so one failed delete does not abort the rest'
    violation: 'An orphaned object or row. Cleanup holds only while the handler reaches its cleanup path; a process kill leaves an orphan nothing reclaims'
    source: FR6.6
  - id: BR6.25
    statement: 'Cleanup never masks the original error, and cancellation is checked at seven points through the write sequence and maps to 499.'
    category: policy
    applies_to: MediaIntake
    trigger: 'Cleanup after a failure, or a client disconnect at any of the seven checkpoints'
    logic: 'IF cleanup fails THEN log it and still report why the UPLOAD failed. IF cancellation is observed at any checkpoint THEN abandon, clean up, and signal 499'
    violation: 'Reporting the cleanup failure instead of the upload failure; or letting 499 fall through to the 503 catch-all'
    source: FR6.6
  - id: BR7.3
    statement: 'A key is served only if it matches the key pattern; a key that does not match is 404, checked FIRST, before any storage access.'
    category: validation
    applies_to: MediaDelivery
    trigger: 'Every GET or HEAD on the media route'
    logic: 'IF the key does not match ''^[a-f0-9-]+\.(jpg|png|webp|pdf|mp4|webm|vtt)$'' THEN 404 immediately'
    violation: '404, "Not found". Also the path-traversal defence: the ENT-4 url form is more permissive than this pattern'
    source: FR7.1
  - id: BR7.4
    statement: |
      THE RULE, EXACTLY. An asset is PUBLICLY READABLE IF AND ONLY IF the literal
      string /api/media/<key> appears ANYWHERE in the serialised published document.
      Not "is referenced by the photo field", not "appears in a known image slot" -
      ANYWHERE AT ALL, INCLUDING INSIDE FREE PROSE: a transcript (up to 60,000
      characters), a description, the bio, the intro, the notice, or any of the nine
      editable copy blocks. The test is a SUBSTRING SCAN over the serialised published
      document.
    category: authorization
    applies_to: MediaDelivery
    trigger: 'Every well-formed media request'
    logic: 'IF the literal "/api/media/" + key is a substring of the serialised published document THEN public; ELSE not public'
    violation: 'A structured field check makes strictly fewer assets public; images referenced from prose start 404-ing'
    source: FR7.2
    hazard: true
  - id: BR7.5
    statement: |
      WHY A STRUCTURED FIELD CHECK IS NOT EQUIVALENT. Computing public-ness from
      structured fields only (photo, item image, imageSources) makes STRICTLY FEWER
      assets public. Every image the owner referenced from prose - a figure linked
      inside a description, an image embedded in a transcript - STARTS RETURNING 404
      TO VISITORS, on a site that renders normally in every other respect. The
      substring rule is not ELEGANT; it is THE RULE, and it is positional-string-based
      rather than semantic, which means it silently changes meaning if the URL format
      ever changes (a query string, a CDN prefix). DO NOT "IMPROVE" IT.
      Two properties the scan verified, so they need not be re-derived: PREFIX
      COLLISIONS ARE IMPOSSIBLE (the key pattern forces a .-extension suffix and a
      match requires /api/media/ immediately followed by the FULL key, so
      /api/media/0.webp cannot match inside /api/media/1230.webp), and JSON ESCAPING
      IS NOT A PROBLEM (serialisation does not escape /).
    category: policy
    applies_to: MediaDelivery
    trigger: 'Any proposal to compute public-ness from structured fields'
    logic: 'S (structured) is always a subset of P (substring), strictly whenever a reference lives in prose. IF tempted to improve the rule THEN do not'
    violation: 'Silent wrongly-private assets: no alarm, no log, no failing test. Depends on serialisation not escaping /'
    source: FR7.2
    hazard: true
  - id: BR7.6
    statement: 'Evaluation order is load-bearing: public-ness is evaluated BEFORE the owner check, and the owner check is short-circuited when the asset is public.'
    category: authorization
    applies_to: MediaDelivery
    trigger: 'Every well-formed media request'
    logic: 'IF public THEN serve with NO authorization lookup at all; ELSE perform the identity lookup'
    violation: 'Reversing the order changes the cost profile of the system hottest path'
    source: FR7.2
    hazard: true
  - id: BR7.7
    statement: |
      THREE CONSEQUENCES THAT ARE PRESERVED, NOT FIXED.
      (a) OVER-PERMISSION THROUGH PROSE - pasting a draft-only image URL into a
          caption transcript publishes that image.
      (b) PUBLICATION IS INDISCRIMINATE - publishing makes public EVERY asset URL
          anywhere in the document, INCLUDING ONES IN SECTIONS TOGGLED OFF via
          sections.*; the visibility toggle hides the section from the page, it does
          NOT make its media private.
      (c) NO REVOCATION AND NO CLEANUP - removing a reference makes the asset
          non-public again on the next request, but neither the bytes nor the metadata
          row is ever deleted, and there is no orphan collection anywhere.
    category: policy
    applies_to: MediaDelivery
    trigger: 'A publish, and any later reading of the rule'
    logic: 'IF a URL appears anywhere in the published document THEN its asset is public, even inside a section sections.* has hidden. Removing the reference makes it non-public on the next request; nothing is ever deleted'
    violation: 'Fixing any of the three changes observable behaviour under the parity rule'
    source: FR7.2
    hazard: true
  - id: BR7.8
    statement: 'Every denial is a 404, never a 403. Malformed key, missing row, missing bytes and not-public-and-not-owner are indistinguishable.'
    category: authorization
    applies_to: MediaDelivery
    trigger: 'Any denial on the media path'
    logic: 'IF denied for ANY reason THEN 404 with the same body. A 403 anywhere on this path is a defect'
    violation: 'A 403 confirms the key exists, disclosing unpublished media'
    source: FR7.3
  - id: BR7.9
    statement: 'HEAD ALWAYS returns 200 with the full Content-Length and NEVER inspects Range; it never returns 206 or 416 even where the equivalent GET would. HEAD and GET must not share range logic.'
    category: constraint
    applies_to: MediaDelivery
    trigger: 'A HEAD request'
    logic: 'IF method = HEAD THEN return 200 with the full length BEFORE any range parsing'
    violation: 'A framework that serves HEAD by running GET and dropping the body reproduces GET 206 and 416 exactly'
    source: FR7.4.1
    hazard: true
  - id: BR7.10
    statement: 'There is NO 304 path. An ETag IS emitted and If-None-Match is NOT honoured; every request is a full transfer of the selected range.'
    category: constraint
    applies_to: MediaDelivery
    trigger: 'A GET carrying If-None-Match'
    logic: 'IF If-None-Match is present THEN ignore it and transfer in full'
    violation: 'Adding a 304 path satisfies the phrase "existing semantics" while silently changing what video players receive'
    source: FR7.4.3
    hazard: true
  - id: BR7.11
    statement: 'If-Range IS honoured: present and not exactly equal to the current ETag discards the Range and serves a full 200. Exact string equality.'
    category: constraint
    applies_to: MediaDelivery
    trigger: 'A GET carrying If-Range'
    logic: 'IF If-Range present AND If-Range != etag THEN discard Range and serve 200'
    violation: 'Handling all conditional headers uniformly gets one of BR7.10 and BR7.11 wrong'
    source: FR7.4.2
    hazard: true
  - id: BR7.12
    statement: 'Multi-range is 416. Neither the whole entity nor a multipart response. bytes=- with both groups empty is 416 as well.'
    category: constraint
    applies_to: MediaDelivery
    trigger: 'A GET whose trimmed Range fails the single-range pattern'
    logic: 'IF the trimmed value does not match ''^bytes=(\d*)-(\d*)$'' THEN 416'
    violation: '416 with the BR7.16 shape'
    source: FR7.4.4
    hazard: true
  - id: BR7.13
    statement: 'A zero-byte object plus ANY range is 416, as is an object whose size is not a safe integer.'
    category: constraint
    applies_to: MediaDelivery
    trigger: 'A GET with any Range against an empty or unsized object'
    logic: 'IF size is not a safe integer OR size < 1 THEN 416 for any range at all'
    violation: '416 with the BR7.16 shape'
    source: FR7.4.5
    hazard: true
  - id: BR7.14
    statement: 'An oversized suffix range yields 206 for the whole object, not 200. N must be a safe integer > 0; start = max(0, size - N), end = size - 1.'
    category: calculation
    applies_to: MediaDelivery
    trigger: 'A GET with a suffix Range of the form bytes=-N'
    logic: 'IF N is a safe integer > 0 THEN start := max(0, size - N), end := size - 1, respond 206 - so N > size yields the WHOLE object as 206'
    violation: 'Answering 200 changes a video player buffering strategy'
    source: FR7.4.6
    hazard: true
  - id: BR7.15
    statement: |
      THE START/END ASYMMETRY. For bytes=S-E: REJECT (416) IF start >= size OR
      end < start; then end = min(end, size - 1) - so an END BEYOND THE OBJECT IS
      SILENTLY CLAMPED and served as 206. For bytes=S-, end = size - 1. THE ASYMMETRY
      IS INTENTIONAL AND MUST BE REPRODUCED: a start past the end is an error, an end
      past the end is not. An absent or empty Range header means no range at all and a
      full 200. The parser returns {offset: start, length: end - start + 1}.
    category: calculation
    applies_to: MediaDelivery
    trigger: 'A GET with an explicit Range of the form bytes=S-E or bytes=S-'
    logic: 'IF start >= size OR end < start THEN 416; ELSE end := min(end, size - 1) and respond 206. The parser returns {offset: start, length: end - start + 1}'
    violation: 'A start past the end is an error, an end past the end is not. The asymmetry is intentional and must be reproduced'
    source: FR7.4.7
    hazard: true
  - id: BR7.16
    statement: 'The 416 response sets Content-Range bytes */<size> and Content-Length 0 with a null body, but RETAINS every other header from the success path including Content-Type and ETag.'
    category: constraint
    applies_to: MediaDelivery
    trigger: 'Any 416'
    logic: 'IF responding 416 THEN emit the BR7.18 header set, then override Content-Range and Content-Length'
    violation: 'A bare error response is not what the source returns'
    source: FR7.4
    hazard: true
  - id: BR7.17
    statement: 'The 206 response sets Content-Range bytes <offset>-<offset+length-1>/<size> and Content-Length <length>, and reads through AssetStore.get_range rather than loading and slicing.'
    category: constraint
    applies_to: MediaDelivery
    trigger: 'Any 206'
    logic: 'IF responding 206 THEN bytes := AssetStore.get_range(key, offset, length); NEVER AssetStore.get(key)[offset:offset+length]'
    violation: 'Loading a whole video to serve one range is precisely what the port exists to avoid; a slicing port passes every correctness test'
    source: FR7.4
    hazard: true
  - id: BR7.18
    statement: |
      Every successful media response carries, VERBATIM:
        Content-Type: <the metadata row's media type>  (FROM THE METADATA STORE, NOT
                                                        FROM THE OBJECT STORE)
        Cache-Control: private, no-cache
        X-Content-Type-Options: nosniff
        Content-Security-Policy: default-src 'none'; sandbox
        Accept-Ranges: bytes
        ETag: <the object's entity tag>
        Content-Length: <the object's size>
      The two stores hold the media type independently and agree only because they are
      written from the same value at upload time; ANYTHING THAT SYNCS ONLY ONE WILL
      SERVE MISMATCHED TYPES.
    category: constraint
    applies_to: MediaDelivery
    trigger: 'Every 200, 206 and (per BR7.16) 416'
    logic: 'Content-Type from the metadata row; Cache-Control private, no-cache; X-Content-Type-Options nosniff; Content-Security-Policy default-src ''none''; sandbox; Accept-Ranges bytes; ETag; Content-Length'
    violation: 'The two stores hold the media type independently; anything that syncs only one serves mismatched types. The CSP and nosniff contain the five-byte PDF check'
    source: FR7.5

  # ---------------------------------------------------------------------------
  # Unit-scoped group BR25.x = U5 + 20. These realise an NFR or a team constraint
  # and trace to NO FR, so they belong in the traceability reverse array.
  # ---------------------------------------------------------------------------
  - id: BR25.1
    statement: 'MediaDelivery holds NO cache of its own. The only cache on its read path is ContentAuthority''s.'
    category: policy
    applies_to: MediaDelivery
    trigger: 'Every non-public media request, which reads the published document'
    logic: 'IF the published document is needed THEN obtain it from ContentAuthority on every request and discard it; NEVER memoise it in this unit, at any scope - module, instance, request-independent or LRU'
    violation: >
      A cache here would not receive the publish invalidation, because ContentAuthority
      invalidates its own and knows nothing about a second one. An asset the owner has
      just unreferenced by publishing stays public for the lifetime of this unit copy.
      That is an authorization defect with no error, no log and no failing test unless
      one is written for it specifically.
    source: NFR8
    traces_to_fr: null
    reverse_reason: >
      No FR states it. It is the corollary of BR7.1 (the cache lives in
      ContentAuthority) expressed as an obligation on THIS unit, whose own FR - FR7.2,
      FR7.3 - say nothing about caching, while FR7.6 is assigned to U4. NFR8 requires
      any cache introduced to have an explicit invalidation path; this unit satisfies
      that by introducing none.
  - id: BR25.2
    statement: 'The two CPU-bound steps in this unit - the hand-written header parse and Pillow variant generation - run off the event loop by the same mechanism the adapters use for blocking drivers.'
    category: policy
    applies_to: MediaIntake
    trigger: 'Byte-signature typing of a buffered image (BR6.4-BR6.6); variant generation (BR6.23)'
    logic: 'IF work is CPU-bound over a buffered upload THEN dispatch it with anyio.to_thread.run_sync; a request handler never performs it inline'
    violation: >
      Event-loop blocking, which is invisible to every check on the merge gate - it
      fails no lint, no type check, no coverage floor and no Compose end-to-end flow.
      A 10 MB image is fully buffered by BR6.9 and parsed byte by byte, and Pillow
      decodes it; both are long enough to stall every other request on the single
      Python process.
    source: 'team.md Code Style (Python) - async by default'
    traces_to_fr: null
    reverse_reason: >
      No FR or NFR states it. The team rule names the mechanism for SYNCHRONOUS
      DEPENDENCIES wrapped in an adapter; this extends the same mechanism to CPU-bound
      code this unit writes itself, which is a case the rule does not name and this
      unit is the only place in the system that has.

rules_subject_to_but_not_owned:
  - { id: BR3.1, owner_unit: u6-http-api, why: 'Every operation authorises itself; this unit upload and serve operations do so' }
  - { id: BR7.1, owner_unit: u4-content-core, why: 'The published-document cache lives in ContentAuthority, not here. DECLARATION MOVED TO u4-content-core at review by coordinator decision - it was declared here while carrying owned_by_unit: u4-content-core and applies_to: ContentAuthority. This unit CONSUMES the cache on its public read path and holds none of its own (BR25.1); consuming is not owning' }
  - { id: BR7.2, owner_unit: u4-content-core, why: 'The cache changes which requests hit storage, never which assets are public; a publish invalidates it. Declaration moved with BR7.1. This unit is the cache''s only reader and its correctness is this unit''s authorization correctness, which is why the rule is quoted in full below - but FR7.6 is assigned to U4 and is discharged there by BR7.1, BR7.2, BR24.1 and BR24.2 together' }
  - { id: BR3.3, owner_unit: u6-http-api, why: 'Origin enforcement on POST /api/upload - discharges FR6.7, which units-generation assigns to U5' }
  - { id: BR3.4, owner_unit: u6-http-api, why: 'CSRF double-submit added on top of BR3.3' }
  - { id: BR3.5, owner_unit: u6-http-api, why: 'Origin applies to mutations only, never to GET or HEAD - so never to the media serve path' }
  - { id: BR10.4, owner_unit: u6-http-api, why: 'The four-member taxonomy this unit raises into; 499 sits OUTSIDE it and is mapped explicitly' }
  - { id: BR10.7, owner_unit: u6-http-api, why: 'The verbatim error copy this unit conditions trigger; this unit raises, it does not compose' }
  - { id: BR10.9, owner_unit: u6-http-api, why: 'The four variant-verification strings BR6.23 retires' }
```

### Rules summary

| Group | Rules | Component | Category mix | Requirement |
|---|---|---|---|---|
| What is accepted | BR6.1–BR6.3 | `MediaIntake` | validation, calculation | FR6.1 |
| **Byte-signature typing [hazard]** | **BR6.4–BR6.10** | `MediaIntake` | validation, constraint, policy | **FR6.2** |
| Size ceilings | BR6.11–BR6.13 | `MediaIntake` | constraint, validation | FR6.3 |
| The WebVTT validator | BR6.14–BR6.22 | `MediaIntake` | validation | FR6.4 |
| Variant generation | BR6.23 | `MediaIntake` | policy | FR6.5 |
| Orphan-free failure | BR6.24–BR6.25 | `MediaIntake` | policy | FR6.6 |
| *Subject to — published-document cache (consumed, declared by U4)* | *BR7.1–BR7.2* | *`ContentAuthority`* | *policy* | *FR7.6 → discharged by U4* |
| Key validation | BR7.3 | `MediaDelivery` | validation | FR7.1 |
| **Asset visibility [hazard]** | **BR7.4–BR7.7** | `MediaDelivery` | authorization, policy | **FR7.2** |
| Denial discloses nothing | BR7.8 | `MediaDelivery` | authorization | FR7.3 |
| **Range handling [hazard]** | **BR7.9–BR7.17** | `MediaDelivery` | constraint, calculation | **FR7.4** |
| Protective headers | BR7.18 | `MediaDelivery` | constraint | FR7.5 |
| *Unit-scoped — trace to no FR* | *BR25.1–BR25.2* | *both* | *policy* | *NFR8; `team.md` § Code Style* |

**41 FR-traced rules: 25 owned by `MediaIntake`, 16 owned by `MediaDelivery`. 20 of
them are hazard rules** — the three bolded groups above, `BR6.4–BR6.10` (7) +
`BR7.4–BR7.7` (4) + `BR7.9–BR7.17` (9) — and every one needs a test per enumerated
branch and falls inside the 100% scoped coverage floor.

**Plus 2 unit-scoped rules, BR25.1 and BR25.2** (group `BR25.x` = U5 + 20), which
realise an NFR and a team constraint respectively and **trace to no FR**. They are
recorded in the traceability `reverse` array with their reasons, not in `coverage`.

**43 rules declared in total for this unit.**

**`BR7.1` and `BR7.2` are NOT among them.** They were declared here until review and
are now declared by **`u4-content-core`**, under `rules_subject_to_but_not_owned`
above. They are still quoted in full below, because this unit is the cache's only
reader and its invalidation correctness *is* this unit's authorization correctness —
but **this unit claims no part of `FR7.6`**: it reads through the cache under
`FR7.2` and discharges nothing in `FR7.6`.

---

## `MediaIntake`

### BR6.1–BR6.3 — what is accepted [FR6.1]

- **BR6.1** Exactly **seven** media types are accepted, with this fixed
  type→extension mapping: `image/jpeg`→`jpg`, `image/png`→`png`,
  `image/webp`→`webp`, `application/pdf`→`pdf`, `video/mp4`→`mp4`,
  `video/webm`→`webm`, `text/vtt`→`vtt`. No other type is accepted.
- **BR6.2** **Captions MIME coercion.** If the upload declares `kind = 'captions'`
  **and** the filename ends `.vtt` **and** the declared type is empty or one of
  `text/vtt`, `text/plain`, `application/octet-stream`, the type is forced to
  `text/vtt`. Otherwise the declared type is used as-is. This exists because browsers
  rarely set `text/vtt`; dropping it makes most caption uploads fail at BR6.1.
- **BR6.3** The stored extension is derived from the **validated** media type,
  **never from the user's filename**, and the object key is `<uuid4>.<ext>`. The
  user's filename is stored for display, truncated to **200 characters**.

### BR6.4–BR6.10 — byte-signature typing [hazard, FR6.2]

Type is determined by **inspecting the file's own bytes**, never the declared type
or extension. The three image parsers are **simultaneously the dimension extractor
and the format validator** — returning no dimensions **is** a rejection — so a port
must reproduce the same **accept/reject decision**, not merely the same dimensions.

> **The single most transcription-error-prone fact in this document:**
> **PNG and JPEG are big-endian. EVERY WebP field is little-endian. JPEG stores
> HEIGHT BEFORE WIDTH.** The source gets its defaults from JavaScript's `DataView`,
> whose `getUint32(n)` / `getUint16(n)` are big-endian **unless** a `true` second
> argument requests little-endian. Python's `int.from_bytes` has **no default to
> inherit**, so **every read below must be transcribed individually** with its
> byteorder stated.

- **BR6.4 — PNG.** Reject unless **all** hold: length **>= 33** bytes; bytes **0–7**
  are exactly `137 80 78 71 13 10 26 10` (`\x89PNG\r\n\x1a\n`); bytes **12–15**
  decode to `IHDR`. Then:
  - `width  =` bytes **16–19**, unsigned 32-bit, **BIG-ENDIAN**
  - `height =` bytes **20–23**, unsigned 32-bit, **BIG-ENDIAN**

  Bytes **8–11** (the IHDR chunk length) are **never checked**. Everything after byte
  23 is ignored.

- **BR6.5 — WebP.** Reject unless **all** hold: length **>= 30** bytes; bytes **0–3**
  decode to `RIFF`; bytes **8–11** decode to `WEBP`; and
  `uint32_le(bytes[4:8]) + 8 <= len(bytes)` — the **LITTLE-ENDIAN** RIFF size field
  plus the 8-byte RIFF header must not exceed the actual buffer (this is what rejects
  truncated files). Bytes **12–15** then select one of exactly three sub-formats;
  **anything else leaves width/height at 0 and is a rejection** at BR6.7.

  - **`VP8X`** (extended) — 24-bit **LITTLE-ENDIAN** canvas dimensions, **minus-one
    encoded**:
    - `width  = 1 + bytes[24] + (bytes[25] << 8) + (bytes[26] << 16)`
    - `height = 1 + bytes[27] + (bytes[28] << 8) + (bytes[29] << 16)`
  - **`VP8L`** (lossless) — requires `bytes[20] == 0x2f` (the VP8L signature byte),
    then a packed 14-bit-each layout:
    - `width  = 1 + bytes[21] + ((bytes[22] & 0x3f) << 8)`
    - `height = 1 + (bytes[22] >> 6) + (bytes[23] << 2) + ((bytes[24] & 0x0f) << 10)`
  - **`VP8 `** (lossy — **note the trailing SPACE in the four-character code**) —
    requires the 3-byte start code `bytes[23] == 0x9d && bytes[24] == 0x01 &&
    bytes[25] == 0x2a`, then:
    - `width  = uint16_le(bytes[26:28]) & 0x3fff` — **LITTLE-ENDIAN**, low 14 bits
    - `height = uint16_le(bytes[28:30]) & 0x3fff` — **LITTLE-ENDIAN**, low 14 bits

    The `& 0x3fff` masks off the 2-bit scaling field in each 16-bit value.

- **BR6.6 — JPEG.** A real **marker-segment walk**, not a fixed-offset read. Reject
  immediately unless length **>= 4** and `bytes[0] == 0xff && bytes[1] == 0xd8`
  (SOI). Then from `position = 2`, loop:
  1. If `bytes[position++] != 0xff` → **reject** (marker desynchronised).
  2. Skip fill bytes: `while bytes[position] == 0xff: position += 1`.
  3. `marker = bytes[position++]`.
  4. If `marker == 0xd9` (EOI) **or** `marker == 0xda` (SOS) **or**
     `position + 2 > len(bytes)` → **break** the loop. **This is not a rejection**;
     it falls through to the final gate.
  5. If `marker == 0x01` (TEM) **or** `0xd0 <= marker <= 0xd7` (RST0–RST7) →
     **continue** — standalone markers with no length field.
  6. `length = uint16_be(bytes[position:position+2])` — **BIG-ENDIAN**.
  7. If `length < 2` **or** `position + length > len(bytes)` → **reject** (malformed
     or truncated segment).
  8. If `marker` is one of the SOF markers
     `0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf`:
     - if `length < 8` → **reject**
     - **`height = uint16_be(bytes[position+3 : position+5])`** — **BIG-ENDIAN**
     - **`width  = uint16_be(bytes[position+5 : position+7])`** — **BIG-ENDIAN**
     - **break**
  9. Otherwise `position += length` and loop while `position + 3 < len(bytes)`.

  **The SOF list deliberately EXCLUDES `0xc4` (DHT), `0xc8` (JPG) and `0xcc`
  (DAC)** — they share the `0xcN` range but are not frame headers. And **height is at
  offset +3, width at offset +5**: a transposition here is a silent bug that shows
  only on non-square images.

- **BR6.7 — the final gate, applied identically to all three formats.** Accept only
  if **all** hold: `width > 0`; `height > 0`; `width <= 40000`; `height <= 40000`;
  `width * height <= 100000000`. Otherwise **reject**.
  This is the **decompression-bomb defence**, and it is reached **without decoding a
  single pixel**. The pixel caps must be enforced from **header data before any
  decode**, or the defence is lost.
- **BR6.8 — the minimum-length checks are part of the contract**, not defensive
  padding: **>= 33** for PNG, **>= 30** for WebP, **>= 4** for JPEG.
- **BR6.9 — non-image signature checks.** `video/mp4`: bytes **4–7** decode to
  `ftyp`. `video/webm`: bytes **0–3** are `0x1a 0x45 0xdf 0xa3` (EBML).
  `application/pdf`: the file begins with `%PDF-`. `text/vtt`: BR6.14–BR6.22.
  **How many bytes are read is itself a rule:** for **images and VTT the ENTIRE file**
  is read into memory; for **PDF, MP4 and WebM only the first 32 bytes**. A 10 MB
  image is fully buffered; a 50 MB video is not.
- **BR6.10 — do not substitute an imaging library for the hand-written walk.** A
  library produces a **different accept/reject set**: it accepts formats this code
  rejects, and — more importantly — may **accept malformed files this walker rejects**
  at steps 1 and 7, and **reject unusual-but-valid files this walker accepts**. Pillow
  is used for **variant generation** (BR6.23), *after* acceptance; it is not the
  acceptance test. This is the one place where the project's reuse-first rule is
  deliberately not applied, and the reason is recorded here so it is not "corrected"
  later.

> **What breaks silently.** A transposed JPEG width/height produces plausible
> numbers for every square test image and wrong ones for every real photograph — and
> the wrong numbers flow into `imageSources`, which drives responsive rendering. A
> big-endian read of a WebP field produces a huge number that trips BR6.7 and
> rejects a valid file as "unverifiable format" — indistinguishable, to the owner,
> from a corrupt upload.

#### Endianness, restated as a per-read checklist

Stated once more as a flat list, because BR6.4–BR6.6 are the only place in the system
where a single wrong keyword argument produces a plausible wrong answer rather than an
exception. **Every multi-byte read in this unit appears below. There are no others.**

| # | Rule | Format | Bytes | Width of read | Byte order | Yields |
|---|---|---|---|---|---|---|
| 1 | BR6.4 | PNG | 16–19 | 32-bit unsigned | **big-endian** | `width` |
| 2 | BR6.4 | PNG | 20–23 | 32-bit unsigned | **big-endian** | `height` |
| 3 | BR6.5 | WebP (all) | 4–7 | 32-bit unsigned | **little-endian** | RIFF size, for the truncation check |
| 4 | BR6.5 | WebP `VP8X` | 24, 25, 26 | 3 × 8-bit, shifted `0/8/16` | **little-endian** by construction | `width - 1` |
| 5 | BR6.5 | WebP `VP8X` | 27, 28, 29 | 3 × 8-bit, shifted `0/8/16` | **little-endian** by construction | `height - 1` |
| 6 | BR6.5 | WebP `VP8L` | 21, 22 | packed 14-bit | **little-endian** by construction | `width - 1` |
| 7 | BR6.5 | WebP `VP8L` | 22, 23, 24 | packed 14-bit | **little-endian** by construction | `height - 1` |
| 8 | BR6.5 | WebP `VP8 ` | 26–27 | 16-bit unsigned, `& 0x3fff` | **little-endian** | `width` |
| 9 | BR6.5 | WebP `VP8 ` | 28–29 | 16-bit unsigned, `& 0x3fff` | **little-endian** | `height` |
| 10 | BR6.6 | JPEG | `position`..`+2` | 16-bit unsigned | **big-endian** | segment `length` |
| 11 | BR6.6 | JPEG | `position+3`..`+5` | 16-bit unsigned | **big-endian** | **`height`** |
| 12 | BR6.6 | JPEG | `position+5`..`+7` | 16-bit unsigned | **big-endian** | **`width`** |

Reads 4–7 are byte-indexed arithmetic rather than an integer decode, so they carry
their order in the shift amounts and cannot be got wrong by a missing argument — but
they can be got wrong by reversing the shift order, which is the same defect wearing a
different shape. Reads 11 and 12 are the **height-before-width** transposition trap.

### BR6.11–BR6.13 — size ceilings [FR6.3]

- **BR6.11** Per-kind ceilings, applied to the **sum** of the original and any
  derived files, not per file: **`video/*` → 50 MB**, **`text/vtt` → 1 MB**,
  **everything else → 10 MB**. `MB = 1024 * 1024`, so these are **mebibytes**:
  52,428,800 / 1,048,576 / 10,485,760 bytes.
- **BR6.12** The declared-length pre-check is **advisory only**. The source tests the
  `content-length` header against **51 MB** (53,477,376 bytes); **a request without
  that header yields 0 and passes**. Reproducing only the header check leaves the cap
  unenforced; reproducing only the sum check changes **when** the rejection happens
  (after buffering rather than before). **Both are required**, and the sum check
  (BR6.11) is the authoritative one.
- **BR6.13** A missing file, a non-file field, or a **zero-byte** file is rejected as
  a 400 before any signature work.

> ### The 51 MB / 50-10-1 MB inconsistency — preserved as-is
>
> **BR6.12's pre-check tests `content-length` against 51 MB (53,477,376 bytes) while
> its own rejection message enumerates 50 MB, 10 MB and 1 MB** — the string, verbatim
> from BR10.7:
>
> > `Choose a video smaller than 50 MB, a photo / PDF smaller than 10 MB, or captions smaller than 1 MB.`
>
> The number tested and the numbers stated are **different numbers**, and they are
> preserved as they are. Three consequences follow, all of them observable:
>
> 1. A **50.5 MB video** passes the pre-check (it is under 51 MB) and is then rejected
>    by BR6.11's sum check at 50 MB — with the **same** sentence, but after the whole
>    body has been buffered rather than before.
> 2. A **20 MB photo** passes the pre-check (it is under 51 MB) and is rejected by
>    BR6.11 at 10 MB. The pre-check is a **single** ceiling; it does not know the kind,
>    because the kind is not known until the bytes are inspected.
> 3. A request with **no `content-length` header at all** yields 0 and passes the
>    pre-check unconditionally, whatever its actual size.
>
> **This is recorded in `WORKING-RECORD.md` § 9 as an open item owned by this unit
> (U5), and this is its disposition: preserve both numbers exactly, and do not
> reconcile them.** The pre-check is the only thing standing between an oversized body
> and a full buffering of it, and 51 MB is where it stands today. Changing it to 50 MB
> would reject a class of request the current system accepts-then-rejects-later, which
> is a different observable behaviour under the parity rule; changing the message to
> say 51 would change **product copy** (BR10.7, FR10.2), which the parity rule also
> forbids. There is no edit here that is not a parity change. The correct action is to
> leave both and to write a test that **asserts the gap** — a 50.5 MB video reaching
> BR6.11 rather than BR6.12 — so a later reader cannot mistake it for a typo and
> "fix" it.
>
> The message string itself is owned by `HttpApi` as product copy (BR10.7); this unit
> raises the condition and does not compose the sentence.

### BR6.14–BR6.22 — the WebVTT validator [FR6.4]

**Eight independent reject conditions.** A permissive VTT library will accept files
this rejects, so the validator is specified rather than delegated.

- **BR6.14** **Decoding is strict UTF-8.** Invalid UTF-8 **throws** and the file is
  rejected. Not lenient, not replacement-character substitution. Then a leading BOM
  is stripped and all `\r\n` and bare `\r` are normalised to `\n`.
- **BR6.15** **Header gate.** Reject unless the text matches
  `/^WEBVTT(?:[ \t][^\n]*)?\n/` — the literal `WEBVTT`, optionally followed by a
  space or tab and trailing text, then a **newline**. **A file consisting of only
  `WEBVTT` with no trailing newline FAILS.**
- **BR6.16** **Reject if any `\u0000` appears anywhere** in the file.
- **BR6.17** **Markup blocklist, applied to the whole file:** reject on any match of
  `/<(?:script|iframe|object|embed|svg|style)\b/i`.
- **BR6.18** **Block split** on `/\n[ \t]*\n/` after trimming — blank-line separated,
  tolerating whitespace on the "blank" line. Reject if there are no blocks, or if
  **block 0 contains `-->`** (the header block must not itself be a cue).
- **BR6.19** **Per block from index 1:** a block matching `/^NOTE(?:[ \t\n]|$)/` is
  **skipped entirely** (comments). Otherwise the timing line is at index
  `0 if '-->' in lines[0] else 1` — **a cue identifier line is allowed before the
  timing line**, and nowhere else.
- **BR6.20** **The timing line must match exactly:**
  ```
  /^((?:\d{2,}:)?\d{2}:\d{2}\.\d{3})[ \t]+-->[ \t]+((?:\d{2,}:)?\d{2}:\d{2}\.\d{3})(?:[ \t]+.*)?$/
  ```
  i.e. an optional `HH:` of **two or more** digits, then `MM:SS.mmm` with **exactly
  three** decimal places, separated by `-->` with **at least one space or tab on each
  side**, with optional trailing cue settings.
- **BR6.21** **`end > start` strictly.** Times are parsed by splitting on `:` and
  taking seconds, then minutes, then hours (hours defaulting to 0); the parse yields
  a value only if hours is finite **and** `seconds < 60` **and** `minutes < 60`,
  otherwise **not-a-number**. Because the comparison is `end > start`, a
  not-a-number on either side makes the comparison false and **rejects the file**. A
  **zero-duration cue is rejected**. Every cue's payload — `lines[index+1:]` joined
  and trimmed — must be **non-empty**.
- **BR6.22** **At least one cue.** A file with a valid header and **no cues at all is
  rejected**. Any single block failing any of the above rejects the **whole file**.

#### The eight reject conditions as a flat checklist

BR6.14–BR6.22 are described above as a procedure. Restated as the **eight independent
reject conditions** the requirement names, because each needs its own test and a
procedure reads as one path:

| # | Reject when | Rule |
|---|---|---|
| 1 | The bytes are not valid UTF-8 (strict decode throws) | BR6.14 |
| 2 | The text does not match `/^WEBVTT(?:[ \t][^\n]*)?\n/` — including the case of a file that is exactly `WEBVTT` with no trailing newline | BR6.15 |
| 3 | A `\u0000` appears anywhere in the file | BR6.16 |
| 4 | `/<(?:script\|iframe\|object\|embed\|svg\|style)\b/i` matches anywhere in the file | BR6.17 |
| 5 | There are no blocks after the split, **or** block 0 contains `-->` | BR6.18 |
| 6 | A non-`NOTE` block's timing line does not match the timing pattern exactly | BR6.19, BR6.20 |
| 7 | `end > start` is false for any cue — including a not-a-number on either side, and including a zero-duration cue — **or** a cue's payload is empty after joining and trimming | BR6.21 |
| 8 | The file contains a valid header and **no cues at all** | BR6.22 |

Normalisation (BOM strip, `\r\n` and bare `\r` → `\n`) happens **after** the strict
decode in condition 1 and **before** conditions 2–8. Condition 4's blocklist is applied
to the **whole file**, not per cue payload — a `<script` inside a cue identifier, a
`NOTE` comment or the header's trailing text rejects the file exactly as one inside a
payload does.

**Why this is specified rather than delegated:** a permissive VTT library accepts files
this rejects, and the rejection set *is* the behaviour. Reuse-first (C4) does not apply
to an acceptance test whose exact boundary is the requirement — the same reasoning as
BR6.10.

### BR6.23 — variant generation [FR6.5, D24]

- **BR6.23** Responsive image variants are generated **server-side in Python** from
  the uploaded original. The browser no longer prepares them, and the entire
  "verify the browser's prepared variants" surface — the variant envelope check, the
  WebP-only rule, the 1600-pixel ceiling and the aspect-ratio tolerance formula —
  **disappears** rather than being ported. Their error strings are BR10.9.
  **Consequence to carry forward:** the upload response's `sources[]` array is
  populated only when variants exist; in the source it was **empty for any upload the
  browser did not pre-process**, and moving generation server-side changes that
  response for **every** upload.

### BR6.24–BR6.25 — orphan-free failure [FR6.6]

- **BR6.24** Bytes and metadata are **two separate non-transactional writes** with no
  shared transaction. On **any** exception, every key written so far is deleted from
  **both** stores, under a gather-all-results primitive so one failed delete does not
  abort the rest. Cleanup is explicitly **best-effort** — it holds only while the
  handler reaches its cleanup path.
- **BR6.25** **Cleanup never masks the original error.** The response reports why the
  upload failed, not why the cleanup did. Cancellation is checked at **seven** points
  through the write sequence and maps to **499**.

---

## `MediaDelivery`

### BR7.3 — key validation [FR7.1]

- **BR7.3** A key is served only if it matches
  `/^[a-f0-9-]+\.(jpg|png|webp|pdf|mp4|webm|vtt)$/`. A key that does not match is
  **404** — checked first, before any storage access.

### BR7.4–BR7.7 — the asset-visibility rule [hazard, FR7.2]

- **BR7.4 — the rule, exactly.** An asset is **publicly readable if and only if the
  literal string `/api/media/<key>` appears ANYWHERE in the serialised published
  document.** Not "is referenced by the `photo` field", not "appears in a known image
  slot" — **anywhere at all, including inside free prose**: a `transcript` (up to
  60,000 characters), a `description`, the `bio`, the `intro`, the `notice`, or any
  of the nine editable copy blocks. The test is a substring scan over the serialised
  published document.
- **BR7.5 — why a structured field check is NOT equivalent.** Computing public-ness
  from structured fields only (`photo`, item `image`, `imageSources`) makes
  **strictly fewer** assets public. Every image the owner referenced from prose — a
  figure linked inside a description, an image embedded in a transcript — **starts
  returning 404 to visitors**, on a site that renders normally in every other
  respect. The substring rule is not *elegant*; it is *the rule*, and it is
  positional-string-based rather than semantic, which means it silently changes
  meaning if the URL format ever changes (a query string, a CDN prefix). Do not
  "improve" it.
  Two properties the scan verified, so they need not be re-derived: **prefix
  collisions are impossible** (the key pattern forces a `.`-extension suffix and a
  match requires `/api/media/` immediately followed by the *full* key, so
  `/api/media/0.webp` cannot match inside `/api/media/1230.webp`), and **JSON
  escaping is not a problem** (serialisation does not escape `/`).
- **BR7.6 — evaluation order is load-bearing.** Public-ness is evaluated **before**
  the owner check, and the owner check is short-circuited when the asset is public.
  So **a public asset costs no authorization lookup at all**, while **every
  non-public asset request** costs the full published-document read *and then* an
  identity lookup. Reversing the order changes the cost profile of the system's
  hottest path.
- **BR7.7 — three consequences that are preserved, not fixed.**
  (a) **Over-permission through prose** — pasting a draft-only image URL into a
  caption transcript publishes that image. (b) **Publication is indiscriminate** —
  publishing makes public *every* asset URL anywhere in the document, **including
  ones in sections toggled off** via `sections.*`; the visibility toggle hides the
  section from the page, it does **not** make its media private. (c) **No revocation
  and no cleanup** — removing a reference makes the asset non-public again on the
  next request, but neither the bytes nor the metadata row is ever deleted, and there
  is no orphan collection anywhere.

> **What breaks silently.** A structured-field port passes every test written
> against the structured fields, serves the site correctly on every page a reviewer
> opens, and 404s exactly the images that were referenced from prose — a set nobody
> enumerated, discovered only by a visitor.

#### Why a structured field check is not equivalent — stated as a containment argument

BR7.5 is the whole hazard and a paraphrase of it loses the argument, so it is set out
here as a containment relation rather than as advice.

Let **P** be the set of assets the substring rule makes public, and **S** the set a
structured-field check makes public. Every structured field that can hold a media
reference — `photo`, `item.image`, `item.video`, `item.captions`, `item.link`,
`item.code`, `item.dataset`, every `imageSource.src`, `photoSources[].src`,
`sceneStory.link` — is itself part of the serialised document. So every reference a
structured check finds, the substring scan also finds:

> **S ⊆ P, always. The inclusion is strict whenever any reference lives in prose.**

The prose-bearing fields are not marginal. They are, by maximum length: `transcript`
(**60,000** characters, per item, across five collections), every `text` field
(**10,000** characters each — `intro`, `bio`, `notice`, `subtitle`, `description`,
`imageAlt`, `contribution`, `approach`, `outcome`), each `section.description`
(**1,000**) and each `label` (**80**), across all nine copy groups. A media URL is
about thirty characters. Any of these can hold one, and the owner has no reason to
think one place is different from another.

**The direction of the error is what makes it silent.** `S ⊆ P` means a structured
check never makes an asset *wrongly public* — it makes assets *wrongly private*. There
is no security alarm, no log line, no failing authorization test. The symptom is a 404
on a specific image for a specific visitor on a page that is otherwise perfect, and
the affected set is **exactly the set nobody enumerated**, because enumerating it is
what the structured check declined to do.

**The inverse error is not symmetrical and is worth naming.** Widening the rule — for
example scanning the *draft* document as well as the published one — would move assets
the other way, into `P` when they should not be there, and that **is** an authorization
defect. BR7.4 scans the **published** document and nothing else. BR7.1–BR7.2's cache is
a cache **of that same document**, which is why its interval is a security parameter
and not a tuning one.

### BR7.8 — denial discloses nothing [FR7.3]

- **BR7.8** **Every denial is a 404, never a 403.** A malformed key, a missing
  metadata row, missing bytes, and "exists but not public and you are not the owner"
  are **indistinguishable** in the response. The route does not confirm the existence
  of unpublished media. A 403 anywhere on this path is a defect.

### BR7.9–BR7.17 — range handling, branch for branch [hazard, FR7.4]

The standards-compliant implementation is **not** the requirement; the existing one
is. Each branch below needs its own test.

- **BR7.9 — `HEAD` never inspects `Range` [FR7.4.1].** `HEAD` **always** returns
  **200** with the **full** `Content-Length`, and **never** returns 206 or 416 — even
  where the equivalent `GET` would. This is a deliberate early return before any
  range parsing. **`HEAD` and `GET` must not share range logic**, even though the
  source routes them to the same function.
- **BR7.10 — there is NO 304 path [FR7.4.3].** An `ETag` **is** emitted, and
  `If-None-Match` is **not honoured**. Every request is a **full transfer of the
  selected byte range**, and combined with `Cache-Control: private, no-cache` nothing
  is cached. This is a **deliberately preserved behaviour, not an omission to
  correct**. Adding a 304 path would satisfy the phrase "existing semantics" while
  silently changing what visitors and video players receive.
- **BR7.11 — `If-Range` IS honoured [FR7.4.2].** If `If-Range` is present and does
  **not** equal the current `ETag`, the `Range` header is **discarded** and a full
  200 is served. Comparison is **exact string equality** against the stored entity
  tag.
- **BR7.12 — multi-range → 416 [FR7.4.4].** A header requesting more than one range,
  e.g. `bytes=0-1,5-6`, is **not satisfiable**. It is answered neither with the whole
  entity nor with a multipart response. Mechanically, it fails the single-range
  pattern `/^bytes=(\d*)-(\d*)$/` applied to the trimmed value. `bytes=-` (both
  groups empty) likewise → 416.
- **BR7.13 — zero-byte object + ANY range → 416 [FR7.4.5].** If the object size is
  not a safe integer, or is `< 1`, **any** range at all is rejected as not
  satisfiable.
- **BR7.14 — oversized suffix → 206 for the whole object [FR7.4.6].** For `bytes=-N`,
  `N` must be a safe integer **> 0**; then `start = max(0, size - N)` and
  `end = size - 1`. **`N > size` therefore yields the whole object as a 206** — not a
  200.
- **BR7.15 — the start/end asymmetry [FR7.4.7].** For `bytes=S-E`: **reject (416) if
  `start >= size` or `end < start`**; then **`end = min(end, size - 1)`** — so an
  **end beyond the object is SILENTLY CLAMPED** and served as 206. For `bytes=S-`,
  `end = size - 1`. **The asymmetry is intentional and must be reproduced**: a start
  past the end is an error, an end past the end is not. An absent or empty `Range`
  header means no range at all and a full 200.
  The parser returns `{offset: start, length: end - start + 1}`.
- **BR7.16 — the 416 response shape.** On 416 the route sets
  `Content-Range: bytes */<size>` and `Content-Length: 0` with a null body, **but
  retains every other header from the success path — including the `Content-Type`
  and the `ETag`**. It is not a bare error response.
- **BR7.17 — the 206 response shape.**
  `Content-Range: bytes <offset>-<offset+length-1>/<size>` and
  `Content-Length: <length>`. Ranged reads are performed **through the store port**
  (`AssetStore.get_range`), never by loading the whole object and slicing — loading a
  whole video to serve one range is precisely what the port exists to avoid.

> **What breaks silently.** A standards-correct range implementation is *more*
> correct and *differently* behaved. Video players change their buffering strategy
> when a 416 becomes a 200, or when a 304 appears where a full transfer was expected.
> Nothing errors; playback just behaves differently, on a device nobody tested.

#### The seven branches, enumerated against their requirement ids

FR7.4 enumerates seven sub-requirements. Each maps to exactly one rule above, and each
needs its own test under the 100% scoped coverage floor. The table exists so a reader
can check the count rather than trust it.

| # | Requirement | Behaviour | Rule |
|---|---|---|---|
| 1 | **FR7.4.1** | `HEAD` **always** 200 with the full `Content-Length`; **never** inspects `Range`; never 206 and never 416, even where the equivalent `GET` would. HEAD and GET must not share range logic | **BR7.9** |
| 2 | **FR7.4.2** | `If-Range` **is** honoured: present and unequal to the current `ETag` → discard `Range`, serve a full 200. Exact string equality | **BR7.11** |
| 3 | **FR7.4.3** | **No 304 path**, despite an `ETag` being emitted. `If-None-Match` is not honoured; every request is a full transfer of the selected range | **BR7.10** |
| 4 | **FR7.4.4** | **Multi-range → 416.** Neither the whole entity nor a multipart response. `bytes=-` (both groups empty) → 416 as well | **BR7.12** |
| 5 | **FR7.4.5** | **Zero-byte object + ANY range → 416.** Also when the size is not a safe integer | **BR7.13** |
| 6 | **FR7.4.6** | **Oversized suffix → 206 for the whole object**, not 200. `start = max(0, size - N)`, `end = size - 1`, with `N` a safe integer `> 0` | **BR7.14** |
| 7 | **FR7.4.7** | **`start >= size` → 416**, while **`end > size` is SILENTLY CLAMPED** to `size - 1` and served as 206. `end < start` → 416. `bytes=S-` → `end = size - 1` | **BR7.15** |

Two response shapes sit beneath the seven and are not themselves branches: **BR7.16**
(the 416 retains `Content-Type` and `ETag`) and **BR7.17** (the 206 shape, read through
`AssetStore.get_range`). An absent or empty `Range` header is **not** one of the seven
branches — it means no range at all and a full 200 (BR7.15, final sentence).

**Branch 1 is the one a refactor destroys.** `HEAD` and `GET` reach the same handler in
the source. The temptation is to write one function and let `HEAD` fall through with an
empty body — which is what an HTTP framework does by default, and which would make
`HEAD` answer 206 and 416 exactly where `GET` does. The rule is the opposite: `HEAD`
returns **before** range parsing. An implementation must make that early return
structural, not incidental.

### BR7.18 — protective headers [FR7.5]

- **BR7.18** Every successful media response carries, verbatim:
  `Content-Type: <the metadata row's media type>` (**from the metadata store, not
  from the object store**), `Cache-Control: private, no-cache`,
  `X-Content-Type-Options: nosniff`,
  `Content-Security-Policy: default-src 'none'; sandbox`, `Accept-Ranges: bytes`,
  `ETag: <the object's entity tag>`, `Content-Length: <the object's size>`.
  The two stores hold the media type independently and agree only because they are
  written from the same value at upload time; **anything that syncs only one will
  serve mismatched types.**

---

## Consumed from `ContentAuthority` — not owned by this unit

### BR7.1–BR7.2 — the published-document cache [subject to; declared by U4]

Quoted here because `MediaDelivery` is the cache's **only consumer** and its
invalidation correctness is this unit's authorization correctness. **The rules are
owned AND declared by `ContentAuthority` in `u4-content-core`** and are specified
there; nothing in this unit may implement, shadow or second-guess them.

> **Declaration moved at review, by coordinator decision.** These two were declared
> in *this* unit while carrying `owned_by_unit: u4-content-core` and
> `applies_to: ContentAuthority`. They now sit in U4's `rules:` block alongside
> `BR24.1`–`BR24.2`, and **this unit claims no part of `FR7.6`** — it reads *through*
> the cache under `FR7.2` and discharges nothing in `FR7.6`.
>
> **FR7.6 is a split requirement**, which is why it looked for two iterations like
> two units claiming one thing. Clause 1 (*"a short interval … and a publish
> invalidates it"*) is `BR24.1`/`BR24.2`; clause 2 (*"changes which requests hit
> storage, never which assets are public"*) is `BR7.2` almost verbatim; `BR7.1` is
> the placement that makes clause 2 achievable. All four are U4's, under one
> coverage entry.

- **BR7.1** The cache of the published document lives in `ContentAuthority`, not in
  `MediaDelivery`, so that **invalidation never crosses a component boundary** — a
  second reader would silently miss it.
- **BR7.2** The cache changes **which requests hit storage**, never **which assets
  are public**. **A publish invalidates it.** The interval is a **security**
  parameter — a stale cache is an authorization defect — and is **set by U4 as
  `BR24.1` (5 seconds, as a maximum)**, not decided here. It was owned by
  `nfr-design` until that stage was SKIPPED in-flight and the parameter was re-homed
  to `functional-design` **for U4 `content-core`** (`WORKING-RECORD.md` § 10a,
  Condition 1).

---

## Unit-scoped rules — BR25.x

Two rules this unit owns that **trace to no FR**. They are allocated in the unit-scoped
group `BR25.x` (**U5 + 20**) and recorded in the traceability `reverse` array rather
than in `coverage`. Both are real obligations — each would be violated silently, and
neither has an FR that states it.

### BR25.1 — `MediaDelivery` holds no cache of its own [NFR8]

- **BR25.1** `MediaDelivery` holds **no cache**. The only cache on its read path is
  `ContentAuthority`'s (BR7.1, BR7.2). The published document is obtained from
  `ContentAuthority` on every non-public request and discarded; it is **never**
  memoised in this unit at any scope — module-level, instance-level,
  request-independent or LRU.

**Stated as a prohibition because the temptation is structural.** `MediaDelivery`
reads the published document on **every non-public request** (BR7.6), which is the
hottest path in the system and the obvious place to put a cache. **It must not hold
one.** A second cache in this unit would not receive the publish invalidation —
`ContentAuthority` invalidates its own (`construction/functional-design/functional-spec.md`
§ *Save or publish*, step 10) and knows nothing about a cache here — so an asset the
owner unreferenced by publishing would **stay public for the lifetime of this unit's
copy**. That is an **authorization defect** with no error, no log and no failing test
unless one is written for it specifically.

**Why it has no FR.** FR7.2 and FR7.3 — this unit's own visibility requirements — say
nothing about caching. FR7.6, which does, is assigned to **U4** by
`units-generation/traceability.json`. So the obligation on *this* unit falls between
them, which is exactly how an obligation gets lost. **NFR8** is the nearest
requirement: *"Any caching introduced has an explicit invalidation path."* This unit
satisfies it by **introducing none**.

**How it is tested.** Not by a unit test — an absence is not directly assertable.
Assert the **observable** instead: publish a document referencing an asset, request it
(200), publish a document that no longer references it, and request it again in the
**same process** with `ContentAuthority`'s cache invalidated. It must 404 **immediately**,
not after an interval. A local cache in this unit fails that test and nothing else
catches it.

### BR25.2 — CPU-bound work stays off the event loop [`team.md` § Code Style]

- **BR25.2** The two CPU-bound steps in this unit — the hand-written header parse
  (BR6.4–BR6.6) over a fully buffered image, and Pillow variant generation (BR6.23) —
  are dispatched off the event loop with the **same** mechanism the adapters use for
  blocking drivers (`anyio.to_thread.run_sync`). A request handler never performs
  either inline.

**Why it has no FR, and why it still needs an id.** No FR and no NFR states it. The
team rule names the mechanism for **synchronous dependencies wrapped in an adapter**;
this extends it to **CPU-bound code this unit writes itself**, which is a case the rule
does not name and which this unit is the only place in the system to have. BR6.9 makes
the exposure concrete: **images and VTT are buffered in their entirety**, so a 10 MB
image is parsed byte by byte and then decoded by Pillow, on a **single** Python
process, while every other request waits.

**Event-loop blocking is invisible to every check on the merge gate.** It fails no
`ruff`, no `mypy --strict`, no coverage floor and no Compose end-to-end flow — which is
why it has to be a rule rather than something a gate catches.

---

## Assumptions & Open Questions

- **[disposition, open item owned by this unit — now decided here]**
  `WORKING-RECORD.md` § 9 records: *"The upload pre-check tests `content-length` against
  **51 MB** while its own message enumerates 50/10/1 MB. Preserved as-is. Owner: U5
  `media`."* **Disposition: preserved exactly, both numbers, with a test that asserts
  the gap** rather than one that papers over it. The reasoning is in the call-out under
  BR6.13: there is no edit here that is not a parity change — the number is behaviour
  (BR6.12) and the message is product copy (BR10.7, FR10.2). The item is closed as
  *preserved*, not as *resolved*; the inconsistency remains in the shipped system and
  is now documented rather than latent.
- **[assumption, this unit]** The sub-requirement ids **FR7.4.1–FR7.4.7** are used in
  this unit's `traceability.json`. They are defined in
  `inception/requirements-analysis/requirements.md` § FR7.4 but are **not separately
  enumerated** in `inception/units-generation/traceability.json`, which lists only the
  parent `FR7.4` against U5. Using them makes the seven-branch coverage machine-checkable;
  it does not move any assignment. Recorded because it is an addition to the upstream id
  set rather than a reading of it.
- **[assumption, this unit]** **FR6.7** ("upload requires both an authenticated owner
  and a matching request origin") is assigned to **U5** by
  `units-generation/traceability.json`, while the rules that discharge it — **BR3.3,
  BR3.4, BR3.5** — are owned by `HttpApi` per `construction/functional-design/rules.md`
  § *Rule index*. This unit therefore **realises** FR6.7 without **implementing** it:
  the origin and CSRF checks run in `HttpApi`'s middleware ahead of this unit's upload
  operation, and this unit's own authorization obligation is the owner check at its
  operation boundary (BR3.1). The split is recorded rather than reconciled; reconciling
  it would mean moving either the rule or the assignment, and neither belongs to this
  stage.
- **[carried hedge — two literals for the cancellation message, unresolved]** The source
  contains both `Upload cancelled.` and `Upload cancelled. Your previous file is
  unchanged.`. The knowledge base documents only the longer one, attached to the
  `AbortError` catch; the shorter appears to belong to the early `checkCancelled()`
  path. **Which 499 carries which sentence is unconfirmed.** BR6.25 requires cancellation
  to be checked at **seven** points and to map to 499; it does not say the sentence is
  the same at all seven. Resolve against the recorded source fixtures (**U1**, the named
  owner in `WORKING-RECORD.md` § 9) before asserting either in a parity test. Until then
  a parity assertion on the cancellation sentence is unfalsifiable and must not be
  written as though it were settled.
- **[carried hedge — `sources[]` changes for every upload]** BR6.23 records that moving
  variant generation server-side changes the upload response for **every** upload, not
  only for images the browser would have pre-processed. This is a **deliberate**
  consequence of FR6.5 and D24, so a recorded U1 fixture of the *source's* `sources[]`
  is **not** a parity target for the ported response. It remains a valid target for
  every other field of the upload response. Stated so the fixture is not asserted
  wholesale.
- **[note]** BR6.11's ceilings are **mebibytes** (`MB = 1024 * 1024`) and the error
  copy says "MB". Both are preserved: the arithmetic is binary, the sentence is the
  source's sentence. They are not reconciled, for the same reason the 51 MB gap is not.
- **[note]** No rule in this unit requires a background worker, scheduler or queue
  consumer. Variant generation (BR6.23) runs **inside the upload request that triggers
  it**, and cleanup (BR6.24) runs inside the same request's failure path. There is no
  orphan sweep because there is no deletion path (BR7.7c).
- **[note]** This unit holds **no cache**. The only cache on its read path is
  `ContentAuthority`'s (BR7.1, BR7.2 — **declared by U4**), whose interval is **set
  by U4 as `BR24.1`**. It was owned by `nfr-design` until that stage was SKIPPED
  in-flight and the parameter was re-homed to `functional-design` **for U4
  `content-core`** by the re-composition of 2026-09-24 (`WORKING-RECORD.md` § 10a,
  Condition 1). It is not this unit's to set, and this unit must not compensate for
  an unset one by caching locally.

## Sources

- `construction/functional-design/rules.md` — **the authoritative text of every rule
  above**, carried verbatim: § `MediaIntake` BR6.1–BR6.25, § `MediaDelivery`
  BR7.3–BR7.18, § `ContentAuthority` BR7.1–BR7.2. Ids, wording, emphasis and the
  "What breaks silently" notes are reproduced without change; the tables, checklists
  and containment argument added here are restatements of that text for
  per-branch testing and are subordinate to it.
- `construction/functional-design/rules.md` § `HttpApi` BR10.7 — the verbatim upload
  error strings this unit's conditions trigger, and BR10.9 — the four retired
  variant-verification strings.
- `aidlc/spaces/default/codekb/Chiku_website/code-quality-assessment.md` §§ *Hazard
  index*, *The hand-written image header parsers*, *The WebVTT validator*, *The
  byte-range parser*, *The media access rule*.
- `aidlc/spaces/default/codekb/Chiku_website/api-documentation.md` §§ *`POST /api/upload`*,
  *`GET` and `HEAD /api/media/[key]`*, *The public-access rule*.
- `inception/requirements-analysis/requirements.md` — FR6.1–FR6.7, FR7.1–FR7.6
  (including FR7.4.1–FR7.4.7), NFR11.
- `inception/domain-design/components.md` §§ `MediaIntake`, `MediaDelivery` — which
  component owns each rule; `inception/domain-design/decisions.md` ADR-002 (cache
  placement), ADR-004 (why intake and delivery are separate components).
- `inception/contract-design/contract-summary.md` §§ C1 (`/api/upload` and
  `/api/media/{key}` statuses), C2 (`asset_metadata`), C4 (`AssetStore`, and
  `get_range` living **in** the port).
- `inception/units-generation/unit-of-work.md` § *U5 — media* — the unit's boundary and
  its acknowledged review-cadence trade-off.
- `WORKING-RECORD.md` §§ 2 (D12, D24), 3 (hazards FR6.2, FR7.2, FR7.4 and their silent
  failure modes), 9 (the 51 MB open item owned by this unit; the cancellation-literal
  item owned by U1), 10a (Condition 1 — the cache interval re-homed to U4).
