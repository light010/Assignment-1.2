# Rules — U7 `api-client`

**Upstream:** `inception/units-generation/unit-of-work.md`,
`inception/contract-design/contract-summary.md`,
`inception/requirements-analysis/requirements.md`,
`inception/domain-design/components.md`.

This unit realises **FR8.9** and the enforcement half of **NFR1**. FR8.9 keeps its
workflow-level id `BR8.9`, so that trace is real. The remaining four are transport
discipline that realises no `FR`; they take group 27 (U7's unit-scoped group under
the corpus scheme: FR-derived groups are `BR3.x`–`BR10.x`, and a rule realising
only an NFR or a constraint takes **unit number + 20**).

> **Correction.** These four were first written as `CL-` ids to avoid a false
> trace. The concern was right and the fix was wrong: the framework records a rule
> that intentionally has no acceptance criterion in the `reverse` array of
> `traceability.json`, and the traceability sensor does not recognise an invented
> namespace — so ids meant to avoid a false trace produced no trace at all.
> Renumbered to `BR27.x` and listed in `reverse`.

```yaml
rules:
  - id: BR8.9
    statement: Client-side validation is generated from the backend schema, never hand-written.
    category: validation
    applies_to: OperationTypes
    trigger: Any request the editor assembles.
    logic: >
      IF the browser holds a mirror of a validation rule THEN that mirror must be
      generated from the backend's schema document. A hand-written client-side
      validation rule, or a hand-written TypeScript type mirroring a backend model,
      is forbidden. Python remains the authoritative validator for every request
      without exception.
    violation: >
      A hand-written mirror does not fail when it drifts — it starts accepting or
      rejecting something the backend does not, and the first symptom is a
      user-visible disagreement between what the editor says and what the server does.
    source: FR8.9, NFR1

  - id: BR27.1
    statement: The backend error envelope is propagated verbatim.
    category: constraint
    applies_to: OperationTypes
    trigger: Any non-success response.
    logic: >
      IF a response carries the error envelope THEN return its top-level `error`
      field — one human sentence — and, on a validation failure, the `issues` array
      whose entries carry `path` and `message`, all unreshaped, unsummarised and
      untranslated. `message` is a per-entry field INSIDE `issues`; it does not
      exist at the top level. Callers branch on the conflict status and read
      `issues` directly.
    violation: >
      The editor's field highlighting and conflict recovery are built on that exact
      shape. Reshaping here reproduces the FR10.1 hazard one layer further out.
      Reading `message` at the top level yields undefined and silently replaces the
      backend's sentence with the caller's fallback copy — the precise failure this
      rule exists to prevent.
    source: NFR1
    note: >
      The field name is fixed by contract-summary C1 `components.schemas.Error`
      (`required: [error]`) and by the source behaviour this unit preserves:
      madhavi-tripathi/app/edit/editor-workflow.ts:60 reads `result.error`.

  - id: BR27.2
    statement: A mutation is never retried automatically.
    category: policy
    applies_to: OperationTypes
    trigger: A timeout or a 503 on a mutating request.
    logic: IF a mutating request fails for any reason THEN surface the failure and stop. Not on timeout, not on 503.
    violation: >
      A save is not idempotent. A retried publish consumes a revision, and a
      retried draft save can lose a concurrent edit by winning a race it should
      have lost. A human decides whether to try again.
    source: NFR1

  - id: BR27.3
    statement: Every mutating request is same-origin, sends credentials, and carries the CSRF token.
    category: authorization
    applies_to: csrfToken
    trigger: Assembling any mutating request.
    logic: >
      IF a mutating request is assembled without the CSRF token received at sign-in
      THEN it is a defect, not a fallback path. Requests are same-origin and send credentials.
    violation: The backend rejects it with 403, and the editor shows a failure the user cannot act on.
    source: NFR1

  - id: BR27.4
    statement: The generated types are committed, and the merge gate fails if regeneration changes them.
    category: constraint
    applies_to: OperationTypes
    trigger: The merge gate.
    logic: >
      IF regenerating from /openapi.json produces output differing from what is
      committed THEN the gate fails.
    violation: >
      An uncommitted generated artifact makes the boundary check unobservable — the
      types would silently match whatever the backend currently is, which is the one
      thing this unit exists to prevent.
    source: NFR1

  - id: BR27.5
    statement: The merge gate fails if any hand-authored frontend file declares a backend payload shape or a validation rule.
    category: constraint
    applies_to: OperationTypes
    trigger: The merge gate.
    logic: >
      IF any `.ts`/`.tsx` file under the frontend tree other than the generated
      module either (a) imports a schema-validation library or constructs a schema
      value from one, or (b) declares an `interface` or `type` whose name matches an
      exported name of the generated module, THEN the gate fails. Backend payload
      shapes reach components by importing from the generated module and by no other
      route. A file that must be excepted is listed, with its reason, in the same
      committed allowlist the gate reads — never excepted silently.
    violation: >
      BR27.4 re-derives the generated file and diffs it against itself, so it proves
      that ONE file is current; it cannot see a second, hand-written definition
      sitting beside it. Without this rule BR8.9's "no second definition" clause has
      no mechanical enforcement at all, which is the same unfalsifiable-claim failure
      team.md's boundary grep was written to close for `'use server'`.
    source: NFR1
    note: >
      This is the check R-02 found missing. It is deliberately shaped like the
      existing boundary grep — a command that fails, not a convention — because an
      ESLint rule is a nicer editor experience but the grep is the one that is
      certain. The allowlist exists so an exception is a visible commit rather than
      a quiet omission.
```

## Rules summary

| id | Category | What it protects | Source |
|---|---|---|---|
| BR8.9 | validation | No hand-written validation mirror in the browser | FR8.9, NFR1 |
| BR27.1 | constraint | Error envelope propagated verbatim, top-level field `error` | NFR1 |
| BR27.2 | policy | No automatic retry of a non-idempotent mutation | NFR1 |
| BR27.3 | authorization | Credentials and CSRF on every mutation | NFR1 |
| BR27.4 | constraint | Generated types committed and gate-checked | NFR1 |
| BR27.5 | constraint | No second, hand-written definition anywhere in the frontend | NFR1 |

## Why each rule exists

The YAML block above is the source of truth. These notes carry the failure mode
behind each rule.

### BR8.9 — Client-side validation is generated, never written

**Owner:** U7. **Realises:** FR8.9, and `discovered-rules.md` § Forbidden.

**Rule:** the browser may hold a mirror of the validation rules **only** when that
mirror is generated from the backend's schema document. A hand-written client-side
validation rule, or a hand-written TypeScript type mirroring a backend model, is
forbidden. Python remains the authoritative validator for every request without
exception.

**What breaks silently if got wrong:** a hand-written mirror does not fail when it
drifts — it simply starts accepting or rejecting something the backend does not,
and the first symptom is a user-visible disagreement between what the editor says
and what the server does.

### BR27.1 — Propagate the error envelope unchanged

**Rule:** the transport returns the backend's envelope verbatim — the top-level
**`error`** field, one human sentence, and, on a validation failure, the `issues`
array whose entries carry `path` and `message`. It does not reshape, summarise, or
translate it. Callers branch on the conflict status and read `issues` directly.

**The field is `error`, not `message`.** `message` exists only per-entry inside
`issues`; there is no top-level `message`. Contract-summary C1
`components.schemas.Error` declares `required: [error]`, and the source this unit
must keep working reads exactly that — `editor-workflow.ts:60` throws
`new Error(result.error||'The draft could not be saved. Please try again.')`. A
transport that reads `message` at the top level gets `undefined` on every failure
and silently substitutes the caller's fallback copy for the backend's sentence,
which looks like working software and is the precise loss this rule prevents.

**Why:** the editor's field highlighting and conflict recovery are built on that
exact shape. Any reshaping here reproduces the FR10.1 hazard one layer further out.

### BR27.2 — Never retry a mutation

**Rule:** the client retries nothing automatically. Not on timeout, not on 503.

**Why:** a save is not idempotent. A retried publish consumes a revision, and a
retried draft save can lose a concurrent edit by winning a race it should have
lost. A human decides whether to try again.

### BR27.3 — Credentials and CSRF on every mutation

**Rule:** requests are same-origin and send credentials. Every mutating request
carries the CSRF token received at sign-in. A mutation assembled without it is a
defect, not a fallback.

### BR27.4 — The generated output is committed and gate-checked

**Rule:** the generated types are committed to the repository. The merge gate
regenerates them and **fails if the result differs from what is committed**.

**Why:** an uncommitted generated artifact makes the boundary check unobservable —
the types would silently match whatever the backend currently is, which is the one
thing this unit exists to prevent.

### BR27.5 — No second definition anywhere else in the frontend

**Rule:** the merge gate fails if any hand-authored `.ts`/`.tsx` file under the
frontend tree, other than the generated module, imports or constructs a
schema-validation value, or declares an `interface`/`type` whose name matches an
exported name of the generated module. Exceptions are listed with their reason in
a committed allowlist the gate reads.

**Why BR27.4 does not already cover this.** BR27.4 regenerates the committed file
and diffs it **against itself**. That proves the one file it inspects is current;
it is structurally blind to a second file that mirrors a backend shape without
ever touching the generated one. BR8.9 forbids the second definition, and until
this rule existed nothing in the unit could detect it — the enforcement was
declared rather than performed, which is exactly the gap `team.md` closed for
`'use server'` with a grep rather than a convention.

**Scope note.** The generated module is the only place a backend shape or a
validation rule may live in the browser, so the check is strict by design; the
allowlist is what keeps a legitimate exception a visible commit rather than a
quiet erosion.

## Assumptions & Open Questions

- **[assumption]** Same-origin routing removes the need for CORS configuration
  entirely. If the origins ever differ, cookie attributes and CORS both become
  live concerns, and a cross-site session cookie is unreliable under
  third-party-cookie restrictions — which is why same-origin was chosen.
