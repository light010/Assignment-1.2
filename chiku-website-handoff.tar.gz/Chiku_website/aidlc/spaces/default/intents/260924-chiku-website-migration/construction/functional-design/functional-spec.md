# Functional Specification — chiku-website runtime-split migration

**Upstream:** `inception/requirements-analysis/requirements.md`,
`inception/domain-design/components.md`,
`inception/contract-design/contract-summary.md`,
`inception/units-generation/unit-of-work.md`,
`construction/functional-design/entities.md`,
`construction/functional-design/rules.md`,
`construction/functional-design/frontend-components.md`.

How each operation behaves end to end. Entity shapes are in `entities.md`;
business rules carry `BR` ids in `rules.md`; this document is the flow that binds
them.

**The standard these three files must meet:** a developer implements from them
without re-reading `madhavi-tripathi/`. Every point where a reader would have to
go back is a defect.

## Module layout

```
chiku-website/
  backend/
    app/
      main.py              # composition root: settings, lifespan, router mount
      settings.py          # env-backed config. SESSION_SIGNING_KEY absent => startup failure
      errors.py            # the four-member taxonomy and the single envelope handler
      content/             # U4 — schema, service, the combined write, the cache
      identity/            # U3 — owner, sessions, login guard
      media/               # U5 — intake and delivery
      stores/              # U2 — the three ports, SQLite adapters, in-memory fakes
      stores_cloud/        # U11 — Firestore and Cloud Storage adapters
      routers/             # U6 — thin handlers. NEVER imports a store (AST-tested)
      cli.py               # create-admin, and the fixture recorder
    tests/
  frontend/                # U7, U8, U9
  compose.yaml             # U10
  docs/deployment-plan.md  # U12
```

Feature modules are named for the domain thing they own — `content`, `identity`,
`media` — never for a layer. There is no `services/`, no `helpers/`, no
`repositories/`. **A layer exists only when it has a job.**

## Cross-cutting behaviour

**Error envelope (BR for FR10.1, hazard).** Every failure returns
`{"error": "<one sentence>"}`, plus `"issues": [{"path": [...], "message": "..."}]`
on validation failure. Produced by **exception handlers**, never constructed in a
route. Services raise `NotAuthorized` → 403, `Conflict` → 409, `TooLarge` → 413,
`Invalid` → 400 (carrying issues), anything else → **503** with
`logger.exception()`. 503 rather than 500 matches the original. The error strings
are **product copy** and fall under the parity rule — a port that rewrites one has
changed what the owner sees.

**Async.** Handlers and services are `async`. The SQLite adapter wraps its
synchronous driver in `anyio.to_thread.run_sync` **inside the adapter**; a handler
or service never touches a blocking driver. Event-loop blocking is invisible to
every check on the merge gate, which is why it is a rule rather than something a
gate catches.

**Wire format.** `camelCase`, frozen. One conversion point: a shared Pydantic base
with `alias_generator=to_camel` and `populate_by_name=True`.

**Same-origin.** Mutating operations require a matching `Origin` and the CSRF token
paired with the session. A missing `Origin` header **fails closed**.

## Operations

### Sign in — `POST /api/auth/login`

1. Read the rate-limit windows for this account and this source address. If either
   is exhausted, return the **same** 403 body as a credential failure — no
   enumeration, no distinct message, no timing branch before the hash.
2. Look up the owner record. **Always** run an argon2id verification, against a
   dummy hash when no owner exists, so absence and wrong-password cost the same.
3. On failure: record the failure against both windows, return 403.
4. On success: clear this account's window, create a `Session` with `issuedAt`,
   `lastSeenAt`, `absoluteExpiresAt` = now + 7 days, and a CSRF token. Set the
   signed cookie `HttpOnly; Secure; SameSite=Lax`. Return the CSRF token in the body.

### Every authenticated request

1. Read and verify the cookie signature. Invalid → treat as anonymous.
2. Load the session. Absent, revoked, `lastSeenAt` older than 8 hours, or past
   `absoluteExpiresAt` → anonymous, and the record is deleted if expired.
3. Otherwise advance `lastSeenAt` (the sliding window) **without** touching
   `absoluteExpiresAt`.
4. For a mutation, compare the request's CSRF header with the session's token;
   mismatch → 403.

### Read content — `GET /api/content` (owner) and `GET /api/public/content`

The public read returns the published document only and is unauthenticated. The
owner read returns draft, published, revision, both timestamps and
`hasUnpublishedChanges`, computed as `draft != published` by value.

Both parse the stored document through the schema, which is what applies the
**content-carrying defaults** (BR for FR9.2, hazard) — an absent research topic
resolves through the id map and otherwise to `general`; absent research links
resolve through the seeded map; an **explicitly emptied list stays empty**.

### Save or publish — `PUT /api/content` (the hazard-dense path)

1. Origin check → 403 on mismatch.
2. Session check → 403 if not the owner.
3. Read the raw body as text. If its **character** count exceeds 1,500,000 → 413.
   **Characters, not bytes** (BR for FR4.6) — the original used JavaScript's
   `.length`, and a byte cap would reject documents it accepts.
4. Parse JSON → 400 on failure, distinctly from a validation failure.
5. Validate `body.content` through the schema. On failure → 400 carrying `issues`.
6. Validate the envelope: `revision` a safe non-negative integer, `action` one of
   `draft`/`publish`, `autosave` boolean and only with `action=draft`.
7. Mint a `mutation_token` — random, unique to this request.
8. Call `ContentStore.commit(...)` with content, base revision, action, the token,
   and the retention policy `RevisionLedger` supplies. **One call, one caller, one
   transaction** carrying the content update, the revision entry and the prune
   together (BR for FR4.5, hazard).
9. Conflict → 409 with current state; the caller's edits are untouched.
10. On success, if `action=publish`, **invalidate the published-document cache**.
    Return the new revision and timestamps.

### Inspect a recovered draft — `POST /api/content/inspect`

The rule that used to live in the browser (ADR-006). Validates the candidate and
returns the normalised document plus each issue classified **recoverable** or
**corrupting** (BR for FR8.3, hazard). Recoverable is what an owner produces by
typing — present, correctly typed, outside its permitted set or range, **including
an out-of-set enumerated value**. Corrupting is a malformed record. Owner-only.

### Revision history — `GET /api/history`

Without `id`: summaries ordered **revision DESC, baseline ASC, action DESC**
(BR for FR5.1) — a three-part sort that is load-bearing for display order — capped
at the current limit. With `id`: validate the id pattern → 400; return the entry or
404 stating the current draft is unaffected. Restoring loads into the editor and
**never publishes**.

### Upload — `POST /api/upload`

Origin and session first. Then, in order: reject on declared content-length over
the largest ceiling → 413; read the multipart; reject an empty file → 400;
determine the kind **from the file's own bytes** (BR for FR6.2, hazard) — never
from the declared type or extension; reject an unsupported kind → 400; enforce the
per-kind ceiling (50 MB video, 10 MB image and PDF, 1 MB captions) → 413; validate a
caption track as well-formed timed text with at least one cue → 400; generate the
responsive variants **in Python** with Pillow; write the original and each variant
through `AssetStore`; register metadata through `ContentStore`.

**On any failure or cancellation**, remove every object and row already written,
best-effort, and never let cleanup mask the original error. Cancellation → 499.

### Serve media — `GET|HEAD /api/media/{key}`

1. Key must match the pattern → 404.
2. Obtain the published document from `ContentAuthority` (served from its
   short-lived cache).
3. **Public iff the literal `/api/media/{key}` appears anywhere in the serialised
   published document** (BR for FR7.2, hazard) — including inside a transcript, the
   biography, any description, the notice, or any copy block. A structured field
   check is **not** equivalent: it makes strictly fewer assets public, so an image
   referenced from prose starts 404-ing.
4. Not public and not the owner → **404, not 403**, so the response does not
   disclose that the key exists.
5. `HEAD` → **always 200** with the full `Content-Length`; it **never inspects
   `Range`** and never returns 206 or 416. HEAD and GET must not share range logic.
6. `GET` applies all seven range branches (BR for FR7.4, hazard), including the
   deliberate absence of a 304 path despite an ETag being emitted.
7. Headers: `Content-Type` from stored metadata, `Cache-Control: private, no-cache`,
   `X-Content-Type-Options: nosniff`, `Content-Security-Policy: default-src 'none'; sandbox`,
   `Accept-Ranges: bytes`, `ETag`.

### Owner provisioning — CLI and one-shot route

`python -m app.cli create-admin` is the normal path: prompts for email and
password, stores only the argon2id hash, refuses if an owner already exists.

For a container with no interactive shell, a **one-shot route** is enabled only
while no owner record exists **and** `ADMIN_BOOTSTRAP_SECRET` is set. The gate is
**the record's existence**, not a consumed flag, so restarting cannot reopen it.
With no secret and no owner, the service starts and refuses every sign-in.

**Acceptance test for FR3.7:** a fresh `docker compose up` against an empty volume
has **no account anyone can sign in to**.

### Startup

Load settings. If `SESSION_SIGNING_KEY` is unset, empty, or under 32 bytes → raise
during startup naming the variable and exit non-zero. **No default, and explicitly
no auto-generated per-process key** — that would look like it works while silently
invalidating every session on restart, which is the worse failure. Run migrations.
Seed the content document if absent. Never seed an owner.

## Public rendering

`GET /` server-renders from `GET /api/public/content`, derives title, description,
Open Graph, Twitter card and `ProfilePage` JSON-LD from that content, and escapes
`<` in the serialised structured data. A validation failure renders the existing
"temporarily unavailable" page rather than an error. `canEdit` comes from a
client-side session check after hydration, so **no admin signal appears in public
HTML**.

## Assumptions & Open Questions

- **[open, this stage]** Whether the editor's multi-flag save state machine holds a
  rule rather than presentation state. Position taken in `frontend-components.md`:
  presentation state. If wrong, that part crosses to Python and a browser-driven
  check becomes mandatory.
- **[assumption]** `hasUnpublishedChanges` compares draft and published **by
  value**. The original compared serialised JSON, which is key-order sensitive;
  value comparison is equivalent here because both sides are produced by the same
  schema.
- **[assumption]** The dummy-hash verification on an unknown account is sufficient
  to avoid a timing oracle. It is not separately measured; it is the standard
  mitigation.
