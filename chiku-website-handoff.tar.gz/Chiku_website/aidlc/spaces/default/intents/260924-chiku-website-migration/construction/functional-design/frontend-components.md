# Frontend Components — chiku-website runtime-split migration

**Upstream:** `inception/domain-design/components.md`,
`inception/requirements-analysis/requirements.md`,
`inception/contract-design/contract-summary.md`,
`codekb/Chiku_website/component-inventory.md`,
`inception/units-generation/unit-of-work.md`.

Three frontend units: `U7 api-client`, `U8 public-site`, `U9 owner-editor`.
**None of them decides anything.** Every component here renders, holds local
presentation state, or transports — and where a reader might think otherwise,
this document says so explicitly.

## What carries across, and in what state

| Category | Count | Disposition |
|---|---|---|
| Route components | 4 | Ported, rewired from direct database access to the generated client |
| Exported presentation components | 13 | Ported byte-identical |
| Private components | 19 | Ported byte-identical with their parents |
| Vendored `components/ui/*` | **11 imported** of 61 | Only the imported ones cross, with their MIT notice |
| Vendored, unreachable | **49** (6,139 lines) | **Do not cross** |
| CSS files | 9 (~1,124 lines) | Ported byte-identical |
| Public assets | favicon, `academic-flow.webp`, Inter woff2 | Ported |
| Retired | `chatgpt-auth.ts`, `server.ts`, `content-persistence.ts`, `upload-validation.ts`, `image-processing.ts`, `media-utils.ts`, all four `app/api/**` route handlers, `db/`, `drizzle/` | Logic moves to Python |

## The file-as-unit rule

Every ported file is in exactly one of two states, and **the file is the unit** —
not the edited region, because "untouched region" is not a property any tool can
evaluate.

- **Unmodified** — byte-identical to its `madhavi-tripathi/` original except
  import specifiers and the rewired data-access call. Keeps the dense house style
  entirely.
- **Modified** — listed in `chiku-website/frontend/PORTED-MODIFIED.md` with one
  line saying what changed and why, and then the **whole file** is formatted
  conventionally.

The merge gate runs `git diff --no-index` for every file **not** on that list and
fails if any hunk is neither an import nor a data-access call. The source tree
stays in the repository, so this costs nothing to run.

**Two files cannot be unmodified and go on the list on day one:** `server.ts`
hard-codes `OWNER_EMAIL`, and `site-metadata.ts` hard-codes `siteOrigin`. Both are
environment-dependent literals the construction rules forbid carrying forward.

## U7 — api-client

| Component | Responsibility | Notes |
|---|---|---|
| Generated types | Every request and response shape | Produced by `openapi-typescript` from the backend's `/openapi.json`, **committed**, regenerated at the merge gate. The gate fails if the committed output is dirty — which is what makes a backend field rename fail `tsc --noEmit` with a file and a line |
| Transport | `fetch` wrapper | Same-origin. Sends credentials; attaches the CSRF token to every mutation; **propagates the error envelope unchanged** so callers can branch on 409 and read `issues[]` |
| — | **No** hand-written type mirroring a backend model | Forbidden by `discovered-rules.md` § Forbidden |
| — | **No** caching, **no** retry | A mutation is not idempotent; a retried publish consumes a revision |

This is the single crossing point of the language boundary. The gate's grep asserts
nothing else in `frontend/` performs a backend call, contains `'use server'`, defines
`app/**/route.ts`, or defines `middleware.ts`.

## U8 — public-site

| Component | Source | State |
|---|---|---|
| `app/page.tsx` | route | **Rewired** — server-renders from `GET /api/public/content` instead of reading the database. Still derives metadata and JSON-LD from the same content |
| `app/site.tsx` | `AcademicSite` | Byte-identical. Already takes `content`, `canEdit`, `preview` as props |
| `achievements.tsx`, `publications.tsx`, `research-section.tsx`, `updates.tsx` | sections | Byte-identical |
| `scene.tsx`, `nano-renderer.ts`, `scene-content.ts`, `scene-performance.ts` | 3D | Byte-identical. The ~560 kB chunk is a known issue, **deliberately not addressed** |
| `responsive-image.tsx`, `use-section-carousel.ts`, `publication-utils.ts` | helpers | Byte-identical |
| `color-mode.tsx` | appearance | Byte-identical |
| `site-metadata.ts` | SEO | **Modified** — `siteOrigin` becomes configuration |
| `robots.ts`, `sitemap.ts` | discoverability | **Rewired** to read published metadata through the client; origin from configuration |
| 9 CSS files | styling | Byte-identical |
| **The 11 vendored `components/ui`** | shared | Byte-identical, **carried by U8** and consumed by U9. Their MIT notice travels with them |

**`canEdit` changes shape.** Today the server derives it while rendering. It now
comes from a client-side `GET /api/auth/session` call after hydration, so the
public HTML contains no admin signal at all — which satisfies NFR11 better than the
original did, without moving anything visually.

**The one agreed behavioural change** lives here: the achievements and updates
carousels currently use native `disabled` on their Next/Previous controls, so at an
endpoint focus drops to `<body>` and arrow-key navigation stops. Replace with
guarded `aria-disabled` controls that retain focus. This file goes on
`PORTED-MODIFIED.md`.

## U9 — owner-editor

| Component | Source | State |
|---|---|---|
| `app/edit/page.tsx` | route | **Rewired** — becomes a client shell. No server-side auth gate; the browser fetches with credentials and a 401/403 redirects to sign-in |
| `app/edit/editor.tsx` | the editor | **Modified** — tab set, fields and layout byte-identical; the `/api/history` call goes through the client |
| `app/edit/editor-workflow.ts` | state machine | **Modified** — see below |
| `app/edit/upload-field.tsx` | uploads | **Modified** — no longer prepares WebP variants in the browser; uploads the original and lets Python derive variants |
| `app/edit/draft-preview.tsx` | preview | Byte-identical |
| `app/edit/preview/page.tsx`, `preview-client.tsx` | preview route | **Rewired** — client shell; the `postMessage` protocol and origin check are unchanged |
| New: `app/login/page.tsx` | sign-in | **New file**, conventional style |

### The recovery flow — three states, not two

FR8.3 is hazard-marked and **the classification rule is no longer here** (ADR-006).
The editor holds the bytes; `ContentAuthority` decides.

1. **Recoverable** — `POST /api/content/inspect` returns issues all marked
   recoverable. Offer the repaired draft for review. Autosave stays **paused**
   until the owner explicitly saves (FR8.3.4).
2. **Corrupting** — the response marks an issue corrupting. Report the stored draft
   unusable and continue with the server draft.
3. **Unclassifiable** — the inspect request **fails or the backend is unreachable**.
   **Hold** the draft, show an unavailable-and-retry state, and **never discard it**.
   Silently discarding on a transport failure would reproduce exactly the class of
   loss this requirement exists to prevent.

Per-tab storage keys are unchanged: each mounted editor owns its own recovery
record, so a clean second tab never clears another tab's unfinished work.

### Client-side validation

`contentSchema.safeParse` is **removed**. Three call sites change:

- **Pre-save validation** → the backend's `issues[]`, which the editor already renders.
- **Draft-recovery normalisation** → `POST /api/content/inspect`.
- **Preview validation** → the preview renders what the editor holds; the backend
  validated it at save.

`zod` leaves the frontend dependency list. Only **generated** constraints may inform
client-side UX, never a hand-written mirror.

### The browser tool

`stage_academic_profile` on `document.modelContext` is **preserved unchanged**. It
stages six profile string fields into the form, validates key names and lengths,
and **never saves and never publishes**. It survives the language boundary because
it mutates local form state only; Python still validates every save.

## Accessibility (NFR7)

Permitted **only where nothing moves visually**: heading order, labels, ARIA
attributes, focus handling, contrast tokens, reduced-motion support. Every such
change puts the file on `PORTED-MODIFIED.md` with its reason. No conformance claim
is made beyond what is tested.

## Parity verification

Normalised DOM-structure diff against the fixtures recorded in B1 — strip volatile
attributes, build hashes and whitespace, then diff element tree and text content per
route — plus a page-by-page human review at the end. **Pixel screenshot comparison
was considered and rejected**, not deferred: brittle against fonts, antialiasing and
animation.

A byte-identical component given identical props cannot render differently, so the
parity surface concentrates in `PORTED-MODIFIED.md` plus the CSS — a small enough
set for the human pass to cover by eye.

## Assumptions & Open Questions

- **[resolved, this stage]** Whether the editor's multi-flag save state machine
  contains a **rule** rather than presentation state. **Resolved: it is presentation
  state.** Every flag gates a UI affordance and none changes what the backend does —
  there is nowhere in Python to put it. U9 carries the per-flag adjudication, and
  found the implemented machine has **four** suspensions where FR8.2 names three
  (`editor-workflow.ts:66` sets `paused` on *any* failed write, not only after a
  restore), disclosed there as a divergence.

  **Consequence: Playwright is mandatory, not optional.** `team.md` § *Testing
  Posture* states the condition as *"if the six-flag editor state machine lands in
  the **frontend** rather than the backend, a browser check becomes the only
  possible verification of it and becomes mandatory"* — frontend implies mandatory,
  and the machine stays in the frontend.

  **Correction, recorded rather than silently overwritten.** An earlier revision of
  this bullet stated that conditional **backwards**: it said a rule *crossing to
  Python* would make a browser check mandatory. That is wrong in both directions —
  a rule that crosses to Python becomes testable by pytest and needs **no** browser
  at all, which ADR-006 then demonstrated for the one rule that did cross. The
  inversion is kept on the record because
  `construction/owner-editor/functional-design/functional-spec.md` cites this file
  **by name** as the place the condition was stated backwards; deleting it would
  orphan that citation.
- **[resolved]** *"The 11 vendored components carried by U8 are exactly the imported
  set. A missed import surfaces at `tsc --noEmit`, cheaply."* **Withdrawn — the set
  is twelve.** `button.tsx` is imported by four of the eleven (`alert-dialog:7`,
  `select:6`, `dialog:10`, `carousel:8`) and by no file under `app/`, so a
  direct-import count cannot see it; 61 vendored files minus 49 unreachable is 12,
  which is the arithmetic that exposed it. The reasoning was also wrong, not just
  the number: deferring to `tsc --noEmit` would have caught the build break but
  never the **MIT attribution obligation** that travels with the file, which no
  compiler reports. U8's `frontend-components.md` carries the full enumeration and
  the transitive closure, which also reaches **outside** `components/ui/` to
  `lib/utils.ts`, `postcss.config.mjs` and `components.json`.
- **[assumption]** Removing browser-side variant preparation changes no
  visitor-visible behaviour, because the same variant sizes are produced — just in
  Python. If Pillow's output differs perceptibly from Canvas's, that is a parity
  question the DOM diff will not catch and the human pass must.
