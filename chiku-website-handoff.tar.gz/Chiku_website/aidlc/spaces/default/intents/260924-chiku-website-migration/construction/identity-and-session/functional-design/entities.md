# Entities — U3 `identity-and-session`

**Unit:** `identity-and-session` · **Kind:** `library`

**Upstream:** `construction/functional-design/entities.md` §§ ENT-1, ENT-2, ENT-3,
`inception/requirements-analysis/requirements.md` FR3.1–FR3.7,
`inception/contract-design/contract-summary.md` § C3,
`inception/units-generation/unit-of-work.md` § U3,
`WORKING-RECORD.md` § 2 (D1, D2, D3, D6).

## How to read this document

This unit owns **three entities**, and **all three are new**. The source system
had no authentication of its own — it relied on a platform header — so nothing
here is a parity obligation and nothing here is inherited. Every shape below
follows from confirmed decisions D1–D3, D6 and from FR3.1–FR3.7.

**That "new" matters in both directions.** There is no source behaviour to
reproduce, so a cleaner design costs nothing; but there is also **no recorded
fixture to check against**, so every constraint below is a decision, and where a
bound was never decided it is recorded in `## Assumptions & Open Questions`
rather than invented silently here.

| ID | Entity | Owning component | Nature |
|---|---|---|---|
| ENT-1 | `OwnerAccount` | `OwnerIdentity` | **New** — the source had no authentication of its own |
| ENT-2 | `Session` | `SessionAuthority` | **New** |
| ENT-3 | `LoginAttemptWindow` | `LoginGuard` | **New** |

## Source of truth — the three entities

The block below is **authoritative for this unit**; the prose sections that follow
are the human-readable summary. Field names are the frozen `camelCase` wire
spelling; the Python attribute is the `snake_case` form of the same name, produced
by the one shared conversion point.

```yaml
source_of_truth: entities
stage: functional-design
unit: u3-identity-and-session
kind: library
kind_note: >
  U3 identity-and-session is a LIBRARY, not a service. U6 http-api is the only unit
  declaring service - there is exactly one deployed Python executable. This unit is
  embedded in it and is not independently deployable.
authority: >
  This block is the source of truth and governs. The prose below carries the
  summary, the rationale and the failure mode for each entity, and must not
  contradict it.
components: [OwnerIdentity, SessionAuthority, LoginGuard]
entity_count: 3
nature_note: >
  All three entities are NEW. The source authenticated through a platform header and
  had no identity of its own, so there is no parity obligation here and no recorded
  source fixture - and none can be made. Every constraint below is a decision, not an
  observation.
wire_format_note: >
  Field names are the frozen camelCase wire spelling. The Python attribute is the
  snake_case form of the same name, produced by the one shared conversion point.
entities:

  - id: ENT-1
    name: OwnerAccount
    owned_by: OwnerIdentity
    nature: new          # the source had no authentication of its own
    cardinality: singleton
    description: >
      The one site owner and the argon2id hash of their password. Exactly one row
      ever exists; there are no multi-editor accounts and no tiered roles. Nothing
      here is a parity obligation, and no recorded source fixture exists for it.
    attributes:
      - name: ownerId
        type: string
        required: true
        unique: true
        constraints: "Opaque identifier, generated at provisioning. NEVER derived from the email."
      - name: email
        type: string
        required: true
        max: 200
        pattern: "^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$"
        constraints: "Not trimmed. Bound and pattern carried from the content schema's email rule - see assumption A-1."
      - name: passwordHash
        type: string
        required: true
        constraints: >
          An argon2id PHC-encoded hash string, stored verbatim. Application code never parses
          it. The plaintext password is never stored, never logged, and never returned by any
          operation.
      - name: createdAt
        type: instant-iso8601-utc
        required: true
      - name: passwordUpdatedAt
        type: instant-iso8601-utc
        required: false
        default: null
        constraints: "Null until the password is first changed after provisioning."
    entity_constraints:
      - "Exactly one row ever exists. Do not model a collection."
      - "No default, seeded, sample or hard-coded credential exists in any form. A fresh start against empty storage has no account anyone can sign in to."
      - "The owner's email is backend-only runtime configuration and must never appear as a publicly-inlined build-time variable."
    persistence: "IdentityStore.owner_record - read, create_if_absent"
    relationships:
      - { to: Session, cardinality: "1 : 0..n", direction: "an OwnerAccount issues Sessions" }
      - { to: LoginAttemptWindow, cardinality: "1 : 0..n", direction: "an account-scoped window counts failures against an OwnerAccount - or against an email that matches none" }

  - id: ENT-2
    name: Session
    owned_by: SessionAuthority
    nature: new
    cardinality: collection
    description: >
      One issued session. Stores both expiry bounds separately so the idle window
      can slide without extending the absolute one, and carries the CSRF token
      paired 1:1 with it.
    attributes:
      - name: sessionId
        type: string
        required: true
        unique: true
        constraints: "Opaque, unguessable, from a cryptographic RNG. NEVER derived from ownerId or from any user-supplied value."
      - name: ownerId
        type: string
        required: true
        references: OwnerAccount.ownerId
        constraints: "Each Session belongs to exactly one OwnerAccount."
      - name: issuedAt
        type: instant-iso8601-utc
        required: true
        constraints: "Set once at issue and never changed."
      - name: lastSeenAt
        type: instant-iso8601-utc
        required: true
        default: "issuedAt at creation"
        constraints: "Advanced on each verified request - the sliding idle window."
      - name: absoluteExpiresAt
        type: instant-iso8601-utc
        required: true
        default: "issuedAt + 7 days"
        constraints: "Computed ONCE at issue and NEVER extended by activity."
      - name: revokedAt
        type: instant-iso8601-utc
        required: false
        default: null
        constraints: "Non-null means revoked server-side; such a session fails verification regardless of its other fields."
      - name: csrfToken
        type: string
        required: true
        constraints: >
          Opaque, unguessable, from a cryptographic RNG, paired 1:1 with this session. Returned
          in the sign-in response body and echoed back as a request header on mutations
          (double-submit). NEVER carried in a cookie.
    entity_constraints:
      - "Two independent expiry bounds, both enforced: 8 hours idle measured from lastSeenAt, and 7 days absolute measured from issuedAt. Whichever is reached first ends the session."
      - "The cookie carries the sessionId only. No field is encoded into it and no claim in it is trusted; verification is a server-side record read every time."
      - "The cookie is signed and marked HttpOnly, Secure, SameSite=Lax."
      - "touch advances lastSeenAt WITHOUT extending absoluteExpiresAt - that asymmetry is the whole point of storing both."
    persistence: "IdentityStore.session - create, read, touch, revoke"
    relationships:
      - { to: OwnerAccount, cardinality: "0..n : 1", direction: "belongs to" }

  - id: ENT-3
    name: LoginAttemptWindow
    owned_by: LoginGuard
    nature: new
    cardinality: collection
    description: >
      One rolling failure window for one counted subject in one scope. Two
      independent counters exist per failed sign-in - one keyed by account, one by
      source address - as separate rows with separate scopes, never one row with
      two counters.
    attributes:
      - name: windowKey
        type: string
        required: true
        constraints: >
          Identity together with scope. For scope = account it is ALWAYS the submitted email,
          normalised (trimmed and lower-cased) - never the account identifier, and the same
          value whether or not an account matches. For scope = ip it is the source address.
      - name: scope
        type: enum
        required: true
        allowed_values: [account, ip]
        constraints: "Identity together with windowKey."
      - name: failureCount
        type: integer
        required: true
        default: 0
        min: 0
        constraints: "Incremented on each failed attempt within the window."
      - name: windowStartedAt
        type: instant-iso8601-utc
        required: true
        constraints: "The instant at which the current rolling window began."
    entity_constraints:
      - "Thresholds over a 15-minute rolling window: refuse beyond 5 failures for scope = account, and beyond 20 failures for scope = ip. The two apply independently and both apply."
      - "Counters are PERSISTED, so a restart does not reset a window."
      - "Nothing about this entity is visible to a caller: no too-many-attempts field, no retry-after value, no remaining-attempts count - any of the three would enumerate."
    persistence: "IdentityStore.login_attempts - record_failure, count_in_window, clear"
    relationships:
      - { to: OwnerAccount, cardinality: "0..n : 0..1", direction: "an account-scoped window may key on an account that does not exist" }
```

**Exactly one site owner edits this site.** The initial brief's "a few
administrators" is superseded by the confirmed intent. There are **no
multi-editor accounts and no tiered editor/publisher roles**; do not model a
collection of accounts, and do not reintroduce tiering as though it were a
dropped requirement.

**The wire spelling is `camelCase`, frozen, and the Python attribute is the
`snake_case` form of the same name**, produced by one conversion point shared with
every other model in the system. Field names below are given in their `camelCase`
wire spelling, because that is the externally visible name.

---

## ENT-1 `OwnerAccount` — owned by `OwnerIdentity`

Exactly **one** row ever exists (D6, FR3.6). There are no multi-editor accounts
and no tiered editor/publisher roles; do not model a collection.

| Field | Type | Required | Default | Constraints |
|---|---|---|---|---|
| `ownerId` | string | yes | — | Opaque identifier, generated at provisioning. Never derived from the email. |
| `email` | string | yes | — | Max **200** characters; must match `/^[^\s@]+@[^\s@]+\.[^\s@]+$/`. Not trimmed. Carried from the content schema's `email` rule for consistency — see assumption A-1. |
| `passwordHash` | string | yes | — | An **argon2id** PHC-encoded hash string. Stored verbatim; application code never parses it. The plaintext password is never stored, never logged, and never returned by any operation. |
| `createdAt` | string | yes | — | ISO-8601 UTC instant, e.g. `2026-09-24T14:48:17.123Z`. |
| `passwordUpdatedAt` | string \| null | no | `null` | ISO-8601 UTC instant; `null` until the password is first changed after provisioning. |

**Never present, in any form:** a default, seeded, sample or hard-coded
credential. A fresh start against empty storage has no account anyone can sign in
to. The former owner-email literal hard-coded in the source's server module is
**not** carried forward; the owner's email is runtime configuration and is
**backend-only** — it must never appear as a publicly-inlined build-time variable,
because such a value is readable by every visitor, baked into the built image, and
cannot be rotated without a rebuild.

**Persistence:** `IdentityStore.owner_record`, operations `read` and
`create_if_absent`. `create_if_absent` **is** the one-shot provisioning gate, and
its gate condition is the record's existence.

**The hash is opaque to this unit too.** `OwnerIdentity` hands the stored string
to the verification primitive and reads back a yes or a no. It does not parse the
encoded parameters, does not branch on them, and does not log the string at any
level. A record dump in a debug log publishes the system's highest-value datum.

---

## ENT-2 `Session` — owned by `SessionAuthority`

| Field | Type | Required | Default | Constraints |
|---|---|---|---|---|
| `sessionId` | string | yes | — | Opaque, unguessable, generated from a cryptographic RNG. Never derived from `ownerId` or from any user-supplied value. |
| `ownerId` | string | yes | — | Reference to ENT-1. Each `Session` belongs to exactly one `OwnerAccount`. |
| `issuedAt` | string | yes | — | ISO-8601 UTC instant, set once at issue and never changed. |
| `lastSeenAt` | string | yes | `issuedAt` at creation | ISO-8601 UTC instant. Advanced on each verified request (the sliding idle window). |
| `absoluteExpiresAt` | string | yes | `issuedAt + 7 days` | ISO-8601 UTC instant. Computed **once at issue** and **never extended** by activity. |
| `revokedAt` | string \| null | no | `null` | ISO-8601 UTC instant. Non-null means revoked server-side; a session with a non-null value fails verification regardless of its other fields. |
| `csrfToken` | string | yes | — | Opaque, unguessable, generated from a cryptographic RNG, paired 1:1 with this session. Sent to the client and echoed back as a request header on mutations (double-submit). |

**Expiry is two independent bounds, both enforced (D2, FR3.3):**

- **8 hours idle, sliding** — measured from `lastSeenAt`.
- **7 days absolute** — measured from `issuedAt` via `absoluteExpiresAt`,
  regardless of activity.

**Whichever bound is reached first ends the session.** The two are not
alternatives and not a maximum of each other: a session used every hour for eight
days ends on the eighth day; a session issued and then left alone ends after eight
hours. **Storing both timestamps is what makes that expressible**, and it is the
entire reason `touch` advances one and not the other.

The cookie carrying `sessionId` is signed and marked `HttpOnly`, `Secure`,
`SameSite=Lax` (FR3.2).

**The cookie carries the session identifier, not the session.** No field above is
encoded into the cookie, no expiry is carried in it, and no claim in it is
trusted. Verification is a **server-side record read** every time. This is what
makes `revokedAt` mean anything: a self-describing token cannot be revoked without
a server-side list, at which point the token was the wrong shape.

**Persistence:** `IdentityStore.session`, operations `create`, `read`, `touch`,
`revoke`. **`touch` advances the idle window without extending the absolute
expiry — that asymmetry is the whole point of storing both timestamps.**

**The CSRF token is a field of this entity, not a second session.** It is
generated with the session, stored with it, dies with it, and is returned to the
client in the sign-in response body — **not** in a cookie, because a token that
travels in a cookie is submitted automatically and defends nothing.

---

## ENT-3 `LoginAttemptWindow` — owned by `LoginGuard`

Two independent counters exist per failed sign-in: one keyed by account, one keyed
by source address. **They are separate rows with separate scopes, not one row with
two counters.**

| Field | Type | Required | Default | Constraints |
|---|---|---|---|---|
| `windowKey` | string | yes | — | Identifies the counted subject within its scope. For `scope = account`: **always the normalised submitted email** (trimmed, lower-cased), matching account or not. For `scope = ip`: the source address. |
| `scope` | enum | yes | — | Exactly one of `account`, `ip`. |
| `failureCount` | integer | yes | `0` | `>= 0`. Incremented on each failed attempt within the window. |
| `windowStartedAt` | string | yes | — | ISO-8601 UTC instant at which the current rolling window began. |

**Thresholds (D3, FR3.5), both over a 15-minute rolling window:**

- `scope = account`: refuse beyond **5** failures per **15 minutes**.
- `scope = ip`: refuse beyond **20** failures per **15 minutes**.

**Persistence:** `IdentityStore.login_attempts`, operations `record_failure`,
`count_in_window`, `clear`. **Counters are persisted, so a restart does not reset
a window.**

**Nothing about this entity is visible to a caller.** There is no
"too many attempts" field, no retry-after value, and no remaining-attempts count —
because there is no response in which one could appear. See `rules.md` BR3.20: a
refusal is indistinguishable from an ordinary credential failure, and any of those
three values would enumerate.

---

## What these three entities replace — the trust boundary, verified

**The source had no identity table, no account row and no credential.** That is
now confirmed by execution rather than inferred from reading: the local identity
came from a **dev-server middleware** vendored into the build, which, on seeing a
single cookie, injected a fixed user id and email as request headers.

**The load-bearing detail is what the middleware did first: it stripped every
client-supplied identity header before injecting its own.** Sending those headers
directly still returned 403. So in the source, **the trust boundary was the
middleware, not the header** — the header was an internal transport that a client
could never author.

**The property being preserved is therefore "a client cannot assert its own
identity", not the header mechanism.** In the new system that property is carried
by the **signed cookie and its server-side verification**: the cookie holds only an
opaque session identifier, nothing in it is trusted, and `Session` is read from
storage on every request. A port that accepted an identity claim from anything the
client controls would satisfy the letter of "replace the platform auth" and lose
the only security property the old mechanism had.

**Two consequences for the entities above.**

- `Session.sessionId` is *opaque and never derived from any user-supplied value*
  for this reason, not as a style preference. A derivable identifier is a
  client-assertable identity.
- There was **no prior account to migrate**, which is why `OwnerAccount` has no
  legacy shape to honour and why `ownerId` is free to be opaque. The old identity
  values were fixtures of a development middleware and are carried forward nowhere.

**The refusal the old boundary produced is product copy and is carried
byte-for-byte.** The unauthenticated response body was captured verbatim as
`{"error":"Please sign in with the website owner’s account."}` — the apostrophe is
**U+2019 RIGHT SINGLE QUOTATION MARK, not ASCII**. The human answered "Match
exactly — characters" on error-copy parity, so a port that writes `owner's` has
changed what the owner sees. **This unit raises the not-authorized member of the
taxonomy; the sentence itself is rendered by `HttpApi` (BR10.7, BR10.8) and is not
composed here** — but it is the sentence every refusal in this unit produces, so it
is recorded rather than left to be discovered.

---

## The secrets this unit depends on, and how they fail

Neither is an entity, and both are stated here because the entities above are
meaningless without them and because a reader looking for "where does the key
live" must not have to open another file.

| Setting | Read | On absence |
|---|---|---|
| The session signing key | An environment variable at startup | **The process raises during startup, names the variable, and exits non-zero.** No default value, no fallback, and explicitly **no auto-generated per-process key**. |
| The bootstrap secret for one-shot provisioning | An environment variable at startup | The service **starts normally** and the provisioning route is simply not enabled. With no owner record present, every sign-in is refused. |

**The asymmetry is deliberate.** A missing signing key is a misconfiguration that
must stop the process; a missing bootstrap secret is a legitimate state (an
already-provisioned system, or one being provisioned by another route). See
`rules.md` BR3.9 and BR3.13.

**The signing key is generated, never chosen**, and it is at least 32 bytes.
Neither secret is ever a literal in a source file, and neither is ever baked into
an image layer. A committed example file lists every variable the system reads,
with empty values and a one-line comment each; real environment files are never
committed.

---

## Assumptions & Open Questions

- **[assumption A-1]** `OwnerAccount.email` is specified as max **200** characters
  with the regex `/^[^\s@]+@[^\s@]+\.[^\s@]+$/`. Neither bound was decided at any
  gate: they are carried from the content schema's `email` field so the system
  uses one email rule rather than two. If a longer address must be supported, this
  is the constraint to revisit, and it has **no parity consequence because the
  entity is new**.
- **[A-2 — RESOLVED at review, and the resolution is forced rather than chosen]**
  `windowKey` for `scope = account` was described as *"the account identifier, or
  the submitted email for an account that does not exist"*, leaving open which value
  keys the counter when no account matches.

  **The step order settles it, and shows the choice was never free.** *Sign in*
  reads the account-scoped window at **step 1**, before the owner lookup at step 2.
  `ownerId` does not exist yet at step 1, so the "account identifier" branch is
  **unimplementable as written** — not merely undecided for the no-match case, but
  impossible for *either* case under the mandated order. The two artifacts could
  not both be implemented literally.

  **Resolved: always the normalised submitted email.** The alternative — reordering
  so the owner lookup precedes the window read — is rejected, because it would let
  the lookup outcome influence whether and when the counter read happens, which is
  precisely the timing channel `BR23.1` exists to close.

  **This narrows A-2's timing concern, and the narrowing is stated precisely
  rather than claimed broadly.** A-2 warned the choice was "observable through
  timing", and `BR23.1` only ever equalised the *hashing* cost, not the counter
  lookup. What keying on the email **establishes** is this, and no more:

  - the **key derivation is the same** in both cases — normalise the submitted
    email — with no branch on whether an account exists;
  - the **number and shape of storage operations are equal** across the two cases:
    two window reads, one owner read and one hash on every attempt, and two window
    writes on any failure;
  - so the **dominant, previously-open channel is closed** — the counter lookup no
    longer happens in one case and not the other, and the enumeration defence is
    closed on the hashing half and the counter half rather than on one.

  **What it does not establish, recorded as an accepted residual.** At the
  storage-engine level, `count_in_window` for a `windowKey` with **no existing
  row** can still cost differently from one that finds a row, and `record_failure`'s
  first hit is an insert where later ones are updates. That residual signal
  correlates with *"has this window key been probed before"*, **not** with *"does
  this account exist"* — the real owner's own window is row-less until their first
  failed attempt and row-having after it — so it does not hand an attacker the
  clean enumeration signal `BR23.1` and A-2 were written to close. It is **not
  claimed to be eliminated**, it is out of scope here, and it is carried on the
  same footing as `BR23.1`'s existing hedge: a standard mitigation, **not
  separately measured**. An earlier wording of this bullet said the step-1 read was
  *"identical in shape and cost whether or not an account exists"*, which was
  broader than what had been shown; narrowed at review (R-04).
- **[assumption A-3]** `OwnerAccount.ownerId`, `Session.sessionId` and
  `Session.csrfToken` are specified as "opaque, unguessable, from a cryptographic
  RNG" **without a fixed length or alphabet**. No decision fixed one. Any choice at
  or above the strength of a 32-byte URL-safe random token satisfies every stated
  requirement; the exact spelling belongs to code generation.
- **[assumption]** `LoginAttemptWindow` is modelled as a **rolling window with a
  start instant and a count**, rather than as a log of individual attempt
  timestamps. Nothing decided which. The window form is cheaper and bounded; the
  log form would make "5 failures in the last 15 minutes" exact rather than
  approximate at a window boundary. **The observable difference is at the
  boundary**: with a window, a sixth failure just after a rollover is permitted
  where a true sliding count would still refuse it. Recorded rather than glossed.
- **[assumption]** `passwordUpdatedAt` exists although no requirement asks for a
  password-change operation. It is carried from the entity schema. If no change
  operation is built, the field is written once at provisioning as `null` and
  never updated — harmless, but it is a field with no reader, which is worth
  saying out loud.
- **[open]** Nothing in this unit fixes a **session record retention policy**.
  Expired and revoked sessions accumulate. The functional spec deletes a record
  found to be expired at verification time, which reclaims the ones that are
  revisited and nothing else. No stage has owned a sweep, and none is required by
  any rule; for a single-owner site the volume is negligible, which is why it is
  recorded as an open item rather than raised as a defect.
- **[note]** These three entities are **new**, so there are **no recorded source
  fixtures for them** and none can be made — the source had no authentication of
  its own to record. This unit deliberately carries **no dependency on the
  fixture-recording unit**, and that absence is a design statement, not an
  oversight.

## Sources

- `construction/functional-design/entities.md` §§ ENT-1, ENT-2, ENT-3, and its
  assumptions A-1, A-2, A-3 — every field, type, default and constraint above is
  carried from there unchanged.
- `inception/contract-design/contract-summary.md` § C3 — `IdentityStore`'s three
  operation groups and their notes, and the separation rationale.
- `inception/units-generation/unit-of-work.md` § U3 — what this unit owns,
  delivers, is bounded by, and realises (FR3.1–FR3.7, NFR5).
- `WORKING-RECORD.md` § 2 (D1 password + argon2id + signed cookie + CSRF +
  rate limiting; D2 8h idle / 7d absolute; D3 5 per account and 20 per address per
  15 minutes with no enumeration; D6 exactly one owner account), § 5 (the signing
  key is generated and fails loudly; publicly-inlined variables).
- `aidlc/spaces/default/memory/team.md` § *Deployment* — the signing key's
  generation and boot-failure rule, the bootstrap secret, and the committed
  example file.
- `aidlc/spaces/default/memory/project.md` § *Forbidden* / § *Mandated* — no
  default, seeded, sample or hard-coded credential; password verified against an
  argon2id hash in a backend-owned session, replacing the platform header auth
  entirely.
