# Code Generation Plan — U3 `identity-and-session`

## Unit scope

**The complete authentication and session surface, enforceable independently of any
frontend.** It answers one question — *who is this, and may they act?* — and owns no
content.

| Component | Owns |
|---|---|
| `OwnerIdentity` | The owner account, its argon2id hash, and one-shot provisioning |
| `SessionAuthority` | Session issue, verification, the sliding and absolute bounds, revocation, and the CSRF token |
| `LoginGuard` | Failed-attempt bounding, per account and per source address |

**Everything here is new, and there is no recorded source fixture — none can be made.**
The source authenticated through a platform header; this replaces it entirely. Uniquely
among the backend units, this one carries **no dependency edge on the fixture-recording
unit**, and the absence of that edge is a design statement rather than an oversight.

**The property being preserved is not the header mechanism.** The source's local identity
came from a vendored dev-server middleware that, on seeing one cookie, injected a fixed
user id and email as request headers — **and stripped every client-supplied identity
header before injecting its own.** Sending those headers directly still returned 403. The
trust boundary was the middleware, not the header. So the property this unit must carry
is **"a client cannot assert its own identity"**, and it is carried by a signed cookie
holding *only* an opaque session identifier plus server-side verification on every
request. A port that trusted any client-controlled identity claim would replace the
platform auth in form and lose the only security property it had.

## Module layout

```
app/auth/hashing.py        argon2id wrapper + the fixed dummy hash        [HAZARD]
app/auth/tokens.py         opaque id and CSRF token generation, cookie signing
app/auth/sessions.py       SessionAuthority: issue, verify, touch, revoke [HAZARD]
app/auth/guard.py          LoginGuard: the two independent windows
app/owner/identity.py      OwnerIdentity: sign-in, one-shot provisioning  [HAZARD]
app/owner/provision.py     the command-line provisioning entry point
app/settings.py            startup configuration and its fail-fast checks
```

`app/auth/store.py`, `store_sqlite.py` and `store_memory.py` already exist from U2 and are
reused unchanged. Persistence is reached **only** through `IdentityStore`, which holds
timestamps and counts and evaluates neither.

## Ordering — the contract's `custom` methodology

This unit has **no recorded fixture and no oracle**, so its tests are written from the
specification. Three behaviours are hazard-class — the timing-equalised sign-in, the
two-bound session machine, and the one-shot provisioning gate — and for those the tests
are **written and observed to fail before the implementation exists** (Steps 3 and 5).
Everything else is tested immediately after the code it covers.

## Steps

- [x] **Step 1 — Verify the test runner and record the exact unit-scoped command.**
      `uv run pytest --version` must succeed; record the unit-scoped command in
      `unit-test-instructions.md`.

- [x] **Step 2 — Startup configuration, fail-fast (BR3.13).** Read
      `SESSION_SIGNING_KEY`. **If it is unset, empty, or under 32 bytes, raise during
      startup with a message naming the variable and exit non-zero.** All three conditions
      are checked separately. **No default, no fallback, and explicitly no auto-generated
      per-process key** — an auto-generated key silently invalidates every session on
      restart and hides the misconfiguration, which makes it **the worse failure because
      it looks like it works**.
      Then read the bootstrap secret and **do not fail on its absence**. The asymmetry is
      decided, not accidental: a missing signing key is a misconfiguration that must stop
      the process; a missing bootstrap secret is a legitimate state — an already-provisioned
      system, or one provisioned another way. **Never seed an owner.**

- [x] **Step 3 — HAZARD tests, written and observed to FAIL.** Three groups:
      - **Sign-in, and its timing equality (BR23.1, BR3.20).** Step 1 reads **both**
        windows keyed on the **normalised submitted email** — trimmed, lower-cased — and
        **does not return early**. Step 2 **always runs a verification**: with no owner
        record, verify against a **fixed dummy argon2id hash** and discard the result, so
        absence and wrong-password cost the same. The **three refusal cases — unknown
        account, wrong password, limit already reached — are indistinguishable**: same
        status, same body, same sentence, **no `Retry-After`, no "too many attempts"**.
      - **The session state machine (BR3.14–BR3.17).** `touch` advances `last_seen_at`
        **and nothing else**; `absolute_expires_at` is computed once at issue and **never
        extended**. This is the single most consequential line in the unit: refreshing
        both satisfies the 8-hour idle rule perfectly and **silently destroys the 7-day
        bound**, while every idle-expiry test stays green. Verification returns **identity
        or nothing, never a third answer** — revoked, idle-expired and absent are one
        outcome to every caller. An expired record is **deleted as it is rejected**
        (BR23.2); a revoked record is **retained**, because its whole purpose is to keep
        failing.
      - **One-shot provisioning (BR3.7, BR3.8, BR22.13).** The gate is **the record's
        existence** — not a consumed flag, not a marker file, not an environment variable.
        **A restart cannot reopen it.** Creation is **atomic against a concurrent caller**:
        two simultaneous attempts produce one record and one refusal. This matters more
        here than anywhere else, because the operation **can never be re-run once it has
        succeeded** — a lost provisioning on a container with no shell leaves a system
        nobody can sign in to and no route that will let them.
      Run them; paste the failing output.

- [x] **Step 4 — `hashing.py` and `tokens.py`.** argon2id via `argon2-cffi` (already
      pinned), the fixed dummy hash, opaque identifiers at or above the strength of a
      32-byte URL-safe random token, and cookie signing via `itsdangerous` (already
      pinned). **The hash is returned to the verifying component and nowhere else: never
      logged, never parsed, never compared inside the store** (BR3.6).

- [x] **Step 5 — The three hazard implementations, to Green.** `identity.py`,
      `sessions.py`, `guard.py`. The cookie is **signed, `HttpOnly`, `Secure`,
      `SameSite=Lax`, and carries only the session identifier** (BR3.11). The CSRF token
      is paired 1:1 with the session, returned **in the response body, never in a cookie**
      — a token the browser attaches automatically defends nothing — and checked as a
      request header on every mutation (BR3.12).

- [x] **Step 6 — `LoginGuard`'s two windows and provisioning's two paths.**
      **5 failures per account per 15 minutes and 20 per source address per 15 minutes,
      counted independently** as separate records (BR3.18, BR3.19). Success clears the
      **account-scoped** counter only (BR3.21). Counters are persisted, so a restart does
      not reset a window (BR3.22) — the thresholds live here, never in the store.
      Provisioning has **two paths and one gate**: the command-line path is the normal
      one; the one-shot route exists for a container with no interactive shell and is
      enabled **only while both hold** — no owner record exists, **and** the bootstrap
      secret is configured. **With the secret unset and no owner, the service starts
      normally and refuses every sign-in** (BR3.9): it does not create an account and it
      does not fail to start.

- [x] **Step 7 — Coverage, documentation and traceability.** The 80% branch floor, and
      **100% branch** on `app/auth/sessions.py`, `app/owner/identity.py` and
      `app/auth/hashing.py` alongside the existing hazard modules. Then `code-summary.md`,
      `source-manifest.json`, `traceability.json`.

## The acceptance test for the no-default-credential rule

**A fresh start against an empty volume has no account anyone can sign in to** (BR3.10).
That is the test, stated exactly as `functional-spec.md` states it, and it is asserted
directly rather than inferred from the absence of a seed.

**No default, seeded, sample or hard-coded credential exists** in this unit, in its
schema setup, or in its fixtures.

## Test files this plan produces

- `tests/auth/test_startup.py` — the three signing-key conditions separately, the
  bootstrap-secret asymmetry, and that no owner is ever seeded.
- `tests/auth/test_sign_in.py` — **hazard**: the step order, the always-hash property, the
  three indistinguishable refusals, and that no response carries `Retry-After` or any
  "too many attempts" hint.
- `tests/auth/test_sessions.py` — **hazard**: the two bounds, `touch`'s asymmetry, the
  three exits from Active, identity-or-nothing, and expired-deleted versus
  revoked-retained.
- `tests/auth/test_guard.py` — the two independent windows, the thresholds, clear-on-success,
  and persistence across a new store instance.
- `tests/owner/test_provisioning.py` — **hazard**: the gate is the record's existence, a
  restart cannot reopen it, concurrent creation yields one record, both paths, and the
  empty-volume acceptance test.

Standard strategy, 5–8 tests per component across five components, plus a test per
enumerated branch on the three hazard modules, which is additive.

## What this unit deliberately does not do

- **Composes no HTTP response.** Statuses, the error envelope and the verbatim
  user-facing sentences belong to U6; this unit raises taxonomy members. The sentence U6
  renders for all three sign-in refusals is `Please sign in with the website owner’s
  account.` — **with a U+2019 apostrophe**, captured verbatim from the running source.
- **Performs the same-origin check nowhere.** BR3.3–BR3.5 are U6's, applied to mutations
  including this unit's own. The CSRF comparison here does **not** replace it.
- **Evaluates no expiry inside the store.** The store returns records as stored; both
  bounds are applied here.
- **Sweeps nothing on a schedule.** No background worker, no scheduler, no queue.
- **Owns no content.** Not the document, not a revision, not an asset.

## Carried open question

**No session retention policy exists.** Revoked records, and expired records never
revisited, accumulate with nothing to sweep them. No stage has owned this and no rule
requires it; for a single-owner site the volume is negligible, which is why
`functional-spec.md` records it rather than raising it as a defect. It is carried here
unchanged and **not invented into existence by this unit**.

## Traceability — plan step to rule

| Step | Realises |
|---|---|
| 2 | BR3.13, BR3.9 |
| 3–5 | BR3.6, BR3.11, BR3.12, BR3.14, BR3.15, BR3.16, BR3.17, BR23.1, BR23.2 |
| 6 | BR3.7, BR3.8, BR3.10, BR3.18, BR3.19, BR3.20, BR3.21, BR3.22 |
| 7 | NFR10 |

BR22.13 and BR22.14 are **enforced** here and **declared** in U2. BR3.1–BR3.5 are
**declared by U6** and quoted in this unit's `rules.md` under *Subject to, not owned*,
because BR3.2 delegates the authorization decision here and neither half is complete
alone.
## Testing Contract

```json
{
  "version": 1,
  "methodology": "custom",
  "source": "team",
  "ordering": "Within each unit, the characterization tests for that unit's hazard-register",
  "scope": "runtime-split-migration",
  "test_strategy": "standard",
  "project_type": "brownfield",
  "applicable_notes": [
    {
      "layer": "org",
      "text": "We treat tests as a first-class deliverable in every Bolt. The specific\nmethodology (TDD, BDD, ATDD, or classic test-after) is affirmed at\npractices-discovery and recorded in `team.md` under this heading with explicit\n`Methodology` and `Ordering` fields; Code Generation resolves those fields\nindependently from coverage, tooling, and scope notes.\n\nWhen no posture has been affirmed, our default per scope is:\n- **Methodology**: test-after\n- **Ordering**: implement each applicable testable layer, then write and run\n  that layer's tests.\n- `mvp`, `enterprise`, `feature`, `infra`, `classic` add an 80% line-coverage\n  floor and CI execution before merge.\n- `bugfix`, `security-patch` add a targeted regression for the specific\n  bug/vulnerability and require the existing suite to remain green.\n- `express` uses the Minimal strategy: requirement-driven unit tests (one per\n  requirement, with a happy-path floor per component); existing tests remain\n  green.\n- `poc`, `refactor`, `workshop` add no extra new-test floor and require the\n  existing suite to remain green.\n\nThe active `Test Strategy` still applies in every scope and determines test\nvolume/types. Scope floors are additive; they never reduce or replace the\nselected strategy.\n\nBuild and Test verifies defined coverage floors and affirmed quality targets;\nthey may not be weakened to make a step pass.\n\nAffirm a stricter posture in `team.md` if the team commits to one."
    },
    {
      "layer": "team",
      "text": "> **Read this section as a proposal we have adopted, not as practice we observed.** The source\n> project contains zero test files, zero testing dependencies and no `test` script, so there was no\n> prior testing practice to discover — every item below was chosen at the practices-discovery gate\n> on 2026-09-24 and affirmed by the site owner, rather than read off how this team already works.\n\n- **Methodology**: custom\n- **Ordering**: Within each unit, the characterization tests for that unit's hazard-register\n  behaviours and for the storage port are written and observed to fail before the Python\n  implementation of that behaviour exists; every other backend test is written immediately after\n  the code it covers; that unit's frontend render layer is ported only once its backend tests\n  pass; a unit with no backend surface begins at the frontend step; and a unit whose behaviour is\n  not enumerated in the hazard register takes the recorded source fixtures as its oracle, falling\n  back to the reverse-engineering knowledge base where no fixture exists.\n- **What `custom` means, and why it is not `test-after`.** Under test-after, a developer who\n  misreads a dense source line implements from the misreading and then writes the test from the\n  same misreading: the test is green, coverage is satisfied, and the defect ships. That is not\n  hypothetical here — a port declaring `research_topic: Topic | None = None` passes `ruff`,\n  `mypy --strict`, `tsc`, the Compose end-to-end flow and 100% line coverage while rendering three\n  identical research cards and returning zero publications for every topic filter. Only a test\n  whose assertion came from the *source* behaviour catches it. `tdd` everywhere is equally wrong:\n  most of the ported render layer has no enumerated oracle, and writing failing render assertions\n  first for ported JSX is waste. Note this is **characterization** testing, not TDD — the test is\n  written from the recorded behaviour of the source, which is why the fixtures below matter.\n- **Recorded source-behaviour fixtures come first, before any Python is written.** Drive the\n  running `madhavi-tripathi/` app over HTTP with `httpx` once and record as golden fixtures: every\n  public route's rendered HTML, `GET /api/content`, the media route's status codes across public /\n  draft-only / missing keys, the 413 boundary in both characters and UTF-8 bytes, byte-range\n  responses across all six rejection branches, and the stored-row state after a save / publish /\n  conflict sequence. It uses a disposable local database and a test identity; nothing hosted is\n  touched. Until these exist, every parity assertion in this project rests on a human's reading of\n  a document; after they exist, they assert against the system. **This capability expires when the\n  source app is retired** — a fixture not recorded before then cannot be recovered.\n- **Coverage floor — backend**: **80% branch coverage** over `chiku-website/backend/`, measured by\n  `pytest --cov --cov-branch` and `coverage report --fail-under=80`, with generated migration\n  files and `__main__` entry points excluded. Branch, not line, is deliberate and costs one flag:\n  every high-risk behaviour in this port is a branch or a `??` fallback chain, and line coverage\n  marks those covered when only one side ever runs. This is a **new floor we are choosing**, not\n  an inherited one — `org.md`'s 80% floor is written for the named stock scopes (`mvp`,\n  `enterprise`, `feature`, `infra`, `classic`) and this workflow runs the custom scope\n  `runtime-split-migration`, which appears in none of them. Absent this affirmation there would be\n  no numeric floor at all. The active `Test Strategy` is **Standard** and continues to govern test\n  volume and type independently of this number.\n- **Coverage floor — hazard modules**: a second, scoped\n  `coverage report --fail-under=100 --include=<hazard module globs>`. The hazard modules are the\n  ports of the behaviours ranked in `code-quality-assessment.md` § *Hazard index* — the\n  seven-statement concurrency batch and its `last_mutation` ABA defence, the media access rule, the\n  `researchIdentity` back-compat shims, the request-size cap, the three hand-written image header\n  parsers, the WebVTT validator, the byte-range parser and the editor state machine. Each carries a\n  test per enumerated branch. An aggregate percentage cannot distinguish \"this branch is exercised\"\n  from \"this branch was ported correctly\"; these are precisely the branches whose silent loss ships\n  a defect, so they get both the per-branch tests and a floor that leaves no room.\n- **Coverage floor — frontend**: none. The Next.js frontend renders only and owns no application\n  decision, so a line-coverage number on it would measure JSX traversal rather than behaviour.\n- **The test families, and which are mandatory.** Mandatory: the recorded fixtures above; backend\n  unit tests for branch-level behaviour of ported logic; **storage-port contract tests written as\n  an adapter-parameterized conformance suite and run against both the real SQLite adapter and an\n  in-memory fake** (two implementations is the minimum that proves the suite tests the port\n  contract rather than SQLite, and it is the whole argument for having a port); API contract tests\n  in the non-circular form — assert the **generated** OpenAPI document against the **hand-written**\n  contract from `contract-design`, and commit the generated `openapi.json` as a snapshot so an\n  unintended contract change surfaces as a gate diff rather than as a frontend 422 three Bolts\n  later; and the Compose end-to-end flow. Frontend render checks are mandatory but add **no\n  frontend test framework**: assert against the HTML the composed stack returns, using the recorded\n  fixtures, and make the assertions named rather than \"landmarks present\" — each of the three\n  research cards has a distinct topic class and icon, the publications topic filter returns\n  non-zero for each seeded theme, each research card shows non-zero related papers. Browser checks\n  (Playwright) are optional today with one condition that flips them: **if the six-flag editor\n  state machine lands in the frontend rather than the backend, a browser check becomes the only\n  possible verification of it and becomes mandatory.** Flag that as a dependency on `domain-design`.\n- **Compose end-to-end runs on every Bolt merge**, not only at the skeleton gate and at the end.\n  With no CI, the per-merge run *is* the CI, and the alternative is a container-level regression\n  surfacing many Bolts after the one that caused it, with no bisect signal and nobody watching a\n  dashboard. Keep the cost bounded by keeping the flow small and fixed — the skeleton's two paths\n  plus one auth-failure path — so it stays inside a few minutes on cached layers.\n- **Parity is verified two ways, and pixel comparison is rejected.** (1) A **normalised\n  DOM-structure diff** against the recorded source HTML: strip volatile attributes, build hashes\n  and whitespace, then diff the element tree plus text content per route. It catches what actually\n  breaks in a port — a dropped section, a wrong class, a missing copy default among the 25 leaf\n  defaults — at a fraction of the setup cost of pixel screenshots and without their flakiness.\n  (2) An explicit **page-by-page human review at the end**, recorded as a checklist. Per-route\n  screenshot comparison was considered and **rejected**: it is brittle against fonts, antialiasing\n  and animation, and it is not a live option to be reopened later. Until the DOM diff exists, the\n  parity rule is an unfalsifiable claim, which is what this closes.\n- **Boundary enforcement is a command, not an assertion.** A rule nobody can check is a wish. Three\n  checks, all on the gate: the frontend's TypeScript types for backend payloads are **generated**\n  from the backend's `/openapi.json` with `openapi-typescript`, committed, regenerated at the gate,\n  and the gate fails if the output is dirty — which makes the boundary type-checked rather than\n  asserted, since a backend field rename then fails `tsc --noEmit` with a file and a line; a\n  three-line grep fails the gate if `chiku-website/frontend` contains any `'use server'` directive,\n  any `app/**/route.ts`, or any `middleware.ts` (an ESLint `no-restricted-syntax` rule is a nicer\n  editor experience, but the grep is the one that is certain); and one pytest walks the AST of\n  `routers/` modules and asserts none of them imports a `store` module or `sqlite3`.\n- **The source has no suite to keep green.** The org rules for several scopes say \"the existing\n  suite remains green\". There is none — the scan found zero test files, zero testing dependencies\n  and no `test` script anywhere in `madhavi-tripathi/`. Every test in this project is a new test.\n  The only inherited automated checks are `tsc --noEmit` (strict) and `pnpm lint`.\n- **Tooling**: backend — pytest 9.1.1 with `httpx` 0.28.1 for FastAPI transport-level tests,\n  `ruff` 0.16.8 and `mypy` 2.3.1 as gating checks, dependencies resolved by `uv` 0.10.0. Frontend\n  — `tsc --noEmit` and ESLint 9 with `eslint-config-next`, unchanged from the source project.\n- **The merge gate.** A Bolt may squash-merge to `main` only when every one of these passes on the\n  developer machine, in this order, with the **verbatim output pasted into the gate approval**:\n\n  ```\n  ruff check\n  ruff format --check\n  mypy --strict\n  pytest --cov --cov-branch\n  coverage report --fail-under=80\n  coverage report --fail-under=100 --include=<hazard module globs>\n  tsc --noEmit\n  pnpm lint\n  git diff --no-index madhavi-tripathi/app/<f> chiku-website/frontend/app/<f>   # per unmodified ported file\n  <boundary grep: 'use server' / app/**/route.ts / middleware.ts>\n  <openapi-typescript regeneration — gate fails if the committed output is dirty>\n  uv export --frozen --no-dev --no-emit-project -o .audit/requirements.txt && uvx pip-audit -r .audit/requirements.txt\n  pnpm audit --prod --audit-level high\n  docker compose up  +  the end-to-end flow\n  ```\n\n  **Dependency advisories block at High and above.** An advisory with no fix available does not\n  silently pass and does not silently block: it is recorded with the **package, the advisory id,\n  the reason it cannot be fixed, and the named Bolt that owns it**, and the gate then proceeds on\n  that record. This is consistent with the correction already in `project.md` that any finding\n  carried past a gate needs a named owner.\n\n  Gates protect the parity guarantee; weakening one to make a Bolt pass is an incident, not a\n  shortcut."
    }
  ],
  "obligations": {
    "strategy": "standard",
    "strategy_volume": [
      "Five to eight tests per component.",
      "Unit tests plus integration tests for key boundaries.",
      "Add E2E, performance, or security tests when requirements demand them."
    ],
    "scope_floor": [
      "Keep the existing test suite green.",
      "This scope adds no extra new-test floor beyond the selected test strategy."
    ],
    "combination_rule": "Apply every selected-strategy obligation and every scope-floor obligation; neither replaces the other, and a targeted scope regression may add the narrowest necessary test type beyond the strategy default."
  },
  "plan_profile": {
    "methodology": "custom",
    "runner_step": "Verify the existing test runner/configuration and record the exact unit-scoped command.",
    "runner_ready_before_first_test": true,
    "testable_layers": [
      "Data model / database behavior",
      "Repository / data access",
      "Business logic",
      "API / endpoint",
      "Frontend behavior"
    ],
    "steps": [
      "Project structure and production configuration skeleton.",
      "Verify the existing test runner/configuration and record the exact unit-scoped command.",
      "Custom ordering - Within each unit, the characterization tests for that unit's hazard-register",
      "Implementation and tests - preserve that exact ordering; do not convert it to layer-local TDD.",
      "Environment/build configuration.",
      "Documentation and traceability."
    ]
  },
  "input_sha256": "sha256:ae7fe698329b9815a1e703cfb6f92beeb23e35c6e2f83768ad7ab02dffb4a262",
  "contract_sha256": "sha256:6b84da29d5313b29b3058ef863280c58a9f6f401f244363de9431d8063261179"
}
```
