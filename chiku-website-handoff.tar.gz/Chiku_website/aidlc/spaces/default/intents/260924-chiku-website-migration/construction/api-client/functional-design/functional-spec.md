# Functional Spec — U7 `api-client`

**Upstream:** `inception/units-generation/unit-of-work.md`,
`inception/contract-design/contract-summary.md`,
`inception/domain-design/components.md`,
`inception/requirements-analysis/requirements.md`,
`construction/api-client/functional-design/entities.md`,
`construction/api-client/functional-design/rules.md`.

The frontend's only route to the backend. Holds no business rule, caches nothing,
retries nothing.

## Entity relationships (derived view — `entities.md` is source of truth)

`entities.md` declares `entities: []` — this unit defines no type of its own, so
there is no entity-relationship diagram to derive. What exists instead is a
generation dependency, shown here in its place:

```mermaid
flowchart LR
    U6["U6 http-api<br/>/openapi.json"] -->|generates| GEN["OperationTypes<br/>(committed)"]
    GEN -->|type-checks| U9["U9 owner-editor"]
    GEN -->|type-checks| U8["U8 public-site"]
    GATE["merge gate"] -->|regenerates and compares| GEN
```

*Text fallback:* U6's OpenAPI document generates the committed `OperationTypes`,
which type-check U8 and U9; the merge gate regenerates and compares them, failing
on any difference. The only state this unit holds is the in-memory `csrfToken`.

## Rules summary (derived view — `rules.md` is source of truth)

No hand-written validation mirror in the browser (BR8.9); the error envelope is
propagated verbatim, top-level field `error` (BR27.1); a mutation is never retried
automatically (BR27.2); every mutation is same-origin with credentials and the
CSRF token (BR27.3); the generated types are committed and gate-checked (BR27.4);
no hand-authored frontend file holds a second definition of a backend shape or a
validation rule (BR27.5).

## Generation workflow

1. The backend serves its OpenAPI document at `/openapi.json`.
2. A generation step produces TypeScript types from it into a committed file.
3. The merge gate re-runs step 2 and **fails if the committed output is dirty**.

This is what makes the boundary type-checked: a backend field rename breaks
`tsc --noEmit` with a file and a line.

## Operation surface

One typed function per backend operation. Each: builds the request, sends it
same-origin with credentials, attaches the CSRF token on a mutation, and returns
either the typed success body or the backend's error envelope **unchanged**.

| Operation | Method | Mutating |
|---|---|---|
| public content | GET | no |
| session state | GET | no |
| sign in | POST | yes |
| sign out | POST | yes |
| read content | GET | no |
| save or publish | PUT | yes |
| inspect a recovered draft | POST | yes (no state change, but carries a body and requires the token) |
| list or fetch revisions | GET | no |
| upload | POST | yes |
| media | GET / HEAD | no |

C1 also defines `/sitemap.xml` and `/robots.txt`. They are **deliberately absent**
from this table: both are fetched directly by crawlers and by the browser's own
well-known-path handling, never by client JavaScript, so a typed function for them
would have no caller. The omission is a scope decision, not an oversight.

## Error handling

The envelope's shape is fixed by C1 `components.schemas.Error`: a required
top-level **`error`** string carrying one human sentence, plus, on a validation
failure only, an `issues` array whose entries carry `path` and `message`. There is
no top-level `message` — that name belongs to the per-entry field inside `issues`,
and reading it one level too high yields `undefined` on every failure.

The envelope reaches the caller as the backend produced it. The client adds no
interpretation: it does not decide that a 409 means "retry", nor that a 503 is
transient. Those are decisions, and decisions are not this unit's job.

## Boundary enforcement

Two gate checks, not one. BR27.4 regenerates the committed types and fails on a
dirty diff — which proves the generated file is current. BR27.5 fails the gate if
a backend shape or a validation rule is declared in any *other* hand-authored
frontend file — which is the half BR27.4 is structurally unable to see, because
it compares the generated file only against itself.

A transport-level failure — the request never completing — is surfaced as
distinct from a backend error, because the editor's third recovery state depends
on telling "the backend said no" from "the backend could not be reached".

## Assumptions & Open Questions

- **[assumption]** One generated type file is sufficient. If the surface grows
  enough to make that unwieldy, splitting it is a packaging change, not a contract
  change.
- **[assumption]** The inspect operation is classified as mutating for CSRF
  purposes although it changes no state. It carries a body and is owner-only, and
  treating it as safe would create the only body-carrying operation without token
  protection.
