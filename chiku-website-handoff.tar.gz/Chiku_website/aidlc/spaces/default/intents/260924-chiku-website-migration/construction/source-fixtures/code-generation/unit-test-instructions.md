# Unit Test Instructions — U1 `source-fixtures`

## Framework and configuration

`pytest` 9.1.1 with `pytest-cov`, resolved by `uv` from
`chiku-website/backend/pyproject.toml`. No new framework is introduced for this unit.
`httpx` 0.28.1 is the transport the recorder uses, not these tests: the tests read
recorded bytes from disk and never make a network call.

## The exact command to run THIS unit's tests

Run from `chiku-website/backend/`:

```
uv run pytest tests/test_fixture_set.py -q
```

This is scoped to this unit's test file only. Build and Test runs every unit's commands,
so a bare project-wide `pytest` would rerun the whole suite once per unit.

To include the two fact assertions this unit depends on but does not own:

```
uv run pytest tests/test_fixture_set.py tests/test_limits.py tests/test_error_copy.py -q
```

Runner readiness is verified before the first test step: `uv run pytest --version` must
succeed. It does today — the runner and both dependent test files already execute.

## Expected coverage

This unit adds no backend application module, so it contributes nothing to the 80%
branch floor over `chiku-website/backend/` and nothing to the 100% hazard-module floor.
Its coverage obligation is different in kind and is asserted directly: **every one of the
57 recorded fixtures is reachable, parseable, and carries provenance.** A percentage
would measure nothing here.

## Test scope — Standard strategy, 5-8 tests for this component

1. Every fixture named in `MANIFEST.json` has a `.meta.json` and, for HTTP fixtures, a
   `.body` file on disk.
2. Every fixture carries non-empty `sourceCommit` and `recordedAt` provenance (BR21.2).
3. The manifest's counts match what is on disk, for HTTP fixtures and DB snapshots.
4. Every fixture flagged `deliberateDefect` names the preserved behaviour in prose
   (BR21.3), and all three known defects are present: HEAD ignoring `Range`, an ETag with
   no `304`, and an oversized suffix range returning `206` for the whole object.
5. Every fixture carrying a `recorderCaveat` names a dev-server artifact rather than
   source behaviour, so no downstream test asserts on it.
6. The media fixtures cover both identities for the draft-only and missing cases, and
   exactly one recording for the malformed case (BR21.7).
7. The size-cap family records UTF-16 units, codepoints and UTF-8 bytes for every entry
   (BR21.6).

## Mocking and stubbing

None. These tests read recorded bytes. Introducing a mock here would replace the evidence
with a belief about the evidence, which is the failure this unit exists to prevent.

## Test data management

The fixtures **are** the test data and are committed. They are never regenerated as part
of a test run: regeneration requires the source app to be running, is a deliberate
operator action, and is documented in `chiku-website/fixtures/README.md`. A test that
re-recorded its own oracle would always pass.
