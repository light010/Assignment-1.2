# Functional Specification — U4 `content-core`

**Unit:** `u4-content-core` · **Kind:** `library` · **Components:**
`ContentAuthority`, `RevisionLedger`

**Upstream:** `construction/content-core/functional-design/entities.md`,
`construction/content-core/functional-design/rules.md`,
`inception/contract-design/contract-summary.md` §§ C1, C2,
`inception/domain-design/decisions.md` ADR-001, ADR-002, ADR-006,
`inception/units-generation/unit-of-work.md` § U4,
`construction/functional-design/functional-spec.md` §§ *Read content*, *Save or
publish*, *Inspect a recovered draft*, *Revision history*.

> **Path note — `construction/functional-design/` is NOT a unit directory.** It is
> the **workflow-level** rule and entity corpus, written before the per-unit split
> and shared by every unit; the per-unit convention is
> `construction/<unit-name>/functional-design/...`, which has a unit segment this
> path lacks. The collision is real enough that a reviewer's scope tooling
> classifies it as a sibling unit and refuses to open it, so it is named here as a
> **shared cross-unit input** rather than an upstream artifact of any one unit.
> It holds the 120 `BR3.x`–`BR10.x` ids this unit carries forward verbatim.

**This document is the source of truth for this unit's workflows and its state
machine.** It additionally carries **two derived views** — an entity-relationship
diagram derived from `entities.md`, and a rules summary derived from `rules.md`.
Where a derived view disagrees with its source, the source wins and the view is the
defect.

## What this unit delivers

**Every content operation, and the seed content.** It owns the one document every
other unit reads and none may write.

| Component | Owns |
|---|---|
| `ContentAuthority` | The document in draft and published form, the authoritative schema, the draft-save and publish operations, the concurrency guard and its side-effect guard, the request-size limit, the published-document cache, and the inspect operation behind draft recovery |
| `RevisionLedger` | The revision listing order and the retention policy — **and performs no write** |

**Three of the system's seven hazards live here**, and this unit **raises into a
fourth**. Each carries a test per enumerated branch under the **100% scoped
coverage floor**:

| Hazard | Requirement | Owned here |
|---|---|---|
| The combined write and its ABA side-effect guard | FR4.5 | **yes** |
| Recoverable versus corrupting classification | FR8.3 | **yes** |
| The content-carrying defaults | FR9.2 | **yes** |
| The error envelope | FR10.1 | **no — `HttpApi` (U6)**; this unit raises into it |

## Conventions that hold throughout

- **This unit raises; it never composes a response.** No status code, no sentence,
  no envelope is built here. Services raise the four taxonomy members and `HttpApi`
  renders them (BR10.3, owned by U6).
- **Persistence is reached only through `ContentStore`.** The store validates
  nothing, defaults nothing, and round-trips payloads byte-identically (BR22.5,
  BR22.6, owned by U2). Everything the schema does happens **here**.
- **The wire format is `camelCase`, frozen**, and the persisted content **is** that
  JSON.
- **Operations are asynchronous**; a blocking driver never leaves the adapter.

---

## Derived view — the two entities and what they touch

Derived from `entities.md`. **Authoritative source: `entities.md`.**

```mermaid
erDiagram
    CONTENT_DOCUMENT ||--o{ CONTENT_REVISION : "past states of"
    CONTENT_DOCUMENT ||--o{ ASSET : "makes public by substring reference"
    OWNER_ACCOUNT ||--o{ CONTENT_DOCUMENT : "authorises every write to"

    CONTENT_DOCUMENT {
        fixed documentId PK "singleton"
        Content draft "ALWAYS overwritten by an accepted write"
        Content published "moves only on publish"
        integer revision "plus one on EVERY accepted write"
        instant updatedAt
        instant publishedAt "null until the first publish"
        token lastMutation "the ABA guard for the side effects"
        boolean hasUnpublishedChanges "COMPUTED on every read, never stored"
    }
    CONTENT_REVISION {
        string revisionEntryId PK "the mutation token, or a fixed baseline literal"
        integer revision "NOT unique"
        enum action "draft or publish"
        Content content "read back from the stored draft column"
        instant createdAt "time of capture for a baseline"
        boolean baseline "never pruned when true"
    }
    ASSET {
        string assetKey PK "owned by u5-media"
    }
    OWNER_ACCOUNT {
        string ownerId PK "owned by u3-identity-and-session"
    }
```

**Text fallback.** **`ContentDocument`** is a singleton and is the centre of this
unit. It has zero or more **`ContentRevision`** entries, each a past state of it.
Its relationship to **`Asset`** is **not a foreign key**: an asset is public **iff
the literal media URL appears anywhere in the serialised published document**, a
substring relation owned by U5. **`OwnerAccount`**, owned by U3, authorises every
write. `hasUnpublishedChanges` is drawn as an attribute but has **no column** — it
is computed on every read.

---

## The content-document state machine

**This is the unit's only state machine.** Its three states are a function of
`publishedAt` and of whether `draft` equals `published` — both derived, neither a
stored status field.

```mermaid
stateDiagram-v2
    [*] --> Seeded : no document exists, the read synthesises this
    Seeded --> UnpublishedEdits : draft save
    Seeded --> Published : publish
    UnpublishedEdits --> UnpublishedEdits : draft save
    UnpublishedEdits --> Published : publish
    Published --> UnpublishedEdits : draft save
    Published --> Published : publish
```

**Text fallback and the meaning of each state.**

| State | `publishedAt` | `draft` vs `published` | `hasUnpublishedChanges` |
|---|---|---|---|
| **Seeded** | `null` | equal — both hold the seed | `false` |
| **UnpublishedEdits** | `null` *or* set | **different** | `true` |
| **Published** | set | equal | `false` |

- **Seeded** is the state of a system with no document. The read **synthesises** it
  and **writes nothing** (BR4.1). The seeded document is **not published** —
  `publishedAt` stays `null` (BR4.4).
- **A draft save always moves to UnpublishedEdits** unless the saved document
  happens to equal `published` by value. It **always** overwrites `draft` (BR4.3)
  and **always** increments `revision` (BR4.5).
- **A publish moves to Published from anywhere**, setting `published` and
  `publishedAt` (BR4.4) and leaving `draft` equal to `published`.
- **There is no unpublish transition and no deletion transition.** Content is never
  removed; it is republished.
- **Every transition increments `revision` by exactly one**, including
  `Published → Published` and `UnpublishedEdits → UnpublishedEdits`. **An
  implementation that only increments on publish breaks the editor's concurrency
  contract on the very next autosave** (BR4.5).
- **`Seeded` is reachable only once and never returned to.** Once the document
  exists, no operation removes it — and the bootstrap that created it is guarded on
  the caller claiming revision 0, so a client at revision 5 can never recreate it
  (BR4.8).

---

## Operations

### Read content state — owner

Returns `draft`, `published`, `revision`, `updatedAt`, `publishedAt` and
`hasUnpublishedChanges`. **Confirmed against the running source**, not inferred.

1. Read the stored state through `ContentStore.read_state`.
2. **If no document exists**, synthesise the seeded state and **write nothing**
   (BR4.1).
3. **Parse both documents through the schema.** This is what applies the
   **content-carrying defaults** (BR9.1–BR9.3): an absent research topic resolves
   through the id map and otherwise to `general`; absent research links resolve
   through the seeded map; **an explicitly emptied list stays empty**. This runs on
   the **read path**, every time — it is not a write-path default (BR9.2).
4. **Compute `hasUnpublishedChanges`** as a comparison of `draft` against
   `published` (BR4.2). It is never read from storage.

**A read never writes, never locks and never bootstraps.**

### Read content — public

**This route does not exist in the source.** Verified by execution: it returns 404
there. It is a **new route in the target design**, so its behaviour is **specified,
not preserved, and has no parity fixture**.

It returns the **published document only**. **No draft content may appear in any
public response, in any field, at any time** (BR24.3, realising NFR11). It is
unauthenticated, and it is served from the **published-document cache** below.

Because there is no source behaviour to diff against, **this prohibition has to be
checked by a test of its own** rather than by a fixture comparison.

### Save or publish — the hazard-dense path

**The nine-step check order is BR10.10's and is owned by U6**; steps 3, 4, 6, 7 and
8 are where this unit's rules fire. The order determines which status a
multiply-invalid request receives, so it is reproduced rather than reasoned about.

1. Origin match → not-authorized *(U6)*
2. Owner session → not-authorized *(U6)*
3. **Decoded body over 1,500,000 CHARACTERS → too-large** (BR4.20). **Characters,
   not bytes** — 1.5 M non-ASCII characters can be 3–4 MB of UTF-8, and a byte cap
   would reject documents the current system accepts (BR4.21). **Checked after the
   body is fully read and before the parse** (BR4.22): the position is part of the
   rule, because moving it changes which status a too-large malformed body gets.
4. JSON parse failure → invalid, **distinctly** from a validation failure *(U6)*
5. Body falsy, not an object, or an array → invalid *(U6)*
6. **Validate the content through the schema → invalid carrying per-field issues**
   (BR4.6). Authoritative, in the backend, **before** anything is persisted. The
   browser's generated mirror is for responsiveness only and is never the
   enforcement.
7. Envelope validation → invalid **without** issues *(U6, BR10.12)*. **Step 6 runs
   before step 7** (BR10.11): a request with both a malformed document and a bad
   revision returns the *content* error, which is the one the editor can highlight.
8. **Mint a fresh `mutation_token`, unique to this request**, and call
   `ContentStore.commit` with the content, the base revision, the action, the token
   and **the retention policy `RevisionLedger` supplies** (BR5.9 — the policy is an
   argument, never a constant in an adapter).
9. **A conflict signal → conflict**, with the **current state returned alongside the
   error** so the caller can reconcile; the caller's edits are untouched (BR4.7).
10. **On success**, if the action was publish, **invalidate the published-document
    cache synchronously, before returning** (BR24.2). Return the new revision and
    both timestamps.

**What `commit` does, and why it is one call.** It carries the content update, the
revision entry **and** the retention prune **together**, in one transaction, made
by one caller (ADR-001, BR4.16). The six effects and their guards are specified
branch by branch in `rules.md` BR4.8–BR4.19. Three properties this unit must not
lose:

- **The `mutation_token` is an ABA defence for the side effects**, not redundancy
  with the revision compare-and-set. Statements 4–6 are guarded on
  `revision = next_revision`, **which is not unique to this writer** — a losing
  writer's `next_revision` collides with the winner's `revision`, and without the
  token it would record a phantom history entry carrying the winner's content and
  run a retention prune it was never entitled to run (BR4.13).
- **The history entry's content is read back from the stored `draft` column**, not
  taken from the request (BR4.11) — because validation transforms and defaults
  changed the stored value, which given the item transform is *most of the time*.
- **The compare-and-set result is read by name, never by position** (BR4.17). In the
  source it is read as `results[3]`, unmarked; inserting a statement before it makes
  the write read the wrong result, most likely nothing — **which the route
  interprets as a conflict**. The failure looks like contention, not like a bug.

**The pure-versus-execute split survives the port**: a function that *builds* the
statements and a thin executor that *runs* them. That factoring is what makes the
batch inspectable, and flattening it loses the property.

### Inspect a recovered draft

**The rule that used to live in the browser** (ADR-006). Owner-only.

1. Accept the candidate draft as bytes.
2. Validate it, and **classify every issue** as **recoverable** or **corrupting**
   (BR8.1–BR8.3).
   - **Recoverable** is what an owner produces by typing: present, correctly typed,
     outside its permitted set or range — below a minimum, above a maximum, a failed
     format or custom check, **and a value outside an enumerated set**.
   - **Corrupting** is a malformed record: wrong type, missing required structure,
     not an object or array where one is required, or not parseable at all.
3. **If every issue is recoverable**, return the **normalised document** — repaired
   against schema defaults — plus the classified issues, for the owner to review.
4. **If any issue is corrupting**, report the record unusable.

**The port implements the rule as written, not as the source behaves** (D9). The
source allowlists four issue codes, one of which can never match because it belongs
to a different major version of the validator, and omits the one that fires for a
bad enum — so **one bad enum discards the owner's entire recovered draft** while the
source's own comment states the opposite intent (BR8.4). **The classification is
re-expressed in the new validator's taxonomy, never by copying code strings**
(BR8.5).

**Carried hedge:** the source defect is recorded as *a latent defect with a proven
mechanism, not a confirmed user-visible failure* — the code mismatch was
demonstrated empirically, but the scan could not exercise the editor to observe a
discarded draft. **The port's behaviour does not depend on resolving that**, because
the requirement specifies the intended rule rather than the observed one.

**The failure this operation can produce is a third state, and it is U9's**
(BR8.7): when inspect is **unreachable**, the editor **holds** the draft and shows
an unavailable-and-retry state. So this unit's transport failure must be
distinguishable, to its caller, from a corrupting verdict — a failed inspect is
**not** "discard it".

### Revision history — list

Returns summaries ordered **`revision` DESC, then `baseline` ASC, then `action`
DESC**, capped at **52** (BR5.1, BR5.3).

- **All three sort keys are load-bearing**, and a listing sorted on revision alone
  differs only on a tied revision — while passing any test written from a looser
  wording (BR5.2).
- **52 is not a page size and there is no pagination.** It is `30 + 20 + 2` by
  construction, so the listing limit and the retention policy move together or not
  at all.
- **The order is confirmed against data**: a listing from the running source
  returned revisions 4, 3, 2, 1 as non-baseline drafts, then revision 0 `publish`
  baseline (`starting-published`), then revision 0 `draft` baseline
  (`starting-draft`).

### Revision history — fetch one

1. **Validate the id first** (BR5.5). **Absent** means list. **Present but empty**,
   over 100 characters, or failing the id pattern is **invalid** — not a list and
   not a not-found. The absent-versus-empty distinction is a real branch.
2. Read the entry. **Well-formed but absent, pruned, or carrying no content →
   not-found, with a body that states the current draft is unaffected** (BR5.10).
   **Reassuring the owner is part of the rule**, not decoration.
3. **Restoring never publishes** (BR5.6). It returns the entry's content for review;
   the owner must save or publish explicitly.

### Retention — inside the write, never on a schedule

Retention keeps the **30 most recent non-baseline draft entries** and the **20 most
recent non-baseline publish entries**, **independently** — a run of 30 drafts never
evicts a publish (BR5.7). **The two starting baselines are kept permanently and are
excluded by the delete predicate**, not by sorting high (BR5.8).

`RevisionLedger` **owns this policy and performs no write** (BR5.9, ADR-001): it
supplies the numbers, `ContentAuthority` applies them inside the combined write, and
the ledger's own store access is read-only.

**The prune is read-the-survivors-then-delete-the-rest, inside the transaction**
(BR4.18, BR22.1) — never a query-language predicate, because a document store has no
such construct. **Its ordering is `revision` descending alone and is not
tiebreak-stable; that indeterminacy is inherited and must not be "fixed"** (BR4.19).

**No background worker, scheduler or queue consumer exists anywhere in this unit.**

### The published-document cache

**Owned by `ContentAuthority` so that invalidation never crosses a component
boundary** — a second reader with its own cache would silently miss it.

- **It changes which requests hit storage, never which assets are public.**
- **It holds exactly one entry** — the published document. No key, no per-asset
  entries.
- **A successful publish invalidates it synchronously, before the operation
  returns** (BR24.2).
- **Its interval is a SECURITY parameter with a stated maximum of 5 seconds**
  (BR24.1). A deployment may choose lower, never higher, and **changing it is a
  security change, reviewed like an authorization rule**.

**Why it is a security parameter.** The cache feeds the asset-visibility test: an
asset is public **iff the literal media URL appears anywhere in the serialised
published document**. **A stale entry therefore means an asset the owner has just
unreferenced stays public** — an authorization defect, not a slow page.

**And the interval is the real bound, not a backstop.** The cache is in-process, so
a publish invalidates **only the instance that served it**; every other warm
instance keeps serving its own cached document until its entry expires. The
reasoning for 5 seconds, both bounds, is in `rules.md` § BR24.1 — bounded above by
that exposure window, bounded below by the 50,000 reads/day free-tier figure that
the hard zero-recurring-cost target depends on.

---

## What this unit raises, and what happens to it

**This unit raises; `HttpApi` renders** (BR10.3). The four taxonomy members and
their mapping are U6's (BR10.4), and this unit must raise **only** those four:

| This unit's condition | Raises | Rendered as |
|---|---|---|
| Caller is not the owner | `NotAuthorized` | 403 |
| Stored revision no longer matches the base revision (BR4.7) | `Conflict` | 409 |
| Body over 1,500,000 characters (BR4.20) | `TooLarge` | 413 |
| Schema validation failed (BR4.6) | `Invalid` **with per-field issues** | 400 with `issues[]` |
| Malformed or absent revision id (BR5.5, BR5.10) | `Invalid` / not-found | 400 / 404 |
| **Anything else** | — | **503, not 500**, with a full traceback logged |

**`else → 503` is the branch to get right.** Every framework default and every
reviewer's instinct says 500; **the source returns 503 on all four routes**, and
under the parity rule that is what the owner's browser sees. A port returning 500
has changed observable behaviour for every unexpected failure — while looking more
correct.

**The corollary for this unit:** never raise one of the four members to "get a nicer
status" for an internal error. An internal error **belongs** in the 503 branch,
where it is logged with a traceback. Dressing it as `Invalid` puts a bug in front of
the owner as a content problem.

---

## Derived view — rules summary

Derived from `rules.md`. **Authoritative source: `rules.md`**, which carries each
rule's full text, its logic and its failure mode.

| Group | Rules | Component | Requirement |
|---|---|---|---|
| Reading content state | BR4.1–BR4.2 | `ContentAuthority` | FR4.1; **FR9.3** (BR4.1 — the seeded document) |
| Draft versus publish | BR4.3–BR4.5 | `ContentAuthority` | FR4.2 |
| Authoritative validation | BR4.6 | `ContentAuthority` | FR4.3 |
| Optimistic concurrency | BR4.7 | `ContentAuthority` | FR4.4 |
| **The combined write** | **BR4.8–BR4.19** | `ContentAuthority` | **FR4.5 (hazard)** |
| The request-size cap | BR4.20–BR4.22 | `ContentAuthority` | FR4.6 |
| Listing order | BR5.1–BR5.4 | `RevisionLedger` | FR5.1 |
| Fetching one revision | BR5.5–BR5.6 | `RevisionLedger` | FR5.2 |
| Retention | BR5.7–BR5.9 | `RevisionLedger` | FR5.3 |
| Absent revisions | BR5.10 | `RevisionLedger` | FR5.4 |
| **Recovery classification** | **BR8.1–BR8.5** | `ContentAuthority` | **FR8.3 (hazard)** |
| **Content-carrying defaults** | **BR9.1–BR9.3** | `ContentAuthority` | **FR9.2 (hazard)** |
| The cache's placement and safety property | BR7.1–BR7.2 | `ContentAuthority` | **FR7.6 clause 2** |
| The published-document cache interval | BR24.1–BR24.2 | `ContentAuthority` | **FR7.6 clause 1** (re-homed interval), NFR8 |
| The public read | BR24.3 | `ContentAuthority` | *(BR24.3 is the only rule here with no FR — NFR11)* |
| *Subject to — the error envelope* | *BR10.1–BR10.12* | *U6* | ***FR10.1 (hazard)**, FR10.2, FR4.7* |
| *Subject to — recovery rendering* | *BR8.6–BR8.8* | *U9* | *FR8.3* |
| *Subject to — asset visibility* | *BR7.4* | *U5* | *FR7.2* |
| *Subject to — port obligations* | *BR22.1, BR22.5, BR22.6, BR22.8* | *U2* | *FR4.5, FR4.6, FR9.2* |

---

## Assumptions & Open Questions

- **[open, assigned to this unit — the latent defect with no owner]** **The
  unsavable-recovered-draft window.** The recovery path accepts a stored draft up to
  **6,000,000 characters**; the save path rejects anything over **1,500,000**
  (BR4.20). **A recovered draft between those bounds is restorable into the editor
  and unsavable from it** — it fails as too-large on every attempt, **including
  autosave**. The two limits were chosen independently in the source. **This is real
  behaviour, not speculation.** Two options — **align the limits**, or **warn at
  recovery time** — are set out in full in `rules.md`. **Neither is chosen here**:
  aligning changes preserved behaviour under an otherwise absolute parity rule, and
  warning adds user-facing copy and a new state to U9's surface. This needs the site
  owner.
- **[declaration conflict — RESOLVED by the coordinator]** **`BR7.1` and `BR7.2`
  are now declared by this unit**, having been declared by `u5-media` while carrying
  `owned_by_unit: u4-content-core` and `applies_to: ContentAuthority`. The
  resolution was not that one side was wrong: **FR7.6 is a split requirement that
  nobody had written down as split.** Clause 1 — *"may be cached in-process for a
  short interval … and a publish invalidates it"* — is discharged by `BR24.1` and
  `BR24.2`; clause 2 — *"the cache changes which requests hit storage, never which
  assets are public"* — is `BR7.2` almost verbatim; and `BR7.1` is the placement
  that makes clause 2 achievable. All four are declared here and carried by **one**
  `FR7.6` coverage entry. `u5-media` **consumes** the cache on its public read path,
  holds none of its own (`BR25.1`), and claims no part of FR7.6.
- **[assumption]** `BR24.1`'s **5 seconds** is a **new decision made at this stage**.
  Its two bounds are argued from stated facts — the multi-instance invalidation gap
  and the 50,000 reads/day free-tier figure — but **no measurement was taken**, and
  the read-rate worst case assumes one cached read per interval per warm instance,
  which is an upper bound rather than an observation. If measurement later
  contradicts the lower bound, the value moves **down**, never up.
- **[assumption]** `hasUnpublishedChanges` compares draft and published **by value**.
  The original compared serialised JSON, which is key-order sensitive; value
  comparison is equivalent here because both sides are produced by the same schema.
- **[assumption]** The state machine above is **derived**, not stored: no status
  field exists, and each state is a function of `publishedAt` and the draft/published
  comparison. Nothing decided to model it this way; it is what BR4.2, BR4.3 and
  BR4.4 jointly describe, drawn out so the transitions can be tested.
- **[carried hedge — BR8.4]** The source's classification defect is recorded as *a
  latent defect with a proven mechanism, not a confirmed user-visible failure*. The
  port's behaviour does not depend on resolving it.
- **[carried hedge — the CodeKB is self-inconsistent on two line attributions]** The
  knowledge base gives one helper's location two different lines in a 14-line file,
  and places two schemas in an order that cannot hold under eager evaluation.
  **Neither affects any rule or constraint here** — only line attributions are in
  doubt, and the schema values in `entities.md` were enumerated from the source files
  directly.
- **[note]** **The public read has no parity fixture** — the route returns 404 in the
  source and is new in the target design. BR24.3's prohibition on draft content in a
  public response therefore has to be checked by its own test.
- **[note]** **No background worker, scheduler or queue consumer.** Retention runs
  inside the write that triggers it, and the cache expires by age rather than by a
  sweep.
- **[note]** The editor's remaining save-state flags — `recoveryReady`, `busy`,
  `uploads`, `conflict`, `paused` — and their autosave arming are **behaviour, not
  business rules**, and belong to U9. The parts adjudicated to be rules are the
  recovery classification (here, BR8.1–BR8.5) and the hold-on-unreachable state
  (U9, BR8.7).

## Sources

- `inception/contract-design/contract-summary.md` §§ C1 (the save path's statuses
  and envelope), C2 (`read_state`, `commit`, `list_revisions`, `read_revision`,
  atomicity, prune shape).
- `construction/functional-design/functional-spec.md` §§ *Read content*, *Save or
  publish — the hazard-dense path*, *Inspect a recovered draft*, *Revision history*
  — the workflows above are this unit's half of those flows.
- `construction/functional-design/rules.md` — BR4.1–BR4.22, BR5.1–BR5.10,
  BR8.1–BR8.8, BR9.1–BR9.3, BR10.1–BR10.12, BR7.1–BR7.4.
- `construction/content-core/functional-design/entities.md` — ENT-4, ENT-5, W-1,
  W-2, the cap census, and the derived diagram above.
- `construction/content-core/functional-design/rules.md` — BR24.1–BR24.3 and the
  derived rules summary above.
- `construction/storage-ports/functional-design/rules.md` — BR22.1, BR22.5, BR22.6,
  BR22.8, the port obligations this unit relies on.
- `inception/domain-design/decisions.md` ADR-001, ADR-002, ADR-006.
- `inception/units-generation/unit-of-work.md` § U4.
- **Boot verification of the running source, executed 2026-09-24** — the top-level
  read shape, the three-part ordering confirmed against data, and
  `GET /api/public/content` returning 404.
- `WORKING-RECORD.md` §§ 2 (D9, D11, D12), 3, 5, 8, 9, 10a Condition 1.
