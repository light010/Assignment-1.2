# Functional Spec — U1 `source-fixtures`

**Upstream:** `inception/units-generation/unit-of-work.md`,
`inception/units-generation/unit-of-work-story-map.md`,
`inception/requirements-analysis/requirements.md`,
`inception/domain-design/components.md`,
`inception/contract-design/contract-summary.md`.

This unit **records**; it asserts nothing. Every assertion lives in the unit that
consumes a fixture. The spec is therefore a recording manifest, not a design.

## Why this unit exists and why it is first

Every parity claim in this migration is otherwise checked against a human's
reading of a document. This unit converts the oracle into **data recorded from the
running system**.

**It expires.** Once `madhavi-tripathi/` is retired its responses cannot be
recorded again. That is why five units carry a dependency edge on this one rather
than a note in a plan: a scheduler cannot place a characterization test before its
oracle exists.

## Entity relationships (derived view — `entities.md` is source of truth)

```mermaid
erDiagram
    RECORDED_FIXTURE ||--o| STORED_STATE_SNAPSHOT : "produces state for"
    RECORDED_FIXTURE {
        string fixtureId
        string manifestRef
        string request_method
        string request_path
        map request_headers
        path request_bodyRef
        int response_status
        map response_headers
        path response_bodyRef
        int response_byteLength
        enum identity
        timestamp recordedAt
        string sourceCommit
        text notes
    }
    STORED_STATE_SNAPSHOT {
        string snapshotId
        string takenAfter
        record contentRow
        list revisionRows
        list assetRows
    }
```

*Text fallback:* a `RecordedFixture` has **at most one** `StoredStateSnapshot`
(only the F4/F5 write fixtures produce one); a snapshot belongs to exactly one
fixture. Fixtures group
many-to-one onto the twelve manifest rows F1–F12.

## Rules summary (derived view — `rules.md` is source of truth)

Record raw, normalise at compare time (BR21.1); provenance is what makes a fixture
evidence (BR21.2); deliberate defects are recorded, never corrected (BR21.3);
nothing hosted is touched (BR21.4); blocked is reported as blocked, never skipped
(BR21.5); the size boundary is recorded in characters and bytes both (BR21.6).

## Preconditions

> **Verified 2026-09-24 by execution.** The source application was booted and
> probed. Evidence: `scratchpad/source-boot-verified.md`. Two of these
> preconditions were wrong as first written and are corrected below.

1. **`node scripts/run-framework.mjs dev`** — *not* `pnpm install
   --frozen-lockfile` followed by `pnpm dev`. `package.json` pins
   `packageManager: pnpm@11.25.0` while the host has 10.30.3, so corepack wants to
   fetch 11.25.0 and pnpm then wants to purge `node_modules`
   (`ERR_PNPM_ABORTED_REMOVE_MODULES_DIR_NO_TTY`). The installed tree is complete
   and the brief requires keeping `madhavi-tripathi/` intact as the rollback
   baseline, so the install step is **skipped** and the framework script invoked
   directly. Serves on `http://localhost:5173/` under `vinext dev (Vite 8.0.13)`.
2. The migrations are already applied to the persisted local emulator state under
   `.wrangler/state`. A disposable copy is taken before recording.
3. **Set the cookie `__sites_local_auth=1`.** There is no editor table to seed.
   `build/sites-vite-plugin.ts` (vendored from `@openai/sites-vite-plugin` 0.2.0)
   injects `oai-authenticated-user-id: local_seedy` and
   `oai-authenticated-user-email: seedy@sites.test` behind that cookie, and
   **strips every client-supplied `oai-authenticated-user-*` header first** —
   verified: sending those headers directly still returns 403. The trust boundary
   is the middleware, not the header. Loopback host and address only; `/callback`
   returns 501 in local mode.

Disposable local database, injected local identity, nothing hosted touched,
nothing published. If any precondition cannot be met, this unit reports
**blocked** — never "skipped" — and every dependent unit's parity claim weakens to
the written knowledge base, which is recorded as such rather than glossed
(BR21.5).

## Already confirmed against the running system

These were probed during the boot verification and no longer need discovery during
recording — only capture:

| Route | Status | Size |
|---|---|---|
| `GET /` | 200 | 119,953 B, `text/html; charset=utf-8` |
| `GET /robots.txt` | 200 | 129 B |
| `GET /sitemap.xml` | 200 | 186 B |
| `GET /api/content` unauthenticated | 403 | 62 B, `cache-control: no-store` |
| `GET /api/content` authenticated | 200 | 31,032 B |
| `GET /api/history` authenticated | 200 | 767 B |
| `GET /api/public/content` | **404** | Does not exist in the source — it is a **new** route in the target design |

**The error envelope, captured verbatim:**

```json
{"error":"Please sign in with the website owner’s account."}
```

The apostrophe is **U+2019**, not ASCII `'`. The human answered "Match exactly —
characters" on error-copy parity, so a port that writes `owner's` has changed what
the owner sees. Every error string needs the same byte-level check, and F2 records
them as bytes rather than as text.

**The three-part ordering, proven empirically rather than read off the SQL:**

```
revision 4  draft    baseline=false
revision 3  draft    baseline=false
revision 2  draft    baseline=false
revision 1  draft    baseline=false
revision 0  publish  baseline=true   id=starting-published
revision 0  draft    baseline=true   id=starting-draft
```

Revision DESC; within revision 0 the baselines; and between the two baselines
**publish precedes draft**. That is `revision DESC, baseline ASC, action DESC`
confirmed against data. F3 still records it, because a fixture is what a test can
assert against.

Content top level is `draft`, `published`, `revision`, `updatedAt`, `publishedAt`,
`hasUnpublishedChanges` — exactly the shape C2 specifies.

## The recording manifest

| # | What is recorded | Why this and not less |
|---|---|---|
| F1 | Rendered HTML of `/`, `/sitemap.xml`, `/robots.txt` | The DOM-structure diff's baseline. Normalised at compare time, recorded raw |
| F2 | `GET /api/content` full body, authenticated | The content shape **as the running system actually serialises it**, including field order and the resolved content-carrying defaults |
| F3 | `GET /api/history` with and without `id` | Proves the three-part ordering empirically rather than from a reading of the SQL |
| F4 | `PUT /api/content` — draft save, publish, and a **deliberately stale-revision** save | The 409 body and the state after each. The stale save is the only way to record the conflict path's real shape |
| F5 | Stored row state after each F4 step | Revision number, both timestamps, and the revision-table contents, so retention and ordering are checkable against data |
| F6 | `PUT /api/content` at the size boundary | A body of exactly 1,500,000 characters and one of 1,500,001, **each recorded with its UTF-8 byte length** — this is what proves the cap counts characters, not bytes |
| F7 | `GET /api/media/{key}` for a **published**, a **draft-only**, a **missing** and a **malformed** key. The first three are recorded under **both identities**; the malformed key is recorded **once** — see the identity matrix below for the fixture ids and the reason the counts differ. The recorder must create the published and draft-only assets itself | The public/private/absent triple, including that a non-public asset returns 404 rather than 403, plus the key-shape gate that refuses before either of them is consulted |
| F8 | `HEAD /api/media/{key}` **with a `Range` header present** | Proves HEAD ignores Range and returns 200 with the full length — a behaviour nobody would guess |
| F9 | `GET /api/media/{key}` across every range branch | Satisfiable, multi-range, zero-byte object, oversized suffix, `start >= size`, `end > size`, and a conditional range whose validator does not match. Status, headers and body length for each |
| F10 | `GET /api/media/{key}` with a matching conditional-get validator | Records that **no 304 is returned** despite an ETag being emitted — a deliberate absence that must not be "fixed" |
| F11 | Upload responses for each accepted type, plus rejects | Both cancellation literals if both can be provoked (see open questions) |
| F12 | Response **headers** for every media response | `Cache-Control`, `X-Content-Type-Options`, `Content-Security-Policy`, `Accept-Ranges`, `ETag` |

## Which identity each media fixture is recorded under — read this before F7

**This is the correctness hazard of the whole unit.** The source route is one line:

```ts
// madhavi-tripathi/app/api/media/[key]/route.ts
if(!isPublic && !await editorAccess()) return new Response('Not found',{status:404});
```

`editorAccess()` is true for exactly the `__sites_local_auth=1` identity that
Precondition 3 establishes **for the whole recording session**. So a draft-only
asset fetched with that cookie returns **200 with the body**, not 404.

A recorder that leaves the cookie on — which is the ambient state, and what every
other fixture in this manifest needs — would record **200 as the oracle for the
private case**. The port that matches that oracle then serves non-public assets to
anonymous users. That is FR7.2, one of the seven hazard-marked requirements, and
this is how it would have failed silently.

**Every media fixture therefore states its identity, and the pair is the evidence.**
The single-identity version of these fixtures proves nothing about visibility.

| Key visibility | Anonymous (no cookie) | Owner (`__sites_local_auth=1`) | Fixture ids | Recordings |
|---|---|---|---|---|
| **Published** — `/api/media/{key}` appears in the serialised published document | 200 + body | 200 + body | `F7-media-published-anon`, `F7-media-published-owner` | 2 |
| **Draft-only** — present in draft, absent from published | **404** `Not found` | **200 + body** | `F7-media-draftonly-anon`, `F7-media-draftonly-owner` | 2 |
| **Missing** — well-formed key, no asset row | 404 `Not found` | 404 `Not found` | `F7-media-missing-anon`, `F7-media-missing-owner` | 2 |
| **Malformed key** — fails `/^[a-f0-9-]+\.(jpg\|png\|webp\|pdf\|mp4\|webm\|vtt)$/` | 404 `Not found` | 404 `Not found` | `F7-media-malformed-anon` | **1** |

All of these carry `manifestRef: F7`. **The malformed-key row is a fixture the
recorder must produce**, not an informational note derived from reading the source:
it was added to the matrix at review (R-1) without a manifest row or a fixture id,
which left a recorder following the manifest with no way to know it was expected.
It keeps the `-anon` suffix and `identity: anonymous` — which `identity` being a
required field means it must carry one either way — because anonymous is the
cheaper request to make, not because the branch depends on it. **The absence of an
`F7-media-malformed-owner` counterpart is a decision, not a gap**, and the reason
is immediately below.

**Why the malformed key is recorded once and the missing key twice**, although both
return the same 404 under both identities — the recording count follows the number
of **distinct source branches**, not the number of distinct statuses:

- **Malformed — one branch.** `route.ts` line 6 tests the key regex and returns
  **before** `readContent()` and **before** `editorAccess()` are ever called. The
  response cannot depend on identity, so a second recording would capture the same
  code path twice and prove nothing the first did not.
- **Missing — two branches, one status.** Anonymous is refused at the **line-8 auth
  block** (a well-formed key absent from the published document is not public, and
  `editorAccess()` is false), while the owner passes line 8 and is refused at the
  **line-9 asset-row lookup**. Recording both is **branch-coverage completeness**,
  not evidence of divergent behaviour.
- **Draft-only — two branches, two statuses.** This is the only case where the
  identities genuinely **diverge in what the caller sees**, and it is the one that
  carries the hazard.

A reader should not infer from "recorded twice" that the behaviour differs; only
the draft-only pair carries that meaning.

Three further notes the recorder needs:

- The 404 body is the **plain string `Not found`**, not the JSON error envelope. The
  media route does not use the envelope. Recorded as bytes.
- **404, never 403**, in every refusing case, so the response does not disclose that
  the key exists. The anonymous draft-only cell is the only fixture that proves it.
- **F9, F10 and F12 reuse F7's key set**, so each of them inherits this matrix.
  Range behaviour, the deliberate absence of a 304, and the header set are all
  recorded **under both identities for the draft-only key**, because the branch
  taken differs. They inherit the **published and draft-only** rows only: a
  malformed or missing key returns at line 6 or line 8/9, before any header,
  `ETag`, `If-Range` or `Range` handling exists to record, so there is nothing for
  F9, F10 or F12 to capture on those two rows.

## The media fixtures have no existing state to record

Verified: the content document contains **zero** `/api/media/{key}` references and
the local database holds no assets. F7 through F12 all assume a published asset, a
draft-only asset and a missing key already exist. **They do not.**

So the recorder must, before recording any media fixture:

1. Upload an asset and **publish**, producing the public key.
2. Upload a second asset and save as **draft without publishing**, producing the
   draft-only key — which is the one that must return 404 rather than 403.
3. Use a well-formed but absent key for the missing case.
4. Use a key that **fails the route's key regex** for the malformed case — anything
   not matching `/^[a-f0-9-]+\.(jpg|png|webp|pdf|mp4|webm|vtt)$/`, for example a
   disallowed extension or a character outside `[a-f0-9-]`. Nothing has to be
   created for it, and it is fetched **once** (see the matrix above).

This is a real addition to the procedure and it was not visible from code reading.
It also means F7's public/private/absent triple is only as good as step 2: if the
draft-only asset is accidentally published, the fixture silently becomes a second
copy of the public case and the 404-not-403 behaviour goes unrecorded.

## Format

Each fixture is one file plus a sibling metadata record carrying: the request
(method, path, headers — see the rule below), the response status, the response
headers, the body, and **when it was recorded against which commit**.

**Request headers: full set for F4–F12, selective for F1–F3.** The selective rule
("only headers that affected the outcome") is a judgement made at record time by
whoever runs the recorder, and a header discarded then cannot be recovered once
`madhavi-tripathi/` is retired — the same irreversibility this unit exists to
guard against. For **F4 through F12** — every write, every size-boundary and every
media fixture — record the **complete request header set**, plus the identity used.
Those are the fixtures with no second chance and the ones whose branches depend on
headers. F1–F3 stay selective: they are plain reads whose diffs would otherwise be
swamped by per-run server and date headers. A fixture without its
provenance is an assertion, not evidence.

The recorder itself is committed. A reader must be able to see how each fixture
was obtained, and re-run it while the source still exists.

## What is NOT recorded

- Anything requiring hosted D1 or R2 — neither is in the export.
- Anything requiring the platform's ChatGPT identity beyond the local test identity.
- Timing or performance figures. This unit records behaviour, not speed.
- **The WebMCP `stage_academic_profile` browser tool**, which `project.md` mandates
  preserving. It registers on `document.modelContext` and has **no HTTP surface**,
  so there is nothing for an HTTP recorder to capture. Its characterization belongs
  to **U9 `owner-editor`**, which owns the editor it registers from. Named here so
  the manifest does not read as exhaustive over the preserved surface. Its exact
  registration and `execute` behaviour are already recorded, from source, in
  `scratchpad/webmcp-tool-verified.md`.

## Assumptions & Open Questions

- **[RESOLVED 2026-09-24]** ~~`madhavi-tripathi/` has not yet been booted in this
  workflow.~~ It was booted and probed. It runs, it serves, and the routes,
  content shape, error envelope and revision ordering above are recorded from
  execution. Evidence: `scratchpad/source-boot-verified.md`. This was the single
  largest unverified assumption in the plan; it is closed, and the three other
  artifacts that recorded it should be read with this note.
- **[open]** The source contains **two** cancellation literals — `Upload cancelled.`
  and `Upload cancelled. Your previous file is unchanged.` Which 499 carries which
  is unconfirmed, and the knowledge base documents only the longer one. F11 should
  provoke both if it can; if only one is reachable, record which and say so.
- **[assumption]** A recorded response is a faithful oracle. It records what the
  system *does*, which under a parity rule is exactly the requirement — including
  where what it does is a defect being deliberately preserved.
- **[open]** Whether a save can still be performed against the persisted
  `.wrangler/state` without disturbing it. The boot verification was read-only plus
  one cookie; F4, F5, F6 and F11 all write. The disposable copy in precondition 2
  is what makes that safe, and taking it is the first thing the recorder does.
- **[assumption]** F6's boundary fixtures are recordable. If the running system
  cannot be driven to exactly 1,500,000 characters, the character-vs-byte claim
  falls back to code reading, and the cap is the one constraint where that
  distinction is invisible until it rejects the owner's longest transcript.
