# Code Summary — U2 `storage-ports`

**Unit:** `storage-ports` · **Kind:** `library` · **Stage:** `code-generation`

**Target tree:** `chiku-website/backend/`. `madhavi-tripathi/` was neither read from nor
written to by this unit — it has no HTTP surface and no recorded fixture is its oracle.

Ten application modules and four test files. No pre-existing file was modified, no
dependency was added, and no `# noqa` or `# type: ignore` was introduced.

---

## What was built

```
app/sqlite.py                    connection, schema, the declared index, the to_thread
                                 boundary, the column readers  [ONLY sqlite3 importer]
app/content/store.py             ContentStore protocol + three record shapes
app/content/store_sqlite.py      verified adapter               [HAZARD]
app/content/store_memory.py      in-memory fake
app/auth/store.py                IdentityStore protocol + three record shapes
app/auth/store_sqlite.py         verified adapter               [HAZARD]
app/auth/store_memory.py         in-memory fake
app/assets/store.py              AssetStore protocol + ObjectHead + compute_etag
app/assets/store_volume.py       verified adapter: bytes on a volume
app/assets/store_memory.py       in-memory fake

tests/conformance/__init__.py           package marker (see Deviations, item 3)
tests/conformance/conftest.py           the adapter parameterisation
tests/conformance/test_content_store.py    8 tests, 16 runs
tests/conformance/test_identity_store.py   6 tests, 12 runs
tests/conformance/test_asset_store.py      5 tests, 12 runs
```

---

## Ordering — the approved Testing Contract was followed, not converted

Methodology `custom`. The contract's ordering clause is load-bearing for this unit
specifically: *"the characterization tests for that unit's hazard-register behaviours
**and for the storage port** are written and observed to fail before the Python
implementation of that behaviour exists."* This unit is entirely storage port.

Step 3 wrote the **full** conformance suite for all three ports and ran it. Every one of
the 19 test functions was unrunnable, because all seven implementation modules were
absent:

```
ImportError while loading conftest '.../tests/conformance/conftest.py'.
tests/conformance/conftest.py:31: in <module>
    from app.assets import store_memory as asset_memory
E   ImportError: cannot import name 'store_memory' from 'app.assets'
```

```
app.sqlite: MISSING (No module named 'app.sqlite')
app.content.store_sqlite: MISSING (No module named 'app.content.store_sqlite')
app.content.store_memory: MISSING (No module named 'app.content.store_memory')
app.auth.store_sqlite: MISSING (No module named 'app.auth.store_sqlite')
app.auth.store_memory: MISSING (No module named 'app.auth.store_memory')
app.assets.store_volume: MISSING (No module named 'app.assets.store_volume')
app.assets.store_memory: MISSING (No module named 'app.assets.store_memory')
```

Steps 4 and 5 then took it to Green. Steps 3 and 5 were not merged and the ordering was
not converted into layer-local TDD.

---

## The four obligations no ordinary correctness assertion catches

| Obligation | Where it lives | How it is held |
|---|---|---|
| `commit` is one transaction, six effects, all-or-none (BR4.16) | `SqliteDatabase.transaction` opens `BEGIN IMMEDIATE`; the connection context manager commits or rolls back; `_StaleWrite` is how a conflict leaves nothing | A conflicting write rolls back rather than relying on an argument about which guards happened not to match |
| The CAS outcome is read **by name** (BR4.17) | `UPDATE ... RETURNING` plus `sqlite3.Row`; `_state_from_row` reads every column by name | **No positional read exists in this adapter**, so no index needs asserting by a test. The source's `results[3]` has no counterpart here |
| The prune is read-the-survivors-then-delete-the-rest (BR4.18, BR22.1) | `prune()` reads survivor ids first and the `DELETE` names them; no `WHERE id NOT IN (subquery)`; `baseline = 0` in the predicate; `ORDER BY revision DESC` **alone** | Both halves are asserted, and both are caught by mutation |
| `get_range` transfers only the window (BR22.11) | `read_window` → `os.pread(fd, length, offset)`; the fake's `MemoryAssetStorage.read_window` | The suite records what the adapter asked its underlying store for. A whole-object slice fails it in **both** implementations |
| `create_if_absent` is atomic against a concurrent caller (BR22.13) | One `INSERT` naming both uniqueness constraints as conflict targets; `rowcount` is the answer | Eight genuinely concurrent callers, exactly one creation. A read-then-write spelling fails it in both implementations |

### The entity tag — the open question carried into generation

Resolved as the plan proposed, not substituted. `compute_etag` is a quoted SHA-256 of the
bytes, computed at `put` and stored in the volume adapter's sidecar, never derived from
mtime or inode.

The plan's stated reason (neither survives a container rebuild or a volume restore) is
right but is **not** what a naive test catches: any tag computed once at write time and
stored beside the object is stable across reads and across handles, including one read
off a clock. What separates a content-derived tag is what happens when the **same bytes
are written again** — a clock or an mtime moves, an inode moves when the file is
recreated, a hash does not. The test therefore re-puts identical bytes and
deletes-then-re-puts them. That is the assertion that bites; the repeated-read assertion
is the weak half and is documented as such in the test.

---

## Coverage — both floors met, neither relaxed

```
app/content/store_sqlite.py      80      0     10      0   100%
app/auth/store_sqlite.py         66      0     12      0   100%
TOTAL                           642      7     86      0    99%
```

- **80% branch over `chiku-website/backend/`** — **99%**. Floor met.
- **100% branch on the two hazard modules** — **100%**. Floor met.

`pyproject.toml` was not touched: no threshold was edited, no `omit` was added, no
`--include` was narrowed. The two gaps that did appear were closed by covering the
behaviour, not by configuring it away:

- `_optional_iso`'s non-null branch was uncovered because no test stored a session that
  **arrives** already revoked. That is a real case — the store records what it is given —
  so the test now stores one.
- `SqliteDatabase.path` was an unused property. It was deleted rather than exercised.

`app/errors.py` remains at 85%, unchanged from before this unit; its uncovered lines are
FastAPI exception handlers owned by U6.

---

## Does the suite actually bite?

A green suite over code the same person wrote is weak evidence. Twenty-two single-defect
mutations were applied one at a time to the implementations and the unit command re-run
against each. **17 of 22 were caught.** The five survivors are analysed below rather than
left as a number; each is a property of the port, not a test that was written carelessly.

Caught, among others: dropping the baseline predicate from the prune (both
implementations); one combined retention cap instead of two; `read_state` creating the
document lazily; whole-object-then-slice in `get_range` (both implementations);
`session_touch` also refreshing the absolute bound (both); `create_if_absent` as
read-then-write (both); `asset_metadata_remove` raising on an absent key; an mtime-derived
entity tag; login attempts keyed on the subject alone; `list_revisions` ignoring the cap;
`session_read` filtering revoked sessions; `put` altering the bytes it was given.

---

## Gaps surfaced, not closed

### 1. The `baseline ASC` and `action DESC` sort parts are not discriminable through this port

`functional-spec.md` § *The conformance suite* requires "the full three-part listing
order, **including a tied revision**". The assertion is present, spells out the expected
order across the tie, and is correct — but removing `action DESC` from either
implementation does **not** fail it.

The reason is structural, and it is in the port's own write semantics. The two baselines
are captured at `revision = base_revision` by the first commit that reaches them, and on
a fresh store that first commit must be at `base_revision = 0` (any other value finds no
document to compare against and conflicts). Every normal entry takes `base_revision + 1`,
so **every normal entry has revision ≥ 1 and the baselines are pinned at 0**: a baseline
and a normal entry can never tie, which makes `baseline ASC` unobservable. The only tie
the port can produce is the baseline pair itself — and BR4.9 fixes their insertion order
as `starting-published` then `starting-draft`, which is exactly what `action DESC`
requires, so both implementations produce the correct tie order by accident as well as on
purpose.

**This is not a reason to weaken the assertion, and it has not been weakened.** It is
live against the adapter it was written to protect: a document store returning ties in
its own order (the Firestore case BR5.4 and BR22.9 warn about, owned by U11) would fail
it. It is inert only against these two implementations.

`entities.md` says "a baseline pair and a normal entry **can** share one" revision. That
is true of the shape and of a migration in which history predates the baseline capture —
which the port has no operation to reach. **Owner: U11 `cloud-adapters`**, which is where
the assertion becomes discriminating.

### 2. The `last_mutation` guard on effects 4–6 is a redundant second defence here

Removing it from the SQLite adapter does not fail the suite. The adapter raises
`_StaleWrite` and rolls the transaction back the moment the compare-and-set matches
nothing, so effects 4–6 are **unreachable** on the stale path — the source ran all seven
statements regardless and relied on the token to neutralise the last three.

The guard is kept, in the SQL, in both implementations, because BR4.14 and BR4.15 say so
and because an adapter with weaker isolation inherits the contract, not this adapter's
short-circuit. What the suite certifies is the **outcome** (a stale writer inserts nothing
and prunes nothing), which is what the owner would observe; it cannot certify which of two
independent defences produced it. Recorded rather than presented as full coverage.

### 3. BR4.11's read-back is structurally unobservable in this port

BR4.11 requires the history entry's `content` to be read back from the record's stored
`draft` column and its `created_at` from the record's `updated_at`, rather than taken
from the caller's argument. Both implementations do exactly that, and a mutation that
inserts the caller's payload instead survives the suite.

It survives because **the store transforms nothing** (BR22.6): `content` and the stored
`draft` are the same value by construction, and `now` and the record's `updated_at`
likewise. The divergence BR4.11 guards against — "whenever validation transforms or
defaults changed the stored value" — arises above this port, in U4, not inside it. The
obligation is implemented as written so that it stays correct if effect 3 ever stores
anything other than its argument.

### 4. Mutation 14 was mis-designed, and its survival is positive evidence

"`commit` stops rolling back on a stale write" injected a destructive prune before
`raise _StaleWrite`. The suite stayed green **because the transaction rolled the injected
prune back**. That is the atomicity of BR4.16 working, not a hole in the suite. Recorded
so the 17/22 figure is not read as five weaknesses.

---

## Deviations from the design artifacts

Each is a place where the artifacts and a working implementation did not line up. None
was resolved silently.

### 1. `login_attempts.record_failure` takes a `window_length` argument

`contract-summary.md` § C3 and `functional-spec.md` spell it
`record_failure(scope, window_key, now)`. The same sentence specifies its behaviour as
*"increments the counter for that scope and key, **starting a new window when the current
one has rolled over**"* — and **rollover is not decidable from those three arguments**.
`entities.md` fixes the persisted shape as a counter plus a window start, not a list of
instants, so the operation cannot infer the window length from what it stores.

Two alternatives were considered and rejected:

- *Start a new window only when no record exists, and let `count_in_window` return 0 for
  an elapsed window.* The counter then accumulates forever and `window_started_at` never
  advances, so the count is zero for every window after the first. A rate limiter that
  silently stops counting is worse than a changed signature.
- *Have the consumer `clear` then `record_failure` when the count comes back 0.* That
  composes only the specified operations, but it is racy and it moves the rollover
  decision to the consumer, which the specification explicitly assigns to this operation.

The parameter is added, and `window_is_current` in `app/auth/store.py` is the **one**
predicate both the count and the record operations use, so the two can never disagree
about whether a window has rolled over. **Owner of the contract correction:
`contract-design` (U2 owns C3).**

### 2. `seed` and `listing_cap` reach an implementation at construction

`read_state()` takes no arguments in C2, yet it must return the seeded document; and the
listing is capped at 52, yet BR5.9 forbids an adapter from holding policy numbers. Both
are constructor arguments, so the signatures match the contract and neither number lives
in an adapter. `listing_cap_for(retention)` in `app/content/store.py` derives 52 from
`30 + 20 + 2`, making BR5.3's "the same number by construction" literally true and
checkable — the suite asserts it.

### 3. `tests/conformance/__init__.py` is not in the plan's file list

It is a package marker, added out of mechanical necessity. Without it, pytest's prepend
import mode names both `tests/conftest.py` and `tests/conformance/conftest.py` the
top-level module `conftest`; whichever loads first wins `sys.modules["conftest"]`, and the
four pre-existing test modules' `from conftest import meta` then resolves to the wrong
file. This was observed, not predicted: creating the conformance conftest without the
marker failed collection of **all 325 pre-existing tests**. With the marker the module is
`conformance.conftest` and the collision cannot occur.

### 4. `get_range` raises where `get` and `head` return absence

`functional-spec.md` states both "absence is a return value, not an error" and, for
`get_range`, "a request for a window that does not exist in the object is a **defect in
the caller** … the adapter reports it rather than returning short bytes silently". These
are reconciled by the operation's purpose: `get` and `head` exist to discover presence,
while `get_range`'s caller has already resolved an offset and a length against a size it
obtained from `head`. `ObjectNotFound` and `RangeNotAvailable` are distinct so the
consumer can map them differently; neither chooses a status code.

### 5. `asset_metadata_register` replaces on a duplicate key, in both implementations

The operation is specified as "stores the record exactly as given" and no test covers a
duplicate key. Left to the obvious spellings, the SQLite adapter would raise on the
duplicate and the fake's mapping assignment would overwrite — **two implementations
diverging on a case the suite does not cover is a port with an undeclared behaviour**, so
both replace and both say so.

### 6. Instants are `datetime` in the port and ISO-8601 text in storage

`entities.md` types them as `instant-iso8601-utc`. `count_in_window` needs real instant
arithmetic, so the port's Python type is an aware `datetime` and the adapter converts.
`isoformat`/`fromisoformat` are exact inverses including the offset, so the round trip is
the identity — the value is stored as the consumer supplied it and is **not** normalised
to UTC first, because normalising would change the value on the way through.

### 7. `owner_record` carries a `singleton` column

It is the mechanism that makes BR22.13 satisfiable in one statement: a second insert
violates its uniqueness constraint, so the conflict is resolved inside SQLite rather than
between a read and a write. It constrains the **shape** (`cardinality: singleton`) and
validates no value a caller supplied, so BR22.6 is untouched.

### 8. No foreign key from `session_record.owner_id` to `owner_record`

`entities.md` records the reference. A referential constraint is not declared by this
port, and the in-memory fake — the second implementation that proves the suite tests the
port — could not reproduce it, so the two would differ on exactly the kind of behaviour
the suite exists to hold identical. The relationship is documented in the schema comment.

### 9. A connection per operation, not one shared connection behind a lock

A lock around a shared connection would have been what serialised two concurrent writers,
and the provisioning race would then pass against a read-then-write implementation
because the lock removed the interleaving the test exists to produce. Measured: with two
contenders the read-then-write defect was caught in roughly half of runs; with eight it
was caught 15 times out of 15, while the correct implementation passed 15 out of 15.

### 10. Asset keys are base64-encoded on disk

The store validates nothing (BR22.6), so it cannot reject a key containing `/` or `..` —
and it must not be traversed by one either. URL-safe base64 without padding makes
traversal structurally impossible rather than checked, and the encoding is total,
lossless and reversible, which is the representation conversion BR22.6 permits.

---

## Security

- **No default, seeded, sample or hard-coded credential exists** in any adapter, in the
  schema, or in any fixture. `app/sqlite.py`'s `initialize()` creates tables and nothing
  else; `MemoryIdentityStorage.owner` starts as `None`. A fresh start against empty
  storage has no account anyone can sign in to, and the first assertion of the
  provisioning test is exactly that.
- The one PHC-shaped string in the suite is an opaque blob with no password behind it and
  nothing that verifies it. It is used to assert that the hash round-trips verbatim.
- The argon2id hash is written and read verbatim. No module in this unit parses it,
  compares it, derives from it or logs it — there is no logging call in any store.
- `ruff`'s `S` (flake8-bandit) ruleset is clean with no suppressions. Every SQL statement
  is a literal with bound parameters; no query is built by string interpolation.

## Boundary discipline

- `grep -rn "import sqlite3" app tests` returns **`app/sqlite.py:27` only**. The driver's
  types are re-exported as `Connection` and `Row` so an adapter can annotate its work
  functions without importing the driver.
- Every `sqlite3` call and every filesystem call runs inside `anyio.to_thread.run_sync`.
  No store blocks the event loop.
- The ports are `typing.Protocol` classes, so conformance is structural and
  `mypy --strict` checks it at every call site — including the conformance harness's
  factories, whose return annotations are the port types.
- Storage-level spelling is `snake_case` everywhere, columns included. **No `camelCase`
  identifier appears anywhere in this unit.**

## Verification

All run from `chiku-website/backend/`, all exit 0.

| Command | Result |
|---|---|
| `uv run pytest tests/conformance -q` | 40 passed |
| `uv run pytest -q` | 365 passed (325 pre-existing + 40 new) |
| `uv run pytest --cov --cov-branch -q` | TOTAL 642 stmts, 7 miss, 86 branch, 0 partial, **99%** |
| `uv run coverage report --fail-under=80` | 99%, exit 0 |
| `uv run coverage report --fail-under=100 --include="app/content/store_sqlite.py,app/auth/store_sqlite.py"` | 100%, exit 0 |
| `uv run ruff check` | All checks passed! |
| `uv run ruff format --check` | 29 files already formatted |
| `uv run mypy --strict app tests` | Success: no issues found in 29 source files |

## Sources

- `construction/storage-ports/functional-design/functional-spec.md` — every operation,
  its behaviour, and § *The conformance suite*, which is the authoritative list of what
  the suite must assert.
- `construction/storage-ports/functional-design/entities.md` § *Source of truth* — every
  persisted shape, field, type, nullability and constraint.
- `construction/storage-ports/functional-design/rules.md` — BR22.1–BR22.14 as declared
  here; BR3.\*, BR4.\*, BR5.\*, BR6.\*, BR7.\* as enforced but declared elsewhere.
- `inception/contract-design/contract-summary.md` §§ C2, C3, C4 — the hand-written port
  operation signatures.
- `aidlc/spaces/default/memory/team.md` § *Testing Posture* — the adapter-parameterised
  conformance suite over two implementations, and the two coverage floors.
- `construction/storage-ports/code-generation/code-generation-plan.md` and
  `unit-test-instructions.md` — the approved plan and its embedded Testing Contract.
