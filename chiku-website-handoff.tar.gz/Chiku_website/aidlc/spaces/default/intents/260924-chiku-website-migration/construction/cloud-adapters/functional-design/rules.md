# Rules — U11 `cloud-adapters`

**Upstream:** `inception/contract-design/contract-summary.md`,
`inception/units-generation/unit-of-work.md`,
`inception/requirements-analysis/requirements.md`,
`inception/domain-design/components.md`.

These carry `BR31.x` ids. Group 31 is U11's unit-scoped group under the corpus
scheme: FR-derived groups are `BR3.x`–`BR10.x` and keep the numbers the
workflow-level `rules.md` gave them; a rule realising only an NFR or a constraint
takes a unit-scoped group at **unit number + 20**.

> **Correction.** These were first written as `CA-` ids on the reasoning that a
> `BR` id reaching no `FR` would be reported as an orphan. That was right, and the
> conclusion was wrong: the `reverse` array in `traceability.json` exists for
> exactly that case, and the traceability sensor does not recognise an invented
> namespace — so ids chosen to avoid a false trace produced no trace at all.
> Renumbered to `BR31.x` and listed in `reverse`, against **NFR3**, **NFR6** and —
> for `BR31.5`, the unverified-labelling rule — the **C4** authorization constraint.

This unit implements ports rather than requirements. Its rules realise NFR3's
cloud half and support NFR6.

```yaml
rules:
  - id: BR31.1
    statement: The port is the contract; an adapter never negotiates it.
    category: constraint
    applies_to: all three adapters
    trigger: An adapter cannot satisfy a port operation as specified.
    logic: >
      IF an adapter cannot satisfy a port operation THEN the port is wrong and
      changes at its owner (U2). The adapter does not weaken the operation, add a
      parameter, or document an exception.
    violation: >
      Two adapter families exist so that one conformance suite proves both. An
      adapter with its own semantics makes the suite prove nothing.
    source: NFR3

  - id: BR31.2
    statement: >
      Every field whose serialised payload exceeds the threshold - the draft, the
      published document, AND the revision entry's content - is written as a
      content-addressed blob before the transaction, never after; and where the
      whole document still does not fit, further fields are substituted
      LARGEST-FIRST until it does.
    category: constraint
    applies_to: ContentStore combined write (Firestore)
    trigger: A serialised content payload exceeds the large-payload threshold.
    logic: >
      IF the payload is too large for one Firestore document THEN write the
      content-addressed blob to Cloud Storage and wait for it to land, THEN open
      the transaction and reference its key.
    violation: >
      The reverse order leaves a document referencing a blob that never landed — a
      dangling reference, which is corruption. This order leaves at worst an
      orphaned blob, which is reclaimable garbage, and the key being a content hash
      is what makes the retry idempotent.
    source: NFR3
    source_note: >
      Cited FR4.6 until review (R-02). FR4.6 is a VALIDATION rule - it fixes the
      1,500,000-character ceiling the port must accept - and it is discharged by
      U4, which performs the accept-or-reject. This rule only handles a downstream
      STORAGE consequence of the boundary FR4.6 sets; it does not discharge it.
      Claiming FR4.6 here overstated this unit's coverage, the same defect class
      already found in two sibling units. The requirement is still what motivates
      the rule, which is why it is named here rather than dropped.
    note: >
      This resolves a real conflict: FR4.6 requires accepting 1,500,000 decoded
      characters, Firestore's per-document limit is 1,048,576 bytes, and a revision
      entry stores full content. CORRECTED AT REVIEW: an earlier version of the
      write algorithm substituted only the CONTENT DOCUMENT and wrote the revision
      entry inline - resolving the conflict for the wrong object, since the
      revision entry is the shape contract-summary C2 names as unable to fit.
      Substitution is per field and covers ContentRevision.content.
      TIE-BREAK ADDED (R-01 suggestion, applied at the R-05 fix): a field that does
      NOT individually exceed the threshold can still need substituting, when the
      fields' SUM does not fit - only ContentDocument can reach that case, since it
      alone carries two full-content fields. That branch was unspecified, and this
      is a hazard module with a 100% branch-coverage floor, so the order is now
      fixed: largest serialised size first, rechecking after each, ties broken
      draft before published. Terminates by construction - substituting every field
      leaves only small keys. Invisible through the port either way, since reads
      reverse substitution; what it buys is ONE predictable stored state the
      conformance suite can assert.

  - id: BR31.3
    statement: >
      Retention pruning is read-then-delete, never a predicate over the set to
      remove - AND every read the transaction needs is gathered before its first
      write.
    category: constraint
    applies_to: >
      ContentStore combined write (Firestore), including the retention prune it
      carries.
    trigger: Any combined write that prunes revisions.
    logic: >
      IF the prune is expressed THEN express it as: read the survivors, delete the
      rest, inside the transaction. Never as a predicate over the set to remove.
      AND IF the transaction needs a read - the content document for the conflict
      check, the revision entries for survivor determination, or any other - THEN
      issue it in the transaction's read phase, before the first write. Never after.
    violation: >
      Two failures, one root cause. (1) Firestore has no
      DELETE ... WHERE id NOT IN (subquery). A SQL-shaped prune would be
      satisfiable by exactly one adapter, which is the shape the port exists to
      prevent. (2) A Firestore transaction executes as a sequence of reads followed
      by a sequence of writes, and REJECTS a read issued after a write - so the
      read-then-delete shape this rule mandates is only legal if that read sits in
      the read phase. The algorithm originally placed the survivor read after the
      content and revision writes, and because pruning fires on every combined
      write once the retention cap is reached, that transaction would have failed
      at runtime on essentially every save.
    source: NFR3
    note: >
      Extended at review (R-05, Critical). The rule already reasoned correctly
      about why a SQL predicate is wrong here; the SAME SQL-shaped mental model is
      what produced the read-after-write, because in SQL a statement's position
      relative to other statements in a transaction is unconstrained and here it is
      not. Getting the prune's EXPRESSION right does not by itself get its
      PLACEMENT right, so the rule now governs both. The fix was pure resequencing:
      the survivor set is computable before the new entry exists, since that entry
      ranks first under revision DESC (its number is base_revision + 1) and its
      action is a caller argument - so it is always a survivor and never changes
      which existing entries fall outside the cap.

  - id: BR31.4
    statement: >
      EXACTLY ONE composite index is required - [revision DESC, baseline ASC,
      action DESC] on the revisions collection - and its definition travels with
      the deployment artifact set. No query this unit issues may require a second
      one.
    category: constraint
    applies_to: >
      ContentRevision listing, AND every other query over the revisions collection,
      including the retention prune's survivor read.
    trigger: >
      Packaging the deployment plan, or adding or reshaping any query over the
      revisions collection.
    logic: >
      IF the index backing the three-part revision order is not part of the
      deployment artifacts THEN the listing query fails at runtime with no
      definition available to apply. AND IF a query over the revisions collection
      would require any composite index other than that one THEN the QUERY is
      reshaped rather than the index set extended - or, if a second index is
      genuinely unavoidable, it is added to the deployment artifacts in the SAME
      change that introduces the query, never afterwards.
    violation: >
      A runtime failure is better than a quiet reordering - but only if the
      definition exists somewhere a deployer will find it. The singular matters for
      the same reason: an UNDECLARED composite index also fails at runtime, so a
      rule whose whole purpose is to prevent that class of failure must not itself
      depend on a second instance of the class being remembered. One index is a
      claim a deployer can check; "the indexes" is a list someone has to maintain.
    source: NFR3, NFR6
    note: >
      Singular ON PURPOSE, not singular by accident - made explicit at the R-05
      fix. The retention prune's survivor read is deliberately shaped to need no
      second index: a single UNFILTERED revision DESC read of the bounded set,
      partitioned by action in memory. The filtered alternative - equality on
      action plus orderBy revision DESC - would require a composite index on
      (action, revision DESC) that nothing declares. The unfiltered read needs no
      index beyond what exists, since an ordering on one field is served by the
      automatic single-field indexes and the declared composite index covers that
      ordering as its prefix. If anyone later switches the survivor read to a
      filtered query, this rule names exactly what they have broken.

  - id: BR31.5
    statement: This unit's unverified status is stated in the README and in the deployment plan.
    category: policy
    applies_to: all three adapters
    trigger: Writing or reviewing any artifact that describes these adapters.
    logic: >
      IF a reader can encounter these adapters without learning that no execution
      has ever confirmed them against a real Google service THEN the labelling is
      insufficient.
    violation: >
      Code that passes a conformance suite looks exactly like code that works. The
      distinction here is real and was chosen deliberately, so it has to be visible.
    source: NFR3, C4

  - id: BR31.6
    statement: Runtime services and the storage they use are deployed in the same region.
    category: constraint
    applies_to: deployment topology
    trigger: Choosing where anything is placed.
    logic: >
      IF components are placed in different regions THEN service-to-service traffic
      moves from free to chargeable, and for Cloud Storage the free tier is forfeited
      entirely outside us-west1, us-central1 and us-east1.
    violation: The zero-recurring-cost target fails. Not a performance trade — a billing one.
    source: NFR6
    note: Stated again as BR32.3 and BR32.4 in U12, where it becomes a deployment step.
```

## Rules summary

| id | Category | What it protects | Source |
|---|---|---|---|
| BR31.1 | constraint | The port's semantics are not negotiable by an adapter | NFR3 |
| BR31.2 | constraint | Blob before transaction; orphan garbage over dangling reference | NFR3 |
| BR31.3 | constraint | A prune shape both adapters can satisfy, and all reads before any write | NFR3 |
| BR31.4 | constraint | Exactly one composite index, named, and it ships with the plan | NFR3, NFR6 |
| BR31.5 | policy | Unverified status is impossible to miss | NFR3, C4 |
| BR31.6 | constraint | One region, or the free-tier reasoning collapses | NFR6 |

## Why each rule exists

The YAML block above is the source of truth. These notes carry the failure mode
behind each rule.

### BR31.1 — The port is the contract; the adapter never negotiates

**Rule:** if an adapter cannot satisfy a port operation, **the port is wrong and
changes at its owner (U2)**. The adapter does not weaken the operation, add a
parameter, or document an exception.

**Why:** two adapter families exist so the same conformance suite proves both. An
adapter with its own semantics makes the suite prove nothing.

### BR31.2 — Blob before transaction, never the reverse

**Rule:** where a payload is too large for one Firestore document, write the
content-addressed blob to Cloud Storage **first**, then reference its key inside
the transaction.

**Why:** a failed transaction then leaves an orphaned blob, which is reclaimable
garbage. The reverse order leaves a document referencing a blob that never landed —
a dangling reference, which is corruption. The key being a content hash is what
makes the retry idempotent.

**Which fields, and in what order.** The check is **per field**, not per write, and
covers `ContentDocument.draft`, `ContentDocument.published` and
`ContentRevision.content`. A field that does not individually exceed the threshold
can still need substituting when the fields' **sum** does not fit — reachable only
for `ContentDocument`, the one document carrying two full-content fields. That
branch is resolved **largest-first**, rechecking after each substitution, ties
broken `draft` before `published`. It terminates by construction, and it is
invisible through the port; its value is that the stored state is **one**
predictable outcome the conformance suite can assert rather than a choice left to
the implementer.

### BR31.3 — The prune is read-then-delete, never a predicate — and every read comes first

**Rule:** retention pruning reads the survivors and deletes the rest, inside the
transaction. It is never expressed as a predicate over the set to remove. **And
every read the transaction needs — the content document for the conflict check,
the revision entries for survivor determination — is issued in the transaction's
read phase, before its first write.**

**Why, part one:** Firestore has no `DELETE ... WHERE id NOT IN (subquery)`. A
SQL-shaped prune would be satisfiable by exactly one adapter, which is the shape
the port exists to prevent.

**Why, part two — the same mistake, one level down.** A Firestore transaction is a
sequence of reads followed by a sequence of writes, and it **rejects a read issued
after a write**. So the read-then-delete shape part one mandates is only legal if
that read sits in the read phase. The algorithm originally placed the survivor read
after the content and revision writes — and since pruning fires on every combined
write once the retention cap is reached (see `entities.md` § `transaction_scope`),
that transaction would have failed at runtime on essentially every save, not on
some rare path. The root cause is identical to part one's: in SQL, a statement's
position relative to the other statements in a transaction is unconstrained, and
here it is not. Getting the prune's *expression* right does not get its *placement*
right, which is why one rule now covers both.

Correcting it cost nothing behavioural, because the survivor set can be determined
before the new entry exists: that entry ranks first under `revision DESC` (its
number is `base_revision + 1`, necessarily the highest), so it is always a survivor
and never decides which *existing* entry falls outside the cap, and its `action` —
which the per-action policy keys on — is a caller argument. Pure resequencing, no
change to what gets pruned.

### BR31.4 — Exactly one composite index, and it travels with the deployment plan

**Rule:** exactly **one** composite index is required — `[revision DESC, baseline
ASC, action DESC]` on the `revisions` collection — and its definition is part of
the deployment artifact set, not an operational afterthought. **No query this unit
issues may require a second one.**

**Why the definition must ship:** without it the query fails at runtime. That is a
loud failure, which is better than a quiet reordering — but only if the definition
exists somewhere a deployer will apply it.

**Why the count is singular on purpose.** An undeclared composite index fails at
runtime too, so a rule that exists to prevent that class of failure must not depend
on a *second* instance of the class being remembered by whoever writes the next
query. Naming the count converts "the index" from an assumption a reader might not
notice into a claim the design is making and can be held to. One index is something
a deployer can check; "the indexes" is a list someone has to maintain.

The retention prune's survivor read is shaped to honour this: it is a **single
unfiltered `revision DESC` read of the bounded set, partitioned by action in
memory**, precisely so it needs no index of its own. The filtered alternative —
equality on `action` plus `orderBy revision DESC` — would require a composite index
on `(action, revision DESC)` that nothing declares, and would have failed at runtime
on every prune. That decision is recorded in `functional-spec.md` § "The combined
write, on Firestore" with its three reasons. **If anyone later switches the survivor
read to a filtered query, this rule is what tells them what they have broken.**

### BR31.5 — Unverified means labelled, everywhere

**Rule:** this unit's status as unverified against real Google services is stated
in the README **and** in the deployment plan. A reader must not be able to
encounter these adapters without learning that no execution has ever confirmed
them.

**Why:** code that passes a conformance suite looks exactly like code that works.
The distinction here is real and was chosen deliberately, so it has to be visible.

### BR31.6 — Same region, or the free-tier reasoning collapses

**Rule:** both runtime services and the storage they use are deployed in the **same
region**. Cross-region placement is not a performance trade here; it moves
service-to-service traffic from free to chargeable and, for Cloud Storage, forfeits
the free tier entirely outside three named regions.

## Assumptions & Open Questions

- **[assumption]** Firestore transactions span enough documents for the combined
  write. The bound is content + one revision + the pruned set, which retention
  caps at 52: at most 53 reads and 3 writes over at most 54 distinct documents,
  comfortably inside the documented limit. See `entities.md` §
  `constraints.transaction_scope` for the phase split and the invariant that keeps
  the read set constant. Unverified by execution.
- **[assumption, load-bearing]** That a Firestore transaction rejects a read issued
  after a write — the premise BR31.3's read-phase requirement rests on — comes from
  published documentation, not from execution, like every other service claim in
  this unit. The resequencing is safe regardless of how that premise resolves: it
  is legal under both orderings, so nothing is lost if the premise is ever found to
  be weaker than stated.
- **[open]** Nothing reclaims orphaned blobs. See `entities.md`.
