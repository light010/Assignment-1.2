# U10 `containers` — no functional-design artifacts

This unit is `kind: packaging`. The `functional-design` stage declares
`produces_kinds` for each of its outputs, and `packaging` appears in **none** of
them:

```
entities:            [service, spec, library]
rules:               [service, spec, library]
functional-spec:     [service, spec, ui, library]
traceability:        [service, spec, ui, library]
frontend-components: [ui]
```

So this unit legitimately owes nothing at this stage. This file exists only so the
empty directory reads as a deliberate consequence of the unit's kind rather than
as work that was forgotten.

What this unit delivers — two Dockerfiles, the Compose file, `.dockerignore`, the
safe environment example, the named volume layout, health checks, graceful
termination, non-root users, and the end-to-end flow — is packaging and
orchestration, and it is produced at `code-generation`.

Its constraints are already fixed and recorded: frozen installs only, base images
pinned **by digest** rather than by tag, no secret through a build argument or
environment instruction and none baked into a layer, durability proven by
recreating the runtime container and re-reading, and verification with **no source
mounts and no development servers**.

## Two install-configuration files this unit owns, assigned here on 2026-09-25

`team.md` § *Deployment* makes two explicit decisions about files that, until now,
**no unit's inventory named** — so both decisions had nowhere to land. They are
assigned to U10 because they are install configuration consumed by the Dockerfile's
`pnpm install --frozen-lockfile`, which makes this unit their only real consumer.
`public-site` drafted rows for them, correctly removed them rather than claiming
install configuration in a `kind: ui` unit, and pointed here.

- **`pnpm-workspace.yaml` — `minimumReleaseAge: 10080` is carried forward.** It is
  a **supply-chain control, not friction**: a seven-day cooldown is the cheapest
  available defence against a compromised fresh release, and it costs nothing. If
  it is ever removed, it is removed **knowingly**.
- **`.npmrc` — `audit=false` is NOT carried forward.** Whatever else is copied from
  the source's `.npmrc`, that line is not. *A suppression copied forward is a
  suppression nobody chose.*

Both are delivered at `code-generation` with the rest of this unit's output. They
are recorded here rather than left implicit because a decision with no owning
artifact is a decision that survives only as long as someone remembers it — and
the second one is a security suppression that would be re-inherited by default if
the file were copied without thought, which is exactly how it got into the source.
