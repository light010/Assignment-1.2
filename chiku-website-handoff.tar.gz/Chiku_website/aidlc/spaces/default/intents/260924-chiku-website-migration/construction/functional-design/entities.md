# Entity Schemas — chiku-website runtime-split migration

**Upstream:** `inception/domain-design/components.md` (entity ownership),
`inception/requirements-analysis/requirements.md` (FR9.1, FR9.2, FR3.x),
`inception/contract-design/contract-summary.md` (port operations),
`codekb/Chiku_website/api-documentation.md` (§ *Content schema — every field and constraint*),
`codekb/Chiku_website/code-quality-assessment.md` (§ *Hazard 3*).

## How to read this document

This is the complete field-level specification of the six entities. It is written so
that **a developer implements from it without opening `madhavi-tripathi/`.** Every
maximum length, regular expression, enumerated value, numeric bound and `.default()`
is quoted exactly, not paraphrased.

Six entities, each owned by exactly one component:

| ID | Entity | Owning component | Nature |
|---|---|---|---|
| ENT-1 | `OwnerAccount` | `OwnerIdentity` | **New** — the source had no authentication of its own |
| ENT-2 | `Session` | `SessionAuthority` | **New** |
| ENT-3 | `LoginAttemptWindow` | `LoginGuard` | **New** |
| ENT-4 | `ContentDocument` | `ContentAuthority` | **Ported** — every constraint below is inherited, not chosen |
| ENT-5 | `ContentRevision` | `RevisionLedger` (written by `ContentAuthority`) | **Ported** |
| ENT-6 | `Asset` | `MediaIntake` | **Ported** |

ENT-4 is the hard one and takes most of this document. ENT-1 to ENT-3 are new
entities whose shape follows from confirmed decisions D1–D3 and FR3.1–FR3.7; where a
field's exact bound was never decided, it is listed in
`## Assumptions & Open Questions` rather than invented silently here.

---

## The wire format is frozen — read this before writing any model

The JSON wire format is **`camelCase`, and it is inherited rather than chosen**
(FR9.4). Two independent reasons, either of which alone is decisive:

1. The ported frontend components read this shape directly and unchanged —
   `site.tsx` reads `c.scholarHighlights`, `c.publications[].featured`, `focalX` /
   `focalY`; the editor reads the same shape. A `snake_case` wire format turns
   "components port largely unchanged" into a rename sweep that voids the
   file-as-unit parity rule for every file it touches.
2. **The persisted content *is* this JSON.** The stored `draft` and `published`
   columns hold exactly these keys, and they are re-parsed through the same schema
   on every read. A wire rename is therefore also a data migration.

Python identifiers are `snake_case` everywhere, **including storage columns**.
Conversion happens in **exactly one place**: a shared Pydantic `BaseModel` with
`alias_generator=to_camel` and `populate_by_name=True`, from which every request and
response model inherits. No hand-written mapping, no `camelCase` identifier in
Python, no `snake_case` key on the wire.

Throughout this document, **field names are given in their `camelCase` wire
spelling**, because that is the frozen, externally visible name. The Python
attribute is the `snake_case` form of the same name, produced by the alias
generator.

---

## ENT-1 `OwnerAccount` — owned by `OwnerIdentity`

Exactly **one** row ever exists (D6, FR3.6). There are no multi-editor accounts and
no tiered editor/publisher roles; do not model a collection.

| Field | Type | Required | Default | Constraints |
|---|---|---|---|---|
| `ownerId` | string | yes | — | Opaque identifier, generated at provisioning. Never derived from the email. |
| `email` | string | yes | — | Max **200** characters; must match `/^[^\s@]+@[^\s@]+\.[^\s@]+$/`. Not trimmed. Carried from the content schema's `email` rule for consistency — see assumption A-1. |
| `passwordHash` | string | yes | — | An **argon2id** PHC-encoded hash string as produced by `argon2-cffi` 25.1.0. Stored verbatim; application code never parses it. The plaintext password is never stored, never logged, and never returned by any operation. |
| `createdAt` | string | yes | — | ISO-8601 UTC instant, e.g. `2026-09-24T14:48:17.123Z`. |
| `passwordUpdatedAt` | string \| null | no | `null` | ISO-8601 UTC instant; `null` until the password is first changed after provisioning. |

**Never present, in any form:** a default, seeded, sample or hard-coded credential
(FR3.7, `project.md` § Forbidden). A fresh start against empty storage has no
account anyone can sign in to. The former `OWNER_EMAIL = 'madhavi.tri16@gmail.com'`
literal at `app/server.ts:5` is **not** carried forward; the owner's email is
runtime configuration and is **backend-only** — it must never appear as a
`NEXT_PUBLIC_*` variable.

**Persistence:** `IdentityStore.owner_record`, operations `read` and
`create_if_absent`.

---

## ENT-2 `Session` — owned by `SessionAuthority`

| Field | Type | Required | Default | Constraints |
|---|---|---|---|---|
| `sessionId` | string | yes | — | Opaque, unguessable, generated from a cryptographic RNG. Never derived from `ownerId` or from any user-supplied value. |
| `ownerId` | string | yes | — | Reference to ENT-1. Each `Session` belongs to exactly one `OwnerAccount`. |
| `issuedAt` | string | yes | — | ISO-8601 UTC instant, set once at issue and never changed. |
| `lastSeenAt` | string | yes | `issuedAt` at creation | ISO-8601 UTC instant. Advanced on each verified request (the sliding idle window). |
| `absoluteExpiresAt` | string | yes | `issuedAt + 7 days` | ISO-8601 UTC instant. Computed **once at issue** and **never extended** by activity. |
| `revokedAt` | string \| null | no | `null` | ISO-8601 UTC instant. Non-null means revoked server-side; a session with a non-null value fails verification regardless of its other fields. |
| `csrfToken` | string | yes | — | Opaque, unguessable, generated from a cryptographic RNG, paired 1:1 with this session. Sent to the client and echoed back as a request header on mutations (double-submit). |

**Expiry is two independent bounds, both enforced (D2, FR3.3):**
- **8 hours idle, sliding** — measured from `lastSeenAt`.
- **7 days absolute** — measured from `issuedAt` via `absoluteExpiresAt`, regardless
  of activity.

The cookie carrying `sessionId` is signed and marked `HttpOnly`, `Secure`,
`SameSite=Lax` (FR3.2).

**Persistence:** `IdentityStore.session`, operations `create`, `read`, `touch`,
`revoke`. `touch` advances the idle window **without** extending the absolute
expiry — that asymmetry is the whole point of storing both timestamps.

---

## ENT-3 `LoginAttemptWindow` — owned by `LoginGuard`

Two independent counters exist per failed sign-in: one keyed by account, one keyed
by source address. They are separate rows with separate scopes, not one row with two
counters.

| Field | Type | Required | Default | Constraints |
|---|---|---|---|---|
| `windowKey` | string | yes | — | Identifies the counted subject within its scope: the account identifier (or the submitted email, for an account that does not exist — see assumption A-2) for `scope = account`, the source address for `scope = ip`. |
| `scope` | enum | yes | — | Exactly one of `account`, `ip`. |
| `failureCount` | integer | yes | `0` | `>= 0`. Incremented on each failed attempt within the window. |
| `windowStartedAt` | string | yes | — | ISO-8601 UTC instant at which the current rolling window began. |

**Thresholds (D3, FR3.5), both over a 15-minute rolling window:**
- `scope = account`: refuse beyond **5** failures per **15 minutes**.
- `scope = ip`: refuse beyond **20** failures per **15 minutes**.

**Persistence:** `IdentityStore.login_attempts`, operations `record_failure`,
`count_in_window`, `clear`. Counters are **persisted**, so a restart does not reset
a window.

---

## ENT-4 `ContentDocument` — owned by `ContentAuthority`

Exactly **one** document ever exists — the source stores it as the singleton row
`site_content WHERE id = 1`.

### ENT-4 envelope

| Field | Type | Required | Default | Constraints |
|---|---|---|---|---|
| `documentId` | fixed singleton | yes | the one document | There is one and only one. |
| `draft` | `Content` | yes | seeded document | The full content document, below. **Always** overwritten by an accepted write, for a publish as well as a draft save. |
| `published` | `Content` | yes | seeded document | The full content document. Changed **only** when `action = 'publish'`. |
| `revision` | integer | yes | `0` | Monotonic. Increments by 1 on **every** accepted write — **drafts as well as publishes**. Must satisfy `Number.isSafeInteger`, `>= 0`, `< Number.MAX_SAFE_INTEGER` when supplied by a caller as a base revision. |
| `updatedAt` | string \| null | yes | `null` when no row exists | ISO-8601 UTC instant, set on every accepted write. |
| `publishedAt` | string \| null | yes | `null` | ISO-8601 UTC instant. **Stays `null` until the first publish** — the seeded document is not "published". Changed only when `action = 'publish'`. |
| `lastMutation` | string \| null | yes | — | The opaque random token stamped by the accepted write that most recently touched this document. Source generates it with `crypto.randomUUID()` (canonical lowercase UUID v4). **Not a convenience field**: it is the ABA guard for the write's side effects — see BR4.8–BR4.19 in `rules.md`. |

**`hasUnpublishedChanges` is computed, never stored.** It is
`serialise(draft) != serialise(published)` — the source computes
`JSON.stringify(draft) !== JSON.stringify(published)`. It appears in the read
response but has no column.

**When no document exists**, the read operation synthesises
`{draft: <seed>, published: <seed>, revision: 0, updatedAt: null, publishedAt: null, hasUnpublishedChanges: false}`
and **writes nothing**.

### ENT-4 shared building blocks

These five definitions are referenced by name throughout the field tables below.

| Name | Exact definition |
|---|---|
| `text` | String, **max 10000** characters. No trim, no refinement. |
| `url` | String, **max 2000** characters, **plus** a refinement that passes if **any** of: (a) the value is empty (`''`); (b) it matches `/^https?:\/\/[^\s]+$/i` — **case-insensitive**; (c) it matches `/^\/api\/media\/[a-zA-Z0-9.-]+$/` — **case-sensitive**. Failure message, verbatim: `Use a full https:// link.` |
| `citationCount` | String, **`.trim()` applied first**, then **max 9** characters, plus a refinement `v === '' \|\| /^\d+$/.test(v)`. **`.default('')`**. Failure message, verbatim: `Use a whole, non-negative citation count, or leave it blank.` |
| `citationDate` | String, **max 10** characters — **no trim** — plus a refinement that passes if the value is empty **or** all three of: `/^\d{4}-\d{2}-\d{2}$/` matches; `Date.parse(v)` is not `NaN`; and `new Date(v).toISOString().slice(0,10) === v`. **`.default('')`**. Failure message, verbatim: `Use a valid snapshot date.` |
| `imageSource` | Object `{src: url, width: integer 1..16000, height: integer 1..16000}`. All three required. `width`/`height` must be **integers**, not merely numbers. **See the note below: this 16,000 cap and `AssetRecord`'s 40,000 describe the same pixel quantities and disagree, and FR6.5 makes that disagreement reachable for the first time.** |

### `imageSource` caps at 16,000; `AssetRecord` caps at 40,000. FR6.5 makes that reachable.

The same pixel quantities carry two different maxima: the content document's
`imageSource.width`/`height` accept `1..16000`, while `AssetRecord.width`/`height`
accept `1..40000` with `width * height <= 100000000`. **In the source these two
ranges never met.** The browser prepared the variants and wrote the `imageSource`
entries, so nothing ever carried an `AssetRecord` dimension into the content
document. **FR6.5 moves variant generation into Python**, deriving variants from
the parsed asset — which connects the two for the first time. An upload between
16,001 and 40,000 pixels on a side is accepted by the asset store and then cannot
be represented in the content document.

**Neither range moves, and parity is what decides that:**

- **Widening `imageSource` to 40,000 is forbidden.** `FR9.1` requires the content
  schema to preserve *every field, constraint, default, maximum and refinement*.
  16,000 is one of those maxima.
- **Narrowing `AssetRecord` to 16,000 changes upload behaviour**, rejecting a file
  the source accepted — a parity break on the upload path.

**So the boundary behaviour is preserved rather than either range being changed,
and it already matches the source:** the upload succeeds, and the **save** fails
with a validation `issue` on the offending field. That is exactly what happened
before — the browser produced an oversized variant, `contentSchema.safeParse`
rejected it at save, and the owner saw a field-level issue. The only thing FR6.5
changes is *where the variant is produced*, not what the owner experiences.

**What this obliges Python to do, which nothing else states:** the variant
derivation must not silently emit an `imageSource` it knows the content schema
will reject. It either downscales to within 16,000 — the behaviour a reader would
most expect, and the one that keeps the owner's upload usable — or refuses and
surfaces the field-level issue. **That choice is a behaviour question owned by
`u5-media`**, which owns FR6.5's derivation, and it is recorded here rather than
in a single unit because the constraint it has to satisfy lives in `u4-content-core`'s
schema. Whichever is chosen, it is stated in `u5-media` and it is not left to the
implementer.

Two details that are easy to lose and have no compensating signal:

- **The `citationDate` round-trip check is the whole point of that refinement.** It
  rejects `2026-02-30`, which `Date.parse` *accepts* and normalises to March 2. The
  regex alone is insufficient; the ISO round-trip equality is what catches it. An
  equivalent Python implementation must reject a syntactically well-formed but
  non-existent date, and must **not** normalise it.
- **`.trim()` is applied to `citationCount` but NOT to `citationDate`.** These two
  look symmetrical and are not. A leading space in `citationsAsOf` fails; a leading
  space in `citations` is stripped and then validated.

**`.trim()` is a transform, not a check.** Wherever it appears below, the trimmed
value is what is validated *and* what is stored — `z.string().trim().min(1)` trims
first and then tests the trimmed length.

**The `url` media form is more permissive than the media route's key pattern.** The
schema accepts `/api/media/` followed by any run of `[a-zA-Z0-9.-]`, while
`GET /api/media/{key}` only serves keys matching
`^[a-f0-9-]+\.(jpg|png|webp|pdf|mp4|webm|vtt)$`. A document may therefore legally
contain a media URL the media route will 404. This asymmetry exists today; preserve
both patterns as written rather than reconciling them.

### ENT-4 `item` — the shape shared by all five collections

**24 declared fields.** Identical for `achievements`, `research`, `publications`,
`journey` and `news` — there is no per-collection variation of the item shape.

| Field | Type | Required | Default | Constraints |
|---|---|---|---|---|
| `id` | string | yes | — | Max **100** characters. No pattern, no trim, **may be empty**. |
| `title` | string | yes | — | **`.trim()`**, then **min 1** with the verbatim message `Add a title before saving.`, then **max 1000**. |
| `subtitle` | `text` | yes | — | Max 10000. |
| `description` | `text` | yes | — | Max 10000. |
| `year` | string | yes | — | Max **40**. Free text — **not** a number and not a date. |
| `image` | `url` | yes | — | Max 2000 + the `url` refinement. |
| `imageAlt` | `text` | yes | — | Max 10000. |
| `imageSources` | array of `imageSource` | no | **`[]`** | **Max 4** elements. |
| `focalX` | number | no | **`50`** | `>= 0`, `<= 100`. Not constrained to an integer. |
| `focalY` | number | no | **`50`** | `>= 0`, `<= 100`. Not constrained to an integer. |
| `link` | `url` | yes | — | |
| `code` | `url` | yes | — | |
| `dataset` | `url` | yes | — | |
| `video` | `url` | yes | — | |
| `captions` | `url` | no | **`''`** | The only `url` field in `item` with a default. |
| `transcript` | string | no | **`''`** | **Max 60000** characters — six times any `text` field. |
| `featured` | boolean | yes | — | |
| `citations` | `citationCount` | no | **`''`** | Trimmed, max 9, digits-only-or-empty. |
| `citationsAsOf` | `citationDate` | no | **`''`** | Max 10, ISO date round-trip, **not** trimmed. |
| `researchTopic` | enum, optional | no | **see warning W-1** | Exactly one of `materials`, `ultrasound`, `photoacoustic`, `general` — in that declaration order. Optional at parse; **resolved by the transform, not defaulted to null**. |
| `researchIds` | array of string, optional | no | **see warning W-2** | Each element max **100** characters; **max 100** elements. Optional at parse; **resolved by the transform, not defaulted to `[]`**. |
| `contribution` | `text` | no | **`''`** | Max 10000. |
| `approach` | `text` | no | **`''`** | Max 10000. |
| `outcome` | `text` | no | **`''`** | Max 10000. |

### ENT-4 `item` — the parse transform

**Every parse of an `item` — including every read out of storage — applies this
transform after validation:**

```
researchTopic := researchIdentity(row)
researchIds   := row.researchIds ?? initialResearchLinks.get(row.id) ?? []
```

where

```
researchIdentity(item) = item.researchTopic ?? originalTopics.get(item.id) ?? 'general'
```

Two consequences that are not obvious from the code shape:

- The transform runs on **reads**, not only writes. The stored document is
  re-validated and re-transformed on every read of `draft` and `published`.
- The editor sends **`validation.data`** back on save — the transformed and
  defaulted document, not the raw form state. So on the first save after a field was
  added, the derived values are **materialised into storage**. The transform is
  therefore simultaneously a read-path rule and the origin of stored values.

> ### W-1 — WARNING: `researchTopic` is a CONTENT-CARRYING default (FR9.2, hazard)
>
> **A Pydantic model declaring `research_topic: Topic | None = None` is type-correct
> and behaviourally wrong.** It produces `None` where the original produces a real
> topic. Nothing errors, nothing logs, and no test written from the type signature
> fails.
>
> The original resolves an absent topic **through a legacy id→topic map, and only
> then to `general`**. Precedence is strictly: an explicit value wins; the id map is
> the fallback; `'general'` is the floor.
>
> **The map, in full — `originalTopics` (`app/research-identity.ts:11-18`):**
>
> | Item `id` | Resolved `researchTopic` |
> |---|---|
> | `nano-materials` | `materials` |
> | `ultrasound-imaging` | `ultrasound` |
> | `photoacoustics` | `photoacoustic` |
>
> Any other id with no explicit topic resolves to **`general`**.
>
> **Why the map exists:** `researchTopic` was added *after* the three original
> research cards were already published, so their stored documents have no such
> field. Rather than a data migration, the card id infers it. The source comment
> states the intent verbatim: *"Existing published cards acquire a stable identity
> without changing their text or order."*
>
> **What breaks silently if this is got wrong:** all three original research cards
> fall back to `general` and **render identically as slate**, losing their distinct
> icon and colour (`researchTopicLabels` maps the four topics to
> `Nanomaterials · blue`, `Ultrasound · violet`, `Photoacoustic · teal`,
> `General research · slate`). Worse, the editor's "Card identity" control then
> shows `general` as the current value for cards the owner never set, **silently
> rewriting their identity on the next save**.
>
> **The operator is `??`, not `||`.** A stored explicit value must win even when it
> is falsy by JavaScript rules. In Python: test for *absence*, never for
> *truthiness*.

> ### W-2 — WARNING: `researchIds` is a CONTENT-CARRYING default (FR9.2, hazard)
>
> **A Pydantic model declaring `research_ids: list[str] = []` is type-correct and
> behaviourally wrong.** It produces `[]` where the original produces the seeded
> editorial links.
>
> **The map, in full — `initialResearchLinks` (`app/site-copy.ts:37-43`):**
>
> | Publication `id` | Resolved `researchIds` |
> |---|---|
> | `breast-imaging-2026` | `['photoacoustics']` |
> | `ultrasound-coherence-2025` | `['ultrasound-imaging']` |
> | `mucin-cus-2025` | `['nano-materials', 'photoacoustics']` |
> | `nanoflakes-2024` | `['nano-materials']` |
> | `nanohybrids-2023` | `['nano-materials', 'photoacoustics']` |
>
> Any other id with no explicit `researchIds` resolves to `[]`.
>
> **Note the values are research-card ids** (`nano-materials`,
> `ultrasound-imaging`, `photoacoustics`) — the same ids `originalTopics` keys on —
> **not** topic enum values. Do not confuse the two vocabularies.
>
> **Why the map exists:** `researchIds` — the many-to-many link from a publication
> to the research themes it supports — was added after those five publications were
> published. The map supplies the original editorial linkage keyed by publication id.
>
> **What breaks silently if this is got wrong:** the publications topic filter
> returns **zero results for every theme** (`paper.researchIds?.includes(topic)`
> never matches), and every research card shows **0 related papers**
> (`papers.filter(p => p.researchIds?.includes(item.id))`). The page renders
> cleanly, with grey cards and empty filters. There is no test in the source that
> would catch it.
>
> **The operator is `??`, not `||` — and here that difference is destructive.** An
> **explicitly emptied list must be preserved as empty.** An `or`/falsy port
> **resurrects links the owner deliberately deleted**, and does so on every read, so
> the owner cannot clear them at all. In Python: `research_ids if research_ids is
> not None else initial_research_links.get(item_id, [])` — never
> `research_ids or ...`.

> **Both W-1 and W-2 apply to a fresh install with particular force.** The seeded
> starting content is constructed *through* these maps, so a fresh install is
> entirely dependent on them; a long-running instance may already have the derived
> values materialised in storage. The starting data is exactly the case that needs
> the shims.

### ENT-4 top-level fields — 31 fields

| Field | Type | Required | Default | Constraints |
|---|---|---|---|---|
| `name` | string | yes | — | **`.trim()`**, then **min 1**, then **max 100**. No custom message on the `min`. |
| `role` | string | yes | — | Max **200**. |
| `affiliation` | string | yes | — | Max **200**. |
| `location` | string | yes | — | Max **200**. |
| `headline` | string | yes | — | Max **240**. |
| `intro` | `text` | yes | — | Max 10000. |
| `bio` | `text` | yes | — | Max 10000. |
| `email` | string | yes | — | Max **200**, plus a refinement passing if empty **or** matching `/^[^\s@]+@[^\s@]+\.[^\s@]+$/`. Verbatim message: `Enter a valid email.` No trim. |
| `photo` | `url` | yes | — | |
| `photoAlt` | `text` | yes | — | |
| `photoSources` | array of `imageSource` | no | **`[]`** | **Max 4** elements. |
| `photoFocalX` | number | no | **`50`** | `>= 0`, `<= 100`. |
| `photoFocalY` | number | no | **`35`** | `>= 0`, `<= 100`. **35, not 50** — a deliberate portrait framing default. This is the single most transcription-error-prone default in the schema. |
| `copy` | `copySchema` | no | **`initialCopy`** (below) | Defaulted at three nesting levels — see the copy section. |
| `cv` | `url` | yes | — | |
| `scholar` | `url` | yes | — | |
| `orcid` | `url` | yes | — | |
| `github` | `url` | yes | — | |
| `linkedin` | `url` | yes | — | |
| `accent` | enum | yes | — | Exactly one of `blue`, `burgundy`, `forest` — in that declaration order. **No default; required.** |
| `motion` | boolean | no | **`true`** | |
| `scene` | `sceneSchema` | no | **`initialScene`** (below) | |
| `scholarHighlights` | object | no | **all-empty object with `visible: false`** (below) | |
| `showNotice` | boolean | yes | — | **Required, no default.** |
| `notice` | `text` | yes | — | Max 10000. |
| `sections` | object of 6 booleans | yes | — | See below — the defaulting is asymmetric. |
| `achievements` | array of `item` | no | **`[]`** | **Max 60** elements. |
| `research` | array of `item` | yes | — | **Max 100** elements. **No default; required.** |
| `publications` | array of `item` | yes | — | **Max 500** elements. **No default; required.** |
| `journey` | array of `item` | yes | — | **Max 100** elements. **No default; required.** |
| `news` | array of `item` | yes | — | **Max 100** elements. **No default; required.** |

> **The collection asymmetry is real and must be reproduced.** `achievements` has
> `.default([])` and a **max of 60**; the other four collections have **no default**
> and different maxima (`research` 100, `publications` **500**, `journey` 100,
> `news` 100). This is a back-compat artefact of achievements being added later. **A
> model that gives all five collections a default is more permissive than the
> original** and will silently accept documents the source rejects.

### ENT-4 `sections` — six booleans, asymmetric defaulting

| Field | Type | Required | Default |
|---|---|---|---|
| `achievements` | boolean | no | **`true`** |
| `research` | boolean | **yes** | — |
| `publications` | boolean | **yes** | — |
| `journey` | boolean | **yes** | — |
| `news` | boolean | **yes** | — |
| `contact` | boolean | **yes** | — |

The `sections` object itself has **no default**: it must be present. Only its
`achievements` member is optional. Same back-compat origin as the collection
asymmetry above.

### ENT-4 `scholarHighlights`

All members are **strings** except `visible`, and **none carries a refinement**.

| Field | Type | Required | Constraint |
|---|---|---|---|
| `visible` | boolean | yes | — |
| `citations` | string | yes | Max **20** |
| `hIndex` | string | yes | Max **20** |
| `i10Index` | string | yes | Max **20** |
| `asOf` | string | yes | Max **100** |
| `affiliation` | string | yes | Max **200** |
| `interests` | string | yes | Max **1000** |

**Object-level `.default()`, verbatim:**

```json
{"visible": false, "citations": "", "hIndex": "", "i10Index": "", "asOf": "", "affiliation": "", "interests": ""}
```

Note `citations` here is a **plain max-20 string with no digits refinement**, unlike
`item.citations`, which is a `citationCount`. Two fields with the same name and
different rules.

### ENT-4 `sceneStory` and `sceneSchema`

`sceneStory` — all three members required, no defaults:

| Field | Type | Constraint |
|---|---|---|
| `title` | string | Max **150** |
| `description` | string | Max **600** |
| `link` | `url` | Max 2000 + the `url` refinement |

`sceneSchema`:

| Field | Type | Required | Default | Constraint |
|---|---|---|---|---|
| `offerTour` | boolean | no | **`true`** | |
| `initialView` | enum | yes | — | Exactly one of `delivery`, `photoacoustic`, `ultrasound` — in that declaration order |
| `delivery` | `sceneStory` | yes | — | |
| `photoacoustic` | `sceneStory` | yes | — | |
| `ultrasound` | `sceneStory` | yes | — | |

A legacy `autoTour` field was **deliberately retired**; the source comment records
that tours now start only after visitor input. Do not reintroduce it, and do not
accept it as an alias.

**`initialScene` — the object-level `.default()` for `scene`, verbatim:**

```json
{
  "offerTour": true,
  "initialView": "delivery",
  "delivery": {
    "title": "Small carriers. Purposeful delivery.",
    "description": "A thermoresponsive nanogel brings a drug payload and CuS nanoparticles together, with release designed to respond to heat.",
    "link": "https://etd.iisc.ac.in/handle/2005/6575"
  },
  "photoacoustic": {
    "title": "Light in. Sound out.",
    "description": "Light-absorbing materials generate acoustic signals—connecting nanoscale material design with photoacoustic imaging.",
    "link": "https://doi.org/10.1021/acsanm.3c02405"
  },
  "ultrasound": {
    "title": "From echoes to clearer insight.",
    "description": "Ultrasound transmits sound and receives echoes. My work explores coherence-based imaging to help distinguish breast cysts from solid masses.",
    "link": "https://doi.org/10.1093/radadv/umaf037"
  }
}
```

The `photoacoustic.description` contains a **U+2014 EM DASH** immediately after
`signals`, with no surrounding spaces. It is content, not punctuation to be
normalised.

### ENT-4 `copy` — `copySchema`, nine groups, 25 leaf defaults

**Defaulting happens at three nesting levels**, and each level must work
independently: an absent `copy` key, an absent `copy.research` key and an absent
`copy.research.title` key must each produce a different but correct result.

- **Level 3 (whole object):** `copySchema` itself is `.default(initialCopy)`.
- **Level 2 (group):** each of the nine groups is `.default(<its own initial group>)`.
- **Level 1 (leaf):** each leaf field is `.default(<its own initial value>)`.

Two reusable shapes:

| Name | Exact definition |
|---|---|
| `label(fallback)` | String, **`.trim()`**, then **min 1** with the verbatim message `Add a label.`, then **max 80**, then `.default(fallback)`. |
| `section(value)` | Object `{title: string .trim().min(1, 'Add a heading.').max(200).default(value.title), description: string .max(1000).default(value.description), navigation: label(value.navigation)}`, and the object itself `.default(value)`. |

Group shapes:

| Group | Shape |
|---|---|
| `hero` | `{researchAction: label, scholarAction: label, discover: label, topics: string max 200 with default}`, object `.default(initialCopy.hero)` |
| `achievements`, `research`, `publications`, `journey`, `news`, `contact` | `section(...)` — three fields each |
| `scholar` | `{title: string .trim().min(1).max(200).default(...), profileAction: label}`, object `.default(initialCopy.scholar)`. **Note: `scholar.title`'s `min(1)` carries NO custom message**, unlike `section`'s `Add a heading.` |
| `footer` | `{tagline: string max 200 with default}`, object `.default(initialCopy.footer)` |

> **These 25 defaults are content, not boilerplate — they are the site's actual
> wording.** 25 leaf defaults, of which **23 are non-empty** (`journey.description`
> and `news.description` default to `''`). Nearly every one is a *different* string.
> All 25 must be carried verbatim, including the embedded newlines.

**`initialCopy` — the complete default value, verbatim (newlines shown as `\n`
exactly as they appear in the strings):**

```json
{
  "hero": {
    "researchAction": "Explore my research",
    "scholarAction": "Google Scholar",
    "discover": "Scroll to discover",
    "topics": "Drug delivery · Photoacoustics · Ultrasound"
  },
  "achievements": {
    "title": "The work.\nThe moments behind it.",
    "description": "Recognition, shared discoveries, and the people along the way.",
    "navigation": "Highlights"
  },
  "research": {
    "title": "Small scale.\nWide possibilities.",
    "description": "Responsive carriers. Optical contrast.\nInformation carried by sound.",
    "navigation": "Research"
  },
  "publications": {
    "title": "Selected publications.",
    "description": "A curated selection. The complete record is on Google Scholar.",
    "navigation": "Publications"
  },
  "journey": {
    "title": "Curiosity.\nA constant in motion.",
    "description": "",
    "navigation": "About"
  },
  "news": {
    "title": "From the research.",
    "description": "",
    "navigation": "Updates"
  },
  "contact": {
    "title": "Good questions.\nNew connections.",
    "description": "Research, collaboration,\nor a shared curiosity.",
    "navigation": "Connect"
  },
  "scholar": {
    "title": "A snapshot of\nthe research.",
    "profileAction": "Explore the full profile"
  },
  "footer": {
    "tagline": "Materials. Delivery. Light & sound."
  }
}
```

Character-level details that a careless transcription loses:

- `hero.topics` uses **U+00B7 MIDDLE DOT** with a space either side, three times.
- `footer.tagline` uses a literal ampersand `&`, not `&amp;`.
- Five titles and two descriptions contain a **literal newline** (`\n`), and the line
  breaks are deliberate typographic composition. `achievements.title`,
  `research.title`, `journey.title`, `contact.title`, `scholar.title`,
  `research.description` and `contact.description` each carry exactly one.
- `journey.description` and `news.description` are the **empty string**, not absent.

---

## ENT-5 `ContentRevision` — owned by `RevisionLedger`, written by `ContentAuthority`

| Field | Type | Required | Default | Constraints |
|---|---|---|---|---|
| `revisionEntryId` | string | yes | — | For a normal entry, **the write's mutation token** (source: the `crypto.randomUUID()` value, canonical lowercase UUID v4). For the two permanent baselines, the **fixed literal ids** `starting-published` and `starting-draft`. When supplied by a caller for lookup: max **100** characters, non-empty, and must match `/^[a-zA-Z0-9-]+$/`. |
| `revision` | integer | yes | — | The revision number this entry records. Not unique — a baseline pair and a normal entry can share one. |
| `action` | enum | yes | — | Exactly one of `draft`, `publish`. |
| `content` | `Content` | yes | — | The full content document **as written**, read back from the stored `draft` column rather than taken from the request — see BR4.11 in `rules.md`. |
| `createdAt` | string | yes | — | ISO-8601 UTC instant. For a normal entry it is read back from the document's `updatedAt`, so entry and document agree exactly. For a baseline it is **the time of capture, not a guessed original publication date**. |
| `baseline` | boolean | yes | `false` | `true` only for the two starting entries. Stored as an integer in SQLite and coerced with a truthiness test on read (`!!row.baseline`). Baselines are **never pruned**. |

Entries reference `ContentDocument`: each `ContentRevision` is a past state of the
one document.

**Write ownership, stated because the ownership table alone misleads:**
`RevisionLedger` owns this entity, its ordering and its retention policy, but
**performs no write**. `ContentAuthority` performs the insert and the prune inside
its one combined write, under the policy `RevisionLedger` supplies (ADR-001).
`RevisionLedger`'s own store access is read-only.

---

## ENT-6 `Asset` — owned by `MediaIntake`

| Field | Type | Required | Default | Constraints |
|---|---|---|---|---|
| `assetKey` | string | yes | — | Generated as `<uuid4>.<ext>`, where the extension is derived from the **validated** media type and **never** from the user's filename. Must match `/^[a-f0-9-]+\.(jpg\|png\|webp\|pdf\|mp4\|webm\|vtt)$/` — this is also the serving route's gate. |
| `filename` | string | yes | — | The user's original filename, **truncated to the first 200 characters**. Stored for display only; never used to derive the key, the extension or the media type. |
| `mediaType` | enum | yes | — | Exactly one of `image/jpeg`, `image/png`, `image/webp`, `application/pdf`, `video/mp4`, `video/webm`, `text/vtt`. The **validated** type, from byte inspection — not the declared `Content-Type`. |
| `byteSize` | integer | yes | — | `>= 1`. A zero-byte upload is rejected before a record exists. |
| `width` | integer \| null | no | `null` | Present for images only, from the header parse. `1..40000`, and `width * height <= 100000000`. `null` for PDF, MP4, WebM and VTT. |
| `height` | integer \| null | no | `null` | Same bounds and same nullability as `width`. |
| `createdAt` | string | yes | — | ISO-8601 UTC instant. |
| `derivedFrom` | string \| null | no | `null` | The `assetKey` of the original this variant was generated from; `null` for an original. **New field** — the source had no variant lineage because the browser produced variants; FR6.5 moves generation server-side. |

**Media-type → extension map, exactly as the source declares it:**

| Media type | Extension |
|---|---|
| `image/jpeg` | `jpg` |
| `image/png` | `png` |
| `image/webp` | `webp` |
| `application/pdf` | `pdf` |
| `video/mp4` | `mp4` |
| `video/webm` | `webm` |
| `text/vtt` | `vtt` |

**Bytes and metadata are two separate stores with no shared transaction.**
`AssetStore` holds the bytes; `ContentStore.asset_metadata` holds this row. A failure
between the two writes leaves an orphan, which the best-effort cleanup path
reconciles (BR6.24 in `rules.md`).

**There is no deletion path and no orphan collection anywhere.** Removing a
reference from the published document makes an asset non-public again on the next
request, but neither the stored bytes nor this row is ever deleted. Storage grows
monotonically. This is preserved behaviour, not an oversight to fix here.

---

## Assumptions & Open Questions

- **[assumption A-1]** `OwnerAccount.email` is specified as max **200** characters
  with the regex `/^[^\s@]+@[^\s@]+\.[^\s@]+$/`. Neither bound was decided at any
  gate: they are carried from the content schema's `email` field so the system uses
  one email rule rather than two. If a longer address must be supported, this is the
  constraint to revisit, and it has no parity consequence because the entity is new.
- **[assumption A-2]** For `scope = account`, `LoginAttemptWindow.windowKey` is
  described as "the account identifier, or the submitted email for an account that
  does not exist". D3 and FR3.5 fix the thresholds and require that the response
  enumerate nothing, but neither states which value keys the counter when no account
  matches. Keying on the submitted email preserves the per-account limit for a
  non-existent account and keeps the response identical; keying on nothing would
  leave only the IP limit. Confirm before implementing, because the choice is
  observable through timing.
- **[assumption A-3]** `OwnerAccount.ownerId`, `Session.sessionId` and
  `Session.csrfToken` are specified as "opaque, unguessable, from a cryptographic
  RNG" without a fixed length or alphabet. No decision fixed one. Any choice at or
  above the strength of `secrets.token_urlsafe(32)` satisfies every stated
  requirement; the exact spelling belongs to code generation.
- **[assumption A-4]** `Asset.width`/`height` are recorded as nullable because the
  source's `assets` table stores no dimensions at all — the parse result is used for
  validation and for the upload response and then discarded. Persisting them is a
  small addition that FR6.5 makes useful (server-side variant generation needs the
  original's dimensions), and `components.md` already lists them as attributes of
  the entity. If a reviewer prefers strict parity, dropping both columns changes no
  rule in `rules.md`.
- **[open, carried from `api-documentation.md`]** The CodeKB records two internal
  inconsistencies it did not resolve, both of which touch this document's sources and
  neither of which changes any constraint above: (a) the second `reply()` helper is
  given as `app/api/history/route.ts:14` in one section and `:4` in another, against
  a 14-line file — one is wrong and the scan does not say which; (b) `contentSchema`
  is placed at `app/content.ts:20` and `sceneSchema` at `:21`, which cannot hold
  under eager evaluation since `contentSchema` consumes `sceneSchema`, so one line
  attribution is likely off by one. The **content** of both schemas is unaffected.
  Carried here rather than laundered into certainty.
- **[note]** The seeded starting content itself (FR9.3 — five publications, three
  research themes, three achievements, four journey entries, four news items, the
  Scholar highlights) is **not** enumerated in this document. It is instance data
  rather than schema, and it is reproduced from `app/content.ts`'s `record()`
  constructor and the recorded source fixtures (U1). What *is* enumerated here is
  every `.default()` the schema itself carries, which is what a model declaration
  must encode.
- **[note]** `ContentRevision.revisionEntryId` carries two different value shapes
  (a UUID for normal entries, a fixed literal for the two baselines) yet one lookup
  pattern `/^[a-zA-Z0-9-]+$/` accepts both. That is deliberate in the source and is
  reproduced, not tidied.

## Sources

- `aidlc/spaces/default/codekb/Chiku_website/api-documentation.md` §§ *Content
  schema — every field and constraint*, *`POST /api/upload`*, *`GET` and
  `HEAD /api/media/[key]`* — authoritative for ENT-4 and ENT-6.
- `aidlc/spaces/default/codekb/Chiku_website/code-quality-assessment.md` § *Hazard 3
  — the `researchIdentity` / `initialResearchLinks` back-compat shims* (W-1, W-2),
  § *Hazard 1 — the seven-statement D1 batch* (ENT-4 envelope, ENT-5).
- `inception/requirements-analysis/requirements.md` FR3.1–FR3.7, FR4.1–FR4.7,
  FR5.1–FR5.4, FR6.1–FR6.7, FR9.1–FR9.4.
- `inception/domain-design/components.md` § *Entity ownership* — the six entities,
  their owners and their attribute lists.
- `inception/contract-design/contract-summary.md` §§ C2, C3, C4 — the port
  operations each entity is persisted through.
- `WORKING-RECORD.md` §§ 2 (D1–D3, D6, D11, D24), 3 (the seven hazards), 5
  (frozen wire format).
- Verbatim default values transcribed from `madhavi-tripathi/app/site-copy.ts`
  (`initialCopy`, `initialResearchLinks`), `app/scene-content.ts` (`initialScene`),
  `app/research-identity.ts` (`researchTopics`, `originalTopics`) and
  `app/content.ts` (the schema itself), because the knowledge base enumerates these
  defaults' *structure* but not their *literal strings*, and a reader of this
  document must not have to open the source to get them.
