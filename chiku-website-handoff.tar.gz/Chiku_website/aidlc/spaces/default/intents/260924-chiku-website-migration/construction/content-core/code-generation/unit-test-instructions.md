# Unit Test Instructions — U4 `content-core`

## Framework and configuration

`pytest` 9.1.1 with `pytest-cov` 7.0.0 and `anyio` 4.12.0, resolved by `uv` from
`chiku-website/backend/pyproject.toml`. No new framework and no new dependency:
`pydantic` 2.13.5 is already pinned.

`tests/content/` needs an `__init__.py` package marker, for the same reason
`tests/conformance/` and `tests/cloud/` have one — without it pytest's prepend import
mode gives two `conftest` modules the same top-level name and the pre-existing suites'
`from conftest import meta` resolves to the wrong file.

## The exact command to run THIS unit's tests

Run from `chiku-website/backend/`:

```
uv run pytest tests/content
```

Do not add `-q`: `addopts = "-q"` already supplies it, and a second `-q` suppresses the
count line.

With the coverage floors this unit is measured against:

```
uv run pytest --cov --cov-branch
uv run coverage report --fail-under=80
uv run coverage report --fail-under=100 --include="app/content/defaults.py,app/content/statements.py,app/content/recovery.py,app/cloud/content_firestore.py,app/content/store_sqlite.py,app/auth/store_sqlite.py"
```

Runner readiness is verified before the first test step: `uv run pytest --version` must
succeed. It does today — 408 tests currently execute.

## Expected coverage

- **80% branch coverage** over `chiku-website/backend/`.
- **100% branch coverage** on this unit's three hazard modules —
  `app/content/defaults.py`, `app/content/statements.py`, `app/content/recovery.py` —
  which join the four already carrying that floor.

Neither floor may be relaxed, lowered or disabled: not by editing a threshold, adding an
`omit`, or narrowing an `--include`. A shortfall is reported as a shortfall.

Three of the system's seven hazards are owned here, and each carries **a test per
enumerated branch**, not merely enough tests to reach a percentage. An aggregate number
cannot distinguish "this branch is exercised" from "this branch was ported correctly".

## The recorded fixtures are the oracle where one exists

`chiku-website/fixtures/` holds 91 recordings from the running source. Where one covers a
behaviour, the expected value is **read from the recording**, never chosen by whoever
writes the test — that is what `custom` methodology means here, and it is the whole
defence against implementing and testing from the same misreading.

| Fixture family | Pins |
|---|---|
| `F2-*` | `/edit` and `/edit/preview` per identity |
| `F3-*` | `GET /api/content` and `/api/history` per identity; the 403 envelope; the serialised shape with content-carrying defaults **resolved** |
| `F4-*`, `F5-*` | The live state read, a draft save, publish, and the **409 conflict envelope** the editor branches on |
| `F6-size-*` | The request-size boundary in UTF-16 units, codepoints **and** UTF-8 bytes |
| `F12-*` | Malformed write bodies — the `400` + `issues[]` shape field highlighting depends on |

Read them through `tests/conftest.py`'s existing helpers (`meta`, `body`, `manifest`).

## Test scope — Standard strategy, 5–8 tests per component

### `tests/content/test_schema.py`

1. All 31 top-level fields parse from the seed and round-trip.
2. Every cap asserted **at its boundary, both sides** — at the maximum accepted, one over
   rejected.
3. `photoFocalY` defaults to **35**, not 50. Asserted explicitly because `entities.md`
   names it the most transcription-error-prone default in the schema.
4. The wire format is `camelCase` and the Python identifiers are `snake_case`, with
   exactly one conversion point.
5. The seed matches the recorded `F3` content response.

### `tests/content/test_defaults.py` — HAZARD, per enumerated branch

6. An **absent** research topic resolves through the id map.
7. An absent research topic **not in the id map** resolves to `general`.
8. **Absent** research links resolve through the seeded map.
9. **An explicitly emptied list stays empty.** This is the branch a naive
   "fill if falsy" default breaks, and it is the difference between a default and a
   silent overwrite of the owner's deletion.
10. The defaults run on the **read path, every time** — asserted by reading twice and by
    confirming the **stored** value was not changed.

### `tests/content/test_write_path.py` — HAZARD, per enumerated branch

11. The nine-step check order: a request that is **both** too large and malformed gets
    **too-large**; one with **both** a malformed document and a bad revision gets the
    *content* error (BR10.11), which is the one the editor can highlight.
12. The six effects commit **together or not at all**.
13. **The ABA collision**: a losing writer whose `next_revision` equals the winner's
    `revision` records **no** history entry and prunes **nothing**. Requires two writers
    at the same base revision; never reproduced single-user.
14. The history entry's content is read back from the **stored `draft`**, not the request
    — asserted with a payload the schema transforms, so the two genuinely differ.
15. The CAS result is read **by name**; a positional read that drifts is caught.
16. A stale `base_revision` returns **conflict with the current state alongside**, and the
    caller's edits are untouched (BR4.7) — asserted against `F5-conflict-stale-revision`.
17. Publish moves `published` and `publishedAt`; a draft save moves neither.

### `tests/content/test_recovery.py` — HAZARD, per enumerated branch

18. Below a minimum, above a maximum, a failed format check, a failed custom check, and
    **a value outside an enumerated set** are each **recoverable**.
19. Wrong type, missing required structure, not-an-object, not-an-array and unparseable
    are each **corrupting**.
20. All-recoverable returns the **normalised document plus the classified issues**.
21. Any-corrupting reports the record unusable.
22. **The bad-enum case the source gets wrong** is recoverable here, per the rule as
    written (BR8.4). This is the test that would fail if the source's allowlist were
    copied.
23. A transport failure is **distinguishable from a corrupting verdict** (BR8.7) — a
    failed inspect is not "discard it".

### `tests/content/test_cache.py`

24. A successful publish invalidates **synchronously, before the operation returns**.
25. The interval's **5-second maximum is enforced**; a higher configured value is refused.
26. **No draft content appears in a public response, in any field.** The public read route
    has no source behaviour to diff against — it returns 404 in the source — so this
    prohibition is checked directly rather than by fixture comparison.
27. The cache holds exactly one entry and is not keyed.

### `tests/content/test_ledger.py`

28. Listing order `revision` DESC, `baseline` ASC, `action` DESC, asserted **across a tied
    revision**. A single-key sort is identical until there is a tie.
29. The cap is 52 and there is no pagination.
30. Retention keeps 30 drafts and 20 publishes **independently** — 30 drafts do not evict
    a publish.
31. Both baselines survive a prune that ordering alone would not have spared.
32. Id validation: **absent** means list; **present but empty**, over 100 characters, or
    failing the pattern is **invalid** — not a list and not a not-found.
33. A well-formed id naming nothing, a pruned entry, and an entry with unreadable content
    all return **not-found with a body stating the current draft is unaffected** (BR5.10).
    Reassuring the owner is part of the rule, not decoration.
34. **Restoring never publishes** (BR5.6).

## Mocking and stubbing

**None for the store.** Use the in-memory `ContentStore` fake U2 already built and the
SQLite adapter — both are real implementations of the port and both are already under
their own conformance suite. Mocking the store here would assert this unit's belief about
the store rather than the store.

Where a test needs two concurrent writers, they are genuinely concurrent — two tasks
against one storage handle — not a simulated interleaving. The ABA defence cannot be
demonstrated any other way.

Time is injected, never read from a module-level clock: `now` is a caller argument
throughout the port, and the cache's interval test needs to advance it without sleeping.

## Test data management

No new fixture files. The recorded fixtures in `chiku-website/fixtures/` are committed and
are never regenerated as part of a test run — regeneration needs the source app running
and is a deliberate operator action. Everything else each test constructs and discards.
