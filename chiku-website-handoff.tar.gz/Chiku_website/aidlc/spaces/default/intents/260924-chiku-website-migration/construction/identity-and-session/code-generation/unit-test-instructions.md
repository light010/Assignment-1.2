# Unit Test Instructions — U3 `identity-and-session`

## Framework and configuration

`pytest` 9.1.1 with `pytest-cov` 7.0.0 and `anyio` 4.12.0, resolved by `uv` from
`chiku-website/backend/pyproject.toml`. **No new framework and no new dependency:**
`argon2-cffi` 25.1.0 and `itsdangerous` 2.2.0 are already pinned.

`tests/auth/` and `tests/owner/` each need an `__init__.py` package marker, for the same
reason `tests/conformance/`, `tests/cloud/` and `tests/content/` have one — without it
pytest's prepend import mode gives two `conftest` modules the same top-level name and the
pre-existing suites break.

**argon2 is deliberately slow.** Use the library's low-cost parameters in tests via a
fixture, never by lowering the production parameters. The production cost is a security
setting and is not a test knob.

## The exact command to run THIS unit's tests

Run from `chiku-website/backend/`:

```
uv run pytest tests/auth tests/owner
```

Do not add `-q`: `addopts = "-q"` already supplies it, and a second `-q` suppresses the
count line.

With the coverage floors this unit is measured against:

```
uv run pytest --cov --cov-branch
uv run coverage report --fail-under=80
uv run coverage report --fail-under=100 --include="app/auth/sessions.py,app/auth/hashing.py,app/owner/identity.py,app/content/defaults.py,app/content/statements.py,app/content/recovery.py,app/cloud/content_firestore.py,app/content/store_sqlite.py,app/auth/store_sqlite.py"
```

Runner readiness is verified before the first test step: `uv run pytest --version` must
succeed. It does today — 764 tests currently execute.

## Expected coverage

- **80% branch coverage** over `chiku-website/backend/`.
- **100% branch coverage** on this unit's three hazard modules — `app/auth/sessions.py`,
  `app/auth/hashing.py`, `app/owner/identity.py` — joining the six already carrying it.

Neither floor may be relaxed, lowered or disabled: not by editing a threshold, adding an
`omit`, or narrowing an `--include`. A shortfall is reported as a shortfall.

## There is no oracle for this unit, and that changes what the tests must do

Every other backend unit can check itself against a recording of the running source. This
one cannot: the source authenticated through a platform header and **no fixture exists or
can be made.** The tests are therefore written from `functional-spec.md` and `rules.md`,
and they must assert **the property**, not the implementation that happens to be there.

Two properties in particular are invisible to any test written the obvious way, and both
get a test designed to fail if the behaviour is done the easy way.

## Test scope — Standard strategy, 5–8 tests per component

### `tests/auth/test_startup.py`

1. `SESSION_SIGNING_KEY` **unset** raises at startup, names the variable, exits non-zero.
2. **Empty** raises — checked separately, not folded into "falsy".
3. **Under 32 bytes** raises — checked separately.
4. A valid key starts cleanly, and **no key is ever auto-generated**: two startups with
   the same configured key produce the same signer, and no code path invents one.
5. A **missing bootstrap secret does not fail startup** — the asymmetry with the signing
   key is asserted, not assumed.
6. **No owner is seeded** by startup, under any configuration.

### `tests/auth/test_sign_in.py` — HAZARD

7. **The three refusals are byte-identical**: unknown account, wrong password, and
   limit-already-reached produce the same raised member with the same message, and
   **nothing distinguishes them** — no `Retry-After`, no "too many attempts", no differing
   field.
8. **A verification always runs**, including with no owner record. Asserted by observing
   that the dummy hash is verified, not by timing — a wall-clock assertion would be flaky
   and would not prove the code path.
9. **Both windows are read at step 1, before the owner lookup**, keyed on the
   **normalised** email — trimmed and lower-cased. Asserted by the key that reaches the
   store, since `owner_id` does not exist yet at that point.
10. **No early return on an exhausted window**: the verification still runs. An early
    return would restore exactly the timing difference the always-hash rule removes.
11. On **any** refusal, the failure is recorded against **both** windows.
12. On success, the **account-scoped** counter is cleared and the address-scoped one is
    not.

### `tests/auth/test_sessions.py` — HAZARD

13. **`touch` advances `last_seen_at` and leaves `absolute_expires_at` untouched.** This
    is the test that catches the defect where refreshing both satisfies the 8-hour idle
    rule perfectly and silently destroys the 7-day bound.
14. A session used every hour for eight days reaches **AbsoluteExpired**. The two expiry
    transitions are independent and whichever fires first wins; collapsing them into one
    refreshed timestamp removes this transition entirely while every idle test stays
    green.
15. A session issued and left alone reaches **IdleExpired** after 8 hours.
16. **Identity or nothing, never a third answer**: revoked, idle-expired, absolutely
    expired and absent are one outcome to every caller.
17. A **revoked** session fails the **very next** verification, and its record is
    **retained** — deleting it would make revocation indistinguishable from an unknown
    session at the storage layer.
18. An **expired** record is **deleted as it is rejected**, and the deletion never changes
    the outcome.
19. An invalid or tampered cookie signature is treated as **anonymous** — no error, no
    distinct response.
20. The CSRF token is paired 1:1, returned **in the body and never in a cookie**, and a
    mismatched header refuses the mutation.
21. **There is no renewal path.** Nothing extends a session; a new sign-in issues a new
    one with a new absolute bound.

### `tests/auth/test_guard.py`

22. **5 per account per 15 minutes**, and the 6th is refused.
23. **20 per source address per 15 minutes**, independently — asserted with a mix that
    would pass a combined counter.
24. The two scopes are **separate records**, not two counters on one record.
25. A window **rolls over** after 15 minutes.
26. Counters **survive a new store instance over the same storage** — an in-memory counter
    is not an acceptable real adapter.
27. `count_in_window` compares against **no threshold**; the numbers live in this unit.

### `tests/owner/test_provisioning.py` — HAZARD

28. **A fresh start against an empty volume has no account anyone can sign in to.** This
    is BR3.10's acceptance test, stated exactly, and asserted directly.
29. The gate is **the record's existence**: once an owner exists, both paths refuse.
30. **A restart cannot reopen it** — asserted by constructing a fresh service against the
    same storage, which is the state a consumed-flag implementation would get wrong.
31. **Two concurrent `create_if_absent` calls yield one record and one refusal.** Run
    genuinely concurrently, not sequentially.
32. The one-shot route is enabled **only while both** conditions hold, and requires the
    secret.
33. **Secret unset and no owner: the service starts and refuses every sign-in.** It does
    not create an account and it does not fail to start.
34. Only the **argon2id hash** is stored — the plaintext appears nowhere in the record, in
    a log, or in a raised error.

## Mocking and stubbing

**Do not mock `IdentityStore`.** Use the in-memory fake and the SQLite adapter U2 already
built — both are real implementations already under their own conformance suite. Mocking
here would assert this unit's belief about the store rather than the store, and tests 26
and 30 depend on real cross-instance persistence.

Concurrent callers must be **genuinely concurrent** — two tasks against one storage handle.
The provisioning race cannot be demonstrated any other way, and a sequential test passes
against a read-then-write implementation that is wrong.

**Time is injected**, never read from a module-level clock: `now` is an argument
throughout, and the expiry tests advance it rather than sleeping.

**Never assert on wall-clock timing.** The always-hash property is asserted by observing
the code path, not by measuring duration — a timing assertion is flaky and proves less.

## Test data management

No fixture files and no recorded fixtures: none exist for this unit and none can be made.
Each test constructs its storage and discards it. **No test may contain a credential that
would work** — passwords used in tests are generated per test and never committed as
constants that could be mistaken for a default.
