# Functional Spec — U8 `public-site`

**Upstream:** `inception/units-generation/unit-of-work.md`,
`inception/units-generation/unit-of-work-story-map.md`,
`inception/requirements-analysis/requirements.md`,
`inception/domain-design/components.md`,
`inception/contract-design/contract-summary.md`.

This unit is `kind: ui`, so it produces no `entities.md` and no `rules.md` — it
owns no entity and decides nothing. This file is the **source of truth for its
workflows**; component detail is in `frontend-components.md`.

**Under the parity rule the existing files are largely the spec.** Where a ported
file is byte-identical to its original, its behaviour is defined by that file, and
restating it here in prose would create a second description that can drift. This
document therefore specifies only what **changes** and what must be **verified**.

## What changes

| # | Change | Why |
|---|---|---|
| C1 | `app/page.tsx` server-renders from `GET /api/public/content` instead of reading a database | The language boundary. Metadata and structured data still derive from the same content |
| C2 | `siteOrigin` becomes configuration | It is a source literal today, which the construction rules forbid carrying forward |
| C3 | `robots` and `sitemap` read published metadata through the client, origin from configuration | Same |
| C4 | `canEdit` comes from a client-side session check after hydration | Today the server derives it while rendering. The public HTML now carries **no admin signal at all**, which satisfies NFR11 better than the original without moving anything visually |
| C5 | Carousel Next/Previous controls use guarded `aria-disabled` instead of native `disabled` | The one agreed user-visible behavioural change. Today focus drops to `<body>` at an endpoint and arrow-key navigation stops |
| C6 | This unit **carries the shared presentation code** — the CSS, `lib/utils.ts`, the build configuration, and the 12 vendored components — which `owner-editor` then consumes | Resolves the shared-code **ownership**. It does **not** resolve the sequencing — see below |

Everything else is byte-identical, including the 3D scene and its ~560 kB chunk,
which is a known issue deliberately left alone.

**C6 does not settle the sequencing, and saying it did was the defect.** The
earlier wording — *"Sequencing settles it"* — cited no artifact, and an ordering
asserted in a downstream design document creates no edge a scheduler can read.
`delivery-planning` runs **upstream** of this stage, so declaring the order here
comes too late to bind anything. This project already has a persisted correction
about exactly this: *a constraint a scheduler can ignore is not a constraint*.

- **What is settled:** U8 **carries** the shared presentation code under the
  current twelve-unit topology. That is this unit's decision to make and it is
  made.
- **What is open:** whether U9 is scheduled after U8, or the shared set is lifted
  into a 13th unit both depend on. **Owner: `delivery-planning`.** Until that is
  recorded there, U9 has a build-order dependency on U8 that nothing enforces.
- **The second remedy transfers what the first bullet settles, so the inventory
  names the rows that move.** Lifting the shared set into a 13th unit *is* a
  transfer of ownership, and calling the ownership settled while offering that
  remedy contradicted itself. It is settled conditionally, and the condition is
  visible: every row marked `[shared]` in `frontend-components.md`
  § *Component inventory* relocates to the 13th unit if that remedy is chosen —
  `lib/utils.ts`, the 9 CSS files, `postcss.config.mjs`, `components.json`,
  `tsconfig.json`, `package.json`, the 10 byte-identical vendored components,
  `button.tsx` and `carousel.tsx`. Everything under `app/` and `public/` stays
  with U8 under either outcome. **C5 remains U8's change either way**: FR1.6 is
  U8's requirement, so under the 13th-unit remedy U8 specifies the
  `aria-disabled` change and the owning unit applies it to the file.

### What renders when the content cannot be loaded (FR1.8, FR10.2)

This is **not** a byte-identical file, so the parity-by-diff argument does not
cover it, and it is the one piece of product copy in this unit with no fixture
oracle — U1 records *"every public route's rendered HTML"*, and a failure state is
not a route.

There are **two** failure renders in `app/page.tsx`, not one, and they carry
different copy:

1. **The page body** (`app/page.tsx:8`, the `catch` around `readContent()` and
   `editorAccess()`):
   `<main className="unavailable">` containing `<h1>Madhavi Tripathi</h1>`,
   `<p>The profile is temporarily unavailable. Please try again in a moment.</p>`,
   and `<a className="button" href="/">Try again</a>`. It also calls
   `console.error('Unable to load academic profile', error)` — the failure is
   logged, never swallowed, which the construction guardrail requires.
2. **The metadata** (`generateMetadata`'s own `catch`): returns
   `{title:'Madhavi Tripathi | Academic profile'}` — a **different** title from the
   success path's `profileMetadata(c)` and from `layout.tsx`'s static fallback.

All three strings are product copy under the parity rule and port character-exact.
Both branches keep their `console.error`. **Both need a fixture**, and neither is
covered by the route recording: the recorder must drive the backend to an error
and capture the rendered HTML, the document title **and the HTTP status**. That
is an addition to U1's manifest, owned by U1 at `code-generation`.

**The failure render returns HTTP 200.** The source reaches it by rendering an
alternative body inside a `catch`, not by signalling an error: it does not call
`notFound()` (404) and it does not rethrow (500). Under parity the port does the
same, and a developer reaching for either would change an observable. The status
is therefore part of the fixture, not an implementation detail — recorded, a
later change from 200 fails a check; unrecorded, it passes silently, which is
what made this a gap rather than a preference.

**The two catches fire independently, and all four combinations are legal.**
`generateMetadata` and the page body are separate invocations with their own read
and their own `catch`; nothing couples them. So "fallback title plus a successful
body" and "derived title plus the failure body" are both legal renders and
neither is a defect — **a test author must not assert that the fallback title and
the failure body always appear together.** The both-fail combination is what a
sustained backend outage produces and is the one the fixture records; the mixed
pairs are transient, the backend failing or recovering between the two calls. If
the implementation deduplicates the content fetch across the two invocations, the
mixed pairs become unreachable in practice — that narrows what *occurs*, it does
not change what is *legal*, and no test may depend on either.

## Public render workflow

1. Request reaches the renderer.
2. Fetch `GET /api/public/content` (unauthenticated, no credentials).
3. On success: derive title, description, Open Graph, Twitter card and
   `ProfilePage` structured data from the content, escaping `<` in the serialised
   JSON-LD; render every enabled section, hiding news when it has no items.
4. On failure, render the failure page specified above and **log the error**
   (`console.error('Unable to load academic profile', error)`, as the source does).
   **Not** an error page, and not a stack trace. Two failure modes reach this
   branch and they are not the same thing: the source's was a validation failure on
   a document it had already read, and the port adds a **transport** failure —
   the backend unreachable, timing out, or answering non-2xx. Both render the same
   page and both are logged; the log line is what distinguishes them for an
   operator, since the visitor-facing copy is fixed by parity.
5. After hydration, call the session endpoint; if signed in, reveal the edit
   affordances. **A 401 is the ordinary answer for a visitor, not a failure** —
   it reveals nothing and is not logged. Any other failure (network, 5xx, timeout)
   also reveals nothing, is logged once, and is never retried: the page is already
   correct without it. Note this makes **two** backend calls from this unit, not
   one — the public content fetch server-side and this session check after
   hydration — which is what the API-integration section means by "exactly one"
   content call plus the session check.

## Verification

**One rule governs what follows: anything whose value is destroyed by parsing
cannot be verified after parsing.** It bites twice in this unit — the JSON-LD
escaping, and the two non-HTML routes — and in both cases the check runs against
the **raw response body**, before any parser touches it.

### V-DOM — normalised DOM-structure diff, per HTML route

Against U1's recorded fixtures: strip volatile attributes, build hashes and
whitespace, then diff element tree and text content.

**`<head>` is in scope, explicitly.** `site-metadata.ts` is a **Modified** file,
so it is reformatted wholesale and its `git diff` parity evidence is gone — and
it owns FR2.1, FR2.2 and the `dateModified` field (`site-metadata.ts:33`) that
nothing else in this unit restates. Three properties of the normaliser follow, as
requirements rather than choices:

- `<head>` elements and their attributes are diffed, not stripped as volatile;
- the JSON-LD `<script type="application/ld+json">` **text node** survives
  normalisation — a normaliser that drops script contents silently stops checking
  the structured data entirely;
- `dateModified` is compared as *present and well-formed*, not by value, since it
  moves with every publish.

### V-JSONLD-ESCAPE — byte-level, on the raw body

**V-DOM cannot check the escaping half of FR2.2, and the earlier claim that the
DOM diff was the only remaining check on FR2.2 was wrong.** `app/page.tsx`
serialises the JSON-LD through a `.replace(/</g, …)` that rewrites every `<` as
its six-character JSON escape (backslash, `u`, `003c`), and an HTML parser
**unescapes that form back to `<`** when it reads the `ld+json` text node — so an
escaped port and an unescaped one produce a byte-identical normalised DOM. The
escaping is the security-relevant half of the requirement: an unescaped
`</script` inside content the owner typed closes the script element early.

The check runs on the **raw body of `GET /`** as text, before any HTML parse:

1. Locate the region between the `>` that closes the opening
   `<script type="application/ld+json"` tag and the next `</script`.
2. **Assert that region contains no `<` (U+003C) at all.** Every `<` the content
   carries must appear as the six-character escape instead. Zero is the entire
   assertion — there is no legitimate raw `<` inside the block, which is why this
   is an absolute character count rather than a pattern match for `</script`.
3. `json.loads` that region — a JSON parser decodes the escape itself — and
   compare the decoded object against the fixture's decoded object, with
   `dateModified` compared as present-and-well-formed and V-ORIGIN's substitution
   applied.

Step 2 is the parity-and-security check; step 3 is the content check. Running
only step 3 reproduces exactly the blindness this finding is about.

### V-ROBOTS and V-SITEMAP — the two non-HTML routes

`robots.ts` and `sitemap.ts` are **Modified**, so they are reformatted wholesale
and their `git diff` parity evidence is gone, exactly as `site-metadata.ts`'s is.
They own FR2.3 and FR2.4, they produce no DOM, and V-DOM does not reach them.
Both bodies are small and fixed, so the strongest available check is also the
cheapest, and no parsing is involved:

- **V-ROBOTS** — byte-exact comparison of the raw `GET /robots.txt` body against
  U1's fixture, after V-ORIGIN's substitution. Plus, named separately because the
  per-file diff evidence is gone, a byte-level assertion that the body allows
  `/`, disallows `/edit` and `/api/`, and carries a `Sitemap:` line whose value
  is the configured origin's `/sitemap.xml` (FR2.4).
- **V-SITEMAP** — byte-exact comparison of the raw `GET /sitemap.xml` body
  against U1's fixture, after V-ORIGIN's substitution, with the `lastModified`
  timestamp compared as *present and well-formed* rather than by value, for the
  same reason `dateModified` is. Plus the assertion that exactly one URL entry is
  present and its location is the configured origin's `/` (FR2.3).

**Neither route is in U1's manifest today.** It records *"every public route's
rendered HTML"*, and these two render none. The addition — the raw bodies of
`/robots.txt` and `/sitemap.xml`, and the literal origin value they carry — is
owned by **U1 at `code-generation`**, alongside the failure-render fixture above.

### V-ORIGIN — a configured origin against fixtures holding a literal one

C2 and C3 make the origin configuration, while U1's fixtures are recorded from a
source that hard-codes it. So canonical, `og:url`, the Twitter card, the JSON-LD
and every sitemap entry carry the literal on the fixture side and the configured
value on the port side. Left unstated, the diff either false-positives on every
page or is quietly relaxed until it checks nothing. It is reconciled by **two
runs with different purposes**, and both are required:

1. **Parity run.** Configure the port with the exact origin literal U1 recorded,
   then compare byte-for-byte with **no** origin normalisation anywhere. The
   parity check stays exact; nothing is relaxed to accommodate C2/C3.
2. **Configuration run (FR2.5).** Re-run with a *different* origin and assert
   that every occurrence of the first origin across all three outputs — `/`'s
   `<head>` and JSON-LD, `/robots.txt`, `/sitemap.xml` — has become the second,
   and that **no occurrence of the first remains anywhere**.

Run 1 alone cannot distinguish a genuinely configurable origin from a port that
re-hard-codes the same literal; run 2 is what makes FR2.5 a checked requirement
rather than an asserted one. The substitution applies to all three surfaces, not
to the HTML alone.

### The rest

- **A page-by-page human review** at the end. Pixel screenshot comparison was
  considered and **rejected**, not deferred.
- A byte-identical component given identical props cannot render differently, so
  the parity surface concentrates in `PORTED-MODIFIED.md` plus the CSS.

## Assumptions & Open Questions

- **[assumption]** Moving `canEdit` to a post-hydration check is invisible to a
  visitor. A signed-in owner briefly sees the page without the edit affordance
  before it appears — a change in *timing*, not in layout or content. Recorded
  because it is the one place C4 could be argued to move something.
- **[resolved]** *"The DOM diff can distinguish a real structural change from React
  hydration markers."* It can, and the answer is available now rather than at test
  time. React 19 emits two kinds of marker: **comment nodes**, which carry no
  semantic content and are safe to strip wholesale; and **`useId`-derived `id`
  values**, which are not safe to strip, because the vendored components wire
  `aria-labelledby` / `aria-describedby` / `aria-controls` to them. Stripping the
  ids would remove the ARIA relationships NFR7 depends on and turn an accessibility
  regression into a passing diff. So: strip comment nodes; then, for each
  `aria-labelledby` / `aria-describedby` / `aria-controls` (and each `for` / `id`
  pairing), **resolve the reference to the node it points at and compare that
  node** — its tag, its text content, and its relationship to the referring node
  (ancestor, sibling, descendant) — and drop the literal id value from the
  comparison entirely. A reference that resolves to no node is itself a
  difference. **Never the target's absolute path in the tree**, which would
  reintroduce the cascade below by another route.

  **Position-derived tokens were the earlier answer and they are wrong.** A token
  derived from an element's position re-encodes document position into the value
  being compared, so dropping or inserting one section shifts every downstream
  token and every ARIA pair after it reports a difference — a cascade that buries
  the single real structural change, which is precisely the case this diff exists
  to catch. Resolving to the target node compares the *wiring* without depending
  on either the literal id or its position, so a structural change produces one
  difference at the node that changed.
