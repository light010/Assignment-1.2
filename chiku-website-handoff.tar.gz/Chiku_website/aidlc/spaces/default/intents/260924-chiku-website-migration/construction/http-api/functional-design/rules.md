# Business Rules — U6 `http-api`

**Unit:** `u6-http-api` · **Kind:** `service` · **Component:** `HttpApi`

**Upstream:** `construction/functional-design/rules.md` (the rule ids and their text),
`inception/requirements-analysis/requirements.md` FR3.8, FR4.7, FR6.7, FR10.1–FR10.3,
NFR1, NFR2, `inception/domain-design/components.md` § `HttpApi` (rule ownership),
`inception/domain-design/decisions.md` ADR-003,
`inception/contract-design/contract-summary.md` § C1,
companion artifacts `entities.md` and `functional-spec.md`.

## How to read this document

Every rule here is something **an implementation could get wrong**. Rules the type
system already enforces are deliberately absent.

`BR{n}.{m}` ids are **stable and unchanged**. The major number tracks the requirement
family — `BR10.*` are FR10 rules, `BR3.*` are FR3 rules. Every id below is carried
**verbatim** from `construction/functional-design/rules.md`, which was written at
workflow level to be split per unit. **This file is that split, not a rewrite**: no id
is renumbered, merged, split or reused for a different rule.

The `BR26.x` group is the unit-scoped allocation (**U6 + 20**) reserved for rules that
realise only an NFR, a team constraint or **a decision the site owner made at a gate**,
and **trace to no FR**. There are four, and all four are listed in the traceability
`reverse` array with their reasons.

**Rule index for this unit**

| Group | Rules | Count | Hazard |
|---|---|---|---|
| The error envelope | BR10.1–BR10.6 | 6 | **yes — FR10.1** |
| Error strings are product copy | BR10.7–BR10.9 | 3 | — |
| Check ordering on `PUT /api/content` | BR10.10–BR10.12 | 3 | — |
| Authorization at the operation boundary | BR3.1–BR3.2 | 2 | — |
| Same-origin and CSRF on every non-`GET`/`HEAD` method | BR3.3–BR3.5 | 3 | — |
| Unit-scoped, **trace to no FR** | BR26.1–BR26.4 | 4 | — |

**21 rules, of which 6 are hazard rules.**

**One hazard: FR10.1, BR10.1–BR10.6.** Specified rule by rule, with an explicit
**"What breaks silently"** note, because by definition it does not fail loudly. Every
hazard rule needs a test per enumerated branch and falls inside the **100% scoped
coverage floor**.

**Nothing here is designed.** Every rule is either preserved behaviour from
`madhavi-tripathi/` or a decision already recorded in the requirements, the component
catalogue, an ADR or `WORKING-RECORD.md` § 2. **The error envelope is ported, not
redesigned** — that is the whole of this unit's risk.

**Structure of this document.** The fenced `yaml` block below is the **source of
truth**: it governs, and it is what downstream stages read. Each hazard rule's
`statement` carries its **full text**, because a hazard cannot be abbreviated without
losing the thing that makes it a hazard. The prose sections after it carry the
**rationale and the failure mode** for each rule. **The prose must not contradict the
block; where it appears to, the block wins and the prose is a defect.**

---

## Source of truth

```yaml
source_of_truth: rules
stage: functional-design
unit: u6-http-api
kind: service
kind_note: >
  U6 http-api is the ONLY unit declaring service - there is exactly one deployed
  Python executable, and this is it. Every other backend unit is a library embedded
  in it.
components: [HttpApi]
rule_count: 21
authority: >
  This block is the source of truth and governs. Each hazard rule statement carries
  its FULL text. The prose sections below carry the rationale and the failure mode
  for each rule and must not contradict this block.
id_format: 'BR{group}.{seq}; source ids are FR{n} / FR{n}.{m} / NFR{n} as spelled in requirements-analysis'
source_field_note: >
  source is a SCALAR id, a LIST of ids, or null. It names WHAT REQUIREMENT THE RULE
  SATISFIES - not what the rule is about. A rule that merely enables a requirement
  does not claim it.
nfr_realisation_note: >
  This unit realises NFR1 and NFR2. The SINGLE STATEMENT of that claim is the source
  field of the rules in this block - NFR1 on BR26.1 and BR26.3, NFR2 on BR3.1. Every
  other place the claim appears is DERIVED from here and must agree with it: the prose
  heading and the rules summary table later in this file, the realises array in
  traceability.json, and the derived rules summary in functional-spec.md. Where a
  derived view disagrees, this block governs and the derived view is the defect.
hazards:
  - { requirement: FR10.1, rules: 'BR10.1-BR10.6', subject: 'the single error envelope and its four-member taxonomy' }

rules:
  - id: BR10.1
    statement: 'Every error response across the whole HTTP surface carries exactly one envelope, {"error": "<one human sentence>"}. The key is error, not detail, not message.'
    category: constraint
    applies_to: HttpApi
    trigger: 'Any error response, at any status, on any route'
    logic: 'IF an error response is produced THEN its body is {"error": "<one sentence>"}, with issues added only per BR10.2'
    violation: >
      FastAPI's default {"detail": ...} is returned instead. Nothing throws and every
      status is still correct, so the editor appears to work while field highlighting
      shows nothing.
    source: FR10.1
    hazard: true
  - id: BR10.2
    statement: |
      On a VALIDATION failure only, the envelope additionally carries issues: an array
      of {"path": [...], "message": "..."}. The keys are PATH and MESSAGE - NOT loc and
      NOT msg. path is an array whose members are strings or integers (an integer
      member is a COLLECTION INDEX).
    category: constraint
    applies_to: HttpApi
    trigger: 'An Invalid exception carrying field-level detail'
    logic: 'IF the raised exception is Invalid THEN attach issues; ELSE omit the key entirely'
    violation: 'Pydantic loc/msg reach the wire; the editor reads result.issues and finds nothing, so no field is highlighted'
    source: FR10.1
    hazard: true
  - id: BR10.3
    statement: 'The envelope is produced by EXCEPTION HANDLERS, never constructed per route. Services raise; routers do not build responses.'
    category: policy
    applies_to: HttpApi
    trigger: 'Every error path in the system'
    logic: 'IF an error condition arises THEN a service raises a taxonomy member and a registered handler maps it; a route handler NEVER constructs an error response'
    violation: 'Per-route construction means one envelope per route, and the one route nobody updated diverges silently'
    source: FR10.1
    hazard: true
  - id: BR10.4
    statement: |
      The exception taxonomy has exactly FOUR members, mapped once:
        Exception       | Status | Carries issues
        NotAuthorized   |  403   | no
        Conflict        |  409   | no
        TooLarge        |  413   | no
        Invalid         |  400   | YES
        anything else   |  503   | no
    category: policy
    applies_to: HttpApi
    trigger: 'An exception reaching the handler layer'
    logic: 'IF NotAuthorized THEN 403; IF Conflict THEN 409; IF TooLarge THEN 413; IF Invalid THEN 400 with issues; ELSE 503'
    violation: 'A fifth member, or a per-route status decision, reintroduces the divergence BR10.3 exists to prevent'
    source: FR10.1
    hazard: true
    note: '499 sits OUTSIDE this taxonomy and is mapped explicitly - see BR26.2'
  - id: BR10.5
    statement: 'The catch-all status is 503, NOT 500. This matches the source exactly: all four source routes return 503 on an unexpected throw, and the exception is additionally logged with a full traceback.'
    category: policy
    applies_to: HttpApi
    trigger: 'An exception that is not a taxonomy member'
    logic: 'IF the exception is unrecognised THEN log it with a full traceback AND respond 503 - surfaced or logged, never swallowed'
    violation: 'A 500 is a different observable status under the parity rule; a swallowed exception violates FR10.3'
    source: [FR10.1, FR10.3]
    source_note: >
      TWO sources, deliberately. FR10.1 for the 503-not-500 status, which is the
      envelope-parity half. FR10.3 for the logging half - FR10.3 has two clauses and
      this rule discharges the FIRST of them, "surfaced or logged, never swallowed",
      in the same words. BR10.6 discharges only the SECOND clause, the wire-level
      recoverable/fatal split. Neither rule covers FR10.3 alone.
    hazard: true
  - id: BR10.6
    statement: 'Recoverable versus fatal is a WIRE-LEVEL distinction, not an internal one: 409 and 400-with-issues are recoverable and the frontend keeps specific handling for each; 503 is retryable with no specific handling.'
    category: policy
    applies_to: HttpApi
    trigger: 'Classifying any error for the client'
    logic: 'IF 409 or 400-with-issues THEN the frontend has specific handling; IF 503 THEN generic retry'
    violation: 'Collapsing the distinction removes the editor conflict recovery and field highlighting even when the envelope shape is right'
    source: FR10.3
    hazard: true
  - id: BR10.7
    statement: |
      Every user-facing error sentence falls under the parity rule. A port that
      rewrites one has changed what the owner sees. The complete set, VERBATIM
      (situation | status | string):
        Not the owner (all routes) | 403 | Please sign in with the website owner’s account.
        Origin mismatch on PUT /api/content | 403 | This request could not be verified. Refresh and try again.
        Body over the character cap | 413 | This update is too large.
        Body not parseable as JSON | 400 | The update could not be read.
        Body falsy, non-object, array, or envelope invalid | 400 | Invalid save request.
        Content validation failed | 400 | Please check the highlighted fields before saving.
        Revision conflict | 409 | This draft changed in another tab. Your edits are still here. Review the latest saved draft before saving again.
        Save threw | 503 | Your changes could not be saved. They are still in the form. Please try again.
        Content read threw | 503 | Unable to load your draft. Please try again.
        History id malformed | 400 | Choose a saved version from the history list.
        History id absent or pruned | 404 | This version is no longer in the recent history. Your current draft is unchanged.
        History read threw | 503 | Version history is temporarily unavailable. Your current edits are safe.
        Media denied or missing | 404 | Not found
        Media read threw | 503 | File temporarily unavailable
        Upload: missing or zero-byte file | 400 | Choose a non-empty file.
        Upload: unsupported or unverifiable format | 400 | The file format could not be verified. Please choose another file.
        Upload: caption file invalid | 400 | Choose a UTF-8 .vtt file beginning with WEBVTT and containing valid timed captions.
        Upload: declared length over the pre-check | 413 | Choose a video smaller than 50 MB, a photo / PDF smaller than 10 MB, or captions smaller than 1 MB.
        Upload: measured sum over the per-kind cap | 413 | Choose files totaling less than ${limit} MB.   (interpolated with the numeric cap)
        Upload cancelled | 499 | Upload cancelled. Your previous file is unchanged.
        Upload threw | 503 | Upload failed. Please try again; your form changes are safe.
      TWO of these were ELIDED in the knowledge base (the save-failure 503 and the
      variant-envelope 400) and are transcribed in full here, because a truncated
      string is not a usable parity target.
    category: policy
    applies_to: HttpApi
    trigger: 'Composing any ErrorEnvelope.error value'
    logic: 'IF an error sentence is emitted THEN it is character-for-character the source sentence for that situation'
    violation: 'A rewritten sentence has changed what the owner sees. Two of these were ELIDED in the knowledge base and are transcribed in full here; a truncated string is not a usable parity target'
    source: FR10.2
  - id: BR10.8
    statement: 'The not-the-owner 403 sentence contains U+2019 RIGHT SINGLE QUOTATION MARK, not an ASCII apostrophe.'
    category: constraint
    applies_to: HttpApi
    trigger: 'Composing the 403 sentence, and any byte-level parity diff against it'
    logic: 'IF emitting "Please sign in with the website owner U+2019 s account." THEN the apostrophe is U+2019'
    violation: 'A parity diff compares BYTES; a straight ASCII apostrophe fails it. Nothing else in the system would notice'
    source: FR10.2
  - id: BR10.9
    statement: |
      Four upload strings lose their trigger under FR6.5 and D24, because server-side
      variant generation removes the browser-prepared-variant surface entirely:
        The prepared image sizes could not be verified. Please choose the photo again.
        Prepared photo sizes must use WebP.
        Prepared photo sizes must be no larger than 1600 pixels.
        Prepared photo sizes must match the original framing.
      They are recorded here so a reader can tell a DELIBERATELY RETIRED string from a
      MISSED one. DO NOT re-create the checks in order to keep the strings alive.
    category: policy
    applies_to: HttpApi
    trigger: 'Reading the BR10.7 set and finding four source strings absent from it'
    logic: 'IF a string relates to verifying browser-prepared variants THEN it is retired. DO NOT re-create the checks in order to keep the strings alive'
    violation: 'Re-creating the retired checks reinstates a surface FR6.5 removed entirely'
    source: FR10.2
  - id: BR10.10
    statement: |
      The checks run STRICTLY in this order, because the order determines which status
      a multiply-invalid request receives:
        1. Origin match -> 403
        2. Owner session -> 403
        3. Decoded body length over the cap -> 413
        4. JSON parse failure -> 400
        5. Body falsy, not an object, or an array -> 400
        6. CONTENT SCHEMA VALIDATION -> 400 with issues[]
        7. ENVELOPE VALIDATION -> 400 without issues[]
        8. Write returns a conflict signal -> 409
        9. Otherwise -> 200
    category: policy
    applies_to: HttpApi
    trigger: 'Every PUT /api/content'
    logic: 'IF the request is invalid in more than one way THEN the FIRST failing check decides the status'
    violation: 'Reordering changes which status a multiply-invalid request receives, which is observable and under the parity rule'
    source: FR4.7
    csrf_position_note: >
      WHERE THE CSRF CHECK SITS, pinned because the nine steps above do not name it and
      an unpinned ordering that is observable is the same defect class as BR3.5's
      unclassified branch. The nine steps are carried VERBATIM from the source, which
      had no CSRF check - BR3.4 is a PORT ADDITION (D1) - which is why it is absent
      rather than misplaced, and why the step numbers are NOT renumbered here.
      THE RULE: the CSRF check belongs to the SAME MIDDLEWARE AUTHORIZATION GROUP as the
      origin check at step 1, and THE WHOLE GROUP PRECEDES STEP 2 (owner session
      authorization) AND THEREFORE STEP 3 (body size) AND EVERYTHING AFTER IT. The
      principle is the one BR3.5 ordering_note states: AUTHORIZATION CHECKS PRECEDE
      PAYLOAD PROCESSING. A request that fails origin or CSRF must never cause the
      server to read and measure a 1,500,000-character body.
      WITHIN THE GROUP, the order of the origin check and the CSRF check is DELIBERATELY
      NOT PINNED, because it is NOT OBSERVABLE: both return 403 and, as currently
      specified, the same sentence. This is stated rather than left silent so a reader
      can tell an unpinned-because-unobservable ordering from an overlooked one.
      SESSION RESOLUTION IS NOT AUTHORIZATION. Verifying the CSRF token requires the
      session to have been RESOLVED (BR3.12 pairs the token 1:1 with it), and resolution
      happens in the middleware. That does not conflict with step 1 preceding step 2:
      step 2 is the owner AUTHORIZATION DECISION made behind the route, and BR3.2 keeps
      resolution and decision distinct.
    csrf_sentence_open: >
      CONDITION ON THE ABOVE. No CSRF-mismatch sentence is stated anywhere in this
      unit's artifacts, in the workflow-level rules, or in BR10.7's verbatim set - the
      source had no CSRF check, so there is no ported string to carry. WHILE the
      mismatch emits the same 403 sentence as an origin mismatch, the intra-group order
      stays unobservable and unpinned. IF it is ever given its own distinct sentence,
      THE INTRA-GROUP ORDER BECOMES OBSERVABLE AND MUST BE PINNED AT THAT POINT. Naming
      the sentence is a product-copy decision and is NOT taken here.
  - id: BR10.11
    statement: 'Content validation (step 6) runs BEFORE envelope validation (step 7). A request carrying both malformed content and a bad revision returns the CONTENT 400 with issues, not the envelope 400.'
    category: policy
    applies_to: HttpApi
    trigger: 'A PUT /api/content invalid in both content and envelope'
    logic: 'IF content fails validation THEN return 400 WITH issues, without evaluating the envelope'
    violation: 'Reordering silently changes the error the editor displays - it highlights fields on one and shows a bare sentence on the other'
    source: FR4.7
  - id: BR10.12
    statement: |
      Envelope validation (step 7) rejects unless ALL hold, evaluated as ONE
      PREDICATE: revision is a safe integer; revision >= 0; revision <
      Number.MAX_SAFE_INTEGER; action is exactly draft or publish; autosave is absent
      or a boolean; and NOT (autosave === true AND action !== 'draft'). Autosave is
      legal only with a draft action.
    category: validation
    applies_to: HttpApi
    trigger: 'Step 7 of the PUT /api/content check order'
    logic: 'IF any clause fails THEN 400 WITHOUT issues. Autosave is legal only with a draft action'
    violation: '400 without issues. Evaluating the clauses separately produces different messages for what the source reports identically'
    source: FR4.7
  - id: BR3.1
    statement: 'Every protected read and every mutation authorises itself AT ITS OWN OPERATION, never by the route placement, a protected layout, a hidden control or a frontend route rule. A request that bypasses the frontend entirely is rejected identically.'
    category: authorization
    applies_to: 'HttpApi, and every component behind it'
    trigger: 'Every protected operation'
    logic: 'IF an operation is protected THEN it checks the caller identity itself, regardless of how the request arrived'
    violation: 'Structural assurance replaces behavioural assurance; a route accidentally left unprotected merely looks wrong in review rather than failing a test'
    source: [FR3.8, NFR2]
    source_note: >
      THIS RULE IS WHERE THIS UNIT REALISES NFR2, and it is the only one. FR3.8 and
      NFR2 state the same obligation from two sides - FR3.8 "authorised in Python at
      its own operation boundary ... a request that bypasses the frontend entirely is
      rejected identically", NFR2 "every protected operation authorises itself,
      verified by tests that call the API directly, bypassing the frontend". BR3.1
      carries the rule half; the verification half is the test obligation in
      functional-spec.md, which ADR-003 names as the condition of its own soundness.
      BR3.2 is NOT a second NFR2 source: it is the prohibition that keeps structural
      assurance from creeping back, which SUPPORTS NFR2 without discharging it.
  - id: BR3.2
    statement: 'HttpApi enforces nothing beyond transport concerns. The authorization decision belongs to the component behind the route.'
    category: authorization
    applies_to: HttpApi
    trigger: 'Every request'
    logic: 'IF an authorization decision is needed THEN the component behind the route makes it; this unit resolves identity and carries it'
    violation: 'A routing layer that decides becomes the enforcement point, which ADR-003 explicitly traded away'
    source: FR3.8
  - id: BR3.3
    statement: 'Origin enforcement reproduces the source predicate: the Origin header must be PRESENT and EXACTLY EQUAL to the request URL own origin. A MISSING Origin header FAILS the check. WHICH requests this applies to is defined by BR3.5 and nowhere else.'
    category: authorization
    applies_to: HttpApi
    trigger: 'Every request in the set BR3.5 defines - every method that is not GET or HEAD'
    logic: 'IF Origin is absent OR Origin != the request URL origin THEN 403. Absent is NOT treated as same-origin'
    violation: 'Treating a missing header as same-origin removes the source only CSRF defence'
    source: FR6.7
  - id: BR3.4
    statement: 'The port ADDS a CSRF token (double-submit) paired with the session, on top of BR3.3. The origin check is not replaced by it. It applies to EXACTLY THE SAME REQUEST SET as BR3.3, which BR3.5 defines.'
    category: authorization
    applies_to: HttpApi
    trigger: 'Every request in the set BR3.5 defines - every method that is not GET or HEAD'
    logic: 'IF the method is not GET or HEAD THEN check BOTH the origin predicate AND the paired CSRF token. The two defences are independent and both apply'
    violation: >
      Replacing the origin check with the token drops a defence the source had. Scoping
      this rule to "mutations" while BR3.5 is scoped to the method would reopen the
      same hole one rule over: POST /api/content/inspect would be origin-checked but
      NOT CSRF-checked, for no stated reason.
    source: FR6.7
    note: >
      BR3.3, BR3.4 and BR3.5 apply to ONE request set, defined ONCE in BR3.5, INCLUDING
      ITS ENUMERATED EXCEPTION. Before the gate widening these three restated the set
      independently as "mutations", which is how POST /api/content/inspect fell outside
      all of them. Do not reintroduce a per-rule scope. The one-shot owner-provisioning
      route is outside this rule for a reason SPECIFIC TO IT: the CSRF token is paired
      1:1 with a SESSION (BR3.12) and during bootstrap no session exists, so there is no
      token to verify. See BR3.5 exceptions.
  - id: BR3.5
    statement: |
      In the source, origin is checked on 2 of 6 endpoint/method pairs - PUT
      /api/content and POST /api/upload only. THE PORT APPLIES IT TO EVERY METHOD THAT
      IS NOT GET OR HEAD. That is the whole rule: the test is the METHOD, not whether
      the operation happens to write. It is NEVER applied to GET or HEAD.
    category: authorization
    applies_to: HttpApi
    trigger: 'Deciding whether origin enforcement applies to a request'
    logic: 'IF the method is GET or HEAD THEN never enforce origin; ELSE enforce it. There is no third branch'
    violation: >
      Applying it to GET breaks the public media path and the public content read for
      any cross-origin reader. Scoping it to "mutations" instead of to the method
      leaves a POST that writes nothing - POST /api/content/inspect - in NEITHER
      branch, and an unclassified branch in an authorization rule is the defect
      regardless of which answer is right.
    source: FR6.7
    note: >
      THIS RULE WAS WIDENED AT THE FUNCTIONAL-DESIGN GATE, and the earlier extensional
      wording - "MUTATIONS, the same set plus the new authentication mutations" - is
      WITHDRAWN, not merely rephrased. It defined the set two ways that disagreed:
      extensionally (the source pairs plus the auth mutations), which excluded POST
      /api/content/inspect because that route did not exist in the source, and
      intensionally ("IF the method mutates"), which did not classify a POST that
      writes nothing. The intensional rule now stands alone and is keyed on the METHOD.
      Three reasons, recorded. ONE, BR3.3 already sets the fail-closed precedent by
      treating an ABSENT Origin as a failure; a sibling rule in the same group reading
      fail-open for an unclassified case would be the inconsistency, not the fix. TWO,
      it costs nothing: every non-GET/HEAD route here is owner-only and same-origin by
      construction, so no legitimate caller is affected and the only thing enforcement
      changes is what happens to a request that had no business being made. THREE, an
      unclassified branch in a security rule is the defect independently of which
      answer is right, and closing holes in this group is what BR3.x is for.
    ordering_note: >
      ORIGIN IS CHECKED BEFORE ANY PAYLOAD IS READ OR MEASURED, on every route it
      applies to. Authorization precedes payload processing: a request from a
      disallowed origin must NOT cause the server to read and measure a body. This is
      already step 1 ahead of step 3 in BR10.10 for PUT /api/content, and it is the
      same ordering on POST /api/content/inspect, where it decides 403 versus 413 for a
      request that is both bad-origin AND oversize. The ordering is observable, so it
      is pinned here rather than left to the implementer.
    exceptions:
      - route: 'The one-shot owner-provisioning route (see functional-spec.md, Owner provisioning and startup). EXACTLY ONE route. This list is exhaustive; there is no second exception and no category of exception'
        applies: 'Neither BR3.3 origin enforcement NOR BR3.4 CSRF verification applies to this route'
        why: >
          THE ORIGIN CHECK DEFENDS AGAINST AMBIENT AUTHORITY, and this route has none to
          borrow. CSRF is possible only when a browser will attach credentials the
          attacker does not possess - a session cookie - to a request the attacker
          causes. This route is gated on ADMIN_BOOTSTRAP_SECRET, which the caller must
          supply EXPLICITLY IN THE REQUEST and which no browser will ever attach on a
          third party's behalf. An attacker's page cannot make a victim's browser send a
          secret the browser does not hold. So on this route the origin check PROTECTS
          NOTHING while breaking the only caller the route exists for. This is a property
          of the route's AUTHENTICATION MODEL, not an exemption for tooling convenience.
          BR3.4 cannot apply either, and not merely by the same argument: the CSRF token
          is paired 1:1 with a SESSION (BR3.12), and during bootstrap NO SESSION EXISTS -
          nobody is signed in and no owner row exists yet - so there is no token to pair
          with or verify.
        compensating_controls:
          - 'ADMIN_BOOTSTRAP_SECRET must be set AND supplied in the request. With the secret unset and no owner, the service starts and refuses every sign-in rather than creating an account'
          - 'The route is enabled ONLY while NO OWNER RECORD EXISTS. The gate is the RECORD EXISTENCE, not a consumed flag, so restarting the container cannot reopen it'
        controls_are_load_bearing: >
          THE CARVE-OUT IS SAFE BECAUSE THOSE TWO HOLD. If either ever changes - if the
          route stops requiring the secret, or the gate becomes a flag rather than the
          record's existence - THE CARVE-OUT MUST BE RE-ARGUED, not carried forward.
        rejected_alternative: >
          REQUIRING THE OPERATOR TO SEND A MATCHING Origin HEADER FROM curl WAS
          CONSIDERED AND REJECTED AS SECURITY THEATRE. Origin is trustworthy ONLY
          BECAUSE BROWSERS SET IT and refuse to let script forge it. A non-browser
          caller sets whatever it likes, so the header proves NOTHING about a curl
          request, and an attacker who can reach the endpoint can set it exactly as
          easily as the operator can. It would add a step to the runbook and zero
          security. Recorded because it is the option that LOOKS stricter and is the one
          the next reader will reach for first.
      - note: >
          THIS IS AN ENUMERATED EXCEPTION, NOT A SOFTENING OF THE TEST. The logic field
          above stays single-branch on the METHOD, and this route is named rather than
          described by a property other routes could acquire. One named exception
          carrying a stated reason is not a hole; an unclassified branch is - which is
          exactly the defect the gate widening closed.

  # ---------------------------------------------------------------------------
  # Unit-scoped group BR26.x = U6 + 20. These realise an NFR or a contract-
  # ownership rule and trace to NO FR, so they belong in the reverse array.
  # ---------------------------------------------------------------------------
  - id: BR26.1
    statement: 'Boundary enforcement is a COMMAND, not an assertion. Three checks run at the merge gate: a grep for forbidden frontend constructs, an AST test that no router module imports a store, and a regeneration of the committed client types that fails if the output is dirty.'
    category: policy
    applies_to: HttpApi
    trigger: 'Every merge gate'
    logic: >
      IF frontend/ contains any ''use server'' directive, any app/**/route.ts or any
      middleware.ts THEN fail. IF any module under routers/ imports a store module or
      sqlite3 THEN fail. IF regenerating the committed openapi-typescript output leaves
      it dirty THEN fail.
    violation: >
      A rule nobody can check is a wish. Without the three commands the language
      boundary is asserted rather than enforced, and a backend field rename surfaces as
      a runtime 422 in the browser instead of as a tsc error with a file and a line.
    source: NFR1
    traces_to_fr: null
    reverse_reason: >
      NFR1 states the boundary; no FR states that it must be MACHINE-CHECKED. The
      obligation comes from team.md Testing Posture - "Boundary enforcement is a
      command, not an assertion" - and it is this unit that owns the two checks on the
      backend side of it.
  - id: BR26.2
    statement: '499 sits OUTSIDE the four-member taxonomy and is mapped EXPLICITLY. It must never fall through to the 503 catch-all, and it still carries the one envelope.'
    category: policy
    applies_to: HttpApi
    trigger: 'A cancelled upload signalled by u5-media'
    logic: 'IF the unit behind the route signals cancellation THEN respond 499 with the standard envelope; NEVER let it reach the BR10.5 catch-all'
    violation: >
      BR10.4 enumerates exactly four members plus a catch-all, and 499 is none of them.
      A literal reading of BR10.4 sends every cancellation to 503, which is a different
      observable status and loses the only signal the editor has that the owner
      cancelled rather than that the server failed.
    source: null
    traces_to_fr: null
    reverse_reason: >
      No FR states it. FR6.6 covers cancellation but is assigned to U5, and BR10.4 -
      this unit own taxonomy rule - does not contain 499. The obligation falls exactly
      in the gap between them, which is how it would be lost. contract-summary C1
      lists 499 on POST /api/upload, so the contract requires it even though no
      requirement sentence does.
    note: >
      THIS IS THE LOCAL CLOSURE OF A WORKFLOW-LEVEL GAP, not a nuance of BR10.4 and not
      a fix to it. The gap is in construction/functional-design/rules.md BR10.4, whose
      four members plus "anything else -> 503" are exhaustive as written; it is OPEN
      there and is being fixed separately. BR26.2 closes it for u6-http-api ONLY. Any
      other reading of the workflow-level BR10.4 - another unit, a later stage, a
      developer working from that file - still sends a cancelled upload to 503 with
      "Upload failed. Please try again; your form changes are safe." instead of 499
      with "Upload cancelled. Your previous file is unchanged." Do not delete this rule
      on the grounds that BR10.4 "obviously" means to allow 499: it does not.
  - id: BR26.3
    statement: 'The OpenAPI document is GENERATED from the Pydantic models, never hand-maintained, and U7 TypeScript types are generated from it and committed.'
    category: policy
    applies_to: HttpApi
    trigger: 'Any change to a request or response model'
    logic: 'IF a model changes THEN the document changes with it automatically; a hand-edited document, or a hand-written TypeScript mirror of a backend model, is forbidden'
    violation: >
      A hand-maintained document is a second definition that drifts from the
      authoritative one. A hand-written type mirror is forbidden outright by
      project.md Forbidden, and it is what makes the boundary type-checked rather than
      asserted.
    source: NFR1
    traces_to_fr: null
    reverse_reason: >
      No FR states it. FR8.9 says the CLIENT mirror must be generated and is assigned
      to U7; the obligation on the PROVIDER - that the document it generates from is
      itself generated - is stated only in contract-summary Contract ownership rules
      and in project.md Forbidden.
  - id: BR26.4
    statement: |
      POST /api/content/inspect carries a request-body cap of 6,000,000 CHARACTERS of
      decoded text. That is the DRAFT-RECOVERY bound (editor-workflow.ts:15) and NOT
      the 1,500,000-character save cap (route.ts:11, BR4.20). A body over it is
      rejected with 413 and the envelope, carrying the sentence:
        This draft is too large to check.
      The cap counts CHARACTERS, not bytes, for the same reason BR4.20/BR4.21 do, and
      it is checked AFTER the body is fully read and BEFORE JSON parsing, the position
      BR4.22 fixes for the save cap. A DRAFT THAT IS RECOVERABLE MUST ALWAYS BE
      INSPECTABLE: this cap tracks the recovery bound by derivation, so if the recovery
      bound ever moves, this number moves with it.
    category: constraint
    applies_to: HttpApi
    trigger: 'Every POST /api/content/inspect, before the body is parsed'
    logic: 'IF the decoded request body exceeds 6,000,000 characters THEN raise TooLarge -> 413 with "This draft is too large to check." The bound is the RECOVERY bound, never the save cap'
    violation: >
      Setting this cap to the 1,500,000 save cap makes a draft in the window between
      the two bounds RECOVERABLE BUT UNCLASSIFIABLE - the editor offers the owner a
      draft the system then refuses to inspect. Omitting the cap entirely leaves this
      unit's one remaining unbounded request body: every other body-bearing route is
      capped, and an uncapped route is a body the process reads in full before
      anything rejects it.
    source: null
    traces_to_fr: null
    reverse_reason: >
      No FR and no NFR states it. FR4.6 states the 1,500,000-character cap for a SAVE
      request only; FR8.3 states recovered-draft classification and is assigned to U4,
      and this rule ENABLES that classification without discharging it. The obligation
      comes from a decision the SITE OWNER made at the functional-design gate:
      preserve both bounds and warn, rather than lower either. The cap belongs to this
      unit because it is a transport-boundary check on a route this unit owns.
    note: >
      THE TWO CAPS ARE NOT ONE CAP AND MUST NOT BE COLLAPSED. Three numbers, three
      jobs: the RECOVERY bound 6,000,000 decides what the editor will offer to restore;
      the INSPECT cap 6,000,000 decides what this route will classify, and tracks the
      recovery bound BY DERIVATION; the SAVE cap 1,500,000 decides what
      PUT /api/content will accept, and moves only with FR4.6. A draft in the window
      1,500,001..6,000,000 is recoverable, offered, inspectable, classified, and THEN
      fails to save with 413 plus the warning - that is the decided behaviour, not a
      defect to be tidied away by making the three numbers agree.
    coverage_note: >
      team.md Testing Posture names "the request-size cap" a hazard module under the
      100 percent scoped coverage floor. This cap is implemented in that module, so it
      falls inside that floor: a test at the bound, one under it and one over it, and a
      test asserting that the inspect cap is NOT the save cap - a body of 1,500,001
      characters is inspected successfully and refused by PUT.

rules_subject_to_but_not_owned:
  - { id: BR4.20, owner_unit: u4-content-core, why: 'The 1,500,000-CHARACTER cap. Owned by ContentAuthority; ENFORCED here, at step 3, where the decoded body first exists' }
  - { id: BR4.22, owner_unit: u4-content-core, why: 'Fixes the cap position - after the body is read, BEFORE JSON parsing - so ownership and enforcement cannot drift' }
  - { id: BR4.7,  owner_unit: u4-content-core, why: 'Optimistic concurrency. This unit maps its conflict signal to 409 and returns the current state with the error' }
  - { id: BR8.1,  owner_unit: u4-content-core, why: 'Recovered-draft classification, reached through POST /api/content/inspect. This unit routes; it does not classify' }
  - { id: BR3.11, owner_unit: u3-identity-and-session, why: 'The signed session cookie this unit sets on a successful sign-in' }
  - { id: BR3.12, owner_unit: u3-identity-and-session, why: 'The CSRF token paired 1:1 with the session, which BR3.4 verifies here' }
  - { id: BR3.16, owner_unit: u3-identity-and-session, why: 'Verification returns the owner identity OR NOTHING; this unit carries the result into WIRE-4' }
  - { id: BR3.20, owner_unit: u3-identity-and-session, why: 'Rate-limit refusal is indistinguishable from a credential failure - same status, same body, same sentence. This unit must add no Retry-After header' }
  - { id: BR5.5,  owner_unit: u4-content-core, why: 'The history id validation whose absent-versus-empty distinction is a real branch: no id means list, ?id= is a 400' }
  - { id: BR6.12, owner_unit: u5-media, why: 'The advisory content-length pre-check, read from a header this unit receives' }
```

### Rules summary

| Group | Rules | Category mix | Requirement | Hazard |
|---|---|---|---|---|
| The error envelope | **BR10.1–BR10.6** | constraint, policy | **FR10.1**; FR10.3 (BR10.5, BR10.6) | **yes** |
| Error strings are product copy | BR10.7–BR10.9 | policy, constraint | FR10.2 | — |
| Check ordering on `PUT /api/content` | BR10.10–BR10.12 | policy, validation | FR4.7 | — |
| Authorization at the operation boundary | BR3.1–BR3.2 | authorization | FR3.8; **NFR2 (BR3.1 only)** | — |
| Same-origin and CSRF on every non-`GET`/`HEAD` method | BR3.3–BR3.5 | authorization | FR6.7 | — |
| *Unit-scoped — trace to no FR* | *BR26.1–BR26.4* | *policy, constraint* | *NFR1 (BR26.1, BR26.3); none (BR26.2, BR26.4)* | — |

**21 rules. 6 are hazard rules** — each needs a test per enumerated branch and falls
inside the 100% scoped coverage floor. **BR26.1–BR26.4 trace to no FR** and belong in
the traceability `reverse` array, not in `coverage`.

**This table is derived.** The `source` fields in the yaml block above are the single
statement of every requirement claim, including **NFR2, which this unit realises at
`BR3.1` and nowhere else**. If this table and the block disagree, the block governs
and this table is the defect.

---

## The error envelope

### BR10.1–BR10.6 — the error envelope [hazard, FR10.1]

> **What breaks silently.** FastAPI's defaults produce `{"detail": ...}` and
> Pydantic's `loc` / `msg` on validation errors. The ported editor branches on
> `409` to enter conflict recovery and reads `result.issues` to highlight fields.
> With FastAPI's defaults, the editor **appears to work**: requests succeed,
> statuses are returned, nothing throws — but field highlighting shows nothing and
> conflict recovery never arms. This is the highest-probability silent regression
> in the migration.

- **BR10.1** Every error response across the whole HTTP surface carries exactly one
  envelope: `{"error": "<one human sentence>"}`. The key is `error`, not `detail`,
  not `message`.
- **BR10.2** On a **validation** failure only, the envelope additionally carries
  `issues`: an array of `{"path": [...], "message": "..."}`. The keys are `path`
  and `message` — not `loc` and `msg`. `path` is an array whose members are strings
  or integers (an integer member is a collection index).
- **BR10.3** The envelope is produced by **exception handlers**, never constructed
  per route. Services raise; routers do not build responses.
- **BR10.4** The exception taxonomy has exactly **four** members, mapped once:

  | Exception | Status | Carries `issues` |
  |---|---|---|
  | `NotAuthorized` | **403** | no |
  | `Conflict` | **409** | no |
  | `TooLarge` | **413** | no |
  | `Invalid` | **400** | **yes** |
  | anything else | **503** | no |

- **BR10.5** The catch-all status is **503, not 500**. This matches the source
  exactly: all four source routes return 503 on an unexpected throw. An unhandled
  exception is additionally logged with a full traceback (`logger.exception()`) —
  surfaced or logged, never swallowed.
- **BR10.6** Recoverable versus fatal is a **wire-level** distinction, not an
  internal one: `409` and `400`-with-`issues` are recoverable and the frontend keeps
  specific handling for each; `503` is retryable with no specific handling.

#### Why "produced by exception handlers, never per route" is the operative clause

BR10.3 is the rule that makes BR10.1 **true of the whole surface** rather than of the
routes someone remembered. Three consequences follow that are easy to miss:

1. **A route handler has no error branch at all.** It calls a service and returns the
   success shape. There is no `if not authorised: return ...` anywhere in `routers/`,
   because that shape is what diverges.
2. **The handler layer must also catch what never reaches a route** — a malformed path,
   an unroutable method, a framework-level request-validation failure, a middleware
   rejection. Every one of those produces a framework default by *default*, and every
   one of them is part of "the whole HTTP surface". Registering handlers only for the
   four taxonomy members leaves those paths emitting `{"detail": ...}`, and they are
   exactly the paths no test exercises.
3. **The four-member taxonomy is closed** (BR10.4). A fifth member is not an extension;
   it is a second mapping decision, and a second mapping decision is how per-route
   divergence returns under a different name. **499 is the one status outside it, and
   it is mapped explicitly rather than by adding a member** — see BR26.2.

#### The one test that catches this and nothing else does

The hazard is silent because the **statuses stay correct**. A test that asserts "a
conflict returns 409" passes under FastAPI's defaults. The assertion that fails is on
the **body**:

- every error response body has an `error` key and **no** `detail` key;
- a validation failure's body has an `issues` array whose members have **`path`** and
  **`message`** keys and **no** `loc` or `msg` keys;
- an unhandled exception returns **503**, not 500;
- **a request that never reaches a route handler** — an unknown path, a wrong method —
  also returns this envelope.

The fourth is the one a reviewer forgets, and it is the one a framework gets wrong by
default.

## Error strings are product copy

### BR10.7–BR10.9 — error strings are product copy [FR10.2]

- **BR10.7** Every user-facing error sentence falls under the parity rule. A port
  that rewrites one has changed what the owner sees. The complete set, **verbatim**:

  | Situation | Status | String |
  |---|---|---|
  | Not the owner (all routes) | 403 | `Please sign in with the website owner’s account.` |
  | Origin mismatch on `PUT /api/content` | 403 | `This request could not be verified. Refresh and try again.` |
  | Body over the character cap | 413 | `This update is too large.` |
  | Body not parseable as JSON | 400 | `The update could not be read.` |
  | Body falsy, non-object, array, or envelope invalid | 400 | `Invalid save request.` |
  | Content validation failed | 400 | `Please check the highlighted fields before saving.` |
  | Revision conflict | 409 | `This draft changed in another tab. Your edits are still here. Review the latest saved draft before saving again.` |
  | Save threw | 503 | `Your changes could not be saved. They are still in the form. Please try again.` |
  | Content read threw | 503 | `Unable to load your draft. Please try again.` |
  | History id malformed | 400 | `Choose a saved version from the history list.` |
  | History id absent or pruned | 404 | `This version is no longer in the recent history. Your current draft is unchanged.` |
  | History read threw | 503 | `Version history is temporarily unavailable. Your current edits are safe.` |
  | Media denied or missing | 404 | `Not found` |
  | Media read threw | 503 | `File temporarily unavailable` |
  | Upload: missing or zero-byte file | 400 | `Choose a non-empty file.` |
  | Upload: unsupported or unverifiable format | 400 | `The file format could not be verified. Please choose another file.` |
  | Upload: caption file invalid | 400 | `Choose a UTF-8 .vtt file beginning with WEBVTT and containing valid timed captions.` |
  | Upload: declared length over the pre-check | 413 | `Choose a video smaller than 50 MB, a photo / PDF smaller than 10 MB, or captions smaller than 1 MB.` |
  | Upload: measured sum over the per-kind cap | 413 | `Choose files totaling less than ${limit} MB.` — interpolated with the numeric cap |
  | Upload cancelled | 499 | `Upload cancelled. Your previous file is unchanged.` |
  | Upload threw | 503 | `Upload failed. Please try again; your form changes are safe.` |

- **BR10.8** `Please sign in with the website owner’s account.` contains
  **U+2019 RIGHT SINGLE QUOTATION MARK**, not an ASCII apostrophe. A parity diff
  against recorded fixtures compares bytes; a straight `'` fails it.
- **BR10.9** Four upload strings lose their trigger under FR6.5 and D24, because
  server-side variant generation removes the browser-prepared-variant surface
  entirely: `The prepared image sizes could not be verified. Please choose the photo
  again.`, `Prepared photo sizes must use WebP.`, `Prepared photo sizes must be no
  larger than 1600 pixels.`, `Prepared photo sizes must match the original framing.`
  They are recorded here so a reader can tell a **deliberately retired** string from
  a **missed** one. Do not re-create the checks in order to keep the strings alive.

#### Two facts about this table that a careless reading loses

**1. Two of these strings were elided in the knowledge base and have since been
transcribed in full.** The CodeKB quotes the save-failure 503 as
`Your changes could not be saved...` and the variant-envelope 400 as
`The prepared image sizes could not be verified...`, both cut short with an ellipsis.
BR10.7 and BR10.9 above give the **full** strings, transcribed directly from
`madhavi-tripathi/app/api/content/route.ts` and `app/api/upload/route.ts`, **because a
truncated string is not a usable parity target** — a diff against `...` cannot pass and
cannot fail for the right reason. The recorded source fixtures (**U1**) are the
confirmation of record.

**2. One contains U+2019, not an ASCII apostrophe.** In
`Please sign in with the website owner’s account.` the mark between `owner` and `s` is
**U+2019 RIGHT SINGLE QUOTATION MARK** (UTF-8 `E2 80 99`), not U+0027 (`27`). This is
the string returned by **every route** on a not-the-owner rejection, so it is the most
frequently emitted sentence in the system.

**This is confirmed against a live response, not read off the code.** The source
application was booted and probed, and an unauthenticated `GET /api/content` returned
**403** with a 62-byte `application/json` body captured verbatim as
`{"error":"Please sign in with the website owner’s account."}`
(`scratchpad/source-boot-verified.md`). The same run confirms the envelope's shape at
the wire: **one key, `error`**, and **no `detail`**.

**A byte-level parity diff fails on a straight `'`.** It is not a typographic
preference and it is not normalisable: the parity check compares the response bytes
against the recorded fixture's bytes, and three bytes differ from one. Nothing else in
the system would notice — the status is right, the shape is right, the sentence reads
identically to a human, and the diff is red.

Two corollaries: the string must not be written through any editor or tool that
"smartens" or "dumbens" quotes, and the test asserting it must compare the **exact
literal**, not a normalised form.

#### The retired four are retired, not missing

BR10.9's four strings have **no trigger left**. FR6.5 and D24 move variant generation
server-side, which removes the entire browser-prepared-variant surface: the variant
envelope check, the WebP-only rule, the 1600-pixel ceiling and the aspect-ratio
tolerance formula. The strings are recorded so that a reader comparing this table
against the source does not conclude four strings were dropped by accident and
reinstate the checks to bring them back. **Do not re-create the checks in order to keep
the strings alive.**

## Check ordering on `PUT /api/content`

### BR10.10–BR10.12 — check ordering on `PUT /api/content` [FR4.7]

- **BR10.10** The checks run **strictly in this order**, because the order determines
  which status a multiply-invalid request receives:

  1. Origin match → 403
  2. Owner session → 403
  3. Decoded body length over the cap → 413
  4. JSON parse failure → 400
  5. Body falsy, not an object, or an array → 400
  6. **Content schema validation → 400 with `issues[]`**
  7. **Envelope validation → 400 without `issues[]`**
  8. Write returns a conflict signal → 409
  9. Otherwise → 200

- **BR10.11** **Content validation (6) runs BEFORE envelope validation (7).** A
  request carrying both malformed `content` and a bad `revision` returns the
  *content* 400 with `issues[]`, not the envelope 400. Reordering these two
  silently changes the error the editor displays — the editor highlights fields on
  one and shows a bare sentence on the other.
- **BR10.12** Envelope validation (step 7) rejects unless **all** hold, evaluated as
  one predicate: `revision` is a safe integer; `revision >= 0`; `revision <
  Number.MAX_SAFE_INTEGER`; `action` is exactly `draft` or `publish`; `autosave` is
  absent or a boolean; and **not** (`autosave === true` **and** `action !==
  'draft'`). Autosave is legal only with a draft action.

#### Three ordering facts that are each a separate test

- **Step 3 before step 4.** The cap is checked **after the body is fully read** and
  **before JSON parsing**. It therefore limits **document size, not memory use** — the
  full body is already in memory when the check runs. Moving it after the parse changes
  which status a too-large **malformed** body receives: 413 today, 400 if reordered.
  (The cap itself — 1,500,000 **characters**, not bytes — is **BR4.20**, owned by
  `ContentAuthority`; this unit **enforces** it at the point where the decoded body
  first exists, and **BR4.22** fixes the position so ownership and enforcement cannot
  drift.)
- **Step 6 before step 7.** BR10.11's case, above. It is the only ordering in the list
  whose two outcomes have the **same status** (400) and **different bodies** — one with
  `issues[]`, one without — which is exactly why reordering it is silent.
- **Step 1 before step 2.** A request with a bad origin **and** no session returns the
  origin 403 with `This request could not be verified. Refresh and try again.`, not the
  ownership 403. Two different sentences at the same status; the order picks one.

#### Where the CSRF check sits — pinned, because the nine steps do not name it

The nine steps are carried **verbatim from the source**, and **the source had no CSRF
check**: BR3.4 is a **port addition** (D1). So it is **absent rather than misplaced**,
and the step numbers are **not renumbered** to make room for it.

**The rule.** The CSRF check belongs to the **same middleware authorization group as the
origin check at step 1**, and **the whole group precedes step 2** (owner session
authorization) and therefore **step 3** (body size) and everything after it. The
principle is the one BR3.5 already states: **authorization checks precede payload
processing.** A request that fails origin or CSRF must never cause the server to read
and measure a 1,500,000-character body.

**Within the group, the order of origin and CSRF is deliberately not pinned, because it
is not observable** — both return `403` and, as currently specified, the same sentence.
That is stated rather than left silent so a reader can tell an
**unpinned-because-unobservable** ordering from an **overlooked** one. This is the same
distinction the BR3.5 widening turned on: a branch nobody classified is a defect, a
branch someone classified as indifferent is not.

> **The condition that would change this.** **No CSRF-mismatch sentence is stated
> anywhere** — not here, not in the workflow-level rules, and not in BR10.7's verbatim
> set, because the source had no such check and there is no ported string to carry.
> **While the mismatch emits the same 403 sentence as an origin mismatch, the
> intra-group order stays unobservable and unpinned. If it is ever given its own
> distinct sentence, the intra-group order becomes observable and must be pinned at that
> point.** Naming that sentence is a **product-copy decision** and is **not taken here**.

**Session resolution is not authorization.** Verifying the CSRF token requires the
session to have been **resolved** — BR3.12 pairs the token 1:1 with it — and resolution
happens in the middleware. That does not conflict with step 1 preceding step 2: **step 2
is the owner authorization decision made behind the route**, and BR3.2 keeps resolution
and decision distinct.

## Authorization at the operation boundary

### BR3.1–BR3.2 — authorization at the operation boundary [BR3.1: FR3.8 + NFR2 · BR3.2: FR3.8]

> **Where NFR2 is realised, stated once.** This unit realises **NFR2 at `BR3.1`, and
> nowhere else**. The single statement of that is `BR3.1`'s `source: [FR3.8, NFR2]` in
> the yaml block above; this heading, the rules summary table, `traceability.json`'s
> `realises` array and `functional-spec.md`'s derived rules summary all **derive from
> it** and must agree with it. `BR3.2` is *not* a second NFR2 source — it forbids the
> structural enforcement that would undermine NFR2, which supports the requirement
> without discharging it. The **verification** half of NFR2 ("verified by tests that
> call the API directly, bypassing the frontend") is the test obligation in
> `functional-spec.md` § *Testing obligations*, which ADR-003 names as the condition of
> its own soundness.

- **BR3.1** Every protected read and every mutation authorises itself **at its own
  operation**, never by the route's placement, a protected layout, a hidden control
  or a frontend route rule. A request that bypasses the frontend entirely is
  rejected identically to one that does not.
- **BR3.2** `HttpApi` enforces nothing beyond transport concerns. The authorization
  decision belongs to the component behind the route.

#### Why this unit has an authorization rule that forbids it from authorizing

The pair reads as a contradiction and is not. **ADR-003** decided one `HttpApi`
carrying every route rather than a `PublicApi` / `OwnerApi` split, and it traded
*structural* assurance ("this route is in the protected module") for *behavioural*
assurance ("this operation checks for itself"). BR3.1 is that behavioural assurance and
BR3.2 is the prohibition that stops the structural one creeping back.

The concrete case ADR-003 rejected the split on is **this unit's hardest route**: the
media route is **public when its asset is referenced by published content and
owner-only otherwise** (BR7.4), so it belongs to both surfaces. The split fails exactly
where the protected/unprotected distinction is hardest, which is the one place it was
supposed to help.

**What makes the trade sound is the test discipline, not the rule.** ADR-003 says so
explicitly: NFR2 requires every protected operation to authorise itself, **and the test
suite calls the API directly with no session** — so a route accidentally left
unprotected fails a test rather than merely looking wrong in review. **If that test
discipline ever lapses, ADR-003 should be revisited.** That sentence is part of the
decision and is repeated here because this unit is where the lapse would happen.

## Same-origin and CSRF on every non-`GET`/`HEAD` method

### BR3.3–BR3.5 — same-origin and CSRF on every non-`GET`/`HEAD` method [FR6.7, D1]

> **One request set, defined once.** BR3.3 (origin), BR3.4 (CSRF) and BR3.5 (scope)
> apply to **exactly the same set of requests**, and **BR3.5 is the only place that set
> is defined**. Before the gate widening all three restated it independently as
> "mutations", which is how `POST /api/content/inspect` fell outside all of them. Do
> not reintroduce a per-rule scope.

- **BR3.3** Origin enforcement reproduces the source predicate: the
  request's `Origin` header must be **present** and **exactly equal** to the request
  URL's own origin. **A missing `Origin` header fails the check** — it is not treated
  as same-origin. This is the source's only CSRF defence.
- **BR3.4** The port **adds** a CSRF token (double-submit) paired with the session,
  on top of BR3.3 (D1). The origin check is not replaced by it, and it applies to
  **exactly the same request set** — so `POST /api/content/inspect` is **both**
  origin-checked and CSRF-checked, not one or the other.
- **BR3.5** In the source, origin is checked on **2 of 6** endpoint/method pairs —
  `PUT /api/content` and `POST /api/upload` only. **The port applies it to every method
  that is not `GET` or `HEAD`.** The test is the **method**, not whether the operation
  happens to write. It is never applied to `GET`/`HEAD`.

#### BR3.5 was widened at the gate — the "mutations" wording is withdrawn

The earlier wording scoped enforcement to **"mutations, the same set plus the new
authentication mutations"**, and that defined the set **two ways that disagreed**:

- **Extensionally** — the source pairs plus the authentication mutations. This
  **excludes** `POST /api/content/inspect`, because that route did not exist in the
  source.
- **Intensionally** — *"IF the method mutates."* This **does not classify**
  `POST /api/content/inspect` either: it is a `POST` that **writes nothing**. Not a
  `GET`, so the never-branch does not reach it; not a mutation, so the mutates-branch
  does not either.

**A rule with a hole in it is the defect, independently of which answer is right.** The
hole is now closed by keeping the intensional rule alone and keying it on the
**method**. Three reasons:

1. **BR3.3 already sets the fail-closed precedent** by treating an **absent** `Origin`
   as a failure. A sibling rule in the same group reading **fail-open** for an
   unclassified case would be the inconsistency, not the fix.
2. **It costs nothing.** Every non-`GET`/`HEAD` route on this surface is owner-only and
   same-origin by construction, so **no legitimate caller is affected**. The only thing
   enforcement changes is what happens to a request that had no business being made.
3. **Closing holes in this group is what `BR3.x` is for.** BR3.1 exists because
   structural assurance leaves gaps; leaving one in BR3.5 would undo that.

**Ordering: origin first, before any payload is read or measured.** Authorization
precedes payload processing — a request from a disallowed origin must **not** cause the
server to read and measure a body. That is already **step 1 ahead of step 3** in
BR10.10 for `PUT /api/content`, and it is the same ordering on
`POST /api/content/inspect`, where it decides **403 rather than 413** for a request that
is **both** bad-origin **and** oversize. The ordering is observable, so it is pinned
rather than left to the implementer.

#### The missing-header branch is the whole rule

"Present **and** exactly equal" has three outcomes, not two, and the third is the one a
permissive implementation gets wrong:

| `Origin` header | Result |
|---|---|
| Present and exactly equal to the request URL's origin | **pass** |
| Present and different | **403** |
| **Absent** | **403 — it is NOT treated as same-origin** |

A reading that treats an absent header as "no cross-origin claim, therefore fine"
removes the source's only CSRF defence, and it removes it **silently**: every browser
request from the site itself carries an `Origin` on a mutation, so the site keeps
working perfectly and only a hand-crafted request notices.

BR3.4 **adds** the double-submit token; it does **not** replace this check. The two
defences are independent and both apply.

**Never on `GET`/`HEAD`** (BR3.5). Applying origin enforcement to reads would break the
public content read and the public media path for any cross-origin reader — and the
media path's public branch is meant to cost no authorization work at all (BR7.6).

#### The one enumerated exception — the one-shot owner-provisioning route

**Exactly one route is exempt from BR3.3 and BR3.4, it is named, and the list is
exhaustive**: the **one-shot owner-provisioning route**. There is no second exception
and no *category* of exception.

**Why — the origin check defends against ambient authority, and this route has none to
borrow.** CSRF is possible only when a browser will attach credentials **the attacker
does not possess** — a session cookie — to a request the attacker causes. This route is
gated on **`ADMIN_BOOTSTRAP_SECRET`, which the caller must supply explicitly in the
request**, and which **no browser will ever attach on a third party's behalf**. An
attacker's page cannot make a victim's browser send a secret the browser does not hold.
**So on this route the origin check protects nothing, while breaking the only caller the
route exists for.** That is a property of the route's **authentication model**, not an
exemption granted for tooling convenience.

**BR3.4 cannot apply either, and not merely by the same argument.** The CSRF token is
paired **1:1 with a session** (BR3.12). During bootstrap **no session exists** — nobody
is signed in and no owner row exists yet — so there is **no token to pair with or
verify**. The rule is not waived here; it is inapplicable.

**The compensating controls, which are what make this safe:**

1. **`ADMIN_BOOTSTRAP_SECRET` must be set *and* supplied in the request.** With the
   secret unset and no owner, the service **starts and refuses every sign-in** rather
   than creating an account.
2. **The route is enabled only while no owner record exists**, and **the gate is the
   record's existence, not a consumed flag** — so restarting the container **cannot
   reopen it**.

**If either control ever changes, the carve-out must be re-argued, not carried
forward.** It is safe *because* those hold, not because it is written down here.

**The stricter-looking option was considered and rejected: requiring the operator to
send a matching `Origin` from `curl` is security theatre.** `Origin` is trustworthy
**only because browsers set it** and refuse to let script forge it. A **non-browser
caller sets whatever it likes**, so the header proves **nothing** about a `curl`
request — and an attacker who can reach the endpoint can set it exactly as easily as the
operator can. It would add a step to the runbook and **zero security**. This is recorded
because it is the option that *looks* responsible, and it is the one the next reader will
reach for first.

**This is an enumerated exception, not a softening of the test.** BR3.5's `logic` stays
**single-branch on the method**, and the exception names **one route** rather than
describing a property other routes could later acquire. **One named exception carrying a
stated reason is not a hole; an unclassified branch is** — which is precisely the defect
the gate widening closed.

## Unit-scoped rules — BR26.x

Four rules this unit owns that **trace to no FR**. They are allocated in the
unit-scoped group `BR26.x` (**U6 + 20**) and recorded in the traceability `reverse`
array rather than in `coverage`. Two realise an NFR (BR26.1, BR26.3); one is the
**local closure of a gap that is open at workflow level** (BR26.2); one implements a
**decision the site owner made at the functional-design gate** (BR26.4).

### BR26.1 — boundary enforcement is a command, not an assertion [NFR1]

- **BR26.1** Three checks run at the merge gate and each **fails** it:
  1. a **grep** over `chiku-website/frontend` that must find **no** `'use server'`
     directive, **no** `app/**/route.ts` and **no** `middleware.ts`;
  2. **one pytest that walks the AST** of every module under `routers/` and asserts
     none of them imports a `store` module or `sqlite3`;
  3. a **regeneration** of the committed `openapi-typescript` output, failing the gate
     **if the result is dirty**.

**A rule nobody can check is a wish.** NFR1 states the language boundary; these three
commands are what make it enforced rather than asserted. Check 3 is the one that does
the most work: it makes the boundary **type-checked** rather than asserted, because a
backend field rename then fails `tsc --noEmit` **with a file and a line** instead of
surfacing as a browser-side 422 three Bolts later.

Check 1 is a grep rather than an ESLint rule deliberately — an ESLint
`no-restricted-syntax` rule is a nicer editor experience, **but the grep is the one
that is certain**.

**Why it has no FR.** NFR1 states the boundary; **no FR states that it must be
machine-checked**. The obligation is `team.md` § Testing Posture — *"Boundary
enforcement is a command, not an assertion"* — and this unit owns the two checks on the
backend side of it.

### BR26.2 — 499 is mapped explicitly and must not fall through to 503

> **This rule is the *local* closure of a *workflow-level* gap.** The gap is in
> `construction/functional-design/rules.md` § BR10.4, it is **open there**, and it is
> being fixed separately. BR26.2 closes it **for `u6-http-api` only**. Any other
> reading of the workflow-level BR10.4 — another unit, a later stage, a developer
> working from that file — still sends a cancelled upload to 503. Do **not** delete
> this rule on the grounds that BR10.4 "obviously" means to allow 499: it does not.

- **BR26.2** **499 sits outside the four-member taxonomy** (BR10.4) and is mapped
  **explicitly**. A cancellation signalled by `u5-media` must never reach the BR10.5
  catch-all. It still carries the one envelope (BR10.1) — "exactly one envelope for the
  whole surface" admits no exception.

**This is a real gap in BR10.4, not a nuance.** BR10.4 enumerates exactly four members
plus `anything else → 503`. **499 is none of the four.** A literal implementation of
BR10.4 therefore sends every cancelled upload to **503 with
`Upload failed. Please try again; your form changes are safe.`** instead of **499 with
`Upload cancelled. Your previous file is unchanged.`** — a different status and a
different sentence, both under the parity rule, and both silently wrong because a
cancelled upload *did* fail from the server's point of view.

`contract-summary.md` § C1 lists **499** on `POST /api/upload`, and BR10.7 lists its
sentence. So the contract requires it even though no requirement sentence does.

**Why it has no FR.** FR6.6 covers cancellation and is assigned to **U5**; BR10.4 —
this unit's own taxonomy rule — does not contain 499. The obligation falls **exactly in
the gap between them**, which is how it would be lost.

### BR26.3 — the OpenAPI document is generated, never hand-maintained [NFR1]

- **BR26.3** The OpenAPI document is **generated from the Pydantic models**, never
  hand-maintained, and `U7 api-client`'s TypeScript types are generated **from it** and
  committed.

A hand-maintained document is a **second definition** that drifts from the
authoritative one — which is exactly why `contract-summary.md` § C1 omits field-level
schemas rather than restating them. A hand-written TypeScript mirror of a backend model
is **forbidden outright** by `project.md` § Forbidden, and generating the mirror is what
makes drift impossible by construction.

**Why it has no FR.** FR8.9 requires the **client** mirror to be generated and is
assigned to **U7**. The obligation on the **provider** — that the document the client
generates from is itself generated — is stated only in `contract-summary.md`
§ *Contract ownership rules* and in `project.md` § Forbidden.

### BR26.4 — the `POST /api/content/inspect` body cap is **6,000,000** characters

- **BR26.4** `POST /api/content/inspect` rejects a request body over **6,000,000
  characters** of decoded text with **413** and the envelope, carrying
  `This draft is too large to check.` The cap counts **characters, not bytes**, and is
  checked **after the body is fully read and before JSON parsing** — the same quantity
  and the same position as the save cap (BR4.20, BR4.22), and a **different number**.

#### Three numbers, three jobs — do not collapse them

| Bound | Value | What it decides | Moves with |
|---|---|---|---|
| **Draft recovery** | **6,000,000** characters (`editor-workflow.ts:15`) | What the editor will parse out of local storage and **offer** the owner to restore | The editor |
| **Inspect cap (BR26.4)** | **6,000,000** characters | What `POST /api/content/inspect` will **classify** | **The recovery bound, by derivation** |
| **Save cap (BR4.20)** | **1,500,000** characters (`route.ts:11`) | What `PUT /api/content` will **accept** | FR4.6 only |

**The site owner decided this at the functional-design gate**, choosing between three
costed options recorded in `WORKING-RECORD.md`:

1. **Preserve both bounds silently** — a 413 loop and **silent work loss**.
2. **Lower the recovery bound** to the save cap — a behaviour change.
3. **Preserve both bounds and warn** — new copy, which is itself a parity change.

**The owner chose option 3.** So the window between 1,500,001 and 6,000,000 characters
persists **by decision**, not by oversight, and the warning is what stops it losing work
silently. Neither bound was lowered.

#### Why the inspect cap is the recovery bound and not the save cap

`/api/content/inspect` classifies a **recovered** draft — that is its entire job
(ADR-006 moved the rule out of the browser; `BR8.1`, owned by `u4-content-core`, is the
classification itself). So the only bodies it ever legitimately receives are drafts the
editor has already decided it can recover.

**If this cap were the save cap, a draft in the window would be recoverable but
unclassifiable.** The owner would be offered a restore for a draft the system then
refuses to even look at: the editor asks "restore this?", the owner says yes, and the
classification call comes back 413. That is strictly worse than the decided behaviour,
because it removes the one step that tells the owner *what is wrong with the draft*
before they discover they cannot save it.

**A draft that is recoverable must always be inspectable.** That invariant, not the
number, is the rule. The number is 6,000,000 today because the recovery bound is
6,000,000; **if the recovery bound ever moves, this cap moves with it**, and the save
cap does not.

The decided flow for a draft in the window is therefore: **recovered → offered →
inspected → classified → and only then refused by `PUT /api/content` with 413 and the
warning.** The refusal is the last step, it is visible, and it is not silent.

#### Why a distinct sentence rather than `This update is too large.`

`This update is too large.` is **not** reused here, and the difference is deliberate.

1. **It is ported product copy bound to a different number.** It is the `PUT
   /api/content` 413 sentence at **1,500,000** characters, carried verbatim under the
   parity rule (BR10.7). Emitting the same sentence at **6,000,000** on another route
   makes one string mean two bounds — which is exactly the ambiguity that invites a
   later reader to "simplify" the two caps into one.
2. **It is factually wrong on this route.** Nothing is being updated: `inspect` saves
   nothing and writes nothing. An owner reading "this update is too large" would
   reasonably start cutting content to get under the save cap, which is not the problem
   they have.
3. **This route is new, so no parity target is being spent.** `POST
   /api/content/inspect` does not exist in `madhavi-tripathi/` — the classification ran
   in the browser (ADR-006) — so, like `GET /api/public/content`, it has **no parity
   fixture and no source string to preserve**. Reusing the ported literal would buy no
   parity; new copy on a new route is not a rewritten sentence.

`This draft is too large to check.` is therefore **new copy**, recorded as new. It is
**not** in the BR10.7 verbatim set, which is the *ported* set, and a parity diff must
not expect to find it there.

#### The cap is a boundary defence, not a flow the owner meets

Because the cap **equals** the recovery bound, the editor cannot legitimately produce a
body that breaches it: `parseRecovery` never offers a record above 6,000,000. So in
normal use this 413 is **unreachable**. It exists because `inspect` is otherwise this
unit's one body-bearing route with **no cap at all**, and an uncapped route is a body
the process reads in full before anything rejects it. Reaching it means a hand-crafted
request or a bug — which is precisely when you want a bounded read and an honest
sentence rather than a 503.

**Why it has no FR.** FR4.6 states the 1,500,000-character cap for a **save** request
only. FR8.3 states recovered-draft classification and is assigned to **U4**; this rule
**enables** that classification for every recoverable draft without **discharging** it.
No requirement sentence and no NFR states an inspect cap — it is a gate decision, which
is why it sits in `BR26.x` and in the `reverse` array.

---

## Assumptions & Open Questions

- **[open at workflow level — owner: `construction/functional-design/rules.md` § BR10.4,
  being fixed separately; closed locally here]** **BR10.4 does not account for 499.**
  The four-member taxonomy plus a 503 catch-all is exhaustive as written, and a
  cancellation is neither a member nor an "anything else" that should become 503. A
  literal implementation therefore returns **503 + `Upload failed. Please try again;
  your form changes are safe.`** where the contract requires **499 + `Upload cancelled.
  Your previous file is unchanged.`** — different status, different sentence, both
  under the parity rule. **`BR26.2` is the local closure for this unit and is sound as
  written**: it maps 499 explicitly, forbids the fall-through to the BR10.5 catch-all,
  and keeps the single envelope. What it does **not** do is fix the workflow-level
  rule, so the gap reappears in any other reading of that file. Recorded rather than
  silently patched, and `BR26.2`'s own `note` says so in the source-of-truth block so a
  reader of the yaml alone learns it.
- **[open — owner: `contract-design`. A deliberate downstream statement, not a silent
  divergence]** **`contract-summary.md` § C1 states no request-body cap for
  `POST /api/content/inspect`**: that path lists **200 / 400 / 403** only. `BR26.4`
  adds a **413**. The cap is a decision the **site owner made at the functional-design
  gate**, which is *after* `contract-design` was approved, so C1 is not wrong — it is
  **out of date**. **C1 is an upstream inception artifact owned by `contract-design`
  and is not edited from here.** `contract-design` owns adding `"413"` to
  `/api/content/inspect` with the cap and its sentence.
  **This will surface as a failing check, and that is the intended signal.** `team.md`
  § *Testing Posture* mandates the non-circular API contract test — assert the
  **generated** OpenAPI document against the **hand-written** contract — and the
  generated document will carry a 413 the hand-written contract does not. **Read that
  failure as "the contract needs the cap added", not as "the backend is wrong", and do
  not resolve it by deleting the 413.**
- **[closed at the functional-design gate]** **BR3.5's enforced set was widened and its
  extensional wording withdrawn.** It previously defined the set two ways that
  disagreed on `POST /api/content/inspect` — a `POST` that writes nothing. It is now
  keyed on the **method**: every method that is not `GET` or `HEAD`. **BR3.3 and BR3.4
  were brought into line in the same pass**, because both restated the scope as
  "mutations" independently and BR3.4 would otherwise have left `inspect`
  origin-checked but **not** CSRF-checked — the same hole one rule over. All three now
  defer to BR3.5's single definition. The check ordering is pinned: **origin (403)
  before size (413)**, because authorization precedes payload processing.
- **[open, NEW — a consequence of that widening. Surfaced here, not resolved here.
  Owner: `contract-design` for the route's contract, this unit at `code-generation`
  for the behaviour]** **The one-shot owner-provisioning route is a `POST`, so widened
  BR3.5 now applies origin enforcement to it — and its documented caller sends no
  `Origin`.** That route exists for a container with no interactive shell, so the
  realistic caller is `curl`, which sends no `Origin` by default; BR3.3 treats an
  absent `Origin` as a failure. As specified, the route therefore **403s the only
  caller it exists for**, and a container cannot be provisioned. The CLI path is
  unaffected, so no default credential is reintroduced and FR3.7's acceptance test
  still holds. Needs a decision — an explicit justified carve-out, or a documented
  requirement that the caller send a matching `Origin`. **Do not resolve it by
  re-narrowing BR3.5**, which would restore the branch the widening closed.
- **[open — owner: U1 `source-fixtures` to measure; this unit to adjust if it is
  wrong]** **Whether 6,000,000 is measured on the same quantity at both ends.** The
  recovery bound is applied by `parseRecovery` to the stored **record**
  (`editor-workflow.ts:15`); `BR26.4` applies its cap to the **decoded request body**
  of `POST /api/content/inspect`. If the request body wraps the draft in an envelope,
  the body is longer than the record and a draft **at** the bound could be refused —
  the one outcome the rule exists to prevent. The two are believed to differ only by
  wrapper overhead in the safe direction (the record contains the document, not the
  reverse), **but this is not confirmed and is not assumed settled.** The invariant
  governs the number: the cap must be **at least** the largest body the editor can
  produce from a record the recovery bound admits. Settle it against the recorded U1
  fixtures before the cap ships.
- **[assumption, this unit]** **FR10.2** (error strings are product copy) is assigned to
  **U8 `public-site`** by `inception/units-generation/traceability.json`, while
  **BR10.7–BR10.9** — the rules that discharge it — are assigned to **`HttpApi`** by
  `construction/functional-design/rules.md` § *Rule index*. The strings are **emitted by
  this unit**: every one of the 21 is an `ErrorEnvelope.error` value produced by this
  unit's exception handlers, and U8 renders none of them. They are carried here for that
  reason, and BR10.7–BR10.9 appear in the traceability `reverse` array rather than in
  `coverage`. **The assignment is not changed here** — that belongs to whoever owns the
  units-generation artifact — but it is flagged rather than quietly reconciled.
- **[assumption, this unit]** The same split applies twice more, in the same direction —
  rules owned by `HttpApi`, requirements assigned elsewhere:
  **BR10.10–BR10.12** discharge **FR4.7**, which is assigned to **U4**; and
  **BR3.3–BR3.5** discharge **FR6.7**, which is assigned to **U5**. In both cases the
  enforcement is unambiguously at this unit's operation boundary — the check order is a
  property of the route, and origin/CSRF are middleware — while the requirement was
  assigned to the unit that owns the *subject* of the operation. Both sets are carried
  here and both appear in `reverse`.
- **[assumption, this unit]** **NFR1 and NFR2** are listed as this unit's upstream
  requirements. They are **not** present in
  `inception/units-generation/traceability.json`, which enumerates no NFRs at all, but
  `inception/units-generation/unit-of-work.md` § *U6 — http-api* states
  **"Realises. FR3.8, FR10, NFR1, NFR2."** Recorded because it is an addition to the
  upstream id set rather than a reading of it.
  **Both are now realised by a named rule, stated in one place.** **NFR1** at `BR26.1`
  and `BR26.3`; **NFR2** at `BR3.1`, and at no other rule. That single statement is the
  `source` field of those rules in the yaml block above (`nfr_realisation_note` says
  so); the prose heading, the rules summary table, `traceability.json`'s `realises`
  array and `functional-spec.md`'s derived summary all **derive from it**. Before this
  revision the four locations disagreed — the prose heading tagged BR3.1–BR3.2 with
  NFR2 while the governing block cited only FR3.8 and `realises` listed only NFR1 — so
  a mechanical reader trusting the block, as the document instructs, would have
  concluded this unit realises NFR2 nowhere. That is review finding **R-01** and this
  is its resolution.
- **[note]** **BR4.20's placement.** The 1,500,000-character cap is owned by
  `ContentAuthority` (it owns "the request-size limit and its unit" per `components.md`)
  while the check is necessarily applied where the decoded body first exists, which is
  inside this unit's request handling. That is a placement of **enforcement**, not of
  **ownership**, and **BR4.22** fixes the ordering so the two cannot drift.
- **[note]** This unit **holds no state and touches no store**. The AST test in BR26.1
  is what makes that checkable rather than asserted. It is also why this unit's
  `entities.md` specifies wire contracts rather than persisted entities.
- **[note]** No rule here requires a background worker, scheduler or queue consumer.

## Sources

- `construction/functional-design/rules.md` — **the authoritative text of every
  `BR10.x` and `BR3.x` rule above**, carried verbatim from § `HttpApi`: BR10.1–BR10.6,
  BR10.7–BR10.9 (including the full 21-row copy table, the U+2019 note and the four
  retired strings), BR10.10–BR10.12, BR3.1–BR3.2, BR3.3–BR3.5. Ids, wording, emphasis
  and the "What breaks silently" note are reproduced without change; the tables and
  commentary added here are restatements and are subordinate to that text.
- `construction/functional-design/rules.md` § *Assumptions & Open Questions* — the
  carried hedges on the two elided strings and on the two cancellation literals.
- `aidlc/spaces/default/codekb/Chiku_website/api-documentation.md` §§ *Shared shape*,
  *`GET`/`PUT /api/content`*, *`GET /api/history`*, *`POST /api/upload`*, *`GET` and
  *`HEAD /api/media/[key]`*.
- `inception/requirements-analysis/requirements.md` — FR3.8, FR4.7, FR6.7,
  FR10.1–FR10.3, NFR1, NFR2.
- `inception/domain-design/components.md` § `HttpApi`;
  `inception/domain-design/decisions.md` **ADR-003** (one `HttpApi`, not a public/owner
  split — including its security-and-compliance paragraph and the condition under which
  it should be revisited).
- `inception/contract-design/contract-summary.md` § C1 (statuses, envelope, the 499 on
  `POST /api/upload`, and `POST /api/content/inspect`'s **200 / 400 / 403 with no body
  cap** — the gap `BR26.4` records) and § *Contract ownership rules*.
- **`BR26.4`, the inspect body cap** — `inception/reverse-engineering/developer-scan.md`
  § *J. The recovery size cap exceeds the server's body cap* (the two numbers and their
  file/line origins: `parseRecovery` at **6,000,000**, `editor-workflow.ts:15`; the
  `PUT /api/content` cap at **1,500,000**, `route.ts:11`); `WORKING-RECORD.md`
  §§ *Latent defect* and *Decisions the human owned at the gate* item 3 (the three
  costed options, and the recommendation to preserve both bounds and warn);
  `construction/functional-design/rules.md` § BR4.20–BR4.22 (the save cap's number, its
  character-not-byte unit and its position in the check order, all of which `BR26.4`
  reproduces with a different number); `inception/domain-design/decisions.md` **ADR-006**
  (the classification is a backend rule reached through `POST /api/content/inspect`,
  which is why the route is new and carries no ported copy).
  **The 6,000,000 value itself is the site owner's decision at the functional-design
  gate**, not a reading of any of the above.
- `inception/units-generation/unit-of-work.md` § *U6 — http-api* —
  `Realises: FR3.8, FR10, NFR1, NFR2`, and the gate grep / AST test constraint.
- `aidlc/spaces/default/memory/team.md` §§ *Code Style* → *Python* (the error-envelope
  paragraph naming this the highest-probability silent regression; `async` by default;
  "a layer exists only when it has a job"), *Testing Posture* ("Boundary enforcement is
  a command, not an assertion"); `aidlc/spaces/default/memory/project.md` § *Forbidden*
  (no hand-written TypeScript mirror of a backend model).
- `WORKING-RECORD.md` §§ 3 (hazard FR10.1), 5 (the error envelope and the frozen wire
  format), 6 (the merge gate, including the grep and the dirty-regeneration check).
