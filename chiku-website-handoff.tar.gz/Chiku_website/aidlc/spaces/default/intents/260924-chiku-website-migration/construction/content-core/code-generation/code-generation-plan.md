# Code Generation Plan — U4 `content-core`

## Unit scope

**Every content operation, and the seed content.** This unit owns the one document every
other unit reads and none may write.

| Component | Owns |
|---|---|
| `ContentAuthority` | The document in draft and published form, the authoritative 31-field schema, draft-save and publish, the concurrency guard and its side-effect guard, the request-size limit, the published-document cache, and the inspect operation behind draft recovery |
| `RevisionLedger` | The revision listing order and the retention policy — **and performs no write** |

**Three of the system's seven hazards live here, and this unit raises into a fourth.**
Each carries a test per enumerated branch under the **100% scoped coverage floor**:

| Hazard | Requirement | Owned here |
|---|---|---|
| The combined write and its ABA side-effect guard | FR4.5 | **yes** |
| Recoverable versus corrupting classification | FR8.3 | **yes** |
| The content-carrying defaults | FR9.2 | **yes** |
| The error envelope | FR10.1 | **no — U6 renders; this unit raises** |

This unit **raises and never composes a response**: no status code, no sentence, no
envelope is built here. It reaches persistence only through `ContentStore`, which
validates nothing and defaults nothing — **everything the schema does happens here.**

## Module layout

```
app/content/schema.py        the 31-field Pydantic model tree, every cap, every default
app/content/defaults.py      the content-carrying defaults    [HAZARD — FR9.2]
app/content/seed.py          the seeded document (5 publications, 3 research cards, ...)
app/content/authority.py     read, save/publish, the nine-step order, the cache
app/content/statements.py    the pure statement builder      [HAZARD — FR4.5]
app/content/recovery.py      recoverable vs corrupting        [HAZARD — FR8.3]
app/content/ledger.py        RevisionLedger: listing order + retention policy, read-only
app/content/cache.py         the single-entry published-document cache
```

`app/content/limits.py` already exists and already holds the UTF-16 cap; it is reused,
not replaced.

**The pure-versus-execute split survives the port** (`statements.py` builds, the store
executes). That factoring is what makes the concurrency batch inspectable; flattening it
loses the property.

## Ordering — the contract's `custom` methodology

The characterization tests for this unit's **hazard-register behaviours** are written and
observed to fail before the implementation of that behaviour exists. Three hazards are
owned here, so **Steps 4 and 6 are Red steps** and are not to be merged with the
implementation steps that follow them. Everything else is tested immediately after the
code it covers.

Where a recorded fixture exists it is the oracle, not a reading of the source: `F2`, `F3`,
`F4`, `F5`, `F6` and `F12` in `chiku-website/fixtures/` pin the read shape, the write
path, the 409 envelope, the size boundary and the `400 + issues[]` shape.

## Steps

- [x] **Step 1 — Verify the test runner and record the exact unit-scoped command.**
      `uv run pytest --version` must succeed. Record the unit-scoped command in
      `unit-test-instructions.md`.

- [x] **Step 2 — The schema and the seed.** All 31 top-level fields with every cap and
      every default transcribed from `entities.md` § ENT-4 and its cap census — **not from
      the source file, and not from memory.** `photoFocalY` defaults to **35, not 50**;
      `entities.md` names it the single most transcription-error-prone default in the
      schema. The seed is reproduced from `entities.md`, which records it as data rather
      than schema. One shared Pydantic base with `alias_generator=to_camel` and
      `populate_by_name=True` is the **single** conversion point: no `camelCase`
      identifier in Python, no `snake_case` key on the wire.

- [x] **Step 3 — Tests for the schema and the seed**, written immediately after Step 2
      per the contract's ordering. Every cap asserted at its boundary, both sides. The
      seed asserted against `F2`/`F3` recorded fixtures, which is what makes it evidence
      rather than a transcription anyone can re-mistype.

- [x] **Step 4 — HAZARD tests, written and observed to FAIL.** Three groups, one per
      hazard owned here, each with a test per enumerated branch:
      - **The content-carrying defaults (BR9.1–BR9.3).** An absent research topic
        resolves through the id map and otherwise to `general`; absent research links
        resolve through the seeded map; **an explicitly emptied list stays empty.** This
        runs on the **read path, every time** — it is not a write-path default, and a port
        that materialises it on write produces values the owner never entered.
      - **The combined write and its ABA guard (BR4.8–BR4.19).** The `mutation_token`
        guards the *side effects* and is **not** redundant with the revision CAS: a losing
        writer's `next_revision` collides with the winner's `revision`, and without the
        token it records a phantom history entry carrying the winner's content and runs a
        prune it was never entitled to run (BR4.13). The history entry's content is read
        back from the **stored `draft`**, not from the request (BR4.11). The CAS result is
        read **by name, never by position** (BR4.17).
      - **Recoverable versus corrupting (BR8.1–BR8.8).** Recoverable is what an owner
        produces by typing — present, correctly typed, outside its permitted set or range,
        **including a value outside an enumerated set.** Corrupting is a malformed record.
        Run them; paste the failing output.

- [x] **Step 5 — The three hazard implementations, to Green.** `defaults.py`,
      `statements.py` + the write path, and `recovery.py`.
      **`recovery.py` implements the rule as written, not as the source behaves** (D9,
      BR8.4): the source allowlists four issue codes, one of which can never match because
      it belongs to a different major version of the validator, and omits the one that
      fires for a bad enum — so one bad enum discards the owner's entire recovered draft
      while the source's own comment states the opposite intent. **The classification is
      re-expressed in the new validator's taxonomy, never by copying code strings**
      (BR8.5).

- [x] **Step 6 — The cache: a SECURITY parameter, tested as one.** One entry, no key. A
      successful publish invalidates it **synchronously, before the operation returns**
      (BR24.2). Its interval has a **stated maximum of 5 seconds** (BR24.1) — a deployment
      may choose lower, never higher. It is a security parameter because the cache feeds
      the asset-visibility test: an asset is public **iff its literal media URL appears in
      the serialised published document**, so a stale entry means **an asset the owner has
      just unreferenced stays public** — an authorization defect, not a slow page. Tests
      assert the maximum is enforced and that publish invalidates before returning.
      **No draft content may appear in any public response, in any field, at any time**
      (BR24.3, realising NFR11). The public read route **does not exist in the source** —
      verified by execution, it returns 404 there — so it has **no parity fixture** and
      this prohibition is checked by a test of its own.

- [x] **Step 7 — The remaining operations and their tests.** Owner read (parse both
      documents through the schema; compute `hasUnpublishedChanges` by comparison, never
      from storage; **a read never writes, never locks and never bootstraps**); the
      listing (`revision` DESC, `baseline` ASC, `action` DESC, capped at **52** — which is
      `30 + 20 + 2` by construction and **not a page size**); fetch-one (**validate the id
      first** — absent means list, present-but-empty or over 100 characters or failing the
      pattern is **invalid**, and that absent-versus-empty distinction is a real branch);
      and retention (30 drafts and 20 publishes kept **independently**; the two baselines
      excluded **by the delete predicate**, not by sorting high). **Restoring never
      publishes** (BR5.6). `RevisionLedger` supplies the numbers and performs no write.

- [x] **Step 8 — Coverage, documentation and traceability.** The 80% branch floor over
      `chiku-website/backend/`, and **100% branch** on the three hazard modules
      (`app/content/defaults.py`, `app/content/statements.py`, `app/content/recovery.py`)
      alongside the existing four. Neither floor relaxed. Then `code-summary.md`,
      `source-manifest.json`, `traceability.json`.

## Test files this plan produces

- `tests/content/test_schema.py` — the 31 fields, every cap at its boundary, the seed
  against the recorded fixtures.
- `tests/content/test_defaults.py` — **hazard**, one test per enumerated branch of
  BR9.1–BR9.3, including the explicitly-emptied-list case that a naive default breaks.
- `tests/content/test_write_path.py` — **hazard**, the six effects and their guards, the
  ABA collision, the read-back of stored content, the by-name CAS read, the nine-step
  order, and the 409 envelope against `F5-conflict-stale-revision`.
- `tests/content/test_recovery.py` — **hazard**, recoverable versus corrupting per branch,
  including the bad-enum case the source gets wrong.
- `tests/content/test_cache.py` — synchronous invalidation, the 5-second maximum, and the
  no-draft-in-public-response prohibition.
- `tests/content/test_ledger.py` — listing order including a tied revision, the 52 cap,
  independent retention, baseline survival, id validation branches, restore-never-publishes.

Standard strategy: 5–8 tests per component across seven components, plus a test per
enumerated branch on the three hazard modules, which is additive.

## The size cap is already settled by evidence

`BR4.20` says the cap counts **characters**; the recorded fixtures prove it counts
**UTF-16 code units** — `F6-size-astral-under-in-units` is accepted at 1,399,999 units
though it is 2,783,472 UTF-8 bytes, and `F6-size-astral-over-in-units` is rejected at
1,599,999 units from only 808,278 codepoints. A byte cap rejects the first; a codepoint
cap accepts the second. `app/content/limits.py` already implements
`len(text.encode("utf-16-le")) // 2` and is reused unchanged. The check runs **after the
body is fully read and before the parse** (BR4.22) — its position is part of the rule,
because moving it changes which status a too-large malformed body gets.

## What this unit deliberately does not do

- **Composes no HTTP response.** No status, no sentence, no envelope. It raises the four
  taxonomy members and U6 renders them.
- **Writes nothing on a read path**, and does not bootstrap (BR4.1).
- **Stores no `hasUnpublishedChanges`** — computed on every read (BR4.2).
- **Runs no background worker, scheduler or queue consumer.** Retention happens inside
  the write.
- **Does not "fix" the retention tie-break.** The survivor ordering is `revision` DESC
  alone and is not tiebreak-stable; that indeterminacy is inherited (BR4.19).
- **Does not let a failed inspect read as "discard it."** An unreachable inspect is a
  third state the editor owns (BR8.7); this unit's transport failure must be
  distinguishable from a corrupting verdict.

## Traceability — plan step to rule

| Step | Realises |
|---|---|
| 2 | BR9.1, BR25.1, the ENT-4 field set |
| 4–5 | BR4.8–BR4.19, BR8.1–BR8.8, BR9.1–BR9.3 |
| 6 | BR24.1, BR24.2, BR24.3 |
| 7 | BR4.1, BR4.2, BR4.6, BR4.7, BR5.1–BR5.10 |
| 8 | NFR10 |

BR4.20–BR4.22 are realised by the reused `app/content/limits.py` plus the step-3 position
check. BR10.x, BR3.x and BR22.x are enforced here but **declared** in U6, U3 and U2.
## Testing Contract

```json
{
  "version": 1,
  "methodology": "custom",
  "source": "team",
  "ordering": "Within each unit, the characterization tests for that unit's hazard-register",
  "scope": "runtime-split-migration",
  "test_strategy": "standard",
  "project_type": "brownfield",
  "applicable_notes": [
    {
      "layer": "org",
      "text": "We treat tests as a first-class deliverable in every Bolt. The specific\nmethodology (TDD, BDD, ATDD, or classic test-after) is affirmed at\npractices-discovery and recorded in `team.md` under this heading with explicit\n`Methodology` and `Ordering` fields; Code Generation resolves those fields\nindependently from coverage, tooling, and scope notes.\n\nWhen no posture has been affirmed, our default per scope is:\n- **Methodology**: test-after\n- **Ordering**: implement each applicable testable layer, then write and run\n  that layer's tests.\n- `mvp`, `enterprise`, `feature`, `infra`, `classic` add an 80% line-coverage\n  floor and CI execution before merge.\n- `bugfix`, `security-patch` add a targeted regression for the specific\n  bug/vulnerability and require the existing suite to remain green.\n- `express` uses the Minimal strategy: requirement-driven unit tests (one per\n  requirement, with a happy-path floor per component); existing tests remain\n  green.\n- `poc`, `refactor`, `workshop` add no extra new-test floor and require the\n  existing suite to remain green.\n\nThe active `Test Strategy` still applies in every scope and determines test\nvolume/types. Scope floors are additive; they never reduce or replace the\nselected strategy.\n\nBuild and Test verifies defined coverage floors and affirmed quality targets;\nthey may not be weakened to make a step pass.\n\nAffirm a stricter posture in `team.md` if the team commits to one."
    },
    {
      "layer": "team",
      "text": "> **Read this section as a proposal we have adopted, not as practice we observed.** The source\n> project contains zero test files, zero testing dependencies and no `test` script, so there was no\n> prior testing practice to discover — every item below was chosen at the practices-discovery gate\n> on 2026-09-24 and affirmed by the site owner, rather than read off how this team already works.\n\n- **Methodology**: custom\n- **Ordering**: Within each unit, the characterization tests for that unit's hazard-register\n  behaviours and for the storage port are written and observed to fail before the Python\n  implementation of that behaviour exists; every other backend test is written immediately after\n  the code it covers; that unit's frontend render layer is ported only once its backend tests\n  pass; a unit with no backend surface begins at the frontend step; and a unit whose behaviour is\n  not enumerated in the hazard register takes the recorded source fixtures as its oracle, falling\n  back to the reverse-engineering knowledge base where no fixture exists.\n- **What `custom` means, and why it is not `test-after`.** Under test-after, a developer who\n  misreads a dense source line implements from the misreading and then writes the test from the\n  same misreading: the test is green, coverage is satisfied, and the defect ships. That is not\n  hypothetical here — a port declaring `research_topic: Topic | None = None` passes `ruff`,\n  `mypy --strict`, `tsc`, the Compose end-to-end flow and 100% line coverage while rendering three\n  identical research cards and returning zero publications for every topic filter. Only a test\n  whose assertion came from the *source* behaviour catches it. `tdd` everywhere is equally wrong:\n  most of the ported render layer has no enumerated oracle, and writing failing render assertions\n  first for ported JSX is waste. Note this is **characterization** testing, not TDD — the test is\n  written from the recorded behaviour of the source, which is why the fixtures below matter.\n- **Recorded source-behaviour fixtures come first, before any Python is written.** Drive the\n  running `madhavi-tripathi/` app over HTTP with `httpx` once and record as golden fixtures: every\n  public route's rendered HTML, `GET /api/content`, the media route's status codes across public /\n  draft-only / missing keys, the 413 boundary in both characters and UTF-8 bytes, byte-range\n  responses across all six rejection branches, and the stored-row state after a save / publish /\n  conflict sequence. It uses a disposable local database and a test identity; nothing hosted is\n  touched. Until these exist, every parity assertion in this project rests on a human's reading of\n  a document; after they exist, they assert against the system. **This capability expires when the\n  source app is retired** — a fixture not recorded before then cannot be recovered.\n- **Coverage floor — backend**: **80% branch coverage** over `chiku-website/backend/`, measured by\n  `pytest --cov --cov-branch` and `coverage report --fail-under=80`, with generated migration\n  files and `__main__` entry points excluded. Branch, not line, is deliberate and costs one flag:\n  every high-risk behaviour in this port is a branch or a `??` fallback chain, and line coverage\n  marks those covered when only one side ever runs. This is a **new floor we are choosing**, not\n  an inherited one — `org.md`'s 80% floor is written for the named stock scopes (`mvp`,\n  `enterprise`, `feature`, `infra`, `classic`) and this workflow runs the custom scope\n  `runtime-split-migration`, which appears in none of them. Absent this affirmation there would be\n  no numeric floor at all. The active `Test Strategy` is **Standard** and continues to govern test\n  volume and type independently of this number.\n- **Coverage floor — hazard modules**: a second, scoped\n  `coverage report --fail-under=100 --include=<hazard module globs>`. The hazard modules are the\n  ports of the behaviours ranked in `code-quality-assessment.md` § *Hazard index* — the\n  seven-statement concurrency batch and its `last_mutation` ABA defence, the media access rule, the\n  `researchIdentity` back-compat shims, the request-size cap, the three hand-written image header\n  parsers, the WebVTT validator, the byte-range parser and the editor state machine. Each carries a\n  test per enumerated branch. An aggregate percentage cannot distinguish \"this branch is exercised\"\n  from \"this branch was ported correctly\"; these are precisely the branches whose silent loss ships\n  a defect, so they get both the per-branch tests and a floor that leaves no room.\n- **Coverage floor — frontend**: none. The Next.js frontend renders only and owns no application\n  decision, so a line-coverage number on it would measure JSX traversal rather than behaviour.\n- **The test families, and which are mandatory.** Mandatory: the recorded fixtures above; backend\n  unit tests for branch-level behaviour of ported logic; **storage-port contract tests written as\n  an adapter-parameterized conformance suite and run against both the real SQLite adapter and an\n  in-memory fake** (two implementations is the minimum that proves the suite tests the port\n  contract rather than SQLite, and it is the whole argument for having a port); API contract tests\n  in the non-circular form — assert the **generated** OpenAPI document against the **hand-written**\n  contract from `contract-design`, and commit the generated `openapi.json` as a snapshot so an\n  unintended contract change surfaces as a gate diff rather than as a frontend 422 three Bolts\n  later; and the Compose end-to-end flow. Frontend render checks are mandatory but add **no\n  frontend test framework**: assert against the HTML the composed stack returns, using the recorded\n  fixtures, and make the assertions named rather than \"landmarks present\" — each of the three\n  research cards has a distinct topic class and icon, the publications topic filter returns\n  non-zero for each seeded theme, each research card shows non-zero related papers. Browser checks\n  (Playwright) are optional today with one condition that flips them: **if the six-flag editor\n  state machine lands in the frontend rather than the backend, a browser check becomes the only\n  possible verification of it and becomes mandatory.** Flag that as a dependency on `domain-design`.\n- **Compose end-to-end runs on every Bolt merge**, not only at the skeleton gate and at the end.\n  With no CI, the per-merge run *is* the CI, and the alternative is a container-level regression\n  surfacing many Bolts after the one that caused it, with no bisect signal and nobody watching a\n  dashboard. Keep the cost bounded by keeping the flow small and fixed — the skeleton's two paths\n  plus one auth-failure path — so it stays inside a few minutes on cached layers.\n- **Parity is verified two ways, and pixel comparison is rejected.** (1) A **normalised\n  DOM-structure diff** against the recorded source HTML: strip volatile attributes, build hashes\n  and whitespace, then diff the element tree plus text content per route. It catches what actually\n  breaks in a port — a dropped section, a wrong class, a missing copy default among the 25 leaf\n  defaults — at a fraction of the setup cost of pixel screenshots and without their flakiness.\n  (2) An explicit **page-by-page human review at the end**, recorded as a checklist. Per-route\n  screenshot comparison was considered and **rejected**: it is brittle against fonts, antialiasing\n  and animation, and it is not a live option to be reopened later. Until the DOM diff exists, the\n  parity rule is an unfalsifiable claim, which is what this closes.\n- **Boundary enforcement is a command, not an assertion.** A rule nobody can check is a wish. Three\n  checks, all on the gate: the frontend's TypeScript types for backend payloads are **generated**\n  from the backend's `/openapi.json` with `openapi-typescript`, committed, regenerated at the gate,\n  and the gate fails if the output is dirty — which makes the boundary type-checked rather than\n  asserted, since a backend field rename then fails `tsc --noEmit` with a file and a line; a\n  three-line grep fails the gate if `chiku-website/frontend` contains any `'use server'` directive,\n  any `app/**/route.ts`, or any `middleware.ts` (an ESLint `no-restricted-syntax` rule is a nicer\n  editor experience, but the grep is the one that is certain); and one pytest walks the AST of\n  `routers/` modules and asserts none of them imports a `store` module or `sqlite3`.\n- **The source has no suite to keep green.** The org rules for several scopes say \"the existing\n  suite remains green\". There is none — the scan found zero test files, zero testing dependencies\n  and no `test` script anywhere in `madhavi-tripathi/`. Every test in this project is a new test.\n  The only inherited automated checks are `tsc --noEmit` (strict) and `pnpm lint`.\n- **Tooling**: backend — pytest 9.1.1 with `httpx` 0.28.1 for FastAPI transport-level tests,\n  `ruff` 0.16.8 and `mypy` 2.3.1 as gating checks, dependencies resolved by `uv` 0.10.0. Frontend\n  — `tsc --noEmit` and ESLint 9 with `eslint-config-next`, unchanged from the source project.\n- **The merge gate.** A Bolt may squash-merge to `main` only when every one of these passes on the\n  developer machine, in this order, with the **verbatim output pasted into the gate approval**:\n\n  ```\n  ruff check\n  ruff format --check\n  mypy --strict\n  pytest --cov --cov-branch\n  coverage report --fail-under=80\n  coverage report --fail-under=100 --include=<hazard module globs>\n  tsc --noEmit\n  pnpm lint\n  git diff --no-index madhavi-tripathi/app/<f> chiku-website/frontend/app/<f>   # per unmodified ported file\n  <boundary grep: 'use server' / app/**/route.ts / middleware.ts>\n  <openapi-typescript regeneration — gate fails if the committed output is dirty>\n  uv export --frozen --no-dev --no-emit-project -o .audit/requirements.txt && uvx pip-audit -r .audit/requirements.txt\n  pnpm audit --prod --audit-level high\n  docker compose up  +  the end-to-end flow\n  ```\n\n  **Dependency advisories block at High and above.** An advisory with no fix available does not\n  silently pass and does not silently block: it is recorded with the **package, the advisory id,\n  the reason it cannot be fixed, and the named Bolt that owns it**, and the gate then proceeds on\n  that record. This is consistent with the correction already in `project.md` that any finding\n  carried past a gate needs a named owner.\n\n  Gates protect the parity guarantee; weakening one to make a Bolt pass is an incident, not a\n  shortcut."
    }
  ],
  "obligations": {
    "strategy": "standard",
    "strategy_volume": [
      "Five to eight tests per component.",
      "Unit tests plus integration tests for key boundaries.",
      "Add E2E, performance, or security tests when requirements demand them."
    ],
    "scope_floor": [
      "Keep the existing test suite green.",
      "This scope adds no extra new-test floor beyond the selected test strategy."
    ],
    "combination_rule": "Apply every selected-strategy obligation and every scope-floor obligation; neither replaces the other, and a targeted scope regression may add the narrowest necessary test type beyond the strategy default."
  },
  "plan_profile": {
    "methodology": "custom",
    "runner_step": "Verify the existing test runner/configuration and record the exact unit-scoped command.",
    "runner_ready_before_first_test": true,
    "testable_layers": [
      "Data model / database behavior",
      "Repository / data access",
      "Business logic",
      "API / endpoint",
      "Frontend behavior"
    ],
    "steps": [
      "Project structure and production configuration skeleton.",
      "Verify the existing test runner/configuration and record the exact unit-scoped command.",
      "Custom ordering - Within each unit, the characterization tests for that unit's hazard-register",
      "Implementation and tests - preserve that exact ordering; do not convert it to layer-local TDD.",
      "Environment/build configuration.",
      "Documentation and traceability."
    ]
  },
  "input_sha256": "sha256:ae7fe698329b9815a1e703cfb6f92beeb23e35c6e2f83768ad7ab02dffb4a262",
  "contract_sha256": "sha256:6b84da29d5313b29b3058ef863280c58a9f6f401f244363de9431d8063261179"
}
```
