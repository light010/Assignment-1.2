# Code Summary — U4 `content-core`

**Unit:** `content-core` · **Kind:** `library` · **Stage:** `code-generation`

**Target tree:** `chiku-website/backend/`. `madhavi-tripathi/` was read from as the
**read-only reference source** and never written to.

Eight new application modules and seven new test files. One pre-existing application
module was reused unchanged (`app/content/limits.py`), one pre-existing config file gained
one entry (`pyproject.toml`), no dependency was added, and no `# noqa` or `# type: ignore`
was introduced anywhere.

---

## What was built

```
app/content/schema.py        the 31-field model tree, every cap, every default,
                             the SINGLE camelCase conversion point, the wire shapes
app/content/defaults.py      the content-carrying defaults          [HAZARD — FR9.2]
app/content/seed.py          the seeded document, as instance data
app/content/statements.py    the pure statement builder             [HAZARD — FR4.5]
app/content/recovery.py      recoverable versus corrupting          [HAZARD — FR8.3]
app/content/cache.py         the single-entry published-document cache [SECURITY]
app/content/ledger.py        RevisionLedger: listing order + retention, read-only
app/content/authority.py     ContentAuthority: the reads, the save path, the order

tests/content/__init__.py        package marker
tests/content/conftest.py        both real stores, the fixture accessors, the helpers
tests/content/test_schema.py         38 functions, 137 runs
tests/content/test_defaults.py       18 functions,  25 runs  [HAZARD]
tests/content/test_write_path.py     28 functions,  68 runs  [HAZARD]
tests/content/test_recovery.py       17 functions,  41 runs  [HAZARD]
tests/content/test_cache.py          15 functions,  29 runs  [SECURITY]
tests/content/test_ledger.py         13 functions,  40 runs
tests/content/test_owner_read.py      8 functions,  16 runs
```

`app/content/limits.py` was **reused unchanged**: it already implements the cap as
`len(text.encode("utf-16-le")) // 2`, which the recorded `F6` family proves is the right
unit. It was not replaced and not edited.

---

## Ordering — the approved Testing Contract was followed, not converted

Methodology `custom`. Three of the system's seven hazards are owned here, so the contract's
ordering clause applied to them in full: **Steps 4 and 6 were Red steps and were not merged
with the implementation steps that follow them.**

**Step 4 Red — the three hazard suites, before any hazard code existed.**

```
=== collection ===
E   ModuleNotFoundError: No module named 'app.content.authority'
E   ImportError: cannot import name 'recovery' from 'app.content'
ERROR tests/content/test_write_path.py
ERROR tests/content/test_recovery.py
2 errors in 0.13s

=== behavioural ===
21 failed, 4 passed in 0.08s
```

`test_defaults.py` was deliberately written so its Red is **behavioural rather than an
import error**: the item model declared `researchTopic` and `researchIds` as required with
no transform, so every absent-identity case failed with `Field required [type=missing]` —
the exact shape a port that never resolved them would ship.

**Step 6 Red — the cache, in two stages.** The first was an import error. The second is the
one that matters, and it is the reason ADR-002 asks for this path to carry its own test:
`cache.py` and the public read were implemented **without** the publish invalidation, and
the authorization assertion failed on both store implementations —

```
E       assert '/api/media/...74058c3.webp' not in '{"name":"Ma...tcome":""}]}'
FAILED test_an_asset_the_owner_unreferences_stops_being_public_on_the_next_request[memory]
FAILED test_an_asset_the_owner_unreferences_stops_being_public_on_the_next_request[sqlite]
2 failed, 27 passed
```

An asset the owner had just unreferenced was still being served. A test that measured cache
*hits* would have passed at that moment. Adding the synchronous invalidation took it Green.

Everything else was written immediately after the code it covers, per the contract.

---

## The three hazards, and what holds each one

| Hazard | Where it lives | What holds it |
|---|---|---|
| **The content-carrying defaults** (FR9.2, BR9.1–BR9.3) | `defaults.py`, applied by a `mode="before"` model validator on `ContentItem` | The resolution runs **before field validation**, which is the only point at which *absence* is still distinguishable from *defaulted*. `researchTopic` and `researchIds` are declared **required and non-nullable**, so a port that forgot the transform fails loudly rather than producing `None`. An explicitly emptied list stays empty because the test is `key not in row`, never truthiness. |
| **The combined write and its ABA guard** (FR4.5, BR4.8–BR4.19) | `statements.py` builds, `ContentStore.commit` executes | The guard structure is **data**: each of the seven effects carries a `Guard` naming what it tests. Effects 4–6 carry `mutation_token`; the compare-and-set does not. The suite asserts the collision *occurs* (`winner.next_revision == loser.next_revision`) before asserting the defence holds, so the scenario is reproduced rather than assumed. Two genuinely concurrent writers, one storage, on both implementations. |
| **Recoverable versus corrupting** (FR8.3, BR8.1–BR8.5) | `recovery.py` | The classification is keyed on **what went wrong with the value**, expressed in Pydantic's own vocabulary; no zod code string appears in the module, and a test greps the source to prove it. `literal_error` — the bad-enum row the source puts on the wrong side — is **recoverable**. A second test asserts every member of `RECOVERABLE_ERROR_TYPES` is in `pydantic_core.core_schema.ErrorType`, which is the guard against the source's *first* defect: an allowlist entry that can never match. |

**The fourth hazard, the error envelope, is raised into and not owned here.** This unit
raises `TooLarge`, `Invalid`, `Conflict` and `NotAuthorized` from `app/errors.py` and
composes no status, no sentence and no envelope. The only copy stated in this unit is the
two history sentences of BR10.7 — see *Deviations*, item 2.

---

## The cache is a security parameter, and is tested as one

- **One entry, no key**, so invalidation is unconditional.
- **The interval's maximum is 5 seconds and is enforced at construction**: `6`, `30` and
  `3600` are each refused with a `ValueError` naming the maximum. A value that was accepted
  and quietly clamped would leave the operator believing a number that is not in force, so
  it fails at boot rather than at first request.
- **A successful publish invalidates synchronously, before `save` returns.** A draft save
  does not, and a *conflicting* publish does not.
- **BR24.3 is checked by its own test.** The public read returns 404 in the source, so it
  has no parity fixture. The test publishes one document, saves a draft that differs from it
  in a top-level string, a nested copy leaf, an item title and a media reference, and
  asserts that none of those five values appears anywhere in the public payload.

---

## What the recorded fixtures decided, rather than a reading of the source

| Question | Fixture | Answer |
|---|---|---|
| The seeded document, field for field | `F3-content-owner` | Identical to the transcription from `initialContent` **except `photoSources`** — see *Findings*, item 1 |
| `photoFocalY` | `F3-content-owner` | **35**, confirmed independently of the transcription |
| The content-carrying defaults, resolved | `F3-content-owner` | All three research topics and all five publication link sets read off the recording, not chosen |
| The size cap's unit | `F6-size-*` | UTF-16 code units — see *Findings*, item 2 |
| The 409 envelope | `F5-conflict-stale-revision` | `error` plus `revision`, `updatedAt`, `publishedAt`, `hasUnpublishedChanges` as **siblings**, asserted as a key set |
| The `400` shapes | `F12-*` | `The update could not be read.` for a parse failure, `Invalid save request.` for a shape or envelope failure, `Please check the highlighted fields before saving.` with `issues[]` for content |
| The timestamp wire form | `F3-content-owner` | `2026-09-25T03:12:29.956Z` — three fractional digits and a literal `Z`, not `isoformat()` |

---

## Deviations from the plan, and why

1. **A seventh test file, `tests/content/test_owner_read.py`.** The plan names six and
   assigns each to one behaviour; the owner read (BR4.1, BR4.2) belongs to none of them.
   Putting it in `test_write_path.py` would have diluted a hazard suite and putting it in
   `test_ledger.py` would have put a content operation behind a name that means revisions.
2. **The two history sentences are stated in `app/content/ledger.py`.** BR10.7 declares
   them in U6, and `app/errors.py` does not yet carry them. They are product copy for
   conditions **this** unit raises, so they are named here with a cross-reference rather
   than invented at the call site; `app/errors.py` was deliberately not edited. U6 may
   re-home them.
3. **`RevisionLedger.read_revision` returns `None` rather than raising a not-found.** The
   taxonomy has exactly four members and 404 is not one of them; `app/errors.py` was not
   extended. Absence is a return value, consistent with the port's own philosophy, and U6
   renders `HISTORY_NOT_FOUND`.
4. **`ContentAuthority` takes `retention` as a constructor argument** rather than holding a
   `RevisionLedger`. BR5.9 requires the policy to be an argument; `RevisionLedger.retention`
   supplies it and `test_ledger.py` asserts the wiring. This also keeps the ledger's store
   access read-only by construction.
5. **One line added to `pyproject.toml`**: `content` joined `known-first-party` in the ruff
   isort config, exactly as `cloud` and `conformance` already had. No threshold was changed,
   no `omit` was added, and no `--include` was narrowed.
6. **Non-ASCII punctuation is written as a NAMED escape** (`\N{MIDDLE DOT}`,
   `\N{EN DASH}`, `\N{EM DASH}`) rather than as `\uXXXX`. The instruction was to escape
   rather than suppress `RUF001`; the named form does that, says which codepoint is meant,
   and needs no lint suppression.

---

## Findings — where the artifacts and the recordings disagree

**These are reported, not quietly resolved. The fixtures are the oracle.**

1. **`F3-content-owner` is not a pristine seed.** Its `photoSources` carries one entry,
   `/api/media/558fe673-2562-492b-b383-235dc74058c3.webp` (1536×1024), which the recording
   session itself created — `fixtures/README.md` records that two gaps were closed by
   performing a real upload and a real publish through the app's own routes before the
   final re-record. Every other value in the document matches the transcription from
   `initialContent` byte for byte. The test states the exclusion explicitly and asserts the
   fixture's `photoSources` value, so the exclusion cannot be widened silently.

2. **The `F6` figures quoted in the plan and the brief were wrong — RESOLVED.** They said
   `F6-size-astral-under-in-units` was *"1,399,999 units / 2,783,472 UTF-8 bytes"* and
   `F6-size-astral-over-in-units` *"1,599,999 units from only 808,278 codepoints"*. The
   recorded metadata says **1,400,000 units / 708,326 codepoints / 2,783,379 bytes** and
   **1,600,000 units / 808,326 codepoints / 3,183,379 bytes**. The figures had been
   written from memory rather than read from the recordings, and had propagated into
   `source-fixtures`' own `code-summary.md` and `traceability.json` as well. **All of them
   have been corrected to the recorded values**; the approved `code-generation-plan.md` is
   left as approved, since its fingerprint binds it and its conclusion was never in doubt.

   The **conclusion is unaffected** — the boundary is UTF-16 code units, a byte cap still
   rejects the first and a codepoint cap still accepts the second. But this is precisely
   what the `custom` methodology exists to catch: a number recalled rather than read is
   the same class of error as an implementation written from a misreading, and it was
   found by a test that took its expected value from the recording.

3. **`rules.md` BR4.20 says the cap counts *characters*; the recordings say UTF-16 code
   units.** Already adjudicated in the plan and in `limits.py`, and recorded here because
   it is a live disagreement between a rule's text and the oracle.

4. **Per-field `issues[].message` text cannot be at parity for built-in failures.**
   `F12-schema-invalid` records zod's own strings (`"Required"`); Pydantic's are different
   (`"Field required"`). `entities.md` quotes only the **custom** refinement messages as
   verbatim, and all seven of those are reproduced exactly and asserted. BR10.2 specifies
   the **shape** (`path`/`message`), which is reproduced. The divergence is confined to a
   validation library's default catalogue, and closing it would mean reimplementing zod's
   message catalogue in Python.

5. **BR5.10's "carries no content" and the plan's gloss "unreadable content" are not the
   same case.** A row whose content column is empty reads as not-found, which matches both
   the rule and the source's `row?.content` truthiness test. A row whose content is
   **present but unparseable** is left to propagate, because the source answers 503 there
   and telling the owner a version is *"no longer in the recent history"* would be untrue of
   an entry that demonstrably exists. Both branches carry a test; the reading is stated in
   the docstring so a reviewer can overrule it cheaply.

---

## Carried, not closed

**The unsavable-recovered-draft window.** The recovery path accepts a draft up to
**6,000,000** characters and the save path rejects anything over **1,500,000**. A draft
between those bounds is restorable into the editor and unsavable from it, including by
autosave. Both limits are reproduced, neither is aligned, and
`test_the_recovery_ceiling_is_six_million_units_and_is_not_the_save_cap` records the
window with its rationale. This still needs the site owner.

---

## Stated divergences from the source, each one deliberate

| Divergence | Why |
|---|---|
| `citationDate` rejects the year `0000` | `Date.parse('0000-01-01')` succeeds in JavaScript; Python's `date` has no year zero. No snapshot date an owner types can reach it. |
| `savedAt` is parsed with `datetime.fromisoformat`, not `Date.parse` | Every timestamp the editor writes is `toISOString()` output and parses identically; a human-written `March 5, 2026` is refused here. |
| A bad enum keeps the recovered draft | **D9**, one of only three deliberate behaviour changes. The rule as written, not the source's defect. |

---

## Conventions held

- **One conversion point.** `wire_name` in `schema.py` is the whole of it. No `camelCase`
  identifier exists in Python and no `snake_case` key reaches the wire; a **trailing
  underscore** escapes a name Pydantic has taken (`copy_` → `copy`), which is why no
  hand-written `alias=` exists anywhere.
- **Strict validation.** `strict=True` on the shared base, because zod coerces nothing: a
  lax port would accept `"50"` for a number and `1` for a boolean, be *more permissive* than
  the system it preserves, and quietly move a wrong-type failure out of the corrupting class.
- **`int | float` rather than `float`** for the four focal percentages, so JSON `50`
  serialises back as `50`. The persisted content **is** this JSON.
- **Time is injected everywhere.** No module-level clock; `now` is a caller argument on
  `save`, on the cache and through the port.
- **The store is never mocked.** Every test runs against both the SQLite adapter and the
  in-memory fake. The only stand-in is `CountingStore`, a delegating wrapper that counts
  reads — "which requests hit storage" is invisible from the returned value, and it is the
  property BR7.2 is about.
- **A layer exists only when it has a job.** No service-per-route and no generic repository.
  The pure-versus-execute split survives: `statements.py` builds, the store executes.

## Verification

All run from `chiku-website/backend/`, all exit 0.

| Command | Result |
|---|---|
| `uv run pytest tests/content` | **356 passed** |
| `uv run pytest` | **764 passed** (408 pre-existing + 356 new) |
| `uv run pytest --cov --cov-branch` | TOTAL 1665 stmts, 7 miss, 244 branch, **0 partial**, **99%** |
| `uv run coverage report --fail-under=80` | 99%, exit 0 |
| `uv run coverage report --fail-under=100 --include=<seven hazard modules>` | **100%**, exit 0 |
| `uv run ruff check` | All checks passed! |
| `uv run ruff format --check` | 62 files already formatted |
| `uv run mypy --strict app tests` | Success: no issues found in 61 source files |

All three of this unit's hazard modules reach **100% branch** coverage, joining the four
already under that floor. `app/content/authority.py`, `app/content/cache.py`,
`app/content/ledger.py`, `app/content/schema.py` and `app/content/seed.py` also reach 100%
branch, which the floors do not require.

**The seven uncovered statements are all in `app/errors.py`** (85%): the three FastAPI
exception handlers and the media not-found helper, which belong to U6 and have no route to
exercise them until that unit exists. No floor covers them, the aggregate floor is met with
19 points of margin, and **nothing was configured away to reach either number.**

## Sources

- `construction/content-core/functional-design/entities.md` §§ ENT-4, ENT-5, W-1, W-2 and
  § *The cap census* — every field, maximum, default and refinement was transcribed from
  here, not from the source file.
- `construction/content-core/functional-design/functional-spec.md` § *Operations* — the
  read, the save path's ordering, inspect, the listing, retention and the cache.
- `construction/content-core/functional-design/rules.md` — BR4.1–BR4.22, BR5.1–BR5.10,
  BR7.1–BR7.2, BR8.1–BR8.5, BR9.1–BR9.3, BR24.1–BR24.3 as declared here; BR10.x, BR22.x as
  enforced but declared elsewhere.
- `chiku-website/fixtures/` — `F2`, `F3`, `F4`, `F5`, `F6` and `F12`, read through
  `tests/conftest.py`'s accessors. The oracle wherever one exists.
- `inception/contract-design/contract-summary.md` § C2 — the port operations this unit calls.
- `madhavi-tripathi/app/content.ts`, `site-copy.ts`, `scene-content.ts`,
  `research-identity.ts`, `content-persistence.ts`, `api/content/route.ts`,
  `api/history/route.ts`, `edit/editor-workflow.ts` — read as the reference source for the
  seed transcription, the check order and `parseRecovery`.
- `aidlc/spaces/default/memory/team.md` §§ *Testing Posture*, *Code Style* — the `custom`
  methodology, the two coverage floors, and the Python conventions.
- `construction/content-core/code-generation/code-generation-plan.md` and
  `unit-test-instructions.md` — the approved plan and its embedded Testing Contract.
