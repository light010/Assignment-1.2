# Entities — U1 `source-fixtures`

**Upstream:** `inception/units-generation/unit-of-work.md`,
`inception/domain-design/components.md`,
`inception/requirements-analysis/requirements.md`,
`inception/contract-design/contract-summary.md`.

**This unit owns no domain entity.** `components.md` assigns all six —
`OwnerAccount`, `Session`, `LoginAttemptWindow`, `ContentDocument`,
`ContentRevision`, `Asset` — to other components. Stated explicitly so the absence
reads as deliberate rather than as an omission.

What it does own is the shape of a **recorded fixture**, which is test data rather
than domain data. It is specified here because a fixture without provenance is an
assertion rather than evidence, and because every dependent unit reads this shape.

```yaml
entities:
  - name: RecordedFixture
    description: >
      One recorded request/response pair captured from the running
      madhavi-tripathi/ application over HTTP. Test data, not domain data. It is
      specified here because a fixture without provenance is an assertion rather
      than evidence, and five other units read this shape as their oracle.
    attributes:
      - name: fixtureId
        type: string
        required: true
        unique: true
        constraints: Stable across re-recordings, e.g. F7-media-published. Referenced by the consuming test.
      - name: manifestRef
        type: string
        required: true
        allowed_values: [F1, F2, F3, F4, F5, F6, F7, F8, F9, F10, F11, F12]
        references: functional-spec.md recording manifest
        note: >
          Many fixtures carry the same value; that is grouping on an enumerated
          attribute, not a relationship between entities. There is no ManifestRow
          entity, so it is recorded here rather than in `relationships`.
      - name: request.method
        type: string
        required: true
        allowed_values: [GET, HEAD, PUT, POST]
      - name: request.path
        type: string
        required: true
        description: Path including query string.
      - name: request.headers
        type: map
        required: true
        constraints: >
          ONLY headers that affected the outcome — Range, If-Range, conditional-get
          validators, Origin, Content-Length. Not the full set, which would record
          noise as signal and make a fixture diff noisy enough to be ignored.
      - name: request.bodyRef
        type: path
        required: false
        description: Path to the request body when one was sent, stored beside the fixture rather than inline.
      - name: response.status
        type: integer
        required: true
        min: 100
        max: 599
      - name: response.headers
        type: map
        required: true
        constraints: >
          The FULL set, unlike the request side. For media responses these carry
          Cache-Control, X-Content-Type-Options, Content-Security-Policy,
          Accept-Ranges, ETag, Content-Range and Content-Length — several of which
          are themselves the thing being preserved.
      - name: response.bodyRef
        type: path
        required: true
        description: Path to the recorded body, raw and unnormalised.
      - name: response.byteLength
        type: integer
        required: true
        constraints: >
          Body length in BYTES. Load-bearing for the size-cap fixtures, where the
          character-versus-byte distinction is the whole point. Stored rather than
          derived, so the computation is not on the side being tested.
      - name: recordedAt
        type: timestamp
        required: true
        constraints: ISO 8601 UTC.
      - name: sourceCommit
        type: string
        required: true
        description: The madhavi-tripathi/ commit the recording ran against.
      - name: identity
        type: enum
        required: true
        allowed_values: [anonymous, owner]
        description: >
          Which identity the request was made under — no cookie, or
          `__sites_local_auth=1`. REQUIRED on every fixture and load-bearing on the
          media ones: the source returns 200 with the body to the owner for a
          draft-only asset and 404 to anonymous, so a media fixture without its
          identity records an ambiguous oracle. See functional-spec.md's identity
          matrix.
      - name: notes
        type: text
        required: false
        description: >
          Used where a fixture records a behaviour that looks like a defect and is
          being preserved deliberately under the parity rule.
    constraints:
      - A fixture missing recordedAt or sourceCommit is not evidence and must not be used as an oracle (BR21.2).
      - A media fixture missing `identity` is not evidence either: the visibility branch it exercises is undetermined without it (BR21.7).
      - Bodies are never inlined — a content document is ~15 KB and the size-boundary fixtures are 1.5M characters.

  - name: StoredStateSnapshot
    description: >
      Database state captured alongside the F4/F5 write fixtures, because some
      behaviour — retention, revision ordering, timestamp movement — is only
      visible in stored rows and never appears in a response.
    attributes:
      - name: snapshotId
        type: string
        required: true
        unique: true
      - name: takenAfter
        type: string
        required: true
        references: RecordedFixture.fixtureId
        description: Which fixture's request produced this state.
      - name: contentRow
        type: record
        required: true
        description: Revision number, both timestamps, and whether draft and published differ.
      - name: revisionRows
        type: list
        required: true
        constraints: >
          Every revision entry present — id, revision, action, created time,
          baseline flag — IN STORED ORDER, so the three-part ordering and the
          retention policy are both checkable against data rather than inferred.
      - name: assetRows
        type: list
        required: false
        description: Present only for upload fixtures.
    constraints:
      - Recording runs against a disposable local database only (BR21.4).

relationships:
  - from: RecordedFixture
    to: StoredStateSnapshot
    cardinality: zero-or-one-to-one
    direction: >
      A fixture has AT MOST ONE snapshot, and a snapshot belongs to exactly one
      fixture. Only the F4/F5 write fixtures produce one; F1, F2, F3, F6 and the
      read-only media fixtures have none. The earlier `one-to-one` was wrong and
      contradicted both this file's prose and the derived diagram.
```

## RecordedFixture

| Field | Required | Meaning |
|---|---|---|
| `fixtureId` | yes | Stable identifier, e.g. `F7-media-published`. Referenced by the consuming test |
| `manifestRef` | yes | Which manifest row (F1–F12) this satisfies |
| `request.method` | yes | The HTTP method as sent |
| `request.path` | yes | Path including query string |
| `request.headers` | yes | **Only headers that affected the outcome** — `Range`, `If-Range`, conditional-get validators, `Origin`, `Content-Length`. Not the full set, which would record noise as signal |
| `request.bodyRef` | no | Path to the request body when one was sent, stored beside the fixture rather than inline |
| `response.status` | yes | The status code |
| `response.headers` | yes | **The full set.** For media responses these carry `Cache-Control`, `X-Content-Type-Options`, `Content-Security-Policy`, `Accept-Ranges`, `ETag`, `Content-Range`, `Content-Length` — several of which are themselves the thing being preserved |
| `response.bodyRef` | yes | Path to the recorded body, raw and unnormalised |
| `response.byteLength` | yes | Body length **in bytes**. Load-bearing for the size-cap fixtures, where the character-versus-byte distinction is the whole point |
| `recordedAt` | yes | ISO 8601 UTC |
| `sourceCommit` | yes | The `madhavi-tripathi/` commit the recording ran against |
| `notes` | no | Free text. Used where a fixture records a behaviour that looks like a defect and is being preserved deliberately |

## StoredStateSnapshot

Recorded alongside the F4/F5 write fixtures, because some behaviour is only
visible in the database rather than in a response.

| Field | Required | Meaning |
|---|---|---|
| `snapshotId` | yes | Stable identifier |
| `takenAfter` | yes | Which fixture's request produced this state |
| `contentRow` | yes | Revision number, both timestamps, and whether draft and published differ |
| `revisionRows` | yes | Every revision entry present: id, revision, action, created time, baseline flag — **in stored order**, so the three-part ordering and retention are both checkable |
| `assetRows` | no | Present only for upload fixtures |

Bodies are **not** recorded inline in either record: a content document is ~15 KB
and the size-boundary fixtures are 1.5 M characters, so inlining would make the
manifest unreadable and the diffs useless.

## Assumptions & Open Questions

- **[assumption]** Recording only the headers that affected the outcome, rather
  than all of them, is the right trade. Recording everything would capture
  server-version and date headers that change on every run and would make a
  fixture diff noisy enough to be ignored — which is the failure mode that
  matters more than an occasional missed header.
- **[assumption]** `response.byteLength` is worth storing separately even though it
  is derivable from the body. It is the fixture that proves the size cap counts
  characters rather than bytes, and deriving it at compare time would put the
  computation on the side being tested.
- **[open]** Whether `StoredStateSnapshot` can be taken at all depends on being
  able to read the local emulator database directly while the dev server holds it.
  If it cannot, F5 degrades to what the API reports, and retention and ordering are
  then checked only through `GET /api/history` rather than against stored rows.
