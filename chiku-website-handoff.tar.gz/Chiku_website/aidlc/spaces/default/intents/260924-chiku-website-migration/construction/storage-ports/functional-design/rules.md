# Business Rules — U2 `storage-ports`

**Unit:** `storage-ports` · **Kind:** `library`

**Upstream:** `construction/functional-design/rules.md` (the 120 rules; ids are
stable and are **not** renumbered here), `inception/contract-design/contract-summary.md`
§§ C2, C3, C4, `inception/domain-design/decisions.md` ADR-001,
`inception/units-generation/unit-of-work.md` § U2, `aidlc/spaces/default/memory/team.md`
§ *Testing Posture*.

## How to read this document

This unit **owns no business rule**. What it owns is a **contract**, and this
document has two halves that must not be confused:

- **Rules this unit DECLARES** — `BR22.1`–`BR22.14`, in the unit-scoped group for
  U2 (unit number + 20). Each is a genuine obligation on an *implementation of a
  port* rather than behaviour a user observes. **Every one of the fourteen carries
  `source: none` and is reported in the traceability `reverse` array**, because
  none of them has an acceptance criterion of its own — and `coverage` is
  consequently **empty**, which is the correct reading of a unit the story map
  assigns **no FR at all**.

  > **Corrected at review (R-6).** Eleven of the fourteen previously carried a
  > real FR in `source:` (`source: FR4.5, FR5.3; enforces BR4.18…`), which put
  > them in `traceability.json`'s `coverage` array and made this unit appear to
  > discharge eleven requirements it does not. **`source:` means *what
  > requirement this rule satisfies*, not *what requirement it is about*.** A
  > port obligation *enables* the FR that some other unit's rule discharges: the
  > atomic batch makes `BR4.18` implementable, and `BR4.18` is where `FR4.5` is
  > actually discharged. The requirement each rule serves, and the owning rule
  > and unit that discharge it, now live in a separate **`enables:`** field where
  > they make no coverage claim. This also makes the document's own long-standing
  > statement — "every one is in the `reverse` array" — true, where before it was
  > false against the file for eleven of fourteen ids.
- **Rules this unit ENFORCES but does not declare** — every `BR3.*`, `BR4.*`,
  `BR5.*`, `BR6.*` and `BR7.*` below. **A `BR` id is declared in exactly one
  unit**: the one whose FR group owns it. `BR3.*` is declared by U3
  `identity-and-session`; `BR4.*`, `BR5.*`, `BR8.3` and `BR9.*` by U4
  `content-core`; `BR6.*` and `BR7.*` by U5 `media`. They appear here **quoted in
  full, attributed to their declaring unit**, because an adapter author needs the
  rule in front of them — but the declaration lives there, not here, and the
  workflow-level `construction/functional-design/rules.md` is the transcription of
  record.

**One literal-translation warning applies to the whole document.** Several of the
quoted rules are expressed in the source as statements in one engine's dialect. A
**port contract written in one engine's dialect is satisfiable by one adapter**,
which is the failure `BR4.18` exists to prevent. So where this document restates a
statement body **structurally** — operation, columns set, guard, result — that
restatement is a *reading aid for an adapter author*, with every guard, binding and
returned column preserved. **It is not a second declaration**, and where it and
the literal transcription disagree, the literal wins and this restatement is the
defect.

**Index**

| Half | Ids | Concerns |
|---|---|---|
| Declared here | BR22.1–BR22.9 | Content, ordering, retention, payload, conformance, runtime |
| Declared here | BR22.10–BR22.12 | Assets — cleanup, ranged reads, the two media types |
| Declared here | BR22.13–BR22.14 | Identity — atomic provisioning, no expiry in the store |
| Enforced, declared by U4 | BR4.1, BR4.8–BR4.20, BR5.1–BR5.4, BR5.7–BR5.9, BR9.2 | `ContentStore` |
| Enforced, declared by U5 | BR6.24, BR7.17, BR7.18 | `AssetStore`, asset metadata |
| Enforced, declared by U3 | BR3.6, BR3.7, BR3.16, BR3.17, BR3.22 | `IdentityStore` |

---

## Source of truth — the rules this unit declares

The block below is **authoritative for this unit**. It declares `BR22.x` and
nothing else; every other id named in this file is a reference to a rule declared
by another unit.

```yaml
source_of_truth: rules
stage: functional-design
unit: u2-storage-ports
kind: library
kind_note: >
  U2 storage-ports is a LIBRARY. U6 http-api is the only unit declaring service -
  there is exactly one deployed Python executable. The three ports, their adapters
  and their fakes are embedded in it, which is the whole point of the
  ports-and-adapters split.
authority: >
  This block is the source of truth and governs. It declares BR22.x and nothing
  else; every other id named in this file is a rule declared by another unit and is
  listed under rules_subject_to_but_not_owned. The prose sections below carry the
  rationale and the failure mode, and must not contradict this block.
components: [ContentStore, IdentityStore, AssetStore]
rule_count: 14
id_format: 'BR{group}.{seq}; source ids are FR{n} / FR{n}.{m} / NFR{n} as spelled in requirements-analysis'
unit_scoped_group: >
  BR22 is the unit-scoped allocation for U2 (unit number + 20), reserved for rules
  that are obligations on an IMPLEMENTATION of a port rather than behaviour a user
  observes. Every BR22 id has no acceptance criterion of its own, carries
  source: none, and is listed in the traceability reverse array with its reason -
  all fourteen, so the traceability coverage array is EMPTY. Where a BR22 rule
  elaborates the port half of a rule another unit owns, the requirement it serves
  and the owning rule that discharges it are named in a separate `enables` field,
  which makes NO coverage claim. CORRECTED AT REVIEW (R-6): eleven of the fourteen
  previously named that requirement in `source`, which is the field for what a rule
  SATISFIES, and that put this unit's traceability coverage at eleven requirements
  it only enables.
hazards: []   # no hazard group is owned by this unit; FR4.5's hazard is owned by u4-content-core
rules:

  - id: BR22.1
    statement: >
      The prune's operational shape: one transaction, two independent per-action survivor
      selections, and baselines excluded by predicate rather than by ordering.
    category: policy
    applies_to: ContentStore.commit
    trigger: Every prune inside the combined write.
    logic: >
      IF pruning THEN select survivors and delete inside the SAME transaction as the
      compare-and-set; select survivors PER ACTION (the 30 highest-revision non-baseline
      drafts, and separately the 20 highest-revision non-baseline publishes) rather than as
      one combined set of 50; and exclude baseline entries IN THE DELETE PREDICATE rather
      than relying on them sorting high.
    violation: >
      A cross-transaction prune reopens the window BR4.16 closes; a combined selection lets
      30 drafts evict a publish; ordering-based baseline protection eventually prunes a
      baseline, which is a once-ever capture and cannot be recreated.
    source: none   # a port obligation; discharges no FR of its own
    enables: FR4.5, FR5.3 - discharged by BR4.18, BR5.7, BR5.8 (u4-content-core)

  - id: BR22.2
    statement: The revision listing is not a paginated operation.
    category: constraint
    applies_to: ContentStore.list_revisions
    trigger: Every listing.
    logic: >
      IF the listing were implemented as a cursor over an ordered query THEN, because the
      order has ties, an entry can repeat or be skipped at a page boundary. THEREFORE return
      the whole capped listing in one result, with no cursor and no page size.
    violation: A duplicated or missing history entry at a page boundary.
    source: none   # a port obligation; discharges no FR of its own
    enables: FR5.1 - discharged by BR5.1, BR5.3 (u4-content-core)

  - id: BR22.3
    statement: >
      The in-memory fake computes the three-part order itself rather than inheriting it from
      its container.
    category: constraint
    applies_to: the in-memory fake of ContentStore
    trigger: Every conformance run against the fake.
    logic: >
      IF the fake's underlying container happens to be insertion-ordered THEN it passes the
      ordering assertions without ever computing the order, while the real adapter fails
      them. THEREFORE the fake implements the three-part order and the tie-break-free
      retention ordering explicitly.
    violation: >
      The exact inversion of what the two-implementation rule exists to catch: the fake
      certifies an order it never had to compute.
    source: none   # a port obligation; discharges no FR of its own
    enables: FR5.1 - discharged by BR5.2 (u4-content-core)

  - id: BR22.4
    statement: >
      One adapter-parameterised conformance suite per port, run against the real adapter AND
      an in-memory fake.
    category: policy
    applies_to: ContentStore, IdentityStore, AssetStore
    trigger: Every port, every adapter, every merge gate.
    logic: >
      IF a port exists THEN one parameterised suite exercises every operation against two
      implementations. The suite is where the neutral contract is written down and is the
      arbiter when this document and an adapter disagree. A new adapter is done when it
      passes the EXISTING suite unchanged; an adapter that needs the suite relaxed has found
      a port defect, and the port changes at its owner rather than the suite at the adapter.
    violation: >
      A suite run against one implementation tests that implementation, not the port - which
      dissolves the entire argument for having a port.
    source: none   # traces to no FR; affirmed team practice, Testing Posture

  - id: BR22.5
    statement: A serialised content payload round-trips byte-identically.
    category: constraint
    applies_to: ContentStore - every payload-bearing operation
    trigger: Any write then read of a content payload.
    logic: >
      IF a payload is written THEN it is returned byte for byte on read - no key re-ordering,
      no re-encoding, no whitespace normalisation, no Unicode normalisation.
    violation: >
      An undeclared data migration of the frozen wire format, and every history entry
      disagreeing with the document it records, because BR4.11 reads the stored column back.
    source: none   # a port obligation; discharges no FR of its own
    enables: >
      FR4.5 - discharged by BR4.11 (u4-content-core); FR9.4 - discharged by
      u4-content-core entities.md section "The wire format is frozen". THIS RULE
      PRESERVES the frozen wire format across the storage boundary; it does not
      state it.

  - id: BR22.6
    statement: The store validates nothing and defaults nothing.
    category: constraint
    applies_to: ContentStore, IdentityStore, AssetStore
    trigger: Any write or read of a payload or record.
    logic: >
      IF an adapter is handed a value THEN it stores it. It applies no field default, runs no
      parse transform, enforces no maximum length, and checks no pattern.

      TYPE COERCION IS BOUNDED, NOT FORBIDDEN, and the distinction is the whole rule. An
      adapter MAY convert a value between the port's type and its store's representation
      where the store has no native equivalent - `ContentRevisionRecord.baseline` is stored
      as an integer by the SQLite adapter and returned as a boolean, because SQLite has no
      boolean type. That is a REPRESENTATION conversion: total, lossless, reversible, and
      invisible to the caller, who both writes and reads a boolean.

      What is forbidden is a SEMANTIC coercion - one that could change, narrow or invent a
      value: parsing a string to a number, truncating to a maximum, substituting a default
      for a null, or normalising a shape. The test is whether the round trip is the
      identity function for every value the port's type admits. Representation conversion
      is; semantic coercion is not.
    violation: >
      A store that materialised the content-carrying defaults would write values the owner
      never entered, in a place nobody is looking - and it would do so on every read.
      Conversely, a literal reading of an unqualified "coerces no type" forbids the
      integer-to-boolean round trip `entities.md` mandates for the same field, which is why
      the boundary is stated rather than left to judgement.
    source: none   # a port obligation; discharges no FR of its own
    enables: FR4.3, FR9.2 - discharged by BR4.6 and BR9.1-BR9.3 (u4-content-core)

  - id: BR22.7
    statement: A blocking driver is confined to the adapter.
    category: policy
    applies_to: every adapter
    trigger: An adapter whose underlying driver is synchronous.
    logic: >
      IF a driver is synchronous THEN the adapter moves that call off the event loop. A
      consumer never touches a blocking driver and an adapter never exposes one upward.
    violation: >
      Event-loop blocking, which is invisible to every check on the merge gate - which is why
      this is a rule rather than something a gate catches.
    source: none   # traces to no FR and to no NFR; a runtime-discipline rule

  - id: BR22.8
    statement: >
      The large-payload path writes the content-addressed blob FIRST, before the transaction,
      and the weakened guarantee is stated rather than hidden.
    category: policy
    applies_to: ContentStore.commit - document-store adapter
    trigger: A serialised payload above the adapter's safe threshold.
    logic: >
      IF the serialised payload exceeds the adapter's per-document ceiling THEN write it as a
      content-addressed object in the blob service FIRST and keep only the key in the
      document. Because the key is a hash of the content the write is idempotent, so a
      transaction that then fails leaves reclaimable garbage rather than a dangling
      reference. The reverse ordering is forbidden.
    violation: >
      Transaction-first ordering leaves a dangling reference, which is corruption rather than
      garbage. Ignoring the path altogether makes a save the port MUST accept unstorable.
    source: none   # a port obligation; discharges no FR of its own
    enables: FR4.6 - discharged by BR4.20 (u4-content-core)

  - id: BR22.9
    statement: A declared index is a deliverable, not a runtime detail.
    category: policy
    applies_to: any adapter needing a declared index
    trigger: Adapter implementation and deployment planning.
    logic: >
      IF an ordering obligation needs a declared index THEN that definition is an artifact of
      the deployment plan, and the conformance suite asserts the order it enables, so a
      missing index fails a test rather than silently reordering the list.
    violation: >
      An ordering that is correct only because someone once created an index by hand, and
      breaks silently in the next environment, in a list the owner reads.
    source: none   # a port obligation; discharges no FR of its own
    enables: FR5.1 - discharged by BR5.4 (u4-content-core)

  - id: BR22.10
    statement: >
      The two cleanup deletes are idempotent and exist for the cleanup path alone; there is no
      ordinary asset-deletion path.
    category: policy
    applies_to: AssetStore.delete, ContentStore.asset_metadata.remove
    trigger: The best-effort cleanup of a failed or cancelled upload.
    logic: >
      IF a key is deleted and that key is absent THEN the operation SUCCEEDS - the cleanup path
      cannot know how far the failed write got. Neither operation is offered for any other
      purpose, and no orphan-collection path exists anywhere in the system.
    violation: >
      A delete that raises on an absent key turns best-effort cleanup into a second failure that
      masks the first, which BR6.24 forbids.
    source: none   # a port obligation; discharges no FR of its own
    enables: FR6.6 - discharged by BR6.24 (u5-media)

  - id: BR22.11
    statement: >
      get_range is a first-class port operation that transfers only the requested bytes, and
      the range arithmetic belongs entirely to the caller.
    category: constraint
    applies_to: AssetStore.get_range
    trigger: Every ranged media read.
    logic: >
      IF a range is requested THEN the adapter transfers ONLY the requested window from the
      underlying store, never whole-object-then-slice. get_range receives an ALREADY-RESOLVED
      offset and length: it clamps nothing, re-interprets nothing and validates nothing, because
      every range branch is decided above this port. A window that does not exist in the object
      is a caller defect, reported rather than silently served short.
    violation: >
      A whole-object slice returns the correct bytes and passes every functional assertion while
      making a 50 MB video cost 50 MB of transfer per seek. The failure mode is cost and latency,
      so no correctness test catches it.
    source: none   # a port obligation; discharges no FR of its own
    enables: FR7.4 - discharged by BR7.17 (u5-media)

  - id: BR22.12
    statement: >
      The object store and the metadata store hold the media type independently and the port
      does not reconcile them.
    category: constraint
    applies_to: AssetStore.head, ContentStore.asset_metadata.read
    trigger: Every media response.
    logic: >
      IF a media response is built THEN its content type comes from the METADATA ROW while its
      entity tag and size come from the OBJECT. Both operations return a media type and the two
      values are different values from different stores; no adapter makes one read the other.
    violation: >
      Reconciling them in an adapter hides the divergence that BR7.18 exists to warn about, and
      anything that syncs only one store then serves a mismatched type.
    source: none   # traces to no FR; enables BR7.18 (u5-media)
    source_note: >
      Cited FR7.5 until review. FR7.5 is "responses carry the existing protective headers:
      no content-type sniffing, a restrictive content policy, and private cache control" -
      it says nothing about the two stores holding the media type independently. That
      mis-citation propagated into traceability.json as FR7.5 -> OK, overstating coverage.
      This is a port-shape obligation with no acceptance criterion of its own; it is what
      makes BR7.18 implementable, and BR7.18 is where FR7.5 is actually discharged.

  - id: BR22.13
    statement: create_if_absent is atomic against a concurrent caller.
    category: constraint
    applies_to: IdentityStore.owner_record.create_if_absent
    trigger: Two simultaneous provisioning attempts.
    logic: >
      IF two callers attempt provisioning at the same time THEN exactly ONE record is created and
      the other caller is refused - never two records, never a lost one. A read-then-write
      implementation does not satisfy this, for the same reason BR4.9 rejects one.
    violation: >
      Two owner records, or a silently lost provisioning, on the one operation that can never be
      re-run once it has succeeded.
    source: none   # a port obligation; discharges no FR of its own
    enables: FR3.7 - discharged by BR3.7 (u3-identity-and-session)

  - id: BR22.14
    statement: The session store evaluates no expiry and filters nothing.
    category: constraint
    applies_to: IdentityStore.session.read
    trigger: Every session read.
    logic: >
      IF a session record is past either expiry bound THEN it is STILL RETURNED as stored. The
      store holds timestamps; the consumer applies the two bounds.
    violation: >
      A store that filtered expired sessions would be enforcing a rule it does not own, and the
      store's evaluation and the consumer's would drift into two different expiry policies.
    source: none   # a port obligation; discharges no FR of its own
    enables: FR3.3 - discharged by BR3.16 (u3-identity-and-session)

rules_subject_to_but_not_owned:
  - { id: BR4.1, owner_unit: u4-content-core, why: 'read_state returns the seed and writes nothing; this unit implements that read but does not own what the seed means' }
  - { id: BR4.8, owner_unit: u4-content-core, why: 'Bootstrap guarded on base revision 0; commit executes it, the meaning of revision 0 is U4''s' }
  - { id: BR4.9, owner_unit: u4-content-core, why: 'The two once-ever baseline captures; this unit must make them idempotent under concurrency' }
  - { id: BR4.10, owner_unit: u4-content-core, why: 'The compare-and-set; this unit provides the guard, U4 decides what a stale revision means to a caller' }
  - { id: BR4.11, owner_unit: u4-content-core, why: 'History content is read back from the stored draft column - the port must make that readable within the transaction' }
  - { id: BR4.12, owner_unit: u4-content-core, why: 'Retention statements gated on the token; BR22.1 is this unit''s obligation under it' }
  - { id: BR4.13, owner_unit: u4-content-core, why: 'The ABA scenario; the port must carry last_mutation and honour the token guard' }
  - { id: BR4.14, owner_unit: u4-content-core, why: 'The token is not optional; a port refactor may not drop it' }
  - { id: BR4.15, owner_unit: u4-content-core, why: 'The guard survives weaker isolation; an adapter may not argue it away' }
  - { id: BR4.16, owner_unit: u4-content-core, why: 'Atomicity is REQUIRED of commit - the one obligation this port cannot delegate downward' }
  - { id: BR4.17, owner_unit: u4-content-core, why: 'The CAS outcome is read by name, not position; the port''s return shape must make that possible' }
  - { id: BR4.18, owner_unit: u4-content-core, why: 'Prune shape is read-then-delete, never a query predicate; BR22.1 is this unit''s obligation under it' }
  - { id: BR4.19, owner_unit: u4-content-core, why: 'The retention tie is indeterminate; an adapter must not add a tie-break' }
  - { id: BR4.20, owner_unit: u4-content-core, why: 'The cap counts CHARACTERS, which is why a payload can exceed 4 MB; BR22.8 is this unit''s obligation under it' }
  - { id: BR5.1, owner_unit: u4-content-core, why: 'The three-part listing order; the adapter produces it, U4 owns why it matters' }
  - { id: BR5.2, owner_unit: u4-content-core, why: 'All three parts are asserted; BR22.3 extends the obligation to the in-memory fake' }
  - { id: BR5.3, owner_unit: u4-content-core, why: 'The cap of 52 and its construction from the retention counts; BR22.2 forbids paginating it' }
  - { id: BR5.4, owner_unit: u4-content-core, why: 'A declared composite index where the adapter needs one; BR22.9 makes it a deliverable' }
  - { id: BR5.7, owner_unit: u4-content-core, why: 'The two retention counts are independent; BR22.1 is this unit''s obligation under it' }
  - { id: BR5.8, owner_unit: u4-content-core, why: 'Baselines are never pruned, by predicate; BR22.1 is this unit''s obligation under it' }
  - { id: BR5.9, owner_unit: u4-content-core, why: 'The ledger owns the policy and performs no write - so retention reaches commit as an argument, never an adapter constant' }
  - { id: BR9.2, owner_unit: u4-content-core, why: 'The content-carrying defaults run on every parse, in the consumer; BR22.6 forbids a store from materialising them' }
  - { id: BR6.24, owner_unit: u5-media, why: 'Bytes and metadata are two non-transactional writes with best-effort cleanup; BR22.10 is this unit''s obligation under it' }
  - { id: BR7.17, owner_unit: u5-media, why: 'The 206 response shape and its rule that ranged reads go through the port; BR22.11 is this unit''s port-signature obligation under it' }
  - { id: BR7.18, owner_unit: u5-media, why: 'The response type comes from the metadata row; BR22.12 is this unit''s obligation not to reconcile the two stores' }
  - { id: BR3.6, owner_unit: u3-identity-and-session, why: 'The hash is opaque and never logged; owner_record.read is the one operation that returns it' }
  - { id: BR3.7, owner_unit: u3-identity-and-session, why: 'The provisioning gate is the record''s existence; BR22.13 is this unit''s atomicity obligation under it' }
  - { id: BR3.16, owner_unit: u3-identity-and-session, why: 'Verification returns identity or nothing; BR22.14 keeps the expiry evaluation out of the store' }
  - { id: BR3.17, owner_unit: u3-identity-and-session, why: 'Revocation is server-side, so session.revoke writes to the record and the next read must fail' }
  - { id: BR3.22, owner_unit: u3-identity-and-session, why: 'Counters are persisted, so the real adapter''s login_attempts shape is durable' }
```

---

## The rules this unit declares

### BR22.1 — the prune's operational shape, spelled out

`BR4.18` (declared by U4) says what the prune is **not**. This is what it **is**,
because "read the survivors then delete the rest" is a sequence an adapter can get
wrong in three ways:

1. **Inside the same transaction as the compare-and-set.** Reading the survivors
   in one transaction and deleting in another reopens exactly the window BR4.16
   closes.
2. **The survivor read is per action.** Two independent selections — the 30
   highest-`revision` non-baseline `draft` entries, and the 20 highest-`revision`
   non-baseline `publish` entries. A single combined selection of 50 is **not**
   equivalent: a run of 30 drafts would then evict publishes, which BR5.7
   forbids.
3. **Baselines are excluded from the delete set by the predicate**, not by
   happening to sort high. An adapter that relies on ordering to spare them will
   eventually prune one, and it cannot be recreated — the capture is once-ever.

The delete set is therefore: *every non-baseline entry of that action that is not
in that action's survivor list*. The set is bounded — at most one content document
plus one revision entry plus the pruned set per call — which keeps it well inside
a document store's per-transaction document limit.

### BR22.2 — ordering and pagination are not the same obligation

`list_revisions` returns **the full capped listing in one result**, ordered. It is
**not** a paginated operation and must not be implemented as one. This matters
because a document store's natural paging primitive is a cursor over an ordered
query, and a cursor over an order with ties (BR4.19, BR5.1) can repeat or skip an
entry at a page boundary. The cap is small and fixed; return the whole thing.

### BR22.3 — the ordering obligation extends to the in-memory fake

The fake must reproduce the **same three-part order**, including the tie behaviour
of `revision DESC` **and** the tie-break-free retention ordering. A fake whose
underlying container happens to be insertion-ordered will pass the suite while the
real adapter fails it, which is the exact inversion of what the two-implementation
rule exists to catch.

### BR22.4 — the conformance suite runs over two implementations, always

**One adapter-parameterised conformance suite per port, run against the real
adapter *and* an in-memory fake.** This is not test hygiene; it is the argument
for having a port at all. **Two implementations is the minimum that proves the
suite tests the port rather than the storage engine.**

The obligation has four parts, and dropping any one of them dissolves it:

1. **One suite, parameterised by adapter** — not two suites that have drifted.
   A second suite written against the fake tests the fake.
2. **Every port operation is exercised in both runs.** An operation covered only
   against the real adapter is an operation whose contract was never stated
   adapter-neutrally.
3. **The suite is where the neutral contract is written down.** Where this
   document and an adapter disagree, the suite is the arbiter, and a rule nobody
   can check is a wish.
4. **A new adapter is "done" when it passes the existing suite unchanged.** An
   adapter that needs the suite relaxed has found a port defect: **if an adapter
   cannot satisfy a port, the port is wrong and changes at its owner, not at the
   adapter.**

**What the suite must assert explicitly**, because each of these passes a loosely
worded test while being wrong: the full three-part listing order including a tied
revision (BR5.2); the independence of the two retention counts (BR5.7); that
baselines survive a prune that would otherwise reach them (BR5.8); that a stale
writer's side effects do not fire (BR4.13); that `read_state` on empty storage
writes nothing (BR4.1); that a content payload round-trips byte-identically
(BR22.5); and that `get_range` returns exactly the requested window (BR22.11).

### BR22.5 — the payload round-trips byte-identically

Whatever serialised content payload is written is returned **unchanged, byte for
byte**. No re-ordering of keys, no re-encoding, no whitespace normalisation, no
Unicode normalisation. The persisted content **is** the frozen wire format, and
the revision entry is read back out of the stored column by the write itself
(BR4.11) — so a store that normalises has silently performed a data migration and
made every history entry disagree with the document it records.

### BR22.6 — the store validates nothing and defaults nothing

No adapter applies a field default, runs a parse transform, enforces a maximum
length, checks a pattern or coerces a type on a content payload. **The
content-carrying defaults in particular run in the consumer on every parse**
(BR9.2), and a store that materialised them would write values the owner never
entered. `storage-ports` "does not know what a revision means, only how to store
one" — and it does not know what a research topic is at all.

### BR22.7 — a blocking driver is confined to the adapter

Where an adapter's underlying driver is synchronous, the **adapter** moves that
call off the event loop. A consumer never touches a blocking driver, and an
adapter never exposes one upward. Event-loop blocking is invisible to every check
on the merge gate, which is precisely why this is a rule rather than something a
gate catches.

### BR22.8 — the large-payload path, and what it costs

This port must accept a content document of up to **1,500,000 decoded
characters**, which in UTF-8 can exceed 4 MB, and a revision entry stores the
**full** content. The locally verified relational adapter has no relevant limit.

A document-store adapter with a smaller per-document ceiling stores any serialised
payload over a safe threshold as a **content-addressed object** in the blob
service and keeps only the key in the document. **Ordering is load-bearing: the
blob is written first, before the transaction.** Because the key is a hash of the
content the write is idempotent, so a transaction that then fails leaves an
**orphaned blob, which is reclaimable garbage**, rather than a **dangling
reference, which is corruption**. The reverse ordering is forbidden.

**The cost, stated plainly:** on that path the guarantee weakens from "everything
commits in one transaction" to "the transaction is atomic, and the blob write
precedes it and is idempotent". **That weakening does not exist on the locally
verified path.** It is an obligation on the cloud-adapters unit, which already
ships unverified against the real services.

This obligation exists because a first analysis of port/adapter compatibility
concluded "no conflict" unconditionally and **was wrong** — the per-document limit
against the character ceiling is a real incompatibility that a later review found.
Recorded rather than quietly amended: an analysis that concluded "no conflict" and
was believed is worse than one never run.

### BR22.9 — a declared index is a deliverable, not a runtime detail

Where an adapter needs a declared index to satisfy an ordering obligation
(BR5.4), that index definition is **an artifact of the deployment plan**, and the
conformance suite asserts the order so that a missing index **fails a test rather
than silently reordering the list**. An ordering that is correct only because a
developer once created an index by hand is an ordering that will break in the next
environment, silently, in a list the owner reads.

### BR22.10 — the cleanup deletes are idempotent, and exist only for cleanup

`AssetStore.delete` and `ContentStore.asset_metadata.remove` exist **for the
best-effort cleanup path on a failed or cancelled upload, and for no other
purpose** — there is no ordinary asset-deletion path in the system and no orphan
collection anywhere.

Both must be **idempotent**: deleting a key that is absent is a **success**, not
an error. The cleanup path cannot know how far the failed write got, so it deletes
every key it might have written; a delete that raised on an absent key would turn
best-effort cleanup into a second failure, and BR6.24 requires that cleanup never
mask the original error.

### BR22.11 — the ranged read is a port operation, and the arithmetic is not

`get_range(key, offset, length)` is a **first-class port operation, not a
convenience wrapper over `get`**. The adapter transfers **only the requested
bytes** from the underlying store.

**Why the obligation needs its own id.** An adapter that reads the whole object
and returns a slice satisfies the signature, returns the correct bytes, and passes
every functional assertion in the suite — while making a 50 MB video cost 50 MB of
transfer for every seek. On a metered object store the failure mode is **cost and
latency, not incorrectness**, so no correctness test catches it.

**The arithmetic is the caller's.** `offset` and `length` arrive already resolved.
Every range branch — the multi-range rejection, the zero-byte object, the
oversized suffix that yields the whole object, and the start/end asymmetry where a
start past the end is an error but an end past the end is silently clamped — is
decided above this port, by U5. **The adapter clamps nothing, re-interprets
nothing and validates nothing**; moving any of that down here moves a rule across
a unit boundary and duplicates it. A request for a window that does not exist in
the object is a **defect in the caller**, reported rather than served short.

### BR22.12 — two media types, held independently, never reconciled

Both `AssetStore.head` and `ContentStore.asset_metadata.read` return a media type,
and **they are different values from different stores**. The port makes no attempt
to reconcile them, and an adapter must not: the serving rule deliberately reads
the metadata row's value while the entity tag and size come from the object.

The conformance suite asserts that both are returned. The divergence hazard is
recorded here so an adapter author does not "fix" it by having one read the other
— which would hide exactly the condition BR7.18 exists to warn about.

### BR22.13 — provisioning is atomic against a concurrent caller

`create_if_absent` is the one-shot provisioning gate (BR3.7), and it must be
**atomic**: two simultaneous attempts produce **one record and one refusal**,
never two records and never a lost one. A read-then-write implementation is not
acceptable, for the same reason BR4.9 rejects one for the revision baselines.

This matters more here than almost anywhere else in the system, because the
operation **can never be re-run once it has succeeded**. A lost provisioning on a
container with no interactive shell leaves a system nobody can sign in to and no
route that will let them.

### BR22.14 — the session store evaluates no expiry

`session.read` returns the record **as stored**, including a record past either
expiry bound. **The store holds timestamps; the consumer applies the two bounds.**

A store that filtered expired sessions would be enforcing a rule it does not own,
and the two evaluations — the store's filter and the consumer's check — would
drift into two different expiry policies with no test that compares them.

---

## The rules this unit enforces but does not declare

**Every id in this half is declared by another unit.** It is quoted here in full
so an adapter author has the rule in front of them; the declaration, and the
authority, live where the heading says.

### `ContentStore` — the combined write · declared by U4 `content-core`

**BR4.8–BR4.19 — the combined write and its side-effect guard [hazard, FR4.5].**

The single highest-risk behaviour in the system. It is one call, one caller, one
transaction, carrying the content update, the revision entry **and** the retention
prune together. The source expresses it as **seven statements in one D1 batch**,
which D1 executes as a single implicit transaction. The pure-versus-execute split —
a function that *builds* the statements and a thin executor that *runs* them —
survives the port, because that factoring is what makes the batch inspectable.

Inputs: `content`, `base_revision`, `action`, `now`, `mutation_token`, `retention`.
Derived: `serialized = serialise(content)`, `initial = serialise(<seed>)`,
`publish = (action == 'publish')`, `next_revision = base_revision + 1`.
`mutation_token` is **freshly generated per call**.

- **BR4.8 — Statement 0, bootstrap the singleton.** *(Restated structurally.)*
  Insert the content document record with the identity of the singleton, the
  `initial` payload in **both** the `draft` and the `published` columns, `revision`
  `0`, `updated_at` = `now`, and `published_at` left **NULL** — applied only when
  `base_revision = 0`, and a no-op if the record already exists.
  Two guards, both load-bearing: the `base_revision = 0` condition fires only when
  the caller claims revision 0, so **a client at revision 5 can never resurrect a
  deleted document**; the conflict-is-a-no-op behaviour makes a concurrent
  bootstrap harmless.

- **BR4.9 — Statements 1 and 2, capture the permanent baselines, once ever.**
  *(Restated structurally.)* Insert-if-absent a revision entry under the **fixed**
  identity `starting-published`, taking `revision` and `content` from the
  **current** content record's `revision` and `published` columns, `action` =
  `publish`, `created_at` = `now`, `baseline` = true — applied only while the
  content record's `revision` equals `base_revision`. Then the same again under
  the fixed identity `starting-draft`, with `action` = `draft`, taking `content`
  from the record's `draft` column.
  The **fixed primary keys** plus insert-if-absent semantics are what make each
  succeed **at most once in the document's lifetime**. They capture the
  *pre-existing* content — the state **before** this write — with `baseline = 1`.
  `created_at` is the time of capture, **not a guessed original publication
  date**; the source comment says so verbatim: *"Capture starting versions once,
  without guessing their original publication date."* The `revision = ?` guard
  means a stale writer captures nothing. **A target store without `INSERT OR
  IGNORE` semantics needs an equivalent that is genuinely idempotent under
  concurrency — not a read-then-write.**

- **BR4.10 — Statement 3, the compare-and-set. This is the concurrency control.**
  *(Restated structurally.)* Update the content record, guarded on **identity =
  the singleton AND revision = `base_revision`**, setting:

  | Column | New value |
  |---|---|
  | `draft` | `serialized` — **always** |
  | `published` | `serialized` **when** `publish`, otherwise unchanged |
  | `revision` | `revision + 1` — **unconditionally** |
  | `updated_at` | `now` |
  | `published_at` | `now` **when** `publish`, otherwise unchanged |
  | `last_mutation` | `mutation_token` |

  and returning `draft`, `published`, `revision`, `updated_at`, `published_at`
  **from the updated row**.
  **The `revision = base_revision` condition is the optimistic-concurrency
  guard**: a stale base revision matches zero rows, the update returns nothing,
  and the caller gets a conflict signal.

- **BR4.11 — Statement 4, the history insert, gated on the token.** *(Restated
  structurally.)* Insert a revision entry whose **identity is `mutation_token`**,
  whose `action` is the call's `action`, and whose `revision`, `content` and
  `created_at` are taken **from the content record itself** — its `revision`, its
  `draft` column and its `updated_at` column — with `baseline` false; applied only
  while the content record's `revision` equals `next_revision` **and** its
  `last_mutation` equals `mutation_token`.
  Three things are load-bearing. (a) The history row's **id is the mutation
  token**. (b) Its `content` is **read back from the row's `draft` column**, and
  its `created_at` from the row's `updated_at` — so the entry is byte-identical to
  **what statement 3 just wrote, not to what the caller sent**. An implementation
  that inserts the caller's payload diverges whenever validation transforms or
  defaults changed the stored value, which is **most of the time**. (c) For a
  publish, `draft` and `published` are equal, so storing `draft` is correct for
  both actions.

- **BR4.12 — Statements 5 and 6, retention, gated on the same token.** *(Restated
  structurally.)* Delete non-baseline revision entries whose `action` is `draft`,
  **except** the 30 with the highest `revision`, and only while the content
  record's `revision` equals `next_revision` **and** its `last_mutation` equals
  `mutation_token`. Then the same for `action = publish`, keeping **20**. See
  BR5.7–BR5.9 for the policy, **BR4.18 and BR22.1 for the shape**.

- **BR4.13 — the ABA scenario, concretely. This is why the token exists.**
  The `revision` CAS and the `last_mutation` token defend **different things**, and
  the second is **not redundant**:
  - `revision` (statement 3) protects **the content write**. It answers *"is the
    caller's view of the document still current?"*
  - `last_mutation` (statements 4, 5, 6) protects **the side effects**. It answers
    *"is the row in its current state because **I** put it there?"*

  The distinction matters because statements 4–6 are guarded on `revision =
  next_revision` — **a value that is not unique to this writer**:

  > The document sits at **revision 5**. Writers **A** and **B** both load
  > revision 5.
  > **B** commits first: the row advances to **revision 6**, stamped with **B's**
  > token.
  > **A's** write now runs. A's statement 3 (`WHERE revision = 5`) matches nothing —
  > **the compare-and-set correctly fails**, and A will receive a 409.
  > **But A's statements 4–6 test `revision = 6`, because A's `next_revision` is
  > also 6 — and B's write satisfies exactly that condition.**

  Without the token, therefore:
  - **Statement 4** inserts a history row keyed by **A's** mutation id, carrying
    **B's** content (it selects `draft` from the row), labelled with **A's**
    action. **A phantom revision that nobody ever saved.**
  - **Statements 5 and 6** run **A's** retention pass off the back of **B's**
    write, **pruning history A had no right to prune** — potentially deleting a
    revision B had just created.

  Adding the `last_mutation = ?` condition with a fresh random token per call
  makes all three guards test **identity rather than position**. A stale writer's
  `next_revision` may collide with the winner's `revision`; its random token will
  not. This is a classic **ABA defence**: the revision counter alone cannot
  distinguish "unchanged" from "changed to a coincidentally equal value by someone
  else", and the token supplies the missing identity.

  **What exactly the token prevents:** a losing writer recording a history entry
  that carries the winner's content under the loser's own action, and a losing
  writer executing a retention prune it was never entitled to execute. It prevents
  nothing about the content write itself — that is the CAS's job, and the CAS
  already works.

- **BR4.14 — the token is not optional, and not an optimisation.** Re-expressing
  this as "CAS on revision, then insert history, then prune" **without** the token
  reintroduces both bugs. They are **timing-dependent and will not appear in
  single-user testing**, which is the entire reason this rule is written out.
- **BR4.15 — the guard does not depend on transactional isolation.** Even under a
  runtime with weaker isolation than one implicit transaction, the token keeps
  statements 4–6 correct. Do not argue the token away on the grounds that the
  transaction already serialises the writes.
- **BR4.16 — all effects commit together or none does.** Atomicity is **required**
  of the port operation (`ContentStore.commit`). Splitting the three effects across
  separate calls or separate transactions breaks both guards.
- **BR4.17 — `results[3]` is a load-bearing positional index.** The source reads
  the CAS result as `results[3]?.results?.[0]`, by **numeric index into the batch
  array, with no comment marking it**. Statement 3 is the `UPDATE`. **Insert a
  statement anywhere before it and the write silently reads the wrong result** —
  most likely `undefined`, which the route interprets as a **409 conflict**. So a
  refactor of the batch produces spurious "this draft changed in another tab"
  errors rather than a crash. The port must read the CAS outcome by **name or by
  explicit binding, never by position**; if a positional read is unavoidable in the
  chosen driver, the index must be asserted by a test.
- **BR4.18 — the prune is expressed as read-the-survivors-then-delete-the-rest,
  inside the transaction** — **not** as a SQL predicate. Firestore has no
  `DELETE ... WHERE id NOT IN (subquery)`, and a SQL-shaped prune would be
  satisfiable by only one adapter. **This is a port-contract rule, not an
  implementation preference.**
- **BR4.19 — the retention subquery's ordering is not tiebreak-stable, and that is
  preserved.** `ORDER BY revision DESC` alone can tie: multiple rows can share a
  revision (a baseline pair plus a normal entry). **Which row survives at the
  boundary is unspecified** in the source. A faithful port uses the same ordering
  and inherits the same indeterminacy; it must not "fix" it by adding a tie-break,
  because that changes which entries survive.

> **What breaks silently across BR4.8–BR4.19.** Nothing errors and nothing logs.
> The history list grows a row the owner never saved, or loses a row it should
> have kept. It is invisible to single-user testing, invisible to coverage
> percentages, and only reproducible by two concurrent writers holding the same
> base revision.

### `ContentStore` — reading state · declared by U4

- **BR4.1** When **no document exists**, the read synthesises
  `{draft: <seed>, published: <seed>, revision: 0, updatedAt: null, publishedAt:
  null, hasUnpublishedChanges: false}` and **writes nothing**. A read must never
  create the document.

**Port consequence.** `read_state` returns the seeded document rather than
emptiness, and is a **pure read**: it takes no lock, creates no record, and
performs no bootstrap. Bootstrap belongs to `commit` alone (BR4.8), under its two
guards. An adapter that lazily creates the record on first read defeats the
`base_revision = 0` guard and lets a client at revision 5 resurrect a deleted
document.

### `ContentStore` — ordering and retention · declared by U4

- **BR5.1** The listing order is a **three-part sort**, not "newest first":
  **`revision DESC`, then `baseline ASC`, then `action DESC`.** In plain terms:
  newest revision first; within one revision, **non-baseline entries before
  baseline entries**; then **`publish` before `draft`** (descending string order).
- **BR5.2** All three parts are **load-bearing for what the owner sees**. A port
  that sorted on revision alone would list a tied revision in a different order
  **while passing any test written from a looser wording** — which is why the
  conformance suite must assert the full order.
- **BR5.3** The listing is capped at **52** entries. **This is not a page size and
  there is no pagination.** 52 is `30 drafts + 20 publishes + 2 baselines` — the
  listing limit and the retention policy are the same number **by construction**
  (BR5.7). Changing one without the other silently truncates history or shows
  nothing new.
- **BR5.4** On the Firestore adapter this order **requires a declared composite
  index**. The deployment plan must carry that index definition, and the
  conformance suite must assert the order, so a missing index **fails a test
  rather than silently reordering the list**.
- **BR5.7** Retention keeps the **30 most recent non-baseline draft entries** and
  the **20 most recent non-baseline publish entries**. The two counts are
  independent — a run of 30 drafts never evicts a publish.
- **BR5.8** The **two starting baselines are kept permanently** and are **never
  pruned**. Both retention deletes exclude `baseline = 1` explicitly; the exclusion
  is part of the delete predicate, not a coincidence of ordering.
- **BR5.9** `RevisionLedger` **owns the retention policy but performs no write**.
  It supplies the policy; `ContentAuthority` applies it inside its one combined
  write (ADR-001). `RevisionLedger`'s own store access is **read-only**. Reading
  the entity ownership table alone would suggest otherwise.

**Port consequence of BR5.9.** The retention numbers arrive at `commit` as an
**argument** — the `retention` parameter — and are never constants inside an
adapter. An adapter that hard-codes 30 and 20 has taken ownership of a policy it
does not own, and the two places will drift the first time the policy changes.

### `AssetStore` and asset metadata · declared by U5 `media`

- **BR6.24** Bytes and metadata are **two separate non-transactional writes** with
  no shared transaction. On **any** exception, every key written so far is deleted
  from **both** stores, under a gather-all-results primitive so one failed delete
  does not abort the rest. Cleanup is explicitly **best-effort** — it holds only
  while the handler reaches its cleanup path. *(This unit's obligation under it is
  BR22.10.)*
- **BR7.17** Ranged reads are performed **through the store port**
  (`AssetStore.get_range`), never by loading the whole object and slicing —
  loading a whole video to serve one range is precisely what the port exists to
  avoid. The 206 response shape it belongs to is U5's. *(This unit's obligation
  under it is BR22.11.)*
- **BR7.18** Every successful media response carries `Content-Type` **from the
  metadata row's media type, not from the object store**, alongside the object's
  entity tag and size. The two stores hold the media type independently and agree
  only because they are written from the same value at upload time; **anything
  that syncs only one will serve mismatched types.** *(This unit's obligation
  under it is BR22.12.)*

### `IdentityStore` · declared by U3 `identity-and-session`

- **BR3.6** Credential verification answers **only whether the supplied password
  matched**, never why it did not, and never whether the account exists. The
  argon2id hash is never returned by any operation and never logged.
  **Port consequence:** `owner_record.read` is the one operation that returns the
  stored hash, and it returns it to the verifying component only. The store never
  compares, parses, derives from or logs it.
- **BR3.7** Initial-owner provisioning is **one-shot**, and its gate is **the
  existence of the owner record** — not a consumed flag, not a file, not an
  environment marker. A container restart therefore cannot reopen it. *(This
  unit's obligation under it is BR22.13.)*
- **BR3.16** Verification returns the owner identity **or nothing**. A session with
  a non-null `revokedAt`, or past either expiry bound, verifies as nothing. *(This
  unit's obligation under it is BR22.14.)*
- **BR3.17** Sign-out revokes **server-side**, so a stolen cookie stops working
  rather than merely disappearing from one browser. Clearing the cookie alone does
  not satisfy this rule.
  **Port consequence:** `session.revoke` writes to the record. It is not a
  client-side action and not a cache eviction, and a revoked session must fail the
  very next `session.read`.
- **BR3.22** Counters are **persisted**, so a process restart does not reset a
  window. An in-memory counter is not an acceptable implementation.
  **Port consequence:** `login_attempts` is a durable shape in the real adapter.
  The in-memory fake is exempt **only** in the sense that its whole store is
  in-memory; it must still behave identically within a process lifetime.

---

## Rules summary

**Declared by this unit.**

| Id | Category | Applies to | In one line |
|---|---|---|---|
| BR22.1 | policy | `commit` | Per-action survivor selection, one transaction, baselines by predicate |
| BR22.2 | constraint | `list_revisions` | Not paginated; a cursor over a tied order repeats or skips |
| BR22.3 | constraint | the fake | The fake computes the order rather than inheriting it |
| BR22.4 | policy | all ports | One suite, two implementations, always |
| BR22.5 | constraint | `ContentStore` | Payloads round-trip byte-identically |
| BR22.6 | constraint | all ports | The store validates nothing and defaults nothing |
| BR22.7 | policy | every adapter | A blocking driver never leaves the adapter |
| BR22.8 | policy | `commit` (document store) | Blob first, transaction second — and the cost is stated |
| BR22.9 | policy | any indexed adapter | A declared index is a deliverable |
| BR22.10 | policy | `delete` / `remove` | Idempotent, and for the cleanup path alone |
| BR22.11 | constraint | `get_range` | Transfer only the requested bytes; the arithmetic is the caller's |
| BR22.12 | constraint | `head` / `asset_metadata.read` | Two independent media types; do not reconcile |
| BR22.13 | constraint | `create_if_absent` | One record, one refusal, atomically |
| BR22.14 | constraint | `session.read` | The store evaluates no expiry and filters nothing |

**Enforced here, declared elsewhere.**

| Id | Declared by | In one line |
|---|---|---|
| BR4.1 | U4 | Empty storage returns the seed and writes nothing |
| BR4.8–BR4.12 | U4 | The six effects of the combined write and their guards |
| BR4.13–BR4.15 | U4 | The token is an ABA defence, not optional, not isolation-dependent |
| BR4.16 | U4 | All effects commit together or none does |
| BR4.17 | U4 | Read the CAS result by name, never by position |
| BR4.18 | U4 | Prune = read survivors, then delete the rest |
| BR4.19 | U4 | The retention tie is indeterminate and stays that way |
| BR4.20 | U4 | The cap counts characters, which is why the payload can exceed 4 MB |
| BR5.1–BR5.4 | U4 | The three-part order, its cap, and the index it needs |
| BR5.7–BR5.9 | U4 | 30 and 20 independently, baselines forever, policy as an argument |
| BR9.2 | U4 | The content-carrying defaults run on every parse, in the consumer |
| BR6.24 | U5 | Two non-transactional writes; best-effort cleanup across both stores |
| BR7.17 | U5 | Ranged reads go through the port |
| BR7.18 | U5 | The response type comes from the metadata row |
| BR3.6 | U3 | The hash is opaque, never logged |
| BR3.7 | U3 | The provisioning gate is the record's existence |
| BR3.16 | U3 | Identity or nothing — the consumer decides, not the store |
| BR3.17 | U3 | Revocation is a stored state change |
| BR3.22 | U3 | Counters survive a restart |

---

## What is deliberately NOT here

Stated explicitly so a reader can tell a deliberate omission from an oversight:

- **BR5.5, BR5.6, BR5.10** — revision-id validation, restore-never-publishes, and
  the 404-with-reassurance. Consumer rules. `read_revision` takes an id and
  returns the entry or absence; it validates no pattern and chooses no status.
- **BR4.2 through BR4.7, BR4.21–BR4.22** — the computed change flag, draft/publish
  semantics, authoritative validation, the cap's unit and position. Consumer
  rules; the store stores what it is handed.
- **BR3.11–BR3.15, BR3.18–BR3.21** — the cookie, the signing key, the expiry
  arithmetic and the thresholds. The store holds timestamps and counts; it
  evaluates neither.
- **BR7.3–BR7.16** — key validation, the asset-visibility rule and every range
  branch. The store serves bytes by key; public-ness is not a storage concept.
- **BR6.1–BR6.23** — everything about accepting an upload. The store never
  inspects a byte it is given.

---

## Assumptions & Open Questions

- **[assumption]** `BR22.1`–`BR22.14` are **new ids introduced by this unit**, in
  the unit-scoped group for U2 (unit number + 20). **No existing id is renumbered,
  reused or reinterpreted**, and this unit **declares no `BR3.*`, `BR4.*`,
  `BR5.*`, `BR6.*`, `BR7.*` or `BR9.*` id** — those are declared by U3, U4 and U5
  and are quoted here under their owners. Each `BR22` id carries `source: none`,
  names in a separate `enables` field the requirement it serves and the owning
  rule and unit that discharge it, and is reported in the traceability `reverse`
  array — **all fourteen of them, with `coverage` empty**.
- **[assumption]** Where a statement body is **restated structurally** rather than
  in the source's dialect, that is a reading aid for an adapter author, made
  necessary by BR4.18. Every guard, binding and returned column is preserved.
  **The literal statements remain in `construction/functional-design/rules.md`
  and in U4's `rules.md`** and are the transcription of record; if the two ever
  disagree, the literal wins and this restatement is the defect.
- **[open, carried from `contract-design`, owner U11]** The document-store
  adapter's large-payload threshold and its orphan-sweep decision are both unset.
- **[open, carried from `contract-design`, owner U11 / U12]** Where the composite
  index definition lives so it is not lost between the adapter and the plan.
- **[carried hedge]** BR4.19's indeterminacy is **preserved, not resolved**. The
  conformance suite therefore cannot assert *which* entry survives a tie at the
  retention boundary — only that the counts are right and that baselines survive.
  An adapter is free to be deterministic; it may not be *differently* deterministic
  in a way the suite would have to encode, because encoding it would turn an
  inherited indeterminacy into a specified behaviour nobody decided.
- **[note]** BR4.16's atomicity requirement and BR22.8's weakened cloud guarantee
  are in tension by construction. The tension is resolved by scope, not by
  argument: the verified adapter gives full atomicity; the unverified one gives
  atomicity plus an idempotent pre-write. Both are stated so a reader cannot
  mistake the second for the first.
- **[note]** No rule in this unit requires a background worker, scheduler or queue
  consumer. Retention runs **inside the write that triggers it**.

## Sources

- `construction/functional-design/rules.md` — BR3.6, BR3.7, BR3.16, BR3.17,
  BR3.22, BR4.1, BR4.8–BR4.20, BR5.1–BR5.9, BR6.24, BR7.17, BR7.18, BR9.2, quoted
  with their ids and their full text and attributed to their declaring units.
- `inception/contract-design/contract-summary.md` §§ C2 (`commit`, `prune_shape`,
  `atomicity`, `payload_size`, `list_revisions`, `conformance`), C3, C4,
  *Contract ownership rules*, *Open questions*, *Assumptions & Open Questions*.
- `inception/domain-design/decisions.md` ADR-001 — one combined write.
- `inception/units-generation/unit-of-work.md` § U2 — owns, delivers, boundary,
  constraints.
- `aidlc/spaces/default/memory/team.md` § *Testing Posture* — the
  adapter-parameterised conformance suite run against two implementations, and the
  reason two is the minimum.
- `WORKING-RECORD.md` §§ 2 (D4), 3 (FR4.5), 5.
