# Business Rules — U3 `identity-and-session`

**Unit:** `u3-identity-and-session` · **Kind:** `library` · **Components:**
`OwnerIdentity`, `SessionAuthority`, `LoginGuard`

**Upstream:** `construction/functional-design/rules.md` (the rule ids and their
text), `inception/requirements-analysis/requirements.md` FR3.1–FR3.8, NFR2, NFR5,
`inception/domain-design/components.md` (rule ownership),
`inception/contract-design/contract-summary.md` § C3,
`inception/units-generation/unit-of-work.md` § U3, `WORKING-RECORD.md` § 2
(D1, D2, D3, D6), companion artifacts `entities.md` and `functional-spec.md`.

## How to read this document

Every rule here is something **an implementation could get wrong**. Rules the type
system already enforces are deliberately absent: "`scope` must be one of two
values" is a schema constraint and lives in `entities.md`, not here.

`BR{n}.{m}` ids are **stable and unchanged**. The major number tracks the
requirement family — `BR3.*` are FR3 rules. Ids are assigned once and do not move;
nothing in this unit-scoped file renumbers, merges or splits a rule from
`construction/functional-design/rules.md`. This file is that split, not a rewrite.

**19 rules declared, 0 of which are hazard rules.** The seven hazard groups are
FR4.5, FR6.2, FR7.2, FR7.4, FR8.3, FR9.2 and FR10.1 — **none of them is an FR3
rule**. That follows from everything in this unit being **new**: the source
authenticated through a platform header and had no identity of its own, and a
hazard in this project is a behaviour whose *silent* loss during a port ships a
defect. There is nothing here to lose.

**That is not a claim that these rules are low-risk.** BR3.13 stops the process at
boot and BR3.20 is an account-enumeration defence; both are severe if wrong. They
simply fail **loudly** rather than silently, which is why none of them needs the
branch-by-branch treatment the hazard groups get. It also means **there is no
recorded source fixture for anything in this unit, and none can be made** — every
rule below is a decision recorded at a gate, not a behaviour observed in the
source.

**Rule index for this unit**

| Component | Rules | Count | Of which hazard |
|---|---|---|---|
| `OwnerIdentity` | BR3.6–BR3.10 | 5 | — |
| `SessionAuthority` | BR3.11–BR3.17 | 7 | — |
| `LoginGuard` | BR3.18–BR3.22 | 5 | — |
| Unit-scoped, **trace to no FR** | BR23.1–BR23.2 | 2 | — |
| *Subject to, owned by `HttpApi` (U6)* | BR3.1–BR3.5 | 5 | — |

**On the BR3 split.** The family divides on a real line rather than a convenient
one. **Credential, session-lifetime and rate-limit rules are decisions this unit
makes** — BR3.6 through BR3.22. **BR3.1–BR3.5 are HTTP-surface rules** — "every
operation authorises itself", the same-origin predicate and the CSRF double-submit
— and they are owned by `HttpApi` and specified in
`construction/http-api/functional-design/rules.md`. This unit's operations are
**enforced by** them; it does not implement them. They are quoted below under
*Subject to, not owned* because BR3.2 explicitly delegates the authorization
decision to the component behind the route, and this unit **is** that component: a
reader who has only one half sees the delegation without what is delegated, or the
check without the prohibition on duplicating it.

**On the BR23 group.** `BR23.1` and `BR23.2` are the unit-scoped allocation
(**U3 + 20**) reserved for rules that realise only a constraint and **trace to no
FR**; there are two, and both are listed in the traceability `reverse` array with
their reasons.

**Structure of this document.** The fenced `yaml` block below is the **source of
truth**: it governs, and it is what downstream stages read. The prose sections
after it carry the **rationale and the failure mode** for each rule. **The prose
must not contradict the block; where it appears to, the block wins and the prose is
a defect.**

---

## Source of truth

```yaml
source_of_truth: rules
stage: functional-design
unit: u3-identity-and-session
kind: library
kind_note: >
  U3 identity-and-session is a LIBRARY, not a service. U6 http-api is the only unit
  declaring service - there is exactly one deployed Python executable. This unit is
  embedded in it and is not independently deployable.
authority: >
  This block is the source of truth and governs. The prose sections below carry the
  rationale and the failure mode for each rule and must not contradict this block.
components: [OwnerIdentity, SessionAuthority, LoginGuard]
rule_count: 19
id_format: 'BR{group}.{seq}; source ids are FR{n} / FR{n}.{m} / NFR{n} as spelled in requirements-analysis'
unit_scoped_group: >
  BR23 is the unit-scoped allocation for U3 (unit number + 20), reserved for rules
  that realise only a constraint and trace to no FR. There are two, and both are
  listed in the traceability reverse array with their reasons.
hazards: []   # none of the seven hazard groups is an FR3 group; everything in this unit is new
nature_note: >
  All three components and all three entities are NEW. The source authenticated
  through a platform header and had no identity of its own, so there is no parity
  obligation here and no recorded source fixture - and none can be made.
rules:

  - id: BR3.6
    statement: >
      Credential verification answers only whether the supplied password matched, never why
      it did not, and never whether the account exists. The argon2id hash is never returned
      by any operation and never logged.
    category: authorization
    applies_to: OwnerIdentity
    trigger: A sign-in attempt.
    logic: >
      IF verification runs THEN return a yes or a no. Do not return or log the argon2id hash
      through any operation, and do not distinguish "no such account" from "wrong password"
      in anything the caller can observe.
    violation: Account enumeration, and exposure of the system's highest-value datum.
    source: FR3.1

  - id: BR3.7
    statement: >
      Initial-owner provisioning is one-shot, and its gate is the existence of the owner
      record - not a consumed flag, not a file, not an environment marker. A container
      restart therefore cannot reopen it.
    category: authorization
    applies_to: OwnerIdentity
    trigger: A provisioning attempt.
    logic: >
      IF an owner record exists THEN refuse, permanently. The gate condition is evaluated
      against the record itself on every attempt, so no state outside the record can reopen
      it.
    violation: A flag-based or file-based gate reopens on restart, on a public route.
    source: FR3.6, FR3.7
    source_note: >
      Cited FR3.7 alone until a corpus-wide coverage audit found FR3.6 discharged by
      no rule anywhere. FR3.6 is "Exactly one owner account exists. No multi-editor
      accounts, no tiered editor/publisher roles" - and THIS rule is what enforces
      it: refusing provisioning whenever an owner record exists is the mechanism
      that makes "exactly one" true at runtime, with the entity model (a single
      fixed-id OwnerAccount record) supplying the other half. The omission was not
      a missing behaviour; it was a missing citation, which is worse in one respect
      - it made a satisfied requirement read as unrealised.

  - id: BR3.8
    statement: >
      The provisioning route is enabled only while BOTH hold: no owner record exists AND the
      bootstrap secret is configured. It requires that secret, accepts the owner's chosen
      password, and stores only its argon2id hash.
    category: authorization
    applies_to: OwnerIdentity
    trigger: Startup, and every provisioning request.
    logic: >
      IF no owner record exists AND the bootstrap secret is set THEN enable the route and
      require the secret on it. ELSE the route does not exist at all.
    violation: An open provisioning route on a live system.
    source: FR3.7

  - id: BR3.9
    statement: >
      With the bootstrap secret unset and no owner present, the service starts normally and
      refuses every sign-in rather than creating an account.
    category: policy
    applies_to: OwnerIdentity
    trigger: Startup with no owner record and no bootstrap secret.
    logic: >
      IF no owner exists AND no bootstrap secret is set THEN start normally and refuse every
      sign-in. Do NOT create an account, and do NOT fail to start.
    violation: >
      Auto-creating an account to "make it work" is exactly the default credential FR3.7
      forbids; refusing to start turns a recoverable configuration state into an outage.
    source: FR3.7

  - id: BR3.10
    statement: >
      No default, seeded, sample or hard-coded credential exists anywhere in the source tree.
    category: constraint
    applies_to: OwnerIdentity, its fixtures, its schema setup
    trigger: Any build, any fresh start.
    logic: >
      The acceptance test is exactly: a fresh docker compose up against an empty volume has
      NO account anyone can sign in to.
    violation: A shipped credential, which is the single worst outcome available here.
    source: FR3.7

  - id: BR3.11
    statement: >
      A successful sign-in issues a SIGNED session cookie marked HttpOnly, Secure and
      SameSite=Lax.
    category: constraint
    applies_to: SessionAuthority
    trigger: A successful sign-in.
    logic: >
      IF sign-in succeeds THEN set a signed cookie carrying the session identifier, with all
      three attributes present. The cookie carries the identifier ONLY - no field of the
      session is encoded into it and no claim in it is trusted.
    violation: >
      A readable or cross-site-submittable cookie makes every other session rule weaker than
      it looks; a self-describing token cannot be revoked at all.
    source: FR3.2

  - id: BR3.12
    statement: >
      A CSRF token is issued paired 1:1 with the session and verified on every mutation as a
      request header (double-submit).
    category: authorization
    applies_to: SessionAuthority
    trigger: Session issue, and every mutation.
    logic: >
      IF a session is issued THEN generate a token paired with it and return it in the
      response BODY. IF a mutation arrives THEN compare the request header against that
      session's token; a mismatch is a refusal.
    violation: >
      A token carried in a cookie is submitted automatically by the browser and defends
      nothing.
    source: FR3.2

  - id: BR3.13
    statement: >
      The signing key is a startup precondition: if SESSION_SIGNING_KEY is unset, empty, or
      under 32 bytes, the backend raises during startup with a message naming the variable
      and exits non-zero. No default value, no fallback, and explicitly no auto-generated
      per-process key.
    category: constraint
    applies_to: startup
    trigger: Process start, before any request exists.
    logic: >
      IF the variable is unset OR empty OR under 32 bytes THEN raise, name the variable, and
      exit non-zero. All three conditions are checked separately; a present-but-short key is
      the one a naive check misses and the one a human is most likely to produce by hand.
    violation: >
      An auto-generated key silently invalidates every session on restart and hides the
      misconfiguration - the worse failure, because it looks like it works.
    source: NFR5

  - id: BR3.14
    statement: A session expires after 8 hours idle, and the idle window slides.
    category: constraint
    applies_to: SessionAuthority
    trigger: Every verified request.
    logic: >
      IF the time since lastSeenAt exceeds 8 hours THEN the session is expired. ELSE advance
      lastSeenAt to now.
    violation: A session that never expires while a tab is open, or one that expires mid-use.
    source: FR3.3

  - id: BR3.15
    statement: >
      A session expires 7 days after issue, absolutely, regardless of activity.
      absoluteExpiresAt is computed once at issue and NEVER extended by a touch. Both bounds
      are enforced; whichever is reached first ends the session.
    category: constraint
    applies_to: SessionAuthority
    trigger: Every verification.
    logic: >
      IF now is past absoluteExpiresAt THEN the session is expired, however recently it was
      used. A touch advances the idle timestamp ONLY.
    violation: >
      A touch that refreshes both timestamps destroys the 7-day bound while every idle-expiry
      test still passes - the only test that separates the two designs runs for more than
      seven days of simulated time.
    source: FR3.3

  - id: BR3.16
    statement: >
      Verification returns the owner identity or nothing. A session with a non-null revokedAt,
      or past either expiry bound, verifies as nothing.
    category: authorization
    applies_to: SessionAuthority
    trigger: Every request carrying a session cookie.
    logic: >
      IF revokedAt is non-null OR now is past the idle bound OR now is past the absolute
      bound THEN verify as nothing. ELSE return the owner identity. There is no third answer.
    violation: >
      A three-valued result invites a caller to treat "expired" differently from "absent" - a
      distinction no caller needs and an attacker can use.
    source: FR3.3, FR3.4

  - id: BR3.17
    statement: >
      Sign-out revokes server-side, so a stolen cookie stops working rather than merely
      disappearing from one browser. Clearing the cookie alone does not satisfy this rule.
    category: authorization
    applies_to: SessionAuthority
    trigger: Sign-out.
    logic: >
      IF the owner signs out THEN write the revocation instant to the stored session record,
      AND clear the cookie. The stored revocation is what makes the session dead everywhere.
    violation: A stolen cookie that keeps working after the owner signed out.
    source: FR3.4

  - id: BR3.18
    statement: Failed sign-in is refused beyond 5 attempts per account per 15 minutes.
    category: policy
    applies_to: LoginGuard
    trigger: A sign-in attempt.
    logic: >
      IF this account has 5 or more failures inside the current 15-minute rolling window THEN
      refuse.
    violation: Unbounded credential guessing against the one account that matters.
    source: FR3.5

  - id: BR3.19
    statement: >
      Independently, failed sign-in is refused beyond 20 attempts per source address per 15
      minutes. The two counters are separate and both apply.
    category: policy
    applies_to: LoginGuard
    trigger: A sign-in attempt.
    logic: >
      IF this source address has 20 or more failures inside the current 15-minute rolling
      window THEN refuse, independently of the account counter and regardless of it.
    violation: >
      One counter alone leaves either distributed guessing or a single-source flood unbounded.
    source: FR3.5

  - id: BR3.20
    statement: >
      The refusal is indistinguishable from an ordinary credential failure: same status, same
      body, same sentence, whether the account is unknown, the password is wrong, or the limit
      was reached. Do not add a "too many attempts" message or a Retry-After header - either
      one enumerates.
    category: authorization
    applies_to: LoginGuard
    trigger: Any refused sign-in.
    logic: >
      IF a sign-in is refused for ANY reason THEN return the same status, the same body and
      the same sentence. It reveals neither that an account exists nor that a limit was hit.
    violation: >
      With exactly one account in the system, a distinguishable rate-limit message tells an
      attacker that the email they submitted is the owner's - the single fact the entire
      enumeration defence exists to withhold.
    source: FR3.5

  - id: BR3.21
    statement: A successful sign-in clears that account's counter.
    category: policy
    applies_to: LoginGuard
    trigger: A successful sign-in.
    logic: IF sign-in succeeds THEN clear the account-scoped counter for that account.
    violation: >
      The owner is locked out by their own earlier typos after they have already proved who
      they are.
    source: FR3.5

  - id: BR3.22
    statement: >
      Counters are persisted, so a process restart does not reset a window. An in-memory
      counter is not an acceptable implementation.
    category: constraint
    applies_to: LoginGuard
    trigger: Every recorded failure, and every process restart.
    logic: IF the process restarts THEN the window does not reset.
    violation: >
      An attacker resets the limit by causing a restart, and the rate limit becomes
      decorative.
    source: FR3.5

  - id: BR23.1
    statement: >
      Verification cost does not depend on whether the account exists: a password hash is
      always verified, against a fixed dummy hash when there is no owner record.
    category: policy
    applies_to: OwnerIdentity
    trigger: Every sign-in attempt.
    logic: >
      IF no owner record exists THEN still run an argon2id verification against a fixed dummy
      hash and discard the result. Return failure either way, so absence and wrong-password
      cost the same.
    violation: >
      BR3.20 governs the BODY, not the clock. argon2id is deliberately slow, so skipping it
      for an unknown account returns measurably faster and enumerates just as effectively -
      without a single byte of the response differing.
    source: none   # traces to no FR; BR3.20 fixes the body, nothing fixes the timing

  - id: BR23.2
    statement: >
      A session record found to be past either expiry bound at verification is deleted as it
      is rejected.
    category: policy
    applies_to: SessionAuthority
    trigger: A verification that finds an expired record.
    logic: >
      IF verification finds a record past its idle or absolute bound THEN reject the request
      AND delete the record. The deletion is housekeeping: it never changes the verification
      outcome, and a failed delete never turns a rejection into an acceptance.
    violation: >
      Expired records accumulate with nothing to reclaim them. This is the ONLY reclamation
      path specified anywhere in the unit, and it reclaims only the records that are
      revisited.
    source: none   # traces to no FR; housekeeping with no requirement behind it

replaces_note: >
  VERIFIED BY EXECUTION. The source had no identity table and no credential: a
  vendored dev-server middleware injected a fixed user id and email as request
  headers on seeing one cookie, and it STRIPPED every client-supplied identity
  header before injecting its own - sending those headers directly still returned
  403. The trust boundary was therefore the middleware, not the header. The property
  this unit preserves is "a client cannot assert its own identity", carried now by
  the signed cookie and its server-side verification, NOT the header mechanism.

rules_subject_to_but_not_owned:
  - { id: BR3.1, owner_unit: u6-http-api, why: 'Every protected read and mutation authorises itself at its own operation; BR3.2 delegates that decision to THIS unit, which is what makes it enforceable off the HTTP path' }
  - { id: BR3.2, owner_unit: u6-http-api, why: 'HttpApi enforces nothing beyond transport - the naming of this unit as the decision-maker is the other half of BR3.1' }
  - { id: BR3.3, owner_unit: u6-http-api, why: 'Origin must be present and exactly equal; a missing header FAILS. Applies to this unit''s sign-in, sign-out and provisioning mutations' }
  - { id: BR3.4, owner_unit: u6-http-api, why: 'The CSRF double-submit added on top of BR3.3; this unit issues and stores the token per BR3.12, the route layer compares it' }
  - { id: BR3.5, owner_unit: u6-http-api, why: 'Origin applies to mutations only - which in this unit means the auth mutations and never a session read' }
  - { id: BR10.7, owner_unit: u6-http-api, why: 'The verbatim error copy; this unit raises the not-authorized member and U6 renders the sentence, which for every refusal here is the sign-in one' }
  - { id: BR10.8, owner_unit: u6-http-api, why: 'That sentence carries U+2019 RIGHT SINGLE QUOTATION MARK, verified byte-for-byte against the running source; a straight apostrophe fails the parity diff' }
```

---

## Subject to, not owned — `HttpApi` (U6)

**These five are declared in `construction/http-api/functional-design/rules.md`.**
They are quoted in full here because BR3.2 delegates the authorization decision to
this unit, and a reader implementing `SessionAuthority` needs to see both halves.

### BR3.1–BR3.2 — authorization at the operation boundary [FR3.8, NFR2]

- **BR3.1** Every protected read and every mutation authorises itself **at its own
  operation**, never by the route's placement, a protected layout, a hidden control
  or a frontend route rule. A request that bypasses the frontend entirely is
  rejected identically to one that does not.
- **BR3.2** `HttpApi` enforces nothing beyond transport concerns. The authorization
  decision belongs to the component behind the route.

> **BR3.1 is the requirement behind reviewer finding R-01.** The intent statement
> asserted "a request that bypasses the front end is still rejected" and cited two
> sources, neither of which says it. **The disposition recorded at the
> re-composition gate: the behaviour is real and it is NFR2, which *is* grounded
> and *is* tested. The citation was wrong, not the requirement.** It is restated
> here because this unit is where that rejection actually happens.

### BR3.3–BR3.5 — same-origin and CSRF on mutations [FR6.7, D1]

- **BR3.3** Origin enforcement on mutations reproduces the source predicate: the
  request's `Origin` header must be **present** and **exactly equal** to the request
  URL's own origin. **A missing `Origin` header fails the check** — it is not treated
  as same-origin. This is the source's only CSRF defence.
- **BR3.4** The port **adds** a CSRF token (double-submit) paired with the session,
  on top of BR3.3 (D1). The origin check is not replaced by it.
- **BR3.5** In the source, origin is checked on **2 of 6** endpoint/method pairs —
  `PUT /api/content` and `POST /api/upload` only. The port applies it to
  **mutations**, which is the same set plus the new authentication mutations. It is
  never applied to `GET`/`HEAD`.

### BR10.7–BR10.8 — the refusal sentence this unit produces [FR10.2]

Every refusal in this unit — unknown account, wrong password, limit reached, an
unverifiable session — renders as one sentence, and it is **product copy under the
parity rule**:

```
{"error":"Please sign in with the website owner’s account."}
```

**The apostrophe is U+2019 RIGHT SINGLE QUOTATION MARK, not ASCII.** This was
**captured verbatim from the running source**, and the human answered *"Match
exactly — characters"* on error-copy parity. A parity diff against the recorded
fixtures compares bytes, so a straight `'` fails it — and a port that writes
`owner's` has changed what the owner sees.

**This unit does not compose that sentence.** It raises the not-authorized member
of the taxonomy and `HttpApi` renders it (BR10.3: services raise, routers do not
build responses). It is recorded here because it is the sentence every refusal in
this unit produces, and because the byte-level detail is the kind that survives
only if someone writes it down.

---

## What this unit replaces — the trust boundary, verified by execution

**The source had no identity table, no account row and no credential.** Confirmed
by booting it rather than by reading it: a **vendored dev-server middleware**
injected a fixed user id and email as request headers on seeing one cookie.

**The load-bearing detail is what the middleware did first.** It **stripped every
client-supplied identity header before injecting its own** — sending those headers
directly still returned 403. **The trust boundary was the middleware, not the
header.**

**So the property being preserved is "a client cannot assert its own identity",
not the header mechanism.** In the new system that property is carried by BR3.11's
signed cookie holding **only an opaque session identifier**, plus BR3.16's
server-side verification on every request. A port that accepted an identity claim
from anything the client controls would satisfy the letter of "replace the platform
auth" and lose the only security property the old mechanism had.

This is also **why BR3.11's cookie carries no claims and why `sessionId` is never
derived from a user-supplied value**: a derivable identifier is a client-assertable
identity, which is exactly the thing the old middleware existed to prevent.

---

## `OwnerIdentity`

### BR3.6–BR3.10 — credentials and one-shot provisioning [FR3.1, FR3.7]

- **BR3.6** Credential verification answers **only whether the supplied password
  matched**, never why it did not, and never whether the account exists. The
  argon2id hash is never returned by any operation and never logged.
- **BR3.7** Initial-owner provisioning is **one-shot**, and its gate is **the
  existence of the owner record** — not a consumed flag, not a file, not an
  environment marker. A container restart therefore cannot reopen it.
- **BR3.8** The provisioning route is enabled only while **both** hold: no owner
  record exists **and** the bootstrap secret is configured. It requires that secret,
  accepts the owner's chosen password, and stores only its argon2id hash.
- **BR3.9** With the bootstrap secret unset and no owner present, the service
  **starts normally and refuses every sign-in** rather than creating an account.
- **BR3.10** No default, seeded, sample or hard-coded credential exists anywhere in
  the source tree. The acceptance test is exactly: **a fresh `docker compose up`
  against an empty volume has no account anyone can sign in to.**

> **Why BR3.7's gate is the record rather than a flag.** Every other formulation
> has a state that can be reset from outside the data: a consumed flag can be
> flipped, a marker file can be deleted with the volume, an environment variable
> can be re-set by the next deployment. **The record is the only state whose
> existence is the thing being protected.** A restart, a redeploy and a fresh
> container all leave it exactly where it was.

> **BR3.9 is a deliberate non-failure**, and it is worth separating from BR3.13.
> A missing **signing key** stops the process (BR3.13). A missing **bootstrap
> secret** does not, because "no secret, no owner" is a legitimate state — an
> already-provisioned system that no longer needs the route, or one being
> provisioned another way. The asymmetry is decided, not accidental.

### BR23.1 — verification cost does not depend on the account existing

**BR3.20 governs the body; it does not govern the clock.** A sign-in against a
non-existent account that returns without hashing anything returns measurably
faster than one that verifies a real argon2id hash — and argon2id is *deliberately*
slow, so the gap is large, not marginal. An attacker who can time two requests
learns which email is the owner's, which is exactly what BR3.6 and BR3.20 exist to
prevent, **without a single byte of the response differing**.

**The rule:** always run a verification. When no owner record exists, verify the
submitted password against a **fixed dummy argon2id hash** and discard the result.
Absence and wrong-password then cost the same.

**Carried hedge:** this is **the standard mitigation, and it is not separately
measured**. It equalises the dominant cost; it does not prove the absence of every
timing signal, and no artifact in this workflow claims a measurement. Recorded as
a mitigation rather than as a guarantee.

---

## `SessionAuthority`

### BR3.11–BR3.13 — the session cookie and its signing key [FR3.2, NFR5]

- **BR3.11** A successful sign-in issues a **signed** session cookie marked
  `HttpOnly`, `Secure` and `SameSite=Lax`.
- **BR3.12** A CSRF token is issued **paired 1:1 with the session** and verified on
  every mutation as a request header (double-submit).
- **BR3.13** The signing key is a **startup precondition**: if
  `SESSION_SIGNING_KEY` is unset, empty, or under 32 bytes, the backend raises
  during startup with a message naming the variable and exits non-zero. **No default
  value, no fallback, and explicitly no auto-generated per-process key** — an
  auto-generated key silently invalidates every session on restart and hides the
  misconfiguration, which makes it the worse failure because it looks like it works.

> **BR3.13 is the one rule in this unit that fires before any request exists.** The
> three failure conditions are separate and all three are checked: **unset**,
> **empty**, and **under 32 bytes**. A present-but-short key is the one a naive
> check misses, and it is the one a human is most likely to produce by hand — which
> is also why the key is **generated, never chosen**.

> **BR3.12's token goes in the response body, never in a cookie.** A double-submit
> defence works because the attacker's page cannot *read* the token to echo it into
> a header; a token the browser attaches automatically to every cross-site request
> defends nothing at all. This is the one detail of the CSRF design that looks like
> an implementation choice and is not.

### BR3.14–BR3.17 — expiry and revocation [FR3.3, FR3.4, D2]

- **BR3.14** A session expires after **8 hours idle**. The idle window **slides**:
  each verified request advances `lastSeenAt`.
- **BR3.15** A session expires **7 days after issue, absolutely**, regardless of
  activity. `absoluteExpiresAt` is computed once at issue and **never extended by a
  touch**. Both bounds are enforced; whichever is reached first ends the session.
- **BR3.16** Verification returns the owner identity **or nothing**. A session with a
  non-null `revokedAt`, or past either expiry bound, verifies as nothing.
- **BR3.17** Sign-out revokes **server-side**, so a stolen cookie stops working
  rather than merely disappearing from one browser. Clearing the cookie alone does
  not satisfy this rule.

> **BR3.14 and BR3.15 are the pair an implementation collapses by accident.** The
> tempting simplification is one expiry timestamp refreshed on use. That satisfies
> BR3.14 exactly and destroys BR3.15 completely — and **every test written against
> idle expiry still passes**, because a session used every hour never reaches the
> idle bound in either design. The only test that separates them runs for more than
> seven days of simulated time. This is the closest thing in this unit to a silent
> failure, which is why it is called out even though FR3.3 is not a hazard group.

### BR23.2 — an expired session record is deleted as it is rejected

Verification that finds a record past either bound rejects the request **and
deletes the record**. The deletion is housekeeping: it never changes the
verification outcome, and a failure to delete never turns a rejection into an
acceptance.

**This is the only reclamation path specified anywhere in the unit**, and it only
reclaims sessions that are revisited. Revoked records, and expired records that are
never touched again, accumulate. For a single-owner site the volume is negligible,
which is why it is recorded as an open item rather than raised as a defect — see
`## Assumptions & Open Questions`.

---

## `LoginGuard`

### BR3.18–BR3.22 — bounding failed sign-in [FR3.5, D3]

- **BR3.18** Failed sign-in is refused beyond **5 attempts per account per 15
  minutes**.
- **BR3.19** Independently, failed sign-in is refused beyond **20 attempts per
  source address per 15 minutes**. The two counters are separate and both apply.
- **BR3.20** The refusal is **indistinguishable from an ordinary credential
  failure**: same status, same body, same sentence, whether the account is unknown,
  the password is wrong, or the limit was reached. It reveals neither that an account
  exists nor that a limit was hit. **Do not add a "too many attempts" message or a
  `Retry-After` header** — either one enumerates.
- **BR3.21** A **successful** sign-in clears that account's counter.
- **BR3.22** Counters are **persisted**, so a process restart does not reset a
  window. An in-memory counter is not an acceptable implementation.

> **BR3.20 is the rule most likely to be "improved" by a well-meaning reviewer.**
> Every mainstream guidance document recommends telling a user they have been rate
> limited, and a `Retry-After` header is a standards-blessed courtesy. **Both are
> wrong here**, and for a specific reason: this system has **exactly one account**.
> A message that distinguishes "rate limited" from "wrong password" tells an
> attacker that the email they submitted is the owner's — the single fact the
> entire enumeration defence exists to withhold. The usual advice assumes many
> accounts and a user who needs help; here the only user is the owner, who knows
> their own password, and the only other caller is an attacker.

> **BR3.18 and BR3.19 bound different attacks and neither substitutes for the
> other.** The account limit bounds guessing against the one account that matters,
> however many addresses it comes from. The address limit bounds a flood from one
> source, whatever it is aimed at. A design with only the first is defeated by
> patience; with only the second, by a botnet.

---

## Rules summary

| Id | Category | Component | In one line | Source |
|---|---|---|---|---|
| BR3.6 | authorization | `OwnerIdentity` | Matched or not; nothing else, ever | FR3.1 |
| BR3.7 | authorization | `OwnerIdentity` | The provisioning gate is the record's existence | FR3.7 |
| BR3.8 | authorization | `OwnerIdentity` | Enabled only with no owner and a configured secret | FR3.7 |
| BR3.9 | policy | `OwnerIdentity` | No secret, no owner: start and refuse everything | FR3.7 |
| BR3.10 | constraint | `OwnerIdentity` | No shipped credential, anywhere, in any form | FR3.7 |
| BR3.11 | constraint | `SessionAuthority` | Signed, HttpOnly, Secure, SameSite=Lax | FR3.2 |
| BR3.12 | authorization | `SessionAuthority` | CSRF token paired 1:1, in the body, checked as a header | FR3.2 |
| BR3.13 | constraint | startup | Missing, empty or short key: raise and exit non-zero | NFR5 |
| BR3.14 | constraint | `SessionAuthority` | 8 hours idle, sliding | FR3.3 |
| BR3.15 | constraint | `SessionAuthority` | 7 days absolute, never extended | FR3.3 |
| BR3.16 | authorization | `SessionAuthority` | Identity or nothing — never a third answer | FR3.3, FR3.4 |
| BR3.17 | authorization | `SessionAuthority` | Revocation is server-side | FR3.4 |
| BR3.18 | policy | `LoginGuard` | 5 per account per 15 minutes | FR3.5 |
| BR3.19 | policy | `LoginGuard` | 20 per source address per 15 minutes, independently | FR3.5 |
| BR3.20 | authorization | `LoginGuard` | One refusal, one sentence, nothing enumerated | FR3.5 |
| BR3.21 | policy | `LoginGuard` | Success clears that account's counter | FR3.5 |
| BR3.22 | constraint | `LoginGuard` | Counters survive a restart | FR3.5 |
| BR23.1 | policy | `OwnerIdentity` | Always hash, even with no account — equal cost | none |
| BR23.2 | policy | `SessionAuthority` | An expired record is deleted as it is rejected | none |

**Subject to, owned by `HttpApi` (U6):** BR3.1, BR3.2 (every operation authorises
itself; the route layer decides nothing), BR3.3, BR3.4, BR3.5 (origin present and
exactly equal, CSRF on top, mutations only), BR10.7, BR10.8 (the verbatim refusal
sentence, with its U+2019 apostrophe).

---

## Assumptions & Open Questions

- **[assumption]** `BR23.1` and `BR23.2` are **new ids introduced by this unit**,
  in the unit-scoped group for U3 (unit number + 20). Both trace to **no FR**, both
  are listed in the traceability `reverse` array, and **no existing id is
  renumbered and no FR-group number is reused**.
- **[assumption]** BR3.1–BR3.5 are assigned to `HttpApi` (U6) rather than to this
  unit. The line is that **credential, session-lifetime and rate-limit rules are
  this unit's decisions, while "every operation authorises itself", the same-origin
  predicate and the CSRF double-submit are HTTP-surface rules.** That placement was
  settled across units; if it is ever revisited, note that BR3.2 makes the two
  halves mutually referential by design and neither is complete alone.
- **[A-2 — RESOLVED at review, and the resolution is forced rather than chosen]**
  For `scope = account`, `windowKey` is **always the normalised — trimmed,
  lower-cased — submitted email**, whether or not an account matches. The
  *"account identifier"* branch is **removed, not deferred**: it is not a live
  option. D3 and FR3.5 fix the thresholds and require that the response enumerate
  nothing, but neither states which value keys the counter, so A-2 was carried as
  open through iteration 1.

  **The step order settles it.** *Sign in* reads the account-scoped window at
  **step 1**, before the owner lookup at step 2, so `ownerId` does not exist yet
  when the key is derived — which makes the "account identifier" branch
  unimplementable as written for *either* case, not merely undecided for the
  no-match one. Reordering so the owner lookup precedes the window read was
  rejected: it would let the lookup outcome influence whether and when the counter
  read happens, which is precisely the timing channel `BR23.1` exists to close.

  **The full resolution, with its narrowed timing claim, is in `entities.md` §
  ENT-3, `[A-2 — RESOLVED at review]`** — including what the resolution does and
  does not establish about timing. Keeping the counter keyed on the email is also
  what preserves a per-account limit for an account that does not exist; keying on
  nothing would have left only the address limit.
- **[assumption A-3, carried]** The length and alphabet of `ownerId`, `sessionId`
  and `csrfToken` are unfixed. Any choice at or above the strength of a 32-byte
  URL-safe random token satisfies every stated requirement; the exact spelling
  belongs to code generation.
- **[assumption]** The rolling window is modelled as a **start instant plus a
  count** rather than as a log of attempt timestamps. Nothing decided which. The
  observable difference is at a window boundary: a sixth failure just after a
  rollover is permitted where a true sliding count would still refuse it.
- **[carried hedge]** BR23.1's dummy-hash verification is **the standard
  mitigation and is not separately measured**. It is recorded as a mitigation, not
  as a proof that no timing signal remains.
- **[open]** No **session retention policy** exists. BR23.2 reclaims only the
  records that are revisited; revoked and never-revisited expired records
  accumulate with nothing to sweep them. No stage has owned this and no rule
  requires it. Raised here so the absence is a visible choice rather than drift.
- **[note]** **No rule in this unit is a hazard**, and that is a consequence of
  everything here being new rather than a judgement about risk. BR3.13 stops the
  process and BR3.20 is an enumeration defence; both fail loudly. The nearest thing
  to a silent failure is the BR3.14/BR3.15 collapse, which is why it is called out
  in prose.
- **[note]** **This unit deliberately carries no dependency on the
  fixture-recording unit.** Every other backend unit depends on U1 because it has
  source behaviour to reproduce. Authentication is entirely new, so there is
  nothing to record and nothing to reproduce — the absence of that edge is a design
  statement, not an omission.

## Sources

- `construction/functional-design/rules.md` §§ *`HttpApi`* (BR3.1–BR3.5, quoted
  here, declared by U6), *`OwnerIdentity`* (BR3.6–BR3.10), *`SessionAuthority`*
  (BR3.11–BR3.17), *`LoginGuard`* (BR3.18–BR3.22) — carried with their ids and
  their full text.
- `inception/requirements-analysis/requirements.md` FR3.1–FR3.8, NFR2, NFR5.
- `inception/contract-design/contract-summary.md` § C3 — the `IdentityStore`
  operations these rules run inside.
- `inception/units-generation/unit-of-work.md` § U3 — owns, delivers, boundary,
  constraints, realises (FR3.1–FR3.7, NFR5).
- `WORKING-RECORD.md` § 2 (D1, D2, D3, D6), § 5 (the signing key's boot failure),
  § 10a (the R-01 disposition quoted under BR3.1).
- `aidlc/spaces/default/memory/team.md` § *Deployment* — the generated signing
  key, the boot failure, initial-owner provisioning, and the acceptance test.
- `aidlc/spaces/default/memory/project.md` § *Forbidden* / § *Mandated* — no
  shipped credential; argon2id in a backend-owned session replacing the platform
  header auth entirely.
