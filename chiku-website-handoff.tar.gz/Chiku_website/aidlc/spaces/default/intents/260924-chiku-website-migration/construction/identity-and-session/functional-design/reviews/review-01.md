## Review

**Verdict:** READY
**Reviewer:** aidlc-architecture-reviewer-agent
**Iteration:** 1

### Findings

| ID | Severity | Location | Finding | Required action | Status |
|---|---|---|---|---|---|
| R-01 | Major | construction/identity-and-session/functional-design/functional-spec.md > "Sign in" step 1, vs entities.md > ENT-3 `LoginAttemptWindow.windowKey` | The operation order mandates reading the account-scoped rate-limit window (step 1) *before* the owner record is looked up (step 2). But `entities.md`'s `windowKey` definition for `scope=account` is "the account identifier (or the submitted email, for an account that does not exist)" — i.e. it implies `ownerId` is used when the account is known. `ownerId` cannot be known at step 1's point in the sequence, since it is only resolved by the owner lookup in step 2. As written, the two artifacts cannot both be implemented literally: either the account-scoped window must always be keyed on the submitted email (making the "account identifier" branch of the `windowKey` definition unreachable/wrong as stated), or the operation order must change (with knock-on timing consequences for BR23.1, since it would let the owner lookup outcome influence whether/when the counter read happens). This is a sharper problem than the recorded assumption A-2 (which frames the unresolved point as "which value keys the counter when no account matches", i.e. a free choice for one branch) — the sequencing constraint shows the "account identifier" branch is not freely choosable at all given the mandated step order, for *either* branch, not just the no-match case. | Resolve by stating explicitly (in both `entities.md` and `functional-spec.md`) that `LoginAttemptWindow.windowKey` for `scope=account` is always the submitted (lower-cased/normalised) email, for both matching and non-matching accounts, and drop the "or the account identifier" branch from ENT-3's `windowKey` constraint — or, if `ownerId`-keying is actually wanted, reorder "Sign in" so the owner lookup happens before the account-scoped window read and re-justify BR23.1's timing-equalisation claim against the new order. | New |
| R-02 | Minor | construction/identity-and-session/functional-design/functional-spec.md > "Derived view — rules summary" table, row "Credentials and one-shot provisioning" | The derived rules-summary table lists this group's `Requirement` column as `FR3.1, FR3.7`, omitting `FR3.6`. But `rules.md`'s source-of-truth `yaml` block gives `BR3.7`'s `source:` as `FR3.6, FR3.7` (with an explicit `source_note` explaining the FR3.6 citation was added after a corpus audit). Per this document's own stated rule ("Where a derived view disagrees with its source, the source wins and the view is the defect"), this is a defect in the derived view. | Add `FR3.6` to the `Requirement` column of that table row so it reads `FR3.1, FR3.6, FR3.7`. | New |

### Validation Tool Results

| Tool | Result | Interpretation |
|---|---|---|
| check-units.py | 2 FAILs (FR9.1, FR9.3 assigned to U4, claimed by no unit) | Both are outside this unit (U4 content-core, frozen) per the dispatch brief; not applicable to identity-and-session. This unit's own FR3.1–FR3.7 and NFR5 all resolve to declared BR ids with no orphan/gap on this unit's side. |
| check-mermaid.sh | 15/15 OK, exit=0 | Both mermaid blocks in this unit's `functional-spec.md` (the ER diagram and the state machine) parse cleanly. |

### Cross-reference checks performed

- `entities.md`'s three entities (ENT-1..3), attribute lists, and the mermaid ER diagram agree field-for-field.
- `rules.md`'s `yaml` source-of-truth block (19 rules, BR3.6–BR3.22 + BR23.1–BR23.2) is internally consistent with its own summary table and with the prose sections; the quoted BR3.1–BR3.5 and BR10.7–BR10.8 text matches `construction/functional-design/rules.md` (the shared, pre-split corpus) verbatim.
- `traceability.json`'s `coverage` and `reverse` entries all name `BRx.y` ids that exist in `rules.md`; `FR3.1`–`FR3.7` and `NFR5` are the complete set this unit realises per `unit-of-work.md` § U3, and all are accounted for.
- `unit-of-work.md` § U3 (owns/delivers/boundary/constraints/realises) and `contract-summary.md` § C3 (`IdentityStore`'s three operation groups) both agree with what `entities.md`/`rules.md` describe as this unit's persistence surface.
- `components.md`'s `OwnerIdentity`/`SessionAuthority`/`LoginGuard` descriptions, their dependency edges to `IdentityStore`, and the interaction table match this unit's artifacts.
- Session lifetime (BR3.14/BR3.15/BR3.16): traced a sequence where `touch` advances only `lastSeenAt`; verified `absoluteExpiresAt` is computed once and never recomputed on any path in `functional-spec.md`'s "Verify a request" or "Sign in" — found no path that extends the absolute bound and no path that fails to reject an idle- or absolute-expired session.
- Rate limiting thresholds (BR3.18/BR3.19) are independent, both enforced, and BR3.20 gives both an exhausted-window refusal and a credential failure the identical status/body/sentence — confirmed in `functional-spec.md` "Sign in" step 3 and `rules.md`.
- CSRF/cookie (BR3.11/BR3.12, quoted BR3.3–BR3.5): the CSRF token is body-issued/header-verified (never cookie-carried), paired 1:1 with the session; `Origin` absence fails closed per the quoted BR3.3 text, consistent across `rules.md` and the shared corpus.
- First-owner provisioning / FR3.6 claim: `owner_record` exposes only `read` and `create_if_absent` (per `contract-summary.md` § C3), `create_if_absent` is the sole creation path, its gate is the record's existence, and it is atomic against a concurrent caller (BR22.13, owned by U2). Combined with the entity's singleton cardinality, this genuinely discharges FR3.6 ("exactly one owner account exists") rather than merely gating the provisioning route — the claim holds.
- BR23.1/BR23.2 "trace to no FR": checked `requirements.md`'s FR3 block and NFR2/NFR5 for any mention of timing-equalisation or record-deletion/retention language; found none. The "traces to no FR" claim for both ids is accurate.
- Secret handling (BR3.13, the signing-key/bootstrap-secret table in `entities.md`): no path returns, logs, or defaults either secret; the boot-failure behaviour and the deliberate absence of an auto-generated key match `team.md` § Deployment verbatim.

### Summary

This is a tightly cross-referenced, internally disciplined design for the product's entire auth surface, and the adversarial pass did not surface anything that breaks the core security properties (session lifetime separation, enumeration-resistant refusal shape, revocation-is-server-side, secret boot-failure). The one substantive gap (R-01) is narrow — a single field's keying rule is underspecified in a way that the artifact's own recorded assumption (A-2) does not fully capture, because the mandated operation order forecloses one of the two branches the entity definition describes — and is cheaply fixable without touching the rest of the design. The other finding (R-02) is a small derived-view/source-of-truth drift that the stage's own rules already anticipate a fix for. Neither rises to Critical, and there are fewer than three Major findings, so this stands as READY subject to the two required actions above.
