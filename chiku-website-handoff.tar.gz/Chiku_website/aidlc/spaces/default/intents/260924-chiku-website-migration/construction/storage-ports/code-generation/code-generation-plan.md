# Code Generation Plan — U2 `storage-ports`

## Unit scope

The contract every backend unit persists through: three ports — `ContentStore`,
`IdentityStore`, `AssetStore` — each with the locally verified adapter, an in-memory
fake, and **one adapter-parameterised conformance suite run over both**.

Two implementations is the minimum that proves the suite tests the **port** rather than
SQLite, and that is the whole argument for having a port (BR22.4). The cloud adapters are
a separate unit, written against these same ports and run through these same suites.

**Boundary, in one line:** this unit defines and implements persistence and owns no
business rule — *it does not know what a revision means, only how to store one*.

This unit owns **no entity and no functional requirement**. All fourteen rules it
declares (`BR22.1`–`BR22.14`) carry `source: none` and belong in `traceability.json`'s
`reverse` array; `coverage` is empty. A port obligation *enables* an FR that another
unit's rule discharges — it does not discharge one itself.

## Module layout

Modules are named for the domain thing they own, never for a layer, and each port sits
with its domain rather than in a shared `storage/` package.

```
app/sqlite.py                    connection factory, schema DDL, the to_thread boundary
app/content/store.py             ContentStore protocol + the three record shapes
app/content/store_sqlite.py      verified adapter   [HAZARD — the combined write]
app/content/store_memory.py      in-memory fake
app/auth/store.py                IdentityStore protocol + the three record shapes
app/auth/store_sqlite.py         verified adapter   [HAZARD — create_if_absent]
app/auth/store_memory.py         in-memory fake
app/assets/store.py              AssetStore protocol + the head record
app/assets/store_volume.py       verified adapter: bytes on a volume
app/assets/store_memory.py       in-memory fake
tests/conformance/conftest.py    the adapter parameterisation
tests/conformance/test_content_store.py
tests/conformance/test_identity_store.py
tests/conformance/test_asset_store.py
```

`app/sqlite.py` earns its place: it owns the connection, the schema and the single point
where a synchronous driver is moved off the event loop. Nothing else in the tree may
import `sqlite3`.

## Ordering — the contract's `custom` methodology, not test-after

`team.md` § *Testing Posture*: *"the characterization tests for that unit's
hazard-register behaviours **and for the storage port** are written and observed to fail
before the Python implementation of that behaviour exists."*

This unit is entirely storage port, so **the conformance suite is written first and
observed to fail first**, in full, for all three ports. Steps 3 and 5 are separated for
exactly that reason and must not be merged or reordered into layer-local TDD.

The Red observation is recorded as real output: `ImportError` / `NotImplementedError`
counts as Red only where the test would otherwise have asserted behaviour. A test that
passes against an empty module is not a test.

## Steps

- [x] **Step 1 — Verify the test runner and record the exact unit-scoped command.**
      `pytest` 9.1.1 under `chiku-website/backend/`, resolved by `uv`. Confirm
      `uv run pytest --version` succeeds and record the unit-scoped command in
      `unit-test-instructions.md`. Runner readiness precedes every test step.

- [x] **Step 2 — The three port definitions and their record shapes.** Protocols and
      frozen dataclasses only: no implementation, no I/O. Ports are `Protocol` classes so
      an adapter conforms structurally and `mypy --strict` checks conformance at every
      call site. Record shapes come from `entities.md` § *Source of truth*, at the
      **storage-level spelling** — `snake_case` everywhere, including columns. The
      `camelCase` wire format is the consumer's single conversion point and appears
      nowhere in this unit.
      Every operation is `async`.

- [x] **Step 3 — The conformance suite, written and observed to FAIL.** One
      adapter-parameterised suite per port, driven by a fixture that yields each
      implementation in turn. Every row of `functional-spec.md` § *The conformance suite*
      becomes a named test, plus the branch-level tests the hazard register demands. Run
      it; paste the failing output. It must fail for the right reason.

- [x] **Step 4 — `app/sqlite.py`: connection, schema, and the blocking-driver boundary.**
      Schema DDL for the five record shapes. `revision` is **not** unique on the revision
      entry table — a baseline pair and a normal entry share one, and an adapter must not
      add that constraint. `last_mutation` exists as a column; omitting it silently
      removes a concurrency defence. Every `sqlite3` call is wrapped in
      `anyio.to_thread.run_sync` here and nowhere else (BR22.7).

- [x] **Step 5 — The six implementations, to Green.** Three verified adapters and three
      fakes, in the order the suite fails. The fake **computes** the listing order rather
      than inheriting it from a storage engine (BR22.3) — a fake that returns insertion
      order passes nothing and proves nothing.
      Four obligations that no functional assertion catches on its own:
      - `commit` is **one transaction**, six effects, all-or-none (BR4.16), with the CAS
        result read **by name, never by position** (BR4.17). A positional read that drifts
        produces spurious "this draft changed in another tab" errors, not a crash.
      - The prune is **read-the-survivors-then-delete-the-rest**, per action, inside the
        transaction, with baselines excluded **by predicate and not by sorting high**
        (BR4.18). The survivor ordering is `revision` DESC alone and is deliberately
        **not tiebreak-stable** (BR4.19) — that indeterminacy is inherited and is not to
        be fixed.
      - `get_range` transfers **only the requested window** (BR22.11). Whole-object-slice
        returns identical bytes and passes every correctness assertion while making a
        50 MB video cost 50 MB per seek; the suite asserts the operation exists, returns
        exactly the window, and is the path the serving code takes.
      - `create_if_absent` is **atomic against a concurrent caller** (BR22.13): one
        record, one refusal. A read-then-write implementation does not satisfy it.

- [x] **Step 6 — Coverage, documentation and traceability.** Confirm the 80% branch floor
      over `chiku-website/backend/` and **100% branch coverage on the two hazard modules**
      (`app/content/store_sqlite.py`, `app/auth/store_sqlite.py`). Neither floor is
      relaxed to make a step pass; a shortfall is surfaced, not configured away. Then
      `code-summary.md`, `source-manifest.json` and `traceability.json` with all fourteen
      `BR22.x` ids in `reverse` and an empty `coverage`.

## Test files this plan produces

Per the Standard strategy (5–8 tests per component) applied per port, plus the
branch-level tests the hazard register requires on the two hazard modules:

- `tests/conformance/conftest.py` — the adapter parameterisation, the one place a new
  adapter is registered.
- `tests/conformance/test_content_store.py` — seed-on-empty-and-write-nothing, byte
  round-trip, stale-CAS-with-no-side-effect, the colliding-`next_revision` stale writer,
  the three-part listing order **including a tied revision**, independent retention
  counts, baseline survival, idempotent `asset_metadata.remove`.
- `tests/conformance/test_identity_store.py` — `touch` advances idle and leaves absolute
  alone, concurrent `create_if_absent` yields one record, a revoked session fails the
  **next** read, the two attempt scopes count independently.
- `tests/conformance/test_asset_store.py` — `get_range` returns exactly the window,
  `head`'s entity tag is stable across reads, idempotent `delete`.

No new test framework. `pytest` and `anyio` are already the affirmed tooling; `anyio` is
already a resolved dependency.

## What this unit deliberately does not do

Named because an implementer will be tempted, and each has broken a port before:

- **No validation and no defaults** (BR22.6). The store records what it is given. A store
  that re-validates content is a store that can disagree with its owner.
- **No expiry evaluation in `session.read`** (BR22.14). A record past either bound is
  returned as stored; the consumer applies both. A store that filtered expired sessions
  would enforce a rule it does not own, and the two evaluations would drift.
- **No threshold in `count_in_window`.** 5 per account and 20 per address are the
  consumer's numbers.
- **No reconciliation of the two media types** (BR22.12). `AssetStore.head` and
  `asset_metadata.read` hold it independently and agree only because both were written
  from the same value. The response type comes from the **metadata row** (BR7.18).
- **No `hasUnpublishedChanges` column.** Computed by the consumer on every read.
- **No lazy create in `read_state`** (BR4.1). Bootstrap belongs to `commit` alone; a lazy
  create lets a client at revision 5 resurrect a deleted document.
- **No range arithmetic** (BR22.11). Every range branch is decided above the port.
- **No seeded credential.** No default, sample or hard-coded credential exists in any
  adapter, its schema setup, or its fixtures.

## Traceability — plan step to rule

| Step | Realises |
|---|---|
| 2 | BR22.5, BR22.6, BR22.7, BR22.12, BR22.14 |
| 3 | BR22.3, BR22.4 |
| 4 | BR22.7, BR22.9 |
| 5 | BR22.1, BR22.2, BR22.8, BR22.10, BR22.11, BR22.13 |
| 6 | NFR10 |

`BR22.x` ids are declared here. `BR3.*`, `BR4.*`, `BR5.*`, `BR6.*` and `BR7.*` are
**enforced** here and **declared** in U3, U4 and U5 respectively; they appear in this
unit's traceability as enforcement, never as coverage.

## Open question carried into generation

**`AssetStore`'s verified adapter writes bytes to a volume directory, not into SQLite.**
`team.md` says "SQLite plus a volume"; `entities.md` requires a **stable entity tag for
unchanged bytes**, because the conditional-range comparison is exact string equality. A
filesystem mtime is not stable across a container rebuild or a volume restore. The plan
therefore derives the entity tag from a **content hash computed at `put` and stored in
the metadata the adapter keeps beside the object**, never from mtime or inode. If that
proves wrong at implementation time it is surfaced, not silently substituted.
## Testing Contract

```json
{
  "version": 1,
  "methodology": "custom",
  "source": "team",
  "ordering": "Within each unit, the characterization tests for that unit's hazard-register",
  "scope": "runtime-split-migration",
  "test_strategy": "standard",
  "project_type": "brownfield",
  "applicable_notes": [
    {
      "layer": "org",
      "text": "We treat tests as a first-class deliverable in every Bolt. The specific\nmethodology (TDD, BDD, ATDD, or classic test-after) is affirmed at\npractices-discovery and recorded in `team.md` under this heading with explicit\n`Methodology` and `Ordering` fields; Code Generation resolves those fields\nindependently from coverage, tooling, and scope notes.\n\nWhen no posture has been affirmed, our default per scope is:\n- **Methodology**: test-after\n- **Ordering**: implement each applicable testable layer, then write and run\n  that layer's tests.\n- `mvp`, `enterprise`, `feature`, `infra`, `classic` add an 80% line-coverage\n  floor and CI execution before merge.\n- `bugfix`, `security-patch` add a targeted regression for the specific\n  bug/vulnerability and require the existing suite to remain green.\n- `express` uses the Minimal strategy: requirement-driven unit tests (one per\n  requirement, with a happy-path floor per component); existing tests remain\n  green.\n- `poc`, `refactor`, `workshop` add no extra new-test floor and require the\n  existing suite to remain green.\n\nThe active `Test Strategy` still applies in every scope and determines test\nvolume/types. Scope floors are additive; they never reduce or replace the\nselected strategy.\n\nBuild and Test verifies defined coverage floors and affirmed quality targets;\nthey may not be weakened to make a step pass.\n\nAffirm a stricter posture in `team.md` if the team commits to one."
    },
    {
      "layer": "team",
      "text": "> **Read this section as a proposal we have adopted, not as practice we observed.** The source\n> project contains zero test files, zero testing dependencies and no `test` script, so there was no\n> prior testing practice to discover — every item below was chosen at the practices-discovery gate\n> on 2026-09-24 and affirmed by the site owner, rather than read off how this team already works.\n\n- **Methodology**: custom\n- **Ordering**: Within each unit, the characterization tests for that unit's hazard-register\n  behaviours and for the storage port are written and observed to fail before the Python\n  implementation of that behaviour exists; every other backend test is written immediately after\n  the code it covers; that unit's frontend render layer is ported only once its backend tests\n  pass; a unit with no backend surface begins at the frontend step; and a unit whose behaviour is\n  not enumerated in the hazard register takes the recorded source fixtures as its oracle, falling\n  back to the reverse-engineering knowledge base where no fixture exists.\n- **What `custom` means, and why it is not `test-after`.** Under test-after, a developer who\n  misreads a dense source line implements from the misreading and then writes the test from the\n  same misreading: the test is green, coverage is satisfied, and the defect ships. That is not\n  hypothetical here — a port declaring `research_topic: Topic | None = None` passes `ruff`,\n  `mypy --strict`, `tsc`, the Compose end-to-end flow and 100% line coverage while rendering three\n  identical research cards and returning zero publications for every topic filter. Only a test\n  whose assertion came from the *source* behaviour catches it. `tdd` everywhere is equally wrong:\n  most of the ported render layer has no enumerated oracle, and writing failing render assertions\n  first for ported JSX is waste. Note this is **characterization** testing, not TDD — the test is\n  written from the recorded behaviour of the source, which is why the fixtures below matter.\n- **Recorded source-behaviour fixtures come first, before any Python is written.** Drive the\n  running `madhavi-tripathi/` app over HTTP with `httpx` once and record as golden fixtures: every\n  public route's rendered HTML, `GET /api/content`, the media route's status codes across public /\n  draft-only / missing keys, the 413 boundary in both characters and UTF-8 bytes, byte-range\n  responses across all six rejection branches, and the stored-row state after a save / publish /\n  conflict sequence. It uses a disposable local database and a test identity; nothing hosted is\n  touched. Until these exist, every parity assertion in this project rests on a human's reading of\n  a document; after they exist, they assert against the system. **This capability expires when the\n  source app is retired** — a fixture not recorded before then cannot be recovered.\n- **Coverage floor — backend**: **80% branch coverage** over `chiku-website/backend/`, measured by\n  `pytest --cov --cov-branch` and `coverage report --fail-under=80`, with generated migration\n  files and `__main__` entry points excluded. Branch, not line, is deliberate and costs one flag:\n  every high-risk behaviour in this port is a branch or a `??` fallback chain, and line coverage\n  marks those covered when only one side ever runs. This is a **new floor we are choosing**, not\n  an inherited one — `org.md`'s 80% floor is written for the named stock scopes (`mvp`,\n  `enterprise`, `feature`, `infra`, `classic`) and this workflow runs the custom scope\n  `runtime-split-migration`, which appears in none of them. Absent this affirmation there would be\n  no numeric floor at all. The active `Test Strategy` is **Standard** and continues to govern test\n  volume and type independently of this number.\n- **Coverage floor — hazard modules**: a second, scoped\n  `coverage report --fail-under=100 --include=<hazard module globs>`. The hazard modules are the\n  ports of the behaviours ranked in `code-quality-assessment.md` § *Hazard index* — the\n  seven-statement concurrency batch and its `last_mutation` ABA defence, the media access rule, the\n  `researchIdentity` back-compat shims, the request-size cap, the three hand-written image header\n  parsers, the WebVTT validator, the byte-range parser and the editor state machine. Each carries a\n  test per enumerated branch. An aggregate percentage cannot distinguish \"this branch is exercised\"\n  from \"this branch was ported correctly\"; these are precisely the branches whose silent loss ships\n  a defect, so they get both the per-branch tests and a floor that leaves no room.\n- **Coverage floor — frontend**: none. The Next.js frontend renders only and owns no application\n  decision, so a line-coverage number on it would measure JSX traversal rather than behaviour.\n- **The test families, and which are mandatory.** Mandatory: the recorded fixtures above; backend\n  unit tests for branch-level behaviour of ported logic; **storage-port contract tests written as\n  an adapter-parameterized conformance suite and run against both the real SQLite adapter and an\n  in-memory fake** (two implementations is the minimum that proves the suite tests the port\n  contract rather than SQLite, and it is the whole argument for having a port); API contract tests\n  in the non-circular form — assert the **generated** OpenAPI document against the **hand-written**\n  contract from `contract-design`, and commit the generated `openapi.json` as a snapshot so an\n  unintended contract change surfaces as a gate diff rather than as a frontend 422 three Bolts\n  later; and the Compose end-to-end flow. Frontend render checks are mandatory but add **no\n  frontend test framework**: assert against the HTML the composed stack returns, using the recorded\n  fixtures, and make the assertions named rather than \"landmarks present\" — each of the three\n  research cards has a distinct topic class and icon, the publications topic filter returns\n  non-zero for each seeded theme, each research card shows non-zero related papers. Browser checks\n  (Playwright) are optional today with one condition that flips them: **if the six-flag editor\n  state machine lands in the frontend rather than the backend, a browser check becomes the only\n  possible verification of it and becomes mandatory.** Flag that as a dependency on `domain-design`.\n- **Compose end-to-end runs on every Bolt merge**, not only at the skeleton gate and at the end.\n  With no CI, the per-merge run *is* the CI, and the alternative is a container-level regression\n  surfacing many Bolts after the one that caused it, with no bisect signal and nobody watching a\n  dashboard. Keep the cost bounded by keeping the flow small and fixed — the skeleton's two paths\n  plus one auth-failure path — so it stays inside a few minutes on cached layers.\n- **Parity is verified two ways, and pixel comparison is rejected.** (1) A **normalised\n  DOM-structure diff** against the recorded source HTML: strip volatile attributes, build hashes\n  and whitespace, then diff the element tree plus text content per route. It catches what actually\n  breaks in a port — a dropped section, a wrong class, a missing copy default among the 25 leaf\n  defaults — at a fraction of the setup cost of pixel screenshots and without their flakiness.\n  (2) An explicit **page-by-page human review at the end**, recorded as a checklist. Per-route\n  screenshot comparison was considered and **rejected**: it is brittle against fonts, antialiasing\n  and animation, and it is not a live option to be reopened later. Until the DOM diff exists, the\n  parity rule is an unfalsifiable claim, which is what this closes.\n- **Boundary enforcement is a command, not an assertion.** A rule nobody can check is a wish. Three\n  checks, all on the gate: the frontend's TypeScript types for backend payloads are **generated**\n  from the backend's `/openapi.json` with `openapi-typescript`, committed, regenerated at the gate,\n  and the gate fails if the output is dirty — which makes the boundary type-checked rather than\n  asserted, since a backend field rename then fails `tsc --noEmit` with a file and a line; a\n  three-line grep fails the gate if `chiku-website/frontend` contains any `'use server'` directive,\n  any `app/**/route.ts`, or any `middleware.ts` (an ESLint `no-restricted-syntax` rule is a nicer\n  editor experience, but the grep is the one that is certain); and one pytest walks the AST of\n  `routers/` modules and asserts none of them imports a `store` module or `sqlite3`.\n- **The source has no suite to keep green.** The org rules for several scopes say \"the existing\n  suite remains green\". There is none — the scan found zero test files, zero testing dependencies\n  and no `test` script anywhere in `madhavi-tripathi/`. Every test in this project is a new test.\n  The only inherited automated checks are `tsc --noEmit` (strict) and `pnpm lint`.\n- **Tooling**: backend — pytest 9.1.1 with `httpx` 0.28.1 for FastAPI transport-level tests,\n  `ruff` 0.16.8 and `mypy` 2.3.1 as gating checks, dependencies resolved by `uv` 0.10.0. Frontend\n  — `tsc --noEmit` and ESLint 9 with `eslint-config-next`, unchanged from the source project.\n- **The merge gate.** A Bolt may squash-merge to `main` only when every one of these passes on the\n  developer machine, in this order, with the **verbatim output pasted into the gate approval**:\n\n  ```\n  ruff check\n  ruff format --check\n  mypy --strict\n  pytest --cov --cov-branch\n  coverage report --fail-under=80\n  coverage report --fail-under=100 --include=<hazard module globs>\n  tsc --noEmit\n  pnpm lint\n  git diff --no-index madhavi-tripathi/app/<f> chiku-website/frontend/app/<f>   # per unmodified ported file\n  <boundary grep: 'use server' / app/**/route.ts / middleware.ts>\n  <openapi-typescript regeneration — gate fails if the committed output is dirty>\n  uv export --frozen --no-dev --no-emit-project -o .audit/requirements.txt && uvx pip-audit -r .audit/requirements.txt\n  pnpm audit --prod --audit-level high\n  docker compose up  +  the end-to-end flow\n  ```\n\n  **Dependency advisories block at High and above.** An advisory with no fix available does not\n  silently pass and does not silently block: it is recorded with the **package, the advisory id,\n  the reason it cannot be fixed, and the named Bolt that owns it**, and the gate then proceeds on\n  that record. This is consistent with the correction already in `project.md` that any finding\n  carried past a gate needs a named owner.\n\n  Gates protect the parity guarantee; weakening one to make a Bolt pass is an incident, not a\n  shortcut."
    }
  ],
  "obligations": {
    "strategy": "standard",
    "strategy_volume": [
      "Five to eight tests per component.",
      "Unit tests plus integration tests for key boundaries.",
      "Add E2E, performance, or security tests when requirements demand them."
    ],
    "scope_floor": [
      "Keep the existing test suite green.",
      "This scope adds no extra new-test floor beyond the selected test strategy."
    ],
    "combination_rule": "Apply every selected-strategy obligation and every scope-floor obligation; neither replaces the other, and a targeted scope regression may add the narrowest necessary test type beyond the strategy default."
  },
  "plan_profile": {
    "methodology": "custom",
    "runner_step": "Verify the existing test runner/configuration and record the exact unit-scoped command.",
    "runner_ready_before_first_test": true,
    "testable_layers": [
      "Data model / database behavior",
      "Repository / data access",
      "Business logic",
      "API / endpoint",
      "Frontend behavior"
    ],
    "steps": [
      "Project structure and production configuration skeleton.",
      "Verify the existing test runner/configuration and record the exact unit-scoped command.",
      "Custom ordering - Within each unit, the characterization tests for that unit's hazard-register",
      "Implementation and tests - preserve that exact ordering; do not convert it to layer-local TDD.",
      "Environment/build configuration.",
      "Documentation and traceability."
    ]
  },
  "input_sha256": "sha256:ae7fe698329b9815a1e703cfb6f92beeb23e35c6e2f83768ad7ab02dffb4a262",
  "contract_sha256": "sha256:6b84da29d5313b29b3058ef863280c58a9f6f401f244363de9431d8063261179"
}
```
