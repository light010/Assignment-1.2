# Functional Specification — U2 `storage-ports`

**Unit:** `storage-ports` · **Kind:** `library`

**Upstream:** `construction/storage-ports/functional-design/entities.md` (the
persisted shapes), `construction/storage-ports/functional-design/rules.md` (the
rules those operations must make satisfiable),
`inception/contract-design/contract-summary.md` §§ C2, C3, C4,
`inception/units-generation/unit-of-work.md` § U2.

**This document is the source of truth for this unit's workflows.** It
additionally carries **two derived views** — an entity-relationship diagram
derived from `entities.md`, and a rules summary derived from `rules.md`. Where a
derived view disagrees with its source, the source wins and the view is the
defect.

## What this unit delivers

**The contract every backend unit persists through, proven by a suite that runs
against two implementations so that it tests the port rather than the storage
engine.**

Three ports: `ContentStore`, `IdentityStore`, `AssetStore`. Each ships with the
locally verified adapter, an in-memory fake, and one adapter-parameterised
conformance suite run over both. The cloud adapters are a separate unit,
implemented against these same ports and these same suites.

**Boundary, in one line:** this unit defines and implements persistence and owns
no business rule — *it does not know what a revision means, only how to store
one*.

## Conventions that hold for every operation below

- **Operations are asynchronous.** Where an adapter's driver is synchronous, the
  adapter moves that call off the event loop; a consumer never touches a blocking
  driver (`rules.md` BR22.7).
- **Field names** in signatures are the **storage-level** spelling. The frozen
  externally visible wire spelling is produced by the consumer's single conversion
  point, never by an adapter (`entities.md` § *Assumptions*).
- **Content payloads are opaque** and round-trip byte-identically (`rules.md`
  BR22.5). No adapter validates, defaults, transforms or normalises one (BR22.6).
- **Absence is a return value, not an error.** Reading something that is not there
  returns absence; it does not raise. Errors are reserved for a store that could
  not answer — a failed connection, a failed write — and those propagate to the
  consumer, which owns the decision about what a caller sees.
- **Nothing here chooses a status code, composes a message, or knows what a
  caller is.** Every user-facing sentence and every HTTP status belongs above this
  unit.

---

## Derived view — the persisted shapes and their relationships

Derived from `entities.md`. **Authoritative source: `entities.md`.**

```mermaid
erDiagram
    OWNER_RECORD ||--o{ SESSION_RECORD : issues
    OWNER_RECORD ||--o{ LOGIN_ATTEMPT_WINDOW : "counted against"
    CONTENT_DOCUMENT ||--o{ CONTENT_REVISION : "past states of"
    ASSET_METADATA ||--|| ASSET_OBJECT : "same key, no shared transaction"

    CONTENT_DOCUMENT {
        fixed id PK "singleton, not a collection key"
        payload draft "always overwritten"
        payload published "moves only on publish"
        integer revision "monotonic, plus one per write"
        instant updated_at
        instant published_at "nullable until first publish"
        token last_mutation "nullable, the ABA guard"
    }
    CONTENT_REVISION {
        text id PK "mutation token, or a fixed baseline literal"
        integer revision "NOT unique"
        enum action "draft or publish"
        payload content "read back from the stored draft"
        instant created_at "time of capture for a baseline"
        boolean baseline "true only for the two starting entries"
    }
    ASSET_METADATA {
        text key PK
        text filename "display only, max 200"
        enum media_type "the response type comes from HERE"
        integer byte_size
        integer width "nullable, images only"
        integer height "nullable, images only"
        instant created_at
        text derived_from "nullable, the original's key"
    }
    ASSET_OBJECT {
        text key PK
        bytes bytes "stored and returned unchanged"
        integer size
        text etag "stable for unchanged bytes"
        text media_type "held independently, NOT reconciled"
    }
    OWNER_RECORD {
        text owner_id PK "never derived from the email"
        text email "max 200"
        text password_hash "argon2id, verbatim, never logged"
        instant created_at
        instant password_updated_at "nullable"
    }
    SESSION_RECORD {
        text session_id PK
        text owner_id FK
        instant issued_at "set once"
        instant last_seen_at "advanced by touch"
        instant absolute_expires_at "NEVER extended"
        instant revoked_at "nullable, server-side revocation"
        text csrf_token "paired one to one"
    }
    LOGIN_ATTEMPT_WINDOW {
        text window_key PK "with scope"
        enum scope PK "account or ip"
        integer failure_count
        instant window_started_at
    }
```

**Text fallback, for a reader whose renderer does not draw the diagram.** Seven
persisted shapes across three ports.

- **`ContentStore`** holds three: the **content document** (a singleton), the
  **revision entries** (one-to-many from the document — each entry is a past state
  of it), and the **asset metadata** rows.
- **`IdentityStore`** holds three: the **owner record** (a singleton), the
  **sessions** (one-to-many from the owner), and the **login-attempt windows**
  (zero-to-many; an account-scoped window may key on an account that does not
  exist).
- **`AssetStore`** holds the **asset objects** — one-to-one with an asset metadata
  row by shared key, **across two stores with no shared transaction**, which is why
  an interrupted upload can leave an orphan.
- **`asset metadata.derived_from`** points a generated variant at the key of the
  original it came from; it is null for an original. That is a self-reference
  within the asset metadata collection and is drawn above as an attribute rather
  than as an edge.

---

# `ContentStore`

Consumers: U4 `content-core`, U5 `media`. Five operation groups.

## `read_state()`

**Returns** `draft`, `published`, `revision`, `updated_at`, `published_at`.

**Behaviour.**

1. Read the singleton content document record.
2. **If it exists**, return its five stored values unchanged — the two payloads
   byte-identical to what was written, the revision as stored, both instants as
   stored (`published_at` may be null).
3. **If it does not exist**, return the **seeded document**: the seed payload as
   both `draft` and `published`, `revision` `0`, `updated_at` null, `published_at`
   null.

**Three things this operation must not do** (`rules.md` BR4.1):

- **It writes nothing.** Not the record, not a bootstrap, not a lazily created
  row. Bootstrap belongs to `commit` alone, under the guards in BR4.8 — a lazy
  create here lets a client at revision 5 resurrect a deleted document.
- **It computes no change flag.** `hasUnpublishedChanges` has no column and is
  derived by the consumer on every read.
- **It applies no default and runs no transform.** The content-carrying defaults
  run in the consumer's parse, and a store that materialised them would write
  values the owner never entered.

**Concurrency.** A pure read. It takes no lock and it need not be serialised
against a concurrent `commit`: the consumer's optimistic concurrency is what
detects a stale view, and it detects it at the write, not at the read.

## `commit(content, base_revision, action, mutation_token, retention, now)`

**THE combined write.** One call, one caller, one transaction, carrying the
content update, the revision entry **and** the retention prune together. Splitting
these across calls is what FR4.5 exists to prevent.

**Arguments.**

| Argument | Meaning |
|---|---|
| `content` | The validated document, already serialised by the consumer. Stored opaquely. |
| `base_revision` | The caller's revision. Compared, and set. |
| `action` | `draft` or `publish`. |
| `mutation_token` | **Unique per request.** It guards the **side effects**, whose guard condition is not unique to the writer — which is why the revision alone is insufficient. |
| `retention` | The policy supplied by the ledger: how many of each action survive, and which entries are permanent. **An argument, never a constant inside an adapter** (`rules.md` BR5.9). |
| `now` | The write instant, supplied by the consumer so that the record and its revision entry agree exactly. |

**Returns** the new state — `draft`, `published`, `revision`, `updated_at`,
`published_at` — **or a conflict signal** when `base_revision` no longer matches.
The conflict signal is a **return value, not an exception**: "someone else wrote
first" is an ordinary outcome of an optimistic write, and the consumer maps it to
what a caller sees.

**Atomicity: REQUIRED.** All effects commit together or none does (`rules.md`
BR4.16).

**The six effects, in order.** Each is specified rule-by-rule in `rules.md`
BR4.8–BR4.12; this is the sequence.

| # | Effect | Guard | Notes |
|---|---|---|---|
| 0 | Bootstrap the singleton with the seed in both payload columns, revision 0, `published_at` null | applies only when `base_revision = 0`; a no-op if the record exists | Two guards, both load-bearing |
| 1 | Capture the `starting-published` baseline from the record's **current** `published` | fixed identity, insert-if-absent, and only while the record's revision equals `base_revision` | Succeeds **at most once ever** |
| 2 | Capture the `starting-draft` baseline from the record's **current** `draft` | same | Succeeds **at most once ever** |
| 3 | **The compare-and-set** on the content record | **only while the record's revision equals `base_revision`** | Returns the new state, or nothing |
| 4 | Insert the revision entry, identified by `mutation_token`, content read back **from the record's `draft` column** | only while revision = `base_revision + 1` **and** `last_mutation = mutation_token` | The entry records what was **stored**, not what was **sent** |
| 5–6 | Prune, per action, to the retention counts | same token guard | Read-the-survivors-then-delete-the-rest, **inside** the transaction |

**Reading the compare-and-set outcome.** By **name or explicit binding, never by
position** (`rules.md` BR4.17). In the source this result is read by numeric index
into the batch, unmarked; inserting a statement before it makes the write read the
wrong result, most likely nothing at all — which the caller interprets as a
conflict. The failure mode is **spurious "this draft changed in another tab"
errors, not a crash.** Where a driver makes a positional read unavoidable, the
index is asserted by a test.

**The prune is read-then-delete, not a predicate** (`rules.md` BR4.18, BR22.1).
Two independent survivor selections — the highest-`revision` non-baseline `draft`
entries and the highest-`revision` non-baseline `publish` entries — and everything
else of that action and non-baseline status is deleted. Baselines are excluded by
the predicate, not by sorting high. The ordering of the survivor selection is
`revision` descending **alone** and is **not tiebreak-stable**; that indeterminacy
is inherited, not fixed (BR4.19).

**Bounds.** At most one content document, one revision entry and the pruned set
per call, which keeps the write well inside a document store's per-transaction
document limit.

**Payload size.** This operation must accept a content payload of up to
**1,500,000 decoded characters**, which in UTF-8 can exceed 4 MB, and the revision
entry stores the full content. An adapter whose per-document ceiling is smaller
takes the content-addressed-blob path in `rules.md` BR22.8, **blob first,
transaction second** — and accepts the stated weakening of the atomicity
guarantee.

## `list_revisions()`

**Returns** revision summaries — identity, `revision`, `action`, `created_at`,
`baseline` — ordered **`revision` descending, then `baseline` ascending, then
`action` descending**, capped at **52**.

- **All three sort parts are returned, not just the first.** A listing sorted on
  revision alone differs only on a tied revision — and passes any test written
  from a looser wording (`rules.md` BR5.2).
- **52 is not a page size.** There is no pagination and no cursor: the cap and the
  retention policy are the same number by construction — `30 + 20 + 2` — and
  changing one without the other silently truncates history or shows nothing new
  (BR5.3, BR22.2).
- **Summaries, not content.** The full content of an entry is fetched one at a
  time through `read_revision`; the listing does not carry 52 documents.
- On an adapter that needs a **declared composite index** for this order, the
  index is a deployment artifact and the conformance suite asserts the order, so a
  missing index **fails a test rather than silently reordering the list** (BR5.4,
  BR22.9).

## `read_revision(id)`

**Returns** the entry with its full content, **or absence**.

- The id is taken as given. **This operation validates no pattern and enforces no
  length** — the id rules, and the distinction between an absent parameter and an
  empty one, belong to the consumer (BR5.5).
- A well-formed id that names nothing, an entry that was pruned, and an entry
  whose stored content is unreadable all return **absence**. The consumer decides
  what a caller sees and what it is told about its own draft.
- The returned content is the stored payload, **byte-identical**.

## `asset_metadata` — `register` / `read` / `remove`

Row-shaped, therefore held here rather than in `AssetStore`.

- **`register(record)`** — stores the asset metadata record exactly as given. The
  store validates no media type, derives no extension, and inspects no filename.
- **`read(key)`** — returns the record or absence. Its `media_type` is the value
  the serving path uses for the response content type — **from this store, not
  from the object store** (`rules.md` BR7.18).
- **`remove(key)`** — **idempotent**; removing a key that is absent is a success.
  It exists for the best-effort cleanup of a failed or cancelled upload and for no
  other purpose: there is no ordinary asset-deletion path and no orphan collection
  anywhere (BR6.24).

---

# `IdentityStore`

Consumer: U3 `identity-and-session`. Separate from `ContentStore` because identity
has a different reason to change and a different blast radius: the credential hash
and the session records are the highest-value data in the system, and **a defect
in a content query cannot reach them through a port that does not expose them**.

## `owner_record` — `read` / `create_if_absent`

- **`read()`** — returns the single owner record, including its stored password
  hash, **or absence**. The hash is returned to the verifying component and
  **nowhere else**: never logged, never parsed, never compared inside the store
  (`rules.md` BR3.6).
- **`create_if_absent(record)`** — creates the owner record **only if none
  exists**, and reports which happened.
  - **This is the one-shot provisioning gate**, and the gate condition is **the
    record's existence** — not a consumed flag, not a marker file, not an
    environment variable. A restart cannot reopen it (BR3.7).
  - **It must be atomic against a concurrent caller.** Two simultaneous attempts
    produce **one record and one refusal**, never two records and never a lost
    one. A read-then-write implementation does not satisfy this.
  - **The store ships no record and no seed that creates one.** No default,
    seeded, sample or hard-coded credential exists in the adapter, its schema
    setup, or its fixtures.

## `session` — `create` / `read` / `touch` / `revoke`

- **`create(record)`** — stores the session with its identity, owner reference,
  `issued_at`, `last_seen_at`, `absolute_expires_at`, null `revoked_at` and its
  paired token. The store **generates nothing**: every opaque value arrives from
  the consumer.
- **`read(session_id)`** — returns the record or absence. **It evaluates no
  expiry.** A record past either bound is returned as stored; the consumer applies
  the two bounds. A store that filtered expired sessions would be enforcing a rule
  it does not own, and the two evaluations would drift.
- **`touch(session_id, now)`** — advances `last_seen_at` **and must not touch
  `absolute_expires_at`**. That asymmetry is the entire reason both timestamps are
  stored; an adapter that refreshes both destroys the absolute bound while every
  test that only checks idle expiry still passes.
- **`revoke(session_id, now)`** — writes `revoked_at`. **Server-side**, so a
  stolen cookie stops working rather than merely disappearing from one browser;
  clearing a cookie does not satisfy this (BR3.17). A revoked session must fail
  the very next `read`.

## `login_attempts` — `record_failure` / `count_in_window` / `clear`

- **`record_failure(scope, window_key, now)`** — increments the counter for that
  scope and key, starting a new window when the current one has rolled over.
  **The two scopes are counted independently**: one record keyed by account, one
  keyed by source address, with separate rows and separate scopes — not one row
  with two counters.
- **`count_in_window(scope, window_key, now, window_length)`** — returns the
  failure count inside the current rolling window. **It compares nothing against a
  threshold**: 5 per account and 20 per source address are the consumer's numbers,
  and a store that knew them would be enforcing a rule it does not own.
- **`clear(scope, window_key)`** — resets that counter. Called on a successful
  sign-in for the account scope.
- **Counters are persisted**, so a process restart does not reset a window; an
  in-memory counter is not an acceptable implementation of the real adapter
  (BR3.22).

---

# `AssetStore`

Consumer: U5 `media`. Separate from both row stores because **a blob is not a
row**, and the cloud implementation is an entirely different service with a
different consistency and pricing model.

## `put(key, bytes, media_type)`

Stores the bytes under the key, unchanged. Used for the original **and for each
derived variant** — a variant is an ordinary object with its own key, and its
lineage is recorded in the metadata row, not here.

The store performs **no transcoding, no re-encoding, no normalisation and no
inspection**. It never derives a key, an extension or a type from anything; every
one of those decisions was made by the consumer before this call.

## `get(key)`

Returns the whole object's bytes, or absence. Used where the whole object is
genuinely wanted.

## `get_range(key, offset, length)` — **in the port, not above it**

**Returns exactly `length` bytes starting at `offset`.**

**This is a first-class port operation, not a convenience wrapper over `get`.**
Ranged reads are performed **through the store**, never by loading the whole
object and slicing — **loading a whole video to serve one range is precisely what
this port exists to avoid** (`rules.md` BR7.17).

**Why the obligation needs stating.** An adapter that reads the whole object and
returns a slice satisfies the signature, returns the correct bytes, and passes
every functional assertion in the suite — while making a 50 MB video cost 50 MB of
transfer for every seek. On a metered object store the failure mode is **cost and
latency, not incorrectness**, so no correctness test catches it. The obligation is
therefore written as a rule and asserted by the conformance suite at the level it
can be asserted: that the operation exists, that it returns exactly the requested
window, and that it is the path the serving code takes.

**The arithmetic is the caller's.** `offset` and `length` arrive already resolved.
Every range branch — multi-range rejection, the zero-byte object, the oversized
suffix that yields the whole object, and the start/end asymmetry where a start
past the end is an error but an end past the end is silently clamped — is decided
above this port. **The adapter clamps nothing, re-interprets nothing and validates
nothing**; moving any of that down here moves a rule across a unit boundary and
duplicates it.

A request for a window that does not exist in the object is a **defect in the
caller**, not a case for the adapter to paper over. The adapter reports it rather
than returning short bytes silently.

## `head(key)`

Returns **size**, **entity tag** and **media type**, or absence.

- The **entity tag** must be **stable for unchanged bytes**: the serving path's
  conditional-range comparison is exact string equality against it, and an
  entity tag that changes on every read turns that comparison into a coin flip.
- The **media type here is not the media type the response carries.** The response
  content type comes from the metadata row in `ContentStore`; the two stores hold
  the value independently and agree only because both were written from the same
  value at upload time. **Anything that syncs only one will serve mismatched
  types** (`rules.md` BR7.18). The port does not reconcile them, and an adapter
  must not.

## `delete(key)`

**Idempotent**: deleting an absent key is a success. It exists for the best-effort
cleanup path on a failed or cancelled upload and for no other purpose. On any
failure the consumer removes every key written so far from **both** stores, under
a primitive that gathers all results so **one failed delete does not abort the
rest**, and **cleanup never masks the original error** (BR6.24).

---

# The conformance suite

**One adapter-parameterised suite per port, run against the real adapter *and* an
in-memory fake.** Two implementations is the minimum that proves the suite tests
the **port** rather than the storage engine, and that is the whole argument for
having a port (`rules.md` BR22.4).

**The suite is the neutral contract in executable form.** Where this document and
an adapter disagree, the suite arbitrates. Where an adapter cannot pass it, **the
port is wrong and changes at its owner, not at the adapter.**

**What every port's suite asserts.**

| Port | Assertion | Why a looser test passes while the code is wrong |
|---|---|---|
| `ContentStore` | `read_state` on empty storage returns the seed **and writes nothing** | A lazily creating store returns the right values |
| `ContentStore` | A content payload round-trips **byte-identically** | A normalising store returns an equal document |
| `ContentStore` | `commit` at a stale `base_revision` returns the conflict signal **and performs no side effect** | The CAS alone already fails correctly; only the side effects differ |
| `ContentStore` | A stale writer whose `next_revision` collides with the winner's `revision` inserts **no** history entry and prunes **nothing** | Requires two concurrent writers at the same base revision — never reproduced single-user |
| `ContentStore` | The full three-part listing order, **including a tied revision** | A single-key sort is identical until there is a tie |
| `ContentStore` | The two retention counts are **independent** — 30 drafts do not evict a publish | A combined cap of 50 looks right until the mix is uneven |
| `ContentStore` | Both baselines survive a prune that would otherwise reach them | Ordering spares them by accident in most fixtures |
| `ContentStore` | `asset_metadata.remove` on an absent key succeeds | Cleanup paths rarely hit the absent case in a test |
| `IdentityStore` | `touch` advances the idle timestamp and **leaves the absolute one alone** | Idle-expiry tests pass either way |
| `IdentityStore` | Two concurrent `create_if_absent` calls yield **one** record | Sequential tests never see it |
| `IdentityStore` | A revoked session fails the **next** read | Cookie-clearing tests look identical |
| `IdentityStore` | The two attempt scopes count independently | One-scope fixtures pass either way |
| `AssetStore` | `get_range` returns **exactly** the requested window | A whole-object slice returns the same bytes |
| `AssetStore` | `head`'s entity tag is stable across reads of unchanged bytes | A per-read tag is only visible to the conditional path |
| `AssetStore` | `delete` on an absent key succeeds | As above |

**What the suite deliberately does not assert:** which revision entry survives a
tie at the retention boundary. That indeterminacy is inherited and preserved
(BR4.19); encoding it would turn an inherited indeterminacy into a specified
behaviour nobody decided.

---

## Derived view — rules summary

Derived from `rules.md`. **Authoritative source: `rules.md`**, which carries each
rule's full text, its reasoning and its "what breaks silently" note.

| Id | Category | Operation | In one line |
|---|---|---|---|
| BR4.1 | constraint | `read_state` | Empty storage returns the seed and writes nothing |
| BR4.8 | constraint | `commit` | Bootstrap only at base revision 0; no-op if the record exists |
| BR4.9 | constraint | `commit` | The two baselines are captured once ever, idempotently |
| BR4.10 | constraint | `commit` | The compare-and-set is the concurrency control |
| BR4.11 | constraint | `commit` | History content is read back from the stored draft column |
| BR4.12 | policy | `commit` | Retention runs inside the write, gated on the token |
| BR4.13 | constraint | `commit` | The token is an ABA defence for the side effects |
| BR4.14 | policy | `commit` | Dropping the token reintroduces two timing-dependent bugs |
| BR4.15 | policy | `commit` | The token is kept regardless of isolation level |
| BR4.16 | constraint | `commit` | All effects commit together or none does |
| BR4.17 | constraint | `commit` | Read the CAS result by name, never by position |
| BR4.18 | constraint | `commit` | Prune = read survivors, then delete the rest |
| BR4.19 | policy | `commit` | The retention tie is indeterminate and stays that way |
| BR5.1 | constraint | `list_revisions` | revision DESC, baseline ASC, action DESC |
| BR5.2 | constraint | `list_revisions` | All three parts are asserted by the suite |
| BR5.3 | constraint | `list_revisions` | Capped at 52; not a page size |
| BR5.4 | policy | `list_revisions` | A declared composite index where the adapter needs one |
| BR5.7 | policy | the prune | 30 drafts and 20 publishes, independently |
| BR5.8 | policy | the prune | Baselines are never pruned, by predicate |
| BR5.9 | policy | `commit` | Retention arrives as an argument, never a constant |
| BR3.6 | authorization | `owner_record.read` | The hash is opaque, never logged |
| BR3.7 | authorization | `create_if_absent` | The gate is the record's existence, atomically |
| BR3.17 | authorization | `session.revoke` | Revocation is a stored state change |
| BR3.22 | constraint | `login_attempts` | Counters survive a restart |
| BR6.24 | policy | `delete` / `remove` | Two non-transactional writes; idempotent best-effort cleanup |
| BR7.17 | constraint | `get_range` | Transfer only the requested bytes |
| BR7.18 | constraint | `head` / `asset_metadata.read` | Two independent media types; do not reconcile |
| BR22.1 | policy | `commit` | Per-action survivor selection, one transaction, baselines by predicate |
| BR22.2 | constraint | `list_revisions` | Not paginated; a cursor over a tied order repeats or skips |
| BR22.3 | constraint | the fake | The fake computes the order rather than inheriting it |
| BR22.4 | policy | all ports | One suite, two implementations, always |
| BR22.5 | constraint | `ContentStore` | Payloads round-trip byte-identically |
| BR22.6 | constraint | all ports | The store validates nothing and defaults nothing |
| BR22.7 | policy | every adapter | A blocking driver never leaves the adapter |
| BR22.8 | policy | `commit` (document store) | Blob first, transaction second — and the cost is stated |
| BR22.9 | policy | any indexed adapter | A declared index is a deliverable |
| BR22.10 | constraint | `AssetStore.delete`, metadata remove | Cleanup deletes are idempotent and exist only for cleanup |
| BR22.11 | constraint | `AssetStore.get_range` | Transfers only the requested bytes; the arithmetic stays with the caller |
| BR22.12 | constraint | `AssetStore.head`, metadata read | The two stores hold the media type independently; the port never reconciles them |
| BR22.13 | constraint | `IdentityStore.create_if_absent` | Atomic against a concurrent caller |
| BR22.14 | constraint | `IdentityStore` session ops | The session store evaluates no expiry |

**`BR22.x` is the unit-scoped group for U2, and all fourteen are listed above.**
Every one is a port-implementation obligation rather than behaviour a user
observes; every one carries `source: none` in `rules.md`; and **all fourteen are
reported in the traceability `reverse` array with their reason, leaving `coverage`
empty** — the correct reading of a unit the story map assigns **no FR at all**.
Where a rule serves a requirement, `rules.md` names it in a separate `enables:`
field alongside the owning rule and unit that discharge it, because a port
obligation *enables* an FR rather than discharging it (corrected at review, R-6).
An earlier version of this table stopped at `BR22.9` and silently dropped the last
five — including the ranged-read and atomic-provisioning obligations this
document's own operation prose cites by id. A derived view that disagrees with its
source is the defect, not the source.

---

## Assumptions & Open Questions

- **[assumption]** `commit` reports a stale base revision as a **return value**
  rather than an exception, because an optimistic write losing a race is an
  ordinary outcome and the consumer already owns what a caller is told. A store
  failure — a lost connection, a failed write — does raise, and the consumer maps
  it to the catch-all. No gate fixed this split; it follows from the contract's
  "returns the new state, or a conflict signal".
- **[assumption]** `now` is passed **into** `commit` rather than read from the
  adapter's clock, so that the content record's `updated_at` and its revision
  entry's `created_at` are the same instant by construction rather than by luck.
  The contract does not spell this out; it follows from the requirement that the
  entry and the document agree exactly.
- **[assumption]** `list_revisions` returns summaries rather than full documents.
  No artifact states it explicitly, but the listing cap of 52 combined with a
  payload ceiling above 4 MB makes a content-carrying listing untenable, and
  `read_revision` exists precisely to fetch one entry's content.
- **[open, carried from `contract-design`, owner U11]** The document-store
  adapter's large-payload threshold, and whether orphaned blobs are swept and by
  what.
- **[open, carried from `contract-design`, owner U11 / U12]** Where the composite
  index definition lives so it is not lost between the adapter and the deployment
  plan.
- **[carried hedge]** The cloud adapters are, by confirmed decision, implemented
  and contract-tested but **shipped unverified against the real services**. Every
  statement here about their behaviour is an obligation on them, not an
  observation of them.
- **[note]** The three ports are described as in-process interfaces. Nothing in
  this unit crosses a network boundary of its own; an adapter may, but the port
  does not model one.
- **[note]** This unit has **no state machine**. Every operation above is a single
  transition with no retained per-caller state, which is why the stage's
  state-machine view is absent rather than empty.

## Sources

- `inception/contract-design/contract-summary.md` §§ C2, C3, C4 — every operation
  name, argument, return and note above is taken from these three blocks.
- `construction/functional-design/rules.md` — BR3.6, BR3.7, BR3.17, BR3.22, BR4.1,
  BR4.8–BR4.19, BR5.1–BR5.9, BR6.24, BR7.17, BR7.18.
- `construction/storage-ports/functional-design/entities.md` — the persisted
  shapes these operations read and write, and the derived diagram above.
- `construction/storage-ports/functional-design/rules.md` — BR22.1 to BR22.14, and
  the derived rules summary above.
- `inception/units-generation/unit-of-work.md` § U2 — **with a known gap, owned by
  `units-generation`**: its `Realises` line reads "NFR3, and the persistence half of
  FR4, FR5, FR6 and FR7" and **omits FR3**, although `contract-summary.md` § C3
  assigns `IdentityStore` (`owner_record`, `session`, `login_attempts`) to this unit
  and this unit's `BR22.13` and `BR22.14` are the port obligations that make
  `BR3.7` and `BR3.16` — where `FR3.7` and `FR3.3` are discharged — implementable.
  The scope this unit's artifacts claim is correct against `contract-summary.md`;
  it is simply wider than the upstream `Realises` line states. Raised at review as
  **R-5** and **deliberately left uncorrected here**: `unit-of-work.md` is an
  inception artifact owned by `units-generation`, and correcting an upstream
  contract from a downstream artifact is how the two quietly diverge. It is carried
  to the gate as an open finding with **`units-generation` named as its owner
  stage**, and nothing under `inception/` was touched.
- `aidlc/spaces/default/memory/team.md` § *Testing Posture* — the
  adapter-parameterised conformance suite over two implementations.
