# Entity Schemas — U5 `media`

**Unit:** `u5-media` · **Kind:** `library` · **Components:** `MediaIntake`, `MediaDelivery`

**Upstream:** `construction/functional-design/entities.md` (ENT-6, and the ENT-4
`url` definition this unit is measured against), `inception/domain-design/components.md`
(entity ownership), `inception/contract-design/contract-summary.md` §§ C2 `asset_metadata`,
C4 `AssetStore`, `inception/requirements-analysis/requirements.md` FR6.1–FR6.7,
FR7.1–FR7.5, `codekb/Chiku_website/api-documentation.md` § *`POST /api/upload`*.

## How to read this document

This is the unit-scoped entity specification for `media`. It carries **one** entity
in full — **ENT-6 `Asset`**, owned by `MediaIntake` — plus the two cross-unit shapes
this unit must be able to read without owning: the `url` form that a content document
may legally hold, and the metadata row shape `ContentStore.asset_metadata` persists.

The other five entities (`OwnerAccount`, `Session`, `LoginAttemptWindow`,
`ContentDocument`, `ContentRevision`) belong to other units and are **not** restated
here. Where this unit reads one of them, it reads it through a port or through
`ContentAuthority`, and this document names the shape it depends on rather than
redefining it.

**Every maximum, pattern, enumerated value and numeric bound below is quoted exactly,
not paraphrased.** A developer implements this unit from this file plus `rules.md` and
`functional-spec.md` without opening `madhavi-tripathi/`.

**Structure of this document.** The fenced `yaml` block immediately below is the
**source of truth**: it governs, and it is what downstream stages read. Everything
after it is the **summary and rationale** — the same facts in prose, plus the
cross-unit shapes this unit reads but does not own, plus the reasoning a reader needs
in order not to "correct" something deliberate. **The prose must not contradict the
block; where it appears to, the block wins and the prose is a defect.**

---

## Source of truth

```yaml
source_of_truth: entities
stage: functional-design
unit: u5-media
kind: library
kind_note: >
  U5 media is a LIBRARY, not a service. U6 http-api is the only unit declaring
  service - there is exactly one deployed Python executable. media is embedded in it
  and is not independently deployable, which is the whole point of the
  ports-and-adapters split.
authority: >
  This block is the source of truth and governs. The prose below carries the summary,
  the rationale and the failure mode for each shape, and must not contradict it.
components: [MediaIntake, MediaDelivery]

entities:
  - id: ENT-6
    name: Asset
    owner_component: MediaIntake
    nature: ported
    description: >
      One stored media object. Created only by an accepted upload, never by a content
      write. An Asset is two rows in two different stores with no shared transaction -
      the bytes in AssetStore keyed by assetKey, and this metadata row in
      ContentStore.asset_metadata - so every property stated here is a property of two
      writes that agree because the same code wrote them from the same value. An
      original and each of its server-generated responsive variants are each a full
      Asset in its own right. There is no deletion path: storage grows monotonically.
    identifier: assetKey
    attributes:
      - name: assetKey
        logical_type: string
        required: true
        unique: true
        references: null
        allowed_values: null
        default: null
        min_length: null
        max_length: null
        constraints:
          - 'Generated as <uuid4>.<ext>'
          - 'Extension derived from the VALIDATED media type, never from the user filename'
          - 'Must match ''^[a-f0-9-]+\.(jpg|png|webp|pdf|mp4|webm|vtt)$'''
          - 'Same pattern gates the serving route (BR7.3); a key outside it is stored but unservable'
          - 'Character class is lowercase hex plus hyphen - the canonical lowercase UUID v4 alphabet'
      - name: filename
        logical_type: string
        required: true
        unique: false
        references: null
        allowed_values: null
        default: null
        min_length: null
        max_length: 200
        constraints:
          - 'The user original filename, truncated to the first 200 characters'
          - 'Display only. Never used to derive the key, the extension or the media type'
      - name: mediaType
        logical_type: enum
        required: true
        unique: false
        references: null
        allowed_values:
          - image/jpeg
          - image/png
          - image/webp
          - application/pdf
          - video/mp4
          - video/webm
          - text/vtt
        default: null
        constraints:
          - 'The VALIDATED type, from byte inspection - not the declared Content-Type'
          - 'Exactly seven types are accepted; the type-to-extension map is total and closed'
          - 'Held independently by AssetStore and by this row; BR7.18 makes THIS row authoritative for the served Content-Type'
      - name: byteSize
        logical_type: integer
        required: true
        unique: false
        references: null
        allowed_values: null
        default: null
        min: 1
        max: null
        constraints:
          - 'A zero-byte upload is rejected (BR6.13) before a record exists'
          - 'Counts this object only. NOT the sum weighed by the per-kind ceiling (BR6.11), which is not persisted'
      - name: width
        logical_type: integer
        required: false
        unique: false
        references: null
        allowed_values: null
        default: null
        nullable: true
        min: 1
        max: 40000
        constraints:
          - 'Present for images only, from the header parse (BR6.4-BR6.6)'
          - 'null for application/pdf, video/mp4, video/webm and text/vtt'
          - 'Entity-level: width * height <= 100000000 (BR6.7)'
      - name: height
        logical_type: integer
        required: false
        unique: false
        references: null
        allowed_values: null
        default: null
        nullable: true
        min: 1
        max: 40000
        constraints:
          - 'Same bounds and same nullability as width'
      - name: createdAt
        logical_type: string
        required: true
        unique: false
        references: null
        allowed_values: null
        default: null
        constraints:
          - 'ISO-8601 UTC instant'
      - name: derivedFrom
        logical_type: string
        required: false
        unique: false
        references: 'Asset.assetKey'
        allowed_values: null
        default: null
        nullable: true
        constraints:
          - 'The assetKey of the original this variant was generated from; null for an original'
          - 'NEW field - the source had no variant lineage because the browser produced variants'
          - 'Not derivable from key, filename or dimensions; if dropped, the relationship is unrecoverable'
    entity_constraints:
      - id: EC-6.1
        statement: 'width * height <= 100000000 when both are present (the decompression-bomb gate, BR6.7)'
      - id: EC-6.2
        statement: 'Bytes and metadata are two non-transactional writes. No transaction covers an Asset; BR6.24 compensates best-effort'
      - id: EC-6.3
        statement: 'The stored extension must equal the map value for mediaType. A derived extension (image/jpeg -> .jpeg) produces an unservable key'
      - id: EC-6.4
        statement: 'No deletion path exists. delete is used only by BR6.24 cleanup of a failed or cancelled upload, never as lifecycle management'
      - id: EC-6.5
        statement: >
          A variant written into a content document imageSource must additionally satisfy
          ENT-4 imageSource bounds of 1..16000, which are NARROWER than this entity
          1..40000. Variant targets stay at or below 1600 pixels.
    relationships:
      - name: variant_of
        from: Asset
        to: Asset
        cardinality: many-to-one
        direction: 'variant -> original'
        via: derivedFrom
        optional: true
        notes: 'Self-referential. An original has derivedFrom = null. Depth is exactly one: a variant is never itself a parent'
      - name: referenced_by
        from: ContentDocument
        to: Asset
        cardinality: many-to-many
        direction: 'ContentDocument -> Asset'
        via: 'literal substring /api/media/<assetKey> anywhere in the serialised document'
        optional: true
        enforced: false
        notes: >
          NOT a foreign key and not enforced in either direction. A document may legally
          reference a key no Asset has (ENT-4 url is more permissive than the key
          pattern), and an Asset may be referenced by no document. This relationship is
          the whole of the FR7.2 public-access decision (BR7.4) and it is evaluated over
          the PUBLISHED document only.
      - name: bytes_of
        from: Asset
        to: 'AssetStore object'
        cardinality: one-to-one
        direction: 'Asset -> object'
        via: assetKey
        optional: false
        enforced: false
        notes: 'Two stores, no shared transaction. Either side can exist without the other; that state is an orphan'

entities_read_not_owned:
  - name: ContentDocument.published
    owner_component: ContentAuthority
    owner_unit: u4-content-core
    read_as: 'one serialised string, for the BR7.4 substring scan'
    depends_on_property: 'serialisation does not escape /'
  - name: 'ENT-4 url'
    owner_component: ContentAuthority
    owner_unit: u4-content-core
    note: 'More permissive than assetKey. A document may legally hold a media URL the route will 404'
  - name: 'AssetStore.head result'
    owner_unit: u2-storage-ports
    returns: [size, etag, media_type]
    note: 'media_type is DISCARDED here; BR7.18 requires the metadata row instead'
```

---

## The wire format is frozen

The JSON wire format is **`camelCase`, and it is inherited rather than chosen**
(FR9.4). Python identifiers are `snake_case` everywhere, including storage columns;
conversion happens in **exactly one place** — the shared Pydantic base with
`alias_generator=to_camel` and `populate_by_name=True`, from which every request and
response model inherits.

Field names below are given in their **`camelCase` wire spelling**, because that is
the frozen, externally visible name. The Python attribute is the `snake_case` form of
the same name, produced by the alias generator.

---

## ENT-6 `Asset` — owned by `MediaIntake`

| Field | Type | Required | Default | Constraints |
|---|---|---|---|---|
| `assetKey` | string | yes | — | Generated as `<uuid4>.<ext>`, where the extension is derived from the **validated** media type and **never** from the user's filename. Must match `/^[a-f0-9-]+\.(jpg\|png\|webp\|pdf\|mp4\|webm\|vtt)$/` — this is also the serving route's gate. |
| `filename` | string | yes | — | The user's original filename, **truncated to the first 200 characters**. Stored for display only; never used to derive the key, the extension or the media type. |
| `mediaType` | enum | yes | — | Exactly one of `image/jpeg`, `image/png`, `image/webp`, `application/pdf`, `video/mp4`, `video/webm`, `text/vtt`. The **validated** type, from byte inspection — not the declared `Content-Type`. |
| `byteSize` | integer | yes | — | `>= 1`. A zero-byte upload is rejected before a record exists. |
| `width` | integer \| null | no | `null` | Present for images only, from the header parse. `1..40000`, and `width * height <= 100000000`. `null` for PDF, MP4, WebM and VTT. |
| `height` | integer \| null | no | `null` | Same bounds and same nullability as `width`. |
| `createdAt` | string | yes | — | ISO-8601 UTC instant. |
| `derivedFrom` | string \| null | no | `null` | The `assetKey` of the original this variant was generated from; `null` for an original. **New field** — the source had no variant lineage because the browser produced variants; FR6.5 moves generation server-side. |

### Media-type → extension map, exactly as the source declares it

| Media type | Extension |
|---|---|
| `image/jpeg` | `jpg` |
| `image/png` | `png` |
| `image/webp` | `webp` |
| `application/pdf` | `pdf` |
| `video/mp4` | `mp4` |
| `video/webm` | `webm` |
| `text/vtt` | `vtt` |

**Exactly seven types are accepted. No other type is accepted.** The map is total and
closed: there is no fallback extension, no "derive from the subtype", no
`mimetypes.guess_extension()`. `image/jpeg` maps to `jpg`, not `jpeg` — a derived
extension would produce `.jpeg`, which the serving-route pattern in `assetKey` does
**not** accept, so every such asset would 404 on its first request.

### `assetKey` — the two patterns and the one that governs

The key pattern is stated twice in the system and the two spellings are identical:

- `ENT-6.assetKey` — `/^[a-f0-9-]+\.(jpg|png|webp|pdf|mp4|webm|vtt)$/`
- `BR7.3`, the serving-route gate — `/^[a-f0-9-]+\.(jpg|png|webp|pdf|mp4|webm|vtt)$/`

They are the same pattern because the generated key must be servable by the route that
serves it. The character class is `[a-f0-9-]` — **lowercase hex plus hyphen**, which
is exactly the canonical lowercase UUID v4 alphabet. An uppercase UUID, a
base32/base64 key, or an underscore-bearing key is **generated-but-unservable**: the
upload succeeds, the metadata row is written, the bytes are stored, and every request
for the asset returns 404. Nothing errors at write time.

### `byteSize` — what it counts

`byteSize` is the byte length of the object the key names. For an **original** it is
the uploaded file's length. For a **variant** it is that variant's own length. It is
**not** the sum used by the per-kind ceiling: the ceiling (BR6.11) is applied to the
**sum of the original and every derived file** as a single admission decision, and
that sum is not persisted on any row.

### `width` / `height` — the parse result, and where else it is bound

`width` and `height` are the values returned by the byte-signature parsers
(BR6.4–BR6.6) and then gated by BR6.7. Two bound-sets are in play and they differ:

| Source of the bound | `width` | `height` | Area |
|---|---|---|---|
| `Asset` admission gate (BR6.7) | `> 0` and `<= 40000` | `> 0` and `<= 40000` | `width * height <= 100000000` |
| `ENT-4 imageSource` (the content document's own record of a variant) | integer `1..16000` | integer `1..16000` | none |

**The two are not the same and neither is a typo.** BR6.7 is the
decompression-bomb defence applied to what may be *stored*; `imageSource`'s
`1..16000` is a constraint on what may be *written into a content document*. An
original between 16,001 and 40,000 pixels on a side is therefore **storable but not
describable in `imageSources`**. Under FR6.5 (server-side variant generation) this
becomes reachable in a way it was not before: the variants this unit generates are
written into the upload response's `sources[]` and from there into the content
document, so a variant's dimensions must satisfy **both** bounds. Variant target sizes
must be chosen at or below 1600 pixels — see `functional-spec.md` § *Variant
generation*, where the source's retired 1600-pixel ceiling is recorded — which keeps
them inside `1..16000` with a wide margin.

### `derivedFrom` — the one new field, and the one it cannot be inferred from

`derivedFrom` is **new**: the source had no variant lineage because the browser
produced the variants and the server never knew they were related. It carries the
`assetKey` of the original.

It is **not** derivable from the key, the filename or the dimensions. Each variant
gets its own fresh `<uuid4>.<ext>` (BR6.3), the filename is the user's original
filename for every row in the group, and dimensions do not identify a parent. If this
column is dropped, the relationship is unrecoverable and a later orphan sweep cannot
tell a variant from an independently uploaded image.

### The two stores, and why an `Asset` is not one write

**Bytes and metadata are two separate stores with no shared transaction.**
`AssetStore` holds the bytes; `ContentStore.asset_metadata` holds this row. A failure
between the two writes leaves an orphan, which the best-effort cleanup path
reconciles (BR6.24).

Restated as an obligation on this unit: **there is no transaction that covers an
`Asset`.** Every property this document states about an `Asset` is a property of two
rows in two stores that agree only because the same code wrote them from the same
value at the same moment. BR7.18 names the concrete consequence — the media type is
held independently by both stores, and **anything that syncs only one will serve
mismatched types**.

### There is no deletion path

**There is no deletion path and no orphan collection anywhere.** Removing a reference
from the published document makes an asset non-public again on the next request, but
neither the stored bytes nor this row is ever deleted. Storage grows monotonically.
This is preserved behaviour, not an oversight to fix here (BR7.7c).

The one place `delete` is used is the best-effort cleanup of a **failed or cancelled**
upload (BR6.24, `AssetStore.delete`). That is failure cleanup, not lifecycle
management: it removes keys this request wrote, and nothing else.

---

## Cross-unit shape 1 — the `url` form a content document may hold

Owned by `ContentAuthority` (ENT-4, `construction/functional-design/entities.md`).
Restated here because it is the **only** definition of what a media reference may look
like inside the document this unit scans, and because it does not agree with this
unit's own key pattern.

`url` is a string, **max 2000** characters, plus a refinement that passes if **any**
of:

1. the value is empty (`''`);
2. it matches `/^https?:\/\/[^\s]+$/i` — **case-insensitive**;
3. it matches `/^\/api\/media\/[a-zA-Z0-9.-]+$/` — **case-sensitive**.

Failure message, verbatim: `Use a full https:// link.`

> **The `url` media form is more permissive than the media route's key pattern.** The
> schema accepts `/api/media/` followed by any run of `[a-zA-Z0-9.-]`, while
> `GET /api/media/{key}` only serves keys matching
> `^[a-f0-9-]+\.(jpg|png|webp|pdf|mp4|webm|vtt)$`. **A document may therefore legally
> contain a media URL the media route will 404.** This asymmetry exists today;
> preserve both patterns as written rather than reconciling them.

Two consequences this unit inherits and must not "fix":

- A content document containing `/api/media/Photo_01.JPG` validates, saves and
  publishes. The media route rejects it at BR7.3 with a 404 **before any storage
  access**. There is no warning at save time and no broken-link report.
- The permissive pattern includes `.` unrestricted, so `/api/media/../secret` is
  *schema-valid*. It is not *servable*: BR7.3's pattern has no `/` and no run of `..`
  that survives, so the request is a 404 at the gate. The gate is load-bearing as a
  path-traversal defence and not merely as a well-formedness check — **it must run
  before the key reaches any store**.

## Cross-unit shape 2 — the asset-metadata row (`ContentStore.asset_metadata`)

Owned by `U2 storage-ports` as part of contract C2. Operations: `register`, `remove`,
`read`. It is row-shaped, which is why it lives in `ContentStore` rather than in
`AssetStore`.

The row **is** ENT-6 above. This unit is its only writer and, together with
`MediaDelivery`, its only reader. Stated so the port's owner and this unit cannot
drift: the fields `register` accepts and `read` returns are exactly the eight fields
of ENT-6, in their `snake_case` storage spelling.

## Cross-unit shape 3 — what `AssetStore` returns for a `head`

Owned by `U2 storage-ports`, contract C4. `head(key)` returns **size, etag,
media_type**.

This unit uses **size** and **etag** from that result and **discards its
`media_type`**: BR7.18 requires the served `Content-Type` to come from the **metadata
row**, not from the object store. Both stores hold the media type; only one of them is
authoritative for the response header. Reading the object store's copy would pass every
test in which the two agree — which is every test that does not deliberately desync
them.

## Cross-unit shape 4 — the published document, as this unit sees it

Owned by `ContentAuthority` (`U4 content-core`); obtained through its
published-document read, served from its short-lived cache (BR7.1, BR7.2, ADR-002).

This unit does **not** read the published document as a structure. It reads it as
**one serialised string** and performs a substring scan over it (BR7.4). The only
property of that string this unit depends on is that serialisation **does not escape
`/`** — verified by the scan and recorded in BR7.5, so it need not be re-derived. If
the serialisation ever escapes `/`, every asset in the system becomes non-public
simultaneously and silently.

---

## Assumptions & Open Questions

- **[assumption A-4, carried from `construction/functional-design/entities.md`]**
  `Asset.width` / `Asset.height` are recorded as nullable because the source's `assets`
  table stores **no dimensions at all** — the parse result is used for validation and
  for the upload response and then discarded. Persisting them is a small addition that
  FR6.5 makes useful (server-side variant generation needs the original's dimensions),
  and `components.md` already lists them as attributes of the entity. **If a reviewer
  prefers strict parity, dropping both columns changes no rule in `rules.md`** — but it
  would force every variant regeneration to re-parse the original's bytes.
- **[assumption, this unit]** `derivedFrom` is populated for every generated variant
  and `null` for every original. No decision fixed this; it follows from the field
  existing at all. The alternative — leaving it `null` everywhere and treating variants
  as independent assets — makes the column inert and is recorded here so the choice is
  visible rather than implied.
- **[assumption, this unit]** The eight ENT-6 fields are exactly the fields
  `ContentStore.asset_metadata.register` accepts. `contract-summary.md` § C2 describes
  the operation as "row-shaped" without enumerating it, so the enumeration is taken
  from ENT-6. If the port's owner (`U2 storage-ports`) enumerates a different set, the
  port is authoritative and this document follows it — the contract-ownership rule is
  that the provider owns the spec.
- **[open, no owner — surfaced here, not decided here]** ENT-6 records `width`/`height`
  bounds of `1..40000` while `ENT-4 imageSource` records `1..16000` for the same
  quantities in the content document. Under the source's browser-side variant
  preparation this gap was unreachable in practice, because the browser's 1600-pixel
  ceiling kept every written `imageSource` far inside both bounds. **FR6.5 moves
  generation server-side and therefore makes the gap reachable for the first time.**
  This unit closes it by constraint — variant targets stay at or below 1600 pixels —
  but nothing enforces that choice outside this unit's own code, and no gate check
  asserts it. Recorded so a later reader can tell a bounded choice from an unexamined
  one.
- **[note]** The seeded starting content's media references (FR9.3) are **not**
  enumerated here. They are instance data owned by `U4 content-core` and reproduced
  from the recorded source fixtures (U1). What matters to this unit is only that they
  are `url` values of form (3) above, and therefore participate in the BR7.4 substring
  scan exactly as any other reference does.

## Sources

- `construction/functional-design/entities.md` § *ENT-6 `Asset`* — the field table, the
  media-type→extension map, the two-store note, the no-deletion note and assumption
  A-4 are carried from it unchanged; § *ENT-4 shared building blocks* — the `url`
  definition and the permissiveness asymmetry; § *ENT-4 `item`* — `imageSources`,
  `imageSource`'s `1..16000` bounds, `transcript`'s 60,000-character maximum.
- `construction/functional-design/rules.md` — BR6.1–BR6.3 (the accepted set and key
  derivation), BR6.7 (the dimension gate), BR6.11 (the ceiling is a sum), BR6.24
  (two non-transactional writes), BR7.3 (the serving gate), BR7.5 (`/` is not escaped
  in serialisation), BR7.7c (no deletion, no orphan collection), BR7.18 (the media type
  comes from the metadata store).
- `inception/domain-design/components.md` § `MediaIntake` — `entities: [Asset]` with
  its attribute list; § `MediaDelivery` — `entities: []`.
- `inception/contract-design/contract-summary.md` §§ C2 (`asset_metadata`: `register`,
  `remove`, `read`), C4 (`AssetStore`: `put`, `get`, `get_range`, `head`, `delete`).
- `inception/requirements-analysis/requirements.md` FR6.1–FR6.7, FR7.1–FR7.5, FR9.4.
- `inception/units-generation/unit-of-work.md` § *U5 — media*.
- `WORKING-RECORD.md` §§ 2 (D12, D24), 3 (hazards FR6.2, FR7.2, FR7.4), 5 (frozen wire
  format).
