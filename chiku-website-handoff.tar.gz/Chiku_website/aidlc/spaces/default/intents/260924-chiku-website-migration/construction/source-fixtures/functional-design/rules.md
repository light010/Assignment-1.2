# Rules — U1 `source-fixtures`

**Upstream:** `inception/units-generation/unit-of-work.md`,
`inception/requirements-analysis/requirements.md`,
`inception/domain-design/components.md`,
`inception/contract-design/contract-summary.md`.

These carry `BR21.x` ids. Group 21 is U1's unit-scoped group under the corpus
scheme: FR-derived groups are `BR3.x`–`BR10.x` and keep the numbers the
workflow-level `rules.md` gave them; a rule that realises only an NFR or a
constraint takes a unit-scoped group at **unit number + 20**.

> **Correction.** These were first written as `REC-` ids on the reasoning that a
> recording rule is not a business rule and that `BR` ids which reach no `FR`
> would be reported as orphans. The second half was right and the conclusion was
> wrong: the framework already solves it with the `reverse` array in
> `traceability.json`, which records a rule that intentionally has no acceptance
> criterion. An invented namespace was unnecessary, and the traceability sensor
> does not recognise it — so the ids that were meant to avoid a false trace
> produced no trace at all. Renumbered to `BR21.x`, with all six listed in
> `reverse` against **NFR10**.

This unit decides nothing about the product. Its rules govern **how evidence is
recorded**, and they matter because a fixture recorded the wrong way is worse than
no fixture: it is a wrong oracle that every dependent test then agrees with.

```yaml
rules:
  - id: BR21.1
    statement: A recorded body and its headers are stored raw, byte for byte, exactly as the source returned them.
    category: constraint
    applies_to: RecordedFixture
    trigger: Capturing any response.
    logic: >
      IF a recorder would strip volatile attributes, build hashes or whitespace at
      record time THEN it must not — normalisation happens at COMPARE time, in the
      consuming test.
    violation: >
      Normalising at record time bakes today's idea of "irrelevant" into permanent
      evidence. A later question the normaliser discarded can never be asked again,
      because the source is gone.
    source: NFR10

  - id: BR21.2
    statement: Every fixture carries the commit it was recorded against and the UTC time of recording.
    category: validation
    applies_to: RecordedFixture
    trigger: Writing a fixture to disk.
    logic: IF sourceCommit or recordedAt is absent THEN the fixture is not evidence and must not be used as an oracle.
    violation: >
      A fixture of unknown provenance is indistinguishable from a guess someone
      wrote down, and it will be trusted exactly as much as a real one.
    source: NFR10

  - id: BR21.3
    statement: Deliberate defects are recorded as they are, with a note saying the preservation is deliberate.
    category: constraint
    applies_to: RecordedFixture
    trigger: The source does something that looks wrong and is being preserved under the parity rule.
    logic: >
      IF the source emits no not-modified response despite an ETag, OR returns 200
      with a full length from HEAD while ignoring Range, OR returns partial content
      for the whole object on an oversized suffix range, OR counts characters rather
      than bytes for a size cap THEN record it verbatim and annotate it, never correct it.
    violation: >
      A recorder who "fixes" a response while capturing it produces an oracle that
      disagrees with the system it was taken from, and the port that matches the
      oracle then fails against reality.
    source: NFR10

  - id: BR21.4
    statement: Recording runs against a disposable local database and the local test identity only.
    category: authorization
    applies_to: StoredStateSnapshot
    trigger: Any recording run.
    logic: >
      IF a run would touch a hosted database, a hosted object store, published
      content, or any credential belonging to the live site THEN it does not run.
    violation: The site this migration exists to preserve is the thing at risk.
    source: NFR10, C4

  - id: BR21.5
    statement: If the source application cannot be booted, this unit reports blocked — never skipped.
    category: policy
    applies_to: RecordedFixture
    trigger: A precondition cannot be met.
    logic: >
      IF madhavi-tripathi/ cannot be booted THEN report blocked, name the reason,
      and explicitly downgrade every dependent unit's parity claim to "checked
      against the written knowledge base".
    violation: >
      Every downstream parity claim would rest on evidence that does not exist while
      reading as though it rests on recorded data. This is the one failure in this
      unit that propagates into every other unit's confidence.
    source: NFR10
    enforcement: >
      PROCESS DISCIPLINE, not a checked constraint. Nothing in this unit or
      downstream mechanically detects a recording run that was skipped rather than
      reported blocked. It is stated as a rule because the person or agent running
      the recorder is the only thing that can honour it, and because the failure is
      invisible from the artifacts alone — a missing fixture set and a skipped one
      look identical on disk.

  - id: BR21.6
    statement: The size-cap fixtures record the request body length in characters AND in UTF-8 bytes.
    category: validation
    applies_to: RecordedFixture
    trigger: Recording the F6 boundary fixtures.
    logic: IF only one of the two numbers is recorded THEN the fixture cannot settle the character-versus-byte question and is incomplete.
    violation: >
      The distinction is invisible until it rejects the owner's longest transcript,
      and a fixture that records one number cannot prove which unit the cap counts.
    source: NFR10

  - id: BR21.7
    statement: >
      Every media fixture records the identity it was fetched under. The draft-only
      and missing-key cases are recorded under BOTH identities; the malformed-key
      case is recorded ONCE.
    category: validation
    applies_to: RecordedFixture
    trigger: Recording F7, F9, F10 or F12.
    logic: >
      IF a media fixture is recorded THEN set `identity` to `anonymous` or `owner`.
      The number of recordings per key case follows the number of DISTINCT SOURCE
      BRANCHES that case can reach, which is not the same as the number of distinct
      statuses. (1) DRAFT-ONLY - record under EACH identity, because the STATUSES
      DIVERGE: route.ts line 8 is
      `if(!isPublic && !await editorAccess()) return 404`, and `editorAccess()` is
      true for the `__sites_local_auth=1` cookie Precondition 3 establishes for the
      whole session, so the owner receives 200 with the body where anonymous
      receives 404. (2) MISSING - record under EACH identity, because although both
      return 404 the BRANCHES DIFFER: anonymous is refused at the line-8 auth block
      (a well-formed key absent from the published document is not public), while
      the owner passes line 8 and is refused at the line-9 asset-row lookup. Two
      branches, one status. (3) MALFORMED - record ONCE, because the line-6 key
      regex returns before `readContent()` and before `editorAccess()` are ever
      called: there is ONE branch, reachable identically under either identity, and
      a second recording would capture the same code path twice.
    violation: >
      A recorder that leaves the ambient cookie on records 200 as the oracle for
      the PRIVATE case. The port that matches that oracle serves non-public assets
      to anonymous users. This is FR7.2, a hazard-marked requirement, and it is the
      single most damaging way this unit could fail - the fixture would look
      correct and every dependent test would agree with it.
    source: NFR10, evidence for FR7.2
    note: >
      Placed after BR21.6 at review. It previously sat between BR21.5 and BR21.6,
      out of numeric order in the block that governs; the summary table and the
      prose sections now agree with it in id order too.
```

## Rules summary

| id | Category | What it protects | Source |
|---|---|---|---|
| BR21.1 | constraint | Raw recording; normalise at compare time | NFR10 |
| BR21.2 | validation | Provenance makes a fixture evidence | NFR10 |
| BR21.3 | constraint | Deliberate defects preserved, not corrected | NFR10 |
| BR21.4 | authorization | Nothing hosted is touched | NFR10, C4 |
| BR21.5 | policy | Blocked is reported as blocked, never skipped | NFR10 |
| BR21.6 | validation | Size boundary recorded in both units | NFR10 |
| BR21.7 | validation | Media fixtures record their identity; draft-only and missing recorded under both, malformed once | NFR10, FR7.2 |

## Why each rule exists

The YAML block above is the source of truth. These notes carry the failure mode
behind each rule, which is the part a reader needs when deciding whether a rule
still applies.

### BR21.1 — Record, never normalise

**Owner:** U1. **Rule:** a recorded body and its headers are stored **raw**, byte
for byte, exactly as the source returned them. Normalisation — stripping volatile
attributes, build hashes, whitespace — happens at **compare** time, in the
consuming test, never at record time.

**What breaks if got wrong:** normalising at record time bakes today's idea of
"irrelevant" into permanent evidence. A later question the normaliser discarded
can never be asked again, because the source is gone.

### BR21.2 — Provenance is part of the fixture

**Owner:** U1. **Rule:** every fixture carries the commit it was recorded against
and the UTC time of recording. A fixture without both is not evidence and must not
be used as an oracle.

**What breaks if got wrong:** a fixture of unknown provenance is indistinguishable
from a guess someone wrote down, and it will be trusted exactly as much as a real
one.

### BR21.3 — Record the deliberate defects too

**Owner:** U1. **Rule:** where the source does something that looks wrong and is
being preserved under the parity rule, the fixture records it **as it is**, with a
note saying it is deliberate. Specifically: no not-modified response despite an
ETag being emitted; `HEAD` returning 200 with a full length while ignoring a
`Range` header; an oversized suffix range returning partial content for the whole
object; a size cap counting characters rather than bytes.

**What breaks if got wrong:** a recorder who "fixes" a response while capturing it
produces an oracle that disagrees with the system it was taken from, and the port
that matches the oracle then fails against reality.

### BR21.4 — Nothing hosted is touched

**Owner:** U1. **Rule:** recording runs against a **disposable local database** and
the local test identity only. No hosted database, no hosted object store, no
published content, no credential belonging to the live site.

**What breaks if got wrong:** the site this migration exists to preserve is the
thing at risk.

### BR21.5 — Blocked is not skipped

**Owner:** U1. **Rule:** if `madhavi-tripathi/` cannot be booted, this unit reports
**blocked**, names the reason, and every dependent unit's parity claim is
explicitly downgraded to "checked against the written knowledge base". It is never
reported as skipped, and the downgrade is never silent.

**What breaks if got wrong:** every downstream parity claim would rest on evidence
that does not exist, while reading as though it rests on recorded data. This is the
one failure in this unit that would propagate into every other unit's confidence.

### BR21.6 — The size boundary is recorded in both units

**Owner:** U1. **Rule:** the size-cap fixtures record the request body's length in
**characters and in UTF-8 bytes**, both. The pair is the evidence; either alone
proves nothing.

**What breaks if got wrong:** the character-versus-byte distinction is invisible
until it rejects the owner's longest transcript, and a fixture that records only
one number cannot settle it.

### BR21.7 — Media fixtures carry the identity they were fetched under

**Owner:** U1. **Rule:** see the yaml block. **Draft-only** and **missing** keys
are each recorded twice, once anonymous and once as the owner; the **malformed**
key is recorded **once**.

**The count per case is the number of distinct source branches, not the number of
distinct statuses.** That distinction is what keeps the rule honest in both
directions:

| Key case | Recordings | Why |
|---|---|---|
| **Draft-only** | 2 | The **statuses diverge** — 404 anonymous, 200 + body as owner |
| **Missing** | 2 | Same status both ways, but **different branches**: anonymous is refused at the line-8 auth block, the owner at the line-9 asset-row miss |
| **Malformed** | 1 | The line-6 key regex returns **before** `readContent()` and `editorAccess()` are called — one branch, identity-irrelevant |

**What breaks if got wrong:** this is the one defect in this unit that produces a
*confidently wrong* oracle rather than a missing one. `editorAccess()` returns true
for the recording session's own cookie, so the private case silently records as
200-with-body. Nothing downstream would question it, because a fixture is what the
tests treat as ground truth.

## Assumptions & Open Questions

- **[open]** Which of the source's two cancellation literals accompanies which 499
  is unconfirmed. If only one is reachable in practice, record which and state
  that the other is unreachable rather than leaving the pair ambiguous.
- **[assumption]** Recording rules are worth writing down at all for a unit that
  produces test data. They are, because this unit's output is the definition of
  correct for five other units, and its failure mode is silent agreement rather
  than a visible error.
