# Code Generation Plan — U1 `source-fixtures`

## Unit scope

This unit produces the **recorded source-behaviour fixtures**: the golden HTTP and
stored-state evidence captured from the running `madhavi-tripathi/` app. It ships no
application feature. Its output is the oracle five other units test against.

This unit is the only one in the project whose capability **expires**. The fixtures can
only be recorded while the source app still boots; once `madhavi-tripathi/` is retired
they cannot be recovered.

## Current state — most of this unit is already delivered

The recording was performed against the running source app and **57 fixtures already
exist** at `chiku-website/fixtures/`:

| Family | Count | What it pins |
|---|---|---|
| Public routes, editor routes, content/history API | 10 | Rendered HTML and JSON per identity |
| Media key cases x identity | 5 | draft-only, missing, malformed |
| HEAD and the three deliberate defects | 4 | Range ignored on HEAD; ETag with no 304; oversized suffix returns 206 |
| Byte-range branches | 18 | Every `parseByteRange` outcome, both If-Range paths |
| Write path: save / conflict / publish | 4 | Including the 409 envelope the editor branches on |
| Authorization and CSRF on the write path | 3 | 403 envelope vs framework-level rejection |
| Size cap boundary | 4 | Including the astral pair that settles the unit question |
| Malformed write bodies | 6 | The `400` + `issues[]` shape |
| Stored-state snapshots | 5 | `site_content`, `content_revisions`, `assets` before/after |

Provenance is on every fixture: source commit `ad27038`, UTC timestamp, and the
recorder's preconditions in `MANIFEST.json`.

## What this plan still has to do

The recorder itself currently lives outside the repository, in the session scratchpad.
That makes the fixture set unreproducible by anyone else, which defeats its purpose as
shared evidence. The remaining work is to bring it in and prove the set is well-formed.

- [x] **Step 1 — Verify the test runner and record the exact unit-scoped command.**
      The runner already exists (`pytest` 9.1.1 under `chiku-website/backend/`, resolved
      by `uv`). Confirm it executes and record the exact command in
      `unit-test-instructions.md`. Runner readiness precedes every test step.
- [x] **Step 2 — Move the recorder into the repository** as
      `chiku-website/fixtures/record.py`, with its corrective pass folded in. It must
      carry, in code rather than in a comment, the two preconditions that make an owner
      recording possible at all: the dev server must be reached on `localhost` (it binds
      `[::1]` only), and the `editors` table must already hold the local identity, because
      `isEditor()` grants access only via an existing row or an email equal to
      `OWNER_EMAIL`.
- [x] **Step 3 — Characterization tests for the fixture set itself.** This unit's oracle
      is the recording, so its tests assert the *set*, not the source: every fixture has a
      body file and metadata; provenance is present and non-empty on all 57; every
      declared deliberate defect names the behaviour it preserves; the manifest's counts
      match what is on disk. These are written against the recorded set and observed
      against it, per the contract's custom ordering.
- [x] **Step 4 — Assert the two corrected facts explicitly**, because both were wrong in
      the design corpus and a later reader will meet the documents before the fixtures:
      the size cap counts UTF-16 code units (the astral pair proves a byte cap and a
      character cap each fail in opposite directions), and the draft-only media key
      diverges 404/200 by identity.
- [x] **Step 5 — Document the recording procedure** in `chiku-website/fixtures/README.md`:
      how to boot the source, the two preconditions, how to re-record, and the expiry.
- [x] **Step 6 — Traceability.** Map each recorded family to the `BR21.x` rule and the
      requirement it carries evidence for.

## Test files this plan produces

Per the Standard strategy (5-8 tests per component) applied to the one component this
unit has — the fixture set and its recorder:

- `chiku-website/backend/tests/test_fixture_set.py` — set-level integrity: presence,
  provenance, manifest/disk agreement, defect annotations, caveat annotations.
- The two fact assertions in Step 4 already exist as `tests/test_limits.py` and
  `tests/test_error_copy.py`, written against these fixtures; this unit does not
  duplicate them, it depends on them.

No new test framework is introduced. `pytest` and `httpx` are already the affirmed tooling.

## Traceability — plan step to rule

| Step | Realises |
|---|---|
| 2 | BR21.1 (raw recording), BR21.2 (provenance), BR21.4 (nothing hosted touched) |
| 3 | BR21.2, BR21.5 (blocked is reported, never skipped) |
| 4 | BR21.6 (size boundary in both units), BR21.7 (media identity) |
| 5 | BR21.4, BR21.5 |
| 6 | NFR10 |

## Deviation recorded against the affirmed practice

`team.md` requires recording against a **disposable local database**. That was not
possible as written: on an empty database the local mock identity is not an editor, so
every owner-identity fixture would have recorded 404 — the exact inverse of the oracle
BR21.7 exists to protect. The recording used the existing local dev database, which is
still local and still touches nothing hosted, and `.wrangler/state` was backed up first.
The precondition is recorded in `MANIFEST.json` so a re-record cannot repeat the mistake.

## Testing Contract

```json
{
  "version": 1,
  "methodology": "custom",
  "source": "team",
  "ordering": "Within each unit, the characterization tests for that unit's hazard-register",
  "scope": "runtime-split-migration",
  "test_strategy": "standard",
  "project_type": "brownfield",
  "applicable_notes": [
    {
      "layer": "org",
      "text": "We treat tests as a first-class deliverable in every Bolt. The specific\nmethodology (TDD, BDD, ATDD, or classic test-after) is affirmed at\npractices-discovery and recorded in `team.md` under this heading with explicit\n`Methodology` and `Ordering` fields; Code Generation resolves those fields\nindependently from coverage, tooling, and scope notes.\n\nWhen no posture has been affirmed, our default per scope is:\n- **Methodology**: test-after\n- **Ordering**: implement each applicable testable layer, then write and run\n  that layer's tests.\n- `mvp`, `enterprise`, `feature`, `infra`, `classic` add an 80% line-coverage\n  floor and CI execution before merge.\n- `bugfix`, `security-patch` add a targeted regression for the specific\n  bug/vulnerability and require the existing suite to remain green.\n- `express` uses the Minimal strategy: requirement-driven unit tests (one per\n  requirement, with a happy-path floor per component); existing tests remain\n  green.\n- `poc`, `refactor`, `workshop` add no extra new-test floor and require the\n  existing suite to remain green.\n\nThe active `Test Strategy` still applies in every scope and determines test\nvolume/types. Scope floors are additive; they never reduce or replace the\nselected strategy.\n\nBuild and Test verifies defined coverage floors and affirmed quality targets;\nthey may not be weakened to make a step pass.\n\nAffirm a stricter posture in `team.md` if the team commits to one."
    },
    {
      "layer": "team",
      "text": "> **Read this section as a proposal we have adopted, not as practice we observed.** The source\n> project contains zero test files, zero testing dependencies and no `test` script, so there was no\n> prior testing practice to discover — every item below was chosen at the practices-discovery gate\n> on 2026-09-24 and affirmed by the site owner, rather than read off how this team already works.\n\n- **Methodology**: custom\n- **Ordering**: Within each unit, the characterization tests for that unit's hazard-register\n  behaviours and for the storage port are written and observed to fail before the Python\n  implementation of that behaviour exists; every other backend test is written immediately after\n  the code it covers; that unit's frontend render layer is ported only once its backend tests\n  pass; a unit with no backend surface begins at the frontend step; and a unit whose behaviour is\n  not enumerated in the hazard register takes the recorded source fixtures as its oracle, falling\n  back to the reverse-engineering knowledge base where no fixture exists.\n- **What `custom` means, and why it is not `test-after`.** Under test-after, a developer who\n  misreads a dense source line implements from the misreading and then writes the test from the\n  same misreading: the test is green, coverage is satisfied, and the defect ships. That is not\n  hypothetical here — a port declaring `research_topic: Topic | None = None` passes `ruff`,\n  `mypy --strict`, `tsc`, the Compose end-to-end flow and 100% line coverage while rendering three\n  identical research cards and returning zero publications for every topic filter. Only a test\n  whose assertion came from the *source* behaviour catches it. `tdd` everywhere is equally wrong:\n  most of the ported render layer has no enumerated oracle, and writing failing render assertions\n  first for ported JSX is waste. Note this is **characterization** testing, not TDD — the test is\n  written from the recorded behaviour of the source, which is why the fixtures below matter.\n- **Recorded source-behaviour fixtures come first, before any Python is written.** Drive the\n  running `madhavi-tripathi/` app over HTTP with `httpx` once and record as golden fixtures: every\n  public route's rendered HTML, `GET /api/content`, the media route's status codes across public /\n  draft-only / missing keys, the 413 boundary in both characters and UTF-8 bytes, byte-range\n  responses across all six rejection branches, and the stored-row state after a save / publish /\n  conflict sequence. It uses a disposable local database and a test identity; nothing hosted is\n  touched. Until these exist, every parity assertion in this project rests on a human's reading of\n  a document; after they exist, they assert against the system. **This capability expires when the\n  source app is retired** — a fixture not recorded before then cannot be recovered.\n- **Coverage floor — backend**: **80% branch coverage** over `chiku-website/backend/`, measured by\n  `pytest --cov --cov-branch` and `coverage report --fail-under=80`, with generated migration\n  files and `__main__` entry points excluded. Branch, not line, is deliberate and costs one flag:\n  every high-risk behaviour in this port is a branch or a `??` fallback chain, and line coverage\n  marks those covered when only one side ever runs. This is a **new floor we are choosing**, not\n  an inherited one — `org.md`'s 80% floor is written for the named stock scopes (`mvp`,\n  `enterprise`, `feature`, `infra`, `classic`) and this workflow runs the custom scope\n  `runtime-split-migration`, which appears in none of them. Absent this affirmation there would be\n  no numeric floor at all. The active `Test Strategy` is **Standard** and continues to govern test\n  volume and type independently of this number.\n- **Coverage floor — hazard modules**: a second, scoped\n  `coverage report --fail-under=100 --include=<hazard module globs>`. The hazard modules are the\n  ports of the behaviours ranked in `code-quality-assessment.md` § *Hazard index* — the\n  seven-statement concurrency batch and its `last_mutation` ABA defence, the media access rule, the\n  `researchIdentity` back-compat shims, the request-size cap, the three hand-written image header\n  parsers, the WebVTT validator, the byte-range parser and the editor state machine. Each carries a\n  test per enumerated branch. An aggregate percentage cannot distinguish \"this branch is exercised\"\n  from \"this branch was ported correctly\"; these are precisely the branches whose silent loss ships\n  a defect, so they get both the per-branch tests and a floor that leaves no room.\n- **Coverage floor — frontend**: none. The Next.js frontend renders only and owns no application\n  decision, so a line-coverage number on it would measure JSX traversal rather than behaviour.\n- **The test families, and which are mandatory.** Mandatory: the recorded fixtures above; backend\n  unit tests for branch-level behaviour of ported logic; **storage-port contract tests written as\n  an adapter-parameterized conformance suite and run against both the real SQLite adapter and an\n  in-memory fake** (two implementations is the minimum that proves the suite tests the port\n  contract rather than SQLite, and it is the whole argument for having a port); API contract tests\n  in the non-circular form — assert the **generated** OpenAPI document against the **hand-written**\n  contract from `contract-design`, and commit the generated `openapi.json` as a snapshot so an\n  unintended contract change surfaces as a gate diff rather than as a frontend 422 three Bolts\n  later; and the Compose end-to-end flow. Frontend render checks are mandatory but add **no\n  frontend test framework**: assert against the HTML the composed stack returns, using the recorded\n  fixtures, and make the assertions named rather than \"landmarks present\" — each of the three\n  research cards has a distinct topic class and icon, the publications topic filter returns\n  non-zero for each seeded theme, each research card shows non-zero related papers. Browser checks\n  (Playwright) are optional today with one condition that flips them: **if the six-flag editor\n  state machine lands in the frontend rather than the backend, a browser check becomes the only\n  possible verification of it and becomes mandatory.** Flag that as a dependency on `domain-design`.\n- **Compose end-to-end runs on every Bolt merge**, not only at the skeleton gate and at the end.\n  With no CI, the per-merge run *is* the CI, and the alternative is a container-level regression\n  surfacing many Bolts after the one that caused it, with no bisect signal and nobody watching a\n  dashboard. Keep the cost bounded by keeping the flow small and fixed — the skeleton's two paths\n  plus one auth-failure path — so it stays inside a few minutes on cached layers.\n- **Parity is verified two ways, and pixel comparison is rejected.** (1) A **normalised\n  DOM-structure diff** against the recorded source HTML: strip volatile attributes, build hashes\n  and whitespace, then diff the element tree plus text content per route. It catches what actually\n  breaks in a port — a dropped section, a wrong class, a missing copy default among the 25 leaf\n  defaults — at a fraction of the setup cost of pixel screenshots and without their flakiness.\n  (2) An explicit **page-by-page human review at the end**, recorded as a checklist. Per-route\n  screenshot comparison was considered and **rejected**: it is brittle against fonts, antialiasing\n  and animation, and it is not a live option to be reopened later. Until the DOM diff exists, the\n  parity rule is an unfalsifiable claim, which is what this closes.\n- **Boundary enforcement is a command, not an assertion.** A rule nobody can check is a wish. Three\n  checks, all on the gate: the frontend's TypeScript types for backend payloads are **generated**\n  from the backend's `/openapi.json` with `openapi-typescript`, committed, regenerated at the gate,\n  and the gate fails if the output is dirty — which makes the boundary type-checked rather than\n  asserted, since a backend field rename then fails `tsc --noEmit` with a file and a line; a\n  three-line grep fails the gate if `chiku-website/frontend` contains any `'use server'` directive,\n  any `app/**/route.ts`, or any `middleware.ts` (an ESLint `no-restricted-syntax` rule is a nicer\n  editor experience, but the grep is the one that is certain); and one pytest walks the AST of\n  `routers/` modules and asserts none of them imports a `store` module or `sqlite3`.\n- **The source has no suite to keep green.** The org rules for several scopes say \"the existing\n  suite remains green\". There is none — the scan found zero test files, zero testing dependencies\n  and no `test` script anywhere in `madhavi-tripathi/`. Every test in this project is a new test.\n  The only inherited automated checks are `tsc --noEmit` (strict) and `pnpm lint`.\n- **Tooling**: backend — pytest 9.1.1 with `httpx` 0.28.1 for FastAPI transport-level tests,\n  `ruff` 0.16.8 and `mypy` 2.3.1 as gating checks, dependencies resolved by `uv` 0.10.0. Frontend\n  — `tsc --noEmit` and ESLint 9 with `eslint-config-next`, unchanged from the source project.\n- **The merge gate.** A Bolt may squash-merge to `main` only when every one of these passes on the\n  developer machine, in this order, with the **verbatim output pasted into the gate approval**:\n\n  ```\n  ruff check\n  ruff format --check\n  mypy --strict\n  pytest --cov --cov-branch\n  coverage report --fail-under=80\n  coverage report --fail-under=100 --include=<hazard module globs>\n  tsc --noEmit\n  pnpm lint\n  git diff --no-index madhavi-tripathi/app/<f> chiku-website/frontend/app/<f>   # per unmodified ported file\n  <boundary grep: 'use server' / app/**/route.ts / middleware.ts>\n  <openapi-typescript regeneration — gate fails if the committed output is dirty>\n  uv export --frozen --no-dev --no-emit-project -o .audit/requirements.txt && uvx pip-audit -r .audit/requirements.txt\n  pnpm audit --prod --audit-level high\n  docker compose up  +  the end-to-end flow\n  ```\n\n  **Dependency advisories block at High and above.** An advisory with no fix available does not\n  silently pass and does not silently block: it is recorded with the **package, the advisory id,\n  the reason it cannot be fixed, and the named Bolt that owns it**, and the gate then proceeds on\n  that record. This is consistent with the correction already in `project.md` that any finding\n  carried past a gate needs a named owner.\n\n  Gates protect the parity guarantee; weakening one to make a Bolt pass is an incident, not a\n  shortcut."
    }
  ],
  "obligations": {
    "strategy": "standard",
    "strategy_volume": [
      "Five to eight tests per component.",
      "Unit tests plus integration tests for key boundaries.",
      "Add E2E, performance, or security tests when requirements demand them."
    ],
    "scope_floor": [
      "Keep the existing test suite green.",
      "This scope adds no extra new-test floor beyond the selected test strategy."
    ],
    "combination_rule": "Apply every selected-strategy obligation and every scope-floor obligation; neither replaces the other, and a targeted scope regression may add the narrowest necessary test type beyond the strategy default."
  },
  "plan_profile": {
    "methodology": "custom",
    "runner_step": "Verify the existing test runner/configuration and record the exact unit-scoped command.",
    "runner_ready_before_first_test": true,
    "testable_layers": [
      "Data model / database behavior",
      "Repository / data access",
      "Business logic",
      "API / endpoint",
      "Frontend behavior"
    ],
    "steps": [
      "Project structure and production configuration skeleton.",
      "Verify the existing test runner/configuration and record the exact unit-scoped command.",
      "Custom ordering - Within each unit, the characterization tests for that unit's hazard-register",
      "Implementation and tests - preserve that exact ordering; do not convert it to layer-local TDD.",
      "Environment/build configuration.",
      "Documentation and traceability."
    ]
  },
  "input_sha256": "sha256:ae7fe698329b9815a1e703cfb6f92beeb23e35c6e2f83768ad7ab02dffb4a262",
  "contract_sha256": "sha256:6b84da29d5313b29b3058ef863280c58a9f6f401f244363de9431d8063261179"
}
```
