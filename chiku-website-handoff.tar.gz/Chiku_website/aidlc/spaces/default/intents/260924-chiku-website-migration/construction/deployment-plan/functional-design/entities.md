# Entities — U12 `deployment-plan`

**Upstream:** `inception/units-generation/unit-of-work.md`,
`inception/requirements-analysis/requirements.md` (NFR6, S4),
`inception/domain-design/components.md`,
`inception/contract-design/contract-summary.md`.

This unit produces a **document**. It owns no runtime entity and no persisted
record. What it does own is the shape of the **costed plan** — and that shape is
load-bearing, because NFR6's zero-recurring-cost target is verified as a property
of this document rather than by observing a bill. A cost line without a dated
source is an opinion.

```yaml
entities:
  - name: CostLine
    description: >
      One row of the cost table. The unit of verification for NFR6: the
      zero-recurring-cost claim is exactly the conjunction of every CostLine's
      expected_charge being zero, each backed by a dated official source.
    attributes:
      - name: service
        type: string
        required: true
        allowed_values: [Cloud Run, Firestore, Cloud Storage, Artifact Registry, Cloud Build, Cloud Logging, Secret Manager, Network egress]
        description: The chosen Google Cloud service.
      - name: expected_usage
        type: string
        required: true
        description: >
          Projected monthly usage with the traffic assumption it rests on.
          Never a bare number — a number without its assumption cannot be
          re-checked when traffic changes.
      - name: free_allowance
        type: string
        required: true
        description: The current free allowance, quoted with its unit and its reset period.
      - name: allowance_period
        type: enum
        required: true
        allowed_values: [daily, monthly]
        description: >
          Load-bearing and frequently wrong. Firestore's quotas reset DAILY with
          no rollover; every other allowance here is monthly. A monthly reading of
          a daily quota understates exhaustion risk by roughly thirtyfold.
      - name: allowance_aggregation
        type: enum
        required: true
        allowed_values: [per-billing-account, per-project, per-region-group]
        description: >
          Also load-bearing. Most allowances aggregate per BILLING ACCOUNT across
          projects, so a second project does not buy a second allowance.
      - name: expected_charge
        type: string
        required: true
        description: Expected monthly charge. Must be zero for every line, or NFR6 is not met.
      - name: overage_trigger
        type: string
        required: true
        description: The specific event that would start charging. Absent this, a zero is unfalsifiable.
      - name: source_url
        type: string
        required: true
        description: Official Google Cloud pricing or free-tier page.
      - name: source_date
        type: date
        required: true
        description: >
          When the figure was fetched. Google reserves the right to change
          allowances with 30 days' notice, so an undated figure has no shelf life.
      - name: verification
        type: enum
        required: true
        allowed_values: [measured, documented, estimated]
        description: >
          How the usage figure was obtained. `measured` means taken from U10's
          real images or a real run; `documented` means read off an official page;
          `estimated` is permitted ONLY where nothing can yet be measured, and
          must say what would measure it. An earlier estimate in this workflow was
          wrong by an order of magnitude, which is why this field exists.
    constraints:
      - Every CostLine has a source_url and a source_date. No exceptions.
      - Any line with expected_charge greater than zero is a failure of NFR6, not a footnote.
      - Image-size lines are `measured` from U10's built images, never `estimated`.

  - name: DeploymentStep
    description: A single operator action in the deploy or rollback runbook. Nothing here is executed by this workflow.
    attributes:
      - name: sequence
        type: integer
        required: true
      - name: action
        type: string
        required: true
        description: What the operator does, as a concrete command or console action.
      - name: verification
        type: string
        required: true
        description: How the operator confirms it worked before moving on.
      - name: rollback
        type: string
        required: true
        description: >
          How to reverse this specific step. Required on EVERY step by the
          operation-phase guardrail, not only on the deploy as a whole.
      - name: cost_impact
        type: string
        required: true
        description: Whether performing this step starts any billable meter.
    constraints:
      - Every step has a rollback. A step that cannot be reversed says so explicitly and says why.
      - No step in this document has been executed. The runbook is untested by construction.

  - name: ConfigurationSetting
    description: >
      A deployment setting whose value is a correctness or cost constraint rather
      than a preference. Separated from prose because several of these silently
      destroy the free tier when left at their console default.
    attributes:
      - name: setting
        type: string
        required: true
      - name: required_value
        type: string
        required: true
      - name: default_value
        type: string
        required: true
        description: What the console or CLI would use if nobody set it.
      - name: consequence_if_wrong
        type: string
        required: true
        description: >
          What breaks, or what it costs, if the setting does not hold its required
          value — whether that happens by leaving a wrong default in place or by
          changing a correct one.
    constraints:
      - >
        A setting belongs here when its value is a correctness or cost constraint
        rather than a preference. That INCLUDES a setting whose required value
        equals its default, when an operator has a plausible reason to change it:
        `min-instances` 0, request-based CPU allocation, Premium network tier and
        30-day log retention are all correct out of the box, and all four are
        pushed against by cold-start latency, by the documented cold-start fix, by
        a tight egress allowance and by wanting an audit trail. Those are the rows
        most worth writing down, because nothing about the console flags them.
      - >
        What does NOT belong here is a setting nobody has a reason to change and
        whose change costs nothing. The earlier wording — "a setting whose required
        value equals its default does not belong here" — deleted exactly the rows
        BR32.5, BR32.15, BR32.22 and BR32.23 exist to protect, and is withdrawn.
      - >
        `default_value` is recorded even when it matches `required_value`, because
        a reader needs to know whether holding the required value means making a
        change or resisting one.

relationships:
  - from: CostLine
    to: ConfigurationSetting
    cardinality: one-to-many
    direction: A CostLine's zero depends on the ConfigurationSettings that hold it there
  - from: DeploymentStep
    to: ConfigurationSetting
    cardinality: many-to-many
    direction: A step applies settings; a setting is applied by one or more steps
```

## Summary

Three record shapes, all of them parts of a document. `CostLine` is the one that
carries NFR6: the zero-cost claim is nothing more than every line reading zero
with a dated source behind it, so `source_date`, `allowance_period` and
`verification` are the fields that make the claim checkable rather than asserted.
`ConfigurationSetting` exists as a separate shape because the free-tier-destroying
values in this topology come in two families and prose hides both. One family is a
**wrong default** that has to be changed — the bucket's `US` multi-region, the
`max-instances` ceiling of 100. The other is a **right default** that has to be
defended — `min-instances` 0, request-based CPU allocation, Premium network tier,
30-day log retention — where the cost is paid by an operator who changes something
for a good-sounding reason. The second family is the one a table catches and prose
does not, which is why the constraints above admit it explicitly.

## Assumptions & Open Questions

- **[assumption]** A document's "entities" are worth modelling at all. They are
  here, because this document is the sole evidence for a success condition, and an
  unstructured cost table is where a missing source date hides.
- **[open]** Image-size CostLines cannot be filled until U10 builds real images.
  They are placeholders marked `measured` **pending**, and the plan is not
  complete while any remains unfilled.
