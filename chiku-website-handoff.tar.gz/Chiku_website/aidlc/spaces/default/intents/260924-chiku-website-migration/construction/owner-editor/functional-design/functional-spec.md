# Functional Specification — U9 `owner-editor`

**Unit:** `u9-owner-editor` · **Kind:** `ui` · **Component:** `OwnerEditor`

**Upstream:** `construction/functional-design/frontend-components.md` § *U9 —
owner-editor* (extended and scoped here, not contradicted),
`construction/functional-design/rules.md` § `OwnerEditor` (BR8.6–BR8.8),
`inception/requirements-analysis/requirements.md` FR8.1–FR8.8, NFR7,
`inception/domain-design/components.md` § `OwnerEditor`,
`inception/domain-design/decisions.md` ADR-005, ADR-006,
`inception/contract-design/contract-summary.md` § C1,
`inception/units-generation/unit-of-work.md` § *U9 — owner-editor*.

## How to read this document

**This unit is kind `ui`, so it produces exactly two artifacts** — this file and
`frontend-components.md`. It has **no `entities.md`** and **no `rules.md`**: `ui` is
absent from both of those `produces_kinds` lists, and that is not an oversight of
packaging but a statement about the unit. **`OwnerEditor` owns no persisted entity and
authors no business rule.** Every application decision it displays was made in Python
(`project.md` § Forbidden: *never place application logic in the Next.js frontend; it
renders, it decides nothing*).

**This file is therefore self-contained and authoritative for what it specifies:
interaction workflows, screen and state transitions.** It carries no derived entity or
rule view, because there is no per-unit entity or rule source to derive one from. Where
it references a `BR` id, that rule is **owned and specified elsewhere** — in
`construction/functional-design/rules.md` or in the owning unit's own `rules.md` — and
this file states only how this unit **renders or obeys** it.

**The state machine specified here has no `BR` id and must not be given one.** That is
the conclusion of § *The save state machine — the adjudication*, which closes the open
item assigned to this stage.

---

## What this unit is

`OwnerEditor` is the owner's no-code editing surface: **the largest frontend surface
and the only one that mutates anything.**

It **renders and holds local state.** Concretely, it owns:

- every editing surface that exists today — profile, highlights, research,
  publications, journey, notes and news, the three-dimensional story, Scholar
  highlights, website text, and appearance (FR8.1);
- draft autosave and its suspension rules (FR8.2);
- per-tab local retention of unsaved work (FR8.3);
- the **recovery flow, including the third unreachable state** (BR8.7);
- the **conflict flow** (FR8.5);
- the leave warning (FR8.4);
- the **private draft preview** (FR8.6);
- focal-point, alternative-text, caption and transcript controls, including their
  keyboard operation (FR8.7);
- the **browser tool registration** (FR8.8).

It **decides nothing.** The rule separating a recoverable draft from a corrupt one
lives in `u4-content-core` (ADR-006); this unit submits the bytes and renders the
verdict. Authoritative validation is Python's; the editor displays `issues[]`.
Client-side validation exists for responsiveness only and is **generated** from the
backend's schema document, never hand-written (FR8.9, owned by `u7-api-client`).

## There is no browser-side runtime validation anywhere in this corpus, by design

**Stated once, plainly, as a property of the architecture rather than as a gap**, because
three separate places in this document would otherwise each read as a missing check:

> **No runtime validator runs in the browser. None is hand-written, and none is
> generated. Every runtime validation decision in this system is Python's, and the
> browser reaches it over HTTP.**

The pieces that make that true:

- **`zod` leaves the frontend.** All seven `contentSchema.safeParse` call sites go
  (`frontend-components.md` § `editor-workflow.ts`), and the dependency goes with them.
- **The generated surface is compile-time only.** `u7-api-client` provisions
  `openapi-typescript`'s `OperationTypes`, checked by `tsc --noEmit` at the merge gate
  (`construction/api-client/functional-design/entities.md` § *generated_surface*).
  TypeScript types are erased before anything runs; they cannot enforce a `maxLength`, a
  `minLength` or a format on a value arriving at run time.
- **Hand-writing one is forbidden.** `project.md` § *Forbidden* and FR8.9 both prohibit a
  hand-written client-side validation rule or a type mirroring a backend model.

**So a browser-side check is not an option this document ever weighs and rejects — it does
not exist.** Each place that would want one resolves the same way, and none of them is an
omission:

| Where a runtime check would sit | What happens instead |
|---|---|
| Recovery classification of a stored draft | `POST /api/content/inspect` (ADR-006, BR8.6) |
| The preview gate, in the editor and in the frame | `POST /api/content/inspect` (§ *The private draft preview*) |
| Pre-save validation (`save`, `manualSave`) | The backend's `400` + `issues[]` (§ *A validation rejection is not a failed write*) |
| The browser tool's field-length check | **Removed**; the backend rejects at save (§ *The browser tool* → the decision) |

**Three local size guards are not validation and are not covered by this.** The two
6,000,000-character bounds and the restore-time warning threshold measure the **size of a
payload**, not the **shape of a document**; they mirror no backend model, admit and refuse
nothing, and are treated in § *Assumptions & Open Questions* under the bounds decision.

---

# The save state machine — the adjudication

> **This section closes the open item that `WORKING-RECORD.md` § 9,
> `requirements-analysis/requirements.md`, `domain-design/decisions.md`,
> `contract-design/contract-summary.md` § *Open questions* and
> `construction/functional-design/rules.md` all carry, each assigned to
> `functional-design`: is any part of the editor's multi-flag save state machine a
> **rule** rather than presentation state?**

## The question, stated precisely

Seven things are in scope: the flags `busy`, `uploads`, `paused`, `conflict`,
`recovery` and `recoveryReady`, and the **1,500 ms autosave arming interval**.

Two parts are **already adjudicated and are not reopened here**:

- the **recovery classification** is a backend rule (**ADR-006**, BR8.1–BR8.5), behind
  `ContentAuthority`'s inspect operation;
- the **hold-on-unreachable** state and the **pause-after-restore** are specified rules
  owned by `OwnerEditor` (**BR8.6–BR8.8**).

What remains open is the other five flags and the interval.

## The test applied

A flag is a **rule** if, when it holds the wrong value, the system reaches an outcome
**the backend would have refused had it known**. A flag is **presentation state** if a
wrong value produces at most a worse experience, while the backend independently
enforces the correct outcome.

This is the test the domain-design correction demands — *"A correctness rule operating
on browser-local state still decides something, and placing it in the frontend needs an
argued justification rather than an assumption"* — so each flag is argued, not
assumed.

## Flag by flag

### `busy` — a save is in flight → **presentation state**

Wrong value ⇒ a second save is dispatched while the first is outstanding.

Both carry the **same base revision**. `ContentAuthority`'s compare-and-set (BR4.7,
BR4.10) admits **one** of them and answers the other with **409**, which **preserves
the caller's edits and returns the current state so the caller can reconcile**. No
write is lost and no write is doubled.

`busy` buys a cleaner experience — one spinner, one disabled button. It does not buy
correctness, because correctness is already bought one layer down.

### `uploads` — uploads in flight → **presentation state**

Wrong value ⇒ an autosave fires while an upload is still running.

The upload's media URL enters form state **on completion**, so an autosave that fires
first writes a draft **without** that reference. The next save carries it. Two real
consequences, neither of them loss:

1. **A transient draft revision lacking the asset reference.** It is a draft, and the
   owner's form still holds the truth.
2. **Revision churn.** Every accepted write increments the revision (BR4.5), inserts a
   history entry (BR4.11), and counts against retention's 30 draft entries (BR5.7). A
   spurious autosave therefore consumes one slot of the owner's history budget.

**The decisive point is what an autosave cannot do.** An accepted write **always**
overwrites `draft`, and `published` / `publishedAt` change **only** when
`action = 'publish'` (BR4.3, BR4.4). Autosave is **legal only with a draft action** —
the backend enforces this as part of one predicate (BR10.12). So a mid-upload autosave
**cannot publish**, and because asset visibility is a scan over the **published**
document (BR7.4), it **cannot change which assets are public**. There is no
authorization consequence, and the one content consequence is transient and
self-correcting.

### `conflict` — a 409 is unresolved → **presentation state, with one carve-out**

Wrong value ⇒ an autosave fires while a conflict is unresolved.

That autosave carries the **stale** base revision, so the CAS matches zero rows, and
the caller receives **409 again**. The backend makes the unsafe path safe.

**The carve-out is not the flag. It is when the locally-held base revision advances** —
and it is specified in § *The base-revision advance rule* below, because it is the one
path in this unit that can destroy committed work with **no error anywhere**.

### `paused` — autosave suspended → **presentation state; part of it is already a rule**

`paused` is **one flag with two causes**, and it is a suspension in its own right rather
than a composite of the others — the machine in § *The state machine* gives it its own
region for exactly that reason. One of its two causes is **already a rule**: **BR8.8** —
restoring a recovered draft pauses autosave until the owner explicitly saves. The other is
the **pause after a failed write** (`editor-workflow.ts:66`), which FR8.2 does not name
and which this unit preserves under the parity rule — **excluding a validation rejection,
which the source's pre-flight meant was never a failed write at all** (§ *A validation
rejection is not a failed write*).

**The precedent this sets is the answer to the whole question.**
`construction/functional-design/rules.md` says of BR8.6–BR8.8, verbatim:

> *The editor **decides nothing**. These three rules exist because getting them wrong
> loses the owner's work, which is a correctness outcome even though the state itself
> is presentational.*

So a flag can carry a correctness outcome **and still stay in the frontend**. "Has a
correctness consequence" is not the boundary test; "can the backend make the decision"
is.

### `recovery` / `recoveryReady` → **presentation state**

`recovery` holds the recovered bytes and the in-flight inspect request.
`recoveryReady` means *a verdict has arrived and the owner has not yet decided*, and it
gates whether autosave may arm.

Both were settled by **ADR-006**: the **classification** crossed to Python; the
**holding of bytes and rendering of the verdict** did not. `recoveryReady`'s one
correctness consequence is BR8.8, already carved out.

### The 1,500 ms arming interval → **presentation state, but parity-fixed**

**Nothing in the system reads this number.** Shorter means more revision churn against
the 30-entry budget; longer means more unsaved work exposed to a crash. Both are
trade-offs in the owner's experience, and neither is a decision the backend has any
stake in.

**Contrast it with the one interval in this system that *is* a rule.** BR7.2's
published-document cache interval is a **security** parameter — a stale cache means an
asset the owner has just unreferenced **stays public**, which is an authorization
defect. The autosave interval has no analogue of that. It changes when a request is
sent, never what the request is permitted to do.

**It is nevertheless fixed at 1,500 ms**, because the parity rule covers observable
behaviour and the source uses 1,500 ms. **Parity-fixed is not the same as
rule-bearing**, and conflating the two is how a tuning constant acquires a `BR` id it
does not deserve.

## The structural argument, which is decisive on its own

Even if one of these flags were relabelled a rule, **there is nowhere in Python to put
it.**

The backend has **no operation whose behaviour differs on the autosave flag**, beyond
BR10.12's check that `autosave === true` implies `action === 'draft'`. The backend
**receives** the autosave signal; it does not **decide** it. "Do not autosave right
now" is not expressible as a server-side check, because the server cannot distinguish a
save it should have received from one it should not have — both arrive as a well-formed
`PUT` from an authenticated owner with a valid base revision.

**This is exactly what separates these flags from the case that did cross.** The
recovery classification could move, because *"which validator outcomes are survivable"*
is a question answerable from the candidate document alone — it needs nothing only the
browser knows. The arming flags are the opposite: **every one of them is a fact about
what this tab is doing right now**, and this tab is the only place that fact exists.

A "rule" relocated to a place that lacks the information to evaluate it is not safer
for having been relocated. It is the same behaviour with a worse home.

## The verdict

> **All five remaining flags — `busy`, `uploads`, `paused`, `conflict`, `recoveryReady`
> — and the 1,500 ms arming interval are PRESENTATION STATE. No part of them crosses to
> Python. They receive no `BR` id.**
>
> **This confirms the position `frontend-components.md` recorded as open, and closes the
> item.** Three obligations are carved out and specified in this file rather than left
> implicit: the two already-adjudicated rules **BR8.7** (hold on unreachable) and
> **BR8.8** (pause after restore), both owned by `OwnerEditor` and specified in
> `construction/functional-design/rules.md`; and **the base-revision advance rule**
> below, which is new here and has no `BR` id for the reason argued above.

## The base-revision advance rule

The single most dangerous transition in this unit is not a flag. It is **when the
locally-held base revision advances.**

> **The locally-held base revision advances only (a) from the response to an accepted
> write, or (b) when the owner explicitly chooses to load the latest saved draft. It is
> NEVER advanced from a 409 response body, even though that body carries the current
> state.**

**Why this is the dangerous one.** If the conflict flow advances the local base
revision to the server's current revision *without* the owner having reconciled, the
next write — including an **autosave** — carries a **matching** base revision. The CAS
**succeeds**. The other tab's committed work is overwritten, silently.

**The backend cannot detect it.** That write is legitimate at every level the backend
can see: authenticated owner, valid CSRF, matching origin, well-formed envelope,
current base revision, validating content. There is no error, no log line and no
conflict. It is the only path in this unit that destroys committed work with nothing
anywhere to notice.

**It still does not cross the boundary**, for the reason argued above: the backend
cannot distinguish a reconciled advance from an unreconciled one, because "the owner
looked at the latest draft and chose" is a fact that exists only in the browser.

**Its test is a browser test**, and it is the single strongest argument for the
Playwright consequence below: two tabs, both at revision *N*; tab A saves; tab B saves
and receives 409; tab B is left untouched for longer than the autosave interval; **tab
B must not have written anything.** Nothing short of a browser can observe that.

## The consequence for verification — and a correction to the corpus

**Because the state machine stays in the frontend, a browser-driven check (Playwright)
becomes MANDATORY, not optional.**

This is the **opposite** of what one of the four corpus statements implies, and the
disagreement must be recorded rather than silently resolved. The four statements are:

| Source | What it says |
|---|---|
| `aidlc/spaces/default/memory/team.md` § *Testing Posture* | *"if the six-flag editor state machine lands in the **frontend** rather than the backend, a browser check becomes the only possible verification of it and becomes mandatory"* |
| `WORKING-RECORD.md` § 9 | *"If that state machine lands in the **frontend**, Playwright becomes **mandatory**"* |
| `construction/functional-design/rules.md` § *Assumptions* | *"if the state machine **remains in the frontend**, a browser-driven check becomes the only possible verification of FR8.2 and FR8.5"* |
| `construction/functional-design/frontend-components.md` § *Assumptions* | *"**If that is wrong**, the part that is a **rule crosses to Python**, and a browser-driven check becomes the only possible verification of it, moving Playwright from optional to mandatory"* |

**The fourth inverts the conditional**, and it is demonstrably the wrong one. **ADR-006**
says of the rule that *did* cross to Python: *"It becomes testable in Python, under the
100% hazard coverage floor, **without a browser**."* A rule that crosses to Python
becomes **cheaper** to verify, not dearer. Three sources agree with each other; one is
backwards.

**Correction recorded:** the condition that flips Playwright from optional to mandatory
is **the state machine staying in the frontend**, which is what this adjudication
concludes. `frontend-components.md`'s phrasing of the consequence is wrong and is
corrected in this unit's `frontend-components.md`.

**What Playwright must cover** — the behaviours no other check in the merge gate can
reach:

1. **FR8.2** — autosave arms after idle, and is suspended in each of its **four**
   conditions **independently**: upload in flight, conflict unresolved, recovered draft
   awaiting decision, and the pause flag set.
2. **The orthogonality itself** — at least one case holds **two suspensions at once**
   and asserts that clearing one **arms nothing**. The canonical case is the one the flat
   machine got wrong: restore a recovered draft (`Pause = Paused`), start an upload
   (`Uploads = Uploading`), let the upload settle, wait past the arming interval, and
   assert **no write was dispatched**.
3. **FR8.5** — the conflict flow end to end, including the **base-revision advance
   rule** above and **step 4's path**: load the latest draft, be offered the local edits
   back, restore them, and save explicitly from `Paused`.
4. **BR8.7** — the unreachable-backend recovery state: the draft is **held**, the
   retry affordance appears, and **nothing is discarded**.
5. **BR8.8** — restoring a recovered draft leaves autosave paused until an explicit save
   is **accepted**; a rejected explicit save leaves it paused.
6. **FR8.4** — the leave warning fires for each of its three conditions.
7. **FR8.6** — the preview gate and the preview frame: an invalid draft does not open the
   preview and reports its fields; a valid draft renders in the frame; and a document the
   frame cannot render shows the preserved sentence. The `postMessage` handshake cannot
   be observed any other way either. **Including the reload path**: after an inspect that
   returned no verdict, `Reload preview` must **re-issue** rather than reuse — the
   regression R-14 identified, which no non-browser check can see.
8. **The validation rejection that must NOT pause** — § *A validation rejection is not a
   failed write*. Type an invalid field, let autosave fire, observe the `400` with
   `issues[]`, then **assert that autosave still arms on the next change**. This is the
   companion of item 1: item 1 asserts that the four suspensions hold when they should,
   and this asserts that a fifth one is never created. It is observable nowhere but a
   browser, because the evidence is the **absence** of a pause.

**The cost is real and is stated rather than absorbed.** This adds a browser test
framework to a project that currently has none on the frontend, on a gate that runs on
every Bolt merge with no CI. It is the price of the flags staying where they are, and
the alternative — moving them to a backend that cannot evaluate them — is not
available.

---

# The recovery flow — three states, not two

FR8.3 is hazard-marked, and **the classification rule is not here** (ADR-006). **The
editor holds the bytes; `ContentAuthority` decides.** On mount, if a stored per-tab
draft exists, the editor submits it to `POST /api/content/inspect` and renders the
verdict (BR8.6).

### State 1 — Recoverable → offer the draft

The response marks every issue **recoverable**: a value **present and of the correct
type** but outside its permitted set or range — a string shorter or longer than
allowed, a number out of range, a failed format or custom check, **and a value outside
an enumerated set** (`accent`, `researchTopic`, the scene's `initialView`).

**These are exactly the states an owner produces by typing.** The draft is kept,
repaired against schema defaults, and **presented for review**.

**Autosave stays paused until an explicit save is accepted** (BR8.8, FR8.3.4), so
recovery never silently overwrites the stored draft. Restoring moves the `Recovery`
region to `NoRecovery` **and** the `Pause` region to `Paused`; only `save200` clears the
pause. An explicit save is **permitted** from `Paused` — that is the whole point of the
rule — and is refused from `Offered` and `Held`, per § *Explicit save — where it is
permitted*.

### The oversize-draft warning at restore

**A recovered draft can be restorable and unsavable at the same time**, because the
recovery bound (6,000,000 characters) is four times the save cap (1,500,000). Under the
decision taken at the gate — § *Assumptions & Open Questions*, *the three bounds* — **all
three bounds are preserved and the owner is WARNED** rather than left to discover it
through a 413 loop.

> **When the owner restores an offered draft whose save payload would exceed the save cap,
> the editor shows:**
>
> `This recovered draft is too large to save. Your edits are here; shorten the draft before saving.`

Four things fix it precisely:

- **Trigger.** `restoreDraft`, evaluated **once, at restore**, not on every keystroke.
- **Subject measured.** The **serialised request body the editor would send** for this
  draft — the same subject `PUT /api/content`'s 413 measures — **not `content` alone**. A
  draft can be under the cap on `content` and over it on the body, and measuring the
  narrower subject would under-warn at exactly the boundary the warning exists for.
- **It warns; it does not block.** The restore proceeds, the draft enters the form, the
  `Pause` region goes to `Paused` under BR8.8 exactly as always, and an explicit save is
  still **permitted** and still dispatched. **The 413 is unchanged and Python still
  decides.** Nothing about this is a client-side validation rule: it admits and refuses
  nothing (§ *There is no browser-side runtime validation anywhere in this corpus*).
- **It is NEW COPY, and therefore a parity change.** It is the **only** new user-facing
  string this unit adds. The site owner accepted it at the gate, for the stated reason:
  without it the owner's longest content fails **silently and repeatedly** — every
  autosave 413s, and an unoffered or unsavable draft says nothing at all.

**One consequence carried forward for the gate, with a named owner.** The threshold is
a **backend-owned number held in the browser** — `PUT /api/content`'s body cap, owned by
`u6-http-api`. **If that cap changes and the frontend constant does not, the warning
misfires or goes silent.** No check in the merge gate catches that drift: the generated
`openapi-typescript` surface carries no body-size cap, so there is nothing for the
gate's dirty-check to compare. **Owner: `u6-http-api`**, to carry the cap and this
warning's threshold as one fact rather than two, and to decide at `code-generation`
whether it can be published in a form the frontend can consume. Recorded, not resolved
here.

### State 2 — Corrupting → discard the stored draft

The response marks an issue **corrupting**: a **malformed record** — wrong JSON shape,
a field of the wrong type, a missing required structure, or a stored blob that is not
parseable at all.

Report the stored draft **unusable** and continue with the server draft.

### State 3 — Unclassifiable → **hold** the draft

**The inspect request fails, or the backend is unreachable.**

**HOLD the draft. Show an unavailable-and-retry state. NEVER discard it.** (BR8.7.)

**This is a specified state, not an error path.** Silently discarding on a transport
failure would reproduce **exactly the class of loss FR8.3 exists to prevent** — the
owner loses unsaved work, is told nothing useful, and the loss is unrecoverable.
ADR-006 named this as the risk its own decision created: *"If the backend is
unreachable at recovery time, the editor cannot classify. It must then hold the draft
and say so, never silently discard it — which is the failure this ADR exists to
prevent."*

Three properties of the held state:

- the recovered bytes stay in per-tab storage, **untouched**;
- the retry re-issues the inspect request and re-enters this machine at `Inspecting`;
- **autosave does not arm** while a draft is held — an unclassified draft is
  "awaiting the owner's decision" for FR8.2's purposes.

### Per-tab retention

Per-tab storage keys are **unchanged**. Each mounted editor owns its own recovery
record, **so a clean second tab never clears another tab's unfinished work** (FR8.3).

The key must be unique to the **tab**, not to the browser, the origin or the user. A
key shared across tabs turns the second tab's clean mount into the first tab's data
loss — which is the same failure FR8.3 exists to prevent, arriving by a different
route.

---

# The state machine

**The TEXT of this section is authoritative for this unit** — § *Why it is orthogonal*,
the five region descriptions, § *The events, and which regions consume them*, § *The
suspension predicate, stated once* and § *Explicit save — where it is permitted*,
together. `ui` units carry no per-unit entity or rule source to derive from; the state
machine **is** the specification, and it is specified in prose. A developer implements
from the text.

**The diagram below is illustrative and carries no authority.** That is a deliberate
reversal of the previous draft, which declared its `stateDiagram-v2` block authoritative,
and it is recorded here rather than made silently.

> **What was wrong, and what was done about it — BOTH repairs, not one.** The previous
> draft drew the five regions as five **sibling** `state X { … }` blocks at the top level.
> **In statechart and mermaid semantics that is XOR decomposition** — exactly one sibling
> is active at a time — which asserts precisely the mutual exclusion the prose beneath it
> exists to refute; and with no top-level `[*]`, nothing was entered at all. The block was
> *syntactically* valid, which is why "validated by construction" did not catch it: a
> syntax validator has nothing to complain about.
>
> 1. **The orthogonality is now expressed in the notation.** The five regions are wrapped
>    in one composite state, `Editor`, separated by `--` — **mermaid's AND-region
>    divider** — with a top-level `[*] --> Editor`. The picture now says what the prose
>    says.
> 2. **And the diagram is no longer called authoritative.** Expressing AND-composition
>    correctly fixes what the picture *claims*; it does not make a picture the right home
>    for a fourteen-state specification with guards, shared events and a predicate. The
>    text is the source of truth, and a developer who finds any disagreement between the
>    two follows the text and reports the diagram as the defect.
>
> **A correction to the review's validation table, which recorded that no mermaid
> validator was available.** One is: `npm install mermaid` and `mermaid.parse()` under
> `jsdom` validates syntax headlessly, and **every fenced block in this file was checked
> that way**, including the named composites inside the `--` dividers. What that check
> cannot do is *render* — layout needs `getBBox()` and therefore a real browser — and it
> could not have caught the previous draft's defect either, which was semantic. **Syntax
> is now checkable at this stage; meaning still is not.**

## Why it is orthogonal, and why a flat machine is wrong here

The suspensions FR8.2 names are **independent and simultaneously holdable**: an upload
can be in flight *while* a conflict is unresolved *while* a recovered draft awaits the
owner's decision. **A flat machine cannot express that.** In a flat machine those states
are mutually exclusive, so the first suspension to clear returns the editor to `Idle`
and **arms autosave while the others still hold**.

For BR8.8's pause that is not a cosmetic error. An upload started while a restored draft
is paused would, on settling, clear the pause, arm autosave, and **silently overwrite the
stored draft** — the exact loss BR8.8 and FR8.3.4 exist to prevent, arriving through the
machine that was supposed to prevent it.

So the machine is **five orthogonal regions**. Each region holds exactly one state at a
time and the editor's state is the **tuple** of the five. **No region transitions into
another.** They compose by **shared events**: an event named in more than one region is
delivered to every region that names it — which is how one `save409` simultaneously
returns the write region to `Idle`, moves the concurrency region to `Conflicted`, and
moves the pause region to `Paused`.

**Every exit edge therefore returns its own region to its own resting state, never the
machine to `Idle`.** Whether autosave may arm is not a state at all: it is the
**predicate** in § *The suspension predicate, stated once*, evaluated over the four
**suspension** regions — `Recovery`, `Uploads`, `Concurrency`, `Pause`. **`Write` is not
one of them**, for the reason that section states.

**The editor's state is the tuple of all five regions at once**, and the diagram says so:
one composite state, `Editor`, whose five regions are separated by `--`. **The `--` lines
are the whole point of the picture** — they are AND-region dividers, so the five regions
below hold **simultaneously** and none is an alternative to another.

## The machine, drawn — illustrative, not authoritative

```mermaid
stateDiagram-v2
    [*] --> Editor
    state Editor {
        state Recovery {
            [*] --> Scanning
            Scanning --> Inspecting : storedDraftFound
            Scanning --> NoRecovery : noStoredDraft
            Inspecting --> Offered : verdictRecoverable
            Inspecting --> NoRecovery : verdictCorrupting
            Inspecting --> Held : inspectUnavailable
            Held --> Inspecting : retryInspect
            Offered --> NoRecovery : restoreDraft
            Offered --> NoRecovery : declineDraft
            NoRecovery --> Offered : latestLoaded
            Scanning --> Offered : latestLoaded
            Inspecting --> Offered : latestLoaded
            Held --> Offered : latestLoaded
            Offered --> Offered : latestLoaded
        }
        --
        state Uploads {
            [*] --> NoUploads
            NoUploads --> Uploading : uploadStarted
            Uploading --> NoUploads : lastUploadSettled
        }
        --
        state Concurrency {
            [*] --> Clean
            Clean --> Conflicted : save409
            Conflicted --> Clean : latestLoaded
        }
        --
        state Pause {
            [*] --> Ready
            Ready --> Paused : restoreDraft
            Ready --> Paused : saveFailed
            Ready --> Paused : save409
            Paused --> Ready : save200
            Paused --> Ready : latestLoaded
        }
        --
        state Write {
            [*] --> Idle
            Idle --> Armed : fieldChanged when unsuspended
            Armed --> Armed : fieldChanged
            Armed --> Idle : suspensionBegan
            Armed --> Idle : documentClean
            Armed --> Saving : idle1500
            Idle --> Saving : explicitSave when permitted
            Armed --> Saving : explicitSave when permitted
            Saving --> Idle : save200
            Saving --> Idle : saveInvalid
            Saving --> Idle : saveFailed
            Saving --> Idle : save409
        }
    }
```

**Two things the diagram cannot carry, and which are therefore only in the text.** The
guards `when unsuspended` and `when permitted` are **labels** to mermaid, not conditions
it evaluates — their content is § *The suspension predicate, stated once* and § *Explicit
save — where it is permitted*. And an event named in more than one region is **one event
delivered to all of them**; the diagram draws it as separate edges with the same label,
which is the same thing only if the reader already knows it.

**Text fallback, and the authoritative statement. Fourteen states across five orthogonal
regions** — `Recovery` 5, `Uploads` 2, `Concurrency` 2, `Pause` 2, `Write` 3. The diagram
draws the same fourteen and adds nothing.

**Region `Recovery`** — what the per-tab stored draft is doing.

- **`Scanning`** — mount; the per-tab storage scan has not finished. Autosave cannot arm;
  an explicit save is **permitted** (no recovery record exists yet).
- **`Inspecting`** — a stored draft was found and is at `POST /api/content/inspect`
  (BR8.6). Exits: `Offered` (recoverable), `NoRecovery` (corrupting — the stored draft is
  discarded and the server draft kept), **`Held`** (inspect failed or unreachable).
- **`Held`** — **BR8.7.** The draft is **held and never discarded**; an
  unavailable-and-retry affordance is shown; a retry returns to `Inspecting`.
- **`Offered`** — the repaired draft is presented for review. The owner restores it or
  declines it; either way the region returns to `NoRecovery`, and **restoring also moves
  the `Pause` region to `Paused`** (BR8.8).
- **`NoRecovery`** — no draft is awaiting a decision. **Re-entered as `Offered` by
  `latestLoaded`**: loading the latest saved draft stashes the owner's local edits as a
  fresh offer, which is what gives FR8.5 step 4 its path.

### `latestLoaded` in every `Recovery` state

**`latestLoaded` replaces the form's contents with the latest saved draft, so the owner's
local edits must be stashed or they are destroyed. They are therefore stashed in EVERY
`Recovery` state, and the region always lands in `Offered`.** The previous draft defined
the event only on `NoRecovery`, leaving it undefined in the other four — which is not an
unreachable corner: an explicit save is **permitted** from `Scanning`, so a `409` can put
`Concurrency = Conflicted` while the scan completes into `Inspecting`, `Offered` or
`Held`, and load-latest is `Conflicted`'s only exit.

| `Recovery` state when `latestLoaded` is consumed | Effect | What happens to what was already there |
|---|---|---|
| `NoRecovery` | → `Offered`, holding the stashed local edits | Nothing was pending. **FR8.5 step 4's path.** |
| `Scanning` | → `Offered`, holding the stashed local edits | The storage scan is **abandoned**; its result is discarded rather than applied late |
| `Inspecting` | → `Offered`, holding the stashed local edits | The outstanding inspect is **aborted** and raises nothing; the per-tab bytes stay in storage, untouched |
| `Offered` | → `Offered`, now holding the stashed local edits | The pending offer is **superseded**, not discarded: the per-tab bytes stay in storage, untouched, and are offered again on the next mount |
| `Held` | → `Offered`, holding the stashed local edits | **BR8.7 is not violated: nothing is discarded.** The held bytes stay in per-tab storage, untouched, and are offered again on the next mount. What the owner loses in this session is the retry affordance, not the draft |

**Aborting the outstanding scan or inspect is the point of the rule, not a detail.**
Without it, a verdict that arrives after `latestLoaded` would overwrite the stash with
the stored draft and the owner's local edits would be gone — a race that destroys work.
The abort is **new mechanism with no source counterpart**, the same kind as the frame's
coalescing rules, and it is recorded as such in § *Assumptions & Open Questions*.

**Nothing here clears per-tab storage.** Storage is cleared only by the owner's decision
on an offer (`restoreDraft` / `declineDraft`) and by the corrupting verdict, exactly as
before. A stash that is itself superseded is in-memory content; the bytes on disk are a
separate thing and they survive.

**Region `Uploads`** — `NoUploads` / `Uploading`. The region tracks a **count**; it
enters `Uploading` on the first start and leaves it only when the count reaches zero.
It never returns the machine to `Idle` — it returns **itself** to `NoUploads`. Whether
autosave may then arm is decided by `unsuspended` (§ *The suspension predicate, stated
once*) over all four suspension regions, **this one included** — and arming additionally
needs a further `fieldChanged`, because a suspension that ends never fires a pending
autosave.

**Region `Concurrency`** — `Clean` / `Conflicted`. Entered on `save409`. **The only exit
is the owner explicitly loading the latest saved draft**, which is also the only place
other than an accepted write where the base revision advances.

**Region `Pause`** — `Ready` / `Paused`. This region is `paused` in the source, and it
carries **two** causes, both verified:

- **`restoreDraft`** — **BR8.8**, restoring a recovered draft pauses autosave until an
  explicit save (`editor-workflow.ts:71`);
- **`saveFailed` and `save409`** — a **failed** write pauses autosave
  (`editor-workflow.ts:66`, the `catch` that sets `paused` on every non-2xx and on a
  transport failure). **FR8.2 does not name this suspension**; it is source behaviour and
  is preserved under the parity rule rather than dropped. It is flagged for the recorded
  fixtures (U1) to pin.

> **`saveInvalid` — a `400` carrying `issues[]` — does NOT enter this region, and that
> is what PRESERVES the source's behaviour rather than diverging from it.** In the source
> a schema-invalid save **was never dispatched**: `editor.tsx:74` `manualSave` parsed the
> form first and returned before dispatching, and `editor-workflow.ts:54` `save` did the
> same for the autosave path. A write that is never dispatched never fails, so
> `editor-workflow.ts:66`'s `catch` never ran for it and **the commonest error an owner
> can make never paused autosave.** Moving that gate to the server (the pre-flight parse
> is one of the seven `contentSchema.safeParse` sites that leave this unit) would, under
> a single undifferentiated `saveRejected`, turn every mistyped field into a suspension
> the source did not have. Splitting the event is what keeps the observable behaviour the
> same. Full treatment in § *A validation rejection is not a failed write*.

It clears only on an **accepted write** (`save200`, `editor-workflow.ts:62`) or on
`latestLoaded` (`editor-workflow.ts:74`). **It does not clear when a save is merely
dispatched** — so an explicit save from `Paused` that is itself rejected or invalid
leaves the region `Paused`, which is the conservative reading of BR8.8 and the one this
unit specifies. `saveInvalid` neither sets the pause nor clears it: it passes the region
by.

**Region `Write`** — `Idle` / `Armed` / `Saving`.

- **`Idle`** — no timer, no write in flight. A field change while any suspension holds
  leaves the region in `Idle`: the document becomes **dirty** (which feeds per-tab
  retention and the leave warning) but **no timer arms**.
- **`Armed`** — a field changed with no suspension holding and the **1,500 ms** timer is
  running. Each further change **re-arms** it. Any suspension beginning, or the document
  becoming clean, disarms it back to `Idle` **without firing**.
- **`Saving`** — a write is outstanding. Every outcome returns this region to `Idle`;
  what differs is the effect broadcast to the other regions.

## The events, and which regions consume them

| Event | Raised by | Regions that consume it |
|---|---|---|
| `storedDraftFound` / `noStoredDraft` | the mount scan completing | `Recovery` |
| `verdictRecoverable` / `verdictCorrupting` | a `200` from `POST /api/content/inspect` | `Recovery` |
| `inspectUnavailable` | inspect failing, or the backend unreachable | `Recovery` |
| `retryInspect` | the owner's retry affordance | `Recovery` |
| `restoreDraft` / `declineDraft` | the owner's choice on the offered draft | `Recovery`, and `restoreDraft` also `Pause` |
| `uploadStarted` / `lastUploadSettled` | `upload-field.tsx` | `Uploads` |
| `fieldChanged` | any editing surface, and the browser tool's `edit(...)` | `Write` |
| `documentClean` | the document matching the last accepted write | `Write` |
| `suspensionBegan` | `unsuspended` going from **true to false** — see § *The suspension predicate, stated once* | `Write` |
| `idle1500` | the arming timer elapsing — dispatches `action: 'draft'`, `autosave: true` | `Write` |
| `explicitSave` | the owner's save or publish control | `Write` |
| `save200` | an accepted write — **the base revision advances here** | `Write`, `Pause` |
| `saveInvalid` | a **`400` carrying a non-empty `issues[]`** — the backend's validation verdict on the submitted document; edits kept, `issues[]` rendered on the fields | `Write` **only** |
| `saveFailed` | `413`, `503`, a transport failure, or a `400` with **no** `issues[]` — edits kept, nothing to highlight | `Write`, `Pause` |
| `save409` | a rejected write under compare-and-set — edits preserved | `Write`, `Concurrency`, `Pause` |
| `latestLoaded` | the owner loading the latest saved draft, accepted — **the base revision advances here** | `Recovery`, `Concurrency`, `Pause` |

**`saveInvalid` and `saveFailed` replace the single `saveRejected` of the previous
draft.** They are distinguished **on the wire** — a `400` either carries `issues[]` or it
does not — which is the distinction `team.md` § *Code Style* already draws between a
recoverable and a fatal response, and it needs no state the browser holds. Why they must
be two events is § *A validation rejection is not a failed write*.

## The suspension predicate, stated once

> **`unsuspended` ≡ `Recovery = NoRecovery` ∧ `Uploads = NoUploads` ∧
> `Concurrency = Clean` ∧ `Pause = Ready`.**

**That is the whole predicate. It ranges over the four SUSPENSION regions and over
nothing else — `Write` is not a conjunct of it, and neither is the document's
dirtiness.** Everything else in this document derives from it, and nothing restates it.

> **Why `Write` is excluded, stated plainly because the previous draft got this wrong and
> the error was fatal.** The previous draft ended the predicate with `… and Write = Idle`
> and defined `suspensionBegan` as *that* predicate becoming false. From `Armed`,
> `Write = Armed`, so the predicate was **false by its own last conjunct the instant the
> timer armed**: `suspensionBegan` fired immediately, `Armed --> Idle : suspensionBegan`
> disarmed it, and an editor built literally from that predicate **never autosaves at
> all**. A suspension is a fact about the other four regions; the `Write` region's own
> position is carried by the edges, which is where it belongs.

Three things derive from `unsuspended`, and they are the only three:

1. **Arming.** `Write` moves `Idle --> Armed` on `fieldChanged` **when `unsuspended`**.
   The two conditions the previous draft folded into the predicate are carried by the
   edge instead: **`Write = Idle` is the edge's own source state**, and **dirtiness is
   what `fieldChanged` means** — the change that raises the event is what makes the
   document dirty.
2. **`suspensionBegan`** is raised **exactly when `unsuspended` goes from true to
   false**, and never by anything else. No `Write` transition can raise it, because no
   `Write` state appears in it. It is what disarms a running timer.
3. **Firing.** `Armed --> Saving : idle1500` needs no further guard, because
   **`Write = Armed` implies `unsuspended`**: any falsification of `unsuspended` while
   the timer runs raises `suspensionBegan` and leaves `Armed` first. That invariant is
   maintained by the `Armed --> Idle : suspensionBegan` edge, and it is the reason the
   arming check is needed in exactly one place.

**Note that `unsuspended` is NOT the explicit-save refusal predicate**, and the two must
not be collapsed. `Recovery = Scanning` and `Pause = Paused` both falsify `unsuspended`
while an explicit save is **permitted** in each — § *Explicit save — where it is
permitted* states that predicate separately, over its own tuple positions.

Every suspension **exit** is an exit from **one region**, and `unsuspended` is
re-evaluated over all four, so clearing one suspension while another holds arms nothing.
This is the property R-03 required and the flat machine could not carry. **Clearing the
last one arms nothing either**: `unsuspended` becoming true raises no event, and the next
`fieldChanged` is what arms the timer.

The four suspending conditions map to FR8.2 as follows: `Uploading` is FR8.2's upload
suspension; `Conflicted` is its conflict suspension; `Recovery ∈ {Scanning, Inspecting,
Offered, Held}` is its "awaiting the owner's decision" suspension; and `Pause = Paused`
is the **continuation** of that third suspension past the verdict (BR8.8) **plus** the
unnamed failed-write pause recorded above.

## Explicit save — where it is permitted, and what the owner sees where it is not

> **An explicit save is refused if and only if** `Uploads = Uploading` **or**
> `Concurrency = Conflicted` **or** `Recovery ∈ {Inspecting, Offered, Held}` **or**
> `Write = Saving`.

**`Pause = Paused` does not refuse an explicit save.** That is the entire content of
BR8.8: the pause stops **autosave**, and the owner's explicit save is what lifts it.

| Tuple position | Explicit save | What the owner sees |
|---|---|---|
| `Pause = Paused` (after `restoreDraft`, BR8.8) | **Permitted** — `Write` goes to `Saving`; on `save200` the pause clears | The normal save result. **This is FR8.3.4's path and the exit from `Paused`.** |
| `Pause = Paused` (after a failed write) | **Permitted** | The normal save result; a second `saveFailed`, or a `saveInvalid`, leaves the region `Paused` — only `save200` clears it |
| `Recovery = Scanning` | **Permitted** — no recovery record exists yet | The normal save result |
| `Recovery ∈ {Inspecting, Offered, Held}` | **Refused** | **Nothing.** The call returns without dispatching a write, sets no message and changes no state |
| `Uploads = Uploading` | **Refused** | **Nothing**, as above |
| `Concurrency = Conflicted` | **Refused** | **Nothing**, as above. The owner's route forward is the load-latest affordance, which is `Conflicted`'s only exit |
| `Write = Saving` | **Refused** | **Nothing**, as above |
| `Write = Armed` | **Permitted** — the timer is cancelled and the write dispatched once | The normal save result |

**The silent refusal is verified source behaviour** (`editor-workflow.ts:53` returns
`false` with no `setError` and no `setMessage`) and is **preserved**. Adding an
explanatory sentence would be **new copy** and therefore a parity change, so none is
added. Whether a control is visibly disabled in each case is `editor.tsx`'s presentation,
carried over unchanged, and is one of the things the recorded fixtures (U1) and the DOM
diff pin rather than something this document re-decides.

**Each suspension needs its own test.** A single "autosave is suspended" assertion that
happens to pass through one region proves nothing about the other three — and the case
the flat machine got wrong is precisely a **pair** of simultaneous suspensions, so at
least one Playwright case must hold two at once and assert that clearing one arms
nothing.

## A validation rejection is not a failed write

**This is the authoritative home of `Check these fields before saving. Your edits are
kept in this browser.`** — the sentence `editor.tsx:74` `manualSave` raises today. The
previous draft moved `manualSave`'s client pre-flight parse to "the backend's `issues[]`"
and stated the sentence's preservation only in `frontend-components.md`'s call-site
table, which left a preserved string with **no trigger anywhere in the authoritative
document**, and left a server-rejected save raising the undifferentiated `saveRejected`
that the `Pause` region consumed. Both are fixed here.

### The rule

> **A `400` carrying a non-empty `issues[]` raises `saveInvalid`, which is consumed by
> the `Write` region ONLY. It never moves the `Pause` region. Every other non-`2xx` and
> every transport failure raises `saveFailed`, which moves `Pause` to `Paused` exactly as
> `editor-workflow.ts:66` does today.**

### What the owner sees, by path

| Path | Outcome | What the owner sees |
|---|---|---|
| **Explicit save**, `400` with `issues[]` | `saveInvalid`. `Write` returns to `Idle`; `Pause` is untouched | `issues[]` are rendered on the fields, the **first is focused**, and the error surface shows `Check these fields before saving. Your edits are kept in this browser.` — `editor.tsx:74`'s own sentence, character-exact |
| **Autosave**, `400` with `issues[]` | `saveInvalid`. Same region effects | `issues[]` are rendered on the fields and **no sentence is set** — `editor-workflow.ts:54` sets its error only when `!automatic`, and that suppression is preserved |
| **Either**, `413` / `503` / transport failure / `400` with no `issues[]` | `saveFailed`. `Write` returns to `Idle`; **`Pause` moves to `Paused`** | The envelope's `error` sentence in the existing error surface, unchanged — `This update is too large.` for the 413, the source's 503 sentence for the 503 |
| **Either**, `409` | `save409` | § *The conflict flow* |

**The second row is the one that keeps autosave usable.** An owner typing an over-long
bio would otherwise have every 1,500 ms tick pause the editor, and the pause clears only
on an accepted write — which is the one thing an invalid document cannot produce. The
owner would have to fix the field **and** press save explicitly to get autosave back.
That is not what the source does and it is not what FR8.2 describes.

**One claim in the second row is flagged for the U1 fixtures rather than asserted.** The
**suppressed sentence** is verified (`editor-workflow.ts:54` sets its error only when
`!automatic`); whether the source's automatic branch **also populated the field
highlighting** before returning is not, because in the source the pre-flight returned
before dispatching and there was no server verdict to render. **The fixtures decide it,
and either answer is compatible with this specification**: highlight or do not highlight
on the autosave path — **no sentence is set either way**, which is the part that carries
the parity obligation.

### The server's `400` sentence is dead copy on this path

The `400` envelope carries an `error` sentence of its own, alongside `issues[]`
(`app/api/content/route.ts:15`). **On the `saveInvalid` path the owner does not see it**
— the editor shows `editor.tsx:74`'s preserved sentence instead, because that is what the
owner saw in the source when they pressed save with an invalid field. The server's
sentence still ports character-exact as `u6-http-api`'s product copy, because it is on
the wire and a non-browser client sees it, but **it is dead copy in the UI on this
path**. This is the same shape as the 409's two sentences in § *The conflict flow* step 3,
and it is recorded for the same reason: so a later reader does not "fix" the editor to
render it.

### The behaviour change this does introduce, stated rather than absorbed

**A save the source refused to dispatch is now dispatched.** The client pre-flight is
gone, so an explicit save with an invalid field costs one round trip and is rejected by
Python rather than by the browser. What the owner sees is unchanged — the same sentence,
the same field highlighting, the same focused first issue — and **no write is created**,
because a `400` is a rejection. What changes is latency on an error path and the fact
that the authoritative validator is now the one that answers. **That is the language
boundary working as intended**, not a regression: the previous arrangement had the
browser deciding, and the sentence it raised could disagree with the server's verdict.

**The two things that must NOT change with it** are the pause (fixed above) and the
sentence (given its trigger above). Both were at risk from the same edit.

---

# The conflict flow (FR8.5)

A `409` from `PUT /api/content` means the base revision is no longer current. The
backend has already done three things: **rejected the write**, **preserved the caller's
edits** (by not applying them), and **returned the current state so the caller can
reconcile** (BR4.7).

The editor then:

1. **Moves the `Concurrency` region to `Conflicted` and the `Pause` region to
   `Paused`** — the source sets both flags on the 409 branch
   (`editor-workflow.ts:59`, and again in the `catch` at `:66`) — so autosave is
   suspended twice over (FR8.2).
2. **Preserves the owner's edits in the form.** Nothing is cleared, reset or replaced.
3. **Renders the conflict sentence. Two different sentences exist and only one of them
   reaches the owner** — the earlier draft of this section conflated them, and the
   distinction is load-bearing for the port:

   | Sentence | Where it lives | Owner |
   |---|---|---|
   | `This draft changed in another tab. Your edits are still here. Review the latest saved draft before saving again.` | the **409 response body**, `app/api/content/route.ts:18` | **BR10.7**, `u6-http-api` |
   | `Another tab saved a newer draft. Your edits are safe here. Load the latest draft before choosing whether to recover your edits.` | a **frontend literal**, `app/edit/editor-workflow.ts:59` | **this unit** |

   **The 409 branch throws its own literal before the response body is ever read for its
   `error` field, so the server's sentence is never displayed.** What the owner sees is
   the frontend literal, and it is this unit's product copy: it must port
   character-exact. The server's sentence must still port character-exact as BR10.7 — it
   is on the wire and it is what a non-browser client sees — but it is **dead copy in the
   UI**, and that is recorded here so a later reader does not "fix" the editor to render
   it.
4. **Offers loading the latest saved draft.** When that load is accepted it raises
   `latestLoaded`, which does four things at once: the base revision advances; the
   `Concurrency` region returns to `Clean`; the `Pause` region returns to `Ready`; and
   **the owner's local edits are stashed as a fresh recovery offer**, moving the
   `Recovery` region from `NoRecovery` to `Offered` (`editor-workflow.ts:74`). **That
   offer is FR8.5 step 4's path** — the owner then restores their local edits on top of
   the loaded draft (`restoreDraft`, which moves `Pause` to `Paused` under BR8.8) and
   saves explicitly, which is permitted from `Paused` and is the exit from it.
   **The stashed edits are in-memory content, not bytes read from storage, so they do
   not pass through `POST /api/content/inspect`** — they enter the `Recovery` region
   directly at `Offered`. A developer who routes them through `Inspecting` adds a round
   trip the source does not have.
5. **Advances the locally-held base revision only when the owner takes that step** —
   see § *The base-revision advance rule*. **The 409 body carries the current state,
   and the editor must not treat that as permission to advance.**

**Step 5 is the whole of the flow's correctness.** Steps 1–4 fail visibly if they are
wrong. Step 5 fails silently, and it destroys committed work.

**An explicit save is refused while `Conflicted`**, silently, per § *Explicit save —
where it is permitted*. The load-latest affordance is the owner's only route forward,
which is why it is a control and not a suggestion.

**The load itself can fail, and that failure is specified.** A non-`200` from
`GET /api/content` leaves every region exactly where it was — still `Conflicted`, still
`Paused`, edits untouched — and renders the source's own sentence, which is product copy
owned by this unit: `The latest draft could not be loaded. Your edits remain here.`
(`editor-workflow.ts:73`). The load is additionally **refused, silently, while a save or
an upload is in flight** (`editor-workflow.ts:72`).

The editor **branches on the status `409`** to enter this flow, which is why FR10.1's
envelope is a hazard: a different error shape and this branch never arms, while
everything **appears** to work.

---

# Autosave, and its suspensions (FR8.2)

> **FR8.2 names three suspensions; the implemented machine has four.** The fourth is the
> `Pause` region, which carries BR8.8's pause-after-restore **and** a pause after any
> failed write. The heading is deliberately not "three suspensions" any more.

**Drafts autosave after a short idle period — 1,500 ms since the last field change.**
The timer is **re-armed** by each change, so it fires on idleness, not on a schedule.

**Autosave is suspended while:**

1. **an upload is in flight** — region `Uploads` = `Uploading`;
2. **a conflict is unresolved** — region `Concurrency` = `Conflicted`;
3. **a recovered draft is awaiting the owner's decision** — region `Recovery` ∈
   {`Scanning`, `Inspecting`, `Offered`, `Held`};
4. **the pause flag is set** — region `Pause` = `Paused`, which carries the
   **continuation** of suspension 3 past the verdict (BR8.8, restoring a recovered draft)
   **and** a pause after a **failed write** (`saveFailed` or `save409`). **FR8.2 names
   only the first three**; the failed-write pause is verified source behaviour
   (`editor-workflow.ts:66`), preserved under the parity rule, and flagged for the
   recorded fixtures to pin. **A validation rejection (`saveInvalid`) is not a failed
   write and does not reach this region** — see § *A validation rejection is not a failed
   write*, which is where that distinction is argued.

Four properties of the suspensions:

- **They are independent, and the machine is orthogonal because of it.** Any one of them
  suspends; **all** must clear before autosave may arm again. Each lives in its own
  region, and an exit edge returns **that region** to its resting state — never the
  machine to `Idle`. The arming condition is `unsuspended`, defined once in § *The
  suspension predicate, stated once* and evaluated over the four suspension regions, so
  an upload settling while a restored draft is still paused arms nothing.
- **Suspension disarms, it does not queue.** A suspension that ends does not fire a
  pending autosave; the next **field change** re-arms the timer. Otherwise clearing a
  conflict would immediately dispatch a write the owner never triggered, into a document
  that has just moved.
- **Suspension 3 outlasts the verdict, in a region of its own.** Restoring the draft
  returns `Recovery` to `NoRecovery` **and** moves `Pause` to `Paused`, which persists
  until an **explicit save is accepted** (BR8.8) — so recovery never silently overwrites
  the stored draft. The pause clears on `save200`, not on the save being dispatched: an
  explicit save that is itself rejected or invalid leaves the region `Paused`, because
  neither `saveFailed` nor `saveInvalid` clears it.
- **Every autosave is `action: 'draft'`.** The backend enforces this (BR10.12): an
  `autosave` flag is legal **only** with a draft action. **Autosave can never publish**,
  which is what bounds every failure mode in § *`uploads`* above.

---

# The leave warning (FR8.4)

The owner is warned before leaving with **unsaved changes**, **an upload in flight**, or
**a save in progress** — three independent conditions, matching, across the regions of
§ *The state machine*: a **dirty** document (`Write` = `Armed`, or `Write` = `Idle` with
the document dirty because a suspension held), `Uploads` = `Uploading`, and `Write` =
`Saving`. **The warning's conditions are not the autosave suspension set** — a dirty
document does not suspend autosave, it is what autosave exists for — and the two lists
must not be collapsed into one predicate.

This is a browser affordance and nothing depends on it: the backend has already
persisted whatever was accepted, and the per-tab retention (FR8.3) is what actually
protects the unsaved work. **The warning is a courtesy over a real safety net, not the
safety net** — which is why losing it is an experience regression and losing per-tab
retention is data loss.

---

# The private draft preview (FR8.6)

The preview renders **the unsaved draft**, using the **visitor's presentation**, in an
**isolated frame**, and is **never indexed**.

**The draft the preview renders is unsaved, so nothing has validated it.** An earlier
draft of this section removed the preview's validation on the reasoning that *"the
backend validated it at save"* — which is false for the only case the preview exists to
serve, and which also deleted user-facing product copy. Both are corrected here. **The
validation is not restored to the browser; it is routed to Python.**

## What validates an unsaved draft, and where

**`POST /api/content/inspect` does** — the operation C1 already carries
(`contract-summary.md`, the `/api/content/inspect` block), owner-only, returning
`{ normalised, issues: [{path, message, recoverable}] }`. It exists because **ADR-006**
moved the recovery classification into Python; the preview is the same question over the
same schema, asked from the same owner context, so it takes the same answer rather than a
second, hand-written one. **BR8.9 is therefore intact: no browser-side mirror of the
schema is created, and `zod` still leaves the frontend.**

**The source has two parse sites on this path, not one**, and both must be accounted for
or a piece of copy is lost:

| Source site | What it does | What it becomes |
|---|---|---|
| `app/edit/editor.tsx:75` `startPreview` | parses the form content; **on failure the preview never opens**, `issues[]` are rendered, the first is focused, and the owner sees `Check the highlighted fields before opening the preview.` | the editor calls `POST /api/content/inspect` and branches on `issues[]` |
| `app/edit/preview/preview-client.tsx:9` | bounds the payload at **6,000,000** characters and parses it; **on either failure** the owner sees `This draft contains a field that needs attention. Return to the editor to review it.` | the bound stays in the frame unchanged; the parse becomes the frame's own `POST /api/content/inspect` |

**Both sentences are product copy and both are preserved verbatim.** Neither is retired,
and no parity exception is claimed for either — unlike BR10.9's four upload strings,
which are named as deliberately retired because the checks that raised them no longer
exist. Here the checks still exist; only the validator moved.

## What BOTH preview gates do with `issues[]`, stated once

The two gates below — `startPreview` and the frame — share one trigger. It is stated here
once and neither gate restates it.

> **On the preview path, the gate fires on `issues[]` being non-empty. `recoverable` is
> NOT consulted, at either gate.**

### Why `recoverable` is not consulted, argued against FR8.3.3 rather than against the uncorrected source

The previous draft justified this by saying the source's `safeParse` fails for recoverable
issues exactly as it fails for corrupting ones. That is true but it is **not a sufficient
argument**, because **FR8.3.3 is a correction to the source's handling of one of those
classes** — the enumerated-value class (`accent`, `researchTopic`, the scene's
`initialView`) — so "the source did it" cannot settle a question about that class. The
argument has to be made against the corrected requirement, and it is:

- **FR8.3.3 corrects the RECOVERY classifier, and the recovery classifier decides whether
  the owner's stored work is KEPT OR DESTROYED.** The source discarded an entire recovered
  draft over one out-of-set enum. That is why the misclassification mattered enough to
  become a numbered correction.
- **The preview decides nothing about the owner's work.** The draft stays in the form
  either way; nothing is stored, discarded or overwritten by a preview that does not open.
  The two decisions are not the same decision over the same input, and FR8.3.3's
  correction does not reach a path where nothing can be lost.
- **Consulting `recoverable` here would make the preview quietly WRONG.** The only
  document the frame could render for a recoverable issue is `normalised` — the document
  **repaired against schema defaults**. An owner who typed an out-of-set accent would be
  shown a preview in the **default** accent, with no indication that what they are looking
  at is not what they typed. The preview exists to show the owner what the site will look
  like; showing them a silently repaired document defeats it.
- **Refusing costs the owner nothing and tells them something true.** `startPreview`
  highlights the offending field, focuses the first one and names the problem. The owner
  fixes the field and previews. Nothing is lost in between.

**A correction to step 3's rationale, which the previous draft stated too broadly.** It
said the source rendered `safeParse`'s `result.data`, *"the parsed document with schema
defaults applied"* — which is right about the **success** path and must not be read as
covering this one. In the source, schema defaults fill fields that are **absent**, on a
parse that **succeeded**; a document carrying an out-of-range or out-of-set value does
not parse successfully at all and never reached the render path. So the source never
rendered a document repaired from a recoverable issue, and step 3's rationale does not
argue that it did.

### Why the two gates still differ in OUTCOME, which is not a severity key

The trigger is identical; the outcome differs, and it differs because the two gates sit at
different points in the flow and each keeps its own source behaviour:

| Gate | Question it answers | Outcome on non-empty `issues[]` | Sentence |
|---|---|---|---|
| `startPreview` (editor) | **Does the preview open?** | It does not open. Fields are highlighted, the first is focused | `Check the highlighted fields before opening the preview.` |
| The frame (`preview-client.tsx`) | **What does this frame render?** | The existing `unavailable` block replaces whatever was rendered | `This draft contains a field that needs attention. Return to the editor to review it.` |

**The frame cannot "refuse to open" — it is already open** — and the editor cannot render
an error inside a frame it declined to create. Neither outcome is available to the other
gate, so there is nothing to make consistent beyond the trigger, which now is.

**In the ordinary flow the frame's gate never fires**, because the editor's gate already
passed the same document through the same operation. It fires in exactly two cases, and
both are real: the document **changed** between the editor's inspect and the frame's (the
parent re-sends on `[theme, content, ready]`), or the editor's gate was **skipped** — the
`503`/transport branch of `startPreview`, where the editor deliberately opens a preview it
could not check. **The second case is precisely what the frame's sentence exists for**,
which is why the frame keeps a gate at all.

## The editor's gate — `startPreview`

**Becomes asynchronous.** It calls `POST /api/content/inspect` with the current form
content and branches:

- **`200` with non-empty `issues[]`** → **the preview does not open.** `issues[]` are
  rendered on the fields, the first is focused, and the error surface shows
  `Check the highlighted fields before opening the preview.` — source behaviour and
  source copy, unchanged. **`recoverable` is not consulted**, per § *What BOTH preview
  gates do with `issues[]`, stated once*, which is where that is decided and argued.
- **`200` with empty `issues[]`** → the preview opens and the editor posts the draft into
  the frame exactly as today. **It posts the form content, not `normalised`** — the frame
  does its own normalisation, which is what the source does and what keeps the two sites'
  roles intact.
- **`403`** → the session has lapsed; this takes the same path as every other `403` in
  this unit — **redirect to sign-in** (§ `app/edit/page.tsx` in `frontend-components.md`).
- **`400`** → the envelope's `error` sentence is rendered in the existing error surface
  and the preview does not open. This is the same shape every other failed call in
  `editor.tsx` already has (`setError(result.error || …)`), so it introduces no new copy.
- **`503` or a transport failure** → **the preview opens.** The editor declines to claim
  a field problem it could not check, and the frame's own failure path (below) surfaces
  the condition with the source's own on-subject sentence. **This is a path the source
  cannot have** — its gate is synchronous and cannot fail — so no existing behaviour is
  changed; it is recorded as an addition, and it deliberately reuses existing copy
  instead of inventing a sentence.

## The frame — `preview-client.tsx`

**The `postMessage` protocol and its origin check are unchanged**, and the frame's
handling is now specified for every message it can receive. A message is **accepted only
if all three hold**: `event.origin === location.origin`, `event.source === window.parent`,
and `event.data?.type === 'academic-draft-preview'`. **A message failing any of the three
is ignored silently** — nothing renders, no error appears, and the frame keeps whatever
it is showing. That is source behaviour and it is preserved.

For an accepted message:

1. **Serialise and bound.** If `JSON.stringify(event.data.content)` throws, yields
   `undefined`, or exceeds **6,000,000 characters**, show the sentence
   `This draft contains a field that needs attention. Return to the editor to review it.`
   and stop. **This is the preview's copy of the 6,000,000 bound and this unit keeps it**
   — see § *Assumptions & Open Questions*. It is a local size guard, not a mirror of any
   backend model, so BR8.9 does not reach it.
2. **Inspect, with a bounded request count.** Otherwise `POST /api/content/inspect` with
   that document. **At most one inspect is in flight**: a newer payload aborts the
   outstanding request via `AbortController` and issues its own, and an aborted request
   raises nothing.

   **Verdict reuse is restricted to payloads that actually received a verdict.** This
   restriction is the whole of the rule and the previous draft omitted it, which broke the
   one recovery affordance the design relies on — see the box below.

   > **A *verdict* is a `200` (with `issues[]` empty or not) or a `400`** — the two
   > outcomes that tell the frame something about the document. **`403`, `503`, a network
   > failure and an aborted or superseded request are NOT verdicts**, and the frame
   > records nothing for them.
   >
   > The frame keeps **one** cache entry: the serialisation of the last payload that
   > received a verdict, and that verdict. A payload whose serialisation equals the cached
   > one **re-applies the cached verdict and issues no request**, which is what makes a
   > theme-only re-send and the `ready`/`onLoad` double-send free. **Every other payload,
   > and every payload at all after a non-verdict outcome, issues a request.**
   >
   > **Re-applying a cached verdict reproduces the WHOLE of its outcome**, including step
   > 3's `academic-preview-rendered` post — so the parent's watchdog is answered exactly
   > as a fresh request would answer it. Reuse is not "do nothing".
   >
   > **The cache is per frame instance.** A `Reload preview` that remounts the frame
   > starts with an empty one.

   **Why the restriction is load-bearing.** Step 5 routes `403`, `503` and network
   failures to the parent's watchdog, whose only affordance is `Reload preview`, which
   re-posts the **identical** payload. Under an unrestricted reuse rule that reload would
   match the cache and issue no request, so the frame could never recover from the exact
   transient failure the design nominates as its failure surface — and the design leans on
   that control twice, here and in `startPreview`'s `503` branch, where the editor
   deliberately opens a preview it could not check. **A reload after a failed or aborted
   inspect always re-issues.**
3. **`200` with empty `issues[]`** → render `normalised`, apply
   `event.data.theme === 'dark' ? 'dark' : 'light'`, clear any previous error, and post
   `{type: 'academic-preview-rendered'}` to the parent at `location.origin`. **The
   rendered document is `normalised`, which is what the source rendered** — it rendered
   `safeParse`'s `result.data`, the parsed document with schema defaults applied to fields
   that were **absent**, on a parse that **succeeded**. (It is not a claim that the source
   rendered documents repaired from an out-of-range or out-of-set value: those did not
   parse, and § *What BOTH preview gates do with `issues[]`* states what happens to them.)
4. **`200` with non-empty `issues[]`, or `400`** → the sentence
   `This draft contains a field that needs attention. Return to the editor to review it.`,
   in the existing `unavailable` block under its existing `Preview needs attention`
   heading, replacing any document already rendered. **`recoverable` is not consulted**,
   per § *What BOTH preview gates do with `issues[]`, stated once* — which is the single
   place that decision is taken, for this gate and for `startPreview` together.
5. **`403`, `503` or a network failure** → **no `academic-preview-rendered` is posted**
   and the frame keeps what it is showing. The parent's **existing** ten-second watchdog
   then surfaces its **existing** sentence, `The preview is taking longer than expected.
   Your draft is still in the editor.`, with its **existing** `Reload preview` control
   (`draft-preview.tsx`). **No new copy, no swallowed failure, and no sentence that
   misdescribes the cause** — the source's own words for "the preview did not come back"
   are already the right ones. That reload always re-issues, per step 2.

   **A superseded request is NOT in this list**, and the previous draft's inclusion of it
   double-classified the same event. Step 2 already disposes of it: the aborted request
   raises nothing, and the request that superseded it goes on to take one of outcomes 3, 4
   or 5 **in its own right**. Nothing is swallowed, and in the ordinary case the
   superseding request renders and posts `academic-preview-rendered`, so the watchdog
   never fires. **The watchdog covers the residual case — no inspect completing at all
   within its ten-second window — which is a property of the window, not a fifth
   outcome.**

**Why the frame inspects at all, when the editor already did.** The editor's gate decides
whether the preview opens; the frame's decides what it renders. They are different
questions, and only the second bounds a payload arriving over `postMessage` from a
context the frame does not control. Collapsing them would leave the origin check as the
only gate on what the frame renders, which is exactly the boundary R-07 required to have
defined behaviour.

**What this costs, stated rather than absorbed.** The preview now depends on the backend
being reachable, where the source's was purely local. That is the same trade **ADR-006**
already accepted and recorded for recovery — *"Draft recovery now requires a network
round trip"* — and it is bounded here by the coalescing rules above and by the fact that
content cannot change while the preview workspace is open, so the common case is one
inspect per preview session plus one per theme toggle avoided by the reuse rule.

## Four facts that hold across the whole preview path

- **It needs no backend operation of its own, and still does not.** `GET /api/content`
  already returns the draft, and `contract-summary.md` § C1 states this explicitly
  *"because leaving it implicit invites a redundant endpoint"* (R-02). The inspect call
  above is an **existing** C1 operation, not a preview-specific endpoint.
- **One precondition belongs to the contract, not to this unit.** C1 states that
  *"Mutations additionally require the paired CSRF token as a request header"*, and the
  frame is a **separate browsing context** that holds no in-memory token. **`POST
  /api/content/inspect` mutates nothing** — it classifies a document the caller supplied
  and returns a normalisation of it — so it should be classified **non-mutating**, taking
  the owner session cookie and the origin check without the double-submit header. **That
  classification is `contract-design`'s and `u6-http-api`'s to make, not this unit's**,
  and it is recorded as an owned item in § *Assumptions & Open Questions*. **The question
  stays open here and this unit does not answer it.**

  **If it is ruled the other way, the fallback is spelled out rather than gestured at,
  because it reverses a decision this document takes elsewhere.** The editor becomes the
  **sole** inspector; the frame issues no inspect of its own, and its check degrades to
  the structural one in step 1. Three consequences follow and all three are stated:

  - **`startPreview` then posts `normalised`, NOT the form content — which SUPERSEDES the
    second bullet of § *The editor's gate*** (*"It posts the form content, not
    `normalised`"*), stated there as the decision that keeps the two sites' roles intact
    and matches the source. Under the fallback the two roles cannot stay intact, because
    only one site is left. The sentence is superseded knowingly, not left to be
    discovered.
  - **What the frame renders is unchanged in substance.** In the main design the frame
    renders the `normalised` document **its own** inspect returned; under the fallback it
    renders the `normalised` document **the editor's** inspect returned and posted. Same
    normalisation of the same document, computed one hop earlier — so no rendered output
    changes and step 3's `academic-preview-rendered` handshake is untouched. What the
    frame loses is the ability to **check** what it renders: step 4's sentence can then be
    raised only for a structural failure (step 1) and never for an `issues[]` verdict,
    because the frame never obtains one.
  - **That is the weakening R-07 identified**, and it is why the recorded position is that
    inspect is **not** a mutation. The fallback preserves every sentence in this document;
    it does not preserve the boundary.
- **The preview route's own sign-in copy.** `app/edit/preview/page.tsx` today gates
  server-side and, when the caller is not the owner, renders `Private draft preview` /
  `Sign in as the website owner to preview a draft.` / `Open the editor`. The rewire to a
  client shell already recorded in `frontend-components.md` replaces that with the
  **sign-in redirect** every other `401`/`403` in this unit takes — the same destination
  that copy's link offered. Recorded here so the disappearance of those three strings is
  a visible consequence of a decision already taken, not an oversight.
- **Never indexed.** `robots.txt` disallows `/edit` (FR2.4) — **and that exclusion is
  never the only thing protecting it** (FR2.6). Access is enforced independently in
  Python at each operation (BR3.1).

---

# The browser tool (FR8.8)

`stage_academic_profile` on `document.modelContext` is **preserved**, with **exactly two
deliberate changes, both DECIDED by the site owner at the functional-design gate** and
recorded below as decisions taken rather than as open questions. Everything else in the
registration and in `execute` is character-exact.

**Everything in this section was read out of the source**, not inferred:
`madhavi-tripathi/app/edit/editor.tsx:81`, one minified line inside a `useEffect`.

## The registration, exactly

| Field | Value |
|---|---|
| `name` | `stage_academic_profile` |
| `title` | `Stage profile changes` |
| `description` | `Stage profile fields in the owner editor. Valid edits autosave as a draft; publishing is a separate owner action.` |
| `inputSchema` | `object`, six `string` properties, **`additionalProperties: false`** |
| properties | `name`, `role`, `affiliation`, `headline`, `intro`, `bio` |
| `annotations` | `readOnlyHint: false` (**unchanged**), **`untrustedContentHint: true`** — **CHANGED from the source's `false`, per the decision below** |

Registered on `document.modelContext.registerTool(...)`, guarded by
`if (!model?.registerTool) return`, wrapped in `try/catch`, with a `.catch(() => {})`
on the promise, and an `AbortController` whose `signal` is passed in and whose
`abort()` is the effect's cleanup. **Empty dependency array** — it registers once per
mount.

`title` and `description` are strings the model and the owner both see, so they are
**product copy** and fall under the character-exact parity answer.

## `execute`, step by step

1. Reject input that is **falsy, not an object, or an array** →
   `Error('Expected profile fields')`.
2. **Per entry**, reject unless **both** hold: the key is one of the six, and the value is
   a **string** → `Error('Invalid profile field')`. **The source's third condition,
   `value.length <= 10000`, is REMOVED, per the decision below.** The literal
   `Invalid profile field` is unaffected: it is still raised, by the two conditions that
   remain.
3. `edit(old => ({...old, ...input}))` — a **merge** into editor draft state, not a
   replacement. Unlisted fields are untouched.
4. `setTab('profile')` — the editor switches to the profile tab, so the staged change is
   visible rather than buried.
5. `setMessage('Profile fields staged as a draft. Review before publishing.')`.
6. Return `{ staged: Object.keys(input), published: false }`.

**It never publishes.** The staged edit reaches the server only through the editor's
normal autosave path, where **Python validates it like any other input**. Those three
literal strings — `Expected profile fields`, `Invalid profile field`, and
`Profile fields staged as a draft. Review before publishing.` — are **product copy**.

## Registration failure is silent, and that is preserved

**Every failure path is swallowed.** The `if (!model?.registerTool) return` guard, the
`try/catch` and the `.catch(() => {})` together mean that **if registration throws or
rejects, the editor renders normally and the tool is simply absent.**

This is **specified behaviour, not an error path** — the same shape of decision as
BR8.7's held draft, and preserved for the same reason: the editor is the owner's
working surface, and a browser capability that fails to register must never be allowed
to take the editor down with it. A browser that does not expose
`document.modelContext` at all takes the same path as one where registration failed,
and neither is distinguishable from the other by design.

**It receives no `BR` id**, per the adjudication above: it decides nothing the backend
could decide, and a wrong value produces at most a missing affordance.

**Its cost is that a broken registration is undiagnosable from the UI.** Stated rather
than fixed: adding a visible error would be new copy and therefore a parity change.

## Why it survives the language boundary

**It mutates local form state only.** Staged values sit in the form exactly as typed
values do, and reach storage only through an ordinary save, where Python is the
authoritative validator (FR4.3).

The tool's remaining checks — **the key set and the value types** — are an **input
affordance**, not an enforcement point: they gate what may enter a form field, not what
may be persisted. That is why they are not the hand-written client-side validation
`project.md` § *Forbidden* prohibits, and it is also why removing the **length** check
takes nothing away from the boundary. A length is a schema constraint, which is exactly
what the browser may not hold; a key set and a type are the shape of the tool's own
`inputSchema`, which the tool must know in order to exist at all.

**A tool that could save or publish would be a different thing entirely** — an
unattended write path into the owner's published site. The prohibition is the reason
the tool is allowed to exist at all.

## The defect the source carries, and the decision taken on it

### The defect, verified from source

`madhavi-tripathi/app/content.ts:5` declares `const text = z.string().max(10000)`. The
six profile fields do **not** all use it, so the tool's flat check is **looser than the
schema for four of the six**:

| Field | Backend schema | Source tool check | Agreed? |
|---|---|---|---|
| `name` | `.trim()`, then **`min(1)`**, then **`max(100)`** | `length <= 10000` | **no** |
| `role` | `max(200)` | `length <= 10000` | **no** |
| `affiliation` | `max(200)` | `length <= 10000` | **no** |
| `headline` | `max(240)` | `length <= 10000` | **no** |
| `intro` | `text` → `max(10000)` | `length <= 10000` | yes |
| `bio` | `text` → `max(10000)` | `length <= 10000` | yes |

**The failure, concretely.** A 5,000-character `name` **passes the source's tool**, merges
into the editor, switches to the profile tab, sets
`Profile fields staged as a draft. Review before publishing.`, and returns
`{staged: ['name'], published: false}` — **a success result** — and then the autosave
**fails validation at the server with a 400**. **The model is told the edit worked; the
owner sees a save error.** The source's tool also **ignores `name`'s `.trim().min(1)`**,
so a whitespace-only name stages cleanly and fails the same way. **This is pre-existing
and reproduces without the migration.**

### DECISION (site owner, functional-design gate): accept asynchronous rejection

> **The tool's length check is REMOVED. `execute` validates the key set and the types; the
> backend rejects over-long input at save, with `issues[]`. The rejection still happens —
> only WHERE and WHEN it happens changes, and that is the accepted cost.**

**Nothing replaces the check.** **No generated runtime validator is provisioned** — the
generated frontend surface this corpus actually has is `openapi-typescript`'s
**compile-time types** (`construction/api-client/functional-design/entities.md`
§ *generated_surface*), checked by `tsc --noEmit` at the merge gate, and TypeScript cannot
express or enforce a string `maxLength` against input arriving at run time. **And no
hand-written cap is added**, flat or per-field: `project.md` § *Forbidden* prohibits a
hand-written client-side validation rule outright, and FR8.9 says the same. The earlier
draft's *"use the generated mirror"* position was not implementable as named and has been
**removed entirely** rather than left standing as an option.

**The behaviour change, stated plainly.** **A profile field longer than 10,000 characters
is now rejected at save rather than synchronously in the browser.** Under the source the
model received `Error('Invalid profile field')` immediately; under this decision the value
stages into the form, the tool returns its success result, and Python rejects the save.
**This is a parity change and it is accepted as one.**

**What it costs, without softening:**

- **The four-of-six mismatch becomes six-of-six.** Every one of the six fields now returns
  a success result for input the server will refuse, where before four did. The
  inconsistency is gone; the asynchrony is general.
- **The model is still told the edit worked.** `{staged: [...], published: false}` is
  unchanged, and it is returned before any save is attempted. A model reading that result
  as "persisted" was wrong before this decision and is wrong after it; the tool's
  `description` already says *"Valid edits autosave as a draft"*, and that word is doing
  the work.
- **On the autosave path the owner sees no sentence.** The staged over-long value triggers
  an autosave, the backend answers `400` with `issues[]`, and per § *A validation
  rejection is not a failed write* the autosave path **highlights the fields and sets no
  message** — `editor-workflow.ts:54`'s `!automatic` suppression, preserved. The owner
  learns of the problem from the highlighted field, or on their next explicit save, which
  shows `Check these fields before saving. Your edits are kept in this browser.` **Stated
  because it is the least visible consequence of this decision**, not because it changes
  it.
- **It contradicts FR8.8 as written**, which says the tool *"validates field names **and
  lengths**"*. Names and types are still validated; lengths are not. **This is recorded as
  a requirements amendment**, here and in `traceability.json`'s FR8.8 row, and not as
  compliance.

**Why the cost is bounded.** The check was never an enforcement point — Python is the
authoritative validator under the language boundary (FR4.3, BR3.1) and re-validates every
save regardless — and no input this removal newly admits could ever have been **persisted**
before, only rejected earlier. Nothing that was savable becomes unsavable.

### DECISION (site owner, functional-design gate): `untrustedContentHint: true`

> **The annotation is flipped from the source's `false` to `true`.**

The tool is **model-driven**, and the project brief treats model output as **untrusted
data**; the source's declaration says the opposite of the brief. **It was not a
vulnerability as it stood** — `execute` validates the key set and the types,
`additionalProperties: false` bounds the shape, and Python re-validates authoritatively —
and flipping it **changes no behaviour and costs nothing**. It is a one-field change to a
declaration, recorded rather than made silently because it is a visible attribute of a
tool the brief requires to be preserved.

**Everything else in the registration is preserved character-exact**: `name`, `title`,
`description`, the six `string` properties, `additionalProperties: false`,
`readOnlyHint: false`, the `if (!model?.registerTool) return` guard, the `try/catch`, the
`.catch(() => {})`, the empty dependency array, and the `AbortController` whose `abort()`
is the effect's cleanup.

---

# Assumptions & Open Questions

- **[CLOSED, this stage — the open item assigned to `functional-design`]** *Is any part
  of the editor's multi-flag save state machine a rule rather than presentation state?*
  **No.** `busy`, `uploads`, `paused`, `conflict`, `recoveryReady` and the 1,500 ms
  arming interval are **presentation state**; none crosses to Python; none receives a
  `BR` id. Full reasoning in § *The save state machine — the adjudication*, including
  the structural argument that the backend has **no operation whose behaviour differs on
  the autosave flag** and therefore nowhere to put such a rule. Three obligations are
  carved out and specified: **BR8.7**, **BR8.8** (both already rules, owned by
  `OwnerEditor`, specified in `construction/functional-design/rules.md`) and **the
  base-revision advance rule**, which is new here and deliberately unnumbered.
- **[CLOSED, this stage — the dependent item]** *If that state machine lands in the
  frontend, does a browser-driven check become mandatory?* **Yes. Playwright moves from
  optional to mandatory**, per `team.md` § *Testing Posture*, `WORKING-RECORD.md` § 9 and
  `construction/functional-design/rules.md` § *Assumptions*. The **eight** behaviours it
  must cover are enumerated in § *The consequence for verification*, which lists exactly
  eight numbered items. **The earlier "five" here was a derived count that had drifted
  from its source** — the same class of error as R-08 — and the source itself then grew an
  eighth item in this iteration (the validation rejection that must not pause, R-11), so
  the count is restated against a re-read of the list rather than adjusted by one.
- **[CORRECTION, recorded not silently resolved]**
  `construction/functional-design/frontend-components.md` § *Assumptions* states the
  Playwright conditional **backwards** — it says a rule **crossing to Python** makes a
  browser check mandatory. A rule that crosses to Python becomes testable **without a
  browser**, which **ADR-006** states verbatim about the one rule that did cross. Three
  other corpus sources state the conditional the right way round. Corrected in this
  unit's `frontend-components.md`; the workflow-level file is not edited by this unit.
- **[DECIDED, site owner, functional-design gate — the three bounds]** **Preserve both
  6,000,000 bounds and the 1,500,000 save cap, warn the owner at restore, and set
  `POST /api/content/inspect`'s body cap to match the recovery bound.** This replaces the
  open item this artifact previously carried, and it closes the latent defect recorded in
  `WORKING-RECORD.md` § 9 as *"no owner yet — unassigned, decide at the functional-design
  gate."* It was decided at that gate.

  **What was decided, on each of the three call sites and on inspect:**

  | Site | Bound | Decision |
  |---|---|---|
  | `editor-workflow.ts:15` `parseRecovery` (draft recovery) | 6,000,000 | **Unchanged.** Nothing is lowered |
  | `preview-client.tsx:9` (the preview client) | 6,000,000 | **Unchanged.** Nothing is lowered |
  | `app/api/content/route.ts:11` (`PUT /api/content`, the save cap) | 1,500,000 | **Unchanged.** The 413 and `This update is too large.` are untouched |
  | `POST /api/content/inspect` body cap | **set to the recovery bound** | **Owned by `contract-design` / `u6-http-api`, being changed in parallel.** Stated as a dependency below; the endpoint's own rule is NOT written here |

  **The warning is the one addition.** A recovered draft whose save payload would exceed
  the save cap raises, at restore,
  `This recovered draft is too large to save. Your edits are here; shorten the draft before saving.`
  — specified in full, with its trigger, its measured subject and its drift risk, in
  § *The recovery flow* → § *The oversize-draft warning at restore*. **It is new copy and
  therefore a parity change, accepted for that reason**: the alternative is that the
  owner's longest content fails silently, on every autosave, with nothing on screen
  explaining why.

  **Why the inspect cap is part of the same decision, and what depends on it.** Under this
  unit's design, inspect receives the recovered draft (recovery) and the posted document
  (preview). **If inspect were capped at the save cap, a draft between the two bounds
  would fail inspect and land in `Held` (BR8.7) instead of being offered** — the editor
  would show an unavailable-and-retry state for a draft that is perfectly classifiable,
  and "preserve all three bounds" would not in fact have preserved anything. Setting
  inspect's cap to the recovery bound removes that: **a draft that is recoverable is
  always inspectable.** It also covers the preview, without a second number — the preview
  bound measures `content` alone while the recovery bound measures the whole stored record
  `{content, revision, savedAt}`, so for the same document the preview payload is **never
  larger**. **This unit DEPENDS on that cap and does not specify it**; `u6-http-api` owns
  it and is carrying the change.

  For the record, the three bounds as verified from source, all measured in
  **characters**:

  | Bound | Site | What it measures | What happens at the boundary |
  |---|---|---|---|
  | **6,000,000** | `app/edit/editor-workflow.ts:15` (`parseRecovery`) | the **whole stored record** serialised — `{content, revision, savedAt}` | the stored draft is treated as **absent**: it is silently not offered |
  | **6,000,000** | `app/edit/preview/preview-client.tsx:9` | **`content` alone**, serialised | the preview shows `This draft contains a field that needs attention. Return to the editor to review it.` |
  | **1,500,000** | `app/api/content/route.ts:11` (`PUT /api/content`) | the **whole request body** — `{content, revision, action, autosave}` | **413** `This update is too large.` |

  **The three measure three different subjects**, which is itself part of why they were
  never reconciled. **A recovered draft between the bounds is restorable into the editor
  but unsavable** — it fails **413** on every attempt, **including every autosave**. That
  is real behaviour, not speculation, and it is the defect the decision above answers.

  **What each rejected alternative would have cost**, kept so the decision is legible
  later: lowering the recovery bound to the save cap would have made the editor decline to
  offer a draft it cannot save — a **silent** behaviour change, since an unoffered draft
  says nothing; lowering the preview bound with it would have shown
  `This draft contains a field that needs attention.` for an **oversize** document, a
  preserved sentence used for a cause it does not describe; and preserving all three
  **without** the warning would have left the owner in a 413 loop with no explanation. The
  decision taken is the only one of the four that leaves every preserved sentence
  describing its actual cause and loses nothing silently. **Its cost is one new string**,
  which is exactly what was accepted.
- **[open, OWNER `contract-design` / `u6-http-api` — named, not decided here]** **Is
  `POST /api/content/inspect` a mutation for CSRF purposes?** C1's `ownerSession` scheme
  says *"Mutations additionally require the paired CSRF token as a request header
  (double-submit)"*. The preview frame is a **separate browsing context** and holds no
  in-memory CSRF token, so the answer decides whether the frame can call inspect at all.
  **Position: it is not a mutation** — it writes nothing, and it returns only a
  normalisation of the document the caller itself supplied, so there is no confused-deputy
  read either; the session cookie and the origin check are the appropriate gates.
  **Consequence if ruled the other way** is stated in full in § *The private draft
  preview* → § *Four facts*: the editor becomes the sole inspector, the frame's check
  degrades to a structural one, and **`startPreview` then posts `normalised` instead of
  the form content, superseding the decision recorded in § *The editor's gate***. Every
  sentence is preserved either way; what the fallback costs is the schema check at the
  `postMessage` boundary. **This item remains OPEN and is not decided by this unit.**
- **[DECIDED, site owner, functional-design gate — the browser tool's field-length
  check]** **The check is REMOVED and the rejection becomes asynchronous: the tool stages
  the input, and the backend rejects at save with `issues[]`.** The defect it answers is
  verified from source and pre-existing — the source's flat `value.length <= 10000` is
  looser than the schema for four of the six fields (`name` 100, `role` 200,
  `affiliation` 200, `headline` 240) and ignores `name`'s `.trim().min(1)`, so the tool
  returns a success result for an edit that cannot be saved.

  **Neither replacement is provisioned, and both are out for stated reasons.** **No
  generated runtime validator**: the generated frontend surface this corpus has is
  `openapi-typescript`'s compile-time types
  (`construction/api-client/functional-design/entities.md` § *generated_surface*), which
  cannot enforce a runtime `maxLength`; provisioning a new generated constraint map was
  considered and is **not** taken. **No hand-written cap**, flat or per-field:
  `project.md` § *Forbidden* and FR8.9 prohibit a hand-written client-side validation rule
  outright, so it was never a live option. **The earlier draft's "use the generated
  mirror" position is withdrawn and removed rather than restated** — it was not
  implementable as named, and leaving it on the page would keep offering a route that does
  not exist.

  **The behaviour change, stated plainly: a profile field longer than 10,000 characters is
  now rejected at save rather than synchronously in the browser.** The rejection still
  happens; only where and when it happens changes, and **that is the accepted cost.** The
  full consequence list — six-of-six rather than four-of-six, the success result the model
  still receives, and the quiet autosave path — is in § *The browser tool* → *the
  decision*. **It contradicts FR8.8's "validates field names and lengths" and is recorded
  as a requirements amendment**, here and in `traceability.json`'s FR8.8 row.
- **[DECIDED, site owner, functional-design gate — `untrustedContentHint`]** **Flipped
  from the source's `false` to `true`.** The tool is **model-driven** and the project
  brief treats model output as **untrusted data**, so the source's declaration says the
  opposite of the brief. **It was not a vulnerability as it stood** — `execute` validates
  the key set and the types, `additionalProperties: false` bounds the shape, and Python
  re-validates authoritatively (FR4.3, BR3.1) — and the flip **changes no behaviour and
  costs nothing**. It is recorded rather than made silently because it is a visible
  attribute of a tool the brief requires to be preserved. **`readOnlyHint: false` and
  every other field of the registration are unchanged.**
- **[CORRECTION, this iteration — review finding R-01/R-02/R-07]** An earlier draft of
  § *The private draft preview* removed the preview's validation, reasoning that *"the
  backend validated it at save"*. **The premise is false for the only case the preview
  serves** — FR8.6 and the section's own first line both state that the preview renders
  the **unsaved** draft — and removing the check also deleted two pieces of product copy
  and left the `postMessage` boundary with no defined failure behaviour. **The validation
  is routed to `POST /api/content/inspect` rather than restored to the browser**: both
  source parse sites keep their sentences, no schema mirror is hand-written, `zod` still
  leaves the frontend, and every message the frame can receive now has a specified
  outcome. Full reasoning in § *The private draft preview*.
- **[CORRECTION, this iteration — review finding R-03/R-04]** An earlier draft drew the
  save machine **flat**, which made `Uploading`, `Conflicted` and `Paused` mutually
  exclusive and returned `Uploading --> Idle` unconditionally — clearing BR8.8's pause
  when an upload settled and arming autosave over a recovered draft. **The machine is
  redrawn as five orthogonal regions** with an explicit arming predicate, and explicit
  save is given its edges and its refusal table. **One suspension the earlier draft
  missed entirely is now recorded**: `editor-workflow.ts:66` pauses autosave after a
  failed write, not only after a restore. FR8.2 does not name it; it is preserved under
  the parity rule and flagged for the U1 fixtures. **Its scope is narrowed in this
  iteration** — a validation rejection is not a failed write, per R-11 below.
- **[CORRECTION, this iteration — review finding R-12]** The previous draft's suspension
  predicate ended `… and Write = Idle`, and `suspensionBegan` was defined as that
  predicate becoming false — so from `Armed` the predicate was false by its own last
  conjunct, `suspensionBegan` fired the instant the timer armed, and **autosave never
  fired at all**. The predicate is now `unsuspended`, a boolean over the **four suspension
  regions only**; `Write = Idle` and dirtiness are carried by the arming edge;
  `suspensionBegan` is the falsification of `unsuspended`. Every other mention derives
  from that one statement, including the `Uploads` region's line, which previously said
  "the other four regions" and contradicted the predicate it referred to.
- **[CORRECTION, this iteration — review finding R-13]** The previous draft declared its
  `stateDiagram-v2` block authoritative and drew the five regions as five **sibling
  composites with no `--` divider and no top-level `[*]`** — XOR decomposition, asserting
  exactly the mutual exclusion the prose refutes, and syntactically valid, which is why
  "validated by construction" passed it. **Both repairs the review offered are taken, not
  one**: the five regions are wrapped in one composite separated by mermaid's `--`
  AND-region dividers with a top-level `[*]`, **and** the **TEXT** is named the source of
  truth while the diagram is labelled illustrative. Reasoning in § *The state machine*.
- **[CORRECTION to the review's own validation table, this iteration]** It recorded that
  **no mermaid validator was available** to the lead or the reviewer, and that the diagram
  was therefore read by hand. **One is available**: `npm install mermaid` plus
  `mermaid.parse()` under `jsdom` validates syntax headlessly with no browser, and every
  fenced block in this file — including the named composites nested inside the `--`
  dividers, which is the construction the previous iteration could not check — was
  validated that way before being written. **Rendering still needs a browser** (layout
  calls `getBBox()`), and a syntax check would not have caught R-13 in any case, because
  that defect was semantic. Recorded because the unavailability of a validator was part of
  the previous iteration's reasoning for not attempting AND-composition.
- **[CORRECTION, this iteration — review finding R-14]** The frame's verdict-reuse rule
  was not restricted to requests that produced a verdict, so `Reload preview` after a
  `503` or a network failure re-posted an identical payload, matched the cache and issued
  **no request** — disabling the one recovery affordance the design relies on, at exactly
  the failure it relies on it for. **Reuse is now restricted to payloads whose inspect
  returned a `200` or a `400`**, and a reload after a failed or aborted inspect always
  re-issues. § *The frame*, step 2.
- **[CORRECTION, this iteration — review finding R-15]** Both preview gates discarded
  `recoverable` and justified it from the **uncorrected** source, which FR8.3.3 corrects
  for the enumerated-value class. **The decision is now stated once for both gates**, in
  § *What BOTH preview gates do with `issues[]`, stated once*, argued against FR8.3.3
  rather than against the source, together with why the two gates still differ in outcome.
  Step 3's "defaults applied" rationale is narrowed to the success path, which is all it
  ever supported.
- **[CORRECTION, this iteration — review finding R-11]** Moving `manualSave`'s client
  pre-flight parse to the backend's `issues[]` would, under a single `saveRejected` event,
  have made **every mistyped field pause autosave** — a suspension the source never had,
  because its pre-flight returned **before dispatching**. The event is split into
  `saveInvalid` (a `400` with `issues[]`; `Write` only) and `saveFailed` (everything else;
  `Write` and `Pause`). The preserved sentence
  `Check these fields before saving. Your edits are kept in this browser.` **now has its
  trigger stated in this document**, which is its authoritative home. § *A validation
  rejection is not a failed write*.
- **[CORRECTION, this iteration — review findings R-16 / R-17 / R-18 / R-19]**
  `latestLoaded` was defined only on `Recovery = NoRecovery` and undefined in the other
  four, through a reachable `Scanning`-save-`409` path — it is now specified in **all
  five**, with the local edits always stashed and the outstanding scan or inspect aborted
  (R-16). A **superseded** inspect was double-classified, listed both as raising nothing
  in step 2 and as a watchdog case in step 5; it is removed from step 5, which now carries
  only genuine failures (R-17). § *Assumptions* said *"the five behaviours"* where
  § *The consequence for verification* enumerated **seven**; the count is restated against
  a re-read of that list, which this iteration also grows to **eight** (R-18).
  The CSRF fallback silently reversed `startPreview`'s *"it posts the form content, not
  `normalised`"*; the fallback now says so explicitly and states what the frame renders
  under it (R-19). **The CSRF question itself remains open, owned by `contract-design` /
  `u6-http-api`.**
- **[CORRECTION, this iteration — review finding R-10]** The conflict flow quoted the
  **server's** 409 sentence and called it *"rendered exactly as returned"*. **Two
  sentences exist and the server's is never displayed**: `editor-workflow.ts:59` throws
  its own literal before the body's `error` field is read. Both are product copy, both
  port character-exact, and § *The conflict flow* now names the owner of each and which
  one the owner sees.
- **[assumption, this unit]** The frame's inspect **coalescing** rules — at most one
  request in flight, a superseded request aborted, an identical payload reusing a verdict
  it actually received — are **new mechanism with no source counterpart**, because the
  source's check is synchronous. They change no rendered output; they bound the request
  count. **If the U1 fixtures show the parent re-sending more often than this document
  expects, the coalescing rules absorb it and nothing else in this specification changes.**
- **[assumption, this unit]** **Aborting the outstanding scan or inspect when
  `latestLoaded` is consumed** (§ *`latestLoaded` in every `Recovery` state*) is likewise
  **new mechanism with no source counterpart**. It exists to close a race the source has
  and this document must not inherit: a verdict arriving after the stash would overwrite
  it and destroy the owner's local edits. It changes no rendered output in any sequence
  where the race does not occur.
- **[assumption, this unit]** The **1,500 ms** interval is taken as the source's value
  and is **parity-fixed**, not rule-bearing. If the recorded source fixtures (U1) show a
  different interval, the number changes and **nothing in this adjudication changes with
  it** — the argument is about what the interval decides, not about its value.
- **[assumption, this unit]** The per-tab storage key is unique to the **tab** and not
  to the browser, origin or user. FR8.3 requires that *"a second tab opened cleanly never
  clears another tab's unfinished work"*, which fixes the property; the mechanism is the
  source's and is ported unchanged.
- **[assumption, this unit]** `NFR7` is treated as this unit's upstream requirement. It
  is **not** in `inception/units-generation/traceability.json`, which enumerates no
  NFRs, but `unit-of-work.md` § *U9* states
  **"Realises. FR8.1–FR8.2, FR8.3.4, FR8.4–FR8.8, and NFR7."**
- **[note]** **FR8.3, FR8.3.1, FR8.3.2 and FR8.3.3 are assigned to U4**, not to this
  unit; only **FR8.3.4** (restoring pauses autosave) is this unit's. The recovery flow is
  described here in full because this unit **executes** it, but the classification rule
  is `u4-content-core`'s. **FR8.9** is `u7-api-client`'s.
- **[note]** This unit produces **no `entities.md` and no `rules.md`**, and that is a
  property of the unit rather than of the packaging: `OwnerEditor` owns no persisted
  entity and authors no business rule. The three rules that govern it — BR8.6, BR8.7,
  BR8.8 — are owned by `OwnerEditor` but **declared once**, in
  `construction/functional-design/rules.md`.

# Sources

- `construction/functional-design/frontend-components.md` § *U9 — owner-editor*, § *The
  recovery flow — three states, not two*, § *Client-side validation*, § *The browser
  tool*, § *Assumptions & Open Questions* — **extended and scoped here, not
  contradicted**, except for the one inverted conditional recorded above as a
  correction.
- `construction/functional-design/rules.md` § `OwnerEditor` — **BR8.6, BR8.7, BR8.8**,
  which are owned by this unit's component and declared there; § `ContentAuthority`
  BR8.1–BR8.5 (the classification, owned by `u4-content-core`), BR4.3–BR4.5, BR4.7,
  BR4.20 (the character cap); § `RevisionLedger` BR5.7 (retention); § `HttpApi` BR10.7
  (the conflict sentence as product copy), BR10.12 (autosave legal only with a draft
  action); § `MediaDelivery` BR7.4 (visibility is a scan over the **published**
  document); § *Assumptions & Open Questions* (the state-machine item and its Playwright
  consequence).
- `inception/requirements-analysis/requirements.md` FR8.1–FR8.8, FR2.4, FR2.6, FR4.6,
  NFR7; and its § *Assumptions & Open Questions*, which carries the same open item
  assigned to `domain-design`.
- `inception/domain-design/components.md` § `OwnerEditor` — the behaviour paragraph,
  which already names the third recovery state;
  `inception/domain-design/decisions.md` **ADR-006** (the classification is a backend
  rule; *"testable in Python … without a browser"*; the unreachable-backend risk),
  **ADR-005** (why the frontend is two components plus a client).
- `inception/contract-design/contract-summary.md` § C1 — `GET /api/content` backing the
  private draft preview (R-02), `POST /api/content/inspect`, the 409 description; and
  § *Open questions*, which carries this item as *"If it does, part of it crosses into
  C1 as an operation"*.
- `inception/units-generation/unit-of-work.md` § *U9 — owner-editor* — the boundary, the
  constraint naming this open question, and `Realises: FR8.1–FR8.2, FR8.3.4,
  FR8.4–FR8.8, NFR7`.
- `aidlc/spaces/default/memory/team.md` § *Testing Posture* — the Playwright condition,
  verbatim; § *Code Style* → *TypeScript / React* (the file-as-unit rule).
  `aidlc/spaces/default/memory/project.md` §§ *Forbidden* (no application logic in the
  frontend; no hand-written client-side validation rule or type mirror), *Mandated*
  (preserve the full owner editor and the existing WebMCP `stage_academic_profile`
  browser tool).
- `WORKING-RECORD.md` §§ 2 (D9, D11, D20), 3 (hazards FR8.3, FR10.1), 9 (the
  state-machine item, its Playwright consequence, and the unassigned
  6,000,000-versus-1,500,000 latent defect).
- **`scratchpad/webmcp-tool-verified.md`** — the browser-tool section is taken from this
  write-up, which reads the registration and `execute` out of
  `madhavi-tripathi/app/edit/editor.tsx:81` and `app/content.ts:5`. The registration
  table, the six `execute` steps, the three product-copy literals, the silent-failure
  behaviour and the four-of-six cap mismatch are **verified from source**, not inferred
  from the component inventory.
- **The source files themselves, read directly for this iteration** — every line
  reference in §§ *The state machine*, *The conflict flow* and *The private draft
  preview* is quoted from one of them, not inferred:
  `madhavi-tripathi/app/edit/editor-workflow.ts` (the whole `useDraftWorkflow` hook —
  `:15` the recovery bound, `:53` the save guard that refuses an explicit save, `:59` the
  frontend 409 literal, `:62` the accepted-write effects, `:66` the pause-on-any-failure
  `catch`, `:69` the arming predicate, `:71` `chooseRecovery`, `:72`–`:74` `reloadLatest`
  and its stashed offer);
  `madhavi-tripathi/app/edit/preview/preview-client.tsx:9` (the 6,000,000 bound, the
  parse, the three-part message guard, the `academic-preview-rendered` handshake, and the
  sentence `This draft contains a field that needs attention. Return to the editor to
  review it.`);
  `madhavi-tripathi/app/edit/draft-preview.tsx` (the parent side of the protocol, the
  ten-second watchdog and its sentence `The preview is taking longer than expected. Your
  draft is still in the editor.`, and the `Reload preview` control);
  `madhavi-tripathi/app/edit/preview/page.tsx` (the route's own sign-in copy);
  `madhavi-tripathi/app/edit/editor.tsx:62`, `:74`, `:75` (`select`, `manualSave` and
  the preview gate `startPreview` with `Check the highlighted fields before opening the
  preview.`);
  `madhavi-tripathi/app/api/content/route.ts:11`, `:15`, `:18`, `:20` (the 1,500,000 cap
  and `This update is too large.`, the 400 issues body, the **server's** 409 sentence,
  the 503 sentence).
- **`scratchpad/source-boot-verified.md`** — the source application was **booted and
  probed**, which resolves the standing assumption that it runs. Two findings bear on
  this unit: the unauthenticated error body was captured verbatim as
  `{"error":"Please sign in with the website owner’s account."}` with **U+2019**,
  confirming BR10.8 against a live response rather than a reading; and the three-part
  revision ordering (BR5.1) was confirmed **against data**, which is what the conflict
  flow's history list renders.
