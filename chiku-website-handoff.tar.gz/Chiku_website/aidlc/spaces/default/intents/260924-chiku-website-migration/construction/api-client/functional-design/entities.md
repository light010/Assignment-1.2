# Entities — U7 `api-client`

**Upstream:** `inception/units-generation/unit-of-work.md`,
`inception/domain-design/components.md`,
`inception/contract-design/contract-summary.md`,
`inception/requirements-analysis/requirements.md`.

**This unit owns no entity and defines no type of its own.** Every type it exposes
is **generated** from the backend's OpenAPI document, committed, and regenerated at
the merge gate. That is the whole point of the unit: it is the single crossing
point of the language boundary, and a hand-written type here would be a second
definition that can drift from the authoritative one.

```yaml
entities: []
# This unit defines no type of its own. Every type it exposes is GENERATED from
# the backend's OpenAPI document, committed, and regenerated at the merge gate.
# A hand-written type here would be a second definition of an authoritative
# shape, and a second definition can drift. The generated surface is described
# below as a derived artifact rather than as an entity, because its source of
# truth is U6's schema, not this file.

generated_surface:
  - name: OperationTypes
    generated_from: /openapi.json
    owner_of_source: U6 http-api
    description: >
      Request and response types for every operation on the HTTP surface, plus
      the error envelope and its issues array.
    regeneration: >
      At the merge gate. The gate FAILS if the committed output differs from a
      fresh generation, which is what makes the language boundary type-checked
      rather than asserted (BR27.4).
    constraints:
      - Committed to the repository, never generated only at build time.
      - A backend field rename surfaces as a tsc --noEmit failure with a file and
        a line, rather than as a runtime error in the editor several units later.
      - The ONLY place in the frontend where a backend payload shape or a
        validation rule may be declared. The regeneration diff above proves this
        file is current; it cannot see a second definition elsewhere, so BR27.5
        supplies the separate gate check that does.

held_state:
  - name: csrfToken
    type: string
    lifetime: one session
    storage: in memory only
    required: true
    description: >
      Received from the sign-in response and attached to every mutating request
      (BR27.3). Never written to localStorage, sessionStorage, or any cookie this
      unit sets.
    constraints:
      - This is the only state the unit holds. No cache, no retry queue, no
        derived copy of the content document.

relationships: []
```

## Generated surface

| Generated from | Shape | Regenerated |
|---|---|---|
| `/openapi.json` (owned by U6) | Request and response types for every operation | At the merge gate. **The gate fails if the committed output is dirty** |

A backend field rename therefore fails `tsc --noEmit` with a file and a line,
rather than surfacing as a runtime error in the editor several units later. That
is what makes the language boundary type-checked rather than asserted.

**What the dirty-diff check does not cover.** Regeneration compares this file
against a fresh generation of *itself*, so it detects drift in the generated file
and nothing else. A hand-written type or validation rule in any other frontend
file never touches it and passes unseen — which is precisely the second
definition BR8.9 forbids. BR27.5 is the separate check that closes that half;
without it, BR8.9's enforcement would be a claim rather than a command.

## Not entities, but state this unit holds

| Thing | Lifetime | Note |
|---|---|---|
| CSRF token | One session | Received from the sign-in response, attached to every mutation. Held in memory only, never in storage |

It holds nothing else. No cache, no retry queue, no derived copy of the content
document.

## Assumptions & Open Questions

- **[assumption]** Generating types from the OpenAPI document captures enough of
  the contract to be useful. It captures **shapes**, not which validation failures
  are survivable — which is exactly why that classification is a backend rule
  (ADR-006) rather than something the generated types could have expressed.
