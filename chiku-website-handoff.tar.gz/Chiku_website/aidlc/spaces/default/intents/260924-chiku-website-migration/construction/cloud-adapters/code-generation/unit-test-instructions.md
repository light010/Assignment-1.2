# Unit Test Instructions — U11 `cloud-adapters`

## Framework and configuration

`pytest` 9.1.1 with `pytest-cov` 7.0.0 and `anyio` 4.12.0, resolved by `uv` from
`chiku-website/backend/pyproject.toml`. **No new framework and no new dependency.** No
cloud SDK is installed and none is needed: the adapters are written against structural
`Protocol`s and the tests supply an in-process fake for each service.

`tests/cloud/` needs an `__init__.py` package marker for the same reason
`tests/conformance/` does — without it, pytest's prepend import mode gives two
`conftest` modules the same top-level name and the pre-existing suites' `from conftest
import meta` resolves to the wrong file.

## The exact command to run THIS unit's tests

Run from `chiku-website/backend/`:

```
uv run pytest tests/cloud -q
```

The conformance suites run the cloud adapters too, once `tests/cloud/conftest.py`
registers them. To run this unit's own tests plus the whole contract over every
implementation:

```
uv run pytest tests/cloud tests/conformance -q
```

With the coverage floors this unit is measured against:

```
uv run pytest tests/cloud tests/conformance --cov --cov-branch -q
uv run coverage report --fail-under=80
uv run coverage report --fail-under=100 --include="app/cloud/content_firestore.py,app/content/store_sqlite.py,app/auth/store_sqlite.py"
```

Runner readiness is verified before the first test step: `uv run pytest --version` must
succeed. It does today — 365 tests currently execute.

## Expected coverage

- **80% branch coverage** over `chiku-website/backend/`.
- **100% branch coverage** on `app/cloud/content_firestore.py`, which joins
  `app/content/store_sqlite.py` and `app/auth/store_sqlite.py` as a hazard-register
  module: it is the combined write, and the substitution ordering in particular is a
  branch whose outcome the design had to specify precisely *because* a 100% floor cannot
  be met on an unspecified branch.

Neither floor may be relaxed, lowered, or disabled — not by editing a threshold, adding
an `omit`, or narrowing an `--include`. A shortfall is reported as a shortfall.

## Test scope — Standard strategy, 5–8 tests per component

### The shared conformance suite, third and fourth implementations

Registering the cloud adapters into `tests/conformance` runs the **entire existing
contract** against them with no new assertions written. That is the whole argument for
having a port, and it is the cheapest evidence in this unit. Every assertion already
there applies: seed-on-empty-and-write-nothing, byte-identical round-trip,
stale-CAS-with-no-side-effect, the three-part listing order, independent retention counts,
baseline survival, `touch` leaving the absolute bound alone, concurrent
`create_if_absent`, revoked-fails-next-read, exact `get_range`, stable entity tag,
idempotent `delete`.

### `tests/cloud/test_transaction_ordering.py` — the R-05 regression

1. **Every read precedes every write** inside the combined write's transaction. The fake
   raises on a read issued after a write; this test asserts a real save does not trigger
   it, **including a save that prunes** — which, by the design's own invariant, is every
   save once the cap is reached.
2. **Removing the split fails.** An adapter variant that reads survivors after writing
   must raise. A test that only checks the happy path cannot tell a correct ordering from
   a fake that permits anything.
3. **The blob writes land before the transaction opens** (BR31.2), asserted by ordering
   the recorded operations — a failed transaction must leave reclaimable orphan garbage,
   never a dangling reference.
4. **The survivor read is one unfiltered `revision DESC` read**, not one filtered query
   per action. A filtered query needs a composite index nothing declares, and an
   undeclared index fails at runtime (BR31.4) — so this asserts the shape, not just the
   result.

### `tests/cloud/test_blob_substitution.py` — the R-01 regression

5. A `ContentRevision.content` above the threshold **is substituted**. This is the shape
   that cannot fit in one Firestore document, and the original algorithm substituted the
   content document instead — resolving the size conflict for the wrong object.
6. `draft` and `published` are checked and substituted **independently, per field**; a
   document whose fields each fit but whose **sum** exceeds the limit is substituted
   further until it fits.
7. The largest-first ordering is **deterministic**, with `draft` before `published` on a
   tie. Asserted on which blobs exist, not merely that the save succeeded — a branch
   whose outcome is unspecified cannot carry a 100% floor.
8. **Reads reverse substitution transparently**: a caller cannot tell a substituted field
   from an inline one. Both paths are covered, which is what makes the substitution
   invisible rather than merely intended.

## Mocking and stubbing

**The fakes are not mocks, and this distinction is the unit's main evidence.** A mock
records calls and returns what it was told to. These fakes **enforce the two documented
service constraints**:

- a read issued after a write inside a transaction **raises**;
- a document over 1,048,576 bytes **raises**.

Both were Critical review findings. A permissive fake makes both regressions invisible
while every test stays green, so a fake that does not enforce them is worse than no test.

No network call is made anywhere in this suite, in either direction.

## Test data management

No fixture files and no recorded fixtures — this unit has no HTTP surface and the source
app never ran on Google Cloud, so no oracle exists or could be made. Each test constructs
its fake storage and discards it.

## What these tests cannot prove

Stated here because BR31.5 requires the unverified status to be impossible to miss.

These tests prove the adapters satisfy **the port's contract as the suite expresses it**,
and that they obey **two documented Firestore constraints as the fake models them**. They
do **not** prove the adapters work against Firestore or Cloud Storage: nothing in this
workflow executes them against either service, and every statement about service
behaviour comes from published documentation. The structural `Protocol`s are a claim
about an API that has not been contacted.

Verification against the real services requires provisioning, which this workflow does
not do.
