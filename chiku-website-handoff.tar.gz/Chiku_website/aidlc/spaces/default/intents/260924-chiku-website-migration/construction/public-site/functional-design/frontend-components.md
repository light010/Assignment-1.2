# Frontend Components — U8 `public-site`

**Upstream:** `inception/domain-design/components.md`,
`inception/requirements-analysis/requirements.md`,
`inception/contract-design/contract-summary.md`,
`inception/units-generation/unit-of-work.md`,
`construction/functional-design/frontend-components.md` (the workflow-level view,
which this scopes to one unit rather than contradicting).

## Component inventory

| Component | State | Note |
|---|---|---|
| `app/layout.tsx` | Byte-identical | **The root layout — mandatory in App Router, and the CSS entry point.** It is the only file that imports all 9 CSS files; it declares the static `metadata` fallback (`title`, `description`, `icons` → `/favicon.svg`); and it renders `<html lang="en" suppressHydrationWarning>`, `<head><meta name="color-scheme" content="light dark"/></head>` and the `ColorModeProvider` wrapper. Nothing in it is environment-dependent, so it crosses unchanged |
| `public/` — `favicon.svg`, `file.svg`, `globe.svg`, `window.svg`, `fonts/inter-latin-variable.woff2`, `images/academic-flow.webp` | Byte-identical | **Static assets, carried by this unit.** `favicon.svg` is referenced by `layout.tsx`'s `icons`; the Inter woff2 is self-hosted, so losing it silently falls back to a system font — a visual parity break no DOM diff detects |
| `app/page.tsx` | **Modified** | Rewired to the client. Goes on `PORTED-MODIFIED.md`. **Also holds the FR1.8 failure render and its copy** — see below |
| `app/site.tsx` (`AcademicSite`) | Byte-identical | Already takes `content`, `canEdit`, `preview` as props |
| `achievements.tsx`, `publications.tsx`, `research-section.tsx`, `updates.tsx` | Byte-identical | Section renderers |
| `scene.tsx`, `nano-renderer.ts`, `scene-content.ts`, `scene-performance.ts` | Byte-identical | The 3D illustration |
| `responsive-image.tsx`, `use-section-carousel.ts`, `publication-utils.ts`, `color-mode.tsx` | Byte-identical | Helpers |
| `site-metadata.ts` | **Modified** | `siteOrigin` becomes configuration |
| `robots.ts`, `sitemap.ts` | **Modified** | Rewired |
| 9 CSS files | Byte-identical | `[shared]` 1,124 lines, all imported by `layout.tsx` |
| `lib/utils.ts` (the `cn` helper) | Byte-identical | `[shared]` **Outside `components/ui/`.** Every vendored component imports it as `@/lib/utils`; omitting it breaks all twelve |
| `postcss.config.mjs`, `components.json` | Byte-identical | `[shared]` Build and generator configuration the vendored set depends on. There is no `tailwind.config` — this is Tailwind v4, configured in CSS |
| `tsconfig.json` | Byte-identical | `[shared]` **Its `@/*` path alias is the only thing that makes `@/lib/utils` resolve** — for all twelve vendored components, and for any other `@/`-prefixed import in the tree. Byte-identical because the port preserves the source's layout beneath the frontend root; if it is edited it goes on `PORTED-MODIFIED.md` like any other ported file. The gate's per-file diff targets `app/**` and does not reach it |
| `package.json` | **Modified** | `[shared]` Carries the third-party dependencies the twelve import — the Radix primitives, `clsx`, `tailwind-merge`, `class-variance-authority`, `lucide-react`, `embla-carousel`, `@tailwindcss/postcss`. Omitting it fails `pnpm install --frozen-lockfile` long before `tsc` runs. **Modified with certainty**: the package name changes and `openapi-typescript` is added, since `team.md` makes the generated boundary types a gate check. Goes on `PORTED-MODIFIED.md` |
| **10** vendored `components/ui/*` | Byte-identical | `[shared]` The eleven directly-imported components **less `carousel.tsx`**, which is Modified and has its own row. **Carried by this unit**, consumed by `owner-editor`. Their MIT notice travels with them |
| `components/ui/button.tsx` | Byte-identical | `[shared]` The 12th vendored component; transitively required (see below) |
| `components/ui/carousel.tsx` | **Modified** | `[shared]` The 11th directly-imported vendored component, not a 13th. `aria-disabled` replaces native `disabled` at `:194` and `:224`. Goes on `PORTED-MODIFIED.md` **and** on the vendored-divergence record |

**`[shared]` marks a row that `owner-editor` also consumes, and whose owning unit
is conditional.** Under the current twelve-unit topology U8 carries every one of
them (functional-spec § *What changes* C6). If `delivery-planning` chooses the
other remedy and lifts the shared set into a 13th unit, **exactly these rows
relocate** and nothing else in this table does: everything under `app/` and
`public/` stays with U8 under either outcome. The marker exists so a reader can
tell which parts of this inventory depend on an answer this unit does not own.

**Twelve, not eleven — `button.tsx` crosses transitively.** Eleven are imported
directly by `app/`: `alert-dialog`, `carousel`, `collapsible`, `dialog`,
`progress`, `radio-group`, `select`, `slider`, `switch`, `tabs`, `toggle`. A
twelfth, **`button.tsx`**, is imported by four of those eleven —
`alert-dialog:7`, `select:6`, `dialog:10`, `carousel:8` — and by
`alert-dialog` again for `buttonVariants`. It appears in no `app/` import, which
is why a direct-import count misses it.

Three consequences, none of them cosmetic:

- **It is not optional.** Omitting it breaks `tsc --noEmit` for four carried
  components and therefore breaks `owner-editor`, which consumes them.
- **The MIT notice obligation covers it**, because the notice travels with the
  files it covers and `button.tsx` is now one of them.
- **It sits under the one modified vendored file.** `carousel.tsx` is what C5
  changes, and it imports `Button` — so the `aria-disabled` fix must be checked
  against `button.tsx`'s own props before assuming the change is local to the
  carousel.

**The arithmetic, since the table splits the eleven.** Ten of the eleven are
byte-identical and share one row; `carousel.tsx` is the eleventh and is Modified,
so it has its own. 10 + `carousel.tsx` + `button.tsx` = **12**.

**49 unreachable vendored components (6,139 lines) do not cross.** That figure was
already right and is what exposed the count: 61 vendored files minus 49 unreachable
is 12, not 11, so the inventory row and the exclusion line disagreed with each
other. Verified by enumeration against `madhavi-tripathi/components/ui/`
(61 `.tsx` files) on 2026-09-25.

**The transitive closure was computed, not assumed.** It was closed by walking the
imports of the eleven directly-imported components, which yielded exactly one
addition, `button.tsx`, and no further level. The closure also reaches **outside**
`components/ui/`: `lib/utils.ts` is imported by every vendored component as
`@/lib/utils`, so the shared set is not "the twelve" but the twelve plus that
helper plus the build configuration above. The earlier count was wrong precisely
because it stopped at direct `app/` imports; stating the closure was computed is
what stops the next reader repeating that.

**The closure of source imports is not the closure of what makes them resolve,
and that is where it previously stopped.** Every one of the twelve imports
`@/lib/utils`, which resolves only through `tsconfig.json`'s `@/*` alias, and
every one imports third-party packages that resolve only through `package.json`.
Neither is a source file, so walking imports never reaches them, and a shared set
missing either does not build. Both now have rows, both are `[shared]`, and both
are files `owner-editor` must write into as well — **the same collision shape C6
describes**, carried by the same open item and the same owner.

**Who writes the shared dependency entries.** Under the current topology U8 does:
it creates `tsconfig.json` and `package.json` and enters the dependencies of the
twelve and of `app/`. `owner-editor` then **adds only the entries its own surface
needs and removes none** — an additive rule, because a shared manifest is the one
file where two units editing in parallel produces a silent loss rather than a
merge conflict. If `delivery-planning` lifts the shared set into a 13th unit, the
two manifests relocate with the other `[shared]` rows and that unit inherits this
rule; both U8 and U9 then become additive consumers of it.

**Two install-configuration files sit one step further out and are *not* claimed
here.** `pnpm-workspace.yaml` and `.npmrc` govern how those dependencies install,
and `team.md` § *Deployment* already decides both — `minimumReleaseAge: 10080` is
carried forward, `.npmrc`'s `audit=false` line is not. They are consumed by the
Dockerfile's `pnpm install --frozen-lockfile`, which makes **U10 `containers`**
their natural owner, not this unit. Recorded because no inventory currently names
them and a decision `team.md` has made needs a file to land in.

**This supersedes the workflow-level `construction/functional-design/frontend-components.md`,**
which still says eleven. That file is frozen under U1's terminal receipt and is
recorded as a gate item rather than edited here; where the two disagree, this unit
is current and the arithmetic above is why.

## Props and state

No component in this unit holds application state. `AcademicSite` receives the
content document as a prop and derives everything it renders from it. Local state
is presentation only: menu open, active section, scroll progress, the copy-email
confirmation, and the publication browser's filter state, which is mirrored into
the URL exactly as today.

## The one behavioural change

Native `disabled` on a carousel control removes it from the tab order, so reaching
the last item drops focus to `<body>` and arrow-key navigation stops. Replace with
a control that stays focusable and carries `aria-disabled`, guarding the activation
handler. Focus is retained; nothing moves visually.

## API integration

Exactly one: `GET /api/public/content`, server-side, unauthenticated, no
credentials. Plus one post-hydration session check for the edit affordance. No
component in this unit calls anything else.

## Assumptions & Open Questions

- **[resolved]** *"The 11 vendored components are exactly the imported set. A missed
  import surfaces at `tsc --noEmit`, cheaply."* Withdrawn: the assumption was wrong
  and the set is twelve. It was resolved by enumeration rather than by waiting for
  the type checker, which matters because the cost of a missed vendored file is not
  only a build error — it is an unmet MIT attribution obligation, and no compiler
  reports that one.
- **[resolved]** *"Whether the carousel fix can be made without touching the
  vendored file's public API."* **It cannot.** The native `disabled` props are
  inside the vendored file at `components/ui/carousel.tsx:194`
  (`disabled={!canScrollPrev}`) and `:224` (`disabled={!canScrollNext}`), and there
  is no app-level wrapper to intercept them — `app/site.tsx` and
  `app/use-section-carousel.ts` contain no `disabled` at all. So C5 modifies a
  vendored file, necessarily.

  Two obligations follow, and the second is the one that is easy to lose:
  `carousel.tsx` goes on `PORTED-MODIFIED.md` like any modified ported file; and
  its **divergence from upstream is recorded separately**, because a later
  dependency upgrade that overwrites the vendored tree would silently revert an
  accessibility fix with nothing failing. `team.md` § *Code Style* requires that
  record; this is the first file to need it.

  Verified against the source on 2026-09-25 rather than left as a judgement call.
