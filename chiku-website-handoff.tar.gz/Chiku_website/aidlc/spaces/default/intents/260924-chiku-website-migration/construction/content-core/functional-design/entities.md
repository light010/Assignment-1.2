# Entities — U4 `content-core`

**Unit:** `u4-content-core` · **Kind:** `library` · **Components:**
`ContentAuthority`, `RevisionLedger`

**Upstream:** `construction/functional-design/entities.md` §§ ENT-4, ENT-5,
`inception/domain-design/components.md` (entity ownership),
`inception/requirements-analysis/requirements.md` (FR4.x, FR5.x, FR9.1, FR9.2,
FR9.3, FR9.4),
`inception/contract-design/contract-summary.md` § C2,
`codekb/Chiku_website/api-documentation.md` § *Content schema — every field and
constraint*, `codekb/Chiku_website/code-quality-assessment.md` § *Hazard 3*,
and the source files `app/content.ts`, `app/site-copy.ts`, `app/scene-content.ts`,
`app/research-identity.ts`.

> **Path note — `construction/functional-design/` is NOT a unit directory.** It is
> the **workflow-level** rule and entity corpus, written before the per-unit split
> and shared by every unit; the per-unit convention is
> `construction/<unit-name>/functional-design/...`, which has a unit segment this
> path lacks. The collision is real enough that a reviewer's scope tooling
> classifies it as a sibling unit and refuses to open it, so it is named here as a
> **shared cross-unit input** rather than an upstream artifact of any one unit.
> It holds the 120 `BR3.x`–`BR10.x` ids this unit carries forward verbatim.

## How to read this document

This is the complete field-level specification of the two entities this unit owns.
It is written so that **a developer implements from it without opening
`madhavi-tripathi/`.** Every maximum length, regular expression, enumerated value,
numeric bound and default is quoted exactly, not paraphrased.

| ID | Entity | Owning component | Nature |
|---|---|---|---|
| ENT-4 | `ContentDocument` | `ContentAuthority` | **Ported** — every constraint below is inherited, not chosen |
| ENT-5 | `ContentRevision` | `RevisionLedger` (written by `ContentAuthority`) | **Ported** |

**ENT-4 is the hardest entity in the system**, and it takes most of this document.
It carries **two warning boxes, W-1 and W-2**, reproduced verbatim from the
workflow-level specification: they describe defaults that a type-correct model
declaration expresses **wrongly**, silently, with nothing failing.

**Nothing here is designed.** Every constraint is preserved behaviour. Where the
source is asymmetric, inconsistent or arguably wrong, **it is reproduced rather
than tidied**, and the reason is stated so a later reader cannot mistake the
asymmetry for a transcription error.

---

## The wire format is frozen — read this before writing any model

The JSON wire format is **`camelCase`, and it is inherited rather than chosen**
(FR9.4). Two independent reasons, either of which alone is decisive:

1. The ported frontend components read this shape directly and unchanged —
   `site.tsx` reads `c.scholarHighlights`, `c.publications[].featured`, `focalX` /
   `focalY`; the editor reads the same shape. A `snake_case` wire format turns
   "components port largely unchanged" into a rename sweep that voids the
   file-as-unit parity rule for every file it touches.
2. **The persisted content *is* this JSON.** The stored `draft` and `published`
   columns hold exactly these keys, and they are re-parsed through the same schema
   on every read. A wire rename is therefore also a data migration.

Python identifiers are `snake_case` everywhere, **including storage columns**.
Conversion happens in **exactly one place**, shared with every other model in the
system. **Field names below are given in their `camelCase` wire spelling**,
because that is the frozen, externally visible name.

**The top-level read shape is confirmed by execution, not inferred.** An
authenticated read of the running source returned exactly `draft`, `published`,
`revision`, `updatedAt`, `publishedAt`, `hasUnpublishedChanges` — matching contract
C2.

---

## Source of truth — the two entities

```yaml
source_of_truth: entities
stage: functional-design
unit: u4-content-core
kind: library
kind_note: >
  U4 content-core is a LIBRARY, not a service. U6 http-api is the only unit
  declaring service - there is exactly one deployed Python executable. This unit is
  embedded in it and is not independently deployable.
authority: >
  This block is the source of truth and governs. The prose below carries the full
  field tables, the verbatim default values and the two warning boxes, and must not
  contradict it. Where a value appears in both, the prose tables carry the
  transcription and this block carries the structure.
components: [ContentAuthority, RevisionLedger]
entity_count: 2
nature_note: >
  Both entities are PORTED. Every constraint is inherited from madhavi-tripathi/ and
  none is chosen here. Asymmetries are reproduced rather than tidied.
wire_format_note: >
  camelCase, frozen, and inherited rather than chosen - the persisted content IS this
  JSON, so a rename is also a data migration. Confirmed against the running source.
entities:

  - id: ENT-4
    name: ContentDocument
    owned_by: ContentAuthority
    nature: ported
    cardinality: singleton
    description: >
      The one content document, held in a draft form and a published form, with a
      monotonic revision, two timestamps and the mutation token that guards the
      combined write's side effects. Exactly one ever exists.
    attributes:
      - { name: documentId, type: fixed-singleton, required: true, unique: true, constraints: 'There is one and only one.' }
      - { name: draft, type: Content, required: true, default: 'the seeded document', constraints: 'ALWAYS overwritten by an accepted write - for a publish as well as a draft save.' }
      - { name: published, type: Content, required: true, default: 'the seeded document', constraints: "Changed ONLY when action = 'publish'." }
      - { name: revision, type: integer, required: true, default: 0, min: 0, constraints: 'Monotonic; +1 on EVERY accepted write, drafts as well as publishes. When supplied by a caller as a base revision it must be a safe integer, >= 0, and below the largest safe integer.' }
      - { name: updatedAt, type: instant-iso8601-utc, required: true, default: 'null when no row exists', constraints: 'Set on every accepted write.' }
      - { name: publishedAt, type: instant-iso8601-utc, required: true, default: null, constraints: 'Stays NULL until the first publish - the seeded document is not "published". Changed only on publish.' }
      - { name: lastMutation, type: opaque-token, required: true, constraints: 'The random token stamped by the accepted write that most recently touched this document. NOT a convenience field: it is the ABA guard for the write side effects. See BR4.8-BR4.19.' }
    computed:
      - { name: hasUnpublishedChanges, derivation: 'serialise(draft) != serialise(published)', constraints: 'Computed on every read. NEVER stored; it has no column and is not a flag the write path maintains.' }
    entity_constraints:
      - 'When no document exists the read synthesises {draft: seed, published: seed, revision: 0, updatedAt: null, publishedAt: null, hasUnpublishedChanges: false} and WRITES NOTHING.'
      - 'Every parse of an item - INCLUDING every read out of storage - applies the content-carrying transform in W-1 and W-2.'
      - 'The collection defaulting is asymmetric and must be reproduced: achievements has a default and a max of 60; research, publications, journey and news have NO default and maxima of 100, 500, 100, 100.'
      - 'The sections object has NO default; only its achievements member is optional.'
      - 'A save request body over 1,500,000 CHARACTERS is rejected - characters, not bytes.'
    relationships:
      - { to: ContentRevision, cardinality: '1 : 0..n', direction: 'each revision entry is a past state of this document' }
      - { to: Asset, cardinality: '1 : 0..n', direction: 'an asset is public iff the literal /api/media/<key> appears ANYWHERE in the serialised published document - a substring relation, not a foreign key' }

  - id: ENT-5
    name: ContentRevision
    owned_by: RevisionLedger
    written_by: ContentAuthority
    nature: ported
    cardinality: collection
    description: >
      One past state of the content document - two permanent baselines plus the
      retained normal entries. RevisionLedger owns the entity, its ordering and its
      retention policy but performs NO write.
    attributes:
      - { name: revisionEntryId, type: string, required: true, unique: true, max: 100, pattern: '^[a-zA-Z0-9-]+$', constraints: "For a normal entry, THE WRITE'S MUTATION TOKEN. For the two permanent baselines, the fixed literal ids starting-published and starting-draft. The max and pattern apply when a caller supplies one for lookup." }
      - { name: revision, type: integer, required: true, unique: false, constraints: 'The revision this entry records. NOT unique - a baseline pair and a normal entry can share one.' }
      - { name: action, type: enum, required: true, allowed_values: [draft, publish] }
      - { name: content, type: Content, required: true, constraints: 'The full document AS WRITTEN, read back from the stored draft column rather than taken from the request. See BR4.11.' }
      - { name: createdAt, type: instant-iso8601-utc, required: true, constraints: "For a normal entry, read back from the document's updatedAt so entry and document agree exactly. For a baseline, THE TIME OF CAPTURE - not a guessed original publication date." }
      - { name: baseline, type: boolean, required: true, default: false, constraints: 'True only for the two starting entries. Stored as an integer by the verified adapter and coerced with a truthiness test on read. Baselines are NEVER pruned.' }
    entity_constraints:
      - 'Listing order is revision DESC, then baseline ASC, then action DESC - confirmed against DATA from the running source, not inferred from the query.'
      - 'The listing is capped at 52 = 30 drafts + 20 publishes + 2 baselines, by construction. There is no pagination.'
      - 'Retention keeps the 30 most recent non-baseline drafts and the 20 most recent non-baseline publishes, independently.'
      - 'RevisionLedger owns the policy and performs no write; ContentAuthority applies it inside its one combined write. RevisionLedger store access is READ-ONLY.'
    relationships:
      - { to: ContentDocument, cardinality: '0..n : 1', direction: 'records a past state of' }

entities_referenced_but_not_owned:
  - { id: ENT-6, name: Asset, owner_unit: u5-media, why: 'The asset-visibility rule reads THIS unit published document, but the asset entity and its metadata row are owned by media' }
  - { id: ENT-1, name: OwnerAccount, owner_unit: u3-identity-and-session, why: 'Every write and the owner read are authorised against it; this unit holds no identity' }
```

---

## ENT-4 `ContentDocument` — owned by `ContentAuthority`

Exactly **one** document ever exists — the source stores it as a singleton row.

### ENT-4 envelope

| Field | Type | Required | Default | Constraints |
|---|---|---|---|---|
| `documentId` | fixed singleton | yes | the one document | There is one and only one. |
| `draft` | `Content` | yes | seeded document | The full content document, below. **Always** overwritten by an accepted write, for a publish as well as a draft save. |
| `published` | `Content` | yes | seeded document | The full content document. Changed **only** when `action = 'publish'`. |
| `revision` | integer | yes | `0` | Monotonic. Increments by 1 on **every** accepted write — **drafts as well as publishes**. Must satisfy `Number.isSafeInteger`, `>= 0`, `< Number.MAX_SAFE_INTEGER` when supplied by a caller as a base revision. |
| `updatedAt` | string \| null | yes | `null` when no row exists | ISO-8601 UTC instant, set on every accepted write. |
| `publishedAt` | string \| null | yes | `null` | ISO-8601 UTC instant. **Stays `null` until the first publish** — the seeded document is not "published". Changed only when `action = 'publish'`. |
| `lastMutation` | string \| null | yes | — | The opaque random token stamped by the accepted write that most recently touched this document. Source generates it with `crypto.randomUUID()` (canonical lowercase UUID v4). **Not a convenience field**: it is the ABA guard for the write's side effects — see BR4.8–BR4.19 in `rules.md`. |

**`hasUnpublishedChanges` is computed, never stored.** It is
`serialise(draft) != serialise(published)` — the source computes
`JSON.stringify(draft) !== JSON.stringify(published)`. It appears in the read
response but has no column.

**When no document exists**, the read operation synthesises
`{draft: <seed>, published: <seed>, revision: 0, updatedAt: null, publishedAt: null, hasUnpublishedChanges: false}`
and **writes nothing**.

### ENT-4 shared building blocks

These five definitions are referenced by name throughout the field tables below.

| Name | Exact definition |
|---|---|
| `text` | String, **max 10000** characters. No trim, no refinement. |
| `url` | String, **max 2000** characters, **plus** a refinement that passes if **any** of: (a) the value is empty (`''`); (b) it matches `/^https?:\/\/[^\s]+$/i` — **case-insensitive**; (c) it matches `/^\/api\/media\/[a-zA-Z0-9.-]+$/` — **case-sensitive**. Failure message, verbatim: `Use a full https:// link.` |
| `citationCount` | String, **`.trim()` applied first**, then **max 9** characters, plus a refinement `v === '' \|\| /^\d+$/.test(v)`. **`.default('')`**. Failure message, verbatim: `Use a whole, non-negative citation count, or leave it blank.` |
| `citationDate` | String, **max 10** characters — **no trim** — plus a refinement that passes if the value is empty **or** all three of: `/^\d{4}-\d{2}-\d{2}$/` matches; `Date.parse(v)` is not `NaN`; and `new Date(v).toISOString().slice(0,10) === v`. **`.default('')`**. Failure message, verbatim: `Use a valid snapshot date.` |
| `imageSource` | Object `{src: url, width: integer 1..16000, height: integer 1..16000}`. All three required. `width`/`height` must be **integers**, not merely numbers. |

Two details that are easy to lose and have no compensating signal:

- **The `citationDate` round-trip check is the whole point of that refinement.** It
  rejects `2026-02-30`, which `Date.parse` *accepts* and normalises to March 2. The
  regex alone is insufficient; the ISO round-trip equality is what catches it. An
  equivalent Python implementation must reject a syntactically well-formed but
  non-existent date, and must **not** normalise it.
- **`.trim()` is applied to `citationCount` but NOT to `citationDate`.** These two
  look symmetrical and are not. A leading space in `citationsAsOf` fails; a leading
  space in `citations` is stripped and then validated.

**`.trim()` is a transform, not a check.** Wherever it appears below, the trimmed
value is what is validated *and* what is stored — `z.string().trim().min(1)` trims
first and then tests the trimmed length.

**The `url` media form is more permissive than the media route's key pattern.** The
schema accepts `/api/media/` followed by any run of `[a-zA-Z0-9.-]`, while the
media route only serves keys matching
`^[a-f0-9-]+\.(jpg|png|webp|pdf|mp4|webm|vtt)$`. A document may therefore legally
contain a media URL the media route will 404. This asymmetry exists today;
preserve both patterns as written rather than reconciling them.

### ENT-4 `item` — the shape shared by all five collections

**24 declared fields.** Identical for `achievements`, `research`, `publications`,
`journey` and `news` — there is no per-collection variation of the item shape.

| Field | Type | Required | Default | Constraints |
|---|---|---|---|---|
| `id` | string | yes | — | Max **100** characters. No pattern, no trim, **may be empty**. |
| `title` | string | yes | — | **`.trim()`**, then **min 1** with the verbatim message `Add a title before saving.`, then **max 1000**. |
| `subtitle` | `text` | yes | — | Max 10000. |
| `description` | `text` | yes | — | Max 10000. |
| `year` | string | yes | — | Max **40**. Free text — **not** a number and not a date. |
| `image` | `url` | yes | — | Max 2000 + the `url` refinement. |
| `imageAlt` | `text` | yes | — | Max 10000. |
| `imageSources` | array of `imageSource` | no | **`[]`** | **Max 4** elements. |
| `focalX` | number | no | **`50`** | `>= 0`, `<= 100`. Not constrained to an integer. |
| `focalY` | number | no | **`50`** | `>= 0`, `<= 100`. Not constrained to an integer. |
| `link` | `url` | yes | — | |
| `code` | `url` | yes | — | |
| `dataset` | `url` | yes | — | |
| `video` | `url` | yes | — | |
| `captions` | `url` | no | **`''`** | The only `url` field in `item` with a default. |
| `transcript` | string | no | **`''`** | **Max 60000** characters — six times any `text` field. |
| `featured` | boolean | yes | — | |
| `citations` | `citationCount` | no | **`''`** | Trimmed, max 9, digits-only-or-empty. |
| `citationsAsOf` | `citationDate` | no | **`''`** | Max 10, ISO date round-trip, **not** trimmed. |
| `researchTopic` | enum, optional | no | **see warning W-1** | Exactly one of `materials`, `ultrasound`, `photoacoustic`, `general` — in that declaration order. Optional at parse; **resolved by the transform, not defaulted to null**. |
| `researchIds` | array of string, optional | no | **see warning W-2** | Each element max **100** characters; **max 100** elements. Optional at parse; **resolved by the transform, not defaulted to `[]`**. |
| `contribution` | `text` | no | **`''`** | Max 10000. |
| `approach` | `text` | no | **`''`** | Max 10000. |
| `outcome` | `text` | no | **`''`** | Max 10000. |

### ENT-4 `item` — the parse transform

**Every parse of an `item` — including every read out of storage — applies this
transform after validation:**

```
researchTopic := researchIdentity(row)
researchIds   := row.researchIds ?? initialResearchLinks.get(row.id) ?? []
```

where

```
researchIdentity(item) = item.researchTopic ?? originalTopics.get(item.id) ?? 'general'
```

Two consequences that are not obvious from the code shape:

- The transform runs on **reads**, not only writes. The stored document is
  re-validated and re-transformed on every read of `draft` and `published`.
- The editor sends **`validation.data`** back on save — the transformed and
  defaulted document, not the raw form state. So on the first save after a field was
  added, the derived values are **materialised into storage**. The transform is
  therefore simultaneously a read-path rule and the origin of stored values.

> ### W-1 — WARNING: `researchTopic` is a CONTENT-CARRYING default (FR9.2, hazard)
>
> **A Pydantic model declaring `research_topic: Topic | None = None` is type-correct
> and behaviourally wrong.** It produces `None` where the original produces a real
> topic. Nothing errors, nothing logs, and no test written from the type signature
> fails.
>
> The original resolves an absent topic **through a legacy id→topic map, and only
> then to `general`**. Precedence is strictly: an explicit value wins; the id map is
> the fallback; `'general'` is the floor.
>
> **The map, in full — `originalTopics` (`app/research-identity.ts:11-18`):**
>
> | Item `id` | Resolved `researchTopic` |
> |---|---|
> | `nano-materials` | `materials` |
> | `ultrasound-imaging` | `ultrasound` |
> | `photoacoustics` | `photoacoustic` |
>
> Any other id with no explicit topic resolves to **`general`**.
>
> **Why the map exists:** `researchTopic` was added *after* the three original
> research cards were already published, so their stored documents have no such
> field. Rather than a data migration, the card id infers it. The source comment
> states the intent verbatim: *"Existing published cards acquire a stable identity
> without changing their text or order."*
>
> **What breaks silently if this is got wrong:** all three original research cards
> fall back to `general` and **render identically as slate**, losing their distinct
> icon and colour (`researchTopicLabels` maps the four topics to
> `Nanomaterials · blue`, `Ultrasound · violet`, `Photoacoustic · teal`,
> `General research · slate`). Worse, the editor's "Card identity" control then
> shows `general` as the current value for cards the owner never set, **silently
> rewriting their identity on the next save**.
>
> **The operator is `??`, not `||`.** A stored explicit value must win even when it
> is falsy by JavaScript rules. In Python: test for *absence*, never for
> *truthiness*.

> ### W-2 — WARNING: `researchIds` is a CONTENT-CARRYING default (FR9.2, hazard)
>
> **A Pydantic model declaring `research_ids: list[str] = []` is type-correct and
> behaviourally wrong.** It produces `[]` where the original produces the seeded
> editorial links.
>
> **The map, in full — `initialResearchLinks` (`app/site-copy.ts:37-43`):**
>
> | Publication `id` | Resolved `researchIds` |
> |---|---|
> | `breast-imaging-2026` | `['photoacoustics']` |
> | `ultrasound-coherence-2025` | `['ultrasound-imaging']` |
> | `mucin-cus-2025` | `['nano-materials', 'photoacoustics']` |
> | `nanoflakes-2024` | `['nano-materials']` |
> | `nanohybrids-2023` | `['nano-materials', 'photoacoustics']` |
>
> Any other id with no explicit `researchIds` resolves to `[]`.
>
> **Note the values are research-card ids** (`nano-materials`,
> `ultrasound-imaging`, `photoacoustics`) — the same ids `originalTopics` keys on —
> **not** topic enum values. Do not confuse the two vocabularies.
>
> **Why the map exists:** `researchIds` — the many-to-many link from a publication
> to the research themes it supports — was added after those five publications were
> published. The map supplies the original editorial linkage keyed by publication id.
>
> **What breaks silently if this is got wrong:** the publications topic filter
> returns **zero results for every theme** (`paper.researchIds?.includes(topic)`
> never matches), and every research card shows **0 related papers**
> (`papers.filter(p => p.researchIds?.includes(item.id))`). The page renders
> cleanly, with grey cards and empty filters. There is no test in the source that
> would catch it.
>
> **The operator is `??`, not `||` — and here that difference is destructive.** An
> **explicitly emptied list must be preserved as empty.** An `or`/falsy port
> **resurrects links the owner deliberately deleted**, and does so on every read, so
> the owner cannot clear them at all. In Python: `research_ids if research_ids is
> not None else initial_research_links.get(item_id, [])` — never
> `research_ids or ...`.

> **Both W-1 and W-2 apply to a fresh install with particular force.** The seeded
> starting content is constructed *through* these maps, so a fresh install is
> entirely dependent on them; a long-running instance may already have the derived
> values materialised in storage. The starting data is exactly the case that needs
> the shims.

### ENT-4 top-level fields — 31 fields

| Field | Type | Required | Default | Constraints |
|---|---|---|---|---|
| `name` | string | yes | — | **`.trim()`**, then **min 1**, then **max 100**. No custom message on the `min`. |
| `role` | string | yes | — | Max **200**. |
| `affiliation` | string | yes | — | Max **200**. |
| `location` | string | yes | — | Max **200**. |
| `headline` | string | yes | — | Max **240**. |
| `intro` | `text` | yes | — | Max 10000. |
| `bio` | `text` | yes | — | Max 10000. |
| `email` | string | yes | — | Max **200**, plus a refinement passing if empty **or** matching `/^[^\s@]+@[^\s@]+\.[^\s@]+$/`. Verbatim message: `Enter a valid email.` No trim. |
| `photo` | `url` | yes | — | |
| `photoAlt` | `text` | yes | — | |
| `photoSources` | array of `imageSource` | no | **`[]`** | **Max 4** elements. |
| `photoFocalX` | number | no | **`50`** | `>= 0`, `<= 100`. |
| `photoFocalY` | number | no | **`35`** | `>= 0`, `<= 100`. **35, not 50** — a deliberate portrait framing default. This is the single most transcription-error-prone default in the schema. |
| `copy` | `copySchema` | no | **`initialCopy`** (below) | Defaulted at three nesting levels — see the copy section. |
| `cv` | `url` | yes | — | |
| `scholar` | `url` | yes | — | |
| `orcid` | `url` | yes | — | |
| `github` | `url` | yes | — | |
| `linkedin` | `url` | yes | — | |
| `accent` | enum | yes | — | Exactly one of `blue`, `burgundy`, `forest` — in that declaration order. **No default; required.** |
| `motion` | boolean | no | **`true`** | |
| `scene` | `sceneSchema` | no | **`initialScene`** (below) | |
| `scholarHighlights` | object | no | **all-empty object with `visible: false`** (below) | |
| `showNotice` | boolean | yes | — | **Required, no default.** |
| `notice` | `text` | yes | — | Max 10000. |
| `sections` | object of 6 booleans | yes | — | See below — the defaulting is asymmetric. |
| `achievements` | array of `item` | no | **`[]`** | **Max 60** elements. |
| `research` | array of `item` | yes | — | **Max 100** elements. **No default; required.** |
| `publications` | array of `item` | yes | — | **Max 500** elements. **No default; required.** |
| `journey` | array of `item` | yes | — | **Max 100** elements. **No default; required.** |
| `news` | array of `item` | yes | — | **Max 100** elements. **No default; required.** |

> **The collection asymmetry is real and must be reproduced.** `achievements` has
> `.default([])` and a **max of 60**; the other four collections have **no default**
> and different maxima (`research` 100, `publications` **500**, `journey` 100,
> `news` 100). This is a back-compat artefact of achievements being added later. **A
> model that gives all five collections a default is more permissive than the
> original** and will silently accept documents the source rejects.

### ENT-4 `sections` — six booleans, asymmetric defaulting

| Field | Type | Required | Default |
|---|---|---|---|
| `achievements` | boolean | no | **`true`** |
| `research` | boolean | **yes** | — |
| `publications` | boolean | **yes** | — |
| `journey` | boolean | **yes** | — |
| `news` | boolean | **yes** | — |
| `contact` | boolean | **yes** | — |

The `sections` object itself has **no default**: it must be present. Only its
`achievements` member is optional. Same back-compat origin as the collection
asymmetry above.

### ENT-4 `scholarHighlights`

All members are **strings** except `visible`, and **none carries a refinement**.

| Field | Type | Required | Constraint |
|---|---|---|---|
| `visible` | boolean | yes | — |
| `citations` | string | yes | Max **20** |
| `hIndex` | string | yes | Max **20** |
| `i10Index` | string | yes | Max **20** |
| `asOf` | string | yes | Max **100** |
| `affiliation` | string | yes | Max **200** |
| `interests` | string | yes | Max **1000** |

**Object-level `.default()`, verbatim:**

```json
{"visible": false, "citations": "", "hIndex": "", "i10Index": "", "asOf": "", "affiliation": "", "interests": ""}
```

Note `citations` here is a **plain max-20 string with no digits refinement**, unlike
`item.citations`, which is a `citationCount`. **Two fields with the same name and
different rules.**

### ENT-4 `sceneStory` and `sceneSchema`

`sceneStory` — all three members required, no defaults:

| Field | Type | Constraint |
|---|---|---|
| `title` | string | Max **150** |
| `description` | string | Max **600** |
| `link` | `url` | Max 2000 + the `url` refinement |

`sceneSchema`:

| Field | Type | Required | Default | Constraint |
|---|---|---|---|---|
| `offerTour` | boolean | no | **`true`** | |
| `initialView` | enum | yes | — | Exactly one of `delivery`, `photoacoustic`, `ultrasound` — in that declaration order |
| `delivery` | `sceneStory` | yes | — | |
| `photoacoustic` | `sceneStory` | yes | — | |
| `ultrasound` | `sceneStory` | yes | — | |

A legacy `autoTour` field was **deliberately retired**; the source comment records
that tours now start only after visitor input. Do not reintroduce it, and do not
accept it as an alias.

**`initialScene` — the object-level `.default()` for `scene`, verbatim:**

```json
{
  "offerTour": true,
  "initialView": "delivery",
  "delivery": {
    "title": "Small carriers. Purposeful delivery.",
    "description": "A thermoresponsive nanogel brings a drug payload and CuS nanoparticles together, with release designed to respond to heat.",
    "link": "https://etd.iisc.ac.in/handle/2005/6575"
  },
  "photoacoustic": {
    "title": "Light in. Sound out.",
    "description": "Light-absorbing materials generate acoustic signals—connecting nanoscale material design with photoacoustic imaging.",
    "link": "https://doi.org/10.1021/acsanm.3c02405"
  },
  "ultrasound": {
    "title": "From echoes to clearer insight.",
    "description": "Ultrasound transmits sound and receives echoes. My work explores coherence-based imaging to help distinguish breast cysts from solid masses.",
    "link": "https://doi.org/10.1093/radadv/umaf037"
  }
}
```

The `photoacoustic.description` contains a **U+2014 EM DASH** immediately after
`signals`, with no surrounding spaces. It is content, not punctuation to be
normalised.

### ENT-4 `copy` — `copySchema`, nine groups, 25 leaf defaults

**Defaulting happens at three nesting levels**, and each level must work
independently: an absent `copy` key, an absent `copy.research` key and an absent
`copy.research.title` key must each produce a different but correct result.

- **Level 3 (whole object):** `copySchema` itself is `.default(initialCopy)`.
- **Level 2 (group):** each of the nine groups is `.default(<its own initial group>)`.
- **Level 1 (leaf):** each leaf field is `.default(<its own initial value>)`.

Two reusable shapes:

| Name | Exact definition |
|---|---|
| `label(fallback)` | String, **`.trim()`**, then **min 1** with the verbatim message `Add a label.`, then **max 80**, then `.default(fallback)`. |
| `section(value)` | Object `{title: string .trim().min(1, 'Add a heading.').max(200).default(value.title), description: string .max(1000).default(value.description), navigation: label(value.navigation)}`, and the object itself `.default(value)`. |

Group shapes:

| Group | Shape |
|---|---|
| `hero` | `{researchAction: label, scholarAction: label, discover: label, topics: string max 200 with default}`, object `.default(initialCopy.hero)` |
| `achievements`, `research`, `publications`, `journey`, `news`, `contact` | `section(...)` — three fields each |
| `scholar` | `{title: string .trim().min(1).max(200).default(...), profileAction: label}`, object `.default(initialCopy.scholar)`. **Note: `scholar.title`'s `min(1)` carries NO custom message**, unlike `section`'s `Add a heading.` |
| `footer` | `{tagline: string max 200 with default}`, object `.default(initialCopy.footer)` |

> **These 25 defaults are content, not boilerplate — they are the site's actual
> wording.** 25 leaf defaults, of which **23 are non-empty** (`journey.description`
> and `news.description` default to `''`). Nearly every one is a *different* string.
> All 25 must be carried verbatim, including the embedded newlines.

**`initialCopy` — the complete default value, verbatim (newlines shown as `\n`
exactly as they appear in the strings):**

```json
{
  "hero": {
    "researchAction": "Explore my research",
    "scholarAction": "Google Scholar",
    "discover": "Scroll to discover",
    "topics": "Drug delivery · Photoacoustics · Ultrasound"
  },
  "achievements": {
    "title": "The work.\nThe moments behind it.",
    "description": "Recognition, shared discoveries, and the people along the way.",
    "navigation": "Highlights"
  },
  "research": {
    "title": "Small scale.\nWide possibilities.",
    "description": "Responsive carriers. Optical contrast.\nInformation carried by sound.",
    "navigation": "Research"
  },
  "publications": {
    "title": "Selected publications.",
    "description": "A curated selection. The complete record is on Google Scholar.",
    "navigation": "Publications"
  },
  "journey": {
    "title": "Curiosity.\nA constant in motion.",
    "description": "",
    "navigation": "About"
  },
  "news": {
    "title": "From the research.",
    "description": "",
    "navigation": "Updates"
  },
  "contact": {
    "title": "Good questions.\nNew connections.",
    "description": "Research, collaboration,\nor a shared curiosity.",
    "navigation": "Connect"
  },
  "scholar": {
    "title": "A snapshot of\nthe research.",
    "profileAction": "Explore the full profile"
  },
  "footer": {
    "tagline": "Materials. Delivery. Light & sound."
  }
}
```

Character-level details that a careless transcription loses:

- `hero.topics` uses **U+00B7 MIDDLE DOT** with a space either side, three times.
- `footer.tagline` uses a literal ampersand `&`, not `&amp;`.
- Five titles and two descriptions contain a **literal newline** (`\n`), and the line
  breaks are deliberate typographic composition. `achievements.title`,
  `research.title`, `journey.title`, `contact.title`, `scholar.title`,
  `research.description` and `contact.description` each carry exactly one.
- `journey.description` and `news.description` are the **empty string**, not absent.

---

## The cap census — every maximum in the schema, exhaustively

Enumerated directly from `app/content.ts` and `app/site-copy.ts` rather than from a
summary, because a cap transcribed wrong is a field that silently accepts or
rejects the wrong input. **Counts are of *declarations* in `app/content.ts`; the
`max(80)` declaration lives in `app/site-copy.ts`.**

| Cap | Count in `app/content.ts` | Where |
|---|---|---|
| **100** | 12 | `item.id`; each element of `item.researchIds`; `item.researchIds` array length; `name`; `scholarHighlights.asOf`; `focalX`, `focalY`, `photoFocalX`, `photoFocalY` (numeric `.max(100)`, not lengths); `research`, `journey`, `news` array lengths |
| **200** | 5 | `role`, `affiliation`, `location`, `email`, `scholarHighlights.affiliation` |
| **20** | 3 | `scholarHighlights.citations`, `.hIndex`, `.i10Index` |
| **16000** | 2 | `imageSource.width`, `imageSource.height` (numeric bounds, min 1) |
| **1000** | 2 | `item.title`, `scholarHighlights.interests` |
| **4** | 2 | `item.imageSources` and `photoSources` array lengths |
| **10000** | 1 | the shared `text` building block — used by `subtitle`, `description`, `imageAlt`, `contribution`, `approach`, `outcome`, `intro`, `bio`, `photoAlt`, `notice` |
| **2000** | 1 | the shared `url` building block — used by 11 fields |
| **60000** | 1 | `item.transcript` |
| **600** | 1 | `sceneStory.description` |
| **500** | 1 | `publications` array length |
| **240** | 1 | `headline` |
| **150** | 1 | `sceneStory.title` |
| **60** | 1 | `achievements` array length |
| **40** | 1 | `item.year` |
| **10** | 1 | the shared `citationDate` building block |
| **9** | 1 | the shared `citationCount` building block |
| **80** | *(in `app/site-copy.ts`)* | the `label(fallback)` building block — `hero.researchAction`, `hero.scholarAction`, `hero.discover`, `scholar.profileAction`, and the six `section(...)` navigation labels |
| **200** | *(in `app/site-copy.ts`)* | each `section(...)` title, `scholar.title`, `hero.topics`, `footer.tagline` |
| **1000** | *(in `app/site-copy.ts`)* | each `section(...)` description |

**The traps in this table, stated so they are not rediscovered by a bug.**

- **`max(100)` is used for three unrelated things** — a string length (`item.id`),
  an array length (`researchIds`, `research`, `journey`, `news`), and a *numeric*
  upper bound (the four focal-point percentages). A transcription that treats them
  uniformly will produce a focal point capped at 100 characters or an id capped at
  the number 100.
- **`max(200)` appears in both files** with different subjects — five content
  fields and four copy fields.
- **`max(1000)` likewise** — `item.title` and `scholarHighlights.interests` in one
  file, every copy-section description in the other.
- **The four collection maxima are all different** and only one of them is 100.

---

## The public read has no parity fixture

`GET /api/public/content` **returns 404 in the source — it does not exist there.**
Verified by execution. It is a **new route in the target design**, introduced so
that public rendering never touches the owner read.

**So its behaviour is specified, not preserved**, and there is no recorded fixture
to assert it against. Two consequences this unit must carry:

- The parity rule does not reach it. Nothing about its shape is inherited, and no
  fixture can contradict a choice made here.
- **What it must not do is still a hard rule**: it returns the **published document
  only**, and **no draft content may appear in any public response** (BR24.2,
  realising NFR11). That is the one property that cannot be checked against the
  source, because the source has no such route — so it has to be checked against
  itself, with a test.

---

## ENT-5 `ContentRevision` — owned by `RevisionLedger`, written by `ContentAuthority`

| Field | Type | Required | Default | Constraints |
|---|---|---|---|---|
| `revisionEntryId` | string | yes | — | For a normal entry, **the write's mutation token** (source: the `crypto.randomUUID()` value, canonical lowercase UUID v4). For the two permanent baselines, the **fixed literal ids** `starting-published` and `starting-draft`. When supplied by a caller for lookup: max **100** characters, non-empty, and must match `/^[a-zA-Z0-9-]+$/`. |
| `revision` | integer | yes | — | The revision number this entry records. Not unique — a baseline pair and a normal entry can share one. |
| `action` | enum | yes | — | Exactly one of `draft`, `publish`. |
| `content` | `Content` | yes | — | The full content document **as written**, read back from the stored `draft` column rather than taken from the request — see BR4.11 in `rules.md`. |
| `createdAt` | string | yes | — | ISO-8601 UTC instant. For a normal entry it is read back from the document's `updatedAt`, so entry and document agree exactly. For a baseline it is **the time of capture, not a guessed original publication date**. |
| `baseline` | boolean | yes | `false` | `true` only for the two starting entries. Stored as an integer in the verified adapter and coerced with a truthiness test on read (`!!row.baseline`). Baselines are **never pruned**. |

Entries reference `ContentDocument`: each `ContentRevision` is a past state of the
one document.

**Write ownership, stated because the ownership table alone misleads:**
`RevisionLedger` owns this entity, its ordering and its retention policy, but
**performs no write**. `ContentAuthority` performs the insert and the prune inside
its one combined write, under the policy `RevisionLedger` supplies (ADR-001).
`RevisionLedger`'s own store access is read-only.

**The ordering and the two baseline ids are confirmed against data, not read off a
query.** A history listing from the running source returned, in order: revision 4
draft non-baseline; 3, 2, 1 the same; then **revision 0 `publish` baseline, id
`starting-published`**; then **revision 0 `draft` baseline, id `starting-draft`**.
That is `revision DESC, baseline ASC, action DESC` exactly, and it confirms the two
literal ids.

---

## Assumptions & Open Questions

- **[open, assigned to this unit — a latent defect with no owner]** `parseRecovery`
  accepts a stored draft up to **6,000,000 characters** while the save path rejects
  anything over **1,500,000**. **A recovered draft between those two bounds is
  restorable into the editor but unsavable** — it fails 413 on every attempt,
  **including autosave**. The two limits were chosen independently in the source.
  This is **real behaviour, not speculation**. It is recorded in full, with its
  options, in `rules.md` § *The unsavable-recovered-draft window* and is **not
  decided here**.
- **[assumption]** `Asset.width`/`height` and the asset metadata row are **not**
  specified in this document: `Asset` is ENT-6 and is owned by U5 `media`. This
  unit relates to assets only through the substring visibility relation on the
  published document, which is a rule (BR7.4, owned by U5), not a foreign key.
- **[carried hedge — CodeKB is self-inconsistent]** The knowledge base gives the
  second `reply()` helper's location as `app/api/history/route.ts:14` in one
  section and `:4` in another, against a 14-line file; one is wrong and the scan
  does not say which. Separately it places `contentSchema` at `app/content.ts:20`
  and `sceneSchema` at `:21`, an ordering that cannot hold under eager evaluation
  since the former consumes the latter. **Neither affects any constraint above** —
  only line attributions are in doubt. Carried rather than laundered into
  certainty. *(The cap census above was enumerated from the file directly, which
  makes the line-attribution doubt irrelevant to the values.)*
- **[note]** The seeded starting content itself (FR9.3 — five publications, three
  research themes, three achievements, four journey entries, four news items, the
  Scholar highlights) is **not** enumerated in this document. It is instance data
  rather than schema, and it is reproduced from the source's constructor and the
  recorded source fixtures. What *is* enumerated here is every `.default()` the
  schema itself carries, which is what a model declaration must encode. **Where
  FR9.3 is cited:** `rules.md` `BR4.1` (`source: FR4.1, FR9.3`) — a fresh install
  holds no document, so the seed *is* what BR4.1 synthesises for both `draft` and
  `published` — plus the ENT-4 envelope above, where *"the seeded document"* is the
  declared default of both fields.
- **[note — where FR9.1 is cited]** **`FR9.1` is discharged by this document**, not
  by a rule: the field tables above, the asymmetric collection defaulting, the nine
  copy groups with their 25 leaf defaults and § *The cap census* together are the
  *"every field, constraint, default, maximum length and refinement"* the
  requirement asks for. `traceability.json` therefore carries `FR9.1` with this
  document as its target. `BR4.6` (authoritative validation) and `BR9.2`
  (re-validation on every read) are where that preserved schema is **enforced**, but
  neither *states* the preservation, so neither carries `FR9.1` in its `source:`.
  Both requirements were **discharged here all along and simply uncited** — a
  corpus-wide audit found no unit claimed either, although
  `inception/units-generation/traceability.json` assigns both to **U4**.
- **[note — where FR9.4 is cited]** **`FR9.4` is discharged by § *The wire format is
  frozen*** above, which cites it by id and gives both reasons the `camelCase` wire
  format is inherited rather than chosen, together with the `camelCase` field
  spellings used throughout ENT-4. It is an entity-specification discharge, on the
  same footing as `FR9.1`. It is recorded here because `FR9.4` is assigned to **U4**
  but was previously reported only by **U2 `storage-ports`**, whose `BR22.5`
  *preserves* the frozen format across the storage boundary without *stating* it;
  when U2's review finding R-6 moved `BR22.5` into that unit's `reverse` array,
  `FR9.4` was left claimed by no unit corpus-wide. It is now carried in this unit's
  `traceability.json` `coverage`.
- **[note]** `revisionEntryId` carries two different value shapes — a UUID for
  normal entries, a fixed literal for the two baselines — yet one lookup pattern
  `/^[a-zA-Z0-9-]+$/` accepts both. That is deliberate in the source and is
  reproduced, not tidied.
- **[note]** **No data migration is required.** The running source holds the
  prior-session test rows at revision 4 with `hasUnpublishedChanges: false`, plus
  the two `starting-*` baselines; the source's `initialContent` remains canonical.

## Sources

- `construction/functional-design/entities.md` §§ ENT-4, ENT-5 — every field table,
  warning box and verbatim default above is carried from there unchanged.
- `madhavi-tripathi/app/content.ts`, `app/site-copy.ts`, `app/scene-content.ts`,
  `app/research-identity.ts` — the cap census was enumerated directly from these
  files rather than from a summary.
- `codekb/Chiku_website/api-documentation.md` § *Content schema — every field and
  constraint*; `code-quality-assessment.md` §§ *Hazard 1*, *Hazard 3*.
- `inception/contract-design/contract-summary.md` § C2 — the operations these
  entities are persisted through.
- `inception/domain-design/components.md` § *Entity ownership*;
  `decisions.md` ADR-001, ADR-002.
- `inception/units-generation/unit-of-work.md` § U4 — owns, delivers, boundary,
  constraints, realises (FR4, FR5, FR7.6, FR8.3.1–FR8.3.3, FR9, NFR8, NFR11).
- **Boot verification of the running source, executed 2026-09-24** — the top-level
  read shape, the three-part revision ordering confirmed against data, the two
  literal baseline ids, and `GET /api/public/content` returning 404.
- `WORKING-RECORD.md` §§ 2 (D9, D11, D12), 3 (FR4.5, FR8.3, FR9.2, FR10.1), 5,
  10a (the cache interval re-homed to this unit).
