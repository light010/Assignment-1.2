# Business Rules — chiku-website runtime-split migration

**Upstream:** `inception/requirements-analysis/requirements.md` (FR1–FR10),
`inception/domain-design/components.md` (rule ownership),
`inception/contract-design/contract-summary.md` (the operations these rules run
inside), `codekb/Chiku_website/api-documentation.md`,
`codekb/Chiku_website/code-quality-assessment.md`,
companion artifact `entities.md`.

## How to read this document

Every rule here is something **an implementation could get wrong**. Rules the type
system already enforces are deliberately absent: "`accent` must be one of three
values" is a schema constraint and lives in `entities.md`, not here.

Rules are grouped by the component that **owns** them and carry a stable
`BR{n}.{m}` id. **The major number `n` tracks the requirement family** — `BR4.*` are
FR4 rules, `BR7.*` are FR7 rules — and every rule group states the exact requirement
it discharges, so a rule and its requirement can each be found from the other. Ids
are assigned once and do not move.

**Seven rule groups are hazards** — FR4.5, FR6.2, FR7.2, FR7.4, FR8.3, FR9.2 and
FR10.1. Each is specified **branch by branch**, and each carries an explicit
**"What breaks silently"** note, because by definition none of them fails loudly.
Every hazard rule needs a test per enumerated branch and falls inside the 100%
scoped coverage floor.

**Nothing here is designed.** Every rule is either preserved behaviour from
`madhavi-tripathi/` or a decision already recorded in the requirements, the
component catalogue, an ADR or `WORKING-RECORD.md` § 2.

**Rule index**

| Component | Rules | Of which hazard |
|---|---|---|
| `HttpApi` | BR10.1–BR10.12, BR3.1–BR3.5 | **BR10.1–BR10.6** (FR10.1) |
| `OwnerIdentity` | BR3.6–BR3.10 | — |
| `SessionAuthority` | BR3.11–BR3.17 | — |
| `LoginGuard` | BR3.18–BR3.22 | — |
| `ContentAuthority` | BR4.1–BR4.22, BR8.1–BR8.5, BR9.1–BR9.3, BR7.1–BR7.2 | **BR4.8–BR4.19** (FR4.5), **BR8.1–BR8.5** (FR8.3), **BR9.1–BR9.3** (FR9.2) |
| `RevisionLedger` | BR5.1–BR5.10 | — |
| `MediaIntake` | BR6.1–BR6.25 | **BR6.4–BR6.10** (FR6.2) |
| `MediaDelivery` | BR7.3–BR7.18 | **BR7.4–BR7.7** (FR7.2), **BR7.9–BR7.17** (FR7.4) |
| `OwnerEditor` | BR8.6–BR8.8 | — |

**120 rules in total.**

---

## `HttpApi`

### BR10.1–BR10.6 — the error envelope [hazard, FR10.1]

> **What breaks silently.** FastAPI's defaults produce `{"detail": ...}` and
> Pydantic's `loc` / `msg` on validation errors. The ported editor branches on
> `409` to enter conflict recovery and reads `result.issues` to highlight fields.
> With FastAPI's defaults, the editor **appears to work**: requests succeed,
> statuses are returned, nothing throws — but field highlighting shows nothing and
> conflict recovery never arms. This is the highest-probability silent regression
> in the migration.

- **BR10.1** Every error response across the whole HTTP surface carries exactly one
  envelope: `{"error": "<one human sentence>"}`. The key is `error`, not `detail`,
  not `message`.
- **BR10.2** On a **validation** failure only, the envelope additionally carries
  `issues`: an array of `{"path": [...], "message": "..."}`. The keys are `path`
  and `message` — not `loc` and `msg`. `path` is an array whose members are strings
  or integers (an integer member is a collection index).
- **BR10.3** The envelope is produced by **exception handlers**, never constructed
  per route. Services raise; routers do not build responses.
- **BR10.4** The exception taxonomy has exactly **five** members, mapped once:

  | Exception | Status | Carries `issues` |
  |---|---|---|
  | `NotAuthorized` | **403** | no |
  | `Conflict` | **409** | no |
  | `TooLarge` | **413** | no |
  | `Invalid` | **400** | **yes** |
  | `Cancelled` | **499** | no |
  | anything else | **503** | no |

  **`Cancelled` → 499 was missing, and its absence was not neutral.** With four
  members plus a catch-all, the taxonomy was exhaustive *as written*, so a literal
  implementation sent a cancelled upload to **503 with `Upload failed…`** instead of
  **499 with `Upload cancelled…`** — a different status **and** a different sentence,
  and user-facing error strings are product copy under the parity rule.
  `contract-summary.md` C1 requires 499 and `BR10.7` already supplies its sentence,
  so the contract demanded a status no requirement stated and the catch-all quietly
  absorbed it. **`u6-http-api` closed this locally as `BR26.2`; this is the
  workflow-level closure**, so a reader of either document now reaches the same
  taxonomy.

  A cancelled request is not an error the owner can act on, which is why it carries
  no `issues` and is not retried — it is the client going away, reported honestly
  rather than dressed as a server failure.

- **BR10.5** The catch-all status is **503, not 500**. This matches the source
  exactly: all four source routes return 503 on an unexpected throw. An unhandled
  exception is additionally logged with a full traceback (`logger.exception()`) —
  surfaced or logged, never swallowed.
- **BR10.6** Recoverable versus fatal is a **wire-level** distinction, not an
  internal one: `409` and `400`-with-`issues` are recoverable and the frontend keeps
  specific handling for each; `503` is retryable with no specific handling.

### BR10.7–BR10.9 — error strings are product copy [FR10.2]

- **BR10.7** Every user-facing error sentence falls under the parity rule. A port
  that rewrites one has changed what the owner sees. The complete set, **verbatim**:

  | Situation | Status | String |
  |---|---|---|
  | Not the owner (all routes) | 403 | `Please sign in with the website owner’s account.` |
  | Origin mismatch on `PUT /api/content` | 403 | `This request could not be verified. Refresh and try again.` |
  | Body over the character cap | 413 | `This update is too large.` |
  | Body not parseable as JSON | 400 | `The update could not be read.` |
  | Body falsy, non-object, array, or envelope invalid | 400 | `Invalid save request.` |
  | Content validation failed | 400 | `Please check the highlighted fields before saving.` |
  | Revision conflict | 409 | `This draft changed in another tab. Your edits are still here. Review the latest saved draft before saving again.` |
  | Save threw | 503 | `Your changes could not be saved. They are still in the form. Please try again.` |
  | Content read threw | 503 | `Unable to load your draft. Please try again.` |
  | History id malformed | 400 | `Choose a saved version from the history list.` |
  | History id absent or pruned | 404 | `This version is no longer in the recent history. Your current draft is unchanged.` |
  | History read threw | 503 | `Version history is temporarily unavailable. Your current edits are safe.` |
  | Media denied or missing | 404 | `Not found` |
  | Media read threw | 503 | `File temporarily unavailable` |
  | Upload: missing or zero-byte file | 400 | `Choose a non-empty file.` |
  | Upload: unsupported or unverifiable format | 400 | `The file format could not be verified. Please choose another file.` |
  | Upload: caption file invalid | 400 | `Choose a UTF-8 .vtt file beginning with WEBVTT and containing valid timed captions.` |
  | Upload: declared length over the pre-check | 413 | `Choose a video smaller than 50 MB, a photo / PDF smaller than 10 MB, or captions smaller than 1 MB.` |
  | Upload: measured sum over the per-kind cap | 413 | `Choose files totaling less than ${limit} MB.` — interpolated with the numeric cap |
  | Upload cancelled | 499 | `Upload cancelled. Your previous file is unchanged.` |
  | Upload threw | 503 | `Upload failed. Please try again; your form changes are safe.` |

- **BR10.8** `Please sign in with the website owner’s account.` contains
  **U+2019 RIGHT SINGLE QUOTATION MARK**, not an ASCII apostrophe. A parity diff
  against recorded fixtures compares bytes; a straight `'` fails it.
- **BR10.9** Four upload strings lose their trigger under FR6.5 and D24, because
  server-side variant generation removes the browser-prepared-variant surface
  entirely: `The prepared image sizes could not be verified. Please choose the photo
  again.`, `Prepared photo sizes must use WebP.`, `Prepared photo sizes must be no
  larger than 1600 pixels.`, `Prepared photo sizes must match the original framing.`
  They are recorded here so a reader can tell a **deliberately retired** string from
  a **missed** one. Do not re-create the checks in order to keep the strings alive.

### BR10.10–BR10.12 — check ordering on `PUT /api/content` [FR4.7]

- **BR10.10** The checks run **strictly in this order**, because the order determines
  which status a multiply-invalid request receives:

  1. Origin match → 403
  2. Owner session → 403
  3. Decoded body length over the cap → 413
  4. JSON parse failure → 400
  5. Body falsy, not an object, or an array → 400
  6. **Content schema validation → 400 with `issues[]`**
  7. **Envelope validation → 400 without `issues[]`**
  8. Write returns a conflict signal → 409
  9. Otherwise → 200

- **BR10.11** **Content validation (6) runs BEFORE envelope validation (7).** A
  request carrying both malformed `content` and a bad `revision` returns the
  *content* 400 with `issues[]`, not the envelope 400. Reordering these two
  silently changes the error the editor displays — the editor highlights fields on
  one and shows a bare sentence on the other.
- **BR10.12** Envelope validation (step 7) rejects unless **all** hold, evaluated as
  one predicate: `revision` is a safe integer; `revision >= 0`; `revision <
  Number.MAX_SAFE_INTEGER`; `action` is exactly `draft` or `publish`; `autosave` is
  absent or a boolean; and **not** (`autosave === true` **and** `action !==
  'draft'`). Autosave is legal only with a draft action.

### BR3.1–BR3.2 — authorization at the operation boundary [FR3.8, NFR2]

- **BR3.1** Every protected read and every mutation authorises itself **at its own
  operation**, never by the route's placement, a protected layout, a hidden control
  or a frontend route rule. A request that bypasses the frontend entirely is
  rejected identically to one that does not.
- **BR3.2** `HttpApi` enforces nothing beyond transport concerns. The authorization
  decision belongs to the component behind the route.

### BR3.3–BR3.5 — same-origin and CSRF on mutations [FR6.7, D1]

- **BR3.3** Origin enforcement on mutations reproduces the source predicate: the
  request's `Origin` header must be **present** and **exactly equal** to the request
  URL's own origin. **A missing `Origin` header fails the check** — it is not treated
  as same-origin. This is the source's only CSRF defence.
- **BR3.4** The port **adds** a CSRF token (double-submit) paired with the session,
  on top of BR3.3 (D1). The origin check is not replaced by it.
- **BR3.5** In the source, origin is checked on **2 of 6** endpoint/method pairs —
  `PUT /api/content` and `POST /api/upload` only. The port applies it to
  **mutations**, which is the same set plus the new authentication mutations. It is
  never applied to `GET`/`HEAD`.

---

## `OwnerIdentity`

### BR3.6–BR3.10 — credentials and one-shot provisioning [FR3.1, FR3.7]

- **BR3.6** Credential verification answers **only whether the supplied password
  matched**, never why it did not, and never whether the account exists. The
  argon2id hash is never returned by any operation and never logged.
- **BR3.7** Initial-owner provisioning is **one-shot**, and its gate is **the
  existence of the owner record** — not a consumed flag, not a file, not an
  environment marker. A container restart therefore cannot reopen it.
- **BR3.8** The provisioning route is enabled only while **both** hold: no owner
  record exists **and** the bootstrap secret is configured. It requires that secret,
  accepts the owner's chosen password, and stores only its argon2id hash.
- **BR3.9** With the bootstrap secret unset and no owner present, the service
  **starts normally and refuses every sign-in** rather than creating an account.
- **BR3.10** No default, seeded, sample or hard-coded credential exists anywhere in
  the source tree. The acceptance test is exactly: **a fresh `docker compose up`
  against an empty volume has no account anyone can sign in to.**

---

## `SessionAuthority`

### BR3.11–BR3.13 — the session cookie and its signing key [FR3.2, NFR5]

- **BR3.11** A successful sign-in issues a **signed** session cookie marked
  `HttpOnly`, `Secure` and `SameSite=Lax`.
- **BR3.12** A CSRF token is issued **paired 1:1 with the session** and verified on
  every mutation as a request header (double-submit).
- **BR3.13** The signing key is a **startup precondition**: if
  `SESSION_SIGNING_KEY` is unset, empty, or under 32 bytes, the backend raises
  during startup with a message naming the variable and exits non-zero. **No default
  value, no fallback, and explicitly no auto-generated per-process key** — an
  auto-generated key silently invalidates every session on restart and hides the
  misconfiguration, which makes it the worse failure because it looks like it works.

### BR3.14–BR3.17 — expiry and revocation [FR3.3, FR3.4, D2]

- **BR3.14** A session expires after **8 hours idle**. The idle window **slides**:
  each verified request advances `lastSeenAt`.
- **BR3.15** A session expires **7 days after issue, absolutely**, regardless of
  activity. `absoluteExpiresAt` is computed once at issue and **never extended by a
  touch**. Both bounds are enforced; whichever is reached first ends the session.
- **BR3.16** Verification returns the owner identity **or nothing**. A session with a
  non-null `revokedAt`, or past either expiry bound, verifies as nothing.
- **BR3.17** Sign-out revokes **server-side**, so a stolen cookie stops working
  rather than merely disappearing from one browser. Clearing the cookie alone does
  not satisfy this rule.

---

## `LoginGuard`

### BR3.18–BR3.22 — bounding failed sign-in [FR3.5, D3]

- **BR3.18** Failed sign-in is refused beyond **5 attempts per account per 15
  minutes**.
- **BR3.19** Independently, failed sign-in is refused beyond **20 attempts per
  source address per 15 minutes**. The two counters are separate and both apply.
- **BR3.20** The refusal is **indistinguishable from an ordinary credential
  failure**: same status, same body, same sentence, whether the account is unknown,
  the password is wrong, or the limit was reached. It reveals neither that an account
  exists nor that a limit was hit. **Do not add a "too many attempts" message or a
  `Retry-After` header** — either one enumerates.
- **BR3.21** A **successful** sign-in clears that account's counter.
- **BR3.22** Counters are **persisted**, so a process restart does not reset a
  window. An in-memory counter is not an acceptable implementation.

---

## `ContentAuthority`

### BR4.1–BR4.2 — reading content state [FR4.1]

- **BR4.1** When **no document exists**, the read synthesises
  `{draft: <seed>, published: <seed>, revision: 0, updatedAt: null, publishedAt:
  null, hasUnpublishedChanges: false}` and **writes nothing**. A read must never
  create the document.
- **BR4.2** `hasUnpublishedChanges` is **computed on every read**, never stored: it
  is a full serialised comparison of `draft` against `published`. It is not a flag
  maintained by the write path.

### BR4.3–BR4.5 — draft versus publish [FR4.2]

- **BR4.3** An accepted write **always** overwrites `draft`, for a publish as well as
  for a draft save.
- **BR4.4** `published` and `publishedAt` change **only** when `action = 'publish'`.
  `publishedAt` stays `null` until the first publish; the seeded document is not
  "published".
- **BR4.5** `revision` increments by exactly 1 on **every** accepted write — **drafts
  as well as publishes**. An implementation that only bumps the revision on publish
  breaks the editor's concurrency contract on the very next autosave.

### BR4.6 — authoritative validation [FR4.3]

- **BR4.6** Every write is validated authoritatively in Python **before** it is
  persisted, and a validation failure returns **field-level issues** the editor
  displays, not a generic message (see BR10.2 for the shape). The browser's generated
  mirror is for responsiveness only and is never the enforcement.

### BR4.7 — optimistic concurrency [FR4.4]

- **BR4.7** A write carries the caller's **base revision**. The content update is
  applied only if the stored revision still equals it; otherwise the write is
  rejected as a conflict, the caller's edits are preserved, and the **current state
  is returned with the error** so the caller can reconcile. *(Deliberately not a
  hazard: this failure is loud and the editor already handles it. The silent risk is
  one level down — BR4.8–BR4.19.)*

### BR4.8–BR4.19 — the combined write and its side-effect guard [hazard, FR4.5]

The single highest-risk behaviour in the system. It is one call, one caller, one
transaction, carrying the content update, the revision entry **and** the retention
prune together. The source expresses it as **seven statements in one D1 batch**,
which D1 executes as a single implicit transaction. The pure-versus-execute split —
a function that *builds* the statements and a thin executor that *runs* them —
survives the port, because that factoring is what makes the batch inspectable.

Inputs: `content`, `base_revision`, `action`, `now`, `mutation_token`, `retention`.
Derived: `serialized = serialise(content)`, `initial = serialise(<seed>)`,
`publish = (action == 'publish')`, `next_revision = base_revision + 1`.
`mutation_token` is **freshly generated per call** (source: `crypto.randomUUID()`).

- **BR4.8 — Statement 0, bootstrap the singleton.**
  `INSERT INTO site_content (id, draft, published, revision, updated_at) SELECT 1, ?, ?, 0, ? WHERE ? = 0 ON CONFLICT(id) DO NOTHING`,
  bound `(initial, initial, now, base_revision)`.
  Creates the document seeded with the initial content in **both** columns at
  revision 0, with `published_at` left **NULL**. Two guards, both load-bearing:
  `WHERE ? = 0` fires only when the caller claims revision 0, so **a client at
  revision 5 can never resurrect a deleted document**; `ON CONFLICT DO NOTHING`
  makes a concurrent bootstrap harmless.

- **BR4.9 — Statements 1 and 2, capture the permanent baselines, once ever.**
  `INSERT OR IGNORE INTO content_revisions (id, revision, action, content, created_at, baseline) SELECT 'starting-published', revision, 'publish', published, ?, 1 FROM site_content WHERE id = 1 AND revision = ?`,
  and the same with `'starting-draft'`, `'draft'`, `draft`. Both bound
  `(now, base_revision)`.
  The **fixed primary keys** plus `INSERT OR IGNORE` are what make each succeed **at
  most once in the document's lifetime**. They capture the *pre-existing* content —
  the state **before** this write — with `baseline = 1`. `created_at` is the time of
  capture, **not a guessed original publication date**; the source comment says so
  verbatim: *"Capture starting versions once, without guessing their original
  publication date."* The `revision = ?` guard means a stale writer captures nothing.
  A target store without `INSERT OR IGNORE` semantics needs an equivalent that is
  **genuinely idempotent under concurrency** — not a read-then-write.

- **BR4.10 — Statement 3, the compare-and-set. This is the concurrency control.**
  ```sql
  UPDATE site_content SET
    draft = ?,
    published = CASE WHEN ? = 1 THEN ? ELSE published END,
    revision = revision + 1,
    updated_at = ?,
    published_at = CASE WHEN ? = 1 THEN ? ELSE published_at END,
    last_mutation = ?
  WHERE id = 1 AND revision = ?
  RETURNING draft, published, revision, updated_at, published_at
  ```
  bound `(serialized, publish, serialized, now, publish, now, mutation_token, base_revision)`.
  `draft` is always overwritten; `published`/`published_at` move only on publish (the
  two `CASE` expressions **are** how "publish" is expressed); `revision` increments
  unconditionally; `last_mutation` is stamped with this call's token.
  **`WHERE id = 1 AND revision = ?` is the optimistic-concurrency guard**: a stale
  base revision matches zero rows, `RETURNING` yields nothing, and the caller gets
  409.

- **BR4.11 — Statement 4, the history insert, gated on the token.**
  `INSERT INTO content_revisions (id, revision, action, content, created_at, baseline) SELECT ?, revision, ?, draft, updated_at, 0 FROM site_content WHERE id = 1 AND revision = ? AND last_mutation = ?`,
  bound `(mutation_token, action, next_revision, mutation_token)`.
  Three things are load-bearing. (a) The history row's **id is the mutation token**.
  (b) Its `content` is **read back from the row's `draft` column**, and its
  `created_at` from the row's `updated_at` — so the entry is byte-identical to **what
  statement 3 just wrote, not to what the caller sent**. An implementation that
  inserts the caller's payload diverges whenever validation transforms or defaults
  changed the stored value, which — given the `item` transform and the many defaults
  — is **most of the time**. (c) For a publish, `draft` and `published` are equal, so
  storing `draft` is correct for both actions.

- **BR4.12 — Statements 5 and 6, retention, gated on the same token.**
  ```sql
  DELETE FROM content_revisions
  WHERE action = 'draft' AND baseline = 0
    AND id NOT IN (SELECT id FROM content_revisions
                   WHERE action = 'draft' AND baseline = 0
                   ORDER BY revision DESC LIMIT 30)
    AND EXISTS (SELECT 1 FROM site_content
                WHERE id = 1 AND revision = ? AND last_mutation = ?)
  ```
  and the same for `action = 'publish'` with `LIMIT 20`. Both bound
  `(next_revision, mutation_token)`. See BR5.7–BR5.9 for the policy itself.

- **BR4.13 — the ABA scenario, concretely. This is why the token exists.**
  The `revision` CAS and the `last_mutation` token defend **different things**, and
  the second is **not redundant**:
  - `revision` (statement 3) protects **the content write**. It answers *"is the
    caller's view of the document still current?"*
  - `last_mutation` (statements 4, 5, 6) protects **the side effects**. It answers
    *"is the row in its current state because **I** put it there?"*

  The distinction matters because statements 4–6 are guarded on `revision =
  next_revision` — **a value that is not unique to this writer**:

  > The document sits at **revision 5**. Writers **A** and **B** both load
  > revision 5.
  > **B** commits first: the row advances to **revision 6**, stamped with **B's**
  > token.
  > **A's** write now runs. A's statement 3 (`WHERE revision = 5`) matches nothing —
  > **the compare-and-set correctly fails**, and A will receive a 409.
  > **But A's statements 4–6 test `revision = 6`, because A's `next_revision` is
  > also 6 — and B's write satisfies exactly that condition.**

  Without the token, therefore:
  - **Statement 4** inserts a history row keyed by **A's** mutation id, carrying
    **B's** content (it selects `draft` from the row), labelled with **A's** action.
    **A phantom revision that nobody ever saved.**
  - **Statements 5 and 6** run **A's** retention pass off the back of **B's** write,
    **pruning history A had no right to prune** — potentially deleting a revision B
    had just created.

  Adding `AND last_mutation = ?` with a fresh random token per call makes all three
  guards test **identity rather than position**. A stale writer's `next_revision` may
  collide with the winner's `revision`; its random token will not. This is a classic
  **ABA defence**: the revision counter alone cannot distinguish "unchanged" from
  "changed to a coincidentally equal value by someone else", and the token supplies
  the missing identity.

  **What exactly the token prevents:** a losing writer recording a history entry that
  carries the winner's content under the loser's own action, and a losing writer
  executing a retention prune it was never entitled to execute. It prevents nothing
  about the content write itself — that is the CAS's job, and the CAS already works.

- **BR4.14 — the token is not optional, and not an optimisation.** Re-expressing this
  as "CAS on revision, then insert history, then prune" **without** the token
  reintroduces both bugs. They are **timing-dependent and will not appear in
  single-user testing**, which is the entire reason this rule is written out.
- **BR4.15 — the guard does not depend on transactional isolation.** Even under a
  runtime with weaker isolation than one implicit transaction, the token keeps
  statements 4–6 correct. Do not argue the token away on the grounds that the
  transaction already serialises the writes.
- **BR4.16 — all effects commit together or none does.** Atomicity is **required** of
  the port operation (`ContentStore.commit`). Splitting the three effects across
  separate calls or separate transactions breaks both guards.
- **BR4.17 — `results[3]` is a load-bearing positional index.** The source reads the
  CAS result as `results[3]?.results?.[0]`, by **numeric index into the batch array,
  with no comment marking it**. Statement 3 is the `UPDATE`. **Insert a statement
  anywhere before it and the write silently reads the wrong result** — most likely
  `undefined`, which the route interprets as a **409 conflict**. So a refactor of the
  batch produces spurious "this draft changed in another tab" errors rather than a
  crash. The port must read the CAS outcome by **name or by explicit binding**, never
  by position; if a positional read is unavoidable in the chosen driver, the index
  must be asserted by a test.
- **BR4.18 — the prune is expressed as read-the-survivors-then-delete-the-rest,
  inside the transaction** — **not** as a SQL predicate. Firestore has no
  `DELETE ... WHERE id NOT IN (subquery)`, and a SQL-shaped prune would be
  satisfiable by only one adapter. This is a port-contract rule, not an
  implementation preference.
- **BR4.19 — the retention subquery's ordering is not tiebreak-stable, and that is
  preserved.** `ORDER BY revision DESC` alone can tie: multiple rows can share a
  revision (a baseline pair plus a normal entry). **Which row survives at the
  boundary is unspecified** in the source. A faithful port uses the same ordering and
  inherits the same indeterminacy; it must not "fix" it by adding a tie-break,
  because that changes which entries survive.

> **What breaks silently across BR4.8–BR4.19.** Nothing errors and nothing logs. The
> history list grows a row the owner never saved, or loses a row it should have
> kept. It is invisible to single-user testing, invisible to coverage percentages,
> and only reproducible by two concurrent writers holding the same base revision.

### BR4.20–BR4.22 — the request-size cap [FR4.6, D11]

- **BR4.20** A save request whose body exceeds **1,500,000 characters** of decoded
  text is rejected as too large. **The cap counts CHARACTERS, not BYTES.** The source
  reads the body as a JavaScript string and tests `.length`, which counts **UTF-16
  code units**.
- **BR4.21** The consequence is concrete: **a document of 1.5 M non-ASCII characters
  can be 3–4 MB of UTF-8**, and an implementation that caps at 1,500,000 *bytes*
  rejects documents the current system accepts. Under the parity rule that is a
  silent, undiscoverable break in the owner's own longest content, so the inelegant
  limit wins over the more defensible one.
- **BR4.22** The cap is checked **after the body is fully read** and **before JSON
  parsing** (BR10.10 steps 3 and 4). It therefore limits **document size, not memory
  use** — the full body is already in memory when the check runs. Reproduce the
  position as well as the number: moving the check after the parse changes which
  status a too-large malformed body receives.

### BR8.1–BR8.5 — recovered-draft classification [hazard, FR8.3, ADR-006]

**This is a backend rule.** Review finding R-01 established it as a correctness
rule, so it lives behind `ContentAuthority`'s inspect operation; the editor holds
the bytes and renders the verdict (BR8.6–BR8.8). The current system gets this rule
**wrong**, and the port implements FR8.3.1/FR8.3.2 as written — **not** the current
behaviour. This is D9, one of only three deliberate behaviour changes.

- **BR8.1 — Recoverable: offer the draft.** A value that is **present and of the
  correct type** but **outside its permitted set or range**. Specifically:
  - a string shorter than a minimum (an emptied required title);
  - a string longer than a maximum;
  - a number outside its range;
  - a value failing a format or custom refinement (a malformed email, a bad URL, a
    non-numeric citation count, an impossible citation date);
  - **a value outside an enumerated set** — `accent`, `researchTopic`, the scene's
    `initialView`.

  These are exactly the states an owner produces **by typing**, so the draft is
  kept, repaired against schema defaults, and presented for review.
- **BR8.2 — Corrupting: discard the draft.** A **malformed record**: the wrong JSON
  shape, a field of the wrong type, a missing required structure, or a stored blob
  that is not parseable at all. These indicate corruption rather than in-progress
  editing.
- **BR8.3 — Mapping validation outcomes to the two classes.** Stated in terms of what
  a validator reports, because the source's bug was precisely a mis-mapping:

  | Validation outcome | Class |
  |---|---|
  | Value below a minimum length/size | **Recoverable** |
  | Value above a maximum length/size | **Recoverable** |
  | Custom/refinement predicate failed | **Recoverable** |
  | String format/pattern check failed | **Recoverable** |
  | **Value not a member of an enumerated set** | **Recoverable** |
  | Wrong type for the declared field | **Corrupting** |
  | Required key missing | **Corrupting** |
  | Value is not an object/array where one is required | **Corrupting** |
  | Payload not parseable as JSON at all | **Corrupting** |

- **BR8.4 — What the source does, and why copying it is wrong.** The source
  allowlists four issue codes — `too_small`, `too_big`, `custom`, `invalid_format` —
  and discards the draft if **any** issue falls outside that list. Two defects
  compound: `invalid_format` is a **zod v4** code and the installed package resolves
  to the **v3** API, so that entry **can never match**; and **`invalid_enum_value`,
  which v3 does emit, is absent**. Net effect: **one bad enum discards the owner's
  entire recovered draft**, along with every other unsaved edit in that record —
  while the source's own comment states the opposite intent (*"Retain these
  recoverable edits, but reject malformed field types or shapes."*). Carried from the
  CodeKB with its hedge: this is **a latent defect with a proven mechanism, not a
  confirmed user-visible failure** — the scan demonstrated the code mismatch
  empirically but could not exercise the editor in that environment.
- **BR8.5 — Re-express the classification in the new validator's taxonomy, never by
  copying issue-code strings.** Pydantic's error types share no names with either zod
  version. Copying the four strings across would carry the bug forward **and add a
  second one**. The rule is stated above in terms of *what went wrong with the
  value*, which is portable; the code names are not.

> **What breaks silently.** A recovered draft is discarded and the owner is told the
> record was unusable. No error is raised, no log line names the field, and the lost
> work is unrecoverable. The failure is invisible in normal use precisely because the
> enum fields are edited through select and radio controls — it bites on a draft
> written by an older schema version or through the browser-tool path, which is
> exactly the case recovery exists for.

### BR9.1–BR9.3 — the content-carrying defaults [hazard, FR9.2]

- **BR9.1** `researchTopic` resolves through the legacy id→topic map and otherwise to
  `general`; `researchIds` resolves through the seeded id→links map and otherwise to
  `[]`. **Both maps' full contents, the precedence order, and the `??`-not-`or`
  requirement are specified in `entities.md` § W-1 and § W-2.** They are not repeated
  here; that section is normative.
- **BR9.2** This is **logic, not a field default**. It runs on **every parse**, which
  includes **every read out of storage**, not only on writes. A model declaration
  cannot express it, which is exactly why a type-correct port is behaviourally wrong.
- **BR9.3** **An explicitly emptied `researchIds` list must be preserved as empty.**
  The operator is `??`: absence triggers the map, a present-but-empty list does not.
  An `or`/falsy port **resurrects links the owner deliberately deleted**, and does so
  on every read, so the owner cannot clear them at all.

> **What breaks silently.** Three identical slate research cards instead of three
> distinct ones; **0 related papers** on every card; a publications topic filter that
> returns **nothing for every theme**; and the editor's "Card identity" control
> showing `general` for cards the owner never set, **rewriting their identity on the
> next save**. The page renders cleanly throughout. A port of this system passes
> `ruff`, `mypy --strict`, `tsc`, the Compose end-to-end flow and 100% line coverage
> while doing all of the above.

### BR7.1–BR7.2 — the published-document cache [FR7.6, ADR-002]

- **BR7.1** The cache of the published document lives in `ContentAuthority`, not in
  `MediaDelivery`, so that **invalidation never crosses a component boundary** — a
  second reader would silently miss it.
- **BR7.2** The cache changes **which requests hit storage**, never **which assets
  are public**. **A publish invalidates it.** The interval is a **security**
  parameter — a stale cache is an authorization defect — and is owned by
  `nfr-design`, not decided here.

---

## `RevisionLedger`

### BR5.1–BR5.4 — listing order [FR5.1]

- **BR5.1** The listing order is a **three-part sort**, not "newest first":
  **`revision DESC`, then `baseline ASC`, then `action DESC`.** In plain terms:
  newest revision first; within one revision, **non-baseline entries before baseline
  entries**; then **`publish` before `draft`** (descending string order).
- **BR5.2** All three parts are **load-bearing for what the owner sees**. A port that
  sorted on revision alone would list a tied revision in a different order **while
  passing any test written from a looser wording** — which is why the conformance
  suite must assert the full order.
- **BR5.3** The listing is capped at **52** entries. **This is not a page size and
  there is no pagination.** 52 is `30 drafts + 20 publishes + 2 baselines` — the
  listing limit and the retention policy are the same number **by construction**
  (BR5.7). Changing one without the other silently truncates history or shows nothing
  new.
- **BR5.4** On the Firestore adapter this order **requires a declared composite
  index**. The deployment plan must carry that index definition, and the conformance
  suite must assert the order, so a missing index **fails a test rather than silently
  reordering the list**.

### BR5.5–BR5.6 — fetching one revision [FR5.2]

- **BR5.5** A revision id is validated before use: **absent** (`id` parameter not
  present at all) means **list**; **present but empty**, longer than **100**
  characters, or failing `/^[a-zA-Z0-9-]+$/` is a **400**, not a list and not a 404.
  The absent-versus-empty distinction is a real branch — `?id=` is a 400.
- **BR5.6** Restoring a revision into the editor **never publishes**. It returns the
  entry's content for review; the owner must save or publish explicitly.

### BR5.7–BR5.9 — retention [FR5.3]

- **BR5.7** Retention keeps the **30 most recent non-baseline draft entries** and the
  **20 most recent non-baseline publish entries**. The two counts are independent — a
  run of 30 drafts never evicts a publish.
- **BR5.8** The **two starting baselines are kept permanently** and are **never
  pruned**. Both retention deletes exclude `baseline = 1` explicitly; the exclusion is
  part of the delete predicate, not a coincidence of ordering.
- **BR5.9** `RevisionLedger` **owns the retention policy but performs no write**. It
  supplies the policy; `ContentAuthority` applies it inside its one combined write
  (ADR-001). `RevisionLedger`'s own store access is **read-only**. Reading the entity
  ownership table alone would suggest otherwise.

### BR5.10 — absent revisions [FR5.4]

- **BR5.10** A revision id that is well-formed but absent — or whose entry has been
  pruned, or whose row carries no content — returns **404** with a body that states
  **the current draft is unaffected**. Reassuring the owner is part of the rule, not
  decoration: the verbatim sentence is in BR10.7.

---

## `MediaIntake`

### BR6.1–BR6.3 — what is accepted [FR6.1]

- **BR6.1** Exactly **seven** media types are accepted, with this fixed
  type→extension mapping: `image/jpeg`→`jpg`, `image/png`→`png`,
  `image/webp`→`webp`, `application/pdf`→`pdf`, `video/mp4`→`mp4`,
  `video/webm`→`webm`, `text/vtt`→`vtt`. No other type is accepted.
- **BR6.2** **Captions MIME coercion.** If the upload declares `kind = 'captions'`
  **and** the filename ends `.vtt` **and** the declared type is empty or one of
  `text/vtt`, `text/plain`, `application/octet-stream`, the type is forced to
  `text/vtt`. Otherwise the declared type is used as-is. This exists because browsers
  rarely set `text/vtt`; dropping it makes most caption uploads fail at BR6.1.
- **BR6.3** The stored extension is derived from the **validated** media type,
  **never from the user's filename**, and the object key is `<uuid4>.<ext>`. The
  user's filename is stored for display, truncated to **200 characters**.

### BR6.4–BR6.10 — byte-signature typing [hazard, FR6.2]

Type is determined by **inspecting the file's own bytes**, never the declared type
or extension. The three image parsers are **simultaneously the dimension extractor
and the format validator** — returning no dimensions **is** a rejection — so a port
must reproduce the same **accept/reject decision**, not merely the same dimensions.

> **The single most transcription-error-prone fact in this document:**
> **PNG and JPEG are big-endian. EVERY WebP field is little-endian. JPEG stores
> HEIGHT BEFORE WIDTH.** The source gets its defaults from JavaScript's `DataView`,
> whose `getUint32(n)` / `getUint16(n)` are big-endian **unless** a `true` second
> argument requests little-endian. Python's `int.from_bytes` has **no default to
> inherit**, so **every read below must be transcribed individually** with its
> byteorder stated.

- **BR6.4 — PNG.** Reject unless **all** hold: length **>= 33** bytes; bytes **0–7**
  are exactly `137 80 78 71 13 10 26 10` (`\x89PNG\r\n\x1a\n`); bytes **12–15**
  decode to `IHDR`. Then:
  - `width  =` bytes **16–19**, unsigned 32-bit, **BIG-ENDIAN**
  - `height =` bytes **20–23**, unsigned 32-bit, **BIG-ENDIAN**

  Bytes **8–11** (the IHDR chunk length) are **never checked**. Everything after byte
  23 is ignored.

- **BR6.5 — WebP.** Reject unless **all** hold: length **>= 30** bytes; bytes **0–3**
  decode to `RIFF`; bytes **8–11** decode to `WEBP`; and
  `uint32_le(bytes[4:8]) + 8 <= len(bytes)` — the **LITTLE-ENDIAN** RIFF size field
  plus the 8-byte RIFF header must not exceed the actual buffer (this is what rejects
  truncated files). Bytes **12–15** then select one of exactly three sub-formats;
  **anything else leaves width/height at 0 and is a rejection** at BR6.7.

  - **`VP8X`** (extended) — 24-bit **LITTLE-ENDIAN** canvas dimensions, **minus-one
    encoded**:
    - `width  = 1 + bytes[24] + (bytes[25] << 8) + (bytes[26] << 16)`
    - `height = 1 + bytes[27] + (bytes[28] << 8) + (bytes[29] << 16)`
  - **`VP8L`** (lossless) — requires `bytes[20] == 0x2f` (the VP8L signature byte),
    then a packed 14-bit-each layout:
    - `width  = 1 + bytes[21] + ((bytes[22] & 0x3f) << 8)`
    - `height = 1 + (bytes[22] >> 6) + (bytes[23] << 2) + ((bytes[24] & 0x0f) << 10)`
  - **`VP8 `** (lossy — **note the trailing SPACE in the four-character code**) —
    requires the 3-byte start code `bytes[23] == 0x9d && bytes[24] == 0x01 &&
    bytes[25] == 0x2a`, then:
    - `width  = uint16_le(bytes[26:28]) & 0x3fff` — **LITTLE-ENDIAN**, low 14 bits
    - `height = uint16_le(bytes[28:30]) & 0x3fff` — **LITTLE-ENDIAN**, low 14 bits

    The `& 0x3fff` masks off the 2-bit scaling field in each 16-bit value.

- **BR6.6 — JPEG.** A real **marker-segment walk**, not a fixed-offset read. Reject
  immediately unless length **>= 4** and `bytes[0] == 0xff && bytes[1] == 0xd8`
  (SOI). Then from `position = 2`, loop:
  1. If `bytes[position++] != 0xff` → **reject** (marker desynchronised).
  2. Skip fill bytes: `while bytes[position] == 0xff: position += 1`.
  3. `marker = bytes[position++]`.
  4. If `marker == 0xd9` (EOI) **or** `marker == 0xda` (SOS) **or**
     `position + 2 > len(bytes)` → **break** the loop. **This is not a rejection**;
     it falls through to the final gate.
  5. If `marker == 0x01` (TEM) **or** `0xd0 <= marker <= 0xd7` (RST0–RST7) →
     **continue** — standalone markers with no length field.
  6. `length = uint16_be(bytes[position:position+2])` — **BIG-ENDIAN**.
  7. If `length < 2` **or** `position + length > len(bytes)` → **reject** (malformed
     or truncated segment).
  8. If `marker` is one of the SOF markers
     `0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf`:
     - if `length < 8` → **reject**
     - **`height = uint16_be(bytes[position+3 : position+5])`** — **BIG-ENDIAN**
     - **`width  = uint16_be(bytes[position+5 : position+7])`** — **BIG-ENDIAN**
     - **break**
  9. Otherwise `position += length` and loop while `position + 3 < len(bytes)`.

  **The SOF list deliberately EXCLUDES `0xc4` (DHT), `0xc8` (JPG) and `0xcc`
  (DAC)** — they share the `0xcN` range but are not frame headers. And **height is at
  offset +3, width at offset +5**: a transposition here is a silent bug that shows
  only on non-square images.

- **BR6.7 — the final gate, applied identically to all three formats.** Accept only
  if **all** hold: `width > 0`; `height > 0`; `width <= 40000`; `height <= 40000`;
  `width * height <= 100000000`. Otherwise **reject**.
  This is the **decompression-bomb defence**, and it is reached **without decoding a
  single pixel**. The pixel caps must be enforced from **header data before any
  decode**, or the defence is lost.
- **BR6.8 — the minimum-length checks are part of the contract**, not defensive
  padding: **>= 33** for PNG, **>= 30** for WebP, **>= 4** for JPEG.
- **BR6.9 — non-image signature checks.** `video/mp4`: bytes **4–7** decode to
  `ftyp`. `video/webm`: bytes **0–3** are `0x1a 0x45 0xdf 0xa3` (EBML).
  `application/pdf`: the file begins with `%PDF-`. `text/vtt`: BR6.14–BR6.22.
  **How many bytes are read is itself a rule:** for **images and VTT the ENTIRE file**
  is read into memory; for **PDF, MP4 and WebM only the first 32 bytes**. A 10 MB
  image is fully buffered; a 50 MB video is not.
- **BR6.10 — do not substitute an imaging library for the hand-written walk.** A
  library produces a **different accept/reject set**: it accepts formats this code
  rejects, and — more importantly — may **accept malformed files this walker rejects**
  at steps 1 and 7, and **reject unusual-but-valid files this walker accepts**. Pillow
  is used for **variant generation** (BR6.23), *after* acceptance; it is not the
  acceptance test. This is the one place where the project's reuse-first rule is
  deliberately not applied, and the reason is recorded here so it is not "corrected"
  later.

> **What breaks silently.** A transposed JPEG width/height produces plausible
> numbers for every square test image and wrong ones for every real photograph — and
> the wrong numbers flow into `imageSources`, which drives responsive rendering. A
> big-endian read of a WebP field produces a huge number that trips BR6.7 and
> rejects a valid file as "unverifiable format" — indistinguishable, to the owner,
> from a corrupt upload.

### BR6.11–BR6.13 — size ceilings [FR6.3]

- **BR6.11** Per-kind ceilings, applied to the **sum** of the original and any
  derived files, not per file: **`video/*` → 50 MB**, **`text/vtt` → 1 MB**,
  **everything else → 10 MB**. `MB = 1024 * 1024`, so these are **mebibytes**:
  52,428,800 / 1,048,576 / 10,485,760 bytes.
- **BR6.12** The declared-length pre-check is **advisory only**. The source tests the
  `content-length` header against **51 MB** (53,477,376 bytes); **a request without
  that header yields 0 and passes**. Reproducing only the header check leaves the cap
  unenforced; reproducing only the sum check changes **when** the rejection happens
  (after buffering rather than before). **Both are required**, and the sum check
  (BR6.11) is the authoritative one.
- **BR6.13** A missing file, a non-file field, or a **zero-byte** file is rejected as
  a 400 before any signature work.

### BR6.14–BR6.22 — the WebVTT validator [FR6.4]

**Eight independent reject conditions.** A permissive VTT library will accept files
this rejects, so the validator is specified rather than delegated.

- **BR6.14** **Decoding is strict UTF-8.** Invalid UTF-8 **throws** and the file is
  rejected. Not lenient, not replacement-character substitution. Then a leading BOM
  is stripped and all `\r\n` and bare `\r` are normalised to `\n`.
- **BR6.15** **Header gate.** Reject unless the text matches
  `/^WEBVTT(?:[ \t][^\n]*)?\n/` — the literal `WEBVTT`, optionally followed by a
  space or tab and trailing text, then a **newline**. **A file consisting of only
  `WEBVTT` with no trailing newline FAILS.**
- **BR6.16** **Reject if any `\u0000` appears anywhere** in the file.
- **BR6.17** **Markup blocklist, applied to the whole file:** reject on any match of
  `/<(?:script|iframe|object|embed|svg|style)\b/i`.
- **BR6.18** **Block split** on `/\n[ \t]*\n/` after trimming — blank-line separated,
  tolerating whitespace on the "blank" line. Reject if there are no blocks, or if
  **block 0 contains `-->`** (the header block must not itself be a cue).
- **BR6.19** **Per block from index 1:** a block matching `/^NOTE(?:[ \t\n]|$)/` is
  **skipped entirely** (comments). Otherwise the timing line is at index
  `0 if '-->' in lines[0] else 1` — **a cue identifier line is allowed before the
  timing line**, and nowhere else.
- **BR6.20** **The timing line must match exactly:**
  ```
  /^((?:\d{2,}:)?\d{2}:\d{2}\.\d{3})[ \t]+-->[ \t]+((?:\d{2,}:)?\d{2}:\d{2}\.\d{3})(?:[ \t]+.*)?$/
  ```
  i.e. an optional `HH:` of **two or more** digits, then `MM:SS.mmm` with **exactly
  three** decimal places, separated by `-->` with **at least one space or tab on each
  side**, with optional trailing cue settings.
- **BR6.21** **`end > start` strictly.** Times are parsed by splitting on `:` and
  taking seconds, then minutes, then hours (hours defaulting to 0); the parse yields
  a value only if hours is finite **and** `seconds < 60` **and** `minutes < 60`,
  otherwise **not-a-number**. Because the comparison is `end > start`, a
  not-a-number on either side makes the comparison false and **rejects the file**. A
  **zero-duration cue is rejected**. Every cue's payload — `lines[index+1:]` joined
  and trimmed — must be **non-empty**.
- **BR6.22** **At least one cue.** A file with a valid header and **no cues at all is
  rejected**. Any single block failing any of the above rejects the **whole file**.

### BR6.23 — variant generation [FR6.5, D24]

- **BR6.23** Responsive image variants are generated **server-side in Python** from
  the uploaded original. The browser no longer prepares them, and the entire
  "verify the browser's prepared variants" surface — the variant envelope check, the
  WebP-only rule, the 1600-pixel ceiling and the aspect-ratio tolerance formula —
  **disappears** rather than being ported. Their error strings are BR10.9.
  **Consequence to carry forward:** the upload response's `sources[]` array is
  populated only when variants exist; in the source it was **empty for any upload the
  browser did not pre-process**, and moving generation server-side changes that
  response for **every** upload.

### BR6.24–BR6.25 — orphan-free failure [FR6.6]

- **BR6.24** Bytes and metadata are **two separate non-transactional writes** with no
  shared transaction. On **any** exception, every key written so far is deleted from
  **both** stores, under a gather-all-results primitive so one failed delete does not
  abort the rest. Cleanup is explicitly **best-effort** — it holds only while the
  handler reaches its cleanup path.
- **BR6.25** **Cleanup never masks the original error.** The response reports why the
  upload failed, not why the cleanup did. Cancellation is checked at **seven** points
  through the write sequence and maps to **499**.

---

## `MediaDelivery`

### BR7.3 — key validation [FR7.1]

- **BR7.3** A key is served only if it matches
  `/^[a-f0-9-]+\.(jpg|png|webp|pdf|mp4|webm|vtt)$/`. A key that does not match is
  **404** — checked first, before any storage access.

### BR7.4–BR7.7 — the asset-visibility rule [hazard, FR7.2]

- **BR7.4 — the rule, exactly.** An asset is **publicly readable if and only if the
  literal string `/api/media/<key>` appears ANYWHERE in the serialised published
  document.** Not "is referenced by the `photo` field", not "appears in a known image
  slot" — **anywhere at all, including inside free prose**: a `transcript` (up to
  60,000 characters), a `description`, the `bio`, the `intro`, the `notice`, or any
  of the nine editable copy blocks. The test is a substring scan over the serialised
  published document.
- **BR7.5 — why a structured field check is NOT equivalent.** Computing public-ness
  from structured fields only (`photo`, item `image`, `imageSources`) makes
  **strictly fewer** assets public. Every image the owner referenced from prose — a
  figure linked inside a description, an image embedded in a transcript — **starts
  returning 404 to visitors**, on a site that renders normally in every other
  respect. The substring rule is not *elegant*; it is *the rule*, and it is
  positional-string-based rather than semantic, which means it silently changes
  meaning if the URL format ever changes (a query string, a CDN prefix). Do not
  "improve" it.
  Two properties the scan verified, so they need not be re-derived: **prefix
  collisions are impossible** (the key pattern forces a `.`-extension suffix and a
  match requires `/api/media/` immediately followed by the *full* key, so
  `/api/media/0.webp` cannot match inside `/api/media/1230.webp`), and **JSON
  escaping is not a problem** (serialisation does not escape `/`).
- **BR7.6 — evaluation order is load-bearing.** Public-ness is evaluated **before**
  the owner check, and the owner check is short-circuited when the asset is public.
  So **a public asset costs no authorization lookup at all**, while **every
  non-public asset request** costs the full published-document read *and then* an
  identity lookup. Reversing the order changes the cost profile of the system's
  hottest path.
- **BR7.7 — three consequences that are preserved, not fixed.**
  (a) **Over-permission through prose** — pasting a draft-only image URL into a
  caption transcript publishes that image. (b) **Publication is indiscriminate** —
  publishing makes public *every* asset URL anywhere in the document, **including
  ones in sections toggled off** via `sections.*`; the visibility toggle hides the
  section from the page, it does **not** make its media private. (c) **No revocation
  and no cleanup** — removing a reference makes the asset non-public again on the
  next request, but neither the bytes nor the metadata row is ever deleted, and there
  is no orphan collection anywhere.

> **What breaks silently.** A structured-field port passes every test written
> against the structured fields, serves the site correctly on every page a reviewer
> opens, and 404s exactly the images that were referenced from prose — a set nobody
> enumerated, discovered only by a visitor.

### BR7.8 — denial discloses nothing [FR7.3]

- **BR7.8** **Every denial is a 404, never a 403.** A malformed key, a missing
  metadata row, missing bytes, and "exists but not public and you are not the owner"
  are **indistinguishable** in the response. The route does not confirm the existence
  of unpublished media. A 403 anywhere on this path is a defect.

### BR7.9–BR7.17 — range handling, branch for branch [hazard, FR7.4]

The standards-compliant implementation is **not** the requirement; the existing one
is. Each branch below needs its own test.

- **BR7.9 — `HEAD` never inspects `Range` [FR7.4.1].** `HEAD` **always** returns
  **200** with the **full** `Content-Length`, and **never** returns 206 or 416 — even
  where the equivalent `GET` would. This is a deliberate early return before any
  range parsing. **`HEAD` and `GET` must not share range logic**, even though the
  source routes them to the same function.
- **BR7.10 — there is NO 304 path [FR7.4.3].** An `ETag` **is** emitted, and
  `If-None-Match` is **not honoured**. Every request is a **full transfer of the
  selected byte range**, and combined with `Cache-Control: private, no-cache` nothing
  is cached. This is a **deliberately preserved behaviour, not an omission to
  correct**. Adding a 304 path would satisfy the phrase "existing semantics" while
  silently changing what visitors and video players receive.
- **BR7.11 — `If-Range` IS honoured [FR7.4.2].** If `If-Range` is present and does
  **not** equal the current `ETag`, the `Range` header is **discarded** and a full
  200 is served. Comparison is **exact string equality** against the stored entity
  tag.
- **BR7.12 — multi-range → 416 [FR7.4.4].** A header requesting more than one range,
  e.g. `bytes=0-1,5-6`, is **not satisfiable**. It is answered neither with the whole
  entity nor with a multipart response. Mechanically, it fails the single-range
  pattern `/^bytes=(\d*)-(\d*)$/` applied to the trimmed value. `bytes=-` (both
  groups empty) likewise → 416.
- **BR7.13 — zero-byte object + ANY range → 416 [FR7.4.5].** If the object size is
  not a safe integer, or is `< 1`, **any** range at all is rejected as not
  satisfiable.
- **BR7.14 — oversized suffix → 206 for the whole object [FR7.4.6].** For `bytes=-N`,
  `N` must be a safe integer **> 0**; then `start = max(0, size - N)` and
  `end = size - 1`. **`N > size` therefore yields the whole object as a 206** — not a
  200.
- **BR7.15 — the start/end asymmetry [FR7.4.7].** For `bytes=S-E`: **reject (416) if
  `start >= size` or `end < start`**; then **`end = min(end, size - 1)`** — so an
  **end beyond the object is SILENTLY CLAMPED** and served as 206. For `bytes=S-`,
  `end = size - 1`. **The asymmetry is intentional and must be reproduced**: a start
  past the end is an error, an end past the end is not. An absent or empty `Range`
  header means no range at all and a full 200.
  The parser returns `{offset: start, length: end - start + 1}`.
- **BR7.16 — the 416 response shape.** On 416 the route sets
  `Content-Range: bytes */<size>` and `Content-Length: 0` with a null body, **but
  retains every other header from the success path — including the `Content-Type`
  and the `ETag`**. It is not a bare error response.
- **BR7.17 — the 206 response shape.**
  `Content-Range: bytes <offset>-<offset+length-1>/<size>` and
  `Content-Length: <length>`. Ranged reads are performed **through the store port**
  (`AssetStore.get_range`), never by loading the whole object and slicing — loading a
  whole video to serve one range is precisely what the port exists to avoid.

> **What breaks silently.** A standards-correct range implementation is *more*
> correct and *differently* behaved. Video players change their buffering strategy
> when a 416 becomes a 200, or when a 304 appears where a full transfer was expected.
> Nothing errors; playback just behaves differently, on a device nobody tested.

### BR7.18 — protective headers [FR7.5]

- **BR7.18** Every successful media response carries, verbatim:
  `Content-Type: <the metadata row's media type>` (**from the metadata store, not
  from the object store**), `Cache-Control: private, no-cache`,
  `X-Content-Type-Options: nosniff`,
  `Content-Security-Policy: default-src 'none'; sandbox`, `Accept-Ranges: bytes`,
  `ETag: <the object's entity tag>`, `Content-Length: <the object's size>`.
  The two stores hold the media type independently and agree only because they are
  written from the same value at upload time; **anything that syncs only one will
  serve mismatched types.**

---

## `OwnerEditor`

### BR8.6–BR8.8 — rendering the recovery verdict [FR8.3, ADR-006]

The editor **decides nothing**. These three rules exist because getting them wrong
loses the owner's work, which is a correctness outcome even though the state itself
is presentational.

- **BR8.6** On recovery the editor **does not classify**. It submits the recovered
  draft to `ContentAuthority`'s inspect operation and **renders the verdict
  returned** — offering the repaired draft for review, or reporting it unusable.
- **BR8.7** There is a **third recovery state**, distinct from both verdicts: when
  the inspect request **fails or the backend is unreachable**, the editor **HOLDS the
  draft**, shows an unavailable-and-retry state, and **never discards it**. Silently
  discarding on a transport failure would reproduce the exact class of loss FR8.3
  exists to prevent, so the unreachable case is a **specified state**, not an error
  path.
- **BR8.8** Restoring a recovered draft **pauses autosave until the owner explicitly
  saves**, so recovery never silently overwrites the stored draft.

---

## Assumptions & Open Questions

- **[carried hedge — CodeKB, not resolved here]** BR8.4's source defect is recorded by
  the knowledge base as **"a latent defect with a proven mechanism, not a confirmed
  user-visible failure"**: the issue-code mismatch was demonstrated empirically, but
  the scan could not exercise the editor to observe a discarded draft. It is listed as
  limit 6 of the seven recorded in `reverse-engineering-timestamp.md`. The port's
  behaviour (BR8.1–BR8.3) does not depend on resolving it, because FR8.3 specifies the
  intended rule rather than the observed one.
- **[carried hedge — CodeKB is self-inconsistent]** `api-documentation.md` gives the
  second `reply()` helper's location as `app/api/history/route.ts:14` in one section
  and `:4` in another, against a 14-line file; one is wrong and the scan does not say
  which. Separately it places `contentSchema` at `app/content.ts:20` and
  `sceneSchema` at `:21`, an ordering that cannot hold under eager evaluation since
  the former consumes the latter. **Neither affects any rule above** — only line
  attributions are in doubt.
- **[carried hedge — CodeKB truncated two strings]** The knowledge base quotes the
  save-failure 503 as `Your changes could not be saved...` and the variant-envelope
  400 as `The prepared image sizes could not be verified...`, both elided. BR10.7
  gives the **full** strings, transcribed directly from
  `madhavi-tripathi/app/api/content/route.ts` and `app/api/upload/route.ts`, because a
  truncated string is not a usable parity target. The recorded source fixtures (U1)
  are the confirmation of record.
- **[open — two literals for the cancellation message]** The source contains both
  `Upload cancelled.` and `Upload cancelled. Your previous file is unchanged.`. The
  knowledge base documents only the longer one, attached to the `AbortError` catch;
  the shorter appears to belong to the early `checkCancelled()` path. **Which 499
  carries which sentence is unconfirmed.** Resolve against the recorded fixtures
  before asserting either in a parity test.
- **[open, owner `nfr-design`]** BR7.2's cache interval is unset. It trades staleness
  for cost and is a **security** parameter, because a stale published document is an
  authorization defect on the media path.
- **[open, owner this stage — addressed outside this file]** Whether any part of the
  editor's six-flag save state machine is a **rule** rather than presentation state.
  `components.md` places it in `OwnerEditor` as presentation state; the parts that
  were adjudicated to be rules — the recovery classification (ADR-006) and the
  hold-on-unreachable state — are specified above as BR8.1–BR8.5 and BR8.6–BR8.8. The
  remaining flags (`recoveryReady`, `busy`, `uploads`, `conflict`, `paused`) and their
  autosave arming are behaviour, not business rules, and belong to this stage's
  behaviour artifact rather than here. **The consequence recorded in
  `WORKING-RECORD.md` § 9 still stands: if the state machine remains in the frontend,
  a browser-driven check becomes the only possible verification of FR8.2 and FR8.5.**
- **[note]** BR4.20's rule is owned by `ContentAuthority` (it owns "the request-size
  limit and its unit" per `components.md`) while the check is necessarily applied at
  the point where the decoded body first exists, which is inside `HttpApi`'s request
  handling. That is a placement of **enforcement**, not of **ownership**, and BR4.22
  fixes the ordering so the two cannot drift.
- **[note]** No rule here requires a background worker, scheduler or queue consumer.
  Retention runs **inside the write that triggers it**, exactly as it does today.

## Sources

- `aidlc/spaces/default/codekb/Chiku_website/code-quality-assessment.md` §§ *Hazard
  index*, *Hazard 1 — the seven-statement D1 batch*, *Why `last_mutation` exists
  alongside the `revision` CAS*, *Hazards in the batch — enumerated*, *The
  hand-written image header parsers*, *The WebVTT validator*, *Hazard 3 — the
  back-compat shims*, *The editor state machine*, findings A, C, G, H, I, J, K.
- `aidlc/spaces/default/codekb/Chiku_website/api-documentation.md` §§ *Shared shape*,
  *`GET`/`PUT /api/content`*, *`GET /api/history`*, *`POST /api/upload`*, *`GET` and
  `HEAD /api/media/[key]`*, *The public-access rule*.
- `inception/requirements-analysis/requirements.md` — FR3.1–FR3.8, FR4.1–FR4.7,
  FR5.1–FR5.4, FR6.1–FR6.7, FR7.1–FR7.6, FR8.3, FR9.2, FR9.4, FR10.1–FR10.3, NFR2,
  NFR5.
- `inception/domain-design/components.md` — which component owns each rule;
  `inception/domain-design/decisions.md` ADR-001 (one combined write), ADR-002 (cache
  placement), ADR-006 (classification is a backend rule).
- `inception/contract-design/contract-summary.md` §§ C1 (statuses, envelope), C2
  (`commit`, `list_revisions`, prune shape, atomicity), C3, C4.
- `WORKING-RECORD.md` §§ 2 (D1–D3, D6, D9, D11, D12, D24), 3 (the seven hazards and
  their silent failure modes), 5 (conventions that must survive the port).
- Verbatim error copy transcribed from `madhavi-tripathi/app/api/content/route.ts`,
  `app/api/history/route.ts`, `app/api/upload/route.ts` and
  `app/api/media/[key]/route.ts`, because the knowledge base elides two of the
  strings and renders a third's apostrophe ambiguously.
