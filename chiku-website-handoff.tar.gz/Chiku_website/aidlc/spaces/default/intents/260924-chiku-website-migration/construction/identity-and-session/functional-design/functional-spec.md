# Functional Specification — U3 `identity-and-session`

**Unit:** `u3-identity-and-session` · **Kind:** `library` · **Components:**
`OwnerIdentity`, `SessionAuthority`, `LoginGuard`

**Upstream:** `construction/identity-and-session/functional-design/entities.md`,
`construction/identity-and-session/functional-design/rules.md`,
`inception/contract-design/contract-summary.md` § C3,
`inception/units-generation/unit-of-work.md` § U3,
`construction/functional-design/functional-spec.md` §§ *Sign in*, *Every
authenticated request*, *Owner provisioning*, *Startup*.

**This document is the source of truth for this unit's workflows and its one state
machine.** It additionally carries **two derived views** — an entity-relationship
diagram derived from `entities.md`, and a rules summary derived from `rules.md`.
Where a derived view disagrees with its source, the source wins and the view is the
defect.

## What this unit delivers

**The complete authentication and session surface, enforceable independently of any
frontend.** It answers one question — *who is this, and may they act?* — and it
owns no content.

Three components:

| Component | Owns |
|---|---|
| `OwnerIdentity` | The owner account, its argon2id hash, and one-shot provisioning |
| `SessionAuthority` | Session issue, verification, the sliding and absolute bounds, revocation, and the CSRF token |
| `LoginGuard` | Failed-attempt bounding, per account and per source address |

**Everything here is new.** The source authenticated through a platform header;
this replaces it entirely, with **no dependency of any kind** on that platform.
There is therefore **no recorded source fixture for this unit and none can be
made** — and, uniquely among the backend units, no dependency edge on the
fixture-recording unit.

**What is being replaced, verified by execution rather than by reading.** The
source's local identity came from a **vendored dev-server middleware**: on seeing
one cookie it injected a fixed user id and email as request headers — and it
**stripped every client-supplied identity header before injecting its own**.
Sending those headers directly still returned 403. **The trust boundary was the
middleware, not the header**, so the property this unit must preserve is **"a
client cannot assert its own identity"**, not the header mechanism. That property
is carried here by the signed cookie holding **only an opaque session identifier**
and by server-side verification on every request. A port that trusted any
client-controlled identity claim would replace the platform auth in form and lose
the only security property it had.

## Conventions that hold throughout

- **This unit decides; the route layer transports.** Every operation below
  authorises itself at its own boundary (BR3.1, BR3.2, owned by U6). A request that
  bypasses the frontend entirely is rejected identically to one that does not.
- **Operations are asynchronous**, and persistence is reached only through
  `IdentityStore`. The store holds timestamps and counts and evaluates neither
  (BR22.14, owned by U2).
- **Nothing here composes an HTTP status or a user-facing sentence.** This unit
  raises; the error envelope and its four-member taxonomy belong to U6. A refused
  sign-in raises the not-authorized member, and U6 renders it.
- **The wire format is `camelCase`, frozen**, with one conversion point shared with
  every other model in the system.

---

## Derived view — the three entities

Derived from `entities.md`. **Authoritative source: `entities.md`.**

```mermaid
erDiagram
    OWNER_ACCOUNT ||--o{ SESSION : issues
    OWNER_ACCOUNT ||--o{ LOGIN_ATTEMPT_WINDOW : "counted against"

    OWNER_ACCOUNT {
        string ownerId PK "opaque, never derived from the email"
        string email "max 200"
        string passwordHash "argon2id, verbatim, never logged"
        instant createdAt
        instant passwordUpdatedAt "nullable"
    }
    SESSION {
        string sessionId PK "opaque, unguessable"
        string ownerId FK
        instant issuedAt "set once"
        instant lastSeenAt "advanced on each verified request"
        instant absoluteExpiresAt "computed once, NEVER extended"
        instant revokedAt "nullable, server-side revocation"
        string csrfToken "paired one to one, returned in the body"
    }
    LOGIN_ATTEMPT_WINDOW {
        string windowKey PK "with scope"
        enum scope PK "account or ip"
        integer failureCount "min 0"
        instant windowStartedAt
    }
```

**Text fallback.** Three entities. **`OwnerAccount`** is a singleton — exactly one
row ever exists. It issues zero or more **`Session`** records, each belonging to
exactly one account. **`LoginAttemptWindow`** records are counted against an
account or against a source address; an account-scoped window may key on an email
that matches no account at all, which is why the relationship is optional on the
account side. No other entity in the system references any of these three.

---

## Derived view — rules summary

Derived from `rules.md`. **Authoritative source: `rules.md`**, which carries each
rule's full text, its logic and its failure mode.

| Group | Rules | Component | Category mix | Requirement |
|---|---|---|---|---|
| Credentials and one-shot provisioning | BR3.6–BR3.10 | `OwnerIdentity` | authorization, policy, constraint | FR3.1, FR3.6, FR3.7 |
| The cookie and its signing key | BR3.11–BR3.13 | `SessionAuthority`, startup | constraint, authorization | FR3.2, NFR5 |
| Expiry and revocation | BR3.14–BR3.17 | `SessionAuthority` | constraint, authorization | FR3.3, FR3.4 |
| Bounding failed sign-in | BR3.18–BR3.22 | `LoginGuard` | policy, authorization, constraint | FR3.5 |
| Unit-scoped, trace to no FR | BR23.1–BR23.2 | `OwnerIdentity`, `SessionAuthority` | policy | — |
| *Subject to, owned by `HttpApi`* | BR3.1–BR3.5 | — | authorization | FR3.8, NFR2, FR6.7 |

**No rule in this unit is a hazard**, because everything here is new and a hazard
is a behaviour whose *silent* loss during a port ships a defect. Both severe rules
— BR3.13's boot failure and BR3.20's enumeration defence — fail **loudly**.

---

## Operations

### Sign in

**Input:** an email and a password, plus the source address. **Output:** a session
and its CSRF token, or a refusal.

> **Step 1 keys on the normalised submitted email, always.** Not on `ownerId`,
> which does not exist until step 2. This is forced by the step order rather than
> chosen: reading the account-scoped window before the owner lookup is what keeps
> the lookup outcome from influencing whether or when the counter read happens.
> Keying on the email makes step 1's **key derivation identical and the number and
> shape of storage operations equal** whether or not an account exists, which
> closes the dominant timing channel the enumeration defence left open on
> `BR23.1`'s counter half. A weaker residual remains at the storage-engine level —
> a window key never seen before has no row to find — but it correlates with
> *"has this key been probed"*, **not** with *"does this account exist"*, and it is
> recorded as an accepted, unmeasured residual rather than claimed away. See
> `entities.md` § ENT-3, `[A-2 — RESOLVED at review]`.

1. **Read both rate-limit windows** — the account-scoped one and the
   address-scoped one (BR3.18, BR3.19). If **either** is exhausted, the attempt
   will be refused. The counters are independent and both apply.
2. **Always run a verification** (BR23.1). Look up the owner record; if there is
   none, verify the submitted password against a **fixed dummy argon2id hash** and
   discard the result. Absence and wrong-password then cost the same, which is what
   keeps BR3.20's identical response from being undone by an identical-looking but
   measurably faster one.
3. **On any refusal** — unknown account, wrong password, **or a limit already
   reached** — record the failure against **both** windows and raise the
   not-authorized member of the taxonomy. **The three cases are
   indistinguishable**: same status, same body, same sentence, no `Retry-After`,
   no "too many attempts" (BR3.20). The sentence `HttpApi` renders for all three
   is `Please sign in with the website owner’s account.`, **captured verbatim from
   the running source, with a U+2019 apostrophe rather than an ASCII one**
   (BR10.7, BR10.8, owned by U6).
4. **On success**, clear the account-scoped counter (BR3.21), then issue a session:
   - `issuedAt` = now; `lastSeenAt` = `issuedAt`; `absoluteExpiresAt` =
     `issuedAt` + 7 days, **computed once here and never again** (BR3.15).
   - `revokedAt` = null; a fresh `csrfToken` paired 1:1 with the session (BR3.12).
   - Set the **signed** cookie carrying **only the session identifier**, marked
     `HttpOnly`, `Secure`, `SameSite=Lax` (BR3.11).
   - Return the CSRF token **in the response body** — never in a cookie, because a
     token the browser attaches automatically defends nothing.

**Ordering note.** Step 1 reads the counters but does not short-circuit before
step 2. A limit check that returned early would skip the hash and reintroduce
exactly the timing signal BR23.1 exists to remove.

### Verify a request

Runs on every request that carries a session cookie.

1. **Verify the cookie's signature.** Invalid → treat the request as anonymous.
   No error, no distinct response: an unsigned or tampered cookie is simply not a
   session.
2. **Load the session record** through `IdentityStore.session.read`, which returns
   the record **as stored** and evaluates no expiry (BR22.14, owned by U2).
3. **Apply both bounds and the revocation, here** (BR3.16):
   - `revokedAt` non-null → **nothing**.
   - now − `lastSeenAt` > 8 hours → **nothing** (BR3.14).
   - now > `absoluteExpiresAt` → **nothing** (BR3.15).
   - An expired record is **deleted as it is rejected** (BR23.2). The deletion is
     housekeeping and never changes the outcome.
4. **Otherwise** advance `lastSeenAt` to now — **and nothing else**.
   `absoluteExpiresAt` is untouched (BR3.15). This is the single most
   consequential line in the unit: refreshing both timestamps satisfies BR3.14
   perfectly and silently destroys the 7-day bound.
5. **For a mutation**, compare the request's CSRF header against the session's
   stored token (BR3.12); a mismatch is a refusal. The same-origin check (BR3.3,
   owned by U6) has already run and is **not** replaced by this.

**Verification returns the owner identity or nothing — never a third answer**
(BR3.16). "Expired", "revoked" and "absent" are one outcome to every caller.

### Sign out

Write the revocation instant to the **stored** session record, then clear the
cookie (BR3.17). **The stored write is the rule; the cookie clear is a courtesy.**
A stolen cookie must stop working, not merely vanish from the browser that had it
legitimately. A revoked session fails the very next verification.

### Provision the initial owner

Two paths, one gate.

**The normal path is the command-line one:** it prompts for an email and a
password, stores only the argon2id hash, and refuses if an owner already exists.

**The one-shot route exists for a container with no interactive shell.** It is
enabled only while **both** hold (BR3.8): **no owner record exists**, and the
bootstrap secret is configured. It requires that secret, accepts the owner's chosen
password, and stores only the hash.

- **The gate is the record's existence** (BR3.7) — not a consumed flag, not a
  marker file, not an environment variable. Every other formulation has a state
  that can be reset from outside the data; the record is the only state whose
  existence *is* the thing being protected. **A restart cannot reopen it.**
- **The creation is atomic against a concurrent caller** (BR22.13, owned by U2):
  two simultaneous attempts produce one record and one refusal. This matters more
  here than anywhere else, because the operation **can never be re-run once it has
  succeeded** — a lost provisioning on a container with no shell leaves a system
  nobody can sign in to and no route that will let them.
- **With the secret unset and no owner, the service starts normally and refuses
  every sign-in** (BR3.9). It does not create an account, and it does not fail to
  start.

**The acceptance test for FR3.7 is exactly this:** a fresh start against an empty
volume has **no account anyone can sign in to** (BR3.10).

### Startup

**Read the signing key. If `SESSION_SIGNING_KEY` is unset, empty, or under 32
bytes, raise during startup with a message naming the variable and exit non-zero**
(BR3.13).

All three conditions are checked separately. **No default value, no fallback, and
explicitly no auto-generated per-process key** — an auto-generated key silently
invalidates every session on restart and hides the misconfiguration, which makes it
**the worse failure, because it looks like it works**.

**Then read the bootstrap secret, and do not fail on its absence.** The asymmetry
between the two secrets is decided, not accidental: a missing signing key is a
misconfiguration that must stop the process; a missing bootstrap secret is a
legitimate state — an already-provisioned system, or one provisioned another way.

**Never seed an owner.**

---

## The session state machine

**This is the unit's only state machine**, and it is a rule rather than
presentation state: every transition below changes what a request is permitted to
do.

```mermaid
stateDiagram-v2
    [*] --> Active : sign in succeeds
    Active --> Active : verified request advances lastSeenAt
    Active --> Revoked : sign out writes revokedAt
    Active --> IdleExpired : 8h since lastSeenAt
    Active --> AbsoluteExpired : 7d since issuedAt
    Revoked --> [*] : verifies as nothing
    IdleExpired --> [*] : rejected, record deleted
    AbsoluteExpired --> [*] : rejected, record deleted
```

**Text fallback.** A session starts **Active** when sign-in succeeds. Each verified
request keeps it Active and advances `lastSeenAt` **without touching
`absoluteExpiresAt`**. It leaves Active by exactly three routes: **Revoked**, when
sign-out writes `revokedAt`; **IdleExpired**, 8 hours after the last verified
request; **AbsoluteExpired**, 7 days after issue regardless of activity. All three
verify as nothing and are indistinguishable to a caller. The two expired states
additionally delete the record as they reject it (BR23.2); a revoked record is
retained, because its whole purpose is to keep failing.

**The two expiry transitions are independent, and whichever fires first wins.** A
session used every hour for eight days reaches **AbsoluteExpired**; a session
issued and left alone reaches **IdleExpired** after eight hours. Collapsing them
into one refreshed timestamp removes the AbsoluteExpired transition entirely while
leaving every idle-expiry test green.

**There is no Renewed state and no re-issue path.** Nothing extends a session; the
owner signs in again, which issues a new one with a new absolute bound.

---

## What this unit does not do

Stated explicitly so a reader can tell a deliberate boundary from an omission.

- **It owns no content.** Not the document, not a revision, not an asset.
- **It composes no HTTP response.** Statuses, the error envelope and the verbatim
  user-facing sentences belong to U6; this unit raises taxonomy members.
- **It performs the same-origin check nowhere.** BR3.3–BR3.5 are U6's, applied to
  mutations including this unit's own.
- **It evaluates no expiry inside the store.** The store returns records as stored;
  the bounds are applied here (BR22.14).
- **It sweeps nothing on a schedule.** No background worker, no scheduler, no queue
  consumer. The only reclamation is BR23.2's delete-on-rejection.
- **It has no multi-editor concept.** Exactly one owner account, no tiered roles.
  The initial brief's "a few administrators" is superseded by the confirmed intent
  and must not be reintroduced as a dropped requirement.

---

## Assumptions & Open Questions

- **[assumption]** The dummy-hash verification on an unknown account (BR23.1) is
  **the standard mitigation and is not separately measured**. It equalises the
  dominant cost; it is not a proof that no timing signal remains, and no artifact
  in this workflow claims a measurement.
- **[A-2 — RESOLVED at review]** The account-scoped counter is keyed on the
  **normalised — trimmed, lower-cased — submitted email, always**, matching account
  or not. The *"account identifier"* branch is **removed, not deferred**: the
  window is read at **step 1** of *Sign in*, before the owner lookup, so `ownerId`
  does not exist yet and that branch is unimplementable as written. Keying on the
  email is also what preserves a per-account limit for an account that does not
  exist. The full resolution, and the narrowed statement of what it establishes
  about timing, is in `entities.md` § ENT-3, `[A-2 — RESOLVED at review]`.
- **[assumption A-3, carried]** The length and alphabet of `ownerId`, `sessionId`
  and `csrfToken` are unfixed; any choice at or above the strength of a 32-byte
  URL-safe random token satisfies every stated requirement.
- **[assumption]** The sign-in flow reads both counters **before** hashing but does
  not return early on an exhausted window. Nothing decided this ordering; it
  follows from BR23.1, because an early return would restore the timing difference
  BR23.1 removes.
- **[assumption]** A revoked session record is **retained** while an expired one is
  deleted (BR23.2). Nothing decided this asymmetry; it follows from purpose — a
  revoked record must keep failing verification, so deleting it would make a
  revoked session indistinguishable from an unknown one at the storage layer, and
  the retention is what makes revocation auditable at all.
- **[open]** No **session retention policy** exists. Revoked records, and expired
  records never revisited, accumulate with nothing to sweep them. No stage has
  owned this and no rule requires it; for a single-owner site the volume is
  negligible, which is why it is recorded rather than raised as a defect.
- **[note]** This unit **deliberately carries no dependency on the
  fixture-recording unit**. Every other backend unit depends on it because it has
  source behaviour to reproduce; authentication is entirely new, so there is
  nothing to record. The absence of that edge is a design statement.
- **[note]** BR3.1–BR3.5 are **owned by `HttpApi` (U6)** and quoted in this unit's
  `rules.md` under *Subject to, not owned*, because BR3.2 delegates the
  authorization decision to this unit and neither half is complete alone.

## Sources

- `inception/contract-design/contract-summary.md` § C3 — `IdentityStore`'s three
  operation groups (`owner_record`, `session`, `login_attempts`) and their notes.
- `construction/functional-design/functional-spec.md` §§ *Sign in —
  `POST /api/auth/login`*, *Every authenticated request*, *Owner provisioning —
  CLI and one-shot route*, *Startup* — the workflow steps above are this unit's
  half of those flows.
- `construction/functional-design/rules.md` — BR3.1–BR3.22.
- `construction/identity-and-session/functional-design/entities.md` — ENT-1 to
  ENT-3 and the derived diagram above.
- `construction/identity-and-session/functional-design/rules.md` — BR23.1, BR23.2
  and the derived rules summary above.
- `construction/storage-ports/functional-design/rules.md` — BR22.13, BR22.14, the
  port obligations this unit relies on.
- `inception/units-generation/unit-of-work.md` § U3.
- `WORKING-RECORD.md` § 2 (D1, D2, D3, D6), § 5, § 10a (the R-01 disposition).
