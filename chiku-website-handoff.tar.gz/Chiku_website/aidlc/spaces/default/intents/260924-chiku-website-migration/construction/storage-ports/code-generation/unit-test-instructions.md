# Unit Test Instructions — U2 `storage-ports`

## Framework and configuration

`pytest` 9.1.1 with `pytest-cov` 7.0.0 and `anyio` 4.12.0, resolved by `uv` from
`chiku-website/backend/pyproject.toml`. No new framework is introduced for this unit.
Async tests run under `anyio`'s pytest plugin, pinned to the `asyncio` backend only —
the production runtime is `asyncio` and running the suite twice per backend would double
the cost for no new evidence.

## The exact command to run THIS unit's tests

Run from `chiku-website/backend/`:

```
uv run pytest tests/conformance -q
```

Scoped to this unit's directory. Build and Test runs every unit's command, so a bare
project-wide `pytest` would rerun the whole suite once per unit.

With the two coverage floors this unit is measured against:

```
uv run pytest tests/conformance --cov --cov-branch -q
uv run coverage report --fail-under=80
uv run coverage report --fail-under=100 --include="app/content/store_sqlite.py,app/auth/store_sqlite.py"
```

Runner readiness is verified before the first test step: `uv run pytest --version` must
succeed. It does today — 325 tests currently execute across the four existing files.

## Expected coverage

- **80% branch coverage** over `chiku-website/backend/`, per `team.md`. This unit adds
  ten application modules, so unlike U1 it contributes to that floor directly.
- **100% branch coverage** on the two hazard modules, `app/content/store_sqlite.py` and
  `app/auth/store_sqlite.py`. They are the ports of two behaviours ranked in the hazard
  index: the seven-statement concurrency batch with its `last_mutation` ABA defence, and
  the one-shot provisioning gate.

Neither floor may be relaxed, lowered, or disabled to make a step pass. A shortfall is
reported as a shortfall.

An aggregate percentage cannot distinguish "this branch is exercised" from "this branch
was ported correctly", which is why the hazard modules carry both a per-branch test and a
floor that leaves no room.

## Test scope — Standard strategy, 5–8 tests per component, three components

### `ContentStore` — `tests/conformance/test_content_store.py`

1. `read_state` on empty storage returns the **seed** and **writes nothing** — asserted
   by re-reading through a second, independent handle. A lazily creating store returns
   the right values and fails only this assertion.
2. A content payload round-trips **byte-identically**, including a payload of 1,500,000
   characters with astral-plane content. A normalising store returns an *equal* document
   and passes any looser test.
3. `commit` at a stale `base_revision` returns the **conflict signal** (a return value,
   not an exception) **and performs no side effect** — no revision entry, no prune, no
   timestamp movement.
4. A stale writer whose `next_revision` collides with the winner's `revision` inserts
   **no** history entry and prunes **nothing**. This needs two writers at the same base
   revision and is never reproduced single-user; it is what `last_mutation` defends.
5. The full **three-part listing order** — `revision` DESC, `baseline` ASC, `action` DESC
   — asserted across a **tied revision**. A single-key sort is identical until there is a
   tie.
6. The two retention counts are **independent**: 30 drafts do not evict a publish. A
   combined cap of 50 looks correct until the mix is uneven.
7. Both baselines survive a prune that would otherwise reach them, with baselines
   excluded **by predicate** — asserted by a fixture in which ordering alone would not
   have spared them.
8. `asset_metadata.remove` on an absent key **succeeds**.

### `IdentityStore` — `tests/conformance/test_identity_store.py`

1. `touch` advances `last_seen_at` and **leaves `absolute_expires_at` alone**. Every
   idle-expiry test passes either way; only this one catches a destroyed absolute bound.
2. Two concurrent `create_if_absent` calls yield **one record and one refusal**. Run
   concurrently, not sequentially — a sequential test never sees it.
3. A **revoked** session fails the **very next** `read`.
4. `read` **evaluates no expiry**: a record past both bounds is returned as stored.
5. The two attempt scopes (`account`, `ip`) count **independently**, as separate records.
6. `count_in_window` compares against **no threshold** and a counter **survives a new
   store instance over the same storage** — an in-memory counter is not an acceptable
   real adapter.

### `AssetStore` — `tests/conformance/test_asset_store.py`

1. `get_range` returns **exactly** the requested window — asserted against an object
   large enough that a whole-object read is distinguishable, and against offset 0.
2. `head`'s **entity tag is stable** across repeated reads of unchanged bytes, and
   **changes** when the bytes change.
3. `delete` on an absent key **succeeds**.
4. `put` stores bytes **unchanged** — no transcoding, no normalisation — including bytes
   that are not valid UTF-8.
5. `head`'s media type is held **independently** of the `asset_metadata` row's; the port
   does not reconcile them.

## The adapter parameterisation

One fixture in `tests/conformance/conftest.py` yields **each implementation of the port
under test**, and every test above runs against all of them. Registering a new adapter is
a one-line change there and immediately subjects it to the whole contract. A test written
against a single implementation is outside this suite's purpose and does not belong here.

## Mocking and stubbing

**None, and the in-memory fake is not a mock.** It is a second real implementation of the
port, and it is under test exactly as the SQLite adapter is. Mocking a store in its own
conformance suite would assert the test's belief about the store rather than the store.

Where a test needs two concurrent writers, they are genuinely concurrent — two tasks
against one storage handle — not a simulated interleaving.

## Test data management

No fixture files. Each test constructs the storage it needs and discards it: the SQLite
adapters run against a temporary database file per test (not `:memory:`, which would hide
the cross-connection behaviour tests 1 and 6 above depend on), and the volume-backed
`AssetStore` runs against a `tmp_path` directory.

The recorded source fixtures in `chiku-website/fixtures/` are **not** this unit's oracle.
They record HTTP behaviour; this unit has no HTTP surface. Its oracle is
`functional-spec.md` § *The conformance suite* and the rules it cites.
