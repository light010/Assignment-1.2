# Entity Schemas — U6 `http-api`

**Unit:** `u6-http-api` · **Kind:** `service` · **Component:** `HttpApi`

**Upstream:** `construction/functional-design/entities.md` (the six persisted entities,
none of which this unit owns), `inception/domain-design/components.md` § `HttpApi`
(`entities: []`), `inception/contract-design/contract-summary.md` § C1 (the HTTP
surface, its statuses and its envelope), `inception/requirements-analysis/requirements.md`
FR3.8, FR10.1–FR10.3, NFR1, NFR2.

## How to read this document

**`HttpApi` owns no persisted entity.** `components.md` records `entities: []` for it,
and that is correct: this unit holds no state, writes to no store, and is forbidden by
an AST test from even importing one. Every persisted entity in the system —
`OwnerAccount`, `Session`, `LoginAttemptWindow`, `ContentDocument`, `ContentRevision`,
`Asset` — is owned by a unit behind this one and specified in that unit's own
`entities.md`.

What this unit **does** own is the set of **wire contracts**: the shapes that cross the
language boundary and are published in the OpenAPI document that `U7 api-client`'s
TypeScript types are generated from. They are not domain entities and they are not
persisted, but they are structures with fields, types, required-ness and constraints,
and **one of them is a hazard** — the error envelope (FR10.1) is the
highest-probability silent regression in the migration, and it is silent precisely
because its shape is the only thing that distinguishes working from
appearing-to-work.

So this document specifies the wire contracts with the same rigour the six entities
get, and says plainly that they are a different kind of thing.

**On identifiers.** These are deliberately **not** numbered in the `ENT-n` sequence.
`ENT-1` through `ENT-6` are the six persisted domain entities and that sequence is
reserved for them; adding to it would imply this unit had acquired state. The
`WIRE-n` prefix is used instead and cannot collide with any other unit's allocation.

**Structure of this document.** The fenced `yaml` block below is the **source of
truth**: it governs, and it is what downstream stages read. Everything after it is the
**summary and rationale**. **The prose must not contradict the block; where it appears
to, the block wins and the prose is a defect.**

---

## Source of truth

```yaml
source_of_truth: entities
stage: functional-design
unit: u6-http-api
kind: service
kind_note: >
  U6 http-api is the ONLY unit declaring service - there is exactly one deployed
  Python executable, and this is it.
authority: >
  This block is the source of truth and governs. The prose below carries the summary,
  the rationale and the failure mode for each shape, and must not contradict it.
components: [HttpApi]

persisted_entities_owned: []
persisted_entities_note: >
  HttpApi owns no persisted entity. components.md records entities: [] for it. This
  unit holds no state, writes to no store, and an AST test asserts that no module
  under routers/ imports a store module. The entities below are WIRE CONTRACTS -
  request and response shapes published in the OpenAPI document - not domain
  entities and not persisted. They are numbered WIRE-n rather than ENT-n because
  the ENT-n sequence is reserved for the six persisted entities.

entities:
  - id: WIRE-1
    name: ErrorEnvelope
    owner_component: HttpApi
    nature: 'ported wire contract - HAZARD (FR10.1)'
    description: >
      The one and only error shape across the whole HTTP surface. Produced by
      exception handlers, never constructed per route. The ported editor branches on
      409 to enter conflict recovery and reads issues to highlight fields, so a
      different shape breaks both WHILE APPEARING TO WORK - requests succeed,
      statuses are returned, nothing throws, and field highlighting simply shows
      nothing. FastAPI's default {"detail": ...} and Pydantic's loc/msg are exactly
      that different shape.
    identifier: null
    attributes:
      - name: error
        logical_type: string
        required: true
        unique: false
        references: null
        allowed_values: null
        default: null
        constraints:
          - 'One human sentence'
          - 'The key is "error" - NOT "detail", NOT "message"'
          - 'PRODUCT COPY: the PORTED sentences fall under the parity rule (FR10.2) and their complete verbatim set is BR10.7'
          - >
            ONE value is NOT in that set: BR26.4 "This draft is too large to check.",
            the 413 on POST /api/content/inspect. That route does NOT exist in the
            source (ADR-006 moved the classification out of the browser), so it has no
            ported string and no parity fixture. It is NEW COPY, and a parity diff must
            not expect to find it in BR10.7.
          - 'Present on EVERY error response, at every status'
      - name: issues
        logical_type: 'array of WIRE-2'
        required: false
        unique: false
        references: WIRE-2
        allowed_values: null
        default: null
        constraints:
          - 'Present ONLY on a validation failure - that is, only on a 400 raised by Invalid'
          - 'Absent on 403, 409, 413, 499 and 503'
          - 'The key is "issues" - not "errors", not "detail"'
    entity_constraints:
      - id: EC-W1.1
        statement: 'Produced by exception handlers, never constructed per route. Services raise; routers do not build responses (BR10.3)'
      - id: EC-W1.2
        statement: >
          Exactly one envelope for the whole surface. There is no second shape for any
          route, no bare string body, and no framework default anywhere - including on
          a request that never reaches a route handler, such as a malformed path or an
          unhandled framework validation error.
      - id: EC-W1.3
        statement: 'The catch-all status is 503, NOT 500, matching all four source routes. An unhandled exception is additionally logged with a full traceback (BR10.5)'
    relationships:
      - name: carries
        from: ErrorEnvelope
        to: ValidationIssue
        cardinality: one-to-many
        direction: 'ErrorEnvelope -> ValidationIssue'
        via: issues
        optional: true
        notes: 'Populated only when the raised exception is Invalid'

  - id: WIRE-2
    name: ValidationIssue
    owner_component: HttpApi
    nature: 'ported wire contract - HAZARD (FR10.1)'
    description: >
      One field-level validation problem. The editor reads these to highlight the
      fields that failed. Pydantic emits loc and msg; this shape is path and message,
      and the rename is the whole of the hazard for this structure.
    identifier: null
    attributes:
      - name: path
        logical_type: 'array of (string | integer)'
        required: true
        unique: false
        references: null
        allowed_values: null
        default: null
        constraints:
          - 'The key is "path" - NOT "loc"'
          - 'Members are strings or integers; an integer member is a COLLECTION INDEX'
          - 'Addresses a field inside the content document, e.g. publications, 3, citationsAsOf'
      - name: message
        logical_type: string
        required: true
        unique: false
        references: null
        allowed_values: null
        default: null
        constraints:
          - 'The key is "message" - NOT "msg"'
          - 'PRODUCT COPY where the schema declares a verbatim message (entities.md ENT-4 carries them)'
    entity_constraints:
      - id: EC-W2.1
        statement: 'Appears only inside ErrorEnvelope.issues; never at the top level of a response'

  - id: WIRE-3
    name: SaveEnvelope
    owner_component: HttpApi
    nature: 'ported wire contract'
    description: >
      The request body of PUT /api/content. Validated as ONE predicate at step 7 of
      the check order, AFTER content schema validation at step 6 - an ordering that is
      itself a rule (BR10.11), because the editor highlights fields on one outcome and
      shows a bare sentence on the other.
    identifier: null
    attributes:
      - name: content
        logical_type: Content
        required: true
        unique: false
        references: 'ENT-4 ContentDocument.draft (owned by u4-content-core)'
        allowed_values: null
        default: null
        constraints:
          - 'The full content document. Validated at step 6, BEFORE this envelope is validated'
          - 'Its schema is owned by u4-content-core; this unit neither defines nor duplicates it'
      - name: revision
        logical_type: integer
        required: true
        unique: false
        references: 'ENT-4 ContentDocument.revision'
        allowed_values: null
        default: null
        min: 0
        max: 'strictly less than Number.MAX_SAFE_INTEGER'
        constraints:
          - 'Must be a SAFE integer'
          - 'revision >= 0'
          - 'revision < Number.MAX_SAFE_INTEGER'
          - 'The caller base revision for optimistic concurrency'
      - name: action
        logical_type: enum
        required: true
        unique: false
        references: null
        allowed_values: [draft, publish]
        default: null
        constraints:
          - 'Exactly draft or publish. No third value, no default, no case folding'
      - name: autosave
        logical_type: boolean
        required: false
        unique: false
        references: null
        allowed_values: [true, false]
        default: null
        constraints:
          - 'Absent or a boolean'
          - 'NOT (autosave = true AND action != draft). Autosave is legal only with a draft action'
    entity_constraints:
      - id: EC-W3.1
        statement: >
          All of revision-is-safe-integer, revision >= 0, revision < MAX_SAFE_INTEGER,
          action in {draft, publish}, autosave absent-or-boolean, and NOT (autosave AND
          action != draft) are evaluated as ONE predicate (BR10.12). A failure is a 400
          WITHOUT issues.
      - id: EC-W3.2
        statement: 'Envelope validation runs at step 7, AFTER content validation at step 6 (BR10.11). A body with both a malformed content AND a bad revision returns the CONTENT 400 with issues'

  - id: WIRE-4
    name: RequestContext
    owner_component: HttpApi
    nature: 'new - internal, never serialised'
    description: >
      What the middleware resolves for each request and hands to the unit behind the
      route. Never appears in a response body and is not in the OpenAPI document. It
      is specified because its FIELDS are load-bearing: a missing Origin header is the
      case the source fails closed on, and getting that wrong removes the only CSRF
      defence the source has.
    identifier: null
    attributes:
      - name: method
        logical_type: string
        required: true
        constraints:
          - 'Decides whether origin enforcement applies at all: EVERY METHOD THAT IS NOT GET OR HEAD, never GET or HEAD (BR3.5). The test is the METHOD, not whether the operation writes - so POST /api/content/inspect, which writes nothing, is included'
          - 'ONE ENUMERATED EXCEPTION: the one-shot owner-provisioning route is exempt from BOTH origin (BR3.3) and CSRF (BR3.4). It has no ambient authority to borrow - it is gated on a secret supplied explicitly in the request, which no browser attaches on a third party behalf - and no session exists during bootstrap, so there is no CSRF token to pair with. See BR3.5 exceptions'
      - name: requestOrigin
        logical_type: string
        required: false
        nullable: true
        constraints:
          - 'The Origin request header'
          - 'ABSENT IS A FAILURE, not same-origin (BR3.3). It fails closed'
      - name: urlOrigin
        logical_type: string
        required: true
        constraints:
          - 'The request URL own origin, which requestOrigin must EXACTLY equal'
      - name: csrfToken
        logical_type: string
        required: false
        nullable: true
        constraints:
          - 'The double-submit token, sent as a request header on EVERY METHOD THAT IS NOT GET OR HEAD - the same set BR3.5 defines for origin (BR3.4, BR3.12)'
          - 'Compared against the token paired 1:1 with the session'
      - name: sessionCookie
        logical_type: string
        required: false
        nullable: true
        constraints:
          - 'Signed. An invalid signature is treated as anonymous, not as an error'
      - name: ownerIdentity
        logical_type: 'opaque | null'
        required: false
        nullable: true
        references: 'ENT-1 OwnerAccount.ownerId (owned by u3-identity-and-session)'
        constraints:
          - 'Resolved by SessionAuthority, which returns the owner identity OR NOTHING (BR3.16)'
          - 'This unit does not decide authorization from it; the unit behind the route does (BR3.2)'
    entity_constraints:
      - id: EC-W4.1
        statement: 'Never serialised into any response and never published in the OpenAPI document'
      - id: EC-W4.2
        statement: 'Carrying an identity is not the same as making a decision. HttpApi enforces nothing beyond transport concerns (BR3.2)'
    relationships:
      - name: resolves
        from: RequestContext
        to: 'ENT-2 Session'
        cardinality: many-to-one
        direction: 'RequestContext -> Session'
        via: sessionCookie
        optional: true
        enforced: false
        notes: 'Session is owned by u3-identity-and-session. This unit carries the resolved result and never reads the store'

entities_referenced_not_owned:
  - { id: ENT-1, name: OwnerAccount,       owner_unit: u3-identity-and-session }
  - { id: ENT-2, name: Session,            owner_unit: u3-identity-and-session }
  - { id: ENT-3, name: LoginAttemptWindow, owner_unit: u3-identity-and-session }
  - { id: ENT-4, name: ContentDocument,    owner_unit: u4-content-core, note: 'Its Content schema generates most of the OpenAPI document; this unit publishes it and does not define it' }
  - { id: ENT-5, name: ContentRevision,    owner_unit: u4-content-core }
  - { id: ENT-6, name: Asset,              owner_unit: u5-media }
```

---

## The wire format is frozen

The JSON wire format is **`camelCase`, and it is inherited rather than chosen**
(FR9.4). Conversion happens in **exactly one place**: the shared Pydantic base with
`alias_generator=to_camel` and `populate_by_name=True`, from which every request and
response model inherits. **No hand-written mapping, no `camelCase` identifier in
Python, no `snake_case` key on the wire.**

This unit is where the frozen format is **published**, in the OpenAPI document, and
therefore where a violation of it becomes visible. It is not where the format is
**defined** — the content schema belongs to `u4-content-core`, and duplicating it here
would create a second definition that can drift from the authoritative one
(`contract-summary.md` § C1, stated as a deliberate omission).

---

## WIRE-1 `ErrorEnvelope` and WIRE-2 `ValidationIssue` — the hazard

### The shape, exactly

Every error response, at every status, carries exactly this:

```
{"error": "<one human sentence>"}
```

On a **validation failure only**, it additionally carries:

```
{"error": "<one human sentence>",
 "issues": [{"path": [...], "message": "..."}]}
```

**The key is `error`, not `detail`, not `message`.** The issue keys are **`path` and
`message`, not `loc` and `msg`.** `path` is an array whose members are strings or
integers, and **an integer member is a collection index** — so
`["publications", 3, "citationsAsOf"]` addresses the `citationsAsOf` field of the
fourth publication.

### Why this is a hazard, and not merely a convention

FastAPI's defaults produce `{"detail": ...}`, and Pydantic's validation errors carry
`loc` and `msg`. The ported editor branches on **`409`** to enter conflict recovery
and reads **`result.issues`** to highlight fields.

With FastAPI's defaults, **the editor appears to work**: requests succeed, statuses
are returned, nothing throws — but field highlighting shows nothing and conflict
recovery never arms. There is no error, no log line, and no failing type check,
because the frontend's generated types would be regenerated from the *new* shape and
would agree with it perfectly. **This is the highest-probability silent regression in
the migration.**

### What follows from that

- The envelope is produced by **exception handlers**, never constructed per route
  (BR10.3). Services raise; routers do not build responses.
- There is **one** envelope for the whole surface — including for requests that never
  reach a route handler. A malformed path, an unroutable method, or a framework-level
  validation error must also produce this shape, or the "exactly one envelope" claim
  is true only of the paths someone remembered.
- The catch-all is **503, not 500** (BR10.5). All four source routes return 503 on an
  unexpected throw.
- **Recoverable versus fatal is a wire-level distinction** (BR10.6): `409` and
  `400`-with-`issues` are recoverable and the frontend keeps specific handling for
  each; `503` is retryable with no specific handling.

### The `error` string is product copy

`ErrorEnvelope.error` is **not** a developer message. Every user-facing error sentence
falls under the parity rule (FR10.2), and a port that rewrites one has changed what the
owner sees. The complete verbatim set of **ported** sentences is **BR10.7** in
`rules.md`, and two facts about it are load-bearing:

- **Two of the strings were elided in the knowledge base** and have since been
  transcribed in full. A truncated string is not a usable parity target.
- **One contains U+2019 RIGHT SINGLE QUOTATION MARK, not an ASCII apostrophe**
  (BR10.8). A parity diff compares bytes; a straight `'` fails it.

**One `error` value is new copy and is deliberately outside that set.** `BR26.4`'s
413 on `POST /api/content/inspect` carries `This draft is too large to check.` That
route **does not exist in `madhavi-tripathi/`** — ADR-006 moved the classification out
of the browser — so it has no ported sentence and no parity fixture, exactly as
`GET /api/public/content` has none. **The parity rule forbids *rewriting* a ported
sentence; it does not forbid *new* copy on a *new* route.** In particular this route
does **not** reuse `This update is too large.`, which is bound to the **1,500,000**
character save cap on `PUT /api/content`: reusing it would make one sentence mean two
different bounds, and `inspect` updates nothing. See `rules.md` § BR26.4.

---

## WIRE-3 `SaveEnvelope`

The request body of `PUT /api/content`: `content`, `revision`, `action`, and an
optional `autosave`.

**It is validated as one predicate** (BR10.12). All of the following must hold:
`revision` is a safe integer; `revision >= 0`;
`revision < Number.MAX_SAFE_INTEGER`; `action` is exactly `draft` or `publish`;
`autosave` is absent or a boolean; and **not** (`autosave === true` **and**
`action !== 'draft'`). **Autosave is legal only with a draft action.**

**It is validated at step 7, after content validation at step 6** (BR10.10, BR10.11).
That ordering is a rule, not an implementation detail: a request carrying **both**
malformed `content` and a bad `revision` returns the **content** 400 **with `issues[]`**,
not the envelope 400. Reordering the two silently changes the error the editor
displays — it highlights fields on one and shows a bare sentence on the other.

**`content`'s schema is not defined here.** It is `ENT-4`, owned by
`u4-content-core`. This unit validates it by delegating to that unit's model and
publishes the generated schema; it does not restate it.

---

## WIRE-4 `RequestContext`

What the middleware resolves per request and hands to the unit behind the route. It is
**never serialised** and is **not** in the OpenAPI document. It is specified because
its fields decide things:

- **`requestOrigin` absent is a failure, not same-origin** (BR3.3). This is the source's
  only CSRF defence and the one case a permissive reading gets wrong.
- **`method`** decides whether origin enforcement applies at all: **every method that is
  not `GET` or `HEAD`** (BR3.5). The test is the **method**, not whether the operation
  writes — so `POST /api/content/inspect`, which writes nothing, is **included**. BR3.5
  was widened at the functional-design gate precisely because the earlier
  "mutations" wording left that route in neither branch. `csrfToken` (BR3.4) applies to
  the **same set**, including the same **one enumerated exception**: the one-shot
  owner-provisioning route is exempt from **both**, because it has **no ambient
  authority to borrow** (it is gated on a secret supplied explicitly in the request,
  which no browser attaches on a third party's behalf) and **no session exists during
  bootstrap**, so there is no CSRF token to pair with.
- **`ownerIdentity`** is resolved, not decided on. `HttpApi` carries it; the component
  behind the route makes the authorization decision (BR3.2). **Carrying an identity is
  not the same as making a decision**, and conflating the two is how a routing layer
  quietly becomes the enforcement point.

---

## What this unit does not own

| Entity | Owner unit | This unit's relationship to it |
|---|---|---|
| `ENT-1 OwnerAccount` | `u3-identity-and-session` | Never read. Sign-in is delegated to `OwnerIdentity` |
| `ENT-2 Session` | `u3-identity-and-session` | Resolved into `WIRE-4` by `SessionAuthority`; the record itself is never touched here |
| `ENT-3 LoginAttemptWindow` | `u3-identity-and-session` | Never read. `LoginGuard` is consulted, not queried |
| `ENT-4 ContentDocument` | `u4-content-core` | Its `Content` schema generates most of the OpenAPI document. **Published here, defined there** |
| `ENT-5 ContentRevision` | `u4-content-core` | Summaries and single entries pass through; the shape is `RevisionLedger`'s |
| `ENT-6 Asset` | `u5-media` | The upload response and the media headers pass through; the row is `MediaIntake`'s |

**The AST test is what makes this table true rather than aspirational**: one pytest
walks the AST of every module under `routers/` and asserts none imports a `store`
module or `sqlite3`. See `functional-spec.md` § *Boundary enforcement is a command*.

---

## Assumptions & Open Questions

- **[assumption, this unit]** `WIRE-1` through `WIRE-4` are **not** additions to the
  six-entity domain model. `components.md` records `entities: []` for `HttpApi` and
  that stays true. They are given `WIRE-n` identifiers rather than `ENT-n` ones so the
  `ENT-n` sequence stays reserved for the six persisted entities and so this unit's
  allocation cannot collide with another unit's. **If the stage's entity-id scheme
  requires a single sequence, these renumber freely** — nothing references them by id
  outside this unit's own three artifacts.
- **[assumption, this unit]** `WIRE-4 RequestContext` is specified as an entity although
  it is never serialised. It is included because its **fields** are load-bearing —
  specifically the absent-`Origin` case — and leaving it out would mean the only record
  of what the middleware resolves is prose. If a reviewer prefers it as a middleware
  description rather than an entity, moving it to `functional-spec.md` changes no rule.
- **[assumption, carried from `contract-summary.md` § C1]** C1's field-level schemas are
  **deliberately omitted** from this unit's artifacts: they are generated from the
  Pydantic models, and duplicating them here would create a second definition that can
  drift from the authoritative one. What is fixed here is the **operations, the status
  codes and the envelope** — the parts that must be **ported rather than designed**.
- **[open, carried from `construction/functional-design/rules.md`]** The source contains
  **two** cancellation literals — `Upload cancelled.` and `Upload cancelled. Your
  previous file is unchanged.` — and **which 499 carries which is unconfirmed**. BR10.7
  records only the longer one. This is an `ErrorEnvelope.error` value, so it is this
  unit's wire contract even though the condition is `u5-media`'s. **Owner: U1
  `source-fixtures`.** Until it resolves, no parity assertion on that sentence may be
  written as settled.
- **[note]** `WIRE-1` has no identifier and no persistence, so it has no uniqueness
  constraint and no key. The `identifier: null` entries in the YAML block are
  deliberate, not omissions.
- **[note]** `499` is **not** in `WIRE-1`'s status set by way of the four-member
  taxonomy — it sits outside it and is mapped explicitly (BR26.2 in `rules.md`). It
  still carries the same envelope, because "exactly one envelope for the whole surface"
  admits no exception.

## Sources

- `construction/functional-design/entities.md` — the six persisted entities and their
  owners; § *The wire format is frozen*, carried here unchanged; § *ENT-4 envelope* for
  `revision`'s safe-integer bounds, which `WIRE-3` echoes.
- `construction/functional-design/rules.md` § `HttpApi` — BR10.1–BR10.6 (the envelope
  and the taxonomy), BR10.7–BR10.9 (product copy, the U+2019, the four retired
  strings), BR10.10–BR10.12 (check ordering and the envelope predicate), BR3.1–BR3.5
  (authorization at the operation boundary; origin and CSRF).
- `inception/domain-design/components.md` § `HttpApi` — `entities: []`, the
  responsibilities list, and the seven `depends_on` edges;
  `inception/domain-design/decisions.md` ADR-003 (one `HttpApi`, not a public/owner
  split).
- `inception/contract-design/contract-summary.md` § C1 — the `Error` schema, the
  `ContentState` schema, every path and its statuses, the `ownerSession` security
  scheme, and § *Contract ownership rules*.
- `inception/requirements-analysis/requirements.md` FR3.8, FR4.7, FR9.4, FR10.1–FR10.3,
  NFR1, NFR2.
- `inception/units-generation/unit-of-work.md` § *U6 — http-api*.
- `aidlc/spaces/default/memory/team.md` § *Code Style* → *Python* → the error-envelope
  paragraph, which names this as "the highest-probability silent regression in the
  migration".
- `WORKING-RECORD.md` §§ 3 (hazard FR10.1), 5 (the error envelope and the frozen wire
  format as conventions that must survive the port).
