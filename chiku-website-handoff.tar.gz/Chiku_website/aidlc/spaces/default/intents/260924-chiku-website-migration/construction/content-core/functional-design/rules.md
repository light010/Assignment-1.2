# Business Rules — U4 `content-core`

**Unit:** `u4-content-core` · **Kind:** `library` · **Components:**
`ContentAuthority`, `RevisionLedger`

**Upstream:** `construction/functional-design/rules.md` (the rule ids and their
text), `inception/requirements-analysis/requirements.md` FR4.1–FR4.7, FR5.1–FR5.4,
FR7.6, FR8.3, FR9.1–FR9.4, FR10.1, NFR8, NFR11,
`inception/domain-design/components.md` (rule ownership), `decisions.md` ADR-001,
ADR-002, ADR-006, `inception/contract-design/contract-summary.md` §§ C1, C2,
companion artifacts `entities.md` and `functional-spec.md`.

> **Path note — `construction/functional-design/` is NOT a unit directory.** It is
> the **workflow-level** rule and entity corpus, written before the per-unit split
> and shared by every unit; the per-unit convention is
> `construction/<unit-name>/functional-design/...`, which has a unit segment this
> path lacks. The collision is real enough that a reviewer's scope tooling
> classifies it as a sibling unit and refuses to open it, so it is named here as a
> **shared cross-unit input** rather than an upstream artifact of any one unit.
> It holds the 120 `BR3.x`–`BR10.x` ids this unit carries forward verbatim.

## How to read this document

Every rule here is something **an implementation could get wrong**. Rules the type
system already enforces are deliberately absent: "`accent` must be one of three
values" is a schema constraint and lives in `entities.md`, not here.

`BR{n}.{m}` ids are **stable and unchanged**. The major number tracks the
requirement family — `BR4.*` are FR4 rules, `BR5.*` are FR5 rules. Ids are assigned
once and do not move; nothing in this unit-scoped file renumbers, merges or splits
a rule from `construction/functional-design/rules.md`. This file is that split, not
a rewrite.

**45 rules declared, of which 20 are hazard rules.** This unit carries **three of
the seven hazards outright** and is **subject to a fourth**:

| Rules | Hazard | Requirement | Owned here? |
|---|---|---|---|
| **BR4.8–BR4.19** | The combined write and its side-effect guard | **FR4.5** | **yes** |
| **BR8.1–BR8.5** | Recovered-draft classification | **FR8.3** | **yes** |
| **BR9.1–BR9.3** | The content-carrying defaults | **FR9.2** | **yes** |
| **BR10.1–BR10.6** | The error envelope | **FR10.1** | **no — `HttpApi` (U6)**, carried in full below |

Each hazard is specified **branch by branch** and carries an explicit **"What
breaks silently"** note, because by definition none of them fails loudly. Every
hazard rule needs a test per enumerated branch and falls inside the **100% scoped
coverage floor**.

**Almost nothing here is designed.** Every rule is either preserved behaviour from
`madhavi-tripathi/` or a decision already recorded in the requirements, the
component catalogue, an ADR or `WORKING-RECORD.md` § 2. **The three exceptions are
BR24.1–BR24.3**, and they are exceptions for a stated reason: the published-document
cache interval was owned by `nfr-design`, which was **SKIPPED in-flight**, and the
human **re-homed it to this stage for this unit** because it is a security
parameter rather than a tuning one.

**Rule index for this unit**

| Component | Rules | Count | Of which hazard |
|---|---|---|---|
| `ContentAuthority` | BR4.1–BR4.22 | 22 | **BR4.8–BR4.19** (FR4.5) |
| `ContentAuthority` | BR8.1–BR8.5 | 5 | **all five** (FR8.3) |
| `ContentAuthority` | BR9.1–BR9.3 | 3 | **all three** (FR9.2) |
| `RevisionLedger` | BR5.1–BR5.10 | 10 | — |
| `ContentAuthority` | BR7.1–BR7.2 | 2 | — · the published-document cache; **declaration moved here from `u5-media` at review** |
| Unit-scoped | BR24.1–BR24.3 | 3 | — · **BR24.1/BR24.2 discharge FR7.6** with BR7.1/BR7.2; only BR24.3 traces to no FR |
| *Subject to, owned elsewhere* | BR3.1, BR7.4, BR8.6–BR8.8, BR10.1–BR10.12, BR22.1, BR22.5, BR22.6, BR22.8 | 21 | BR10.1–BR10.6, BR7.4 |

**On the BR24 group.** `BR24.1`–`BR24.3` are the unit-scoped allocation
(**U4 + 20**), for rules whose subject the FR-derived groups do not cover.

**Corrected at review, and the correction matters.** `BR24.1` and `BR24.2` were
first declared to trace to no FR, on the reasoning that no requirement fixes an
interval. That confused the *value* with the *rule*. **FR7.6 is assigned to this
unit** by both `unit-of-work.md` § U4 and the story map, and it reads: *"The
published document consulted by FR7.2 may be cached in-process for a short
interval. The cache changes which requests hit storage, never which assets are
public, and a publish invalidates it."* That is precisely what `BR24.1` (the
interval) and `BR24.2` (invalidation on publish) implement. The 5-second bound is
a new decision closing the gap FR7.6 leaves open in *"a short interval"* — a gap,
not an absence of requirement. Declaring no FR made a requirement this unit
genuinely discharges look project-wide like an orphan.

**Only `BR24.3` traces to no FR**, and that was re-verified rather than assumed:
FR7.6 governs the cache, not what a public response may contain. NFR11 is its
whole source. It alone is in the traceability `reverse` array.

**Also corrected at review — `FR9.1` and `FR9.3` were discharged but uncited.** A
corpus-wide audit found that **no unit claimed either**, although
`inception/units-generation/traceability.json` assigns both to **U4**. Both were
being *done* here and simply not *cited*, which reads project-wide as two
unrealised requirements. They are cited differently, because they are discharged
differently, and the difference is stated rather than smoothed over:

| Requirement | What discharges it | Where it is now cited |
|---|---|---|
| **FR9.3** — the seeded content carried across byte-for-byte in meaning | **`BR4.1`**: a fresh install holds no document, so the seed *is* what BR4.1 synthesises for both `draft` and `published`. The seed's own values are **instance data**, reproduced from the source constructor and asserted against U1's recorded fixtures. | `BR4.1`'s `source:` (`FR4.1, FR9.3`), the rules summary, and `traceability.json` `coverage` |
| **FR9.1** — the schema preserves every field, constraint, default, maximum and refinement | **`entities.md` § ENT-4** — the 31 top-level fields, the asymmetric collection defaulting, the nine copy groups with 25 leaf defaults, and the exhaustive **cap census**. It is discharged by the *entity specification*, **not by any rule here**. | `traceability.json` `coverage`, targeting `entities.md` |
| **FR9.4** — the wire format stays `camelCase` | **`entities.md` § *The wire format is frozen*** — an entity-specification discharge, same footing as FR9.1. Added after U2's R-6: `FR9.4` is assigned to **U4**, but was reported only by U2's `BR22.5`, which *preserves* the frozen format across the storage boundary without *stating* it. Moving `BR22.5` into U2's `reverse` array left `FR9.4` claimed by no unit. | `traceability.json` `coverage`, targeting `entities.md` |

**No rule's `source:` was given `FR9.1`, deliberately.** `BR4.6` (authoritative
validation) and `BR9.2` (re-validation on every read) are where the preserved
schema is *enforced*, but neither rule *states* the preservation — writing `FR9.1`
into their `source:` would repeat the exact error this document was corrected for
above, claiming a rule discharges a requirement it merely enables. The
`traceability.json` entry therefore targets `entities.md` directly, as `U8` and
`U9` already do for their non-rule coverage.

**Structure of this document.** The fenced `yaml` block below is the **source of
truth**: it governs, and it is what downstream stages read. The prose sections
after it carry the **rationale and the failure mode** for each rule, and carry the
BR10 family in full because this unit raises into it. **The prose must not
contradict the block; where it appears to, the block wins and the prose is a
defect.**

---

## Source of truth

```yaml
source_of_truth: rules
stage: functional-design
unit: u4-content-core
kind: library
kind_note: >
  U4 content-core is a LIBRARY, not a service. U6 http-api is the only unit
  declaring service - there is exactly one deployed Python executable. This unit is
  embedded in it and is not independently deployable.
authority: >
  This block is the source of truth and governs. Each hazard rule statement carries
  its FULL text, branch by branch. The prose sections below carry the rationale and
  the failure mode for each rule and must not contradict this block.
components: [ContentAuthority, RevisionLedger]
rule_count: 45
id_format: 'BR{group}.{seq}; source ids are FR{n} / FR{n}.{m} / NFR{n} as spelled in requirements-analysis'
unit_scoped_group: >
  BR24 is the unit-scoped allocation for U4 (unit number + 20), for rules whose
  subject the FR-derived groups do not cover. There are three, all concerning the
  published-document cache and the public read. CORRECTED AT REVIEW - BR24.1 and
  BR24.2 DO discharge an FR (FR7.6, assigned to U4 by unit-of-work.md and the story
  map) and are carried in the traceability coverage array; only BR24.3 traces to no
  FR and it alone is in the traceability reverse array.
hazards:
  - { requirement: FR4.5, rules: 'BR4.8-BR4.19', subject: 'the combined write and its ABA side-effect guard', owned: true }
  - { requirement: FR8.3, rules: 'BR8.1-BR8.5',  subject: 'recoverable versus corrupting classification', owned: true }
  - { requirement: FR9.2, rules: 'BR9.1-BR9.3',  subject: 'the content-carrying defaults', owned: true }
  - { requirement: FR10.1, rules: 'BR10.1-BR10.6', subject: 'the error envelope', owned: false, owner_unit: u6-http-api }
rules:

  - id: BR4.1
    statement: >
      When no document exists, the read synthesises {draft: seed, published: seed, revision: 0,
      updatedAt: null, publishedAt: null, hasUnpublishedChanges: false} and WRITES NOTHING. A
      read must never create the document.
    category: constraint
    applies_to: ContentAuthority
    trigger: Any read of content state.
    logic: >
      IF the content document is absent THEN return the seeded document at revision 0 with both
      timestamps null and the change flag false, and perform no write. ELSE return the stored
      state.
    violation: >
      A read that creates the document defeats the bootstrap guard in BR4.8 and lets a client at
      revision 5 resurrect a deleted document.
    source: FR4.1, FR9.3
    source_note: >
      FR9.3 added at review. FR9.3 ("the seeded content is carried across
      byte-for-byte in meaning - five publications, three research themes, three
      achievements, four journey entries, four news items, the Scholar highlights
      and all nine editable copy blocks") is assigned to U4 by
      inception/units-generation/traceability.json, and THIS is the rule that makes
      the seed observable: a fresh install has no document, so what BR4.1
      synthesises for both draft and published IS the seeded content the requirement
      is about. The seed's own field values are instance data rather than schema -
      entities.md records that they are reproduced from the source constructor and
      asserted against U1's recorded fixtures, not enumerated here.

  - id: BR4.2
    statement: >
      hasUnpublishedChanges is computed on every read, never stored: a full serialised comparison
      of draft against published. It is not a flag maintained by the write path.
    category: calculation
    applies_to: ContentAuthority
    trigger: Every read of content state.
    logic: IF a read occurs THEN compute the comparison fresh. There is no column and no flag.
    violation: >
      A maintained flag drifts from the documents it describes, and nothing in the write path
      would reveal the drift.
    source: FR4.1

  - id: BR4.3
    statement: An accepted write ALWAYS overwrites draft, for a publish as well as a draft save.
    category: constraint
    applies_to: ContentAuthority
    trigger: Every accepted write.
    logic: IF a write is accepted THEN draft receives the validated document, whatever the action.
    violation: A publish that leaves the draft stale makes the editor show pre-publish content.
    source: FR4.2

  - id: BR4.4
    statement: >
      published and publishedAt change ONLY when action = publish. publishedAt stays null until
      the first publish; the seeded document is not "published".
    category: constraint
    applies_to: ContentAuthority
    trigger: Every accepted write.
    logic: >
      IF action = publish THEN set published to the validated document and publishedAt to now.
      ELSE leave both untouched.
    violation: >
      A draft save that moved published would publish unreviewed content; a seeded publishedAt
      would claim a publication that never happened.
    source: FR4.2

  - id: BR4.5
    statement: >
      revision increments by exactly 1 on EVERY accepted write - drafts as well as publishes.
    category: constraint
    applies_to: ContentAuthority
    trigger: Every accepted write.
    logic: IF a write is accepted THEN revision becomes revision + 1, regardless of action.
    violation: >
      An implementation that only bumps the revision on publish breaks the editor's concurrency
      contract on the very next autosave.
    source: FR4.2

  - id: BR4.6
    statement: >
      Every write is validated authoritatively in the backend BEFORE it is persisted, and a
      validation failure returns field-level issues the editor displays, not a generic message.
    category: validation
    applies_to: ContentAuthority
    trigger: Every write.
    logic: >
      IF the document fails validation THEN reject before persisting and return per-field issues
      (see BR10.2 for the shape). The browser's generated mirror is for responsiveness only and
      is NEVER the enforcement.
    violation: >
      A generic message leaves the owner hunting for the bad field; a browser-only check means no
      enforcement at all for a caller that bypasses the browser.
    source: FR4.3

  - id: BR4.7
    statement: >
      A write carries the caller's base revision; the update applies only if the stored revision
      still equals it, otherwise it is rejected as a conflict with the CURRENT STATE RETURNED
      alongside the error.
    category: constraint
    applies_to: ContentAuthority
    trigger: Every write.
    logic: >
      IF the stored revision equals the caller's base revision THEN apply. ELSE reject as a
      conflict, preserve the caller's edits, and return the current state so the caller can
      reconcile.
    violation: >
      Without returning the current state the editor cannot show what changed, and conflict
      recovery becomes "discard your work and reload".
    source: FR4.4
    note: >
      Deliberately NOT a hazard: this failure is loud and the editor already handles it. The
      silent risk is one level down, in BR4.8-BR4.19.

  - id: BR4.8
    statement: >
      Statement 0 bootstraps the singleton with the seed in BOTH payload columns at revision 0
      with publishedAt NULL, guarded on the caller claiming revision 0, and a no-op if the record
      already exists.
    category: constraint
    applies_to: ContentAuthority
    trigger: Every combined write, as the first effect.
    logic: >
      IF base_revision = 0 AND no document exists THEN insert the singleton seeded with the
      initial content in both columns, revision 0, updated_at = now, published_at NULL. IF it
      already exists THEN do nothing.
    violation: >
      Without the revision-0 guard a client at revision 5 can resurrect a deleted document;
      without the no-op a concurrent bootstrap errors.
    source: FR4.5

  - id: BR4.9
    statement: >
      Statements 1 and 2 capture the two permanent baselines ONCE EVER, under the fixed ids
      starting-published and starting-draft, from the document's PRE-EXISTING content, guarded on
      the stored revision equalling the caller's base revision.
    category: constraint
    applies_to: ContentAuthority
    trigger: Every combined write, before the compare-and-set.
    logic: >
      IF no entry exists under the fixed id starting-published AND the stored revision equals
      base_revision THEN insert it from the CURRENT published column with action publish,
      created_at = now, baseline true. THEN the same for starting-draft from the current draft
      column with action draft. The fixed ids plus insert-if-absent are what make each succeed at
      most once in the document's lifetime.
    violation: >
      created_at is the TIME OF CAPTURE, never a guessed original publication date. A stale writer
      must capture nothing. A target store without genuinely idempotent insert-if-absent semantics
      needs an equivalent that is idempotent UNDER CONCURRENCY - not a read-then-write.
    source: FR4.5

  - id: BR4.10
    statement: >
      Statement 3 is the compare-and-set and it is the concurrency control: draft always
      overwritten, published and publishedAt moved only on publish, revision incremented
      unconditionally, lastMutation stamped with this call's token - all guarded on the stored
      revision equalling the caller's base revision.
    category: constraint
    applies_to: ContentAuthority
    trigger: Every combined write.
    logic: >
      IF the stored revision equals base_revision THEN set draft, conditionally set published and
      published_at, increment revision, set updated_at and last_mutation, and return the new
      draft, published, revision, updated_at, published_at. ELSE match zero rows, return nothing,
      and the caller gets a conflict.
    violation: >
      The two conditional expressions ARE how publish is expressed; collapsing them publishes on
      every save. A missing guard loses the optimistic concurrency entirely.
    source: FR4.4, FR4.5

  - id: BR4.11
    statement: >
      Statement 4 inserts the history entry whose ID IS THE MUTATION TOKEN, whose content is read
      back FROM THE STORED DRAFT COLUMN and whose createdAt is read back from the document's
      updatedAt, gated on revision = next_revision AND lastMutation = this token.
    category: constraint
    applies_to: ContentAuthority
    trigger: Every combined write, after the compare-and-set.
    logic: >
      IF the stored revision equals base_revision + 1 AND last_mutation equals this call's token
      THEN insert the entry taking revision, content and created_at FROM THE DOCUMENT ITSELF, with
      baseline false. For a publish, draft and published are equal, so storing draft is correct
      for both actions.
    violation: >
      An implementation that inserts the CALLER'S payload diverges whenever validation transforms
      or defaults changed the stored value - which, given the item transform and the many
      defaults, is MOST OF THE TIME.
    source: FR4.5, FR5.3

  - id: BR4.12
    statement: >
      Statements 5 and 6 apply retention per action, gated on the same revision and token: keep
      30 non-baseline drafts and 20 non-baseline publishes.
    category: policy
    applies_to: ContentAuthority
    trigger: Every combined write, after the history insert.
    logic: >
      IF the stored revision equals base_revision + 1 AND last_mutation equals this call's token
      THEN delete non-baseline draft entries outside the 30 highest-revision drafts, and
      independently delete non-baseline publish entries outside the 20 highest-revision publishes.
    violation: Ungated, a losing writer prunes history off the back of the winner's write.
    source: FR4.5, FR5.3

  - id: BR4.13
    statement: >
      The ABA scenario, concretely. The revision CAS protects THE CONTENT WRITE ("is the caller's
      view still current?"); the mutation token protects THE SIDE EFFECTS ("is the row in this
      state because I put it there?"). Statements 4-6 are guarded on revision = next_revision,
      which is NOT UNIQUE TO THIS WRITER.
    category: constraint
    applies_to: ContentAuthority
    trigger: Two concurrent writers holding the same base revision.
    logic: >
      The document sits at revision 5; writers A and B both load it. B commits first and the row
      advances to revision 6 stamped with B's token. A's statement 3 (WHERE revision = 5) matches
      nothing and A correctly gets a conflict - BUT A's statements 4-6 test revision = 6, because
      A's next_revision is also 6, and B's write satisfies exactly that condition. THEREFORE those
      statements additionally test last_mutation = A's own fresh random token, so all three guards
      test IDENTITY rather than POSITION.
    violation: >
      Without the token, statement 4 inserts a history row keyed by A's mutation id carrying B's
      content under A's action - a phantom revision nobody ever saved - and statements 5 and 6 run
      A's retention pass off the back of B's write, pruning history A had no right to prune,
      potentially deleting a revision B had just created.
    source: FR4.5

  - id: BR4.14
    statement: >
      The token is not optional and not an optimisation; re-expressing the write as "CAS on
      revision, then insert history, then prune" WITHOUT it reintroduces both bugs.
    category: policy
    applies_to: ContentAuthority
    trigger: Any refactor of the combined write.
    logic: >
      IF the token is dropped THEN both defects return. They are TIMING-DEPENDENT and will not
      appear in single-user testing, which is the entire reason this rule is written out.
    violation: Silent history corruption under concurrency, with nothing failing anywhere.
    source: FR4.5

  - id: BR4.15
    statement: >
      The guard does not depend on transactional isolation and must not be argued away on the
      grounds that the transaction already serialises the writes.
    category: policy
    applies_to: ContentAuthority
    trigger: Any design review of the combined write.
    logic: >
      IF the runtime provides weaker isolation than one implicit transaction THEN the token still
      keeps statements 4-6 correct. The token is kept regardless of isolation level.
    violation: A correct-looking simplification that fails on a different adapter.
    source: FR4.5

  - id: BR4.16
    statement: All effects commit together or none does; atomicity is REQUIRED of the port operation.
    category: constraint
    applies_to: ContentAuthority
    trigger: Every combined write.
    logic: >
      IF any of the content update, the revision entry or the prune fails THEN none is visible.
      Splitting the three effects across separate calls or separate transactions breaks both
      guards.
    violation: Partial state becomes observable and both guards lose their meaning.
    source: FR4.5

  - id: BR4.17
    statement: >
      results[3] is a load-bearing positional index. The source reads the CAS result by numeric
      index into the batch array with no comment marking it; statement 3 is the UPDATE.
    category: constraint
    applies_to: ContentAuthority
    trigger: Reading the outcome of the combined write.
    logic: >
      IF a statement is inserted anywhere before the UPDATE THEN the write silently reads the
      wrong result - most likely undefined, which the route interprets as a 409 CONFLICT.
      THEREFORE the port reads the CAS outcome BY NAME OR EXPLICIT BINDING, never by position; if
      a positional read is unavoidable in the chosen driver, the index is asserted by a test.
    violation: >
      A refactor of the batch produces spurious "this draft changed in another tab" errors rather
      than a crash - the failure looks like a concurrency event, not like a bug.
    source: FR4.5

  - id: BR4.18
    statement: >
      The prune is expressed as read-the-survivors-then-delete-the-rest, inside the transaction -
      NOT as a query-language predicate.
    category: constraint
    applies_to: ContentAuthority
    trigger: Every prune.
    logic: >
      IF the prune is expressed as delete-where-id-not-in-subquery THEN only a relational adapter
      can satisfy it; a document store has no such construct. This is a PORT-CONTRACT RULE, not an
      implementation preference.
    violation: A port contract satisfiable by exactly one adapter.
    source: FR4.5, FR5.3

  - id: BR4.19
    statement: >
      The retention ordering is revision DESC alone, is NOT tiebreak-stable, and the indeterminacy
      is preserved rather than fixed.
    category: policy
    applies_to: ContentAuthority
    trigger: A prune where several entries share a revision.
    logic: >
      Multiple rows can share a revision - a baseline pair plus a normal entry. WHICH ROW SURVIVES
      AT THE BOUNDARY IS UNSPECIFIED in the source. A faithful port uses the same ordering and
      inherits the same indeterminacy; it must NOT "fix" it by adding a tie-break, because that
      changes which entries survive.
    violation: Different history contents from the "improved" implementation.
    source: FR5.3

  - id: BR4.20
    statement: >
      A save request whose body exceeds 1,500,000 CHARACTERS of decoded text is rejected as too
      large. The cap counts CHARACTERS, NOT BYTES.
    category: validation
    applies_to: ContentAuthority
    trigger: Every save request.
    logic: >
      IF the decoded body's character count exceeds 1,500,000 THEN reject as too large. The source
      reads the body as a string and tests its length, which counts UTF-16 code units.
    violation: A byte cap rejects documents the current system accepts.
    source: FR4.6

  - id: BR4.21
    statement: >
      The consequence is concrete: a document of 1.5 M non-ASCII characters can be 3-4 MB of
      UTF-8, so a byte cap is a silent, undiscoverable break in the owner's own longest content.
    category: policy
    applies_to: ContentAuthority
    trigger: Any proposal to "fix" the unit of the cap.
    logic: >
      IF a byte cap is chosen because it is more defensible in isolation THEN under the parity rule
      it is a regression. The inelegant limit wins over the more defensible one.
    violation: >
      The owner's longest content stops saving, with no error anyone can trace to a decision, and
      no way to discover the new boundary.
    source: FR4.6

  - id: BR4.22
    statement: >
      The cap is checked AFTER the body is fully read and BEFORE JSON parsing. It therefore limits
      document size, not memory use - the full body is already in memory when the check runs.
    category: constraint
    applies_to: ContentAuthority
    trigger: Every save request.
    logic: >
      Reproduce the POSITION as well as the number: moving the check after the parse changes which
      status a too-large malformed body receives.
    violation: >
      A too-large malformed body returns the parse error instead of the size error, changing what
      the editor shows for a case the owner can actually hit by pasting.
    source: FR4.6

  - id: BR5.1
    statement: >
      The listing order is a three-part sort, not "newest first": revision DESC, then baseline ASC,
      then action DESC. Newest revision first; within one revision, non-baseline entries before
      baseline entries; then publish before draft.
    category: constraint
    applies_to: RevisionLedger
    trigger: Every history listing.
    logic: Sort by the three keys in that order, with those directions.
    violation: A tied revision lists in a different order than the owner saw before.
    source: FR5.1

  - id: BR5.2
    statement: >
      All three parts are load-bearing for what the owner sees, which is why the conformance suite
      must assert the full order.
    category: constraint
    applies_to: RevisionLedger
    trigger: Every listing, and the conformance suite.
    logic: >
      IF a test asserts only "newest first" THEN a single-key sort passes while the display order
      is wrong. THEREFORE assert the full order, including a tied revision.
    violation: A wrong order that no test can see.
    source: FR5.1

  - id: BR5.3
    statement: >
      The listing is capped at 52 entries. This is not a page size and there is no pagination.
      52 = 30 drafts + 20 publishes + 2 baselines, by construction.
    category: constraint
    applies_to: RevisionLedger
    trigger: Every listing.
    logic: >
      The listing limit and the retention policy are the SAME NUMBER by construction; changing one
      without the other silently truncates history or shows nothing new.
    violation: Silent truncation, or a listing that can never show a newly created entry.
    source: FR5.1

  - id: BR5.4
    statement: >
      On the document-store adapter this order requires a declared composite index, carried by the
      deployment plan and asserted by the conformance suite.
    category: policy
    applies_to: RevisionLedger
    trigger: Deploying or testing that adapter.
    logic: >
      IF the index is absent THEN the query reorders or fails. THEREFORE the index definition is a
      deployment artifact and the suite asserts the order, so a missing index FAILS A TEST rather
      than silently reordering the list.
    violation: A silently reordered history list in a new environment.
    source: FR5.1

  - id: BR5.5
    statement: >
      A revision id is validated before use: ABSENT means list; present but empty, longer than 100
      characters, or failing ^[a-zA-Z0-9-]+$ is a 400 - not a list and not a 404.
    category: validation
    applies_to: RevisionLedger
    trigger: A history request.
    logic: >
      IF the id parameter is not present at all THEN return the listing. IF it is present but
      empty, over 100 characters, or fails the pattern THEN reject as invalid. The
      absent-versus-empty distinction is a REAL BRANCH - a present-but-empty id is a 400.
    violation: >
      Treating empty as absent silently turns a malformed request into a successful listing, and
      the caller never learns its id was wrong.
    source: FR5.2

  - id: BR5.6
    statement: Restoring a revision into the editor NEVER publishes.
    category: constraint
    applies_to: RevisionLedger
    trigger: A restore.
    logic: >
      IF a revision is restored THEN return the entry's content for review only. The owner must
      save or publish explicitly.
    violation: >
      A restore that published would put historical content live with one click and no review
      step.
    source: FR5.2

  - id: BR5.7
    statement: >
      Retention keeps the 30 most recent non-baseline draft entries and the 20 most recent
      non-baseline publish entries. The two counts are independent - a run of 30 drafts never
      evicts a publish.
    category: policy
    applies_to: RevisionLedger
    trigger: Every accepted write.
    logic: Count drafts and publishes separately and apply each limit to its own action.
    violation: A combined cap silently loses publishes during a burst of autosaves.
    source: FR5.3

  - id: BR5.8
    statement: >
      The two starting baselines are kept permanently and are NEVER pruned; both retention deletes
      exclude baseline entries EXPLICITLY, as part of the delete predicate.
    category: policy
    applies_to: RevisionLedger
    trigger: Every prune.
    logic: >
      The exclusion is part of the predicate, not a coincidence of ordering. IF a prune relies on
      baselines sorting high THEN it will eventually reach one.
    violation: >
      A once-ever capture is lost and cannot be recreated - the pre-migration state is gone
      permanently.
    source: FR5.3

  - id: BR5.9
    statement: >
      RevisionLedger owns the retention policy but performs NO write. It supplies the policy;
      ContentAuthority applies it inside its one combined write. RevisionLedger's own store access
      is READ-ONLY.
    category: policy
    applies_to: RevisionLedger
    trigger: Every combined write.
    logic: >
      IF the ledger wrote directly THEN the combined write would no longer be one call with one
      caller, which is what ADR-001 exists to prevent. Reading the entity ownership table alone
      would suggest otherwise, which is why this is stated.
    violation: The single-writer property of ADR-001 is lost, and with it both guards.
    source: FR5.3

  - id: BR5.10
    statement: >
      A revision id that is well-formed but absent - or whose entry has been pruned, or whose row
      carries no content - returns 404 with a body that states THE CURRENT DRAFT IS UNAFFECTED.
    category: constraint
    applies_to: RevisionLedger
    trigger: A single-revision fetch that finds nothing.
    logic: >
      IF the id is well-formed and names nothing THEN 404, and the response must say the current
      draft is unchanged. Reassuring the owner is PART OF THE RULE, not decoration.
    violation: >
      An owner who asks for a pruned version and gets a bare 404 has no way to know their unsaved
      work is still safe, and may reload to find out.
    source: FR5.4

  - id: BR7.1
    statement: >
      The published-document cache lives in ContentAuthority, not in MediaDelivery, so
      invalidation never crosses a component boundary.
    category: policy
    applies_to: ContentAuthority
    trigger: Any read of the published document for the asset-visibility test.
    logic: >
      IF the published document is needed THEN it is obtained from ContentAuthority; NO other
      component caches it. u5-media holds no cache of its own (BR25.1, declared there) precisely
      so that this one cache is the only thing BR24.2's invalidation has to reach.
    violation: >
      A second cache in a consuming component would MISS the publish invalidation and leave an
      asset the owner has just unreferenced public for that cache's lifetime.
    source: FR7.6
    source_note: >
      DECLARATION MOVED HERE at review, by coordinator decision. BR7.1 and BR7.2 were
      declared in u5-media while carrying `owned_by_unit: u4-content-core` and
      `applies_to: ContentAuthority`; the workflow-level rule index and ADR-002 place them
      here, and `units-generation/traceability.json` assigns FR7.6 to U4. Four sources
      agreed and the declaration's location was the lone dissenter. u5-media now lists
      both under `rules_subject_to_but_not_owned`: it CONSUMES this cache on its public
      read path, it does not own it.
    clause_note: >
      FR7.6 IS A SPLIT REQUIREMENT and all four of its rules are now declared in this
      unit. Clause 1, "may be cached in-process for a short interval", is discharged by
      BR24.1 (the interval) and BR24.2 (invalidation on publish). Clause 2, "the cache
      changes which requests hit storage, never which assets are public, and a publish
      invalidates it", is discharged by BR7.2 almost verbatim. BR7.1 is the PLACEMENT
      that makes the invalidation local and therefore possible at all.

  - id: BR7.2
    statement: >
      The cache changes WHICH REQUESTS HIT STORAGE, never WHICH ASSETS ARE PUBLIC. A publish
      invalidates it. The interval is a SECURITY parameter, not a tuning one.
    category: policy
    applies_to: ContentAuthority
    trigger: A publish; and every cached read of the published document.
    logic: >
      IF action = publish succeeds THEN invalidate (BR24.2 fixes that this is synchronous and
      inside the operation). The cache is permitted to change only WHICH REQUESTS REACH STORAGE;
      it may never change the OUTCOME of the visibility test in BR7.4. The interval bounds how
      long a just-unreferenced asset stays public, which is why BR24.1 sets it as a maximum
      rather than a default.
    violation: >
      A stale entry is an AUTHORIZATION defect on the system's hottest path, not a performance
      one - and nothing anywhere reports it.
    source: FR7.6
    source_note: >
      This rule is FR7.6's second clause almost verbatim, which is why the requirement is
      discharged jointly rather than duplicated. Declaration moved here with BR7.1; see
      BR7.1's notes. The INTERVAL this rule leaves unset is decided here as BR24.1,
      re-homed from the SKIPPED nfr-design stage by WORKING-RECORD 10a Condition 1.

  - id: BR8.1
    statement: >
      RECOVERABLE - offer the draft. A value that is PRESENT and of the CORRECT TYPE but outside
      its permitted set or range: a string shorter than a minimum (an emptied required title); a
      string longer than a maximum; a number outside its range; a value failing a format or custom
      refinement (a malformed email, a bad URL, a non-numeric citation count, an impossible
      citation date); and A VALUE OUTSIDE AN ENUMERATED SET - accent, researchTopic, the scene's
      initialView.
    category: policy
    applies_to: ContentAuthority
    trigger: Inspecting a recovered draft.
    logic: >
      IF every failure is of one of those kinds THEN these are exactly the states an owner produces
      BY TYPING, so keep the draft, repair it against schema defaults, and present it for review.
    violation: >
      Discarding these loses the owner's work for a mistake they made while editing, which is the
      precise case recovery exists for.
    source: FR8.3, FR8.3.1

  - id: BR8.2
    statement: >
      CORRUPTING - discard the draft. A malformed record: the wrong JSON shape, a field of the
      wrong type, a missing required structure, or a stored blob that is not parseable at all.
      These indicate corruption rather than in-progress editing.
    category: policy
    applies_to: ContentAuthority
    trigger: Inspecting a recovered draft.
    logic: IF any failure is of one of those kinds THEN the record is corrupt and the draft is discarded.
    violation: >
      Offering a structurally broken record to the editor puts it into a state no control can
      repair.
    source: FR8.3, FR8.3.2

  - id: BR8.3
    statement: >
      The mapping from validation outcome to class, stated in terms of what a validator reports
      because the source's bug was precisely a mis-mapping. RECOVERABLE - below a minimum; above a
      maximum; custom/refinement predicate failed; string format/pattern check failed; VALUE NOT A
      MEMBER OF AN ENUMERATED SET. CORRUPTING - wrong type for the declared field; required key
      missing; value is not an object/array where one is required; payload not parseable as JSON at
      all.
    category: policy
    applies_to: ContentAuthority
    trigger: Classifying each validation issue.
    logic: >
      Classify each issue by WHAT WENT WRONG WITH THE VALUE, per the two lists. The draft is
      discarded only if at least one issue is corrupting.
    violation: >
      Placing the enumerated-set case on the corrupting side is exactly the source defect: one bad
      enum discards the entire recovered draft.
    source: FR8.3, FR8.3.1, FR8.3.2

  - id: BR8.4
    statement: >
      What the source does, and why copying it is wrong. The source allowlists four issue codes -
      too_small, too_big, custom, invalid_format - and discards the draft if ANY issue falls outside
      that list. Two defects compound: invalid_format is a zod v4 code and the installed package
      resolves to the v3 API, so that entry CAN NEVER MATCH; and invalid_enum_value, which v3 DOES
      emit, is ABSENT. Net effect - one bad enum discards the owner's entire recovered draft, along
      with every other unsaved edit in that record, while the source's own comment states the
      opposite intent.
    category: policy
    applies_to: ContentAuthority
    trigger: Porting the classification.
    logic: >
      IF the four code strings are copied across THEN the defect is carried forward. THEREFORE the
      port implements FR8.3.1/FR8.3.2 as written, NOT the current behaviour. This is D9, one of only
      three deliberate behaviour changes.
    violation: >
      Copying the source's behaviour preserves a bug that destroys the owner's work; and it is
      carried WITH ITS HEDGE - the CodeKB records this as a latent defect with a proven mechanism,
      not a confirmed user-visible failure, because the scan demonstrated the code mismatch
      empirically but could not exercise the editor in that environment.
    source: FR8.3

  - id: BR8.5
    statement: >
      Re-express the classification in the new validator's taxonomy, NEVER by copying issue-code
      strings. The new validator's error types share no names with either zod version; copying the
      four strings across would carry the bug forward AND ADD A SECOND ONE.
    category: policy
    applies_to: ContentAuthority
    trigger: Implementing the classification.
    logic: >
      The rule is stated in terms of WHAT WENT WRONG WITH THE VALUE, which is portable; the code
      names are not.
    violation: >
      A second, new defect layered on the inherited one, in the code path whose whole job is not to
      lose work.
    source: FR8.3, FR8.3.3

  - id: BR9.1
    statement: >
      researchTopic resolves through the legacy id-to-topic map and otherwise to general;
      researchIds resolves through the seeded id-to-links map and otherwise to the empty list. Both
      maps' full contents, the precedence order and the absence-not-truthiness requirement are
      specified in entities.md W-1 and W-2, WHICH ARE NORMATIVE.
    category: calculation
    applies_to: ContentAuthority
    trigger: Every parse of an item.
    logic: >
      researchTopic := explicit value, else originalTopics[id], else 'general'.
      researchIds := explicit value, else initialResearchLinks[id], else [].
      Precedence is strict and the first present value wins.
    violation: >
      A model declaring the field as nullable-with-a-None-default is TYPE-CORRECT AND BEHAVIOURALLY
      WRONG: it produces None where the original produces a real topic, and the empty list where the
      original produces the seeded editorial links.
    source: FR9.2

  - id: BR9.2
    statement: >
      This is LOGIC, not a field default. It runs on EVERY PARSE, which includes EVERY READ OUT OF
      STORAGE, not only on writes. A model declaration cannot express it, which is exactly why a
      type-correct port is behaviourally wrong.
    category: calculation
    applies_to: ContentAuthority
    trigger: Every parse, on the read path as much as the write path.
    logic: >
      IF a stored document is read THEN it is re-validated and re-transformed. The editor also sends
      the TRANSFORMED document back on save, so on the first save after a field was added the derived
      values are MATERIALISED INTO STORAGE - the transform is simultaneously a read-path rule and the
      origin of stored values.
    violation: >
      Implementing it as a default on the write path only leaves every pre-existing stored document
      rendering wrong forever.
    source: FR9.2

  - id: BR9.3
    statement: >
      An explicitly emptied researchIds list MUST be preserved as empty. The operator tests ABSENCE:
      absence triggers the map, a present-but-empty list does not.
    category: calculation
    applies_to: ContentAuthority
    trigger: Every parse of an item.
    logic: >
      IF researchIds is absent THEN consult the map. IF it is present and empty THEN keep it empty. In
      Python, test for None, never for falsiness.
    violation: >
      A falsy-test port RESURRECTS LINKS THE OWNER DELIBERATELY DELETED, and does so on every read, so
      the owner cannot clear them at all.
    source: FR9.2

  - id: BR24.1
    statement: >
      The published-document cache interval is a SECURITY parameter with an explicit stated maximum
      of 5 SECONDS. It is never a convenience default, and it is bounded from above by exposure and
      from below by the hard zero-recurring-cost target.
    category: policy
    applies_to: ContentAuthority
    trigger: Every cached read of the published document; every deployment that sets the value.
    logic: >
      The cache feeds the asset-visibility test, so a stale entry means an asset the owner has just
      unreferenced STAYS PUBLIC for the entry's remaining lifetime - an AUTHORIZATION defect, not a
      performance one. UPPER BOUND - with more than one warm instance, a publish invalidates only the
      instance that served it, so the interval IS the exposure window for every other instance rather
      than a backstop; 5 seconds is the largest value that still reads as "immediately" to an owner
      who unreferences an asset and then checks. LOWER BOUND - worst case is one document read per
      interval per warm instance, so 86,400 / interval reads per instance-day; at 5 s that is 17,280,
      which leaves room for two concurrently warm instances inside the 50,000 reads/day free tier,
      while 1 s would be 86,400 and breaks the zero-cost target on a single instance. THEREFORE the
      value is 5 seconds as a MAXIMUM: a deployment may choose lower, never higher, and changing it is
      a security change that gets the same review as changing an authorization rule.
    violation: >
      An unstated or generous interval publishes an asset the owner believes they have made private,
      for as long as the interval lasts, on every instance that did not handle the publish - and
      nothing anywhere reports it.
    source: FR7.6, NFR8
    source_note: >
      Said `none` until review, on the reasoning that no requirement fixes an
      INTERVAL. That confused the value with the rule. FR7.6 reads "The published
      document consulted by FR7.2 may be cached in-process for a short interval.
      The cache changes WHICH REQUESTS HIT STORAGE, never WHICH ASSETS ARE PUBLIC,
      and a publish invalidates it" - which is exactly this rule's existence, and
      `unit-of-work.md` 'U4 Realises' and the story map both assign FR7.6 here.
      The 5-second bound is a new decision resolving the gap FR7.6 leaves open
      ("a short interval"), re-homed from the SKIPPED nfr-design stage by
      WORKING-RECORD 10a Condition 1. Claiming no FR made a requirement this unit
      genuinely discharges look project-wide like an orphan.

  - id: BR24.2
    statement: >
      A successful publish invalidates the cached published document synchronously, inside the
      operation that succeeded and before it returns; the invalidation path carries its own test.
    category: policy
    applies_to: ContentAuthority
    trigger: Every accepted write with action = publish.
    logic: >
      IF a publish is accepted THEN invalidate the cached entry before returning, so the instance that
      handled the publish serves the new document on the very next request. The cache holds exactly
      one entry - the published document - so invalidation is unconditional and needs no key. ADR-002
      records that this path needs ITS OWN TEST because a stale cache here is an authorization defect
      rather than a performance one, and a test that only measures cache hits would pass while the
      invalidation is missing.
    violation: >
      Without the synchronous invalidation even the publishing instance serves the previous document
      for the interval, which turns BR24.1's bound from a residual exposure into the NORMAL one.
    source: FR7.6, NFR8
    source_note: >
      FR7.6's final clause is "and a publish invalidates it" - this rule IS that
      clause, plus ADR-002's requirement that the invalidation carry its own test.
      Previously claimed to trace to no FR; see BR24.1's note.

  - id: BR24.3
    statement: >
      The public read returns the published document ONLY. No draft content may appear in any public
      response, in any field, at any time.
    category: authorization
    applies_to: ContentAuthority
    trigger: Every public read.
    logic: >
      IF a response is public THEN it is derived from published alone. The draft form, the revision
      history and the change flag are owner-only. The public route DOES NOT EXIST in the source - it
      returns 404 there - so this behaviour is SPECIFIED, not preserved, and has no parity fixture to
      check it against; it must be checked by a test of its own.
    violation: >
      Unpublished content reaches visitors. There is no source fixture that would catch it, because
      the source has no such route.
    source: none   # realises NFR11; no FR states it
    source_note: >
      Re-verified at review alongside BR24.1/BR24.2. This one genuinely has no FR:
      FR7.6 governs the cache, not what a public response may contain, and no FR
      states the no-draft-content prohibition. NFR11 is its whole source, and
      `GET /api/public/content` has no parity fixture (it 404s in the legacy app),
      so it is checked by its own test rather than against recorded behaviour.

rules_subject_to_but_not_owned:
  - { id: BR3.1, owner_unit: u6-http-api, why: 'Every protected read and mutation authorises itself at its own operation; this unit''s read, write and inspect operations do so rather than relying on route placement' }
  - { id: BR7.4, owner_unit: u5-media, why: 'An asset is public iff the literal /api/media/<key> appears ANYWHERE in the serialised published document - the document this unit owns and caches, which is why BR7.2, BR24.1 and BR24.2 are security rules' }
  - { id: BR8.6, owner_unit: u9-owner-editor, why: 'The editor does not classify; it submits to this unit''s inspect operation and renders the verdict' }
  - { id: BR8.7, owner_unit: u9-owner-editor, why: 'The third recovery state - inspect unreachable means HOLD the draft - which is why this unit''s inspect failure must be distinguishable from a corrupting verdict' }
  - { id: BR8.8, owner_unit: u9-owner-editor, why: 'Restoring a recovered draft pauses autosave until the owner saves explicitly, so recovery never silently overwrites the stored draft this unit holds' }
  - { id: BR10.1, owner_unit: u6-http-api, why: 'One envelope, key error - this unit raises, it never composes a response' }
  - { id: BR10.2, owner_unit: u6-http-api, why: 'issues[] with path and message on validation failure - the shape BR4.6''s field-level issues are rendered into' }
  - { id: BR10.3, owner_unit: u6-http-api, why: 'The envelope is produced by exception handlers; services raise and routers do not build responses. This is the rule that makes this unit a raiser' }
  - { id: BR10.4, owner_unit: u6-http-api, why: 'The four-member taxonomy this unit raises into: NotAuthorized, Conflict, TooLarge, Invalid' }
  - { id: BR10.5, owner_unit: u6-http-api, why: 'The catch-all is 503, NOT 500, and is logged with a full traceback - anything this unit throws unexpectedly lands here' }
  - { id: BR10.6, owner_unit: u6-http-api, why: 'Recoverable versus fatal is a WIRE-LEVEL distinction: 409 and 400-with-issues are recoverable, 503 is retryable' }
  - { id: BR10.7, owner_unit: u6-http-api, why: 'The verbatim error copy for every condition this unit raises - conflict, too large, unparseable, validation failure, read failure, history 404' }
  - { id: BR10.8, owner_unit: u6-http-api, why: 'The sign-in sentence carries U+2019, verified byte-for-byte against the running source' }
  - { id: BR10.9, owner_unit: u6-http-api, why: 'Four upload strings lose their trigger under FR6.5 and D24: server-side variant generation removes the browser-prepared-variant surface entirely, so the strings disappear rather than being ported. This unit is subject to that removal because it owns nothing that may reintroduce them.' }
  - { id: BR10.10, owner_unit: u6-http-api, why: 'The nine-step check order on the save path; steps 3 and 4 are where BR4.22 positions the size cap, and step 8 is this unit''s conflict signal' }
  - { id: BR10.11, owner_unit: u6-http-api, why: 'Content validation runs BEFORE envelope validation - the ordering that decides which 400 the editor sees for a doubly-invalid request' }
  - { id: BR10.12, owner_unit: u6-http-api, why: 'Envelope validation as one predicate, including autosave being legal only with a draft action' }
  - { id: BR22.1, owner_unit: u2-storage-ports, why: 'The prune''s operational shape inside commit - one transaction, per-action survivor selection, baselines by predicate' }
  - { id: BR22.5, owner_unit: u2-storage-ports, why: 'Payloads round-trip byte-identically, which is what makes BR4.11''s read-back of the stored draft meaningful' }
  - { id: BR22.6, owner_unit: u2-storage-ports, why: 'The store defaults nothing, which is why BR9.2''s transform must run HERE on every read' }
  - { id: BR22.8, owner_unit: u2-storage-ports, why: 'The large-payload path a document-store adapter needs to accept BR4.20''s character cap' }
```

---

## `ContentAuthority` — reading and writing content

### BR4.1–BR4.2 — reading content state [FR4.1]

- **BR4.1** When **no document exists**, the read synthesises
  `{draft: <seed>, published: <seed>, revision: 0, updatedAt: null, publishedAt:
  null, hasUnpublishedChanges: false}` and **writes nothing**. A read must never
  create the document.
- **BR4.2** `hasUnpublishedChanges` is **computed on every read**, never stored: it
  is a full serialised comparison of `draft` against `published`. It is not a flag
  maintained by the write path.

### BR4.3–BR4.5 — draft versus publish [FR4.2]

- **BR4.3** An accepted write **always** overwrites `draft`, for a publish as well as
  for a draft save.
- **BR4.4** `published` and `publishedAt` change **only** when `action = 'publish'`.
  `publishedAt` stays `null` until the first publish; the seeded document is not
  "published".
- **BR4.5** `revision` increments by exactly 1 on **every** accepted write — **drafts
  as well as publishes**. An implementation that only bumps the revision on publish
  breaks the editor's concurrency contract on the very next autosave.

### BR4.6 — authoritative validation [FR4.3]

- **BR4.6** Every write is validated authoritatively in Python **before** it is
  persisted, and a validation failure returns **field-level issues** the editor
  displays, not a generic message (see BR10.2 for the shape). The browser's generated
  mirror is for responsiveness only and is never the enforcement.

### BR4.7 — optimistic concurrency [FR4.4]

- **BR4.7** A write carries the caller's **base revision**. The content update is
  applied only if the stored revision still equals it; otherwise the write is
  rejected as a conflict, the caller's edits are preserved, and the **current state
  is returned with the error** so the caller can reconcile. *(Deliberately not a
  hazard: this failure is loud and the editor already handles it. The silent risk is
  one level down — BR4.8–BR4.19.)*

---

## Hazard — BR4.8–BR4.19, the combined write and its side-effect guard [FR4.5]

The single highest-risk behaviour in the system. It is one call, one caller, one
transaction, carrying the content update, the revision entry **and** the retention
prune together. The source expresses it as **seven statements in one D1 batch**,
which D1 executes as a single implicit transaction. The pure-versus-execute split —
a function that *builds* the statements and a thin executor that *runs* them —
survives the port, because that factoring is what makes the batch inspectable.

Inputs: `content`, `base_revision`, `action`, `now`, `mutation_token`, `retention`.
Derived: `serialized = serialise(content)`, `initial = serialise(<seed>)`,
`publish = (action == 'publish')`, `next_revision = base_revision + 1`.
`mutation_token` is **freshly generated per call** (source: `crypto.randomUUID()`).

- **BR4.8 — Statement 0, bootstrap the singleton.**
  `INSERT INTO site_content (id, draft, published, revision, updated_at) SELECT 1, ?, ?, 0, ? WHERE ? = 0 ON CONFLICT(id) DO NOTHING`,
  bound `(initial, initial, now, base_revision)`.
  Creates the document seeded with the initial content in **both** columns at
  revision 0, with `published_at` left **NULL**. Two guards, both load-bearing:
  `WHERE ? = 0` fires only when the caller claims revision 0, so **a client at
  revision 5 can never resurrect a deleted document**; `ON CONFLICT DO NOTHING`
  makes a concurrent bootstrap harmless.

- **BR4.9 — Statements 1 and 2, capture the permanent baselines, once ever.**
  `INSERT OR IGNORE INTO content_revisions (id, revision, action, content, created_at, baseline) SELECT 'starting-published', revision, 'publish', published, ?, 1 FROM site_content WHERE id = 1 AND revision = ?`,
  and the same with `'starting-draft'`, `'draft'`, `draft`. Both bound
  `(now, base_revision)`.
  The **fixed primary keys** plus `INSERT OR IGNORE` are what make each succeed **at
  most once in the document's lifetime**. They capture the *pre-existing* content —
  the state **before** this write — with `baseline = 1`. `created_at` is the time of
  capture, **not a guessed original publication date**; the source comment says so
  verbatim: *"Capture starting versions once, without guessing their original
  publication date."* The `revision = ?` guard means a stale writer captures nothing.
  A target store without `INSERT OR IGNORE` semantics needs an equivalent that is
  **genuinely idempotent under concurrency** — not a read-then-write.

- **BR4.10 — Statement 3, the compare-and-set. This is the concurrency control.**
  ```sql
  UPDATE site_content SET
    draft = ?,
    published = CASE WHEN ? = 1 THEN ? ELSE published END,
    revision = revision + 1,
    updated_at = ?,
    published_at = CASE WHEN ? = 1 THEN ? ELSE published_at END,
    last_mutation = ?
  WHERE id = 1 AND revision = ?
  RETURNING draft, published, revision, updated_at, published_at
  ```
  bound `(serialized, publish, serialized, now, publish, now, mutation_token, base_revision)`.
  `draft` is always overwritten; `published`/`published_at` move only on publish (the
  two `CASE` expressions **are** how "publish" is expressed); `revision` increments
  unconditionally; `last_mutation` is stamped with this call's token.
  **`WHERE id = 1 AND revision = ?` is the optimistic-concurrency guard**: a stale
  base revision matches zero rows, `RETURNING` yields nothing, and the caller gets
  409.

- **BR4.11 — Statement 4, the history insert, gated on the token.**
  `INSERT INTO content_revisions (id, revision, action, content, created_at, baseline) SELECT ?, revision, ?, draft, updated_at, 0 FROM site_content WHERE id = 1 AND revision = ? AND last_mutation = ?`,
  bound `(mutation_token, action, next_revision, mutation_token)`.
  Three things are load-bearing. (a) The history row's **id is the mutation token**.
  (b) Its `content` is **read back from the row's `draft` column**, and its
  `created_at` from the row's `updated_at` — so the entry is byte-identical to **what
  statement 3 just wrote, not to what the caller sent**. An implementation that
  inserts the caller's payload diverges whenever validation transforms or defaults
  changed the stored value, which — given the `item` transform and the many defaults
  — is **most of the time**. (c) For a publish, `draft` and `published` are equal, so
  storing `draft` is correct for both actions.

- **BR4.12 — Statements 5 and 6, retention, gated on the same token.**
  ```sql
  DELETE FROM content_revisions
  WHERE action = 'draft' AND baseline = 0
    AND id NOT IN (SELECT id FROM content_revisions
                   WHERE action = 'draft' AND baseline = 0
                   ORDER BY revision DESC LIMIT 30)
    AND EXISTS (SELECT 1 FROM site_content
                WHERE id = 1 AND revision = ? AND last_mutation = ?)
  ```
  and the same for `action = 'publish'` with `LIMIT 20`. Both bound
  `(next_revision, mutation_token)`. See BR5.7–BR5.9 for the policy itself, and
  **BR4.18 for the shape the delete must take in the port**.

- **BR4.13 — the ABA scenario, concretely. This is why the token exists.**
  The `revision` CAS and the `last_mutation` token defend **different things**, and
  the second is **not redundant**:
  - `revision` (statement 3) protects **the content write**. It answers *"is the
    caller's view of the document still current?"*
  - `last_mutation` (statements 4, 5, 6) protects **the side effects**. It answers
    *"is the row in its current state because **I** put it there?"*

  The distinction matters because statements 4–6 are guarded on `revision =
  next_revision` — **a value that is not unique to this writer**:

  > The document sits at **revision 5**. Writers **A** and **B** both load
  > revision 5.
  > **B** commits first: the row advances to **revision 6**, stamped with **B's**
  > token.
  > **A's** write now runs. A's statement 3 (`WHERE revision = 5`) matches nothing —
  > **the compare-and-set correctly fails**, and A will receive a 409.
  > **But A's statements 4–6 test `revision = 6`, because A's `next_revision` is
  > also 6 — and B's write satisfies exactly that condition.**

  Without the token, therefore:
  - **Statement 4** inserts a history row keyed by **A's** mutation id, carrying
    **B's** content (it selects `draft` from the row), labelled with **A's** action.
    **A phantom revision that nobody ever saved.**
  - **Statements 5 and 6** run **A's** retention pass off the back of **B's** write,
    **pruning history A had no right to prune** — potentially deleting a revision B
    had just created.

  Adding `AND last_mutation = ?` with a fresh random token per call makes all three
  guards test **identity rather than position**. A stale writer's `next_revision` may
  collide with the winner's `revision`; its random token will not. This is a classic
  **ABA defence**: the revision counter alone cannot distinguish "unchanged" from
  "changed to a coincidentally equal value by someone else", and the token supplies
  the missing identity.

  **What exactly the token prevents:** a losing writer recording a history entry that
  carries the winner's content under the loser's own action, and a losing writer
  executing a retention prune it was never entitled to execute. It prevents nothing
  about the content write itself — that is the CAS's job, and the CAS already works.

- **BR4.14 — the token is not optional, and not an optimisation.** Re-expressing this
  as "CAS on revision, then insert history, then prune" **without** the token
  reintroduces both bugs. They are **timing-dependent and will not appear in
  single-user testing**, which is the entire reason this rule is written out.
- **BR4.15 — the guard does not depend on transactional isolation.** Even under a
  runtime with weaker isolation than one implicit transaction, the token keeps
  statements 4–6 correct. Do not argue the token away on the grounds that the
  transaction already serialises the writes.
- **BR4.16 — all effects commit together or none does.** Atomicity is **required** of
  the port operation (`ContentStore.commit`). Splitting the three effects across
  separate calls or separate transactions breaks both guards.
- **BR4.17 — `results[3]` is a load-bearing positional index.** The source reads the
  CAS result as `results[3]?.results?.[0]`, by **numeric index into the batch array,
  with no comment marking it**. Statement 3 is the `UPDATE`. **Insert a statement
  anywhere before it and the write silently reads the wrong result** — most likely
  `undefined`, which the route interprets as a **409 conflict**. So a refactor of the
  batch produces spurious "this draft changed in another tab" errors rather than a
  crash. The port must read the CAS outcome by **name or by explicit binding**, never
  by position; if a positional read is unavoidable in the chosen driver, the index
  must be asserted by a test.
- **BR4.18 — the prune is expressed as read-the-survivors-then-delete-the-rest,
  inside the transaction** — **not** as a SQL predicate. Firestore has no
  `DELETE ... WHERE id NOT IN (subquery)`, and a SQL-shaped prune would be
  satisfiable by only one adapter. This is a port-contract rule, not an
  implementation preference.
- **BR4.19 — the retention subquery's ordering is not tiebreak-stable, and that is
  preserved.** `ORDER BY revision DESC` alone can tie: multiple rows can share a
  revision (a baseline pair plus a normal entry). **Which row survives at the
  boundary is unspecified** in the source. A faithful port uses the same ordering and
  inherits the same indeterminacy; it must not "fix" it by adding a tie-break,
  because that changes which entries survive.

> **What breaks silently across BR4.8–BR4.19.** Nothing errors and nothing logs. The
> history list grows a row the owner never saved, or loses a row it should have
> kept. It is invisible to single-user testing, invisible to coverage percentages,
> and only reproducible by two concurrent writers holding the same base revision.

**`results[3]` deserves a sentence of its own, because it is the trap a careful
refactor walks into.** The index is not documented in the source, not named, and not
asserted. It is correct today only because statement 3 happens to be fourth. The
failure it produces is **not a crash and not a wrong document** — it is a **spurious
conflict**, which looks exactly like the system working correctly under contention.
A developer who sees "this draft changed in another tab" after a refactor will look
for a concurrency bug, not for an off-by-one in a result array.

---

## BR4.20–BR4.22 — the request-size cap [FR4.6, D11]

- **BR4.20** A save request whose body exceeds **1,500,000 characters** of decoded
  text is rejected as too large. **The cap counts CHARACTERS, not BYTES.** The source
  reads the body as a JavaScript string and tests `.length`, which counts **UTF-16
  code units**.
- **BR4.21** The consequence is concrete: **a document of 1.5 M non-ASCII characters
  can be 3–4 MB of UTF-8**, and an implementation that caps at 1,500,000 *bytes*
  rejects documents the current system accepts. Under the parity rule that is a
  silent, undiscoverable break in the owner's own longest content, so the inelegant
  limit wins over the more defensible one.
- **BR4.22** The cap is checked **after the body is fully read** and **before JSON
  parsing** (BR10.10 steps 3 and 4). It therefore limits **document size, not memory
  use** — the full body is already in memory when the check runs. Reproduce the
  position as well as the number: moving the check after the parse changes which
  status a too-large malformed body receives.

> **Ownership versus enforcement.** BR4.20's rule is owned by `ContentAuthority` —
> this unit owns "the request-size limit and its unit" — while the check is
> necessarily applied at the point where the decoded body first exists, which is
> inside `HttpApi`'s request handling. That is a placement of **enforcement**, not
> of **ownership**, and BR4.22 fixes the ordering so the two cannot drift.

---

## Hazard — BR8.1–BR8.5, recovered-draft classification [FR8.3, ADR-006]

**This is a backend rule.** Review finding R-01 established it as a correctness
rule, so it lives behind `ContentAuthority`'s inspect operation; the editor holds
the bytes and renders the verdict (BR8.6–BR8.8, owned by U9). The current system
gets this rule **wrong**, and the port implements FR8.3.1/FR8.3.2 as written — **not**
the current behaviour. This is D9, one of only three deliberate behaviour changes.

- **BR8.1 — Recoverable: offer the draft.** A value that is **present and of the
  correct type** but **outside its permitted set or range**. Specifically:
  - a string shorter than a minimum (an emptied required title);
  - a string longer than a maximum;
  - a number outside its range;
  - a value failing a format or custom refinement (a malformed email, a bad URL, a
    non-numeric citation count, an impossible citation date);
  - **a value outside an enumerated set** — `accent`, `researchTopic`, the scene's
    `initialView`.

  These are exactly the states an owner produces **by typing**, so the draft is
  kept, repaired against schema defaults, and presented for review.
- **BR8.2 — Corrupting: discard the draft.** A **malformed record**: the wrong JSON
  shape, a field of the wrong type, a missing required structure, or a stored blob
  that is not parseable at all. These indicate corruption rather than in-progress
  editing.
- **BR8.3 — Mapping validation outcomes to the two classes.** Stated in terms of what
  a validator reports, because the source's bug was precisely a mis-mapping:

  | Validation outcome | Class |
  |---|---|
  | Value below a minimum length/size | **Recoverable** |
  | Value above a maximum length/size | **Recoverable** |
  | Custom/refinement predicate failed | **Recoverable** |
  | String format/pattern check failed | **Recoverable** |
  | **Value not a member of an enumerated set** | **Recoverable** |
  | Wrong type for the declared field | **Corrupting** |
  | Required key missing | **Corrupting** |
  | Value is not an object/array where one is required | **Corrupting** |
  | Payload not parseable as JSON at all | **Corrupting** |

- **BR8.4 — What the source does, and why copying it is wrong.** The source
  allowlists four issue codes — `too_small`, `too_big`, `custom`, `invalid_format` —
  and discards the draft if **any** issue falls outside that list. Two defects
  compound: `invalid_format` is a **zod v4** code and the installed package resolves
  to the **v3** API, so that entry **can never match**; and **`invalid_enum_value`,
  which v3 does emit, is absent**. Net effect: **one bad enum discards the owner's
  entire recovered draft**, along with every other unsaved edit in that record —
  while the source's own comment states the opposite intent (*"Retain these
  recoverable edits, but reject malformed field types or shapes."*). Carried from the
  CodeKB with its hedge: this is **a latent defect with a proven mechanism, not a
  confirmed user-visible failure** — the scan demonstrated the code mismatch
  empirically but could not exercise the editor in that environment.
- **BR8.5 — Re-express the classification in the new validator's taxonomy, never by
  copying issue-code strings.** Pydantic's error types share no names with either zod
  version. Copying the four strings across would carry the bug forward **and add a
  second one**. The rule is stated above in terms of *what went wrong with the
  value*, which is portable; the code names are not.

> **What breaks silently.** A recovered draft is discarded and the owner is told the
> record was unusable. No error is raised, no log line names the field, and the lost
> work is unrecoverable. The failure is invisible in normal use precisely because the
> enum fields are edited through select and radio controls — it bites on a draft
> written by an older schema version or through the browser-tool path, which is
> exactly the case recovery exists for.

**The enumerated-set row is the whole hazard in one line.** Every other row in
BR8.3's table would be classified the same way by anyone reasoning from first
principles. The enum row is the one a reasonable implementer puts on the *other*
side — "a value that is not a member of the enum is not a valid value of that type,
so the record is malformed" — and that reasoning is exactly the source's bug.

---

## Hazard — BR9.1–BR9.3, the content-carrying defaults [FR9.2]

- **BR9.1** `researchTopic` resolves through the legacy id→topic map and otherwise to
  `general`; `researchIds` resolves through the seeded id→links map and otherwise to
  `[]`. **Both maps' full contents, the precedence order, and the `??`-not-`or`
  requirement are specified in `entities.md` § W-1 and § W-2.** They are not repeated
  here; that section is normative.
- **BR9.2** This is **logic, not a field default**. It runs on **every parse**, which
  includes **every read out of storage**, not only on writes. A model declaration
  cannot express it, which is exactly why a type-correct port is behaviourally wrong.
- **BR9.3** **An explicitly emptied `researchIds` list must be preserved as empty.**
  The operator is `??`: absence triggers the map, a present-but-empty list does not.
  An `or`/falsy port **resurrects links the owner deliberately deleted**, and does so
  on every read, so the owner cannot clear them at all.

> **What breaks silently.** Three identical slate research cards instead of three
> distinct ones; **0 related papers** on every card; a publications topic filter that
> returns **nothing for every theme**; and the editor's "Card identity" control
> showing `general` for cards the owner never set, **rewriting their identity on the
> next save**. The page renders cleanly throughout. A port of this system passes
> `ruff`, `mypy --strict`, `tsc`, the Compose end-to-end flow and 100% line coverage
> while doing all of the above.

**Two distinct failure modes, and the second is worse.** Getting W-1 wrong makes the
site *look* wrong — three grey cards where there should be three coloured ones —
which a human reviewer might notice. Getting W-2 wrong makes the site look *fine*
and the data wrong: empty filters and zero related papers are indistinguishable from
"the owner has not linked anything yet". **And BR9.3's falsy-test variant is worse
still**, because it is not a one-time error: it re-applies the map on every read, so
an owner who clears a link sees it come back, repeatedly, with no way to make the
clearing stick and no error to report.

---

## `RevisionLedger`

### BR5.1–BR5.4 — listing order [FR5.1]

- **BR5.1** The listing order is a **three-part sort**, not "newest first":
  **`revision DESC`, then `baseline ASC`, then `action DESC`.** In plain terms:
  newest revision first; within one revision, **non-baseline entries before baseline
  entries**; then **`publish` before `draft`** (descending string order).
- **BR5.2** All three parts are **load-bearing for what the owner sees**. A port that
  sorted on revision alone would list a tied revision in a different order **while
  passing any test written from a looser wording** — which is why the conformance
  suite must assert the full order.
- **BR5.3** The listing is capped at **52** entries. **This is not a page size and
  there is no pagination.** 52 is `30 drafts + 20 publishes + 2 baselines` — the
  listing limit and the retention policy are the same number **by construction**
  (BR5.7). Changing one without the other silently truncates history or shows nothing
  new.
- **BR5.4** On the Firestore adapter this order **requires a declared composite
  index**. The deployment plan must carry that index definition, and the conformance
  suite must assert the order, so a missing index **fails a test rather than silently
  reordering the list**.

> **BR5.1 is confirmed against data, not against the query.** A history listing from
> the running source returned revision 4, 3, 2, 1 as non-baseline drafts, then
> **revision 0 `publish` baseline (`starting-published`)**, then **revision 0 `draft`
> baseline (`starting-draft`)**. That is all three sort keys exercised by real rows,
> and it confirms the two literal baseline ids at the same time.

### BR5.5–BR5.6 — fetching one revision [FR5.2]

- **BR5.5** A revision id is validated before use: **absent** (`id` parameter not
  present at all) means **list**; **present but empty**, longer than **100**
  characters, or failing `/^[a-zA-Z0-9-]+$/` is a **400**, not a list and not a 404.
  The absent-versus-empty distinction is a real branch — `?id=` is a 400.
- **BR5.6** Restoring a revision into the editor **never publishes**. It returns the
  entry's content for review; the owner must save or publish explicitly.

### BR5.7–BR5.9 — retention [FR5.3]

- **BR5.7** Retention keeps the **30 most recent non-baseline draft entries** and the
  **20 most recent non-baseline publish entries**. The two counts are independent — a
  run of 30 drafts never evicts a publish.
- **BR5.8** The **two starting baselines are kept permanently** and are **never
  pruned**. Both retention deletes exclude `baseline = 1` explicitly; the exclusion is
  part of the delete predicate, not a coincidence of ordering.
- **BR5.9** `RevisionLedger` **owns the retention policy but performs no write**. It
  supplies the policy; `ContentAuthority` applies it inside its one combined write
  (ADR-001). `RevisionLedger`'s own store access is **read-only**. Reading the entity
  ownership table alone would suggest otherwise.

### BR5.10 — absent revisions [FR5.4]

- **BR5.10** A revision id that is well-formed but absent — or whose entry has been
  pruned, or whose row carries no content — returns **404** with a body that states
  **the current draft is unaffected**. Reassuring the owner is part of the rule, not
  decoration: the verbatim sentence is in BR10.7.

---

## The published-document cache — BR7.1, BR7.2, BR24.1, BR24.2

**All four rules of the cache are declared in this unit**, and they discharge
**FR7.6 between them** — a requirement whose two clauses ask for two different
things. Reading it as one undivided requirement is what let it look, for two
iterations, like two units claiming the same thing:

| FR7.6 clause | Rule | What it fixes |
|---|---|---|
| 1 — *"may be cached in-process for **a short interval**"* | **BR24.1** | The interval: **5 seconds, as a maximum** |
| 1 — *"and a publish invalidates it"* | **BR24.2** | The invalidation is **synchronous and inside the operation** |
| 2 — *"changes **which requests hit storage, never which assets are public**"* | **BR7.2** | The safety property, almost verbatim |
| — | **BR7.1** | The **placement**: the cache lives here, so invalidation never crosses a component boundary |

**BR7.1 and BR7.2 were declared in `u5-media` until review** and moved here by
coordinator decision; media's declarations already carried
`owned_by_unit: u4-content-core` and `applies_to: ContentAuthority`. `u5-media`
**consumes** this cache — it is the cache's only reader, on its public read path —
and holds none of its own (BR25.1, declared there). Consuming is not owning.

**The interval was owned by `nfr-design`. That stage was SKIPPED in-flight, and the
human re-homed the parameter here**, with a condition attached: it *"must carry an
explicit stated bound, never a convenience default."* This section discharges that.

### BR7.1 and BR7.2 — placement, and the property the interval is bounded by

**BR7.1 — the cache lives here, and that is the whole of the rule.** A second cache
in a consuming component would not receive BR24.2's invalidation: `ContentAuthority`
invalidates its own and knows nothing about anyone else's. Placement is what makes
invalidation a local operation rather than a distributed one, and a local
invalidation is the only kind this system can actually guarantee.

**BR7.2 — the cache may change which requests reach storage; it may never change
the answer.** This is the property every other rule in the group exists to protect:
BR24.2 stops the publishing instance from violating it, and BR24.1 bounds how far
*other* warm instances can violate it before they converge. Stated as a property
rather than a mechanism, because a port that satisfies the mechanism and breaks the
property has broken the requirement.

### Why it is a security parameter and not a tuning one

The cache feeds the asset-visibility test (BR7.4, owned by U5): an asset is public
**iff the literal `/api/media/<key>` appears anywhere in the serialised published
document**. The cache is where that document comes from.

**So a stale cache entry means an asset the owner has just unreferenced stays
public for the remaining lifetime of the entry.** That is an **authorization
defect**. It is not a slow page, not a stale render, not an inconsistency a refresh
fixes — it is content the owner believes they have made private, being served to
anyone who has the URL.

### BR24.1 — the stated bound: **5 seconds, as a maximum**

**Bounded from above by exposure.** The obvious reading is that
invalidation-on-publish handles the real case and the interval is only a backstop.
**That reading is wrong as soon as there is more than one warm instance.** The
cache is in-process; a publish invalidates **only the instance that served it**.
Every other warm instance keeps serving its own cached published document until its
entry expires. **The interval is therefore the actual exposure window for every
instance that did not handle the publish**, not a defence in depth. Five seconds is
the largest value that still reads as "immediately" to an owner who unreferences an
asset, publishes, and then checks whether it is gone.

**Bounded from below by the hard zero-recurring-cost target.** Worst case is one
published-document read per interval per warm instance: `86,400 / interval` reads
per instance-day. At **5 s** that is **17,280 per instance-day**, which leaves room
for two concurrently warm instances inside the free tier's **50,000 reads/day**. At
1 s it would be **86,400**, which breaks the target on a single instance before any
other read is counted.

**Therefore: 5 seconds, stated as a maximum.** A deployment may choose **lower**,
never higher. The value is **configuration with a stated ceiling**, not a magic
number and not a tuning knob: **changing it is a security change and gets the same
review as changing an authorization rule.**

Two further properties, stated so they are not left implicit:

- **The cache holds exactly one entry** — the published document. It is not a
  per-asset cache and has no key, which is what makes BR24.2's invalidation
  unconditional.
- **The bound applies uniformly on both adapters.** The locally verified adapter has
  no read cost, so the lower bound is a cloud-path constraint — but the value is the
  same on both, so the verified path exercises the same behaviour the cloud path
  will have.

### BR24.2 — the invalidation path

**A successful publish invalidates the cached entry synchronously, inside the
operation that succeeded and before it returns.** The instance that handled the
publish therefore serves the new document on the very next request.

**ADR-002 records that this path needs its own test**, and the reason is worth
repeating: a test that measures cache *hits* passes whether or not the invalidation
exists. The test has to assert the **authorization consequence** — publish a
document that no longer references an asset, then request that asset, and require a
404 — because that is the behaviour the cache can silently break.

> **What breaks silently.** Nothing errors. The site serves correctly, the editor
> reports a successful publish, and an asset the owner removed stays readable to
> anyone holding its URL — on every instance that did not handle the publish, for as
> long as the interval lasts. With no stated bound, "as long as the interval lasts"
> is whatever a developer typed.

---

## Subject to, not owned — the error envelope [hazard, FR10.1]

**BR10.1–BR10.12 are declared in `construction/http-api/functional-design/rules.md`.**
They are carried here in full because **this unit is the one that raises into
them**: BR10.3 says services raise and routers do not build responses, and this unit
is the service. Every conflict, every validation failure, every too-large body and
every unexpected throw in this unit lands in this envelope.

> **What breaks silently.** FastAPI's defaults produce `{"detail": ...}` and
> Pydantic's `loc` / `msg` on validation errors. The ported editor branches on
> `409` to enter conflict recovery and reads `result.issues` to highlight fields.
> With FastAPI's defaults, the editor **appears to work**: requests succeed,
> statuses are returned, nothing throws — but field highlighting shows nothing and
> conflict recovery never arms. This is the highest-probability silent regression
> in the migration.

- **BR10.1** Every error response across the whole HTTP surface carries exactly one
  envelope: `{"error": "<one human sentence>"}`. The key is `error`, not `detail`,
  not `message`.
- **BR10.2** On a **validation** failure only, the envelope additionally carries
  `issues`: an array of `{"path": [...], "message": "..."}`. The keys are `path`
  and `message` — not `loc` and `msg`. `path` is an array whose members are strings
  or integers (an integer member is a collection index).
- **BR10.3** The envelope is produced by **exception handlers**, never constructed
  per route. Services raise; routers do not build responses.
- **BR10.4** The exception taxonomy has exactly **four** members, mapped once:

  | Exception | Status | Carries `issues` |
  |---|---|---|
  | `NotAuthorized` | **403** | no |
  | `Conflict` | **409** | no |
  | `TooLarge` | **413** | no |
  | `Invalid` | **400** | **yes** |
  | anything else | **503** | no |

- **BR10.5** The catch-all status is **503, not 500**. This matches the source
  exactly: all four source routes return 503 on an unexpected throw. An unhandled
  exception is additionally logged with a full traceback (`logger.exception()`) —
  surfaced or logged, never swallowed.
- **BR10.6** Recoverable versus fatal is a **wire-level** distinction, not an
  internal one: `409` and `400`-with-`issues` are recoverable and the frontend keeps
  specific handling for each; `503` is retryable with no specific handling.

**`else → 503` is the branch this unit must not get wrong.** It is the one place
where the correct answer is the *unusual* one: every framework default, every
convention and every reviewer's instinct says 500. **The source returns 503 on all
four routes**, and under the parity rule that is what the owner's browser and any
client sees. A port that returns 500 has changed observable behaviour for every
unexpected failure in the system — and it will look more correct while doing it.

**What this unit must do to hold up its end of BR10.3:** raise the four taxonomy
members and nothing else. A conflict is `Conflict`, not a return value the router
inspects; a validation failure is `Invalid` carrying its per-field issues; an
over-cap body is `TooLarge`; an unauthorised caller is `NotAuthorized`. Anything
this unit throws that is not one of the four **becomes a 503** — which is correct,
and is also why an internal error must never be raised as one of the four to "get a
nicer status".

### BR10.7–BR10.9 — the error strings this unit's conditions produce [FR10.2]

Every sentence below is **product copy under the parity rule**; a port that rewrites
one has changed what the owner sees. These are the rows that this unit's conditions
trigger:

| Situation | Status | String |
|---|---|---|
| Not the owner (all routes) | 403 | `Please sign in with the website owner’s account.` |
| Body over the character cap | 413 | `This update is too large.` |
| Body not parseable as JSON | 400 | `The update could not be read.` |
| Body falsy, non-object, array, or envelope invalid | 400 | `Invalid save request.` |
| Content validation failed | 400 | `Please check the highlighted fields before saving.` |
| Revision conflict | 409 | `This draft changed in another tab. Your edits are still here. Review the latest saved draft before saving again.` |
| Save threw | 503 | `Your changes could not be saved. They are still in the form. Please try again.` |
| Content read threw | 503 | `Unable to load your draft. Please try again.` |
| History id malformed | 400 | `Choose a saved version from the history list.` |
| History id absent or pruned | 404 | `This version is no longer in the recent history. Your current draft is unchanged.` |
| History read threw | 503 | `Version history is temporarily unavailable. Your current edits are safe.` |

**BR10.8:** `Please sign in with the website owner’s account.` contains **U+2019
RIGHT SINGLE QUOTATION MARK**, not an ASCII apostrophe — **captured verbatim from
the running source**. A parity diff against recorded fixtures compares bytes; a
straight `'` fails it.

### BR10.10–BR10.12 — check ordering on the save path [FR4.7]

- **BR10.10** The checks run **strictly in this order**, because the order determines
  which status a multiply-invalid request receives:

  1. Origin match → 403
  2. Owner session → 403
  3. Decoded body length over the cap → 413
  4. JSON parse failure → 400
  5. Body falsy, not an object, or an array → 400
  6. **Content schema validation → 400 with `issues[]`**
  7. **Envelope validation → 400 without `issues[]`**
  8. Write returns a conflict signal → 409
  9. Otherwise → 200

- **BR10.11** **Content validation (6) runs BEFORE envelope validation (7).** A
  request carrying both malformed `content` and a bad `revision` returns the
  *content* 400 with `issues[]`, not the envelope 400. Reordering these two silently
  changes the error the editor displays — the editor highlights fields on one and
  shows a bare sentence on the other.
- **BR10.12** Envelope validation (step 7) rejects unless **all** hold, evaluated as
  one predicate: `revision` is a safe integer; `revision >= 0`; `revision <
  Number.MAX_SAFE_INTEGER`; `action` is exactly `draft` or `publish`; `autosave` is
  absent or a boolean; and **not** (`autosave === true` **and** `action !==
  'draft'`). Autosave is legal only with a draft action.

**Steps 3 and 4 are where BR4.22 lives**, and steps 6 and 7 are where BR4.6's issues
are produced. Step 8 is this unit's conflict signal from BR4.7.

---

## The unsavable-recovered-draft window — an open question, not a decision

**A latent defect with a proven mechanism, found at this stage, with no owner
before now. It is recorded here and deliberately NOT resolved.**

**The facts.** The recovery path accepts a stored draft up to **6,000,000
characters**. The save path rejects anything over **1,500,000 characters**
(BR4.20). **The two limits were chosen independently in the source**; nothing
relates them.

**The consequence.** A recovered draft whose length falls **between 1,500,000 and
6,000,000 characters** is **restorable into the editor and unsavable from it**. It
loads, it renders, the owner can edit it — and every save attempt fails with the
too-large rejection, **including every autosave**. The owner is in a state where
their work is visible, apparently recovered, and cannot be persisted by any action
available to them.

**This is real behaviour, not speculation.** Both numbers are read from the source.

**The two options, neither of them chosen here:**

| Option | What it does | What it costs |
|---|---|---|
| **A — align the limits** | Lower the recovery ceiling to 1,500,000 so that anything recoverable is savable | Changes observable behaviour: a draft between the bounds that today *loads* would no longer load at all. Under the parity rule that is a deliberate behaviour change and needs the same treatment as D9 |
| **B — warn at recovery time** | Keep both limits and detect the window at recovery, telling the owner the draft exceeds the save limit before they invest work in it | Preserves current loading behaviour exactly; adds a message and a state the editor does not have today, which means new copy and a new branch in a unit that is not this one |

**Why it is not decided here.** Option A changes preserved behaviour under a parity
rule that is otherwise absolute, and option B adds a user-facing state to the
editor, which is U9's surface and carries new product copy. **Both are decisions the
site owner should make**, and neither is forced by any rule already agreed. Picking
one silently would be the worse outcome — it would look like an implementation
detail and it is not.

**What must not happen:** the window being left undetected *and* unrecorded, so that
the first person to meet it is the owner, with 3 MB of work they cannot save and no
explanation.

---

## Rules summary

| Group | Rules | Component | Category mix | Requirement |
|---|---|---|---|---|
| Reading content state | BR4.1–BR4.2 | `ContentAuthority` | constraint, calculation | FR4.1; **FR9.3** (BR4.1 — the seeded document) |
| Draft versus publish | BR4.3–BR4.5 | `ContentAuthority` | constraint | FR4.2 |
| Authoritative validation | BR4.6 | `ContentAuthority` | validation | FR4.3 |
| Optimistic concurrency | BR4.7 | `ContentAuthority` | constraint | FR4.4 |
| **The combined write** | **BR4.8–BR4.19** | `ContentAuthority` | constraint, policy | **FR4.5 (hazard)** |
| The request-size cap | BR4.20–BR4.22 | `ContentAuthority` | validation, policy, constraint | FR4.6 |
| Listing order | BR5.1–BR5.4 | `RevisionLedger` | constraint, policy | FR5.1 |
| Fetching one revision | BR5.5–BR5.6 | `RevisionLedger` | validation, constraint | FR5.2 |
| Retention | BR5.7–BR5.9 | `RevisionLedger` | policy | FR5.3 |
| Absent revisions | BR5.10 | `RevisionLedger` | constraint | FR5.4 |
| **Recovery classification** | **BR8.1–BR8.5** | `ContentAuthority` | policy | **FR8.3 (hazard)** |
| **Content-carrying defaults** | **BR9.1–BR9.3** | `ContentAuthority` | calculation | **FR9.2 (hazard)** |
| The cache's placement and safety property | BR7.1–BR7.2 | `ContentAuthority` | policy | **FR7.6 clause 2** |
| The published-document cache interval | BR24.1–BR24.2 | `ContentAuthority` | policy | **FR7.6 clause 1** (re-homed interval), NFR8 |
| The public read | BR24.3 | `ContentAuthority` | authorization | *(BR24.3 is the only rule here with no FR — NFR11)* |
| *Subject to — the error envelope* | *BR10.1–BR10.12* | *`HttpApi` (U6)* | *constraint, policy* | ***FR10.1 (hazard), FR10.2, FR4.7*** |
| *Subject to — recovery rendering* | *BR8.6–BR8.8* | *`OwnerEditor` (U9)* | *policy* | *FR8.3* |
| *Subject to — asset visibility* | *BR7.4* | *`media` (U5)* | *policy* | *FR7.2* |
| *Subject to — port obligations* | *BR22.1, BR22.5, BR22.6, BR22.8* | *`storage-ports` (U2)* | *constraint, policy* | *FR4.5, FR4.6, FR9.2* |

---

## Assumptions & Open Questions

- **[open, assigned to this unit — the latent defect with no owner]** The
  **unsavable-recovered-draft window**: recovery accepts up to **6,000,000**
  characters, the save path rejects above **1,500,000**, and a draft between those
  bounds is **restorable and unsavable, autosave included**. Two options — **align
  the limits** or **warn at recovery time** — are set out in full above. **Neither
  is chosen here**, because A changes preserved behaviour under the parity rule and
  B adds user-facing copy and a state to U9's surface. This needs the site owner.
- **[declaration conflict — RESOLVED by the coordinator; BR7.1 and BR7.2 are now
  declared here]** They were declared by `u5-media` and listed here as *subject to,
  not owned* to avoid a double declaration, escalated because **four sources said
  they belong to this unit**: the workflow-level rule index assigns `BR7.1–BR7.2`
  to `ContentAuthority`; ADR-002 places the cache here; media's own declarations
  carried `owned_by_unit: u4-content-core` and `applies_to: ContentAuthority`; and
  `units-generation/traceability.json` assigns **FR7.6 to U4**. The declaration's
  location was the lone dissenter, so it moved.

  **The resolution was not that one claim was wrong — it was that FR7.6 is a split
  requirement nobody had written down as split.** Its two clauses are discharged by
  two different rule pairs, and both pairs are genuine:

  | FR7.6 clause | Discharged by | How |
  |---|---|---|
  | 1 — *"may be cached in-process for **a short interval**"* | **BR24.1, BR24.2** | The interval itself (5 s maximum) and its invalidation on publish |
  | 2 — *"changes **which requests hit storage, never which assets are public**, and a publish invalidates it"* | **BR7.2** | Almost verbatim |
  | — the placement that makes clause 2 achievable | **BR7.1** | The cache lives in `ContentAuthority`, so invalidation never crosses a component boundary |

  The corpus previously read as **two units claiming the same requirement**; it now
  reads as **one unit discharging both halves**, with a single `coverage` entry
  naming all four rules and the clause each one carries. `u5-media` **consumes**
  this cache on its public read path (and holds none of its own, BR25.1) and
  **claims no part of FR7.6**.
- **[assumption]** `BR24.1`'s value of **5 seconds** is a **new decision made at
  this stage**, not a carried one. Its two bounds are argued from stated facts — the
  multi-instance invalidation gap, and the 50,000 reads/day free-tier figure — but
  **no measurement was taken**, and the read-rate worst case assumes one cached read
  per interval per instance, which is an upper bound rather than an observation. If
  a measurement later contradicts the lower bound, the value moves **down**, never
  up.
- **[assumption]** `BR24.2`'s invalidation is **synchronous and inside the
  operation**. ADR-002 requires the invalidation and its test; it does not spell out
  synchrony. Synchronous is chosen because an asynchronous invalidation reintroduces
  a window on the publishing instance itself, which is the one case the interval is
  not covering.
- **[carried hedge — BR8.4]** The source's classification defect is recorded by the
  knowledge base as **"a latent defect with a proven mechanism, not a confirmed
  user-visible failure"**: the issue-code mismatch was demonstrated empirically, but
  the scan could not exercise the editor to observe a discarded draft. **The port's
  behaviour does not depend on resolving it**, because FR8.3 specifies the intended
  rule rather than the observed one.
- **[carried hedge — CodeKB truncated two strings]** The knowledge base quotes the
  save-failure 503 and the variant-envelope 400 elided. BR10.7's table gives the
  **full** strings, transcribed from the source routes, because a truncated string
  is not a usable parity target. The recorded source fixtures are the confirmation
  of record.
- **[note]** BR4.20's rule is owned by `ContentAuthority` while the check is applied
  where the decoded body first exists, inside `HttpApi`. That is a placement of
  **enforcement**, not of **ownership**, and BR4.22 fixes the ordering so the two
  cannot drift.
- **[note]** **No rule here requires a background worker, scheduler or queue
  consumer.** Retention runs **inside the write that triggers it**, and the cache
  expires by age rather than by a sweep.
- **[note]** The **public read has no parity fixture**: `GET /api/public/content`
  returns 404 in the source and is a new route in the target design. BR24.3's
  prohibition therefore has to be checked by a test of its own rather than against
  recorded behaviour.

## Sources

- `construction/functional-design/rules.md` §§ *`ContentAuthority`* (BR4.1–BR4.22,
  BR8.1–BR8.5, BR9.1–BR9.3, BR7.1–BR7.2), *`RevisionLedger`* (BR5.1–BR5.10),
  *`HttpApi`* (BR10.1–BR10.12, quoted here, declared by U6), *`OwnerEditor`*
  (BR8.6–BR8.8, declared by U9) — carried with their ids and their full text.
- `construction/content-core/functional-design/entities.md` §§ W-1, W-2 — normative
  for BR9.1.
- `inception/requirements-analysis/requirements.md` FR4.1–FR4.7, FR5.1–FR5.4,
  FR7.6, FR8.3.1–FR8.3.3, FR9.1–FR9.4, FR10.1–FR10.2, NFR8, NFR11.
- `inception/domain-design/decisions.md` ADR-001 (one combined write), ADR-002
  (cache placement, and that the invalidation needs its own test), ADR-006
  (classification is a backend rule).
- `inception/contract-design/contract-summary.md` §§ C1 (statuses, envelope), C2
  (`commit`, `list_revisions`, prune shape, atomicity).
- **Boot verification of the running source, executed 2026-09-24** — the three-part
  ordering confirmed against data with the two literal baseline ids; the
  unauthenticated error body captured byte-for-byte with its U+2019 apostrophe; and
  `GET /api/public/content` returning 404.
- `WORKING-RECORD.md` §§ 2 (D9, D11, D12), 3 (FR4.5, FR8.3, FR9.2, FR10.1 and their
  silent failure modes), 5, **8** (the 50,000 reads/day free-tier figure behind
  BR24.1's lower bound), **9** (the unsavable-recovered-draft window, unassigned
  until this stage), **10a Condition 1** (the cache interval re-homed here).
