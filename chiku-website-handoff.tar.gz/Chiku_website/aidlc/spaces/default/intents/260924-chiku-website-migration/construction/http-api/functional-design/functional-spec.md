# Functional Specification — U6 `http-api`

**Unit:** `u6-http-api` · **Kind:** `service` · **Component:** `HttpApi`

**Upstream:** `construction/functional-design/functional-spec.md` (the end-to-end flows
this unit fronts), companion artifacts `entities.md` and `rules.md`,
`inception/contract-design/contract-summary.md` § C1,
`inception/units-generation/unit-of-work.md` § *U6 — http-api*,
`inception/domain-design/decisions.md` ADR-003.

How each operation behaves at the HTTP surface. Wire shapes are in `entities.md`;
business rules carry `BR` ids in `rules.md`; this document is the flow that binds them.

**The standard these three files must meet:** a developer implements this unit from
them without re-reading `madhavi-tripathi/`. Every point where a reader would have to
go back is a defect.

## What this unit is, and what it is not

`HttpApi` is **the one deployed Python executable** — the only unit in the system
declaring `service`. Every other backend unit is a library embedded in it.

It is also **where the language boundary physically sits**, and it owns exactly four
things: **route definitions**, **the single error envelope and its taxonomy**,
**origin/CSRF middleware and request context**, and **the OpenAPI document**.

It owns nothing else. In particular:

- **It holds no state and touches no store.** An AST test asserts that no module under
  `routers/` imports a `store` module or `sqlite3` (BR26.1).
- **It makes no authorization decision.** It resolves identity and carries it; the
  component behind the route decides (BR3.2). This is not a stylistic preference — it
  is the behavioural half of the trade **ADR-003** made when it chose one `HttpApi`
  over a `PublicApi`/`OwnerApi` split.
- **It defines no schema.** The content schema is `u4-content-core`'s; this unit
  publishes the generated document and does not restate it.
- **It constructs no error response.** Services raise; exception handlers map
  (BR10.3).

**Route handlers stay thin.** A handler reads the request, calls one service, and
returns the success shape. It has **no error branch at all** — because the error branch
is exactly what diverges per route, and the envelope is this unit's one hazard.

## Cross-cutting behaviour

**Error envelope (FR10.1, hazard).** Every failure returns
`{"error": "<one sentence>"}`, plus `"issues": [{"path": [...], "message": "..."}]` on
validation failure. Produced by **exception handlers**, never constructed in a route.
Services raise `NotAuthorized` → 403, `Conflict` → 409, `TooLarge` → 413, `Invalid` →
400 (carrying `issues`), **anything else → 503** with `logger.exception()`. **503
rather than 500 matches the original.** The error strings are **product copy** and fall
under the parity rule. **499 sits outside the taxonomy and is mapped explicitly**
(BR26.2).

**Async.** Handlers and services are `async`. The SQLite adapter wraps its synchronous
driver in `anyio.to_thread.run_sync` **inside the adapter**; a handler or service never
touches a blocking driver. Event-loop blocking is invisible to every check on the merge
gate, which is why it is a rule rather than something a gate catches.

**Wire format.** `camelCase`, frozen. One conversion point: a shared Pydantic base with
`alias_generator=to_camel` and `populate_by_name=True`.

**Same-origin.** **Every method that is not `GET` or `HEAD`** requires a matching
`Origin` **and** the CSRF token paired with the session. **A missing `Origin` header
fails closed** (BR3.3). Never applied to `GET`/`HEAD` (BR3.5). The test is the
**method**, not whether the operation writes — so it covers
`POST /api/content/inspect`, which writes nothing. **Origin is checked before any
payload is read or measured.**

## Units behind the routes

This unit depends on seven components across four units and owns none of them.

| Route group | Component | Unit |
|---|---|---|
| `/api/auth/login` (credentials) | `OwnerIdentity` | `u3-identity-and-session` |
| every request (session), `/api/auth/logout` | `SessionAuthority` | `u3-identity-and-session` |
| `/api/auth/login` (rate limit) | `LoginGuard` | `u3-identity-and-session` |
| `/api/content`, `/api/public/content`, `/api/content/inspect` | `ContentAuthority` | `u4-content-core` |
| `/api/history` | `RevisionLedger` | `u4-content-core` |
| `/api/upload` | `MediaIntake` | `u5-media` |
| `/api/media/{key}` | `MediaDelivery` | `u5-media` |

---

## Derived views

**These two sections are derived, not authoritative.** The entity relationships are
derived from `entities.md` § *Source of truth*; the rules summary is derived from
`rules.md` § *Source of truth*. Where a derived view and its source disagree, **the
source governs** and the disagreement is a defect in this file.

### Entity relationships (derived from `entities.md`)

`HttpApi` owns **no persisted entity** — `components.md` records `entities: []`. What
it owns is the set of **wire contracts**, and their relationships are to each other and
to entities owned elsewhere.

```mermaid
erDiagram
    ERROR_ENVELOPE {
        string error          "one human sentence; key is error, NOT detail"
        array  issues         "optional; ONLY on a validation failure"
    }
    VALIDATION_ISSUE {
        array  path           "key is path, NOT loc; integer member is a list index"
        string message        "key is message, NOT msg"
    }
    SAVE_ENVELOPE {
        object  content       "the full document; schema owned by u4-content-core"
        integer revision      "safe integer, at least 0, below MAX_SAFE_INTEGER"
        enum    action        "draft or publish; no third value"
        boolean autosave      "optional; legal ONLY with action draft"
    }
    REQUEST_CONTEXT {
        string method         "decides whether origin enforcement applies at all"
        string requestOrigin  "nullable; ABSENT IS A FAILURE, not same-origin"
        string urlOrigin      "requestOrigin must EXACTLY equal this"
        string csrfToken      "nullable; double-submit, paired with the session"
        string sessionCookie  "nullable; signed; bad signature means anonymous"
        string ownerIdentity  "nullable; resolved, never decided on here"
    }
    SESSION {
        string sessionId   PK "ENT-2, owned by u3-identity-and-session"
        string csrfToken      "paired 1 to 1 with the session"
    }
    CONTENT_DOCUMENT {
        string documentId  PK "ENT-4, owned by u4-content-core"
        integer revision      "compared against SAVE_ENVELOPE revision"
    }
    ERROR_ENVELOPE   ||--o{ VALIDATION_ISSUE : "carries, only when Invalid"
    REQUEST_CONTEXT  }o--o| SESSION          : "resolves, via the signed cookie"
    SAVE_ENVELOPE    }o--|| CONTENT_DOCUMENT : "targets, via base revision"
```

**Text fallback, in case the diagram does not render.** Six boxes and three edges.

- **`ERROR_ENVELOPE`** (`WIRE-1`) — `error` (required, one sentence, key is **`error`**
  not `detail`) and `issues` (optional, **present only on a validation failure**).
- **`VALIDATION_ISSUE`** (`WIRE-2`) — `path` (array of string-or-integer; key is
  **`path`** not `loc`; an integer member is a collection index) and `message` (key is
  **`message`** not `msg`).
- **`SAVE_ENVELOPE`** (`WIRE-3`) — the `PUT /api/content` body: `content`, `revision`,
  `action`, optional `autosave`.
- **`REQUEST_CONTEXT`** (`WIRE-4`) — internal, never serialised. Six fields, of which
  `requestOrigin` carries the load-bearing rule: **absent is a failure, not
  same-origin**.
- **`SESSION`** (`ENT-2`) and **`CONTENT_DOCUMENT`** (`ENT-4`) are owned **elsewhere**
  and shown only because this unit's contracts point at them.

Edges:

1. **`ERROR_ENVELOPE` → `VALIDATION_ISSUE`, one-to-many, optional.** Populated **only**
   when the raised exception is `Invalid`. On 403, 409, 413, 499 and 503 the key is
   **absent**, not empty.
2. **`REQUEST_CONTEXT` → `SESSION`, many-to-one, optional, unenforced.** Resolved from
   the signed cookie by `SessionAuthority`, which returns the owner identity **or
   nothing**. This unit **carries** the result and never reads the store.
3. **`SAVE_ENVELOPE` → `CONTENT_DOCUMENT`, many-to-one.** `revision` is the caller's
   **base** revision, compared by `ContentAuthority`'s compare-and-set. A mismatch is a
   **409**, not a 400 — a conflict, not a malformed request.

### Rules summary (derived from `rules.md`)

| Rules | Subject | Requirement | Hazard |
|---|---|---|---|
| **BR10.1–BR10.6** | **The single error envelope, the four-member taxonomy, 503-not-500, and the wire-level recoverable/fatal split** | **FR10.1**; FR10.3 (BR10.5, BR10.6) | **yes** |
| BR10.7–BR10.9 | 21 verbatim error strings; the U+2019; the four deliberately retired strings | FR10.2 | — |
| BR10.10–BR10.12 | The nine-step check order on `PUT /api/content`; content-before-envelope; the envelope predicate | FR4.7 | — |
| BR3.1–BR3.2 | Every operation authorises itself; this unit enforces nothing beyond transport | FR3.8; **NFR2 at BR3.1 only** | — |
| BR3.3–BR3.5 | Origin present **and** exactly equal; CSRF on top; **every method that is not `GET`/`HEAD`**, checked before any payload is read; **one enumerated exception** — the owner-provisioning route | FR6.7 | — |
| BR26.1 | Boundary enforcement is a command: grep, AST test, dirty-regeneration check | **no FR** (NFR1) | — |
| BR26.2 | 499 is mapped explicitly and never falls through to 503 — the **local** closure of a workflow-level gap | **no FR** | — |
| BR26.3 | The OpenAPI document is generated, never hand-maintained | **no FR** (NFR1) | — |
| BR26.4 | `POST /api/content/inspect` body cap: **6,000,000 characters** — the recovery bound, **not** the save cap | **no FR** (a gate decision) | — |

**21 rules. 6 are hazard rules** — each needs a test per enumerated branch and falls
inside the 100% scoped coverage floor. **BR26.1–BR26.4 trace to no FR** and belong in
the traceability `reverse` array, not in `coverage`.

**This table is derived and the `source` fields in `rules.md`'s yaml block govern.**
In particular, **this unit realises NFR2 at `BR3.1` and nowhere else** — `BR3.2`
supports NFR2 without discharging it — and that claim is stated once, in that block's
`nfr_realisation_note`.

---

## The error envelope — how it is produced

**This is the unit's hazard and the highest-probability silent regression in the
migration.** The mechanism is three layers and no fourth:

1. **A service raises** one of the four taxonomy members, or something unexpected.
2. **A registered exception handler maps it** to a status and builds the envelope —
   once, for the whole surface.
3. **The route handler returns only the success shape.** It has no error branch.

### The mapping, and the two things it must also cover

| Raised | Status | Body |
|---|---|---|
| `NotAuthorized` | **403** | `{"error": ...}` |
| `Conflict` | **409** | `{"error": ...}` |
| `TooLarge` | **413** | `{"error": ...}` |
| `Invalid` | **400** | `{"error": ..., "issues": [{"path": [...], "message": ...}]}` |
| *cancellation* | **499** | `{"error": ...}` — **outside the taxonomy, mapped explicitly** (BR26.2) |
| anything else | **503** | `{"error": ...}`, plus `logger.exception()` with a full traceback |

Two paths are easy to leave uncovered and both are part of "the whole HTTP surface":

- **Requests that never reach a route handler** — an unknown path, a wrong method, a
  framework-level request-validation failure, a middleware rejection. Each produces a
  framework default **by default**, which is `{"detail": ...}`. Handlers must be
  registered for these too, or "exactly one envelope" is true only of the paths someone
  remembered.
- **Cancellation.** BR10.4 enumerates four members plus `anything else → 503`, and
  **499 is none of them**. A literal implementation sends every cancelled upload to
  **503** with the wrong sentence. BR26.2 exists because that gap is in the rule itself.

### Why it is silent, and the one test that catches it

**The statuses stay correct.** A test asserting "a conflict returns 409" passes under
FastAPI's defaults. The editor still receives a 409. What it does not receive is
`result.issues`, so field highlighting shows nothing; and because `{"detail": ...}` is
a perfectly valid JSON object, nothing throws.

The assertions that fail are on the **body**:

1. Every error response body has an `error` key and **no** `detail` key.
2. A validation failure's `issues[]` members have **`path`** and **`message`** keys and
   **no** `loc` or `msg` keys.
3. An unhandled exception returns **503**, not 500, and is logged with a traceback.
4. **A request that never reaches a route handler** — unknown path, wrong method — also
   returns this envelope.
5. A cancelled upload returns **499**, not 503.

**4 and 5 are the ones a reviewer forgets**, and 4 is the one a framework gets wrong by
default.

---

## Operations

Each entry gives the surface behaviour. The application decision in every case belongs
to the unit behind the route.

### `POST /api/auth/login` — sign in

1. Consult `LoginGuard` for this account and this source address. **If either window is
   exhausted, return the same 403 body as a credential failure** — no enumeration, no
   distinct message, no `Retry-After`, and no timing branch before the hash (BR3.20,
   owned by `u3-identity-and-session`).
2. `OwnerIdentity` looks up the owner record and **always** runs an argon2id
   verification, against a dummy hash when no owner exists, so absence and
   wrong-password cost the same.
3. On failure: record against **both** windows, return **403**.
4. On success: clear the account's window; `SessionAuthority` creates a `Session` with
   `issuedAt`, `lastSeenAt`, `absoluteExpiresAt` = now + 7 days, and a CSRF token. Set
   the **signed** cookie `HttpOnly; Secure; SameSite=Lax`. Return the CSRF token in the
   body.

Statuses: **200** issued · **400** malformed · **403** rejected, with an **identical
body** whether the account is unknown, the password is wrong, or the limit was reached.

### Every authenticated request — the middleware

1. Read and verify the cookie signature. **Invalid → treat as anonymous**, not as an
   error.
2. Load the session. Absent, revoked, `lastSeenAt` older than **8 hours**, or past
   `absoluteExpiresAt` → **anonymous**, and the record is deleted if expired.
3. Otherwise advance `lastSeenAt` (the sliding idle window) **without** touching
   `absoluteExpiresAt`.
4. **For every method that is not `GET`/`HEAD`**, compare the request's CSRF header
   with the session's token; mismatch → **403** (BR3.4).
5. **For the same set**, apply BR3.3: `Origin` must be **present and exactly equal** to
   the request URL's origin. **Absent fails.** Never applied to `GET`/`HEAD` (BR3.5).

**Both cover one request set, defined once in BR3.5** — a request is never
origin-checked without also being CSRF-checked, and the set has **one enumerated
exception**, the owner-provisioning route, which is exempt from **both**. **Both run
before any payload is read or measured** (BR3.5 § *ordering_note*); their order
*relative to each other* is not pinned here and is unobservable while both return the
same 403 sentence.

The result is `WIRE-4 RequestContext`, handed to the unit behind the route. **Carrying
an identity is not making a decision** (BR3.2).

### `GET /api/public/content` — the published document

Unauthenticated. Returns the published document only. **200** · **503** when storage is
unavailable or the stored document fails validation.

> **This route is NEW. It does not exist in the source, and it has no parity fixture.**
> Verified by execution, not inference: the source application was booted and
> `GET /api/public/content` returned **404**
> (`scratchpad/source-boot-verified.md`). The source served the public site by reading
> the database directly during server-side rendering; this route exists because the
> renderer may no longer do that (NFR1).
>
> **Consequence for verification.** Every other route on this surface is measured
> against a recorded U1 fixture. **This one cannot be** — there is nothing to record.
> Its behaviour is **specified, not preserved**, so it is verified against this
> specification and against the contract, and a reviewer must not expect a fixture for
> it or read the absence of one as a gap in U1's manifest.
>
> What it returns is still bound by parity **indirectly**: the public page rendered from
> it must match the source's rendered HTML under the normalised DOM diff (NFR10). The
> route is new; the bytes the visitor ends up seeing are not.

### `GET /api/auth/session`

Returns `{ signedIn: boolean }`. Drives the footer edit link only — it is **not** an
authorization mechanism, and nothing else may depend on it. **200** always.

### `GET /api/content` — full content state

Owner-only. Returns draft, published, revision, both timestamps and
`hasUnpublishedChanges`. **It also backs the private draft preview (FR8.6)** — the
preview needs no operation of its own, and this is stated explicitly because leaving it
implicit invites a redundant endpoint.

**200** · **403** not the owner · **503** storage unavailable.

### `PUT /api/content` — save or publish (the hazard-dense path)

**The nine checks run strictly in order** (BR10.10), because **the order determines
which status a multiply-invalid request receives**:

| # | Check | Failure | Notes |
|---|---|---|---|
| 1 | Origin match | **403** | `This request could not be verified. Refresh and try again.` |
| 2 | Owner session | **403** | `Please sign in with the website owner’s account.` — **U+2019** |
| 3 | Decoded body length over the cap | **413** | **1,500,000 CHARACTERS, not bytes.** Owned by `ContentAuthority` (BR4.20); **enforced here**, where the decoded body first exists |
| 4 | JSON parse | **400** | `The update could not be read.` — distinct from a validation failure |
| 5 | Body falsy, not an object, or an array | **400** | `Invalid save request.` |
| 6 | **Content schema validation** | **400 with `issues[]`** | `Please check the highlighted fields before saving.` |
| 7 | **Envelope validation** | **400 without `issues[]`** | `Invalid save request.` |
| 8 | Conflict signal from the write | **409** | Current state returned so the caller can reconcile; the caller's edits are untouched |
| 9 | — | **200** | New revision and timestamps |

**The CSRF check is not among the nine, and its position is pinned separately.** The
nine steps come **verbatim from the source**, which had no CSRF check — BR3.4 is a port
addition (D1) — so it is **absent rather than misplaced**, and the numbering is not
changed. It belongs to the **same middleware authorization group as step 1**, and **the
whole group runs before step 2 and therefore before step 3**: authorization checks
precede payload processing. **Within the group, origin and CSRF are not ordered
relative to each other, because that order is not observable** — both return 403 with
the same sentence as currently specified. If CSRF is ever given its own distinct
sentence, that intra-group order becomes observable and must be pinned then
(`rules.md` § BR10.10 `csrf_sentence_open`).

Three ordering facts, each a separate test:

- **Step 3 before step 4.** The cap is checked **after the body is fully read** and
  **before JSON parsing** (BR4.22). It limits **document size, not memory use** — the
  full body is already in memory. Moving it after the parse changes which status a
  too-large **malformed** body receives: 413 today, 400 if reordered.
- **Step 6 before step 7** (BR10.11). A body with **both** malformed `content` and a
  bad `revision` returns the **content** 400 **with `issues[]`**. This is the only
  ordering whose two outcomes share a **status** and differ in **body**, which is
  exactly why reordering it is silent: the editor highlights fields on one and shows a
  bare sentence on the other.
- **Step 1 before step 2.** A request with a bad origin **and** no session returns the
  **origin** 403, not the ownership 403 — two different sentences at the same status.

**Step 7's predicate is evaluated as one predicate** (BR10.12): `revision` a safe
integer, `>= 0`, `< Number.MAX_SAFE_INTEGER`; `action` exactly `draft` or `publish`;
`autosave` absent or boolean; and **not** (`autosave === true` and `action !==
'draft'`).

**Behind the route**, `ContentAuthority` mints a fresh `mutation_token` and performs
**one call, one caller, one transaction** carrying the content update, the revision
entry and the retention prune together (FR4.5). That is `u4-content-core`'s hazard, not
this unit's; this unit contributes the check order and the status mapping.

**On a successful publish**, `ContentAuthority` invalidates the published-document
cache. This unit does not.

### `POST /api/content/inspect` — classify a recovered draft

Owner-only. **The rule that used to live in the browser** (ADR-006). Returns the
normalised document plus each issue classified **recoverable** or **corrupting**.

**This unit routes; it does not classify.** **200** · **400** body unparseable at all ·
**403** not the owner · **413 body over 6,000,000 characters** (BR26.4).

**The 413 cap is 6,000,000 characters — the draft-recovery bound, not the save cap**
(BR26.4). The checks run in this order, the same shape as `PUT /api/content`:

| # | Check | Failure | Notes |
|---|---|---|---|
| 1 | **Origin match** | **403** | **Enforced.** `POST` is not `GET`/`HEAD`, so BR3.5 applies. `This request could not be verified. Refresh and try again.` |
| 2 | Owner session | **403** | `Please sign in with the website owner’s account.` |
| 3 | Decoded body length over the cap | **413** | **6,000,000 CHARACTERS, not bytes.** New copy: `This draft is too large to check.` |
| 4 | JSON parse | **400** | Body unparseable at all |
| 5 | — | **200** | Normalised document plus classified issues |

**The order is the same shape as `PUT /api/content` steps 1 → 4** (BR10.10): **origin
before session, session before size, size before parse.**

- **Step 1 before step 3 is the one that was open and is now decided.** A request that
  is **both** bad-origin **and** oversize returns **403, not 413**. Authorization
  precedes payload processing: a request from a disallowed origin must **not** cause
  the server to read and measure a six-million-character body. One answer a test can
  assert, rather than two plausible ones (BR3.5 § *ordering_note*).
- **Step 3 before step 4** matters for the same reason it does on `PUT` — a too-large
  **malformed** body is a **413**, not a 400.

**Why origin applies to a route that writes nothing.** BR3.5 was widened at the
functional-design gate: enforcement is keyed on the **method**, not on whether the
operation writes. Its earlier "mutations" wording left this exact route in **neither**
branch — not a `GET`, so the never-branch missed it; not a mutation, so the
mutates-branch missed it too. BR3.3 already treats an **absent** `Origin` as a failure,
so fail-open here would have been the inconsistency. See `rules.md` § *BR3.5 was widened
at the gate*.

Three things about the cap that a later reader will otherwise try to "simplify":

- **It is the recovery bound (`editor-workflow.ts:15`), not the save cap
  (`route.ts:11`, BR4.20).** The site owner decided at the functional-design gate to
  **preserve both bounds and warn** rather than lower either, so the window between
  1,500,001 and 6,000,000 characters persists by decision.
- **A draft that is recoverable must always be inspectable.** This route classifies a
  *recovered* draft. At the save cap, a draft in the window would be **recoverable but
  unclassifiable** — the editor offers a restore, the owner accepts, and the
  classification call returns 413. The decided flow instead is: recovered → offered →
  inspected → classified → **and only then** refused by `PUT /api/content` with its own
  413 and the warning. The refusal is last, and it is visible.
- **The sentence is new copy, not the save cap's.** `This update is too large.` is
  ported copy bound to 1,500,000 on another route; reusing it would make one string
  mean two bounds, and it is wrong besides — `inspect` updates nothing. This route does
  not exist in `madhavi-tripathi/`, so it has no parity fixture and no source string to
  preserve. See `rules.md` § BR26.4 for the full argument.

> **Contract gap, recorded not diverged.** `contract-summary.md` § C1 lists **200 / 400
> / 403** for this path and **states no body cap**. That artifact is owned by
> `contract-design` and is **not edited from here**; the cap post-dates its approval.
> `contract-design` owns adding the `413`. The non-circular API contract test will fail
> on exactly this difference — **that is the intended signal**, and it must not be
> resolved by removing the 413.

### `GET /api/history` — list revisions, or fetch one

Owner-only. **Without `id`**: summaries ordered **revision DESC, baseline ASC, action
DESC** — a three-part sort that is load-bearing for display order — capped at the
current limit. **With `id`**: validate the pattern, then return the entry or a 404.

**The absent-versus-empty distinction is a real branch** (BR5.5): `id` **not present at
all** means **list**; `?id=` — present but empty — is a **400**, not a list and not a
404. A framework that coerces a missing query parameter to `""` collapses the two.

**200** · **400** malformed id · **403** · **404** absent or pruned, with a body
stating **the current draft is unaffected** · **503**.

### `POST /api/upload`

Owner-only, origin-checked. Behind the route, `MediaIntake` runs its ordered admission
sequence. This unit contributes the origin and session checks, the multipart transport,
and the status mapping.

**200** · **400** · **403** · **413** · **499 cancelled** · **503**.

**499 is this unit's explicit mapping** (BR26.2) and the only status in the system
outside the four-member taxonomy.

### `GET | HEAD /api/media/{key}`

**Unauthenticated at the transport layer** — `MediaDelivery` makes the access decision
itself (BR3.1). **Origin enforcement is never applied** (BR3.5).

This is the route **ADR-003 rejected a public/owner split on**: it is public when its
asset is referenced by published content and owner-only otherwise, so it belongs to
both surfaces. The split fails exactly where the protected/unprotected distinction is
hardest.

**200** · **206** · **404** (every denial, never 403) · **416** · **503**.
**`HEAD` always returns 200** and never inspects `Range`.

### `POST /api/auth/logout`

Owner-only. `SessionAuthority` revokes **server-side**, so a stolen cookie stops working
rather than merely disappearing from one browser. **204**.

### `/sitemap.xml`, `/robots.txt`

Served by the frontend, not by this unit. Listed in C1 for completeness; recorded here
so a reader does not add Python routes for them.

---

## Owner provisioning and startup

### Provisioning — CLI and a one-shot route

`python -m app.cli create-admin` is the normal path: prompts for email and password,
stores only the argon2id hash, refuses if an owner already exists.

For a container with no interactive shell, a **one-shot route** is enabled only while
**no owner record exists** **and** `ADMIN_BOOTSTRAP_SECRET` is set. **The gate is the
record's existence, not a consumed flag**, so restarting cannot reopen it. With no
secret and no owner, the service **starts and refuses every sign-in** rather than
creating an account.

> **THIS ROUTE IS EXEMPT FROM ORIGIN AND CSRF ENFORCEMENT — read this before you call
> it or implement it.** BR3.5 enforces origin on every method that is not `GET`/`HEAD`,
> and BR3.4 pairs a CSRF token with it. **This one route is the single enumerated
> exception to both** (BR3.5 § `exceptions`). **Call it with no `Origin` header and no
> CSRF token; that is correct and expected.**
>
> **Why.** The origin check defends against **ambient authority** — CSRF works only when
> a browser attaches credentials **the attacker does not possess** (a session cookie) to
> a request the attacker causes. This route has **no ambient authority to borrow**: it
> is gated on **`ADMIN_BOOTSTRAP_SECRET`, supplied explicitly in the request**, which
> **no browser will ever attach on a third party's behalf**. An attacker's page cannot
> make a victim's browser send a secret the browser does not hold. **The origin check
> would protect nothing here while breaking the only caller the route exists for** — a
> non-browser client, `curl` in a container, which sends no `Origin`. This follows from
> the route's **authentication model**, not from tooling convenience. **CSRF is
> inapplicable rather than waived:** the token is paired 1:1 with a **session**
> (BR3.12), and during bootstrap **no session exists**.
>
> **What makes it safe — and what would invalidate it.** Two compensating controls: the
> **bootstrap secret** must be set *and* supplied; and the route is enabled **only while
> no owner record exists**, gated on **the record's existence rather than a consumed
> flag**, so a restart cannot reopen it. **If either ever changes, this carve-out must
> be re-argued, not carried forward.**
>
> **Do not "harden" this by requiring a matching `Origin` from the caller.** That was
> considered and **rejected as security theatre**: `Origin` is trustworthy only because
> *browsers* set it and refuse to let script forge it. A non-browser caller sets whatever
> it likes, so the header proves nothing about a `curl` request, and an attacker who can
> reach this endpoint can set it as easily as you can. It adds a runbook step and zero
> security. **Nor should BR3.5 be re-narrowed** — that restores the unclassified branch
> the widening closed. The CLI path above is unaffected either way, so no default
> credential is reintroduced and FR3.7's acceptance test still holds.

**Acceptance test for FR3.7:** a fresh `docker compose up` against an empty volume has
**no account anyone can sign in to.**

### Startup

Load settings. **If `SESSION_SIGNING_KEY` is unset, empty, or under 32 bytes → raise
during startup naming the variable and exit non-zero.** **No default, and explicitly no
auto-generated per-process key** — that would look like it works while silently
invalidating every session on restart, which is the worse failure. Run migrations. Seed
the content document if absent. **Never seed an owner.**

The same rule holds for every required setting: **fail at boot, not at first request.**

---

## Boundary enforcement is a command, not an assertion

**A rule nobody can check is a wish.** NFR1 states the language boundary; three commands
at the merge gate make it enforced. All three **fail the gate** (BR26.1).

### 1. The grep

Fails if `chiku-website/frontend` contains **any** `'use server'` directive, **any**
`app/**/route.ts`, or **any** `middleware.ts`.

An ESLint `no-restricted-syntax` rule is a nicer editor experience, **but the grep is
the one that is certain** — it cannot be disabled by a config change, an override
comment or a file that the linter does not cover.

### 2. The AST test

**One pytest walks the AST of every module under `routers/` and asserts none of them
imports a `store` module or `sqlite3`.**

This is what makes "route handlers stay thin, persistence lives behind the ports" a
checkable claim rather than a convention. It is an **AST walk rather than a grep**
because a grep over import lines is defeated by an aliased or dynamic import, and
because the AST distinguishes an import from a mention in a string or a comment.

### 3. The dirty-regeneration check

The frontend's TypeScript types for backend payloads are **generated** from this unit's
`/openapi.json` with `openapi-typescript`, **committed**, **regenerated at the gate**,
and **the gate fails if the output is dirty**.

This is the check that does the most work. It makes the boundary **type-checked** rather
than asserted: a backend field rename then fails `tsc --noEmit` **with a file and a
line**, instead of surfacing as a browser-side 422 three Bolts later. The committed
`openapi.json` snapshot means an unintended contract change appears as a **gate diff**
rather than as a runtime failure.

**Why these three and not a review checklist.** There is **no CI and no pull request**
(C5, D17). The local merge gate is the only enforcement point this project has, and its
**verbatim output** is pasted into the Bolt's gate approval. An unwitnessed gate is an
assertion, not a check.

---

## Testing obligations for this unit

- **Characterization tests come first** for the envelope hazard: written from the
  **recorded source behaviour** (U1 fixtures) and observed to fail before the Python
  implementation exists. Under test-after, a developer who misreads the envelope
  implements from the misreading and then writes the test from the same misreading — the
  test is green and the defect ships. Only a test whose assertion came from the
  **source** catches it.
- **API contract tests in the non-circular form**: assert the **generated** OpenAPI
  document against the **hand-written** contract from `contract-design`, and commit the
  generated `openapi.json` as a snapshot. Asserting the generated document against
  itself proves nothing.
- **NFR2 is verified by tests that call the API directly, bypassing the frontend**,
  with no session. This is the discipline **ADR-003 named as the condition of its own
  soundness**: a route accidentally left unprotected must **fail a test** rather than
  merely look wrong in review. **If that discipline lapses, ADR-003 should be
  revisited.**
- **A test per enumerated branch** under the 100% scoped coverage floor: the five
  envelope assertions above, the nine steps of the `PUT` check order, the three
  outcomes of the origin predicate (present-equal, present-different, **absent**), and
  the CSRF mismatch.
- **The byte-level parity assertion on the copy.** All 21 strings compared as **exact
  literals**, not normalised — and the U+2019 one written through a path that cannot
  smarten or dumben a quote. **`This draft is too large to check.` is not among them**:
  it is new copy on a new route (BR26.4) and has no fixture to diff against.
- **The two caps are asserted to be different, not merely correct.** `team.md` names
  "the request-size cap" a hazard module under the **100% scoped coverage floor**, and
  BR26.4 is implemented in it. So: a body at each bound, one under and one over, **plus
  one test that pins the difference** — a body of **1,500,001** characters is
  **inspected successfully** by `POST /api/content/inspect` and **refused with 413** by
  `PUT /api/content`. A test that only checks each route against its own cap passes
  after someone collapses the two numbers into one; this one does not.

---

## Assumptions & Open Questions

- **[open at workflow level — owner: `construction/functional-design/rules.md` § BR10.4,
  being fixed separately; closed locally here]** **BR10.4 does not account for 499.**
  The four-member taxonomy plus a 503 catch-all is exhaustive as written, and a
  cancelled upload is neither a member nor an "anything else" that should become 503.
  **BR26.2 is the local closure for this unit and is sound as written** — it maps 499
  explicitly, forbids the fall-through to the BR10.5 catch-all, and keeps the single
  envelope — but it closes the gap **for `u6-http-api` only**. The gap itself is in the
  workflow-level `construction/functional-design/rules.md` § BR10.4 and reappears in any
  other reading of that file. `contract-summary.md` § C1 lists 499 on `POST /api/upload`
  and BR10.7 gives its sentence, so the contract requires what no requirement sentence
  states.
- **[open — owner: `contract-design`. Recorded, not diverged]** **`contract-summary.md`
  § C1 states no request-body cap for `POST /api/content/inspect`** — that path lists
  **200 / 400 / 403** only — while **`BR26.4` adds a 413 at 6,000,000 characters**. The
  cap is a decision the **site owner made at the functional-design gate**, *after* C1
  was approved, so C1 is out of date rather than wrong. **C1 is an upstream inception
  artifact owned by `contract-design` and is not edited from here**; `contract-design`
  owns adding the `413`. The non-circular API contract test (`team.md` § *Testing
  Posture*) asserts the **generated** document against the **hand-written** contract and
  **will fail on exactly this difference** — that is the intended signal, and it must
  not be resolved by deleting the 413.
- **[closed at the functional-design gate — was raised here as an open item]** **Whether
  origin enforcement applies to `POST /api/content/inspect`.** BR3.5 used to define the
  enforced set two ways that disagreed on this route — **extensionally** (the source
  pairs plus the authentication mutations, which excludes a route that did not exist in
  the source) and **intensionally** (*"IF the method mutates"*, which does not classify
  a `POST` that **writes nothing**). **Decided: enforce it, fail closed.** BR3.5 is
  **widened** to *every method that is not `GET` or `HEAD`*, the extensional wording is
  **withdrawn**, and the check ordering is pinned **origin (403) before size (413)**.
  BR3.3's absent-`Origin`-fails precedent, the zero cost on owner-only same-origin
  routes, and the principle that an unclassified branch in a security rule is itself the
  defect are recorded in `rules.md` § *BR3.5 was widened at the gate*.
- **[closed at the functional-design gate — was raised here as a consequence of the
  BR3.5 widening]** **The one-shot owner-provisioning route would have been broken by
  the widening**: it is a `POST`, its documented caller is a non-browser client sending
  no `Origin`, and BR3.3 fails closed on an absent `Origin`, so it would have returned
  **403 to the only caller it exists for**. **Decided: an explicit, named carve-out
  from both BR3.3 and BR3.4**, on the merits — the origin check defends against
  **ambient authority**, and a route gated on a secret the caller supplies explicitly
  has **none to borrow**, so the check protects nothing there. Requiring a matching
  `Origin` from `curl` was **rejected as security theatre**. Full argument, the two
  compensating controls and the condition under which the carve-out must be re-argued
  are in `rules.md` § *The one enumerated exception*, and the operational form of it is
  inline in § *Owner provisioning and startup*, where a caller will meet it.
- **[open, NEW — owner: `contract-design`]** **The one-shot owner-provisioning route
  has no path in `contract-summary.md` § C1.** C1 enumerates nine paths and this is not
  among them; the route appears only as a capability in C1's data section
  (`owner_record: create_if_absent`, with the record-existence gate). **This now
  matters more than it did**, because BR3.5's exception is required to **name a route**
  rather than describe a property — and a named exception is only enumerable against a
  contract that enumerates the route. Until C1 gives it a path, the exception is
  anchored to a route this unit describes and the contract does not. `contract-design`
  owns adding it, alongside the `413` on `/api/content/inspect`.
- **[flagged, assignment not changed here]** Three FR→unit assignments in
  `inception/units-generation/traceability.json` point away from the unit whose rules
  discharge them, all in the same direction: **FR10.2 → U8** while BR10.7–BR10.9 are
  `HttpApi`'s; **FR4.7 → U4** while BR10.10–BR10.12 are `HttpApi`'s; **FR6.7 → U5**
  while BR3.3–BR3.5 are `HttpApi`'s. In each case the **enforcement** is unambiguously
  at this unit's operation boundary and the requirement was assigned to the unit that
  owns the operation's **subject**. All three rule sets are carried here and all three
  appear in the traceability `reverse` array. Changing the assignments belongs to
  whoever owns the units-generation artifact.
- **[assumption, this unit]** **NFR1 and NFR2** are treated as this unit's upstream
  requirements. They are **not** in `units-generation/traceability.json`, which
  enumerates no NFRs, but `unit-of-work.md` § *U6* states
  **"Realises. FR3.8, FR10, NFR1, NFR2."** **Each is now realised by a named rule and
  the claim is stated in exactly one place**: `rules.md`'s yaml block, where **NFR1** is
  the `source` of `BR26.1` and `BR26.3` and **NFR2** is the `source` of `BR3.1` and of
  no other rule. This file's derived rules summary, `rules.md`'s prose heading and
  summary table, and `traceability.json`'s `realises` array all **derive from that
  block**. Review finding **R-01** was that these four locations disagreed; this is its
  resolution.
- **[assumption, carried from `contract-summary.md` § C1]** Field-level schemas are
  **deliberately omitted** from this unit's artifacts — they are generated from the
  Pydantic models, and duplicating them would create a second definition that can drift
  from the authoritative one. What is fixed here is the **operations, the status codes
  and the envelope**: the parts that must be **ported rather than designed**.
- **[assumption, carried from `contract-summary.md`]** Same-origin routing via a Next.js
  `rewrites()` entry is **declarative configuration** rather than a JavaScript
  backend-for-frontend, and is therefore permitted by the language boundary. Chosen
  because a cross-site session cookie is unreliable under third-party-cookie
  restrictions. **This assumption is what makes BR3.3's "exactly equal" predicate
  satisfiable at all** — under a cross-origin deployment every mutation would fail it.
- **[assumption, carried from `construction/functional-design/functional-spec.md`]** The
  dummy-hash verification on an unknown account is sufficient to avoid a timing oracle.
  **It is not separately measured**; it is the standard mitigation.
- **[open, owner U1 `source-fixtures`]** Which of the two cancellation literals each 499
  carries. This is an `ErrorEnvelope.error` value and therefore this unit's wire
  contract, even though the condition is `u5-media`'s.
- **[resolved by execution, was the plan's largest unverified assumption]** The source
  application **runs**. It was booted and probed
  (`scratchpad/source-boot-verified.md`), which resolves the standing assumption that
  U1's fixture recording is possible at all. Three results bear directly on this unit:
  the **error envelope was captured verbatim** at the wire — one `error` key, no
  `detail`, with **U+2019** — confirming BR10.1 and BR10.8 against a live response;
  `GET /api/content` unauthenticated returns **403**, not 401, consistent with BR10.4;
  and **`GET /api/public/content` returns 404 because it does not exist in the source**,
  so it is this unit's one route with **no parity fixture** (see its entry above).
- **[note]** `GET /api/auth/session` drives the footer edit link **only**. It is not an
  authorization mechanism. Every protected operation authorises itself (BR3.1), and a
  caller who lies about this endpoint's answer gains nothing.
- **[note]** This unit holds no state and touches no store; the AST test is what makes
  that checkable. It is also why its `entities.md` specifies wire contracts rather than
  persisted entities.
- **[note]** No operation here requires a background worker, scheduler or queue
  consumer. Retention runs inside the write that triggers it.

## Sources

- `construction/functional-design/functional-spec.md` §§ *Cross-cutting behaviour*,
  *Operations* (every route), *Owner provisioning*, *Startup*, *Module layout* — this
  unit fronts the same flows, scoped to the surface.
- `construction/http-api/functional-design/rules.md` — **normative for every `BR` id
  cited above**; the tables here restate it and are subordinate to it.
- `construction/http-api/functional-design/entities.md` §§ *WIRE-1/WIRE-2* (the
  envelope hazard), *WIRE-3* (the save envelope), *WIRE-4* (what the middleware
  resolves, and the absent-`Origin` case).
- `inception/contract-design/contract-summary.md` § C1 — every path, its statuses and
  its descriptions, the `ownerSession` security scheme, the note that `GET /api/content`
  also backs the private draft preview (R-02), and § *Contract ownership rules*. **Its
  `/api/content/inspect` entry lists 200 / 400 / 403 and states no body cap** — the gap
  BR26.4 records and `contract-design` owns.
- **The `POST /api/content/inspect` body cap (BR26.4)** —
  `inception/reverse-engineering/developer-scan.md` § *J* (the two bounds and their
  origins: `parseRecovery` at **6,000,000**, `editor-workflow.ts:15`; the save cap at
  **1,500,000**, `route.ts:11`); `WORKING-RECORD.md` § *Decisions the human owned at the
  gate*, item 3 (the three costed options); `construction/http-api/functional-design/rules.md`
  § BR26.4, which is normative for the cap, its sentence and the three-bound table.
  **The value is the site owner's decision at the functional-design gate.**
- `inception/domain-design/decisions.md` **ADR-003** (one `HttpApi`; the media route as
  the case the split fails on; the test discipline as the condition of soundness),
  **ADR-006** (the classification is a backend rule, reached through
  `POST /api/content/inspect`).
- `inception/domain-design/components.md` § `HttpApi` — responsibilities and the seven
  `depends_on` edges, which produce the units-behind-the-routes table.
- `inception/requirements-analysis/requirements.md` FR3.1–FR3.8, FR4.1–FR4.7, FR5.1–FR5.4,
  FR10.1–FR10.3, NFR1, NFR2, NFR5, NFR9.
- `inception/units-generation/unit-of-work.md` § *U6 — http-api* — the boundary, the
  gate grep and AST-test constraint, and `Realises: FR3.8, FR10, NFR1, NFR2`.
- `aidlc/spaces/default/memory/team.md` §§ *Code Style* → *Python* (the error envelope,
  `async` by default, "a layer exists only when it has a job", boundary discipline),
  *Testing Posture* (the `custom` methodology, the non-circular contract test, boundary
  enforcement as a command), *Deployment* (the signing key, the one-shot provisioning
  route, the no-default-credential acceptance test), *Way of Working* (no CI, no PR, the
  local merge gate as the only enforcement point).
- `WORKING-RECORD.md` §§ 2 (D1–D3, D6, D11, D17), 3 (hazard FR10.1), 5 (the error
  envelope, the frozen wire format, secrets), 6 (the merge gate).
