# traceability finding — functional-design

**Timestamp**: 2026-09-24T22:58:04Z
**Fire id**: 149790c1
**Output path**: /Users/praka/Workspace/Projects/Chiku_website/aidlc/spaces/default/intents/260924-chiku-website-migration/construction/deployment-plan/functional-design/traceability.json
**Pass**: false

## Findings

```json
{
  "pass": false,
  "gaps": [],
  "orphans": [],
  "missing_from_table": [],
  "missing_from_upstream_ids": [],
  "invalid_entries": [],
  "invalid_targets": [],
  "findings_count": 1,
  "reason": "no coverage entries found in traceability.json"
}
```
