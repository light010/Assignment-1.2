# traceability finding — code-generation

**Timestamp**: 2026-09-25T11:21:37Z
**Fire id**: cd6879a3
**Output path**: /Users/praka/Workspace/Projects/Chiku_website/aidlc/spaces/default/intents/260924-chiku-website-migration/construction/cloud-adapters/code-generation/traceability.json
**Pass**: false

## Findings

```json
{
  "pass": false,
  "gaps": [],
  "orphans": [],
  "missing_from_table": [],
  "missing_from_upstream_ids": [],
  "invalid_entries": [],
  "invalid_targets": [],
  "findings_count": 1,
  "reason": "no coverage entries found in traceability.json"
}
```
