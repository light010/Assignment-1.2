# traceability finding — functional-design

**Timestamp**: 2026-09-24T18:18:05Z
**Fire id**: 74cb2850
**Output path**: /Users/praka/Workspace/Projects/Chiku_website/aidlc/spaces/default/intents/260924-chiku-website-migration/construction/source-fixtures/functional-design/traceability.json
**Pass**: false

## Findings

```json
{
  "pass": false,
  "gaps": [],
  "orphans": [],
  "missing_from_table": [],
  "missing_from_upstream_ids": [],
  "invalid_entries": [],
  "invalid_targets": [],
  "findings_count": 1,
  "reason": "rules.md contains no traceable IDs: /Users/praka/Workspace/Projects/Chiku_website/aidlc/spaces/default/intents/260924-chiku-website-migration/construction/source-fixtures/functional-design/rules.md"
}
```
