# upstream-coverage finding — delivery-planning

**Timestamp**: 2026-09-24T17:55:25Z
**Fire id**: 120bc57e
**Output path**: /Users/praka/Workspace/Projects/Chiku_website/aidlc/spaces/default/intents/260924-chiku-website-migration/inception/delivery-planning/delivery-planning-questions.md
**Pass**: false

## Findings

```json
{
  "pass": false,
  "consumes": [
    "requirements",
    "components",
    "unit-of-work",
    "unit-of-work-dependency",
    "unit-of-work-story-map",
    "contract-summary",
    "team-practices"
  ],
  "unreferenced": [
    "team-practices"
  ],
  "scanned_files": [
    "/Users/praka/Workspace/Projects/Chiku_website/aidlc/spaces/default/intents/260924-chiku-website-migration/inception/delivery-planning/bolt-plan.md",
    "/Users/praka/Workspace/Projects/Chiku_website/aidlc/spaces/default/intents/260924-chiku-website-migration/inception/delivery-planning/team-allocation.md",
    "/Users/praka/Workspace/Projects/Chiku_website/aidlc/spaces/default/intents/260924-chiku-website-migration/inception/delivery-planning/risk-and-sequencing-rationale.md",
    "/Users/praka/Workspace/Projects/Chiku_website/aidlc/spaces/default/intents/260924-chiku-website-migration/inception/delivery-planning/external-dependency-map.md"
  ],
  "findings_count": 1
}
```
