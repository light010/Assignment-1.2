# traceability finding — functional-design

**Timestamp**: 2026-09-24T18:23:12Z
**Fire id**: 8beb22aa
**Output path**: /Users/praka/Workspace/Projects/Chiku_website/aidlc/spaces/default/intents/260924-chiku-website-migration/construction/storage-ports/functional-design/traceability.json
**Pass**: false

## Findings

```json
{
  "pass": false,
  "gaps": [],
  "orphans": [
    "BR3.11",
    "BR3.16",
    "BR3.18",
    "BR3.21",
    "BR4.2",
    "BR4.20",
    "BR4.22",
    "BR4.7",
    "BR5.6",
    "BR6.1",
    "BR6.23",
    "BR7.16",
    "BR7.3",
    "PC-4",
    "PC-6",
    "PC-7"
  ],
  "missing_from_table": [],
  "missing_from_upstream_ids": [
    "FR1",
    "FR1.1",
    "FR1.2",
    "FR1.3",
    "FR1.4",
    "FR1.5",
    "FR1.6",
    "FR1.7",
    "FR1.8",
    "FR10",
    "FR10.1",
    "FR10.2",
    "FR10.3",
    "FR2",
    "FR2.1",
    "FR2.2",
    "FR2.3",
    "FR2.4",
    "FR2.5",
    "FR2.6",
    "FR3",
    "FR3.2",
    "FR3.3",
    "FR3.6",
    "FR3.8",
    "FR4.2",
    "FR4.3",
    "FR4.4",
    "FR4.7",
    "FR6.1",
    "FR6.2",
    "FR6.3",
    "FR6.4",
    "FR6.5",
    "FR6.7",
    "FR7.1",
    "FR7.2",
    "FR7.3",
    "FR7.6",
    "FR8",
    "FR8.1",
    "FR8.2",
    "FR8.3",
    "FR8.4",
    "FR8.5",
    "FR8.6",
    "FR8.7",
    "FR8.8",
    "FR8.9",
    "FR9",
    "FR9.1",
    "FR9.2",
    "FR9.3",
    "FR9.4"
  ],
  "invalid_entries": [],
  "invalid_targets": [
    "FR4.6: target must name at least one BRx.y ID",
    "NFR3: target must name at least one BRx.y ID"
  ],
  "findings_count": 72
}
```
