# traceability finding — functional-design

**Timestamp**: 2026-09-24T23:13:58Z
**Fire id**: d323eaff
**Output path**: /Users/praka/Workspace/Projects/Chiku_website/aidlc/spaces/default/intents/260924-chiku-website-migration/construction/media/functional-design/traceability.json
**Pass**: false

## Findings

```json
{
  "pass": false,
  "gaps": [],
  "orphans": [
    "BR10.4",
    "BR10.7",
    "BR10.9",
    "BR24.1",
    "BR24.2",
    "BR3.1",
    "BR3.3",
    "BR3.4",
    "BR3.5"
  ],
  "missing_from_table": [],
  "missing_from_upstream_ids": [
    "FR1",
    "FR1.1",
    "FR1.2",
    "FR1.3",
    "FR1.4",
    "FR1.5",
    "FR1.6",
    "FR1.7",
    "FR1.8",
    "FR10",
    "FR10.1",
    "FR10.2",
    "FR10.3",
    "FR2",
    "FR2.1",
    "FR2.2",
    "FR2.3",
    "FR2.4",
    "FR2.5",
    "FR2.6",
    "FR3",
    "FR3.1",
    "FR3.2",
    "FR3.3",
    "FR3.4",
    "FR3.5",
    "FR3.6",
    "FR3.7",
    "FR3.8",
    "FR4",
    "FR4.1",
    "FR4.2",
    "FR4.3",
    "FR4.4",
    "FR4.5",
    "FR4.6",
    "FR4.7",
    "FR5",
    "FR5.1",
    "FR5.2",
    "FR5.3",
    "FR5.4",
    "FR6",
    "FR6.7",
    "FR7",
    "FR8",
    "FR8.1",
    "FR8.2",
    "FR8.3",
    "FR8.4",
    "FR8.5",
    "FR8.6",
    "FR8.7",
    "FR8.8",
    "FR8.9",
    "FR9",
    "FR9.1",
    "FR9.2",
    "FR9.3",
    "FR9.4"
  ],
  "invalid_entries": [],
  "invalid_targets": [],
  "findings_count": 69
}
```
