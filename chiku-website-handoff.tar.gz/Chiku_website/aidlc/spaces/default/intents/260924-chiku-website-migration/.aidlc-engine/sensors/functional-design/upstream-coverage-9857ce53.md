# upstream-coverage finding — functional-design

**Timestamp**: 2026-09-24T22:00:35Z
**Fire id**: 9857ce53
**Output path**: /Users/praka/Workspace/Projects/Chiku_website/aidlc/spaces/default/intents/260924-chiku-website-migration/construction/storage-ports/functional-design/entities.md
**Pass**: false

## Findings

```json
{
  "pass": false,
  "consumes": [
    "unit-of-work",
    "unit-of-work-story-map",
    "requirements",
    "components",
    "contract-summary"
  ],
  "unreferenced": [
    "requirements"
  ],
  "scanned_files": [
    "/Users/praka/Workspace/Projects/Chiku_website/aidlc/spaces/default/intents/260924-chiku-website-migration/construction/storage-ports/functional-design/entities.md",
    "/Users/praka/Workspace/Projects/Chiku_website/aidlc/spaces/default/intents/260924-chiku-website-migration/construction/storage-ports/functional-design/rules.md",
    "/Users/praka/Workspace/Projects/Chiku_website/aidlc/spaces/default/intents/260924-chiku-website-migration/construction/storage-ports/functional-design/functional-spec.md"
  ],
  "findings_count": 1
}
```
