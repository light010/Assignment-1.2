# traceability finding — functional-design

**Timestamp**: 2026-09-24T18:17:45Z
**Fire id**: 87fe41b3
**Output path**: /Users/praka/Workspace/Projects/Chiku_website/aidlc/spaces/default/intents/260924-chiku-website-migration/construction/source-fixtures/functional-design/traceability.json
**Pass**: false

## Findings

```json
{
  "pass": false,
  "gaps": [],
  "orphans": [
    "BR1.1",
    "BR1.2",
    "BR1.3",
    "BR1.4",
    "BR1.5",
    "BR1.6"
  ],
  "missing_from_table": [],
  "missing_from_upstream_ids": [],
  "invalid_entries": [],
  "invalid_targets": [],
  "findings_count": 6
}
```
