# traceability finding — functional-design

**Timestamp**: 2026-09-24T23:00:35Z
**Fire id**: babd3963
**Output path**: /Users/praka/Workspace/Projects/Chiku_website/aidlc/spaces/default/intents/260924-chiku-website-migration/construction/content-core/functional-design/traceability.json
**Pass**: false

## Findings

```json
{
  "pass": false,
  "gaps": [],
  "orphans": [
    "BR10.1",
    "BR10.10",
    "BR10.11",
    "BR10.12",
    "BR10.2",
    "BR10.3",
    "BR10.4",
    "BR10.5",
    "BR10.6",
    "BR10.7",
    "BR10.8",
    "BR10.9",
    "BR22.1",
    "BR22.5",
    "BR22.6",
    "BR22.8",
    "BR3.1",
    "BR7.1",
    "BR7.2",
    "BR7.4",
    "BR8.6",
    "BR8.7",
    "BR8.8"
  ],
  "missing_from_table": [
    "FR9.4"
  ],
  "missing_from_upstream_ids": [
    "FR1",
    "FR1.1",
    "FR1.2",
    "FR1.3",
    "FR1.4",
    "FR1.5",
    "FR1.6",
    "FR1.7",
    "FR1.8",
    "FR10",
    "FR10.1",
    "FR10.2",
    "FR10.3",
    "FR2",
    "FR2.1",
    "FR2.2",
    "FR2.3",
    "FR2.4",
    "FR2.5",
    "FR2.6",
    "FR3",
    "FR3.1",
    "FR3.2",
    "FR3.3",
    "FR3.4",
    "FR3.5",
    "FR3.6",
    "FR3.7",
    "FR3.8",
    "FR4",
    "FR4.7",
    "FR5",
    "FR6",
    "FR6.1",
    "FR6.2",
    "FR6.3",
    "FR6.4",
    "FR6.5",
    "FR6.6",
    "FR6.7",
    "FR7",
    "FR7.1",
    "FR7.2",
    "FR7.3",
    "FR7.4",
    "FR7.5",
    "FR8",
    "FR8.1",
    "FR8.2",
    "FR8.4",
    "FR8.5",
    "FR8.6",
    "FR8.7",
    "FR8.8",
    "FR8.9",
    "FR9"
  ],
  "invalid_entries": [],
  "invalid_targets": [],
  "findings_count": 80
}
```
