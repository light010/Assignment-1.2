# upstream-coverage finding — delivery-planning

**Timestamp**: 2026-09-24T17:55:24Z
**Fire id**: cc0840b9
**Output path**: /Users/praka/Workspace/Projects/Chiku_website/aidlc/spaces/default/intents/260924-chiku-website-migration/inception/delivery-planning/bolt-plan.md
**Pass**: false

## Findings

```json
{
  "pass": false,
  "consumes": [
    "requirements",
    "components",
    "unit-of-work",
    "unit-of-work-dependency",
    "unit-of-work-story-map",
    "contract-summary",
    "team-practices"
  ],
  "unreferenced": [
    "team-practices"
  ],
  "scanned_files": [
    "/Users/praka/Workspace/Projects/Chiku_website/aidlc/spaces/default/intents/260924-chiku-website-migration/inception/delivery-planning/bolt-plan.md",
    "/Users/praka/Workspace/Projects/Chiku_website/aidlc/spaces/default/intents/260924-chiku-website-migration/inception/delivery-planning/team-allocation.md",
    "/Users/praka/Workspace/Projects/Chiku_website/aidlc/spaces/default/intents/260924-chiku-website-migration/inception/delivery-planning/risk-and-sequencing-rationale.md",
    "/Users/praka/Workspace/Projects/Chiku_website/aidlc/spaces/default/intents/260924-chiku-website-migration/inception/delivery-planning/external-dependency-map.md"
  ],
  "findings_count": 1
}
```
