# traceability finding — domain-design

**Timestamp**: 2026-09-24T17:03:28Z
**Fire id**: 40eee741
**Output path**: /Users/praka/Workspace/Projects/Chiku_website/aidlc/spaces/default/intents/260924-chiku-website-migration/inception/domain-design/traceability.json
**Pass**: false

## Findings

```json
{
  "pass": false,
  "gaps": [],
  "orphans": [],
  "missing_from_table": [],
  "missing_from_upstream_ids": [
    "FR1",
    "FR10",
    "FR2",
    "FR3",
    "FR4",
    "FR5",
    "FR6",
    "FR7",
    "FR8",
    "FR9"
  ],
  "invalid_entries": [],
  "invalid_targets": [],
  "findings_count": 10
}
```
