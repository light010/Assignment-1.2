# Project-Level Rules

> Project-specific specialisation and corrections. Loaded after `org.md` and
> `team.md` as strict-additive guidance; contradictions with broader policy
> are rejected. Populated by practices-discovery and the self-learning loop.
>
> Use sparingly: most teams don't need a project layer. Reach for it
> only when this specific project needs stable, durable guidance beyond the
> team practice (for example, package-specific release checks or an additional
> regression suite for a legacy component).

## Way of Working

<!-- Project-specific specialisation. Example: -->
<!-- This monorepo requires package-scoped branch names and a package owner -->
<!-- review in addition to the team's normal merge policy. -->

## Walking Skeleton

<!-- Project-specific specialisation. Example: -->
<!-- The walking skeleton must exercise the legacy service adapter as well -->
<!-- as the new service boundary. -->

## Testing Posture

<!-- Project-specific specialisation. -->

## Change Control

<!-- Project-specific. Mode: strict or relaxed. Strict here holds for every intent and cannot be changed from chat. -->

## Deployment

<!-- Project-specific specialisation. -->

## Code Style

<!-- Project-specific specialisation. -->

## Tech Stack

<!-- Technology choices locked for this project. -->

## Decided

<!-- Decisions made in earlier stages that should not be re-asked. -->
<!-- Format: DECIDED: [decision] (Stage [slug], [date]) -->

## Scope Overrides

<!-- Custom scope rules for this project. -->

## Forbidden

<!-- Populated by practices-discovery affirmation gate. -->
<!-- Format: NEVER [behavior] (affirmed [date]) -->
<!-- Example: NEVER throw exceptions across service layer boundaries (affirmed 2026-05-17) -->

- NEVER place application logic in the Next.js frontend. It renders; it decides nothing. [desc] (affirmed 2026-09-24)

- NEVER ship a default, seeded, sample or hard-coded credential. The site owner's credential is (affirmed 2026-09-24)

supplied at runtime through configuration and exists nowhere in the source tree. [Q — confirmed] (affirmed 2026-09-24)

- NEVER provision a Google Cloud resource in this piece of work. Cloud work is plan-only: no (affirmed 2026-09-24)

project, no service, no bucket, no credential. [Q — confirmed; also recorded in the approved (affirmed 2026-09-24)

scope file as the reason the operation phase is skipped] (affirmed 2026-09-24)

- NEVER introduce a paid, metered or otherwise recurring-cost component. [Q — confirmed, follows (affirmed 2026-09-24)

from the zero-cost target] (affirmed 2026-09-24)

- NEVER change the visual layout or the content of an existing page while porting it. [Q — (affirmed 2026-09-24)

confirmed parity rule, stated as a prohibition because that is how it will be applied in review] (affirmed 2026-09-24)

- NEVER hand-write a client-side validation rule, or a TypeScript type that mirrors a backend (affirmed 2026-09-24)

model. The browser may hold a mirror of the validation rules **only** when that mirror is (affirmed 2026-09-24)

generated from Python's OpenAPI document, so drift is impossible by construction; Python remains (affirmed 2026-09-24)

the authoritative validator in every case. [Q4 — confirmed at practices-discovery] (affirmed 2026-09-24)

- NEVER carry a secret value through a Docker `ARG` or `ENV` instruction, and never bake one into (affirmed 2026-09-24)

an image layer. A build-time credential, if one is ever needed, uses a supported build secret (affirmed 2026-09-24)

mount so the value never lands in a layer. [desc — stated verbatim in the original brief] (affirmed 2026-09-24)

## Mandated

<!-- Populated by practices-discovery affirmation gate. -->
<!-- Format: ALWAYS [behavior] (affirmed [date]) -->
<!-- Example: ALWAYS use Result<T,E> for fallible operations in service layer (affirmed 2026-05-17) -->

- ALWAYS keep every application decision in the Python FastAPI backend — authentication, (affirmed 2026-09-24)

authorization, authoritative validation, business rules, persistence, uploads and publishing all (affirmed 2026-09-24)

belong to the backend. [desc] (affirmed 2026-09-24)

- ALWAYS reproduce the existing site's layout and content as-is when porting a page; accessibility (affirmed 2026-09-24)

and semantic markup may improve only where nothing moves visually. [Q — confirmed parity rule] (affirmed 2026-09-24)

- ALWAYS preserve, in the new system, all public routes, the full owner editor (affirmed 2026-09-24)

(draft/publish, revision history, uploads, preview), seed content, branding, SEO metadata, (affirmed 2026-09-24)

JSON-LD, sitemap and robots, and the existing WebMCP `stage_academic_profile` browser tool. (affirmed 2026-09-24)

[desc] (affirmed 2026-09-24)

- ALWAYS authenticate the site owner with a password verified against an argon2id hash, in a (affirmed 2026-09-24)

Python-owned session, replacing the ChatGPT platform header auth entirely. [desc] (affirmed 2026-09-24)

- ALWAYS reach persistence through the narrow ContentStore / AssetStore port — SQLite plus a (affirmed 2026-09-24)

volume is the locally verified implementation; Firestore and GCS adapters are written against (affirmed 2026-09-24)

the same port. [desc] (affirmed 2026-09-24)

- ALWAYS prefer a maintained public library over custom code (reuse-first). [desc] (affirmed 2026-09-24)

- ALWAYS deliver a Dockerfile for each runtime plus a Compose file, and verify the containerised (affirmed 2026-09-24)

flow end to end. [desc] (affirmed 2026-09-24)

- ALWAYS sequence Bolts dependency-first. [Q — confirmed] (affirmed 2026-09-24)

- ALWAYS run the walking-skeleton Bolt first and gate it on explicit human approval before any (affirmed 2026-09-24)

remaining Bolt runs. [Q — confirmed; `skeleton: on` in the approved scope file] (affirmed 2026-09-24)

- ALWAYS hold total recurring cost at zero. [Q — confirmed hard target] (affirmed 2026-09-24)

## Corrections

<!-- Project-specific corrections from human feedback. -->
<!-- Format: NEVER/ALWAYS [behavior] (learned [date]) -->
- Exactly one site owner edits chiku-website. The initial brief's "a few administrators" is superseded by the confirmed intent; do not reintroduce multi-editor accounts or tiered editor/publisher permissions as though they were a dropped requirement. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:intent-capture:a86e559b7df6e54fd770636614ba8a16b8e44a78efe52a41ffa9f5d817fd5e3b -->
- After a human answers a summary checkpoint, the FIRST tool call of that turn must be `aidlc engine log answer --checkpoint summary-confirmation --stage <slug> --questions-file <path> --details "Looks correct"`; the engine binds the receipt to that turn, and any other call first expires the slot and forces the human to re-answer. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:intent-capture:1cb623dc14325663a1b8b0ee0347f62065b9ccdcd393517e81fd693e9ccc9850 -->
- Write every `produces[]` artifact with the harness Write or Edit tool, never a shell heredoc: heredoc writes are invisible to the write-recording hook and the engine then refuses the review with SUMMARY_ARTIFACT_UNAUTHORIZED. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:intent-capture:afedbd415e7d5fe6dc36602022492407eed5d41b85337bf5a769ef1476c74049 -->
- Paste the required review shape into every reviewer dispatch brief - one `## Review` H2, H3 or deeper below it, findings as a Markdown table with columns ID|Severity|Location|Finding|Required action|Status and single-line cells, severities Critical/Major/Minor. The reviewer persona does not supply it, and the logger refuses any later H1 or H2 heading. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:intent-capture:d729030d1286fd39d239c9dd524712d3fbdb9ee4d1a23d9bd09dfa8afb8056a3 -->
- Write each stage-diary entry as a single-line bullet `- <ISO timestamp> - <summary>; <context>` under one of memory.md's four existing H2 headings. A new `###` heading buckets every following entry under whichever H2 precedes it, which yields zero learning candidates at the ritual. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:intent-capture:7988079f481cf1ea1ef617db6454778a8e1c4e44e78ae202d67f8825e6eef05a -->
- Report container image sizes and cloud cost figures as measured values only, never estimates. The hard zero recurring-cost target depends on Artifact Registry storage staying under 0.5 GB, which is compressed and layer-deduplicated size, so an uncompressed estimate materially misstates it. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:intent-capture:de7590da1a3f8758a61f5a2e3dc35c20b49c4760051d5efaafe43d401f82c617 -->
- An option a human is offered and does not select is neither an exclusion nor a permission. Record only what was positively selected, and where the silence matters say so explicitly rather than reading it either way. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:scope-definition:8d9fa7dfb913d2e29df15e716c4b84c8675bf0626bc42932479cb611e14be2eb -->
- When two confirmed inputs contradict each other, raise a numbered follow-up question and resolve it before writing the artifact that depends on them. Writing over an unresolved contradiction hides it instead of settling it, and contradiction resolution is mandatory at every depth level. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:scope-definition:b417f999e15367ed7e6cb952839de35c1071812235a1aa6f921bf6e7dc79f87e -->
- When a composed scope marks a stage SKIP, every downstream artifact that would have consumed its output must state which decision removed that content instead of silently omitting the section, so a reader can distinguish a deliberate omission from an oversight. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:approval-handoff:70a63e7680836d588a3c9bddbc138be22e074fa926fccd46f80d90a40724bd47 -->
- Record, for every open review or sensor finding carried past a gate, whether it has a named owner stage. A finding with no owner does not close on its own, and naming that makes its persistence a visible choice rather than drift. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:approval-handoff:8cc43892a8dee647a9df680d7ff1f0926206c71b3160f7192545faabde9e2c91 -->
- When a prior inspection already covers breadth, brief the deeper scan to go deep on named subsystems rather than re-covering the same ground. Depth is where behavioural migration risk lives: on this project it returned four factual corrections and three behaviours whose loss would each ship a silent defect. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:reverse-engineering:77e932478e4fd4142d30576cf6a8e6a0160238816d93199cdd5cd07db352338d -->
- When a pipeline link produces a large work product, have it write to a file and brief the next link to read that path, rather than returning the content through the orchestrator's context. The pipeline contract permits handing results down as context, and routing six figures of bytes through conversation crowds out the stages that follow. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:reverse-engineering:7a20781822a8078355f3648258368937089c1f03c7152b86493f418351128939 -->
- Never infer that a dispatched agent is stuck from an unchanged artifact size. An agent that reads all its inputs before writing any output produces no file-level signal until the end. Either brief it to write each artifact as soon as it has what that artifact needs, so size becomes a real signal, or accept that no signal exists and wait for the completion notification. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:practices-discovery:dfa895f4bf7c874c3e321c522ec37834d1787da812bd5be35e01732d213c0df6 -->
- When independent reviewers converge on a recommendation, adopt it without putting it to the human as an open choice - but record each adopted item and who agreed in a visible table in the stage's questions file. Asking about a settled expert consensus is ceremony; hiding that it was ever a choice is worse. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:practices-discovery:5c422c757f731516075a7248093693e00bdc9de391822bd0e0f21df8917ade31 -->
- When explaining to a human why a decision is still open, never describe the system being discarded in a way that implies it is a live option. Frame the question as the value that remains to be chosen, and say plainly what has already been removed. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:requirements-analysis:c1541df3f5173c9439cc2240d752e97433f66516e1e0c2a95be236cee3f22f72 -->
- When a cleaner implementation would silently reject input the preserved system accepted, prefer parity. A silent, undiscoverable break in the owner's own longest content is worse than an inelegant limit, and 'more defensible in isolation' is not a reason to change observable behaviour under a parity rule. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:requirements-analysis:24c766106055174d2befe32d541e1a91fbb8b625a6ca7a8caa4821980ca703f9 -->
- Test every hazard-marked requirement explicitly against the language boundary when assigning it to a component, not only the ones that read like rules. A correctness rule operating on browser-local state still decides something, and placing it in the frontend needs an argued justification rather than an assumption. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:domain-design:6dc1dbe017a5e34ae3b6892de787527612831669c8e357275a261d69c5e1f86f -->
- Do not defer a design tension to a later stage when the structure you are drawing already determines its outcome. Recording a fallback is only honest if the fallback is not already the likely result; when the graph forces it, decide now and redraw. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:domain-design:4c9e39056c6d478207b553b681444b54b271ddd4865bf686e494f1f4f63b43c4 -->
- When a deliverable's capability expires - it can only be produced while some other system still exists - encode it as a real dependency edge, not as a note in a plan. A constraint a scheduler can ignore is not a constraint, and an expiry is the one kind of mistake that cannot be undone later. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:units-generation:d6a8044ff3a1ee3e8cf98afe204ccbae42a8a6abcf5a7d74c1d415c2d5b5746a -->
- When a sensor cannot pass because it checks for artifacts a skipped stage would have produced, report it as not-applicable-by-construction and disclose it inside the artifact it examines. Never manufacture the identifiers it greps for: a sensor that was satisfied artificially tells a later reader less than one that honestly failed. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:units-generation:02bc607c382dbdaba6651ef950ba60e80a047b6cd641d32d732f08a543b2666b -->
- Anything whose value is destroyed by parsing cannot be verified after parsing. An HTML parser unescapes an escaped character before a DOM diff sees it, so escaping needs a byte-level assertion on the raw response. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:functional-design:03804d91293f3ebcd52748ec6a4d02650161b7f4c274a676cf565a9d30152ea2 -->
- A plan's own rules can push an operator toward the choice that costs money. When a rule forbids a setting, check whether another rule in the same document makes that setting the natural-looking pick, and say so where the operator will be standing. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:functional-design:b324ff70777b8d149618b3458b18e3334355dc4b2e363d4e549ee6996d6fad99 -->
- Cross-check a cost table against its cited source line by line, not figure by figure. A figure can be correct while the sentence beside it decides whether the figure is reachable. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:functional-design:5557a15f11a5fbb9bad2b6ca695460df2728668d87c219f374ae2de63213fb22 -->
- Where an artifact states a total and a complement, subtract them. Two numbers that do not reconcile are the finding, and a count derived from direct references cannot see a transitive one. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:functional-design:07d61520d5500ceb37d77134577e5adb12a5e0e5a7b2ecce4ec81a54b67da3b1 -->
- When a finding names a call site, enumerate every call site before fixing it. A check that appears at N places leaves N pieces of behaviour behind when removed at one. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:functional-design:f38df72786c220d6606cc7ab460a82caf0f479dbd946943a0eedd43fc4a034fc -->
- Read a removal's stated justification against its own immediate context, not only against upstream. A justification refuted by the paragraph it sits in is the least visible and most authoritative-looking kind of error. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:functional-design:1238e3fe309ff507b054f62bdf1fc4bdd5f4c402131e34c689ed27f08b857728 -->
- Removing a validation check silently removes the user-facing copy that check raised. Ask of every deleted check: what did the user see when it fired, and is that loss recorded as a deliberate exception? (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:functional-design:d1684a0c6a12a3044e57f590b9e35ea36ad14bb7e0cc7aeaa81e35db19960a54 -->
- A check that regenerates an artifact and diffs it against itself proves that artifact is CURRENT; it cannot prove it is the ONLY one. Currency and uniqueness are separate properties and need separate checks. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:functional-design:5c043802b0844c0609ad26868544195aad52d7d8e65670d658da84cebf58e1df -->
- A rule's `source:` field means WHAT REQUIREMENT THIS RULE SATISFIES, not what requirement it is about. A rule that merely enables a requirement must not claim to discharge it. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:functional-design:8e998faddc789f2d8f839a0d2cca270f655aff17aabf170287dafb423ea8c410 -->
- Paste all three enumerated review cells into every dispatch brief: ID `^R-[0-9]+$`, Severity Critical|Major|Minor, Status New|Unresolved|Resolved|Accepted risk|Rejected: <reason>. There is no partial state, and the logger refuses the whole receipt over one bad cell. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:functional-design:d6ff0a0a40b49bac78e089a4ddc827a32c39d7f4637a4e133c824b657057fb16 -->
- Workflow-level stage artifacts freeze under the FIRST unit's terminal receipt, not under a separate workflow-level review. Shared artifacts must be right before the first unit is reviewed, not merely before the last. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:functional-design:c36d33dc11429e27be4fb4c5fcc6045d3c1e922f9ceb7a369e612136c5a83fc1 -->
- The reviewer dispatch record is the conductor's file, not the engine's: write it immediately before every per-unit dispatch and DELETE it the moment the verdict is read. A leftover record enforces the previous unit's scope against the next reviewer. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:functional-design:eb760391a9790a5abd459bf8e7bd2fce6770758d319d3b8bf967a58e7d9ed956 -->
- When an `aidlc` noun fails with "does not export main(argv)", run its `.claude/tools/aidlc-*.ts` source directly with bun before recording a deviation. The binary's loader is usually the only obstruction. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:functional-design:8766ebf20ae00e47255281730af8655da41a16257d9cbab27d3662809d1a0d49 -->
- A reviewer that cannot open the artifacts it was sent to review must refuse to write a verdict. READY and NOT-READY on zero evidence are both false audit records, and either burns a review iteration on a dispatch fault. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:functional-design:bf73370d2239a7459b6b9e6f2bf792bee1c3889a134d08458351701de26c168c -->
- A dispatch brief cannot widen a reviewer's read scope. The dispatch record's exempt[] is the only place a sibling read is granted; a reviewer denied evidence does not report insufficient evidence, it reasons from what it can reach. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:functional-design:fcda835cb579539f9b80c0e7e8bb045002880187ee0c2a4221aa144b61db524f -->
- Open the review request BEFORE dispatching the reviewer. `log review --iteration N` without `--verdict` opens the slot and deletes any review file already sitting there. (learned 2026-09-24) <!-- cid:260924-chiku-website-migration:functional-design:e90ba71cc476ad2be7b1e9c9b923f75d33ec7b7d3176e8bded9b08f4a0356971 -->
