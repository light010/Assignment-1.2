# Architecture — `madhavi-tripathi/`

**System documented:** the application source tree at `madhavi-tripathi/` inside the workspace
`/Users/praka/Workspace/Projects/Chiku_website`.
**Commit:** `50856de`. **Scan time:** 2026-09-24T14:48:17Z. Depth, exclusions and limits:
`reverse-engineering-timestamp.md`.

**What this file is — and is not.** This is an *as-built* record of the runtime topology and of
where each cross-cutting decision (authentication, authorisation, validation, transactionality,
caching) is actually made in the code. It documents what **is**. It proposes no target
architecture, recommends nothing and contains no migration instructions, so it presents no
decision records and no alternatives analysis — there is no decision being taken here to weigh
alternatives for. Where the scan identified a risk in the existing behaviour, it is recorded
below as a **hazard**, with the full technical analysis in `code-quality-assessment.md`.

`.claude/` and `aidlc/` are framework, not application code, and are excluded throughout.
`chiku-website/` does not exist.

---

## Runtime topology as it is today

Everything — page rendering, API handling, authorisation and data access — runs in **one
Cloudflare Worker**. There is no separate application server, no container, and no network hop
between "frontend" and "backend".

`vinext@1.0.0-beta.5` is a Vite-based runtime that presents a **Next.js 16.3.4** App Router
programming model on top of the Workers runtime. React Server Components render inside the
Worker; the browser receives HTML plus a client bundle.

Two Cloudflare services are bound to the Worker by logical name, declared in
`.openai/hosting.json`:

```json
{ "d1": "DB", "r2": "BUCKET", "project_id": "appgprj_6ab410c1958881919d6bb03246327b86" }
```

`db/index.ts` (**3 lines**) is the entire data-access abstraction — it reads `env.DB` /
`env.BUCKET` from `cloudflare:workers` and throws if either is missing. **Every query in the
application is a raw SQL string** against the returned `D1Database` handle.

> **Correction carried from the scan.** `drizzle-orm` is **not** the runtime data layer.
> `db/schema.ts` is not reachable from any of the ten Next.js entry points; it is imported only
> by `drizzle.config.ts`, which exists to run `drizzle-kit generate`. Grepping for `drizzle`
> across `app/` and `db/` returns exactly one hit: the import on line 1 of `db/schema.ts`.
> There are **11 hand-written SQL strings** and no ORM in the request path. Describing this
> system as "using an ORM" would be wrong. See `code-structure.md` and `dependencies.md`.

## Request path

```mermaid
flowchart TD
  V["Visitor browser"] --> W
  O["Owner browser at /edit"] --> W
  W["Cloudflare Worker: vinext + Next.js 16.3.4"]
  W --> RSC["Server components: page.tsx, edit/page.tsx, sitemap.ts, robots.ts"]
  W --> API["Route handlers: api/content, api/history, api/upload, api/media"]
  RSC --> AUTH
  API --> AUTH
  AUTH["editorAccess in app/server.ts line 15"]
  AUTH --> HDR["getChatGPTUser reads oai-authenticated headers"]
  AUTH --> ED[("D1 table: editors")]
  API --> ORIG["sameOrigin check, PUT and POST only"]
  API --> ZOD["contentSchema.safeParse in app/content.ts line 20"]
  ZOD --> CP["content-persistence.ts: seven-statement D1 batch"]
  CP --> SC[("D1 table: site_content, draft and published and revision")]
  CP --> CR[("D1 table: content_revisions")]
  API --> R2[("R2 bucket: BUCKET")]
  API --> AS[("D1 table: assets")]
  RSC --> CP
```

**Text fallback for the diagram.** Both the visitor browser and the owner browser talk to a
single Cloudflare Worker running vinext plus Next.js 16.3.4. Inside the Worker, requests split
two ways: server components (`page.tsx`, `edit/page.tsx`, `sitemap.ts`, `robots.ts`) and route
handlers (`/api/content`, `/api/history`, `/api/upload`, `/api/media/[key]`). Both paths call
`editorAccess()` at `app/server.ts:15`, which calls `getChatGPTUser()` to read the
platform-injected `oai-authenticated-*` headers and then looks the user up in the D1 `editors`
table. The two mutating route handlers additionally call `sameOrigin()`. Content writes go
through `contentSchema.safeParse` in `app/content.ts:20` and then into
`content-persistence.ts`, which issues one seven-statement D1 batch against `site_content` and
`content_revisions`. Uploads write to the R2 bucket and to the D1 `assets` table. Server
components read content through the same persistence module.

## Where authentication is decided

**Nowhere in this codebase.** The application does not authenticate anyone. It trusts four HTTP
headers injected by the ChatGPT hosting platform (`app/chatgpt-auth.ts:11-16`):

- `oai-authenticated-user-id`
- `oai-authenticated-user-email`
- `oai-authenticated-user-full-name`
- `oai-authenticated-user-full-name-encoding`

`getChatGPTUser()` (`app/chatgpt-auth.ts:21`) returns `null` unless **both** the user-id and
email headers are present; otherwise it returns them as a trusted identity. There is **no
signature check, no token validation, no session cookie and no expiry**. The security model is
entirely "the platform terminates the request and the Worker is not reachable directly".
Sign-in, sign-out and callback are platform routes (`/signin-with-chatgpt`,
`/signout-with-chatgpt`, `/callback`) that are **not implemented in this repository**.

Locally, `build/sites-vite-plugin.ts` fakes these headers for `local_seedy` /
`seedy@sites.test` via a `__sites_local_auth` cookie, restricted to localhost.

> **Hazard.** Anything that puts the Worker behind a proxy, or reproduces this pattern without
> the platform in front of it, makes the editor world-writable: an attacker who can set two
> request headers becomes the owner. There is **no second factor anywhere in the code**.

## Where authorization is decided

`app/server.ts`, in `isEditor()` (lines 6–14), reached through `editorAccess()` (line 15):

1. No user → not an editor.
2. `SELECT user_id FROM editors WHERE user_id = ?` → row exists → editor.
3. Otherwise, if `user.email.toLowerCase()` equals the hard-coded
   `OWNER_EMAIL = 'madhavi.tri16@gmail.com'` (line 5) → `INSERT OR IGNORE` that user into
   `editors`, re-select, and return the result.

So authorisation is a **self-bootstrapping allowlist of one, seeded by a hard-coded email
address in source**. There are no roles and no permission levels: `isEditor` is the only
authorisation predicate in the codebase, and it gates every privileged path.

**Seven call sites:** `app/api/content/route.ts:6,10`, `app/api/history/route.ts:7`,
`app/api/upload/route.ts:17`, `app/api/media/[key]/route.ts:8`, `app/edit/page.tsx:8`,
`app/edit/preview/page.tsx:8`, and `app/page.tsx:7` (to decide whether to show the
"Edit website" footer link).

> **Hazard.** `app/page.tsx:7` calls `editorAccess()` on **every public page render**, purely to
> decide whether to show one footer link. Every anonymous visitor request therefore performs a
> D1 lookup that is only meaningful for one person.

> **Hazard.** A personal email address is committed to the repository and functions as the
> authorization root of trust (`code-quality-assessment.md` → finding E).

## Where validation happens — in both places, via the same schema

`app/content.ts` exports one zod schema, `contentSchema`. It is imported and executed on **both
sides of the network boundary**:

| Side | File and line | What it does with the result |
|---|---|---|
| Browser | `app/edit/editor-workflow.ts:54` | Blocks the save entirely; renders `issues[]` as a "check these fields" list |
| Browser | `app/edit/editor-workflow.ts:17` | Validates a recovered localStorage draft |
| Browser | `app/edit/editor-workflow.ts:73` | Re-validates the draft fetched by *Load latest draft* |
| Browser | `app/edit/editor.tsx` (`RevisionHistory.select`) | Validates a historical revision before offering to restore it |
| Worker | `app/api/content/route.ts:14` | Rejects with 400 and returns `issues[]` |
| Worker | `app/content-persistence.ts:10` | `normalizeStoredContent` — re-parses **on every read out of D1** |

Because the same module runs in both places, client and server can never disagree today.

> **Hazard — the highest-leverage one in this section.** The moment client and server stop
> sharing this module, this single schema becomes two schemas. Every constraint in
> `api-documentation.md` → *Content schema* would have to be reproduced exactly, and the
> `.transform()` and `.default()` behaviour reproduced too — not just the validation rules.
> `normalizeStoredContent` re-parsing on every read means **the schema is also the storage read
> path**: tighten a rule and previously-stored documents stop loading, which surfaces as a
> **503 on `/`, on `/api/content` and on every `/api/media/*` request simultaneously**.

## The draft/published split and how a change reaches a visitor

One row, `site_content` with `id = 1`, holds both documents:

```
site_content(id=1, draft TEXT, published TEXT, revision INT,
             updated_at TEXT, published_at TEXT NULL, last_mutation TEXT NULL)
```

The other three tables (from `drizzle/`'s two SQL migrations, all queried as raw SQL at
runtime):

- `content_revisions` — `id` (a mutation UUID, or the fixed `starting-draft` /
  `starting-published`), `revision`, `action` (`draft` or `publish`), `content` JSON,
  `created_at`, `baseline` (SQLite integer, coerced with `!!row.baseline`).
- `editors` — `user_id` primary key, `email` unique.
- `assets` — `key` primary key, `filename`, `mime`, `size`, `created_at`.

The path from an owner's keystroke to a visitor's screen:

1. Owner types. `useDraftWorkflow` marks the document dirty.
2. **1.5 s** after typing stops, if the document is valid, the editor `PUT`s
   `{content, revision, action: 'draft', autosave: true}`.
3. The Worker validates, then runs the **seven-statement D1 batch**. `draft` is replaced;
   `published` is untouched; `revision` increments.
4. Nothing changes for visitors. Repeat 1–3 indefinitely.
5. Owner presses *Publish changes*. Same `PUT`, `action: 'publish'`, `autosave` absent.
6. The batch's `UPDATE` sets `published = draft = <new content>` and stamps
   `published_at = now`.
7. The next visitor request runs `app/page.tsx`, which is `dynamic = 'force-dynamic'`. It reads
   the row fresh from D1 and renders `data.published`.

**Propagation is immediate and uncached.** Every public page render is a fresh D1 read; there is
no ISR, no revalidation window and no CDN cache in front of the HTML. There is therefore no
"publish then wait" step and no cache to purge. `hasUnpublishedChanges` is computed on the fly
as `JSON.stringify(draft) !== JSON.stringify(published)` (`app/content-persistence.ts:16`) — a
full string comparison of two ~15 KB documents on every single read.

> **Hazard.** That `force-dynamic` + no-cache posture is load-bearing for the product's feel
> ("publish and it's live"), but it means the read path has no caching headroom designed into
> it. Any architecture that introduces caching changes observable publish behaviour.

All four route files also declare `export const dynamic = 'force-dynamic'`
(`api-documentation.md`).

## Three behaviours that carry architectural weight

These are documented in full in `code-quality-assessment.md`. They are named here because each
one *is* an architectural property of this system, not an implementation detail, and a
reimplementation that loses any one of them ships a silent defect.

### 1. Transactional integrity of a write is enforced by two different guards

`app/content-persistence.ts:28-40`. All seven statements run in **one D1 `batch()`**, which D1
executes as a single implicit transaction. Two guards operate inside it:

- **`revision` (statement 3) protects the content write.** `UPDATE ... WHERE id = 1 AND
  revision = ?` is the optimistic-concurrency check. If it matches nothing,
  `results[3]?.results?.[0]` is `undefined`, `writeContent()` returns `null`, and
  `app/api/content/route.ts:18` returns **409**.
- **`last_mutation` (statements 4, 5, 6) protects the side effects.** A fresh
  `crypto.randomUUID()` per call is stamped onto the row by statement 3 and then required by
  the history insert and both retention deletes.

The second guard is **not redundant**: statements 4–6 are guarded on `revision = nextRevision`,
a value that is *not unique to the writer*. With the row at revision 5 and writers A and B both
holding 5, B commits first and the row advances to 6; A's CAS correctly fails, but A's
`nextRevision` is also 6, so without the token A's history insert and retention deletes would
match **B's** write. This is a classic **ABA defence**. Full statement-by-statement analysis,
including the nine enumerated hazards and the load-bearing positional index `results[3]`, in
`code-quality-assessment.md` → *The seven-statement D1 batch* and *Why `last_mutation` exists
alongside the `revision` CAS*.

### 2. Validation is also the storage read path, and it carries content

`app/content.ts:17` runs a `.transform()` on **every** parse of an item — which, through
`normalizeStoredContent`, includes every read out of D1:

```ts
.transform(row => ({...row,
  researchTopic: researchIdentity(row),
  researchIds: row.researchIds ?? initialResearchLinks.get(row.id) ?? []}))
```

This is **not a validator; it is a defaulting rule that carries content**. `researchIdentity`
(`app/research-identity.ts:11-18`) maps three legacy card ids to their topic;
`initialResearchLinks` (`app/site-copy.ts:37-43`) supplies the original editorial linkage for
five seeded publications. Both use `??`, so an explicitly-cleared `[]` is preserved and never
re-populated. Dropping either produces a page that renders with identical slate research cards,
0 related papers on every card, and an empty topic filter — with nothing logged. Full analysis
in `code-quality-assessment.md`; consequences at the field level in `api-documentation.md` →
*Content schema*.

### 3. Media access control is decided by the content of the published document

`app/api/media/[key]/route.ts:7`:

```ts
const {published} = await readContent();
const isPublic = JSON.stringify(published).includes(`/api/media/${key}`);
```

An asset is public **iff** the literal string `/api/media/<key>` appears anywhere in the
serialised published document — including inside free prose. Architecturally this means:

- the **content store is on the critical path of every media byte served**;
- every free-text field is an access-control surface;
- a stored document that fails schema validation **503s every image, the public page and the
  editor simultaneously**, because all three go through `readContent()`;
- the cost per media request is one D1 row read, **two** full schema validations and **three**
  serialisations of a ~15 KB document, with `Cache-Control: private, no-cache` and **no 304
  path**, repeated for **every byte-range request** of a streamed video.

Full analysis, including the six failure modes and the prefix-collision check, in
`api-documentation.md` → *The public-access rule* and `code-quality-assessment.md`.

## Observed trade-off of this topology

Recorded as an observation about the system as built, not as a recommendation.

**The merit:** colocating render and data in one Worker makes the published document reachable
with zero network hops, and makes the draft/published swap atomic within a single D1
transaction.

**The cost:** authentication is delegated entirely to the host platform, so the application has
**no identity mechanism of its own**. There is nothing in this codebase to carry forward on that
axis.

**A second observed cost:** `readContentState()` does unnecessary work on every read — it parses
*both* the draft and the published document and computes `hasUnpublishedChanges` via two
`JSON.stringify` calls, regardless of caller. Three of the five call sites
(`/api/media/[key]`, `app/page.tsx`, `app/sitemap.ts`) pay for the draft parse and the
comparison and use neither (`code-quality-assessment.md` → finding G).

## Cross-cutting concerns as they stand today

| Concern | Where it is handled | Notes |
|---|---|---|
| Authentication | Not in this codebase | Platform headers only; see above |
| Authorization | `app/server.ts` `isEditor` | Single predicate, 7 call sites, allowlist of one |
| CSRF | `sameOrigin()` at `app/server.ts:16` | Applied to `PUT /api/content` and `POST /api/upload` only. No token. A missing `Origin` header **fails** the check |
| Input validation | `contentSchema` + per-route checks | Broad; see `api-documentation.md` and `code-quality-assessment.md` |
| Transactions | One D1 `batch()` per content write | R2 and D1 in the upload path have **no shared transaction** |
| Caching | None for HTML; `private, no-cache` for media | No ISR, no CDN cache, no 304 path |
| Rate limiting | **None anywhere** | Not on upload, not on save, not on media |
| Observability | `console.error` only | No structured logging, no request id, no correlation, no error taxonomy — everything unexpected is a 503 |
| Error handling | `try/catch` in all four route handlers | Structured JSON errors; no exception escapes to a framework error page |
| Configuration | Hard-coded | `siteOrigin` (`app/site-metadata.ts:5`) and `OWNER_EMAIL` (`app/server.ts:5`) are source literals; no environment variable for either |

## Sources

- `aidlc/spaces/default/intents/260924-chiku-website-migration/inception/reverse-engineering/developer-scan.md`
  § `architecture` (authoritative for this file), with facts drawn from § `api-documentation`,
  § `code-structure` and § `code-quality-assessment`.
- Source files cited inline: `madhavi-tripathi/app/server.ts`, `app/chatgpt-auth.ts`,
  `app/content.ts`, `app/content-persistence.ts`, `app/page.tsx`, `app/site-metadata.ts`,
  `app/api/*/route.ts`, `db/index.ts`, `db/schema.ts`, `drizzle/*.sql`, `.openai/hosting.json`,
  `build/sites-vite-plugin.ts`.
