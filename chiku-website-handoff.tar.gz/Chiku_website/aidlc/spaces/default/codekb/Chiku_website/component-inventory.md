# Component inventory — `madhavi-tripathi/`

**System documented:** the application source tree at `madhavi-tripathi/` inside the workspace
`/Users/praka/Workspace/Projects/Chiku_website`.
**Commit:** `50856de`. **Scan time:** 2026-09-24T14:48:17Z. Depth, exclusions and limits:
`reverse-engineering-timestamp.md`.

**What this file is.** A census of every user-interface building block in the tree — React
components, the vendored UI library, stylesheets and static assets — with an explicit
used/unused determination for each, computed by resolving import specifiers rather than by
inspection. It records what **is**; it does not propose what to keep or drop.

**Context a reader needs and will not find elsewhere in this file.** The application is a
Next.js 16.3.4 App Router project running on the Cloudflare Workers runtime via
`vinext@1.0.0-beta.5`. It has exactly **ten framework entry points** — `app/page.tsx`,
`app/layout.tsx`, `app/robots.ts`, `app/sitemap.ts`, `app/edit/page.tsx`,
`app/edit/preview/page.tsx`, and the four `app/api/*/route.ts` files. "Reachable" below always
means reachable from those ten by following imports. Transitive reachability from them covers
**52 files** in total.

`.claude/` and `aidlc/` are framework, not application code, and are excluded. `chiku-website/`
does not exist.

---

## React components in `app/` — 36 total

Enumerated by grepping declaration forms across all **16** `app/**/*.tsx` files.
**All 36 are used**; none is orphaned.

**Route components (4)** — invoked by the framework, not imported:

| Component | File:line |
|---|---|
| `Home` | `app/page.tsx:6` |
| `RootLayout` | `app/layout.tsx:13` |
| `EditPage` | `app/edit/page.tsx:6` |
| `PreviewPage` | `app/edit/preview/page.tsx:6` |

**Exported components (13)** — imported by other modules:

| Component | File:line | Used by |
|---|---|---|
| `ColorModeProvider` | `app/color-mode.tsx:7` | `layout.tsx` |
| `ColorModeToggle` | `app/color-mode.tsx:11` | `site.tsx` |
| `AcademicSite` | `app/site.tsx:32` | `page.tsx`, `draft-preview.tsx`, `preview-client.tsx` |
| `Achievements` | `app/achievements.tsx:72` | `site.tsx` |
| `Publications` | `app/publications.tsx:31` | `site.tsx` |
| `ResearchSection` | `app/research-section.tsx:40` | `site.tsx` |
| `Updates` | `app/updates.tsx:18` | `site.tsx` |
| `ResearchScene` | `app/scene.tsx:43` | `site.tsx` |
| `ResponsiveImage` | `app/responsive-image.tsx:21` | `site.tsx`, `achievements.tsx`, others |
| `Editor` | `app/edit/editor.tsx:66` | `edit/page.tsx` |
| `UploadField` | `app/edit/upload-field.tsx:46` | `editor.tsx` |
| `DraftPreview` | `app/edit/draft-preview.tsx:5` | `editor.tsx` |
| `PreviewClient` | `app/edit/preview/preview-client.tsx:5` | `edit/preview/page.tsx` |

**Module-private components (19)** — declared and used within one file:

| File | Components |
|---|---|
| `app/achievements.tsx` | `MomentPreview` (:16), `MomentCard` (:22), `AchievementShowcaseCard` (:37), `CaptionLoadError` (:52), `ViewerMedia` (:56) |
| `app/edit/editor.tsx` | `Field` (:30), `MediaField` (:35), `CropControl` (:39), `ToggleField` (:43), `CollectionFields` (:44), `RevisionHistory` (:59) |
| `app/site.tsx` | `External` (:14), `Label` (:17), `ProfilePortrait` (:20) |
| `app/research-section.tsx` | `RelatedPapers` (:13), `ResearchCard` (:20) |
| `app/publications.tsx` | `PaperRow` (:12) |
| `app/scene.tsx` | `SceneSteps` (:37) |
| `app/updates.tsx` | `UpdateCard` (:9) |

Split: 4 route + 13 exported + 19 private = **36**.

> **Caution on the line references.** `app/edit/editor.tsx` is written in a dense single-line
> style (99 lines, 34,555 bytes, longest line 3,969 characters), so a line number there locates
> a region, not a statement. See `code-quality-assessment.md` → *The dense single-line style*.

## `components/ui/` — 61 files, 7,334 lines

Vendored shadcn registry components (registry **4.17.0**). The used/unused split was computed by
resolving every import specifier in the tree.

| Category | Count | Lines |
|---|---|---|
| **Imported by `app/` code** | **11** | 1,131 |
| Reachable only transitively from those 11 | **1** (`button.tsx`) | 64 |
| **Reachable in total** | **12** | **1,195** |
| **Never reachable from any entry point** | **49** | **6,139** |
| Total | **61** | **7,334** |

So **84% of the vendored component library by line count is unreachable code.**

**The 11 imported directly by `app/`:** `alert-dialog`, `carousel`, `collapsible`, `dialog`,
`progress`, `radio-group`, `select`, `slider`, `switch`, `tabs`, `toggle`. (Full edge list in
`code-structure.md` → *Import graph*.)

**Transitive reachability.** Starting from the ten Next.js entry points, exactly **12**
`components/ui` files are reachable: the 11 above plus `button.tsx`, pulled in by
`alert-dialog.tsx`, `carousel.tsx` and `dialog.tsx`.

**The 49 unreachable files:**

```
accordion, alert, aspect-ratio, attachment, avatar, badge, breadcrumb, bubble,
button-group, calendar, card, chart, checkbox, combobox, command, context-menu,
direction, drawer, dropdown-menu, empty, field, form, hover-card, input-group,
input-otp, input, item, kbd, label, marker, menubar, message-scroller, message,
native-select, navigation-menu, pagination, popover, resizable, scroll-area,
separator, sheet, sidebar, skeleton, sonner, spinner, table, textarea,
toggle-group, tooltip
```

Eight of these (`input-group`, `input`, `label`, `separator`, `sheet`, `skeleton`, `textarea`,
`tooltip`) *are* imported — but **only by other unused components** (`combobox`, `field`,
`form`, `sidebar`, `button-group`, `item`). They form a **dead subgraph: real edges, no root**.

> **Correction carried from the scan.** The earlier inspection reported **55 files and ~44
> unused**. The measured figures are **61 files** and **49 unreachable** (11 app-imported, 12
> reachable in total). The scan recorded the discrepancy rather than silently correcting it, and
> so does this file: the measured numbers above are authoritative.

## Other non-`app/` modules

| File | Lines | Status |
|---|---|---|
| `lib/utils.ts` | 6 | **Used, but only by `components/ui/`** — 57 of 61 import it. **Zero `app/` imports** |
| `hooks/use-mobile.ts` | 19 | **Dead.** Imported only by `components/ui/sidebar.tsx:8`, itself unreachable |
| `db/index.ts` | 3 | Used by 4 `app/` files (`content-persistence.ts`, `server.ts`, `api/upload/route.ts`, `api/media/[key]/route.ts`) |
| `db/schema.ts` | 7 | **Not in the runtime graph.** Build-time only — imported solely by `drizzle.config.ts` (see `code-structure.md`) |

Both `lib/utils.ts` and `hooks/use-mobile.ts` travel with the vendored UI library, not with the
application. That matters to any instruction phrased as "keep `lib/` and `hooks/`".

## CSS — 9 application files, 1,124 lines (+629 vendored)

All nine are imported, **in this exact order**, by `app/layout.tsx:2-10`. **Order matters:**
`globals.css` establishes the design tokens the other eight consume.

| File | Lines | Styles |
|---|---|---|
| `app/globals.css` | 169 | **Entry point.** `@import "tailwindcss"`, `@import "tw-animate-css"`, `@import "../vendor/shadcn-tailwind-4.13.0.css"`; the `@font-face` for self-hosted Inter Variable (line 6); the `:root` design-token palette; the `@theme inline` Tailwind token bridge |
| `app/color-mode.css` | 594 | **Largest by far.** Light/dark palettes, accent variants (blue/burgundy/forest), and the bulk of the editorial page styling |
| `app/gallery.css` | 115 | Achievements gallery, showcase cards, media lightbox |
| `app/editor-workflow.css` | 99 | Editor shell, save bar, recovery notice, validation summary, undo notice, revision history |
| `app/research-navigation.css` | 71 | Research theme spreads and topic navigation |
| `app/scene-guide.css` | 28 | 3D scene tour guide overlay |
| `app/media-upload.css` | 20 | Upload field, progress bar, retry controls |
| `app/updates.css` | 17 | News carousel cards |
| `app/site-navigation.css` | 11 | Section index / sticky nav |
| `vendor/shadcn-tailwind-4.13.0.css` | 629 | Vendored shadcn base layer (MIT, © 2023 shadcn) |

**No CSS modules, no CSS-in-JS.** The application mixes Tailwind utility classes (mostly inside
`components/ui/`) with hand-written semantic class names (mostly in `app/`).

## `public/` — 6 files

| File | Status |
|---|---|
| `public/favicon.svg` | Used — `layout.tsx:12` |
| `public/images/academic-flow.webp` | Used — the decorative cover artwork |
| `public/fonts/inter-latin-variable.woff2` | Used — `globals.css:6` |
| `public/file.svg` | **Unused** — Next.js starter leftover |
| `public/globe.svg` | **Unused** — Next.js starter leftover |
| `public/window.svg` | **Unused** — Next.js starter leftover |

Note that the font is **self-hosted from `public/fonts/`**, which is why the declared
`@fontsource-variable/inter` dependency is imported nowhere (`dependencies.md`).

## Known defect touching a live component

`components/ui/carousel.tsx:194` (`disabled={!canScrollPrev}`) and `:224`
(`disabled={!canScrollNext}`) use the native `disabled` attribute on the arrow buttons. A
disabled button is removed from the tab order, so at a carousel endpoint the focused control
disappears and focus falls to `<body>`, breaking keyboard navigation mid-interaction. This
affects **both live carousels** — achievements (`app/achievements.tsx`) and updates
(`app/updates.tsx`) — and is aggravated by `app/use-section-carousel.ts:38`, which routes arrow
keys through `closest('[data-slot="carousel-previous"],[data-slot="carousel-next"]')`, i.e. the
keyboard handler depends on focus being *on* the very button `disabled` has just removed.
`carousel.tsx` is **vendored shadcn source** that `eslint.config.mjs` deliberately exempts from
three lint rules to keep the registry copy verbatim. Confirmed **pre-existing**, not a
regression. Full detail in `code-quality-assessment.md`.

## Sources

- `aidlc/spaces/default/intents/260924-chiku-website-migration/inception/reverse-engineering/developer-scan.md`
  § `component-inventory` (authoritative for this file), with the carousel defect from
  § `code-quality-assessment`.
- Measurements: declaration-form grep over the 16 `app/**/*.tsx` files; a full import graph and
  entry-point reachability analysis (the scan's `graph.mjs` / `reach.mjs`); per-file line counts.
