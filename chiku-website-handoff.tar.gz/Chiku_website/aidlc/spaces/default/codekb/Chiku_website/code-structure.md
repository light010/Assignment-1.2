# Code structure — `madhavi-tripathi/`

**System documented:** the application source tree at `madhavi-tripathi/` inside the workspace
`/Users/praka/Workspace/Projects/Chiku_website`.
**Commit:** `50856de`. **Scan time:** 2026-09-24T14:48:17Z. Depth, exclusions and limits:
`reverse-engineering-timestamp.md`.

**What this file is.** The physical and logical layout of the code as it exists: what is where,
how big it is, what imports what, and which boundaries the code already separates along. It
records what **is**; it proposes no reorganisation.

`.claude/` and `aidlc/` are framework, not application code, and are excluded from every count
below. `chiku-website/` does not exist.

---

## Top-level layout

Counts are from `find` over the tree with `node_modules/`, `.next/`, `.vinext/`, `dist/`,
`.wrangler/`, `.sites-runtime/`, `outputs/` and `examples/` excluded. **157 files** remain (git
tracks 158 under `madhavi-tripathi/`; the difference is `tsconfig.tsbuildinfo`, a generated file
recorded as omitted in `SOURCE-MANIFEST.json`).

| Directory | Files | Purpose |
|---|---|---|
| `app/` | 47 (22 `.ts`, 16 `.tsx`, 9 `.css`) | The entire application: pages, API routes, domain logic, styles |
| `components/ui/` | 61 `.tsx` | Vendored shadcn 4.17.0 registry components |
| `db/` | 2 | `index.ts` (binding accessors) + `schema.ts` (drizzle, build-time only) |
| `drizzle/` | 5 | 2 SQL migrations + drizzle-kit metadata |
| `hooks/` | 1 | `use-mobile.ts` |
| `lib/` | 1 | `utils.ts` (the shadcn `cn()` helper) |
| `public/` | 6 | favicon, cover image, Inter woff2, 3 unused SVGs |
| `scripts/` | 10 | Cloudflare/OpenAI-Sites installer and environment shims (1,089 lines) |
| `build/` | 2 | Vendored `@openai/sites-vite-plugin` 0.2.0 + its MIT licence |
| `vendor/` | 2 | shadcn Tailwind 4.13.0 CSS + its MIT licence |
| `docs/` | 1 | `CONTENT-SOURCES.md` — content provenance |
| root | 18 | configs, manifests, README, two archive-only prompt files |

> **Recorded discrepancy, not corrected.** The rows above sum to **156**, while the stated total
> is **157**. The most likely unplaced file is `.openai/hosting.json`, which the scan describes
> (it declares the `DB`/`BUCKET` bindings) but does not assign to any directory row. Recorded as
> an open arithmetic gap rather than silently reconciled.

**Line counts.** **9,513 lines** of `.ts`/`.tsx` across the scanned tree. Of those,
`components/ui/` is **7,334** (77%) and `app/` is **1,819** (19%). Plus **1,124 lines of CSS**
in `app/` and **629** in `vendor/`.

The shape to notice: the application's own logic is **under 1,900 lines**. Three quarters of the
TypeScript in the repository is vendored UI library code, most of which is never used (see
`component-inventory.md`).

> **Caution on line counts.** `app/` files are written in a dense single-line style: the whole
> top-level schema is one 1,189-character line, and `app/edit/editor.tsx` has a 3,969-character
> line. The line counts understate the work by roughly **3–5×**; bytes are the honest measure
> (~200 KB of application TypeScript). Full evidence that this is a deliberate house style
> rather than a defect is in `code-quality-assessment.md` → *The dense single-line style*.

## `app/` module responsibilities

Line counts are exact. 38 `.ts`/`.tsx` files plus 9 `.css` files = 47.

**Route entry points (10).** These are the only files the framework invokes directly.

| File | Lines | Responsibility |
|---|---|---|
| `app/page.tsx` | 9 | Public page. Parallel `readContent()` + `editorAccess()`; injects JSON-LD; renders `AcademicSite` |
| `app/layout.tsx` | 13 | HTML shell; imports all 9 CSS files; wraps in `ColorModeProvider` |
| `app/robots.ts` | 5 | Static robots rules; disallows `/edit` and `/api/` |
| `app/sitemap.ts` | 8 | One URL, `lastModified` = `publishedAt` |
| `app/edit/page.tsx` | 11 | Owner gate → renders `Editor` with the draft |
| `app/edit/preview/page.tsx` | 10 | Owner gate → renders `PreviewClient` |
| `app/api/content/route.ts` | 21 | GET draft+published state; PUT save/publish |
| `app/api/history/route.ts` | 14 | GET revision list or one revision |
| `app/api/upload/route.ts` | 75 | POST multipart media upload |
| `app/api/media/[key]/route.ts` | 21 | GET/HEAD media bytes |

**Domain and persistence (server-reachable).**

| File | Lines | Responsibility |
|---|---|---|
| `app/content.ts` | 66 | **The schema.** zod `contentSchema` + `initialContent` seed. 12,484 bytes |
| `app/content-persistence.ts` | 58 | All content SQL: read state, the 7-statement write batch, revision list/fetch |
| `app/server.ts` | 16 | `isEditor` / `editorAccess` / `sameOrigin`; re-exports `readContent` |
| `app/chatgpt-auth.ts` | 90 | Platform header identity; sign-in/out path builders; return-path sanitisation |
| `app/upload-validation.ts` | 68 | Hand-written PNG/WebP/JPEG header parsers + WebVTT validator |
| `app/media-utils.ts` | 22 | `videoSource()` host allowlist; `parseByteRange()` |
| `app/site-copy.ts` | 43 | `copySchema`, `initialCopy`, **and** `initialResearchLinks` |
| `app/research-identity.ts` | 18 | Topic enum, labels, and the `originalTopics` back-compat map |
| `app/scene-content.ts` | 10 | Scene types + `initialScene` defaults |
| `app/site-metadata.ts` | 42 | OG/Twitter metadata + JSON-LD. **Hard-codes `siteOrigin` at line 5** |

**Presentation (client).**

| File | Lines | Responsibility |
|---|---|---|
| `app/site.tsx` | 122 | `AcademicSite` — the whole public page, all six sections |
| `app/achievements.tsx` | 125 | Highlights gallery carousel + media lightbox |
| `app/publications.tsx` | 74 | Publication archive with search/year/topic/sort |
| `app/research-section.tsx` | 43 | Research theme spreads + related-paper counts |
| `app/updates.tsx` | 29 | News carousel |
| `app/scene.tsx` | 142 | 3D cover; gates and lazily imports the WebGL renderer |
| `app/nano-renderer.ts` | 129 | three.js renderer. **Builds to a 560,248-byte client chunk** |
| `app/scene-performance.ts` | 16 | `shouldLoadResearchScene` — motion/save-data gate |
| `app/responsive-image.tsx` | 31 | `srcset` builder with per-source URL sanitisation |
| `app/color-mode.tsx` | 19 | next-themes provider + toggle |
| `app/publication-utils.ts` | 50 | Filter/sort/anchor/URL logic for publications |
| `app/use-section-carousel.ts` | 43 | Shared carousel state, reduced-motion handling, arrow keys |

**Editor (client).**

| File | Lines | Bytes | Responsibility |
|---|---|---|---|
| `app/edit/editor.tsx` | 99 | 34,555 | The whole 10-tab editor. Largest file in `app/` |
| `app/edit/editor-workflow.ts` | 78 | 9,831 | `useDraftWorkflow` — save, autosave, recovery, conflict state |
| `app/edit/upload-field.tsx` | 126 | 9,791 | XHR upload with progress, abort, retry |
| `app/edit/draft-preview.tsx` | 12 | 2,861 | In-editor preview overlay |
| `app/edit/preview/preview-client.tsx` | 13 | 1,913 | Standalone draft preview page body |
| `app/image-processing.ts` | 48 | 2,308 | **Browser-side** canvas WebP variant generation |

(10 + 10 + 12 + 6 = 38 files; 187 + 433 + 823 + 376 = 1,819 lines.)

## Import graph

Computed by resolving every `import` / `require` / dynamic-`import` specifier against the tree,
with the `@/*` → `./*` path alias from `tsconfig.json`.

**`app/` → `db/`.** Exactly **four** files import `@/db`: `app/content-persistence.ts`,
`app/server.ts`, `app/api/upload/route.ts`, `app/api/media/[key]/route.ts`. All four use the raw
`D1Database` / `R2Bucket` handles.

**`app/` → `components/ui/`.** Eleven components, from ten `app/` files. Full edge list:

```
alert-dialog  <- app/edit/editor.tsx
carousel      <- app/achievements.tsx, app/updates.tsx, app/use-section-carousel.ts
collapsible   <- app/publications.tsx, app/research-section.tsx, app/scene.tsx
dialog        <- app/achievements.tsx
progress      <- app/edit/upload-field.tsx
radio-group   <- app/edit/editor.tsx
select        <- app/edit/editor.tsx, app/publications.tsx
slider        <- app/edit/editor.tsx
switch        <- app/edit/editor.tsx
tabs          <- app/edit/editor.tsx, app/scene.tsx
toggle        <- app/color-mode.tsx
```

**`app/` → `lib/`: zero edges.** `lib/utils.ts` is imported by **57 of the 61**
`components/ui/` files and by **no `app/` file at all**. It exists solely to serve the vendored
component library.

**`app/` → `hooks/`: zero edges.** `hooks/use-mobile.ts` is imported only by
`components/ui/sidebar.tsx`, which is itself never imported. Both are dead.

**`db/schema.ts` is not in the runtime graph.** This is the finding most likely to mislead a
reader. Reachability analysis from the ten Next.js entry points reaches **52 files**, and
`db/schema.ts` is not one of them. It is imported only by `drizzle.config.ts`, which exists to
run `drizzle-kit generate`. Grepping for `drizzle` across `app/` and `db/` returns **exactly one
hit**: the import on line 1 of `db/schema.ts`.

> **Correction carried from the scan.** So **drizzle-orm is not the runtime data layer.** Every
> query in this application is a hand-written SQL string passed to `db.prepare(...)` — 11 of
> them. Drizzle is a build-time schema-authoring and migration-generation tool only. Describing
> this system as "using an ORM" would be wrong, and describing work on it as "replacing the ORM"
> would misstate the work: there is no ORM in the request path to replace.

**Internal `app/` clusters.**

- *Schema cluster*: `content.ts` ← `site-copy.ts`, `research-identity.ts`, `scene-content.ts`.
  Imported by both server routes and the browser editor. **This is the module that straddles the
  boundary.**
- *Persistence cluster*: `content-persistence.ts` → `db/index.ts` + `content.ts`. `server.ts`
  re-exports `readContentState` as `readContent`, so route handlers and page components import
  persistence *through* `server.ts`.
- *Editor cluster*: `editor.tsx` → `editor-workflow.ts` → `content.ts`; `editor.tsx` →
  `upload-field.tsx` → `image-processing.ts`.
- *Public-site cluster*: `site.tsx` → `achievements`, `publications`, `research-section`,
  `updates`, `scene`, `responsive-image`, `color-mode`.

**External packages imported outside `components/ui/`** — **10 only**: `react`, `next`, `zod`,
`three`, `lucide-react`, `next-themes`, `clsx`, `tailwind-merge`, `cloudflare:workers`,
`drizzle-orm`. Everything else in `dependencies` is reached only through vendored UI components,
or not at all (`dependencies.md`).

## Boundaries the code already separates along

Ranked by how cleanly the code already separates. Recorded as observed structure, not as a plan.

1. **`db/index.ts` (3 lines) — the cleanest boundary in the repository.** Two functions
   returning two bindings. Every storage access in the application passes through them. The
   callers, however, use D1-specific APIs (`.prepare/.bind/.first/.all/.batch`) and R2-specific
   ones (`.head/.get/.put/.delete`, `httpEtag`, `range`) directly, so the abstraction stops at
   the handle.

2. **`app/content.ts` — schema versus seed.** The file holds two independent things: the
   validation schema (lines 1–24) and the `initialContent` seed data (lines 25–66). The seed is
   pure data and is serialisable as-is; the schema is behaviour, including `.transform()` and
   `.default()` rules that carry content (`architecture.md`, `code-quality-assessment.md`).

3. **`app/server.ts` (16 lines) — the authorization boundary.** `isEditor` is the only
   authorisation predicate and has exactly seven call sites (listed in `architecture.md`).
   Authentication (`chatgpt-auth.ts`) sits behind it and is independent of `isEditor`'s shape.

4. **`app/content-persistence.ts` — the transactional boundary.** All content SQL is in one
   58-line file, and `contentWriteStatements()` is deliberately factored as a **pure function
   returning statements**, separately from `writeContent()` which executes them. That factoring
   is the single best thing about this codebase's structure — it makes the transaction
   inspectable. It is also the riskiest piece to re-express; see `code-quality-assessment.md` →
   *The seven-statement D1 batch*.

5. **The four route handlers — the HTTP boundary.** **131 lines total.** Each is self-contained:
   guard, validate, act, respond. No shared middleware, no framework plumbing to unwind.

6. **`app/image-processing.ts` — a boundary that currently runs on the browser side.** The
   browser generates WebP variants and the Worker then re-verifies them
   (`app/api/upload/route.ts:26-47`). That verification burden exists *only* because the work
   happens client-side.

**Boundaries that do not exist in this codebase:**

- **No service layer.** Route handlers call persistence functions directly. There is no place
  where "business rules" live apart from HTTP and SQL.
- **No repository interface.** `content-persistence.ts` is simultaneously the domain operations
  and the SQL.
- **No shared error type.** Each route hand-writes its own `{error: '...'}` literals.
- **`app/content.ts` deliberately straddles the client/server line.** Splitting it is the point
  at which client and server validation could silently diverge.
- **`app/edit/editor.tsx` is one 34.5 KB file** holding all ten tabs and seven components. There
  is no per-tab seam inside it.

## Sources

- `aidlc/spaces/default/intents/260924-chiku-website-migration/inception/reverse-engineering/developer-scan.md`
  § `code-structure` (authoritative for this file), with the dense-style caution from
  § `code-quality-assessment`.
- Measurements: `find` over the tree with the generated directories excluded; per-file line,
  byte and maximum-line-length counts over the 38 `app/` `.ts`/`.tsx` files; a full import graph
  built by the scan's `graph.mjs` / `reach.mjs` scripts (paths recorded in
  `reverse-engineering-timestamp.md`).
