# Dependencies — `madhavi-tripathi/`

**System documented:** the application source tree at `madhavi-tripathi/` inside the workspace
`/Users/praka/Workspace/Projects/Chiku_website`.
**Commit:** `50856de`. **Scan time:** 2026-09-24T14:48:17Z. Depth, exclusions and limits:
`reverse-engineering-timestamp.md`.

**What this file is.** The declared dependency surface of the project, with a measured
reachability verdict for every production package, plus the licence obligations and maintenance
facts that travel with them. Every "imported by" value was produced by **resolving import
specifiers across the tree**, not by inspection. It records what **is**; it recommends no
changes.

**Context a reader needs and will not find elsewhere in this file.** "Reachable" always means
reachable by following imports from the ten Next.js entry points (`app/page.tsx`,
`app/layout.tsx`, `app/robots.ts`, `app/sitemap.ts`, `app/edit/page.tsx`,
`app/edit/preview/page.tsx`, and the four `app/api/*/route.ts` files). `components/ui/` holds
61 vendored shadcn files of which only **12** are reachable, which is why so many packages below
are "unreachable from `app/`" — they exist to support components nothing imports
(`component-inventory.md`).

`.claude/` and `aidlc/` are framework, not application code, and are excluded. `chiku-website/`
does not exist.

---

`madhavi-tripathi/package.json` declares **26 production** and **19 dev** dependencies.

## Production dependencies — all 26

| Package | Pinned | Imported by | Status |
|---|---|---|---|
| `@base-ui/react` | `^1.7.0` | 1 `components/ui` file | Unreachable from `app/` |
| `@fontsource-variable/inter` | `^5.3.0` | **nothing** | **Unimported** — the font is self-hosted from `public/fonts/` |
| `@hookform/resolvers` | `^5.7.1` | **nothing** | **Unimported** — zero occurrences in the tree |
| `@shadcn/react` | `^0.3.0` | 1 `components/ui` file | Unreachable from `app/` |
| `class-variance-authority` | `0.7.1` | 16 `components/ui` files | Used (transitively) |
| `clsx` | `2.1.1` | `lib/utils.ts` | Used (transitively) |
| `cmdk` | `^1.1.1` | `components/ui/command.tsx` | Unreachable from `app/` |
| `date-fns` | `^4.4.0` | **nothing** | **Unimported** — zero occurrences |
| `drizzle-orm` | `0.45.2` | `db/schema.ts` only | **Build-time only**, not in the runtime graph |
| `embla-carousel-react` | `^8.6.0` | `components/ui/carousel.tsx` | **Used** — carousel is reachable |
| `input-otp` | `^1.4.2` | `components/ui/input-otp.tsx` | Unreachable from `app/` |
| `lucide-react` | `^1.31.0` | 33 files (10 in `app/`) | **Used directly** |
| `next` | `16.3.4` | 6 files (`chatgpt-auth`, `layout`, `robots`, `site-metadata`, `sitemap`, `next.config`) | **Used directly** |
| `next-themes` | `^0.4.6` | `app/color-mode.tsx` + 1 ui file | **Used directly** |
| `radix-ui` | `^1.6.7` | 37 `components/ui` files | Used (transitively) |
| `react` | `19.2.6` | 66 files (14 in `app/`) | **Used directly** |
| `react-day-picker` | `^10.0.1` | `components/ui/calendar.tsx` | Unreachable from `app/` |
| `react-dom` | `19.2.6` | (framework) | **Used** |
| `react-hook-form` | `^7.85.0` | `components/ui/form.tsx` | Unreachable from `app/` |
| `react-resizable-panels` | `^4.12.2` | `components/ui/resizable.tsx` | Unreachable from `app/` |
| `recharts` | `^3.8.0` | `components/ui/chart.tsx` | Unreachable from `app/` |
| `sonner` | `^2.0.8` | `components/ui/sonner.tsx` | Unreachable from `app/` |
| `tailwind-merge` | `3.6.0` | `lib/utils.ts` | Used (transitively) |
| `three` | `^0.186.0` | `app/nano-renderer.ts` | **Used directly** |
| `vaul` | `^1.1.2` | `components/ui/drawer.tsx` | Unreachable from `app/` |
| `zod` | `^3.25.76` | `app/content.ts`, `app/site-copy.ts` | **Used directly — the schema** |

**Summary of the 26.**

- **7** are imported directly by `app/` code: `lucide-react`, `next`, `next-themes`, `react`,
  `react-dom`, `three`, `zod`.
- **5** more are reachable transitively through the 12 live `components/ui` files:
  `class-variance-authority`, `clsx`, `radix-ui`, `tailwind-merge`, `embla-carousel-react`.
- **1** is build-time only: `drizzle-orm`.
- **10** are reachable only through unused UI components: `@base-ui/react`, `@shadcn/react`,
  `cmdk`, `input-otp`, `react-day-picker`, `react-hook-form`, `react-resizable-panels`,
  `recharts`, `sonner`, `vaul`.
- **3** are imported nowhere at all: `@fontsource-variable/inter`, `@hookform/resolvers`,
  `date-fns`.

7 + 5 + 1 + 10 + 3 = **26**.

> **Correction carried from the scan.** The earlier inspection listed **11** unused production
> dependencies. The measured figure is **13** with no path from any entry point (the 10 + the 3),
> of which 3 have no import anywhere in the tree. The two additions beyond the earlier list are
> **`@fontsource-variable/inter`** and **`@base-ui/react`**. `drizzle-orm` is **excluded** from
> that 13 because it *does* have a path — a build-time one.
>
> That is **13 of 26 — half the production dependency surface, and half the audit surface,
> carrying no function.**

> **Correction carried from the scan — no ORM in the request path.** `drizzle-orm` appears in
> `dependencies`, but `db/schema.ts` (its only importer) is not reachable from any entry point.
> Every query in the application is a hand-written SQL string passed to `D1Database.prepare()` —
> 11 of them. There is no ORM at runtime. See `architecture.md` and `code-structure.md`.

## Dev dependencies — all 19

| Package | Pinned | Purpose | Status |
|---|---|---|---|
| `@cloudflare/vite-plugin` | `1.37.1` | `vite.config.ts` | Cloudflare-specific |
| `@cloudflare/workers-types` | `4.20260515.1` | `tsconfig.json` `types` | Cloudflare-specific |
| `@tailwindcss/postcss` | `4.2.1` | `postcss.config.mjs` | Used |
| `@types/node` | `22.19.19` | Types | Used |
| `@types/react` | `19.2.14` | Types | Used |
| `@types/react-dom` | `19.2.3` | Types | Used |
| `@types/three` | `^0.186.0` | Types | Used |
| `@vitejs/plugin-react` | `6.0.2` | Vite React transform | vinext-specific |
| `@vitejs/plugin-rsc` | `0.5.26` | Vite RSC | vinext-specific |
| `drizzle-kit` | `0.31.10` | `drizzle.config.ts`, `pnpm db:generate` | Build-time |
| `eslint` | `9.39.4` | `pnpm lint` | Used |
| `eslint-config-next` | `16.3.4` | Flat config presets | Used |
| `react-server-dom-webpack` | `19.2.6` | RSC wire format | vinext-specific |
| `tailwindcss` | `4.2.1` | CSS framework | Used |
| `tw-animate-css` | `^1.4.0` | `globals.css:2` | Used |
| `typescript` | `5.9.3` | Compiler | Used |
| `vinext` | `1.0.0-beta.5` | Runtime | Platform-specific |
| `vite` | `8.0.13` | Bundler | Platform-specific |
| `wrangler` | `4.92.0` | Local Workers dev | Cloudflare-specific |

Plus `overrides: {miniflare: {sharp: "0.35.4"}}` — a transitive pin for the local emulator.

## Licence obligations

All licences found in the tree are **MIT**, which requires the copyright notice and permission
text be preserved in redistributions. Two are **vendored into the source tree** rather than
installed, so the obligation travels with the files themselves and is easy to lose in a
copy-forward:

| Vendored artefact | Notice file | Copyright |
|---|---|---|
| `build/sites-vite-plugin.ts` (from `@openai/sites-vite-plugin` 0.2.0, openai/sites#9) | `build/sites-vite-plugin.LICENSE` | MIT, © 2026 OpenAI |
| `vendor/shadcn-tailwind-4.13.0.css` | `vendor/shadcn-tailwind-4.13.0.LICENSE.md` | MIT, © 2023 shadcn |

The **61 `components/ui/*.tsx` files are also vendored shadcn source** (registry 4.17.0), as
`eslint.config.mjs` states explicitly when it disables three lint rules for them. They carry **no
per-file licence header**; the `vendor/` notice is what covers them.

> **Obligation if components are carried forward.** If any of the 12 live `components/ui` files
> moves into another codebase, the shadcn MIT notice must move with it. Dropping `vendor/` while
> keeping `components/ui/` would strip the notice from code it covers. The OpenAI notice can be
> dropped only together with `build/sites-vite-plugin.ts`.

> **Stated limit.** No full transitive licence audit of `node_modules/` was performed — that is
> outside a source scan. Licence findings cover **only what is present in the source tree**. This
> is limit 5 of the seven recorded in `reverse-engineering-timestamp.md`.

## Maintenance concerns

1. **`vinext@1.0.0-beta.5` — a pre-release runtime.** The entire application executes through it.
   Beta versioning means no stability guarantee, and it is the **least substitutable dependency
   in the tree**.
2. **`zod@3.25.76` — a transition release.** The 3.25.x line ships both the v3 API (at the
   package root) and the v4 API (at `zod/v4`). `app/content.ts:1` imports from the **root** and
   therefore gets **v3** semantics; the scan verified this by resolving the entry point and
   enumerating `ZodIssueCode`. The codebase contains at least one place that assumes **v4**
   naming — see `code-quality-assessment.md` → finding A.
3. **Declared vs installed package manager.** `packageManager: pnpm@11.25.0`; the scanning host
   has **pnpm 10.30.3**. Not an error, but any exact-reproduction step will hit it.
4. **`pnpm-workspace.yaml` sets `minimumReleaseAge: 10080`** (7 days) plus `trustLockfile: false`
   and `strictDepBuilds: true`. **A fresh install refuses packages published in the last week** —
   worth knowing before anyone debugs a "missing version".
5. **Caret ranges on 19 of 26 production dependencies**, with exact pins on the remaining 7
   (`class-variance-authority`, `clsx`, `drizzle-orm`, `next`, `react`, `react-dom`,
   `tailwind-merge`). The mixture means **`pnpm-lock.yaml` (344 KB) is the only complete record
   of what actually resolves** — and the lockfile was **not parsed** by the scan; declared
   versions were read from `package.json`.
6. **10 production dependencies exist solely to support unused UI components**, and 3 more are
   imported nowhere. That is **13 of 26**.

## Sources

- `aidlc/spaces/default/intents/260924-chiku-website-migration/inception/reverse-engineering/developer-scan.md`
  § `dependencies` (authoritative for this file), with reachability facts from § `code-structure`
  and § `component-inventory`.
- `madhavi-tripathi/package.json`, `pnpm-workspace.yaml`, `eslint.config.mjs`,
  `build/sites-vite-plugin.LICENSE`, `vendor/shadcn-tailwind-4.13.0.LICENSE.md`.
- Measurement: import-specifier resolution across the whole tree (the scan's `graph.mjs` /
  `reach.mjs`), plus an empirical `ZodIssueCode` enumeration against the installed `zod@3.25.76`.
