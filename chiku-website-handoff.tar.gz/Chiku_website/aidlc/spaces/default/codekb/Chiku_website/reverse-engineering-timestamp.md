# Reverse-engineering timestamp and provenance — `madhavi-tripathi/`

**What this file is.** The provenance record for the other eight files in this knowledge base:
when the scan ran, against which commit, at what depth, what was deliberately excluded and why,
and exactly what the scan could **not** establish. Every claim in
`business-overview.md`, `architecture.md`, `code-structure.md`, `api-documentation.md`,
`component-inventory.md`, `technology-stack.md`, `dependencies.md` and
`code-quality-assessment.md` inherits the limits recorded here.

---

## When and against what

**Scan performed:** **2026-09-24T14:48:17Z** (UTC).

**Workspace:** `/Users/praka/Workspace/Projects/Chiku_website`

**Git:** the repository root is the workspace root; branch `main`; HEAD
**`50856def65ec53e843e2e47aff571c564402f9d0`** (`50856de`, *"Ideation closed: GO to Inception"*).
There are four commits, the earliest being `367b9c3` *"Baseline: AI-DLC workspace +
madhavi-tripathi reference tree"*. **158 files** under `madhavi-tripathi/` are tracked.

> **Correction carried from the scan.** The earlier discovery report recorded *"NOT a git
> repository"*. That was true when it was written; `git init` ran later in the same session.
> `git rev-parse --show-toplevel` now returns the workspace root. Recorded as a correction rather
> than silently using the new fact.

**Source provenance of the scanned application.** `madhavi-tripathi/SOURCE-MANIFEST.json` records
upstream commit **`161690d54eb79c3245419676006e08bf8755e5da`**, committed
**2026-09-23T17:10:42-05:00**, **155 source files**, each with a SHA-256 digest. It lists
`tsconfig.tsbuildinfo` as an omitted generated file, and `DESKTOP-START-HERE.md`,
`CHATGPT-DESKTOP-PROMPT.txt` and `SOURCE-MANIFEST.json` as archive-only additions.

> **The digests were not re-verified in this session** (a prior session did). This is limit 7
> below.

## What was scanned, and at what depth

All **157** non-generated files under `madhavi-tripathi/`:

| Area | Files | Depth |
|---|---|---|
| `app/` | 47 | **Every file read in full.** 22 `.ts`, 16 `.tsx`, 9 `.css` |
| `components/ui/` | 61 | Import graph resolved for all 61; `carousel.tsx` read for the known defect |
| `db/` | 2 | Both read in full |
| `drizzle/` | 5 | Both `.sql` migrations read in full; `meta/` inspected |
| `hooks/`, `lib/` | 2 | Both read; import graph resolved |
| `public/` | 6 | Enumerated and usage-traced |
| `scripts/` | 10 | Enumerated with line counts; **not read line-by-line** |
| `build/` | 2 | Plugin head read for the local-auth mechanism; licence read |
| `vendor/` | 2 | Line-counted; licence read |
| `docs/` | 1 | Read in full |
| root configs | 18 | `package.json`, `tsconfig.json`, `next.config.ts`, `vite.config.ts`, `eslint.config.mjs`, `postcss.config.mjs`, `components.json`, `drizzle.config.ts`, `.openai/hosting.json`, `pnpm-workspace.yaml`, `.npmrc`, `README.md`, `SOURCE-MANIFEST.json` read in full |

> **Recorded arithmetic gap, not corrected.** The rows above sum to **156** against a stated total
> of **157**. The most likely unplaced file is `.openai/hosting.json`, which the scan describes but
> does not assign to a directory row. The same gap appears in the directory table in
> `code-structure.md`.

> **Recorded inconsistency, not corrected.** The measurement list below states "all **39** `app/`
> `.ts`/`.tsx` files", while the directory breakdown gives `app/` as 22 `.ts` + 16 `.tsx` = **38**
> such files, and the per-file line tables in `code-structure.md` enumerate exactly **38** files
> totalling 1,819 lines. One of the two numbers is wrong; the file-level evidence favours 38.

## Measurements taken, not estimated

- Per-file **line, byte and maximum-line-length** counts across the `app/` `.ts`/`.tsx` files.
- A **full import graph**, built by resolving every `import` / `require` / dynamic-`import`
  specifier against the tree with the `@/*` → `./*` path alias from `tsconfig.json`.
- **Transitive reachability** from the ten Next.js entry points → **52 reachable files**.
- **`components/ui` usage census** → 11 app-imported, 12 transitively reachable, 49 unreachable.
- **Built chunk sizes** from the existing `dist/` output (nano-renderer = **560,248 bytes**).
- **Local Miniflare D1 contents** via `sqlite3`: 1 `site_content` row (revision 4, `published_at`
  NULL, both documents **15,423 bytes**), 6 `content_revisions`, 1 `editors`, 3 `assets`.
- An **empirical zod issue-code test** executed against the installed `zod@3.25.76`, confirming
  `invalid_format` is not a v3 code and that `invalid_enum_value` causes `parseRecovery` to discard
  a draft.
- **Confirmation by exhaustive search** that the tree contains **zero** test files and **zero**
  test-framework dependencies.

## What was deliberately excluded, and why

| Excluded | Reason |
|---|---|
| `.claude/`, `aidlc/` | AI-DLC framework shell and workflow record — **not application code**. Excluded from every count, inventory and assessment in this knowledge base |
| `chiku-website/` | **Does not exist.** Nothing to scan and nothing invented. It is described nowhere in these files |
| `node_modules/` | Installed dependencies. Consulted **only** to resolve `zod`'s entry point and enumerate its issue codes for finding A |
| `.next/`, `.vinext/` | Framework build output |
| `dist/` | Build output. **Partially used**: chunk file sizes were measured to quantify the known performance defect. **No source was read from it** |
| `.wrangler/` | Local Miniflare state. **Partially used**: the D1 SQLite file was queried for row counts and content size — facts about the emulator's contents, not about source |
| `.sites-runtime/` | pnpm store and local runtime scratch |
| `outputs/` | Generated output |
| `examples/` | An unrelated `d1` sample project bundled with the starter; also excluded by `tsconfig.json`'s `exclude` array |
| `madhavi-tripathi/.claude/` | Present but **empty** — contains no files |
| `pnpm-lock.yaml` | 344 KB resolution record. Declared versions were read from `package.json`; **the lockfile was not parsed** |

## Limits of this scan — stated plainly

These seven limits bound every claim in this knowledge base. They are reproduced as the scan
stated them; none has been resolved since.

1. **Nothing was executed.** No dev server, no build, no request. Every behavioural claim is
   derived from reading source, **except** the four measured items noted above (chunk sizes, D1
   contents, the zod issue-code test, the import graph).
2. **No hosted data was available.** The production D1 and R2 at
   `madhavi-tripathi.madhavi-tri16.chatgpt.site` are **not in this export**. The local emulator
   holds prior-session **test** data only. **Claims about production content volume cannot be
   made.**
3. **Runtime behaviour of the 3D scene, video playback, captions, touch interaction and the WebMCP
   tool was not observed** — only read. The README records that browser and WebMCP validation were
   unavailable in the originating session too.
4. **No accessibility audit was run.** The carousel defect is reported because it is visible in
   source; **absence of other findings is not evidence of their absence**.
5. **No transitive dependency licence audit** was performed over `node_modules/`. Licence findings
   cover only what is present in the source tree.
6. **The `invalid_format` finding is a proven mechanism, not an observed failure.** The issue-code
   mismatch was demonstrated empirically, but the editor could not be exercised to confirm a
   user-visible consequence. It is labelled **latent** throughout.
7. **`SOURCE-MANIFEST.json` digests were not re-verified** in this session.

## Scan artefacts

Intermediate scripts and data, retained in the scanning session's scratchpad (session-scoped; they
may not outlive that session):

- `/private/tmp/claude-501/-Users-praka-Workspace-Projects-Chiku-website/252bae3e-1f47-4da7-99d5-f5d725d19282/scratchpad/graph.mjs`
  — import extraction and `components/ui` census
- `.../scratchpad/reach.mjs` — entry-point reachability and external-package attribution
- `.../scratchpad/graph.json`, `.../scratchpad/deps.json` — resolved graph data
- `.../scratchpad/zodtest.mjs` — the zod issue-code experiment

## Chain of custody for this knowledge base

| Step | Output | Location |
|---|---|---|
| 1. Earlier inspection (superseded where it disagrees) | Discovery report | Session scratchpad, `discovery.md`, now carrying a CORRECTIONS section |
| 2. Deep scan (link 1 of the reverse-engineering stage) | `developer-scan.md`, 2,513 lines, nine sections | `aidlc/spaces/default/intents/260924-chiku-website-migration/inception/reverse-engineering/developer-scan.md` |
| 3. Synthesis (link 2 — this knowledge base) | The nine files named at the top of this document | `aidlc/spaces/default/codekb/Chiku_website/` |

**Where the earlier inspection and the scan disagree, the scan is authoritative.** The four
corrections the scan recorded are carried into the relevant files:

1. **`components/ui/` is 61 files, not 55** — 11 app-imported (1,131 lines), 12 reachable in total
   (1,195 lines), **49 unreachable (6,139 lines)**, i.e. 84% of the vendored library by line count
   is dead (`component-inventory.md`).
2. **13 unused production dependencies, not 11** — adding `@fontsource-variable/inter` and
   `@base-ui/react` (`dependencies.md`).
3. **drizzle-orm is not in the request path at all.** `db/schema.ts` is unreachable from every
   entry point; every query is a hand-written SQL string. **There is no ORM to replace**
   (`architecture.md`, `code-structure.md`, `technology-stack.md`, `dependencies.md`).
4. **The workspace is a git repository** as of this scan, HEAD `50856de` (recorded above).

## Sources

- `aidlc/spaces/default/intents/260924-chiku-website-migration/inception/reverse-engineering/developer-scan.md`
  § `reverse-engineering-timestamp` (authoritative for this file).
- `madhavi-tripathi/SOURCE-MANIFEST.json`, `README.md`, `tsconfig.json`, `package.json`.
- `git rev-parse` / `git log` against the workspace repository at scan time.
