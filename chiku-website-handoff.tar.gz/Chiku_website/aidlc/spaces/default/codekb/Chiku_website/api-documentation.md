# API documentation — `madhavi-tripathi/`

**System documented:** the application source tree at `madhavi-tripathi/` inside the workspace
`/Users/praka/Workspace/Projects/Chiku_website`.
**Commit:** `50856de`. **Scan time:** 2026-09-24T14:48:17Z. Depth, exclusions and limits:
`reverse-engineering-timestamp.md`.

**What this file is.** The complete observable contract of the four HTTP routes as they exist
today — every guard, every status code, every message string, every header — plus the full
content schema they validate against. It records what **is**; it specifies no target API. Where
a behaviour is easy to lose or get subtly wrong, it is marked as a **hazard**.

**Context a reader needs and will not find elsewhere in this file.** The application runs
entirely inside one Cloudflare Worker (vinext 1.0.0-beta.5 presenting Next.js 16.3.4 on the
Workers runtime). Storage is Cloudflare D1 (SQLite) for content, revisions, editors and asset
metadata, and Cloudflare R2 for media objects. Identity comes from four
`oai-authenticated-*` HTTP headers injected by the ChatGPT hosting platform — the application
authenticates no one itself. Full topology in `architecture.md`.

`.claude/` and `aidlc/` are framework, not application code. `chiku-website/` does not exist.

---

## Shared shape

Four route files, **131 lines total**, all `export const dynamic = 'force-dynamic'`.

Three shared guards:

- **`editorAccess()`** — `app/server.ts:15`. Resolves the platform-header identity and then
  checks the D1 `editors` table, bootstrapping from the hard-coded
  `OWNER_EMAIL = 'madhavi.tri16@gmail.com'` (`app/server.ts:5`). It is the **only**
  authorisation predicate in the codebase. Detail in `architecture.md`.
- **`sameOrigin(request)`** — `app/server.ts:16`:
  `const origin = request.headers.get('origin'); return !!origin && origin === new URL(request.url).origin;`
  A **missing** `Origin` header **fails** this check. Applied to `PUT /api/content` and
  `POST /api/upload` **only**. This is the **only CSRF defence** in the application; there is no
  token.
- **`reply(body, status)`** — `Response.json(body, {status, headers: {'Cache-Control': 'no-store'}})`,
  defined identically but **separately** in two files.

> **Recorded inconsistency, not corrected.** The scan gives the second definition's location as
> `app/api/history/route.ts:14` in its API section and as `app/api/history/route.ts:4` in its
> quality section, against a file that is 14 lines long. One of the two is wrong; the scan does
> not say which. The first definition is consistently given as `app/api/content/route.ts:5`.
> `/api/upload` and `/api/media` use neither helper, so **upload error responses carry no
> `Cache-Control: no-store`** (`code-quality-assessment.md` → error handling, weakness 4).

**Six endpoint/method pairs exist:** `GET /api/content`, `PUT /api/content`,
`GET /api/history`, `POST /api/upload`, `GET /api/media/[key]`, `HEAD /api/media/[key]`.
Same-origin is checked on **2 of the 6**.

---

## `GET /api/content`

**Auth:** editor required. **Same-origin:** not checked. **Request:** no body, no params.

| Status | Condition | Body |
|---|---|---|
| 200 | Editor | Full `ContentState` |
| 403 | `editorAccess()` false | `{error: 'Please sign in with the website owner's account.'}` |
| 503 | Any thrown exception | `{error: 'Unable to load your draft. Please try again.'}` |

200 body shape (`app/content-persistence.ts:5-6`):

```ts
{ draft: Content, published: Content, revision: number,
  updatedAt: string|null, publishedAt: string|null, hasUnpublishedChanges: boolean }
```

`hasUnpublishedChanges` is **computed, not stored**:
`JSON.stringify(draft) !== JSON.stringify(published)` (`app/content-persistence.ts:16`).

When **no row exists**, `readContentState()` synthesises
`{draft: initialContent, published: initialContent, revision: 0, updatedAt: null, publishedAt: null, hasUnpublishedChanges: false}`
**without writing anything** (`app/content-persistence.ts:20`).

> **Hazard — 503 causes include a zod failure**, because `normalizeStoredContent`
> (`app/content-persistence.ts:10`) parses **both** stored columns on **every read**. A stored
> document that no longer satisfies the schema produces **503, not 200-with-warnings** — and it
> does so on `/`, on this route and on every `/api/media/*` request simultaneously, because all
> three go through `readContent()`.

---

## `PUT /api/content`

**Auth:** editor required. **Same-origin:** required. **Content-Type:** **not checked** — the
body is parsed as JSON regardless of what the client declares.

Request body:

```ts
{ content: Content,            // validated by contentSchema
  revision: number,            // the revision the editor loaded
  action: 'draft' | 'publish',
  autosave?: boolean }         // optional; only legal when action === 'draft'
```

Checks run **strictly in this order** — the order determines which status code a
multiply-invalid request receives:

| # | Line | Check | On failure |
|---|---|---|---|
| 1 | `:9` | `sameOrigin(request)` | **403** `'This request could not be verified. Refresh and try again.'` |
| 2 | `:10` | `editorAccess()` | **403** `'Please sign in with the website owner's account.'` |
| 3 | `:11` | `bodyText.length > 1500000` | **413** `'This update is too large.'` |
| 4 | `:12` | `JSON.parse` throws | **400** `'The update could not be read.'` |
| 5 | `:13` | Body falsy, non-object, or an array | **400** `'Invalid save request.'` |
| 6 | `:14-15` | `contentSchema.safeParse(body.content)` | **400** `'Please check the highlighted fields before saving.'` + `issues[]` |
| 7 | `:16` | Envelope validation (below) | **400** `'Invalid save request.'` |
| 8 | `:17-18` | `writeContent()` returns `null` | **409** conflict + latest metadata |
| — | `:19` | Success | **200** |
| — | `:20` | Any throw | **503** `'Your changes could not be saved...'` |

Step 7 rejects unless **all** hold (a single expression at line 16):
`Number.isSafeInteger(body.revision)` · `body.revision >= 0` ·
`body.revision < Number.MAX_SAFE_INTEGER` · `body.action` is `'draft'` or `'publish'` ·
`body.autosave` is `undefined` or boolean · not (`autosave === true` && `action !== 'draft'`).

> **Hazard — step ordering.** Content validation (6) runs **before** envelope validation (7). A
> request with both a malformed `content` and a bad `revision` returns the *content* 400 with
> `issues[]`, not the envelope 400. Reordering these silently changes the error the editor
> displays.

> **Hazard — the 413 cap counts characters, not bytes.** `request.text()` returns a JavaScript
> string; `.length` counts **UTF-16 code units**. The cap is **1,500,000 characters**. A
> document of 1.5 M non-ASCII characters can be **3–4 MB of UTF-8**, and an implementation that
> caps at 1,500,000 *bytes* would reject documents this one accepts. Note also that the full
> body is read into memory at line 11 **before** the check, so the cap limits document size, not
> memory use.

**200 body:** `{...ContentMetadata, published: boolean}` — that is `revision`, `updatedAt`,
`publishedAt`, `hasUnpublishedChanges`, plus `published: body.action === 'publish'`.

**409 body:**
`{error: 'This draft changed in another tab. Your edits are still here. Review the latest saved draft before saving again.', revision, updatedAt, publishedAt, hasUnpublishedChanges}`
— the error string **plus the current server metadata**, fetched by a second read at line 18 so
the editor can show what it is now up against.

**The optimistic-concurrency path.** `writeContent()` returns `null` exactly when
`results[3]?.results?.[0]` is `undefined` — i.e. when the `UPDATE ... WHERE id = 1 AND
revision = ?` inside the seven-statement D1 batch matched no row.

> **Hazard — the write behind this route is the highest-risk behaviour in the system.** The
> batch carries **two** guards, not one: the `revision` CAS protects the content write, and a
> random `last_mutation` token stamped by the same statement protects the history insert and the
> two retention deletes against a stale writer whose `nextRevision` coincides with the winner's
> `revision` (a classic ABA defence). Losing the token reintroduces phantom history rows and
> wrongful pruning — timing-dependent and invisible in single-user testing. Also load-bearing:
> `results[3]` is a **hard-coded positional index with no comment**, so reordering the batch
> turns successful writes into spurious 409s. Full statement-by-statement analysis in
> `code-quality-assessment.md` → *The seven-statement D1 batch*.

> **Hazard — what the editor sends back.** On save the editor sends `validation.data`, the
> **transformed and defaulted** document, not the raw form state
> (`app/edit/editor-workflow.ts`, `save()` step 5). Combined with the `.transform()` on `item`
> (below), this means derived values get materialised into storage on the first save.

---

## `GET /api/history`

**Auth:** editor required. **Same-origin:** not checked.

Two modes, selected by the presence of `?id=`:

| Condition | Status | Body |
|---|---|---|
| `editorAccess()` false | 403 | `{error: 'Please sign in with the website owner's account.'}` |
| `id` param absent (`=== null`) | 200 | `{revisions: RevisionSummary[]}` |
| `id` empty, `> 100` chars, or fails `/^[a-zA-Z0-9-]+$/` | 400 | `{error: 'Choose a saved version from the history list.'}` |
| `id` valid, row found with content | 200 | `RevisionSummary & {content: Content}` |
| `id` valid, no row (or row has no content) | 404 | `{error: 'This version is no longer in the recent history. Your current draft is unchanged.'}` |
| Any throw | 503 | `{error: 'Version history is temporarily unavailable. Your current edits are safe.'}` |

Note the distinction at line 9: `id === null` (**absent**) means *list*. `?id=` (**present but
empty**) falls through to line 10 and is a **400**, not a list.

`RevisionSummary` = `{id, revision, action: 'draft'\|'publish', createdAt, baseline: boolean}`.

List query (`app/content-persistence.ts:52`):

```sql
SELECT id, revision, action, created_at, baseline
FROM content_revisions
ORDER BY revision DESC, baseline ASC, action DESC
LIMIT 52
```

The three-part sort is **load-bearing for display order**: newest revision first; within a
revision non-baselines before baselines; then `'publish'` before `'draft'` (descending string
order).

`baseline` is stored as a SQLite integer and coerced with `!!row.baseline`
(`app/content-persistence.ts:49`).

> **Note — the 52 is not a page size.** There is no pagination. Retention keeps at most **30
> drafts + 20 publishes + 2 baselines = 52**. The listing limit and the retention policy are the
> same number by construction, enforced by statements 5 and 6 of the write batch
> (`code-quality-assessment.md`).

---

## `POST /api/upload`

**Auth:** editor required. **Same-origin:** required. Both are checked in **one combined
condition at line 17**, so both failures yield the same 403.

Request: `multipart/form-data` with fields
`file` (required, `File`), `kind` (optional; `'captions'` selects the VTT path),
`variants` (0–2 `File`s), `optimized` (`'true'` to declare browser-prepared variants).

Accepted MIME → extension map (lines 6–9):
`image/jpeg`→`jpg`, `image/png`→`png`, `image/webp`→`webp`, `application/pdf`→`pdf`,
`video/mp4`→`mp4`, `video/webm`→`webm`, `text/vtt`→`vtt`.

Checks in order:

| # | Line | Check | On failure |
|---|---|---|---|
| 1 | `:17` | `sameOrigin` **and** `editorAccess` | **403** |
| 2 | `:18` | `request.signal.aborted` | **499** (via `checkCancelled`) |
| 3 | `:19` | `Number(content-length ?? 0) > 51 MB` | **413** |
| 4 | `:22` | `file` not a `File`, or `file.size === 0` | **400** `'Choose a non-empty file.'` |
| 5 | `:25` | `mime` not in the map, or captions-kind with non-VTT mime | **400** format message |
| 6 | `:28` | Variant envelope invalid (below) | **400** `'The prepared image sizes could not be verified...'` |
| 7 | `:31` | Sum of all file sizes > per-kind limit | **413** `` `Choose files totaling less than ${limit} MB.` `` |
| 8 | `:35` | A variant's type is not `image/webp` | **400** `'Prepared photo sizes must use WebP.'` |
| 9 | `:40-41` | Magic-byte validation fails | **400** format or VTT message |
| 10 | `:42` | `optimized` and any dimension > 1600 px | **400** `'Prepared photo sizes must be no larger than 1600 pixels.'` |
| 11 | `:43-47` | Variant larger than original, or aspect mismatch | **400** `'Prepared photo sizes must match the original framing.'` |
| — | `:62` | Success | **200** |
| — | `:71` | `AbortError` | **499** `'Upload cancelled. Your previous file is unchanged.'` |
| — | `:73` | Anything else | **503** `'Upload failed. Please try again; your form changes are safe.'` |

**Captions MIME coercion (line 24).** If `kind === 'captions'` **and** the filename ends `.vtt`
**and** `file.type` is empty or one of `text/vtt`, `text/plain`, `application/octet-stream`, the
mime is forced to `text/vtt`. Otherwise `file.type` is used as-is. This exists because browsers
rarely set `text/vtt`.

**Variant envelope (line 28)** rejects if: more than 2 variants · any variant is not a `File` or
is empty · variants present without `optimized === 'true'` · `optimized` true while the main
file's mime is not `image/webp`.

**Size caps (line 30):** `video/*` → 50 MB · `text/vtt` → 1 MB · everything else → 10 MB. The
cap at line 31 applies to the **sum** of the original and its variants, not per file.
`MB = 1024 * 1024` (line 5), so these are **mebibytes**.

> **Hazard — the 51 MB pre-check is advisory only.** Line 19 reads the `content-length` header;
> a request without one yields `Number(null || 0) === 0` and **passes**. The authoritative cap is
> the post-parse sum at line 31. Reproducing only the header check would leave the cap
> unenforced; reproducing only the sum check changes *when* the rejection happens (after
> buffering rather than before).

**How many bytes are read for validation (line 36).** For **images and VTT, the entire file** is
read into a `Uint8Array`. For **PDF, MP4 and WebM, only `entry.slice(0, 32)`**. This matters for
memory: a 10 MB image is fully buffered; a 50 MB video is not.

**Magic-byte dispatch (line 40)**, where `head` is the UTF-8 decode of the first 12 bytes:

| Type | Test |
|---|---|
| `image/*` | `imageDimensions(bytes, mime)` returns non-null |
| `text/vtt` | `validCaptions(bytes)` |
| `video/mp4` | `head.slice(4, 8) === 'ftyp'` |
| `video/webm` | `bytes[0..3] === 0x1a 0x45 0xdf 0xa3` (EBML) |
| `application/pdf` | `head.startsWith('%PDF-')` |

`imageDimensions` and `validCaptions` are hand-written parsers in `app/upload-validation.ts`;
they are simultaneously the dimension extractor and the format validator, and their exact
accept/reject behaviour — including **mixed endianness** (PNG and JPEG big-endian, **all** WebP
fields little-endian) and **JPEG storing height before width** — is documented in
`code-quality-assessment.md` → *The hand-written image header parsers* and *The WebVTT
validator*.

**Aspect-ratio tolerance (lines 45–46).** A variant is rejected if it is wider or taller than
the original, or if

```
|w_v/h_v − w_o/h_o| > 2 / min(h_v, h_o)
```

The tolerance **scales with the smaller height**, permitting the rounding error a downscale
introduces. This exact formula must be reproduced or legitimate variants start failing.

**Write sequence per entry (lines 51–60).** For each of the 1–3 files: generate
`` `${crypto.randomUUID()}.${ext}` ``, push to `written[]`,
`bucket().put(key, file, {httpMetadata: {contentType}})`, then
`INSERT INTO assets (key, filename, mime, size, created_at)` with the filename truncated to
**200 characters** (`entry.file.name.slice(0, 200)`). `checkCancelled()` runs between every
step. The extension is derived from the **validated MIME**, never from the user's filename.

**These are two separate non-transactional writes.** R2 and D1 have no shared transaction. A
failure between them leaves an orphan.

**Cleanup (lines 64–70).** On *any* exception, every key in `written[]` is deleted from both R2
and D1 under `Promise.allSettled`, so a partial failure does not leave orphans — *provided the
handler runs to the catch block*. It is explicitly documented as best-effort.

**200 body:**
`{url: '/api/media/<first-key>', filename: file.name, sources: [{src, width, height}, ...]}`
with `sources` sorted **ascending by width**, and **populated only when `optimized` is true**
(line 59). Non-optimised uploads return `sources: []`.

> **Hazard.** `sources` is empty for any upload the browser did not pre-process. Moving variant
> generation off the browser changes this response for **every** upload.

**Abort handling.** `request.signal.aborted` is checked at **seven** points (lines 18, 21, 37,
52, 56, 58, 61) and `AbortError` maps to **499**.

---

## `GET` and `HEAD /api/media/[key]`

Both methods are the **same function** (`app/api/media/[key]/route.ts:20-21`).

**Auth:** conditional — see *The public-access rule* below. **Same-origin:** not checked.

| # | Line | Check | On failure |
|---|---|---|---|
| 1 | `:6` | `key` matches `/^[a-f0-9-]+\.(jpg\|png\|webp\|pdf\|mp4\|webm\|vtt)$/` | **404** `'Not found'` |
| 2 | `:7-8` | Not public **and** not an editor | **404** `'Not found'` |
| 3 | `:9` | No `assets` row for `key` | **404** `'Not found'` |
| 4 | `:10` | `storage.head(key)` returns nothing | **404** `'Not found'` |
| 5 | `:12` | `method === 'HEAD'` | **200**, headers only, null body |
| 6 | `:15` | `parseByteRange(...) === 'invalid'` | **416** |
| 7 | `:16` | `storage.get` returns nothing | **404** |
| 8 | `:18` | Range present | **206** |
| 9 | `:18` | No range | **200** |
| — | `:19` | Any throw | **503** `'File temporarily unavailable'` |

Every denial is a **404, never a 403** — the route does not distinguish "no such asset" from
"not permitted", which avoids confirming the existence of unpublished media.

**Response headers (line 11), set for every success:**

```
Content-Type: <assets.mime>            (from D1, not from R2)
Cache-Control: private, no-cache
X-Content-Type-Options: nosniff
Content-Security-Policy: default-src 'none'; sandbox
Accept-Ranges: bytes
ETag: <R2 metadata.httpEtag>
Content-Length: <R2 metadata.size>
```

`Content-Type` comes from the **D1 `assets` row**, not from R2's stored metadata. Those are
written from the same value at upload time, so they agree today — but they are **two independent
stores**, and anything that syncs only one will serve mismatched types.

**HEAD behaviour.** Returns 200 with the *full* `Content-Length` and **never inspects `Range`**.
It therefore never returns 206 or 416, even when the equivalent GET would. This is a deliberate
early return at line 12, and it means HEAD and GET disagree about what they would return.

**Conditional-request support.** `If-Range` **is** honoured. `If-None-Match` is **not** — there
is **no 304 path at all**, so despite emitting an `ETag` the route always transfers the full
selected byte range. Combined with `Cache-Control: private, no-cache`, **every media request is
a full transfer through the Worker.**

**Byte-range handling (lines 13–17).**

```ts
const ifRange = request.headers.get('if-range');
const range = parseByteRange(
  !ifRange || ifRange === metadata.httpEtag ? request.headers.get('range') : null,
  metadata.size);
```

If `If-Range` is present and does **not** equal the ETag, the `Range` header is discarded and a
full 200 is served — correct RFC 9110 behaviour. Comparison is **exact string equality** against
R2's `httpEtag`.

On **416** (line 15) the route sets `Content-Range: bytes */<size>` and `Content-Length: 0` and
returns a null body — but **retains** all the headers from line 11, including the original
`Content-Length` before it is overwritten, and the `ETag`. Note the 416 response still carries
`Content-Type`.

On **206** (line 17): `Content-Range: bytes <offset>-<offset+length-1>/<size>` and
`Content-Length: <length>`.

**`parseByteRange(header, size)` — `app/media-utils.ts:15-21`.** Returns `null` (no range),
`'invalid'` (→ 416), or `{offset, length}`.

| Input | Result | Why |
|---|---|---|
| Header absent/empty | `null` | Line 16; full 200 |
| Fails `/^bytes=(\d*)-(\d*)$/` on the trimmed value | `'invalid'` | Line 17 |
| **Multi-range**, e.g. `bytes=0-1,5-6` | `'invalid'` → **416** | Fails the single-range regex |
| `bytes=-` (both groups empty) | `'invalid'` | Line 17 |
| `size` not a safe integer, or `size < 1` | `'invalid'` | Line 17 — **a 0-byte object + any Range is always 416** |
| `bytes=-N` (suffix) | `N` must be a safe integer `> 0`; `start = max(0, size − N)`, `end = size − 1` | Line 19. `N > size` yields the whole file as a **206** |
| `bytes=S-` | `end = size − 1` | Line 20 |
| `bytes=S-E` | Rejects `start >= size` or `end < start`; then `end = min(end, size − 1)` | Line 20 |

Returns `{offset: start, length: end − start + 1}`.

> **Hazard.** Four behaviours here deviate from what a naive reimplementation produces:
> multi-range → **416** (not 200 or multipart); zero-length object + Range → **416**; suffix
> range larger than the file → **206 for the whole file** (not 200); and `start >= size` → **416**
> while `end > size` is **silently clamped**. Each is a distinct branch that needs its own test.

**Video URL allowlist.** Separately from this route, `videoSource()`
(`app/media-utils.ts:2-13`) restricts embedded video to **YouTube and Vimeo only**, with an
11-character id regex — never an arbitrary iframe src.

---

## The public-access rule — `JSON.stringify(published).includes('/api/media/' + key)`

`app/api/media/[key]/route.ts:7`:

```ts
const {published} = await readContent();
const isPublic = JSON.stringify(published).includes(`/api/media/${key}`);
```

**What it means, plainly.** An asset is publicly readable **if and only if** the literal string
`/api/media/<key>` appears **anywhere** in the serialised published document. Not "is referenced
by the `photo` field" or "appears in a known image slot" — **anywhere at all, including inside
free prose**.

**What it costs, per request.** `readContent()` is `readContentState()`
(`app/content-persistence.ts:18`), which:

1. Runs `SELECT draft, published, revision, updated_at, published_at FROM site_content WHERE id = 1`
   — fetching **both** ~15 KB documents.
2. Calls `normalizeStoredContent` on **each**, i.e. `JSON.parse` + a full `contentSchema.parse`
   (with every refinement and transform) **twice**.
3. Computes `hasUnpublishedChanges` with two more `JSON.stringify` calls and a full string
   comparison (line 16) — a value **this route never uses**.
4. Then line 7 performs a **third** `JSON.stringify` of `published` and an O(n) substring scan.

That is **one D1 row read, two full schema validations and three serialisations of a 15 KB
document for every media byte served** — and because `Cache-Control` is `private, no-cache` with
no 304 path, nothing is cached. A page with N images costs N repetitions. A video streamed in
byte ranges repeats the whole thing for **every range request**.

**Failure modes.**

1. **Over-permission through prose.** Any field that can hold free text will make an asset public
   if the URL is typed into it — `transcript` (up to 60,000 chars), `description`, `bio`,
   `intro`, `notice`, any of the nine copy blocks. Pasting a draft-only image URL into a caption
   transcript publishes that image.
2. **Publication is indiscriminate.** Publishing makes public *every* asset URL anywhere in the
   document, including ones in fields that are not rendered — e.g. an item in a collection whose
   section is toggled off via `sections.*`. The visibility toggle hides the section from the
   page; it does **not** make its media private.
3. **No revocation and no cleanup.** Removing a reference makes the asset non-public again on the
   next request, but **neither the R2 object nor the `assets` row is ever deleted**. There is no
   orphan collection anywhere in the codebase. Storage grows monotonically.
4. **Total coupling of the media path to schema health.** Because the check calls
   `readContent()`, which parses stored content, a stored document that fails validation throws —
   caught at line 19 — and **every media request returns 503**, simultaneously with `/` and
   `/api/content`. **One bad document takes down images, the page and the editor.**
5. **Substring rather than structural matching.** The scan checked for prefix collisions and
   found **none**: the key regex forces a `.`-extension suffix, and a match requires
   `/api/media/` immediately followed by the full key, so `/api/media/0.webp` cannot match inside
   `/api/media/1230.webp`. JSON escaping is also not a problem — `JSON.stringify` does not escape
   `/`. The mechanism is not *wrong*, but it is positional-string-based rather than semantic, so
   it silently changes meaning if the URL format ever changes (e.g. adding a query string or a
   CDN prefix).
6. **Timing.** `isPublic` is evaluated **before** `editorAccess()` (line 8 short-circuits on
   `!isPublic`). So for public assets, **no authorisation lookup happens at all** — good. But for
   **every non-public asset request**, the full content read happens *and then* a D1 `editors`
   lookup.

> **Hazard — this is the second-highest-risk behaviour in the system, after the write batch.** A
> reimplementation that computes public-ness from structured fields only (`photo`, item `image`,
> `imageSources`) will make strictly **fewer** assets public than today, and images referenced
> from prose will 404 for visitors. A reimplementation that caches the published document changes
> failure mode 3's timing. **Both are behaviour changes, and both are silent.** Security
> consequences are analysed further in `code-quality-assessment.md` → *Security posture — the
> media path*.

---

## Content schema — every field and constraint

`app/content.ts`. This is the specification a reimplementation must match exactly. Note the
dense-style caution: the whole top-level schema is a **single 1,189-character line**, so every
constraint has been enumerated here precisely so nobody has to read that line again to get it
right.

> **Recorded inconsistency, not corrected.** The scan places `contentSchema` at
> `app/content.ts:20` and `sceneSchema` at `:21`, while also attributing to line 20 the comment
> about the retired legacy `autoTour` field that belongs with `sceneSchema`. Since `contentSchema`
> consumes `sceneSchema`, under eager evaluation that ordering cannot hold as stated, so one of
> the two line attributions is likely off by one. The *content* of both schemas below is
> unaffected; only the line numbers are in doubt.

**Shared building blocks (lines 5–9):**

| Name | Definition |
|---|---|
| `text` | `z.string().max(10000)` |
| `url` | `z.string().max(2000)` + refinement: passes if empty, **or** matches `/^https?:\/\/[^\s]+$/i`, **or** matches `/^\/api\/media\/[a-zA-Z0-9.-]+$/`. Message: `'Use a full https:// link.'` |
| `citationCount` | `z.string().trim().max(9)` + refinement `v === '' \|\| /^\d+$/.test(v)`. **`.default('')`**. Message: `'Use a whole, non-negative citation count, or leave it blank.'` |
| `citationDate` | `z.string().max(10)` + refinement: empty, **or** all three of `/^\d{4}-\d{2}-\d{2}$/`, `!Number.isNaN(Date.parse(v))`, and `new Date(v).toISOString().slice(0,10) === v`. **`.default('')`**. Message: `'Use a valid snapshot date.'` |
| `imageSourceSchema` | `{src: url, width: int 1..16000, height: int 1..16000}` |

> The `citationDate` round-trip check is the interesting one: it rejects `2026-02-30` (which
> `Date.parse` accepts and normalises to March 2) by requiring the ISO round-trip to be
> identical. Note `.trim()` is applied to `citationCount` but **not** to `citationDate`.

**`item` (lines 11–17)** — the shape shared by all five collections:

| Field | Constraint | Default |
|---|---|---|
| `id` | `z.string().max(100)` | — (required) |
| `title` | `z.string().trim().min(1, 'Add a title before saving.').max(1000)` | — (required, non-empty after trim) |
| `subtitle` | `text` (max 10000) | — |
| `description` | `text` | — |
| `year` | `z.string().max(40)` | — |
| `image` | `url` | — |
| `imageAlt` | `text` | — |
| `imageSources` | `z.array(imageSourceSchema).max(4)` | `[]` |
| `focalX` | `z.number().min(0).max(100)` | `50` |
| `focalY` | `z.number().min(0).max(100)` | `50` |
| `link`, `code`, `dataset`, `video` | `url` | — |
| `captions` | `url` | `''` |
| `transcript` | `z.string().max(60000)` | `''` |
| `featured` | `z.boolean()` | — (required) |
| `citations` | `citationCount` | `''` |
| `citationsAsOf` | `citationDate` | `''` |
| `researchTopic` | `z.enum(['materials','ultrasound','photoacoustic','general']).optional()` | — |
| `researchIds` | `z.array(z.string().max(100)).max(100).optional()` | — |
| `contribution`, `approach`, `outcome` | `text` | `''` |

**Then a `.transform()` on line 17** — this runs on *every* parse, **including reads from D1**:

```ts
.transform(row => ({...row,
  researchTopic: researchIdentity(row),
  researchIds: row.researchIds ?? initialResearchLinks.get(row.id) ?? []}))
```

> **Hazard — this transform carries content, not just types.** `researchIdentity`
> (`app/research-identity.ts:11-18`) maps three legacy card ids (`nano-materials`,
> `ultrasound-imaging`, `photoacoustics`) to their topic and otherwise returns `'general'`;
> `initialResearchLinks` (`app/site-copy.ts:37-43`) supplies the original theme links for five
> seeded publications. A model that declares the equivalent of `researchTopic: Optional[Topic] =
> None` and `researchIds: list[str] = []` is **type-correct and behaviourally wrong**: it yields
> `None` where the original yields `'general'`, and `[]` where the original yields the seeded
> links. The visible consequences are silent — identical slate research cards, 0 related papers
> per card, and a topic filter that returns nothing. Both use `??`, so an explicitly-cleared `[]`
> **must** be preserved; an `or`/falsy port resurrects links the owner deliberately deleted. Full
> analysis in `code-quality-assessment.md` → *The `researchIdentity` / `initialResearchLinks`
> back-compat shims*.

**Top-level `contentSchema` (line 20)** — 31 fields:

| Field | Constraint | Default |
|---|---|---|
| `name` | `z.string().trim().min(1).max(100)` | — (required) |
| `role`, `affiliation`, `location` | `z.string().max(200)` | — |
| `headline` | `z.string().max(240)` | — |
| `intro`, `bio` | `text` (max 10000) | — |
| `email` | `z.string().max(200)` + refinement empty or `/^[^\s@]+@[^\s@]+\.[^\s@]+$/`, message `'Enter a valid email.'` | — |
| `photo` | `url` | — |
| `photoAlt` | `text` | — |
| `photoSources` | `z.array(imageSourceSchema).max(4)` | `[]` |
| `photoFocalX` | `z.number().min(0).max(100)` | `50` |
| `photoFocalY` | `z.number().min(0).max(100)` | **`35`** (not 50 — deliberate for portraits) |
| `copy` | `copySchema` | `initialCopy` |
| `cv`, `scholar`, `orcid`, `github`, `linkedin` | `url` | — |
| `accent` | `z.enum(['blue','burgundy','forest'])` | — (required) |
| `motion` | `z.boolean()` | `true` |
| `scene` | `sceneSchema` | `initialScene` |
| `scholarHighlights` | object (below) | all-empty object with `visible: false` |
| `showNotice` | `z.boolean()` | — (required) |
| `notice` | `text` | — |
| `sections` | object of 6 booleans | `achievements` defaults `true`; the other five are **required** |
| `achievements` | `z.array(item).max(60)` | `[]` |
| `research` | `z.array(item).max(100)` | — (required) |
| `publications` | `z.array(item).max(500)` | — (required) |
| `journey` | `z.array(item).max(100)` | — (required) |
| `news` | `z.array(item).max(100)` | — (required) |

> **Note the asymmetry:** `achievements` has `.default([])` and `sections.achievements` has
> `.default(true)`; the other four collections and five toggles do not. That is a back-compat
> artefact of achievements being added later. A model that gives all five collections a default
> is **more permissive** than the original.

**`scholarHighlights` (line 18):**
`{visible: boolean, citations: max 20, hIndex: max 20, i10Index: max 20, asOf: max 100, affiliation: max 200, interests: max 1000}`,
all strings, no refinements. Default
`{visible: false, citations: '', hIndex: '', i10Index: '', asOf: '', affiliation: '', interests: ''}`.

**`sceneStory` (line 19):** `{title: max 150, description: max 600, link: url}`.

**`sceneSchema` (line 21):**
`{offerTour: boolean default true, initialView: z.enum(['delivery','photoacoustic','ultrasound']), delivery: sceneStory, photoacoustic: sceneStory, ultrasound: sceneStory}`.
A comment records that a legacy `autoTour` field was deliberately retired.

**`copySchema` (`app/site-copy.ts:22-32`):** nine groups, every field defaulted from
`initialCopy`, and the whole object `.default(initialCopy)`.

- `label(fallback)` = `z.string().trim().min(1, 'Add a label.').max(80).default(fallback)`
- `section(value)` = `{title: trim().min(1,'Add a heading.').max(200).default(value.title), description: max(1000).default(value.description), navigation: label(value.navigation)}`,
  itself `.default(value)`
- `hero`: `{researchAction: label, scholarAction: label, discover: label, topics: max(200).default}`
- `achievements`, `research`, `publications`, `journey`, `news`, `contact`: `section(...)`
- `scholar`: `{title: trim().min(1).max(200).default, profileAction: label}`
- `footer`: `{tagline: max(200).default}`

> **Hazard.** There are **25 leaf defaults** in `initialCopy`, of which **23 are non-empty**
> (`journey.description` and `news.description` default to `''`). Nearly every one is a
> *different* string. **These defaults are content, not boilerplate** — they are the site's
> actual wording. All 25 must be carried verbatim, and the nested `.default()` at **three
> levels** (field, group, whole object) means an absent `copy` key, an absent `copy.research`
> key and an absent `copy.research.title` key must each produce different but correct results.

## Sources

- `aidlc/spaces/default/intents/260924-chiku-website-migration/inception/reverse-engineering/developer-scan.md`
  § `api-documentation` (authoritative for this file), with hazard cross-references to
  § `code-quality-assessment` and § `architecture`.
- Source files cited inline: `madhavi-tripathi/app/api/content/route.ts`,
  `app/api/history/route.ts`, `app/api/upload/route.ts`, `app/api/media/[key]/route.ts`,
  `app/server.ts`, `app/content.ts`, `app/content-persistence.ts`, `app/media-utils.ts`,
  `app/upload-validation.ts`, `app/site-copy.ts`, `app/research-identity.ts`,
  `app/edit/editor-workflow.ts`.
