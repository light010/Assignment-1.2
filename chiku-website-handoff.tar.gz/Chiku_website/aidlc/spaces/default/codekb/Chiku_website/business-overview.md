# Business overview — `madhavi-tripathi/`

**System documented:** the application source tree at `madhavi-tripathi/` inside the workspace
`/Users/praka/Workspace/Projects/Chiku_website`.
**Commit:** `50856de` (`50856def65ec53e843e2e47aff571c564402f9d0`).
**Scan time:** 2026-09-24T14:48:17Z. Depth, exclusions and the seven stated limits of the scan
are recorded in `reverse-engineering-timestamp.md`.

**What this file is.** A record of what the product *is* today, in business terms: who uses it,
what it holds, and how a change reaches a reader. It contains no target design, no
recommendation and no migration instruction. Where the scan identified a risk, it is recorded
here as a hazard and analysed in `code-quality-assessment.md`.

**Scope boundaries that apply to every file in this knowledge base.** `.claude/` and `aidlc/`
are the AI-DLC framework shell and workflow record, not application code; they are excluded
from every inventory, count and assessment. `chiku-website/` **does not exist** and is not
described anywhere.

---

## What the product is

A single-person academic profile website with an owner-only, no-code editor bolted onto it.
One public page presents a researcher's profile, selected work and news to visitors; one
private page (`/edit`) lets exactly one person — the site owner — rewrite every word of that
page through forms, without touching code.

## The two audiences

| Audience | Reaches | Sees |
|---|---|---|
| Anonymous visitor | `/`, `/robots.txt`, `/sitemap.xml`, published media | The **published** document only |
| Site owner | `/edit`, `/edit/preview`, all four `/api/*` routes | Both the **draft** and the **published** document |

There is no third audience. There are no roles, no tiers, no editor-versus-publisher split and
no invite mechanism (see *Who may edit* below).

## The domain entities

The content model is **one document, not a set of tables**. Every entity below is a field or
sub-object of that single document, defined by the zod schema at `app/content.ts:20` and
serialised to roughly 15 KB — measured at **15,423 bytes** for the row in the local Miniflare
emulator database. That measurement is of prior-session *test* data in the local emulator; no
hosted production content was available to the scan (limit 2 in
`reverse-engineering-timestamp.md`).

1. **Profile** — the person. Name, role, affiliation, location, headline, intro, bio, email,
   portrait photo with alt text, responsive photo variants and a focal point.
2. **Research themes** — up to **100** items. The strands of work the researcher pursues. Each
   carries a *card identity* (`materials`, `ultrasound`, `photoacoustic`, `general`) that drives
   its colour and icon on the page. For the three originally-seeded cards this identity is
   **derived from the item id at parse time**, not stored — see the hazard note below.
3. **Publications** — up to **500** items. Papers, each optionally linked to one or more
   research themes, with a citation count and the date that count was taken.
4. **Journey milestones** — up to **100** items. The career timeline (degrees, posts, moves).
5. **News / notes** — up to **100** items. Short updates.
6. **Achievements / highlights** — up to **60** items. Awards and moments, shown as a gallery
   carousel directly below the cover, with optional photo or video and captions.
7. **Site copy** — **nine** editable blocks of the page's own wording (hero, each of the six
   sections, the Scholar panel, the footer tagline). The owner can rename "Publications" to
   anything, rewrite every section heading and description, and change every button label.
   There are **25 leaf defaults** behind these blocks, 23 of them non-empty; they are the
   site's actual wording, not boilerplate (`api-documentation.md` → *Content schema*).
8. **Appearance settings** — accent colour (`blue`, `burgundy`, `forest`), a motion on/off
   switch, six per-section visibility toggles, and an optional site-wide notice banner.
9. **3D scene story** — the animated cover. Three narrated views (delivery, photoacoustic,
   ultrasound) each with a title, description and link, plus which view opens first and whether
   a guided tour is offered.
10. **Scholar highlights** — an optional panel of hand-entered Google Scholar figures
    (citations, h-index, i10-index, "as of" date, affiliation, interests). It is explicitly a
    snapshot the owner types in, **not** a live sync (`docs/CONTENT-SOURCES.md`).

The five numbered collections (2–6) all share one **Item** shape, which is why the editor can
present them with the same form. Every field and constraint of that shape is enumerated in
`api-documentation.md` → *Content schema*.

> **Hazard — two of these entities carry content in a default, not in storage.** The card
> identity of the three seeded research themes and the theme links of the five seeded
> publications are produced by a `.transform()` that runs on **every parse**, including every
> read out of the database (`app/content.ts:17`). If that transform is lost, the research
> section renders every card in identical slate, every card reports 0 related papers, and the
> publications topic filter returns zero results for every theme — silently, with nothing
> logged. Full analysis in `code-quality-assessment.md` → *The `researchIdentity` /
> `initialResearchLinks` back-compat shims*.

## The draft/publish lifecycle

The heart of the product. **One database row holds two complete copies of the document:**

- **draft** — what the owner is working on. Private. Never shown to a visitor.
- **published** — what visitors see. Only changes when the owner explicitly publishes.

Every save is one of two actions. `draft` writes the draft column only. `publish` writes *both*
columns to the same value, so publishing is "make the draft the live page". There is **no
scheduling, no partial publish and no per-section publish**: the document is published whole or
not at all.

A **revision counter** on the row increments on every save of either kind — drafts as well as
publishes. The editor holds the revision it loaded and sends it back with each save; if it no
longer matches, the save is refused and the owner is told the draft changed elsewhere.

```mermaid
flowchart LR
  E["Owner types in the editor"] --> A["Autosave 1500 ms after typing stops, only if valid"]
  A --> D["draft column written, revision plus 1"]
  D --> PV["Preview at /edit/preview, owner only"]
  D --> PB["Owner presses Publish changes"]
  PB --> P["published column set equal to draft, published_at stamped"]
  P --> V["Next visitor request reads published fresh from the database"]
```

**Text fallback for the diagram.** The owner types in the editor. 1,500 ms after typing stops,
and only if the document validates, the editor autosaves: the `draft` column is written and the
revision counter increments by one. The draft can be previewed at `/edit/preview`, which is
owner-only. When the owner presses *Publish changes*, the `published` column is set equal to the
draft and `published_at` is stamped. The next visitor request reads the published document fresh
from the database — there is no cache and no delay.

**Propagation is immediate and uncached.** Every public page render is a fresh database read;
there is no ISR, no revalidation window and no CDN cache in front of the HTML. There is
therefore no "publish then wait" step and no cache to purge. Architectural detail in
`architecture.md`.

## The editorial workflow as the owner experiences it

1. Sign in, open the site, choose *Edit website* in the footer.
2. Work through **ten tabs**: Profile, Highlights, Research, Publications, Journey,
   Notes & news, 3D story, Scholar, Website text, Appearance.
3. **Valid** changes save themselves as a draft **1.5 seconds** after typing stops. Invalid ones
   do not — the offending fields are listed and the owner is told to fix them.
4. *Preview draft* renders the draft exactly as visitors would see it, without publishing.
5. *Publish changes* makes the draft live.
6. **Revision history** offers the last **52** saved versions and can restore any of them as a
   draft. Restoring never publishes. The very first save also captures a permanent "starting
   draft" and "starting published" pair that is never pruned. The 52 is not a page size — there
   is no pagination; retention keeps 30 drafts + 20 publishes + 2 baselines = 52, so the listing
   limit and the retention policy are the same number by construction.
7. If the browser dies mid-edit, unsaved work is offered back on the next visit ("Recover an
   editing session?"), per tab.

> **Hazard — draft recovery silently discards on one class of error.** The recovery path keeps a
> draft whose only faults are empty/over-long/refinement failures, but discards the **entire**
> recovered draft when a field holds an out-of-range enum value. Full analysis in
> `code-quality-assessment.md` → finding A.

## Who may edit

Exactly one person. Authorisation is a row in an `editors` table, bootstrapped by a **single
hard-coded owner email address in source** (`app/server.ts:5`,
`OWNER_EMAIL = 'madhavi.tri16@gmail.com'`). There are no roles, no permission levels and no
invite flow. `isEditor` is the only authorisation predicate in the codebase and it gates every
privileged path — seven call sites, listed in `architecture.md`.

> **Hazard — the application authenticates no one.** Identity is taken entirely from four HTTP
> headers injected by the ChatGPT hosting platform. There is no signature check, no token
> validation, no session cookie and no expiry anywhere in this codebase. See `architecture.md`
> → *Where authentication is decided*.

## Media and access

Uploaded media (images, PDFs, video, WebVTT captions) is stored outside the document and served
through `/api/media/<key>`. **An asset is publicly readable if and only if the literal string
`/api/media/<key>` appears anywhere in the serialised published document** — including inside
free prose such as a caption transcript, the bio, the notice banner or any of the nine copy
blocks. That makes every free-text field an access-control surface: pasting a draft-only image
URL into a transcript publishes that image. Publishing is indiscriminate — it makes public every
asset URL anywhere in the document, including in sections the owner has toggled off. Removing a
reference makes the asset non-public again on the next request, but **nothing is ever deleted**:
neither the stored object nor its database row, and there is no orphan collection anywhere in
the codebase, so storage grows monotonically. Full analysis in `api-documentation.md` → *The
public-access rule* and `code-quality-assessment.md`.

## Content provenance

The seed content is **real, sourced data about a named individual**, with every claim traced to
a citation in `docs/CONTENT-SOURCES.md`. The README states that missing facts were deliberately
left blank rather than invented. Any change that "fills in" empty fields would violate a stated
product rule.

The seed lives in source as `initialContent` (`app/content.ts`, lines 25–66 of that file).
`docs/DESKTOP-START-HERE.md` establishes `initialContent` as the canonical starting content.
Seed volumes: 3 achievements, 3 research themes, 5 publications, 4 journey entries, 4 news
items.

## An in-product agent capability

When the browser exposes **WebMCP**, the editor registers a `stage_academic_profile` tool on
`document.modelContext` (`app/edit/editor.tsx`, the `useEffect` at line 81) that lets an
assistant fill **six** profile string fields (`name`, `role`, `affiliation`, `headline`,
`intro`, `bio`) into the form. It stages only; it never saves and never publishes, and it
returns `published: false` literally. It has no privileged access — it manipulates React state
in a page the owner is already authenticated on.

One indirect effect is worth recording at the product level: because staging marks the document
dirty, the **1.5 s autosave timer arms**, so a staged change *will* be written to the server as
a draft 1.5 s later without further human action, provided the document validates and no
blocker is active. Nothing is published. Full detail in `code-quality-assessment.md` → *The
WebMCP `stage_academic_profile` tool*.

## Where the rest of this knowledge base is

| File | Covers |
|---|---|
| `architecture.md` | Runtime topology, request path, where auth/authz/validation are decided, the draft/published split |
| `code-structure.md` | Directory layout, file inventory, import graph, module responsibilities, existing seams |
| `api-documentation.md` | All four HTTP routes with every status code, and the full content schema |
| `component-inventory.md` | React components, the vendored UI library census, CSS and static assets |
| `technology-stack.md` | Every technology and version, and what each is used for |
| `dependencies.md` | The 26 production and 19 dev dependencies, licence obligations, maintenance concerns |
| `code-quality-assessment.md` | Hazards, defects, the concurrency batch, parsers, state machine, and what is good |
| `reverse-engineering-timestamp.md` | When, at what commit, at what depth, with what exclusions and what limits |

## Sources

- `aidlc/spaces/default/intents/260924-chiku-website-migration/inception/reverse-engineering/developer-scan.md`
  § `business-overview` (authoritative for this file), with cross-referenced facts from
  § `architecture`, § `api-documentation` and § `code-quality-assessment`.
- Source files cited inline: `madhavi-tripathi/app/content.ts`, `app/server.ts`,
  `app/edit/editor.tsx`, `app/api/media/[key]/route.ts`, `docs/CONTENT-SOURCES.md`,
  `docs/DESKTOP-START-HERE.md`, `README.md`.
- Measurement of the 15,423-byte document and the revision-4 row: local Miniflare D1 database,
  queried with `sqlite3` during the scan.
