# Technology stack — `madhavi-tripathi/`

**System documented:** the application source tree at `madhavi-tripathi/` inside the workspace
`/Users/praka/Workspace/Projects/Chiku_website`.
**Commit:** `50856de`. **Scan time:** 2026-09-24T14:48:17Z. Depth, exclusions and limits:
`reverse-engineering-timestamp.md`.

**What this file is.** Every technology present in the running system, its pinned version, and
what it is actually used for. Versions are the values declared in
`madhavi-tripathi/package.json`; "used for" statements were produced by resolving import
specifiers across the tree, not by inspection.

**What this file deliberately omits.** The scan's § `technology-stack` carried a *Disposition*
column recording already-settled decisions about what each item would be replaced by. That
column is **not reproduced here**, because this knowledge base documents what the system **is**;
target-technology choices are decisions that live in the intent record, not findings about the
existing code. In its place, the tables below carry a **Coupling** column, which is a fact about
the current system: whether an item is tied to the Cloudflare / OpenAI-Sites / vinext hosting
platform or is platform-neutral.

`.claude/` and `aidlc/` are framework, not application code, and are excluded. `chiku-website/`
does not exist.

---

## Runtime platform

Everything runs in **one Cloudflare Worker**. There is no separate application server and no
container. Full topology in `architecture.md`.

| Technology | Version | Used for | Coupling |
|---|---|---|---|
| **Cloudflare Workers** | runtime | The entire application process | Platform |
| **`vinext`** | `1.0.0-beta.5` | Vite-based Next.js-compatible runtime for Workers — a **pre-release** runtime shim | Platform |
| **Cloudflare D1** | via `env.DB` | `site_content`, `content_revisions`, `editors`, `assets` | Platform |
| **Cloudflare R2** | via `env.BUCKET` | Uploaded media objects | Platform |
| **ChatGPT platform auth** | headers | The *only* identity source (`oai-authenticated-*`); sign-in/out/callback routes are **not** in this repository | Platform |
| **`wrangler`** | `4.92.0` | Local Miniflare dev server; `pnpm start` | Platform |
| **`@cloudflare/vite-plugin`** | `1.37.1` | Binds D1/R2 into the Vite dev server | Platform |
| **`@cloudflare/workers-types`** | `4.20260515.1` | `D1Database`, `R2Bucket` ambient types | Platform |
| **`cloudflare:workers`** | built-in | `import { env }` in `db/index.ts:1` | Platform |
| **`.openai/hosting.json`** | — | Declares the logical `DB` / `BUCKET` binding names and `project_id` | Platform |
| **`build/sites-vite-plugin.ts`** | vendored 0.2.0 | Local auth-header mocking (`local_seedy` / `seedy@sites.test` via a `__sites_local_auth` cookie, localhost only); Sites build integration | Platform |
| **`scripts/*`** (10 files, 1,089 lines) | — | pnpm/npm installer shims, execution-profile detection, Sites env | Platform |
| **`cloudflare-env.d.ts`** | — | Ambient binding types | Platform |

## Application framework and UI

| Technology | Version | Used for | Coupling |
|---|---|---|---|
| **Next.js** | `16.3.4` | App Router, RSC, route handlers, metadata, sitemap/robots — but executed **through vinext on Workers**, not standard Next.js tooling | Neutral (runtime is platform-bound) |
| **React** / **React DOM** | `19.2.6` | All UI | Neutral |
| **TypeScript** | `5.9.3` | Whole codebase, `strict: true` | Neutral |
| **Tailwind CSS** | `4.2.1` | Utility classes, design tokens via `@theme inline` | Neutral |
| **`@tailwindcss/postcss`** | `4.2.1` | PostCSS integration (`postcss.config.mjs`) | Neutral |
| **`tw-animate-css`** | `^1.4.0` | Animation utilities; imported by `globals.css:2` | Neutral |
| **shadcn/ui** | vendored `4.17.0` | 61 components under `components/ui/` — **12 of 61 reachable** (`component-inventory.md`) | Neutral |
| **`radix-ui`** | `^1.6.7` | Primitives behind 37 `components/ui` files | Neutral |
| **`@base-ui/react`** | `^1.7.0` | Primitive for **1** `components/ui` file; reachability shows **no `app/` path to it** | Neutral |
| **`lucide-react`** | `^1.31.0` | Icons. 10 `app/` files + 23 `components/ui` files | Neutral |
| **`next-themes`** | `^0.4.6` | Light/dark switching (`app/color-mode.tsx`) | Neutral |
| **`embla-carousel-react`** | `^8.6.0` | Engine behind `components/ui/carousel.tsx`, which **is** reachable (achievements + updates) | Neutral |
| **`class-variance-authority`** | `0.7.1` | Variant props in 16 `components/ui` files | Neutral |
| **`clsx`** + **`tailwind-merge`** | `2.1.1` / `3.6.0` | `lib/utils.ts` `cn()` helper | Neutral |
| **`@fontsource-variable/inter`** | `^5.3.0` | **Nothing.** Declared but never imported; the font is self-hosted from `public/fonts/` via `globals.css:6` | Dead dependency |
| **three.js** | `^0.186.0` | `app/nano-renderer.ts` WebGL cover scene | Neutral |
| **`@types/three`** | `^0.186.0` | three.js types | Neutral |

The three.js renderer builds to a **560,248-byte** client chunk (547 KB uncompressed), above the
500 KB warning threshold — but it is loaded **dynamically and gated**, so it is never on the
critical path. Measurements and the gating logic are in `code-quality-assessment.md`.

## Validation and data

| Technology | Version | Used for | Coupling |
|---|---|---|---|
| **zod** | `^3.25.76` | `contentSchema` — **the** validation schema, executed client *and* server, and also the storage read path via `normalizeStoredContent` | Neutral |
| **drizzle-orm** | `0.45.2` | **Schema authoring only** (`db/schema.ts`). **Not in the runtime graph** | Build-time only |
| **drizzle-kit** | `0.31.10` | `pnpm db:generate` → `drizzle/*.sql` | Build-time only |

> **Correction carried from the scan — recording this precisely matters.** There is **no ORM at
> runtime**. `db/schema.ts` is reachable only from `drizzle.config.ts`; every query in the
> application is one of **11 hand-written SQL strings** passed to `D1Database.prepare()`. The
> phrase "replace the ORM" would misdescribe the work: what exists is (a) 11 SQL strings and
> (b) a schema-authoring tool. See `code-structure.md` and `architecture.md`.

> **Version note.** `zod` is recorded as `3.25.76` in the scan's technology table and as
> `^3.25.76` in its dependency table; the scan's own caret/pin census (7 exact pins, none of
> which is zod) implies the caret form, which is what is recorded above. The distinction matters
> only for reproducibility, not for behaviour.

> **zod 3.25.x is a transition release.** The 3.25.x line ships both the v3 API (at the package
> root) and the v4 API (at `zod/v4`). `app/content.ts:1` imports from the **root** and therefore
> gets **v3** semantics. The scan verified this empirically by resolving the entry point and
> enumerating `ZodIssueCode`. One place in the codebase assumes **v4** naming — see
> `code-quality-assessment.md` → finding A, *the `invalid_format` allowlist entry*.

## Build and quality tooling

| Technology | Version | Used for | Coupling |
|---|---|---|---|
| **Vite** | `8.0.13` | Bundler, via `vinext` | Platform |
| **`@vitejs/plugin-react`** | `6.0.2` | React transform | Platform |
| **`@vitejs/plugin-rsc`** | `0.5.26` | RSC support in Vite | Platform |
| **`react-server-dom-webpack`** | `19.2.6` | RSC wire format | Platform |
| **ESLint** | `9.39.4` | `pnpm lint`; flat config in `eslint.config.mjs` | Neutral |
| **`eslint-config-next`** | `16.3.4` | core-web-vitals + typescript rulesets | Neutral |
| **pnpm** | `11.25.0` **declared**; host has **10.30.3** | Package manager; `pnpm-workspace.yaml` sets a 7-day `minimumReleaseAge` (10080 minutes), `trustLockfile: false` and `strictDepBuilds: true` | Neutral |
| **Node.js** | `engines: >=22.13.0`; host runs **v24.13.0** | Build tooling | Neutral |

`eslint.config.mjs` applies the strict ruleset to `app/` and relaxes **three** rules only for
`components/ui/**` and `hooks/use-mobile.ts`, with a comment stating those are "vendored verbatim
from shadcn@4.17.0".

## Absent today — recorded as facts, not gaps to be filled here

| Concern | State |
|---|---|
| **Test framework** | **None.** Zero test files and zero testing dependencies in the entire tree — no vitest, jest, playwright or testing-library; no `test` script. See `code-quality-assessment.md` → *Testing — total absence* |
| **Formatter** | **None configured.** No `.prettierrc`, no Prettier dependency, no `format` script. The org rule defers to project configuration, and there is none |
| **CI configuration** | **None found.** No workflow files in the scanned tree |

The only automated quality gates that exist are `tsc` (`strict: true`) and `pnpm lint`. The
README records what was verified **by hand**: *"TypeScript, the production build, content
validation, and SQL save/publish/conflict checks passed"*.

## Platform coupling — summary

Counted from the tables above, treating the 10 `scripts/` files as one entry:

- **Platform-coupled (Cloudflare / OpenAI-Sites / vinext), 16 entries:** Cloudflare Workers,
  `vinext`, `wrangler`, `@cloudflare/vite-plugin`, `@cloudflare/workers-types`,
  `cloudflare:workers`, `.openai/hosting.json`, `build/sites-vite-plugin.ts`, the 10 `scripts/`
  files, `cloudflare-env.d.ts`, ChatGPT header auth, Vite, `@vitejs/plugin-react`,
  `@vitejs/plugin-rsc`, `react-server-dom-webpack`, `@fontsource-variable/inter` (also dead).
  Counting **Cloudflare D1 and Cloudflare R2** as two further platform entries — they appear in
  the scan's table but not in its own summary list — gives **18**.
- **Platform-neutral, 17 entries:** Next.js, React, React DOM, TypeScript, Tailwind,
  `@tailwindcss/postcss`, `tw-animate-css`, shadcn (12 of 61 files reachable), `radix-ui`,
  `lucide-react`, `next-themes`, `embla-carousel-react`, `class-variance-authority`, `clsx`,
  `tailwind-merge`, three.js, ESLint + `eslint-config-next`.
- **Build-time only, 2:** `drizzle-orm`, `drizzle-kit`.
- **Dead, 1:** `@fontsource-variable/inter`.
- **Absent, 3:** test framework, formatter, CI.

> **Recorded inconsistency, not corrected.** The scan's own summary states **"Retired ... 18
> items"** and then enumerates a list that comes to **16** under the counting above (D1 and R2
> appear in its table but not in its retired list, which would account for the difference). The
> scan's **"Survives, 17"** count reconciles exactly. Both numbers are recorded here rather than
> one being silently chosen.

## Sources

- `aidlc/spaces/default/intents/260924-chiku-website-migration/inception/reverse-engineering/developer-scan.md`
  § `technology-stack` (authoritative for this file, minus its *Disposition* column as explained
  above), with supporting facts from § `dependencies`, § `code-structure` and
  § `code-quality-assessment`.
- `madhavi-tripathi/package.json`, `pnpm-workspace.yaml`, `eslint.config.mjs`,
  `postcss.config.mjs`, `tsconfig.json`, `.openai/hosting.json`, `README.md`.
- Host tool versions (node v24.13.0, pnpm 10.30.3) were verified on the scanning host on
  2026-09-24.
