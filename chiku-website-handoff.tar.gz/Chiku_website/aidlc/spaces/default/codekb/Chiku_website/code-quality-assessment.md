# Code quality assessment — `madhavi-tripathi/`

**System documented:** the application source tree at `madhavi-tripathi/` inside the workspace
`/Users/praka/Workspace/Projects/Chiku_website`.
**Commit:** `50856de`. **Scan time:** 2026-09-24T14:48:17Z. Depth, exclusions and limits:
`reverse-engineering-timestamp.md`.

**What this file is.** An honest read of the codebase as it stands, separating "unusual but
deliberate" from "defective" and saying which is which with evidence. It records what **is**.
Every risk below is recorded as a **hazard** — a behaviour that is easy to lose or reproduce
incorrectly — not as a recommendation, and this file contains no target design and no
instructions for changing anything.

**Context a reader needs and will not find elsewhere in this file.** The application is a
single-owner academic profile site with a no-code editor, running entirely inside one Cloudflare
Worker (vinext 1.0.0-beta.5 presenting Next.js 16.3.4). Content is one ~15 KB JSON document held
in **two columns of one D1 row** — `draft` and `published`. Media lives in Cloudflare R2 with
metadata in a D1 `assets` table. Identity comes from platform-injected HTTP headers; the only
authorisation predicate is `isEditor` in `app/server.ts`. Full topology in `architecture.md`;
the HTTP contract in `api-documentation.md`.

`.claude/` and `aidlc/` are framework, not application code, and are excluded. `chiku-website/`
does not exist.

---

## Hazard index

The three highest-risk behaviours, then the runners-up. Each is analysed in full below.

| Rank | Hazard | Location | Where analysed |
|---|---|---|---|
| **1** | **`last_mutation` is an ABA defence, not redundancy.** Losing it produces phantom history rows and wrongful pruning — timing-dependent, invisible in single-user testing | `app/content-persistence.ts:28-40`, esp. `:36-38` | *The seven-statement D1 batch*; *Why `last_mutation` exists* |
| **2** | **The media access rule makes every free-text field an access-control surface**, and puts two full schema parses on the path of every media byte | `app/api/media/[key]/route.ts:7` | *The media access rule* |
| **3** | **`researchIdentity` / `initialResearchLinks` is a content-carrying default**, run on every parse including every read from the database | `app/content.ts:17`, `app/research-identity.ts:11-18`, `app/site-copy.ts:37-43` | *The back-compat shims* |
| R1 | **The `PUT /api/content` 413 cap counts UTF-16 characters, not bytes** — 1.5 M characters can be 3–4 MB of UTF-8 | `app/api/content/route.ts:11` | *Input validation coverage*, and `api-documentation.md` |
| R2 | **The image parsers mix endianness** (PNG/JPEG big-endian, **all** WebP fields little-endian) and **JPEG stores height before width** | `app/upload-validation.ts:5-43` | *The hand-written image header parsers* |
| R3 | **`parseRecovery`'s allowlist contains `invalid_format`, a zod v4 code that can never match under the installed v3**, while `invalid_enum_value` is absent — so a bad enum discards the whole recovered draft | `app/edit/editor-workflow.ts:20` | Finding A |
| R4 | **`results[3]` is a load-bearing positional index with no comment** — reordering the batch turns successful writes into spurious 409s | `app/content-persistence.ts:44` | Finding C |

Also load-bearing and easy to miss: the **PAUSED/CONFLICT distinction** in the editor state
machine, the **aspect-ratio tolerance formula** on uploads, the **byte-range parser's four
non-obvious branches** (`api-documentation.md`), and the **25 leaf copy defaults** which are
content rather than boilerplate (`api-documentation.md`).

---

## The dense single-line style — deliberate house style, not a defect

**The observation.** `app/` files report tiny line counts against substantial byte counts.
Measured, per file:

| File | Lines | Bytes | Longest line | Bytes/line |
|---|---|---|---|---|
| `app/edit/editor.tsx` | 99 | 34,555 | **3,969** | 349 |
| `app/content.ts` | 66 | 12,484 | **1,189** | 189 |
| `app/achievements.tsx` | 125 | 17,052 | 1,151 | 136 |
| `app/edit/draft-preview.tsx` | 12 | 2,861 | **1,574** | 238 |
| `app/publications.tsx` | 74 | 13,751 | 733 | 186 |
| `app/edit/upload-field.tsx` | 126 | 9,791 | 742 | 78 |
| `app/upload-validation.ts` | 68 | 3,895 | 202 | 57 |
| `app/chatgpt-auth.ts` | 90 | 2,550 | 79 | 28 |

`app/content.ts` holds the **entire** top-level schema — all **31** fields, with their
refinements, defaults and nested objects — on a **single 1,189-character line** (line 20).
`app/edit/editor.tsx` has a **3,969-character line**.

**Is it a defect or a house style?** It is a **deliberate, consistently applied house style**, on
this evidence:

1. **It is not uniform — it tracks authorship.** `app/chatgpt-auth.ts` (28 bytes/line, longest
   line 79) and `build/sites-vite-plugin.ts` are conventionally formatted with multi-line
   signatures and blank lines. Both are **vendored/platform-supplied** files. Every file written
   for *this* application is dense. A formatter or an accident would not respect that boundary.
2. **Within dense files, formatting is still deliberate.** `app/upload-validation.ts` and
   `app/api/upload/route.ts` use conventional 2-space multi-line formatting — they are the files
   with real branching logic. The dense files are the ones dominated by JSX and object literals.
   Someone was choosing per-file.
3. **No formatter is configured.** No `.prettierrc`, no Prettier dependency, no `format` script.
   The style is not the output of a tool and was not going to be reformatted.
4. **Comments are present and purposeful.** Dense code that had been minified or generated would
   not carry prose comments like `app/content-persistence.ts:23-27` (the batch rationale),
   `app/media-utils.ts:1`, `app/edit/editor-workflow.ts:18-19` and `:24-25`, or
   `app/content.ts:20`'s note on the retired `autoTour` field. These are explanations written for
   a reader.
5. **`eslint.config.mjs` applies the strict ruleset to `app/`** and relaxes three rules only for
   `components/ui/**` and `hooks/use-mobile.ts`, with a comment saying those are "vendored
   verbatim from shadcn@4.17.0". The author distinguished their own code from vendored code
   deliberately and held their own to the stricter standard.

**So: a house style.** But it carries real, recordable costs:

- **Line-based tooling degrades.** Diffs, blame and coverage reports are line-granular. A
  one-character change inside a 3,969-character line shows as that whole line changing.
- **Line numbers are nearly useless as references.** Saying "`content.ts:20`" locates a
  1,189-character region, not a statement. Every reference into `content.ts` or `editor.tsx` in
  this knowledge base has that limitation, which is why the referenced *content* is described
  rather than left to the number alone.
- **The line counts understate the work by roughly 3–5×.** Sizing from `wc -l` (1,819 lines in
  `app/`) underestimates. Bytes are the honest measure: **~200 KB of application TypeScript**.
- **Review is harder.** A 3,969-character line cannot be read in a side-by-side diff.

> **Hazard, not a recommendation.** The risk is *translation*: dense code hides branches, and a
> reviewer skimming `content.ts:20` can miss a `.default()` or a `.refine()` in the middle of a
> 1,189-character line. Every constraint has been enumerated in `api-documentation.md` →
> *Content schema* precisely so that nobody has to read that line again to get it right.

## Testing — total absence

The scan searched the whole tree (excluding generated directories) for `*.test.*`, `*.spec.*`,
`*.cy.*`, `vitest.config.*`, `jest.config.*`, `playwright.config.*`, `__tests__/` and `tests/`.
**Zero results.** `package.json` has no `test` script and no testing dependency — no vitest, no
jest, no playwright, no testing-library.

**There is no test of any kind in this repository.** Not one unit test, not one integration test,
not one end-to-end test.

The only automated quality gates are `tsc` (`strict: true`) and `pnpm lint`. The README records
what was verified by hand: *"TypeScript, the production build, content validation, and SQL
save/publish/conflict checks passed"* — a manual pass, not an automated suite.

**Why this matters more than usual here.** The pieces with the most intricate branching and the
least observability are exactly:

- the seven-statement concurrency batch,
- three hand-written binary header parsers,
- a WebVTT grammar validator,
- a byte-range parser with six distinct rejection branches,
- a six-flag editor state machine.

**Every one of them is currently unverified by any automated check.** There is no
characterisation suite and no oracle to diff an alternative implementation against. Behavioural
equivalence cannot be demonstrated by running the old tests, because there are none.

> This is the single largest quality gap in the codebase.

## Error handling at boundaries

**Consistent and, on the whole, good.** Every one of the four route handlers wraps its body in
`try/catch` and returns a structured JSON error. No exception escapes to a framework error page.
Nothing is swallowed silently: every catch either logs (`console.error`) or returns a message,
and most do both.

Observed patterns:

- **Uniform status vocabulary** across routes: 403 auth/origin, 400 malformed, 413 too large,
  409 conflict, 404 not found, 499 client abort, 503 unexpected.
- **User-facing messages are genuinely good.** Every error tells the owner what happened *and
  what is safe*: `'Your changes could not be saved. They are still in the form.'`,
  `'Upload cancelled. Your previous file is unchanged.'`, `'Version history is temporarily
  unavailable. Your current edits are safe.'`. This is a real strength and is worth preserving
  verbatim.
- **Abort handling is explicit.** `app/api/upload/route.ts` checks `request.signal.aborted` at
  **seven** points (lines 18, 21, 37, 52, 56, 58, 61) and maps `AbortError` to **499**.
- **Compensating cleanup on failure.** The upload catch block deletes every already-written R2
  object and `assets` row under `Promise.allSettled` (lines 65–70), so a mid-upload failure does
  not orphan. Explicitly documented as best-effort.
- **Render-time degradation.** `app/page.tsx:8` catches and renders a "temporarily unavailable"
  page rather than failing; `app/page.tsx:5` catches inside `generateMetadata` and falls back to
  a static title. `app/edit/page.tsx:10` does the same for the editor.

Weaknesses:

1. **Everything unexpected is a 503.** A schema-validation failure on *stored* content, a D1
   outage and a genuine code bug are indistinguishable to the caller and to logs. There is **no
   error taxonomy and no error identifier**.
2. **`console.error` is the entire observability story.** No structured logging, no request id,
   no correlation between the three routes that fail together.
3. **Error message strings are duplicated as literals** across route files with no shared
   constant, so the client cannot branch on anything but the status code.
4. **The `reply()` helper is defined twice**, identically, in `app/api/content/route.ts:5` and in
   `app/api/history/route.ts`. `/api/upload` and `/api/media` use neither — so **upload error
   responses carry no `Cache-Control: no-store`** at all, unlike content and history errors.
   Minor, but a real inconsistency at a boundary.
   *(Recorded inconsistency: the scan gives the history-route definition as line 14 in one
   section and line 4 in another, against a 14-line file. One is wrong; it does not say which.)*
5. **Two independent stores, no transaction.** The upload path writes R2 then D1. The cleanup
   block is the only thing keeping them consistent, and it only runs if the handler reaches its
   catch.

## Input validation coverage

**Strong where it exists, and the coverage is genuinely broad:**

| Boundary | Validation |
|---|---|
| Content body | Full zod schema + envelope checks + 1.5 M cap |
| History id | Length ≤ 100 and `/^[a-zA-Z0-9-]+$/` before it reaches SQL |
| Media key | `/^[a-f0-9-]+\.(jpg\|png\|webp\|pdf\|mp4\|webm\|vtt)$/` |
| Upload | MIME allowlist, magic bytes, per-kind size caps, dimension and aspect checks |
| Range header | Strict regex + safe-integer and bounds checks |
| Video URLs | Host allowlist (`app/media-utils.ts:2-13`) — YouTube/Vimeo only, 11-char id regex, never an arbitrary iframe src |
| Image srcset | Per-source re-validation client-side (`app/responsive-image.tsx:10-19`), rejecting control characters and non-http(s) protocols, and percent-encoding commas so a URL cannot forge a srcset candidate |
| Return paths | `safeRelativeReturnPath` (`app/chatgpt-auth.ts:61-74`) rejects `//`-prefixed and absolute URLs and reserved auth paths — an open-redirect defence |
| JSON-LD injection | `app/page.tsx:7` escapes `<` before `dangerouslySetInnerHTML` |
| SQL | **Every** query uses `.bind(...)` parameters. The scan found **no string-concatenated SQL anywhere** |

**Gaps:**

1. **`Content-Type` is never checked** on `PUT /api/content`. The body is parsed as JSON
   regardless of what the client declares.
2. **`sameOrigin` is the only CSRF defence.** It *requires* an `Origin` header — a **missing**
   header fails the check — so it is **not bypassable by omission**; but it is a single check with
   no token backing it, applied to only **2 of the 6** endpoint/method pairs.
   *(Recorded wording inconsistency: the scan introduces this bullet with the phrase "it fails
   open on shape" and then describes behaviour that fails **closed**. The behaviour as described
   in the same sentence, and as stated elsewhere in the scan, is what is recorded here.)*
3. **`GET /api/content` and `GET /api/history` have no same-origin check.** They are protected
   only by being non-simple JSON GETs with no CORS headers, i.e. by the browser.
4. **The 51 MB upload pre-check is bypassable** (no `content-length` → `Number(null || 0) === 0`
   → passes). The real cap is the post-buffer sum at line 31.
5. **No rate limiting anywhere.** Not on upload, not on save, not on media.
6. **Runner-up hazard R1 — the 1.5 M body cap is applied after full buffering and counts
   characters, not bytes.** `request.text()` returns a JavaScript string and `.length` counts
   **UTF-16 code units**, so the cap is **1,500,000 characters**; a document of 1.5 M non-ASCII
   characters can be **3–4 MB of UTF-8**. Any reimplementation that caps at 1,500,000 *bytes*
   rejects documents this implementation accepts. The body is already fully in memory when the
   check runs, so the cap bounds document size, not memory use.

## Security posture — the upload path

**Defences present, and better than typical:**

- Editor + same-origin required before anything is read.
- MIME allowlist of exactly **7** types; the extension is derived from the *validated* MIME,
  never from the user's filename.
- **Magic-byte verification for every accepted type** — the client-declared MIME is never trusted
  on its own.
- Stored keys are `crypto.randomUUID()` + a derived extension, so a user-supplied filename can
  never influence the storage key or path. The original name is kept only as metadata, truncated
  to 200 characters.
- **Dimension caps (`≤ 40000` per side, `≤ 100,000,000` pixels) reject decompression-bomb
  geometry without decoding pixels** — headers only.
- Per-kind size caps, applied to the summed upload.
- Cleanup on failure.

**Concerns:**

1. **Images and VTT are fully buffered in memory** (`route.ts:36` reads the whole file for
   `image/*` and `text/vtt`). A 10 MB image is entirely resident. Videos are not — only 32 bytes
   are read.
2. **No content scanning beyond structure.** A file with a valid PNG header and arbitrary
   trailing bytes passes. A polyglot is not detected. The `nosniff` + `sandbox` +
   `default-src 'none'` headers on the **serving** side are what actually contain this, and they
   are correctly applied — the defence is at read time, not write time.
3. **PDF validation is `head.startsWith('%PDF-')` only** — 5 bytes. Any file beginning `%PDF-` is
   accepted as a PDF, and PDFs are the richest attack format in the allowlist. The serving CSP is
   again what contains it.
4. **No virus/malware scanning**, a reasonable choice for a single-owner site but recorded rather
   than assumed.
5. **No quota.** Unlimited uploads, and no orphan collection anywhere, so storage grows without
   bound.

## Security posture — the media path

**Defences present:**

- The key regex confines lookups to a UUID-plus-known-extension shape; **no traversal is
  expressible**.
- **Every denial is a 404**, never a 403 — the existence of non-public assets is not confirmed.
- `Content-Security-Policy: default-src 'none'; sandbox` neutralises active content in a served
  file. This is the control that makes the weak PDF check tolerable.
- `X-Content-Type-Options: nosniff` prevents MIME confusion.
- `Cache-Control: private, no-cache` keeps authorised bytes out of shared caches — correct, given
  the same URL can be public or private depending on document content.
- `Content-Type` comes from the `assets` row, not from anything in the request.

**Concerns:**

1. **The `includes()` access rule** — hazard 2, analysed in full below.
2. **Unbounded cost per request** — a full content read, two schema parses and three
   serialisations per media byte served, with no caching. That is a **denial-of-service
   amplifier**: a cheap range request forces expensive work, and there is no rate limit.
3. **HEAD ignores `Range`**, so HEAD and GET disagree about what they would return.
4. **No 304 path** despite emitting `ETag`.
5. **`Content-Type` and R2's stored content type are two independent records** that happen to
   agree today, because both are written from the same value at upload time.

---

## Hazard 2 — the media access rule

`app/api/media/[key]/route.ts:7`:

```ts
const {published} = await readContent();
const isPublic = JSON.stringify(published).includes(`/api/media/${key}`);
```

**The mechanism.** An asset is publicly readable **if and only if** the literal string
`/api/media/<key>` appears **anywhere** in the serialised published document. Not "is referenced
by the `photo` field" or "appears in a known image slot" — anywhere at all, **including inside
free prose**.

**The per-request cost.** `readContent()` is `readContentState()`
(`app/content-persistence.ts:18`), which:

1. Runs `SELECT draft, published, revision, updated_at, published_at FROM site_content WHERE id = 1`
   — fetching **both** ~15 KB documents.
2. Calls `normalizeStoredContent` on **each**, i.e. `JSON.parse` + a full `contentSchema.parse`
   (with every refinement and transform) **twice**.
3. Computes `hasUnpublishedChanges` with two more `JSON.stringify` calls and a full string
   comparison (line 16) — **a value this route never uses**.
4. Then line 7 performs a **third** `JSON.stringify` of `published` and an O(n) substring scan.

**One D1 row read, two full schema validations and three serialisations of a ~15 KB document for
every media byte served**, with `Cache-Control: private, no-cache` and no 304 path, so nothing is
cached. A page with N images costs N repetitions. A video streamed in byte ranges repeats the
whole thing for **every range request**.

**Failure modes.**

1. **Over-permission through prose.** Any field that can hold free text will make an asset public
   if the URL is typed into it — `transcript` (up to **60,000** chars), `description`, `bio`,
   `intro`, `notice`, any of the nine copy blocks. Pasting a draft-only image URL into a caption
   transcript publishes that image.
2. **Publication is indiscriminate.** Publishing makes public *every* asset URL anywhere in the
   document, including ones in fields that are not rendered — e.g. an item in a collection whose
   section is toggled off via `sections.*`. The visibility toggle hides the section from the page;
   it does **not** make its media private.
3. **No revocation and no cleanup.** Removing a reference makes the asset non-public again on the
   next request, but neither the R2 object nor the `assets` row is ever deleted. There is **no
   orphan collection anywhere in the codebase**. Storage grows monotonically.
4. **Total coupling of the media path to schema health.** Because the check calls `readContent()`,
   which parses stored content, a stored document that fails validation throws — caught at line 19
   — and **every media request returns 503**, simultaneously with `/` and `/api/content`. **One
   bad document takes down images, the public page and the editor.**
5. **Substring rather than structural matching.** The scan checked for prefix collisions and found
   **none**: the key regex forces a `.`-extension suffix, and a match requires `/api/media/`
   immediately followed by the full key, so `/api/media/0.webp` cannot match inside
   `/api/media/1230.webp`. JSON escaping is also not a problem — `JSON.stringify` does not escape
   `/`. The mechanism is not *wrong*, but it is positional-string-based rather than semantic, so
   it silently changes meaning if the URL format ever changes (a query string, a CDN prefix).
6. **Timing.** `isPublic` is evaluated **before** `editorAccess()` (line 8 short-circuits on
   `!isPublic`). For public assets, no authorisation lookup happens at all — good. But for **every
   non-public asset request**, the full content read happens *and then* a D1 `editors` lookup.

> **Hazard.** A reimplementation that computes public-ness from structured fields only (`photo`,
> item `image`, `imageSources`) makes strictly **fewer** assets public than today, and images
> referenced from prose 404 for visitors. A reimplementation that caches the published document
> changes failure mode 3's timing. **Both are behaviour changes, and both are silent.** The
> status-code contract of this route is in `api-documentation.md`.

---

## The two known defects — confirmed, with measurements

**1. Carousel arrow buttons use native `disabled` (accessibility).**
`components/ui/carousel.tsx:194` (`disabled={!canScrollPrev}`) and `:224`
(`disabled={!canScrollNext}`). A disabled button is removed from the tab order, so when the
carousel reaches an endpoint the focused control disappears and focus falls to `<body>`, breaking
keyboard navigation mid-interaction. This affects **both live carousels**: achievements
(`app/achievements.tsx`) and updates (`app/updates.tsx`).

Two aggravating details: this is **vendored shadcn source**, which `eslint.config.mjs`
deliberately exempts from three lint rules to keep the registry copy verbatim — so fixing it means
forking the vendored file. And `app/use-section-carousel.ts:38` routes arrow keys through
`closest('[data-slot="carousel-previous"],[data-slot="carousel-next"]')`, i.e. the keyboard
handler depends on focus being *on* a button that `disabled` has just removed. Confirmed as
**pre-existing**.

**2. Oversized client chunk (performance).** Measured from the existing build:

```
560,248 bytes  dist/client/_next/static/chunks/nano-renderer-DnAj1dia.js
560,140 bytes  dist/server/ssr/_next/static/nano-renderer-WQUhoSTV.js
195,917 bytes  dist/client/_next/static/chunks/index--4o58axH.js
190,152 bytes  dist/client/_next/static/chunks/framework-D_rUT4EX.js
100,209 bytes  dist/client/_next/static/chunks/research-identity-CieCsVSF.js
```

The three.js renderer is **547 KB uncompressed**, above the 500 KB warning threshold.

**Mitigation already present, and it is good.** `app/scene.tsx:85` imports the renderer
**dynamically** (`await import('./nano-renderer')`), gated by
`shouldLoadResearchScene(motion, preferences, requested)` (`app/scene-performance.ts:9-16`),
which requires preferences to be **known**, motion enabled, `prefers-reduced-motion` not set, and
either save-data off or an explicit request. So the 547 KB is **never on the critical path** and
never loads for a reduced-motion or save-data visitor. The chunk is large; the loading strategy
is careful. Confirmed **pre-existing**.

## Findings beyond what the earlier inspection recorded

### A. The `invalid_format` allowlist entry is dead code, and enum errors discard drafts (runner-up R3)

`app/edit/editor-workflow.ts:20` decides whether a recovered localStorage draft is salvageable:

```ts
if(!parsed.success && parsed.error.issues.some(
     issue => !['too_small','too_big','custom','invalid_format'].includes(issue.code)))
  return null;
```

`invalid_format` is a **zod v4** issue code. `app/content.ts:1` imports from the `zod` package
root, which in 3.25.76 resolves to the **v3** API. The scan verified this empirically by running
the resolved package:

```
Is "invalid_format" a valid zod-v3 issue code?  false
v3 codes: invalid_type, invalid_literal, custom, invalid_union,
          invalid_union_discriminator, invalid_enum_value, unrecognized_keys,
          invalid_arguments, invalid_return_type, invalid_date, invalid_string,
          too_small, too_big, invalid_intersection_types, not_multiple_of, not_finite
```

So the fourth allowlist entry **can never match**. More consequentially, **`invalid_enum_value`
is not in the allowlist**. Measured behaviour against an equivalent schema:

| Draft defect | zod v3 code | `parseRecovery` outcome |
|---|---|---|
| Empty required title | `too_small` | **KEEP** the draft |
| Over-length field | `too_big` | **KEEP** |
| Malformed email (a `.refine`) | `custom` | **KEEP** |
| **Bad enum** (`accent`, `initialView`, `researchTopic`) | `invalid_enum_value` | **DISCARD the entire draft** |
| Wrong field type | `invalid_type` | **DISCARD** |
| Missing required key | `invalid_type` | **DISCARD** |

The comment on lines 18–19 states the intent: *"Locally authored drafts can contain a temporarily
empty title or invalid link. Retain these recoverable edits, but reject malformed field types or
shapes."* A bad enum value is a *value* problem, not a shape problem — the stated intent says keep
it, and the code discards it silently, along with every other unsaved edit in that recovery record.

Whether this bites in practice depends on whether the editor can produce an out-of-range enum. The
three enum fields are edited through `Select` and `RadioGroup` controls, so in normal use it should
not arise — but a draft written by an **older schema version** (a retired enum member) or by the
WebMCP tool path is exactly the case recovery exists for.

> **Recorded as a latent defect with a proven mechanism, not a confirmed user-visible failure.**
> The scan demonstrated the issue-code mismatch empirically but could not exercise the editor in
> that environment. This is limit 6 of the seven in `reverse-engineering-timestamp.md`.

> **Hazard.** If draft recovery is reimplemented against a different validator, this allowlist has
> to be re-expressed in terms of *that* library's error taxonomy. Copying the four strings across
> would carry the bug forward and add a second one, since other libraries' codes share no names
> with either zod version.

### B. `db/schema.ts` is not in the runtime graph

Covered in `code-structure.md`. Recorded here because "the app uses an ORM" is the kind of
assumption that silently shapes a plan. **It does not.** It uses **11 hand-written SQL strings**.

### C. `results[3]` is a hard-coded positional index (runner-up R4)

`app/content-persistence.ts:44` reads the CAS `UPDATE`'s result by numeric index into the batch
array:

```ts
const saved = results[3]?.results?.[0];
```

Statement 3 is the `UPDATE`. **Insert a statement anywhere before it and `writeContent()` silently
reads the wrong result** — most likely returning `undefined`, which the route interprets as
**409 conflict**. So a refactor of the batch produces spurious "this draft changed in another tab"
errors rather than a crash. There is **no comment marking index 3 as load-bearing**, and no test
to catch it.

### D. `siteOrigin` is hard-coded in source

`app/site-metadata.ts:5`:
`export const siteOrigin = 'https://madhavi-tripathi.madhavi-tri16.chatgpt.site';`
It feeds `metadataBase`, the canonical link, OG `url`, `siteName`, the JSON-LD `url` and `@id`,
and `robots.ts`'s sitemap URL. **There is no environment variable.** Deploying anywhere else
without changing this emits wrong canonical URLs and wrong structured data.

### E. `OWNER_EMAIL` is hard-coded in source

`app/server.ts:5`. A personal email address committed to the repository, functioning as the
**authorization root of trust**.

### F. `lib/utils.ts` and `hooks/use-mobile.ts` have zero `app/` consumers

`lib/utils.ts` is imported by **57 of 61** `components/ui` files and by **no application file**.
`hooks/use-mobile.ts` is imported only by the unreachable `sidebar.tsx`. Both travel with the UI
library, not with the application — relevant to any "keep `lib/` and `hooks/`" instruction.

### G. `readContentState()` does unnecessary work on every read

It parses **both** the draft and the published document and computes `hasUnpublishedChanges` via
two `JSON.stringify` calls, regardless of caller. `/api/media/[key]` needs only `published`.
`app/page.tsx` needs only `published`. `app/sitemap.ts` needs only `publishedAt`. **Three of the
five call sites pay for the draft parse and the comparison and use neither.**

### H. Two independent stores with no transaction across them

R2 and D1 writes in the upload path can diverge, and only the best-effort catch block reconciles
them.

### I. Draft recovery is suppressed while a recovery offer is pending

`app/edit/editor-workflow.ts:50` returns early when `recovery` is non-null, so **no localStorage
backup is written while the owner is deciding** whether to recover. Edits made during that window
are protected only by the `beforeunload` warning.

### J. The recovery size cap exceeds the server's body cap

`parseRecovery` accepts records up to **6,000,000** characters (`editor-workflow.ts:15`);
`PUT /api/content` rejects bodies over **1,500,000** characters. A recovered draft between those
bounds is restorable into the editor but **unsavable** — it would fail with 413 on every attempt.
An edge case, but the two numbers were chosen independently and do not agree.

### K. The localStorage recovery scan is capped at 500 keys

`Math.min(localStorage.length, 500)` (`editor-workflow.ts:45`). With more than 500 keys in the
origin's storage, recovery records beyond index 499 are not seen.

---

## Hazard 1 — the seven-statement D1 batch, precise behaviour

`app/content-persistence.ts:28-40`. This is the highest-risk behaviour in the system, so it is
documented statement by statement. All seven run in **one D1 `batch()`**, which D1 executes as a
**single implicit transaction**. The in-code comment (lines 23–27) states the design intent:

> *"All statements run in one D1 batch transaction. The random mutation token gates history and
> retention after the optimistic revision guard. A stale request can therefore neither modify
> content nor add misleading history entries."*

Inputs (line 28): `{content, revision, action, now, mutationId}`.
Derived (line 29): `serialized = JSON.stringify(content)`,
`initial = JSON.stringify(initialContent)`, `publish = action === 'publish' ? 1 : 0`,
`nextRevision = revision + 1`. `mutationId` is a fresh `crypto.randomUUID()` per call (line 43).

**Statement 0 — bootstrap the singleton row.**

```sql
INSERT INTO site_content (id, draft, published, revision, updated_at)
SELECT 1, ?, ?, 0, ? WHERE ? = 0
ON CONFLICT(id) DO NOTHING
```

Binds `(initial, initial, now, revision)`.

Creates row `id = 1` seeded with `initialContent` in **both** columns at revision 0. Two guards:
`WHERE ? = 0` means it only fires when the caller claims revision 0, so a client at revision 5 can
never resurrect a deleted row; `ON CONFLICT DO NOTHING` makes a concurrent bootstrap harmless.
Note `published_at` is left **NULL** — the seed is not "published".

**Statements 1 and 2 — capture permanent baselines, once, ever.**

```sql
INSERT OR IGNORE INTO content_revisions (id, revision, action, content, created_at, baseline)
SELECT 'starting-published', revision, 'publish', published, ?, 1
  FROM site_content WHERE id = 1 AND revision = ?
```

and the same with `'starting-draft'`, `'draft'`, `draft`. Both bind `(now, revision)`.

Fixed primary keys (`'starting-published'`, `'starting-draft'`) plus `INSERT OR IGNORE` means each
can succeed **at most once in the row's lifetime**. They capture the *pre-existing* content — the
state before this write — as `baseline = 1`, which the retention deletes below explicitly never
touch. `created_at` is the current time, not a guessed original date; the comment on line 32 says
so: *"Capture starting versions once, without guessing their original publication date."* The
`revision = ?` guard means a stale writer captures nothing.

**Statement 3 — the compare-and-set. This is the concurrency control.**

```sql
UPDATE site_content SET
  draft = ?,
  published = CASE WHEN ? = 1 THEN ? ELSE published END,
  revision = revision + 1,
  updated_at = ?,
  published_at = CASE WHEN ? = 1 THEN ? ELSE published_at END,
  last_mutation = ?
WHERE id = 1 AND revision = ?
RETURNING draft, published, revision, updated_at, published_at
```

Binds `(serialized, publish, serialized, now, publish, now, mutationId, revision)`.

- `draft` is **always** overwritten.
- `published` and `published_at` change **only** when `action === 'publish'` — the two `CASE`
  expressions are how "publish" is expressed.
- `revision` increments **unconditionally, for drafts as well as publishes**.
- `last_mutation` is stamped with this call's random token.
- **`WHERE ... AND revision = ?` is the optimistic-concurrency guard.** If the caller's revision is
  stale, zero rows match, `RETURNING` yields nothing, `results[3]?.results?.[0]` is `undefined`,
  `writeContent` returns `null`, and `app/api/content/route.ts:18` returns **409**.

**Statement 4 — the history insert, gated on the token.**

```sql
INSERT INTO content_revisions (id, revision, action, content, created_at, baseline)
SELECT ?, revision, ?, draft, updated_at, 0
  FROM site_content WHERE id = 1 AND revision = ? AND last_mutation = ?
```

Binds `(mutationId, action, nextRevision, mutationId)`.

The history row's **id is the mutation token**. Its `content` is read back from the row's `draft`
column and its `created_at` from `updated_at`, so the history entry is guaranteed **byte-identical
to what statement 3 just wrote — not to what the caller sent**. (For a publish, `draft` and
`published` are equal, so storing `draft` is correct for both actions.)

**Statements 5 and 6 — retention, gated on the same token.**

```sql
DELETE FROM content_revisions
WHERE action = 'draft' AND baseline = 0
  AND id NOT IN (SELECT id FROM content_revisions
                 WHERE action = 'draft' AND baseline = 0
                 ORDER BY revision DESC LIMIT 30)
  AND EXISTS (SELECT 1 FROM site_content
              WHERE id = 1 AND revision = ? AND last_mutation = ?)
```

and the same for `action = 'publish'` with `LIMIT 20`. Both bind `(nextRevision, mutationId)`.

Keep the **30** newest non-baseline drafts and the **20** newest non-baseline publishes.
`baseline = 0` excludes the two starting records from deletion permanently.
**30 + 20 + 2 = 52**, which is exactly the `LIMIT 52` on the history listing
(`api-documentation.md`).

## Why `last_mutation` exists alongside the `revision` CAS

They defend different things, and the second is **not redundant**.

- **`revision` (statement 3) protects the content write.** It answers *"is the caller's view of
  the document still current?"* If not, nothing is written and the caller gets 409.
- **`last_mutation` (statements 4, 5, 6) protects the side effects.** It answers *"is the row in
  its current state because **I** put it there?"*

The distinction matters because statements 4–6 are guarded on `revision = nextRevision` — a value
that is *not unique to this writer*. Concretely:

> Row sits at revision 5. Writer A and writer B both load revision 5.
> B's batch commits first: the row advances to revision 6, stamped with B's token.
> A's batch now runs. A's statement 3 (`WHERE revision = 5`) matches nothing — the CAS correctly
> fails, and A will get a 409.
> But A's statements 4–6 test `revision = 6`, because A's `nextRevision` is **also** 6.
> **Without the token, that guard would be satisfied by B's write.**

The consequences, precisely:

- **Statement 4** would insert a history row keyed by *A's* mutation id, carrying *B's* content (it
  selects `draft` from the row), labelled with *A's* action. **A phantom revision that no one ever
  saved** — exactly the *"misleading history entries"* the comment names.
- **Statements 5 and 6** would run A's retention pass off the back of B's write, **pruning history
  A had no right to prune**, potentially deleting a revision B had just created.

Adding `AND last_mutation = ?` with a fresh random token per call makes all three guards test
**identity rather than position**. A stale writer's `nextRevision` may collide with the winner's
`revision`; its random UUID will not.

This is a classic **ABA defence**: the revision counter alone cannot distinguish "unchanged" from
"changed to a coincidentally equal value by someone else", and the random token supplies the
missing identity.

**Secondary benefit.** Even if a future runtime executed the batch with weaker isolation than D1's
implicit transaction, the token keeps statements 4–6 correct. **The guard does not depend on
transactional isolation to hold.**

## Hazards in the batch — enumerated

1. **The token is not optional.** Re-expressing this as "CAS on revision, then insert history,
   then prune" without the token reintroduces the phantom-history and wrongful-prune bugs. They
   are **timing-dependent and will not appear in single-user testing**.
2. **All seven statements must share one transaction.** Splitting them across separate
   transactions breaks both guards.
3. **`results[3]` is positional** (finding C). Any reordering silently turns successful writes
   into 409s.
4. **The retention numbers are coupled to the listing limit.** 30 + 20 + 2 = 52.
5. **Baselines are `baseline = 1` and must never be pruned**, and `INSERT OR IGNORE` on a fixed
   primary key is what makes them once-only. A target database without `INSERT OR IGNORE`
   semantics needs an equivalent that is genuinely idempotent under concurrency.
6. **`revision` increments on drafts too**, not only publishes.
7. **`published_at` stays NULL until the first publish.** The local emulator row confirms this:
   revision 4, `published_at` empty, both documents 15,423 bytes — four draft saves, never
   published.
8. **History content is read back from the row, not taken from the request.** An implementation
   that inserts the caller's payload directly will diverge whenever validation transforms or
   defaults change the stored value — which, given the `.transform()` on `item` and the many
   `.default()`s, is **most of the time**.
9. **`ORDER BY revision DESC` in the retention subquery is not a tiebreak-stable order.** Multiple
   rows can share a revision (a baseline pair plus a normal entry). **Which row survives at the
   boundary is unspecified.** The behaviour is the same in any faithful port only if the same
   ordering is used.

---

## The hand-written image header parsers (runner-up R2)

`app/upload-validation.ts:5-43`, `imageDimensions(bytes, mime)`. Returns `{width, height}` or
`null`. **`null` is a rejection** — `app/api/upload/route.ts:40` treats `!!dimensions` as the
validity test for every `image/*` upload. So these parsers are **simultaneously the dimension
extractor and the format validator**, and any reimplementation must reproduce the same
accept/reject decision, not merely the same dimensions.

A `DataView` is created over the array (line 6). **`view.getUint32(n)` and `view.getUint16(n)`
default to big-endian**; `getUint32(n, true)` / `getUint16(n, true)` are little-endian. Both appear
below and the distinction is load-bearing.

**PNG (lines 8–10).** Rejects unless **all** hold:

- `bytes.length >= 33`
- bytes 0–7 exactly `137 80 78 71 13 10 26 10` (the PNG signature, `\x89PNG\r\n\x1a\n`)
- bytes 12–15 decode to `IHDR`

Then:

- `width  = view.getUint32(16)` — **big-endian**, bytes 16–19
- `height = view.getUint32(20)` — **big-endian**, bytes 20–23

Bytes 8–11 (the IHDR chunk length) are **never checked**. Anything after byte 23 is ignored.

**WebP (lines 11–23).** Rejects unless **all** hold:

- `bytes.length >= 30`
- bytes 0–3 decode to `RIFF`
- bytes 8–11 decode to `WEBP`
- `view.getUint32(4, true) + 8 <= bytes.length` — **little-endian** RIFF size field, plus the
  8-byte RIFF header, must not exceed the actual buffer. This rejects truncated files.

Then bytes 12–15 select one of three sub-formats. **Anything else leaves `width`/`height` at 0,
which becomes a rejection at line 42.**

*`VP8X` (extended, lines 14–16)* — 24-bit little-endian canvas dimensions, minus-one encoded:

- `width  = 1 + bytes[24] + (bytes[25] << 8) + (bytes[26] << 16)`
- `height = 1 + bytes[27] + (bytes[28] << 8) + (bytes[29] << 16)`

*`VP8L` (lossless, lines 17–19)* — requires `bytes[20] === 0x2f` (the VP8L signature byte), then a
packed 14-bit-each layout:

- `width  = 1 + bytes[21] + ((bytes[22] & 0x3f) << 8)`
- `height = 1 + (bytes[22] >> 6) + (bytes[23] << 2) + ((bytes[24] & 0x0f) << 10)`

*`VP8 ` (lossy, note the trailing space, lines 20–22)* — requires the 3-byte start code
`bytes[23] === 0x9d && bytes[24] === 0x01 && bytes[25] === 0x2a`, then:

- `width  = view.getUint16(26, true) & 0x3fff` — little-endian, low 14 bits
- `height = view.getUint16(28, true) & 0x3fff` — little-endian, low 14 bits

The `& 0x3fff` masks off the 2-bit scaling field in each 16-bit value.

**JPEG (lines 24–40).** A real marker-segment walk, not a fixed offset read.

Rejects immediately unless `bytes.length >= 4` and `bytes[0] === 0xff && bytes[1] === 0xd8` (SOI).
Then from `position = 2`:

1. If `bytes[position++] !== 0xff` → **return null** (marker desynchronised).
2. Skip fill bytes: `while (bytes[position] === 0xff) position++`.
3. `marker = bytes[position++]`.
4. If `marker === 0xd9` (EOI) or `marker === 0xda` (SOS) or `position + 2 > bytes.length` →
   **break** out of the loop (not a rejection; falls through to the final check).
5. If `marker === 0x01` (TEM) or `0xd0 <= marker <= 0xd7` (RST0–RST7) → `continue` — these are
   standalone markers with no length field.
6. `length = view.getUint16(position)` — **big-endian**.
7. If `length < 2` or `position + length > bytes.length` → **return null** (malformed or truncated
   segment).
8. If `marker` is one of the SOF markers
   `0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf`:
   - if `length < 8` → **return null**
   - `height = view.getUint16(position + 3)` — **big-endian**
   - `width  = view.getUint16(position + 5)` — **big-endian**
   - **break**
9. Otherwise `position += length` and loop, while `position + 3 < bytes.length`.

Note the SOF list deliberately **excludes** `0xc4` (DHT), `0xc8` (JPG) and `0xcc` (DAC), which
share the `0xcN` range but are not frame headers. Note also that **height precedes width** in a
SOF segment — a transposition here is a silent bug that only shows on non-square images.

**The final gate (line 42), applied to all three formats:**

```ts
return width > 0 && height > 0 && width <= 40000 && height <= 40000
    && width * height <= 100000000 ? {width, height} : null;
```

Both dimensions positive, each at most **40,000**, and at most **100,000,000** total pixels. This
is the **decompression-bomb defence**, and it is reached **without decoding a single pixel**.

> **Hazards.**
> 1. **Endianness is mixed**: PNG and JPEG are big-endian; **every WebP field is little-endian**.
> 2. A language whose integer-from-bytes helper requires an **explicit byteorder** (Python's
>    `int.from_bytes` among them) has no default to inherit, so each read must be transcribed
>    individually.
> 3. **JPEG stores height before width.**
> 4. Using an imaging library instead of a hand-written parser produces a **different
>    accept/reject set**: such libraries accept formats this code rejects (GIF, BMP, TIFF, AVIF —
>    though the MIME allowlist would catch those first) and, more importantly, may *accept*
>    malformed files this walker rejects at steps 1 and 7, and *reject* unusual-but-valid files
>    this walker accepts. The pixel caps must also be enforced from header data **before** any
>    decode, or the bomb defence is lost.
> 5. The `>= 33` / `>= 30` / `>= 4` minimum-length checks are **part of the contract**.
> 6. WebP sub-formats other than `VP8X`, `VP8L`, `VP8 ` are **rejected**.

## The WebVTT validator

`app/upload-validation.ts:45-67`. `validCaptions(bytes)` → boolean.

**Decode (line 54).** `new TextDecoder('utf-8', {fatal: true})` — **invalid UTF-8 throws** and the
function returns `false`. Then a leading BOM is stripped and all `\r\n` and bare `\r` are
normalised to `\n`.

**Header and safety gate (line 55).** Returns `false` unless all hold:

- `/^WEBVTT(?:[ \t][^\n]*)?\n/` — the literal `WEBVTT`, optionally followed by a space or tab and
  trailing text, then a newline. **A file consisting of only `WEBVTT` with no trailing newline
  fails.**
- No `\u0000` anywhere.
- No match for `/<(?:script|iframe|object|embed|svg|style)\b/i` — a **markup blocklist** applied to
  the whole file.

**Block split (line 56).** `text.trim().split(/\n[ \t]*\n/)` — blank-line separated, tolerating
whitespace on the "blank" line.

**Line 57.** Returns `false` if there are no blocks, or if `blocks[0]` contains `-->` (the header
block must not itself be a cue).

**Per block, from index 1 (lines 59–65):**

- `/^NOTE(?:[ \t\n]|$)/` → skipped entirely (comments).
- `index = lines[0].includes('-->') ? 0 : 1` — so a cue identifier line is allowed before the
  timing line, and the timing line is expected at 0 or 1.
- The timing line must match:

  ```
  /^((?:\d{2,}:)?\d{2}:\d{2}\.\d{3})[ \t]+-->[ \t]+((?:\d{2,}:)?\d{2}:\d{2}\.\d{3})(?:[ \t]+.*)?$/
  ```

  i.e. optional `HH:` (**two or more** digits), then `MM:SS.mmm`, exactly three decimal places,
  separated by `-->` with at least one space or tab on each side, with optional trailing settings.
- `cueTime(end) > cueTime(start)` must hold — **strictly** greater; a zero-duration cue is
  rejected.
- `lines.slice(index + 1).join('\n').trim()` must be non-empty — a cue with no payload text is
  rejected.
- Any block failing any of these → `false` for the whole file.

**`cueTime` (lines 45–49).** Splits on `:`, pops seconds, then minutes, then hours (defaulting to
`0`). Returns `hours*3600 + minutes*60 + seconds` only if
`Number.isFinite(hours) && seconds < 60 && minutes < 60`, else `NaN`. Since the comparison is
`end > start`, any `NaN` makes the comparison false and rejects the file.

**Line 67.** `return cues > 0` — **a file with a valid header but no cues at all is rejected**.

> **Hazard.** Strict-UTF-8 decoding (not lenient), the required trailing newline after the header,
> the markup blocklist, the NOTE skip, the identifier-line tolerance, the strictly-increasing
> timing requirement, the non-empty-payload requirement, and the at-least-one-cue requirement are
> **eight independent reject conditions**. A permissive VTT library will accept files this rejects.

## The editor state machine

`app/edit/editor-workflow.ts`, `useDraftWorkflow(initial, initialState)`.

**Storage keys.**

- Legacy singleton: `'academic-site:draft-recovery:v1'` (exported as `recoveryKey`, line 12).
- Per-instance: `` `${recoveryKey}:${crypto.randomUUID()}` `` (line 32), generated once per hook
  instance via lazy `useState`.

Because the UUID is regenerated on every mount, a tab that reloads gets a new key and its
*previous* record becomes "another session's" — which is precisely what makes same-tab crash
recovery work. The comment on lines 42–44 states the intent: *"Each mounted editor owns its own
recovery record. A clean second tab must never clear another tab's unfinished work."*

**Mount scan (lines 40–49).** Collects the legacy key plus every key starting with
`` `${recoveryKey}:` `` found in the first `Math.min(localStorage.length, 500)` indices. Skips its
own key. For each, runs `parseRecovery`; keeps candidates whose content differs from the server's
`initial`; picks the one with the greatest `Date.parse(savedAt)`. On success, `setRecovery(latest)`
with `storageKey` attached. Any throw sets `storageWarning`. `setRecoveryReady(true)` runs
**unconditionally**, including after a throw.

**Persistence effect (line 50).** No-op while `!recoveryReady || recovery`. Otherwise: if `dirty`,
write `{content, revision, savedAt}` under the own key; if clean, remove it. Throws set
`storageWarning`.

**Autosave effect (line 69).** Arms a **1,500 ms** `setTimeout` calling `save('draft', true)` only
when **all** of: `dirty`, `recoveryReady`, `!recovery`, `!busy`, `!uploads`, `!paused`,
`!conflict`. The timer is cleared and re-armed on every content change, so it fires 1.5 s after
typing *stops*.

**States** — **six independent flags, not an enum**:

| Flag | Type | Meaning |
|---|---|---|
| `recoveryReady` | boolean | Mount scan finished |
| `recovery` | `DraftRecovery \| null` | A recovery choice is pending |
| `busy` | `'draft' \| 'publish' \| null` | A save is in flight |
| `uploads` | number | Count of in-flight uploads |
| `conflict` | boolean | Server reported 409 |
| `paused` | boolean | Autosave suspended |

Derived: `dirty = JSON.stringify(content) !== saved`.

**Named states:**

| State | Condition | Autosave | Manual save |
|---|---|---|---|
| INITIALISING | `!recoveryReady` | no | yes |
| CLEAN | `dirty === false` | n/a | yes (no-op for autosave) |
| DIRTY | `dirty`, all blockers clear | **armed, 1.5 s** | yes |
| SAVING | `busy !== null` | no | **blocked** |
| UPLOADING | `uploads > 0` | no | **blocked** |
| RECOVERY-OFFERED | `recovery !== null` | no | **blocked** |
| CONFLICT | `conflict === true` (implies `paused`) | no | **blocked** |
| PAUSED | `paused === true`, no conflict | no | **yes** |

```mermaid
flowchart TD
  INIT["INITIALISING: recoveryReady false"] --> CLEAN["CLEAN: dirty false"]
  CLEAN --> DIRTY["DIRTY: autosave armed at 1500 ms"]
  DIRTY --> SAVING["SAVING: busy is draft or publish"]
  SAVING --> CLEAN
  SAVING --> CONFLICT["CONFLICT: 409 received, manual save blocked"]
  SAVING --> PAUSED["PAUSED: other failure, manual save still allowed"]
  CONFLICT --> RELOAD["reloadLatest: GET /api/content"]
  RELOAD --> OFFER["RECOVERY-OFFERED: local edits become a recovery offer"]
  OFFER --> PAUSED
  OFFER --> CLEAN
  UPLOAD["UPLOADING: in-flight uploads block saving"] --> DIRTY
```

**Text fallback for the diagram.** The editor starts in INITIALISING until the mount scan
finishes, then sits in CLEAN. Editing moves it to DIRTY, where the autosave timer is armed at
1,500 ms. A save moves it to SAVING, which returns to CLEAN on success, to CONFLICT on a 409, or
to PAUSED on any other failure. CONFLICT has exactly one exit: `reloadLatest()` fetches
`GET /api/content` and converts the owner's local edits into a recovery offer, moving the editor
to RECOVERY-OFFERED; choosing to restore lands in PAUSED, declining lands in CLEAN or DIRTY.
UPLOADING blocks saving while uploads are in flight and returns to DIRTY when they finish.

> **The PAUSED/CONFLICT distinction is easy to miss and easy to get wrong.** `save()`'s guard
> (line 53) is `busyRef || uploadRef || recoveryRef || conflictRef` — **`paused` is not in it**.
> So PAUSED suppresses *automatic* saving only; the owner can still press *Save draft*. CONFLICT
> blocks both. An implementation that treats them as one state either **strands the owner**
> (blocking manual save while paused) or **lets them overwrite a conflicting revision**.

**Transitions.**

*`edit(updater)` (line 70)* — sets content, clears `message` and `issues`. Usually CLEAN → DIRTY.

*`save(action, automatic)` (lines 52–68):*

1. Guard `busyRef || uploadRef || recoveryRef || conflictRef` → return `false`, no state change.
2. `contentSchema.safeParse(snapshot)`. On failure: `setIssues`; if manual, `setError`; return
   `false`. **Does not set `paused`.**
3. If `automatic && serialized === savedRef` → return `true` without a request.
4. Enter SAVING: `busyRef = true`, `setBusy(action)`, clear `error`/`issues`, clear `message` if
   manual.
5. `PUT /api/content` with
   `{content: validation.data, revision: stateRef.revision, action, autosave: automatic}`.
   Note it sends `validation.data` — the **transformed and defaulted** document, not the raw form
   state.
6. **409** → `setConflict(true)`, `conflictRef = true`, `setPaused(true)`, throw → caught →
   `setError(...)`, `setPaused(true)`, return `false`. → CONFLICT.
7. **Other non-OK** → if `result.issues` is an array, `setIssues`; throw `result.error` →
   `setError`, `setPaused(true)`, return `false`. → PAUSED.
8. **OK** → adopt the new state; `savedRef = JSON.stringify(validation.data)`; `setPaused(false)`;
   then line 64:

   ```ts
   setContent(latest => JSON.stringify(latest) === serialized ? validation.data : latest);
   ```

   The canonical server-shaped document replaces the form state **only if the owner has not typed
   since the request began** — the comment on line 63 explains it: *"New keystrokes during this
   request belong to the next draft, never this response."* Then `setMessage(...)`, return `true`.
   → CLEAN (or DIRTY if the owner kept typing).
9. `finally` → `busyRef = false`, `setBusy(null)`.

*`chooseRecovery(restore)` (line 71):*

- If `restore` and `recovery` → `setContent(recovery.content)`.
- `setRecovery(null)`, `recoveryRef.current = null`.
- **`setPaused(restore)`** — restoring **pauses** autosave (so the owner must deliberately save
  over the server draft); declining resumes it.
- Best-effort `localStorage.removeItem(recovery.storageKey)`.

→ PAUSED if restoring, DIRTY/CLEAN if declining.

*`reloadLatest()` (lines 72–76)* — **the only exit from CONFLICT**:

- Guard `busyRef || uploadRef` → return.
- Enter SAVING (`setBusy('draft')`), clear error.
- `GET /api/content` with `cache: 'no-store'`; `contentSchema.safeParse(result.draft)`.
- On failure → `setError`; **`conflict` and `paused` are left unchanged**, so the editor stays in
  CONFLICT.
- On success → **`setRecovery({content: current.current, revision: stateRef.revision, savedAt: now, storageKey: ownRecoveryKey})`**
  — the owner's *local edits* are converted into a recovery offer — then `setContent(server draft)`,
  `setSaved`, `setState`, `setConflict(false)`, `conflictRef = false`, `setPaused(false)`.

→ RECOVERY-OFFERED. Saving remains blocked until `chooseRecovery` is called.

So the conflict resolution path is a **two-step, deliberately**:
**CONFLICT → (reloadLatest) → RECOVERY-OFFERED → (chooseRecovery) → PAUSED or CLEAN.** There is
**no path from CONFLICT directly back to saving**.

**`parseRecovery(raw)` (lines 14–30)** — returns `DraftRecovery | null`:

1. `null` if `raw` is falsy or `raw.length > 6_000_000`.
2. `JSON.parse` inside try/catch; any throw → `null`.
3. `null` unless `Number.isInteger(value.revision)`, `typeof value.savedAt === 'string'`, and
   `Number.isFinite(Date.parse(value.savedAt))`.
4. `contentSchema.safeParse(value.content)`.
5. If it failed **and** any issue code is outside
   `['too_small','too_big','custom','invalid_format']` → `null`. (See finding A — this allowlist
   has a dead entry and omits `invalid_enum_value`.)
6. If it succeeded → use `parsed.data`.
7. Otherwise **reconstruct** (line 26), merging the raw value over `initialContent`:
   - shallow spread of `initialContent` then `raw`
   - `scene`, `scholarHighlights`, `sections`: one-level merge over the `initialContent` value
   - `copy`: per-group merge — each of the nine groups merged field-by-field
   - each of the five collections (line 27): `(raw[group] ?? initialContent[group])` mapped to
     `{...newItem(), ...item, researchTopic: researchIdentity(item), researchIds: item.researchIds ?? initialResearchLinks.get(item.id) ?? []}`

   The comment (lines 24–25) gives the intent: *"Validation errors must not discard freshly added
   schema defaults. Invalid text remains editable, while legacy local records receive the same new
   fields."* This is a **forward-migration path for locally-stored drafts written by an older
   schema.**
8. Returns `{content, revision, savedAt}` — note `storageKey` is attached by the *caller* (line
   47), not here.

> Step 7 is the subtlest part of the whole module: it is how an old local draft acquires fields the
> schema has since gained. `{...newItem(), ...item}` generates a fresh UUID that is then
> overwritten by `item.id` when present — so items keep their identity, and only items genuinely
> lacking an id get a new one.

**`fieldId(path)` (line 13).**
`` `edit-${path.join('-').replace(/[^a-zA-Z0-9_-]/g,'-')}` `` — maps a validation-issue path to a
DOM id so the validation summary can focus the offending field. `app/edit/upload-field.tsx:51`
**re-implements the same expression inline** rather than importing `fieldId`. **Two copies of one
rule; they agree today.**

---

## Hazard 3 — the `researchIdentity` / `initialResearchLinks` back-compat shims

Two small maps that carry **real product behaviour**.

**`researchIdentity` — `app/research-identity.ts:11-18`:**

```ts
const originalTopics = new Map<string, ResearchTopic>([
  ['nano-materials',     'materials'],
  ['ultrasound-imaging', 'ultrasound'],
  ['photoacoustics',     'photoacoustic'],
]);
export function researchIdentity(item: {id: string; researchTopic?: ResearchTopic}): ResearchTopic {
  return item.researchTopic ?? originalTopics.get(item.id) ?? 'general';
}
```

**Why it exists.** The comment on line 10 says it: *"Existing published cards acquire a stable
identity without changing their text or order."* The `researchTopic` field was **added after** the
three original research cards were already published. Those cards' stored documents have no
`researchTopic`. Rather than a data migration, the id is used to infer it. Precedence is explicit:
an explicit value always wins; the legacy id map is the fallback; `'general'` is the floor.

**`initialResearchLinks` — `app/site-copy.ts:37-43`:**

```ts
export const initialResearchLinks = new Map<string, string[]>([
  ['breast-imaging-2026',       ['photoacoustics']],
  ['ultrasound-coherence-2025', ['ultrasound-imaging']],
  ['mucin-cus-2025',            ['nano-materials', 'photoacoustics']],
  ['nanoflakes-2024',           ['nano-materials']],
  ['nanohybrids-2023',          ['nano-materials', 'photoacoustics']],
]);
```

**Why it exists.** Same reason, for a different field: `researchIds` — the many-to-many link from a
publication to the research themes it supports — was added after those five publications were
published. The map supplies the original editorial linkage keyed by publication id. Note the
**values are research-card ids** (`nano-materials`, `ultrasound-imaging`, `photoacoustics`), the
same ids `originalTopics` keys on.

**Where they are applied — four places, which is itself a hazard:**

1. `app/content.ts:17` — the `.transform()` on `item`. **Runs on every parse**, which includes
   every read out of D1 via `normalizeStoredContent`.
2. `app/content.ts:26` — `record()`, the seed-data constructor, materialises both into
   `initialContent`.
3. `app/edit/editor-workflow.ts:27` — the draft-recovery reconstruction path.
4. `app/research-section.tsx:22` — `ResearchCard` calls `researchIdentity(item)` **again at render
   time**, even though the schema transform has already set the field.

**What breaks if they are dropped.**

*Dropping `researchIdentity`:* the three original research cards fall back to `'general'`.

- `app/research-section.tsx:22` — `const topic = researchIdentity(item), Icon = researchIcons[topic]`.
  All three cards lose their distinct icon and colour and **render identically as slate**.
  `researchTopicLabels` (`research-identity.ts:3-8`) maps the four topics to "Nanomaterials ·
  blue", "Ultrasound · violet", "Photoacoustic · teal", "General research · slate" — the visual
  identity of the research section collapses to one colour.
- `app/edit/editor.tsx:47` — the "Card identity" `Select` shows `'general'` as the current value for
  cards the owner never set, **silently rewriting their identity on the next save**.

*Dropping `initialResearchLinks`:* the five seeded publications get `researchIds: []`.

- `app/publication-utils.ts:21` —
  `const matchesTopic = topic === 'all' || paper.researchIds?.includes(topic)`. The publications
  topic filter returns **zero results for every theme**.
- `app/research-section.tsx:23` —
  `const related = papers.filter(paper => paper.researchIds?.includes(item.id))`, rendered by
  `RelatedPapers` (line 13). Every research card shows **0 related papers**.

**Both failures are silent.** Nothing errors, nothing logs; the page renders with grey cards and
empty filters. **There is no test that would catch it.**

**The subtlety that makes this dangerous.** Because the transform runs on every parse *and* the
editor sends `validation.data` back on save (`save()` step 5), the derived values get
**materialised into storage** on the first save after the field was added. So for a long-running
instance the shims may already be redundant. But:

- The **seed** (`initialContent`) depends on them at construction time (`record()`), so a **fresh
  install is entirely dependent on them**.
- `docs/DESKTOP-START-HERE.md` establishes `initialContent` as the canonical starting content, and
  the local emulator row is that seed at revision 4 — so **the starting data is exactly the case
  that needs the shims**.
- **`??` (not `||`) is used in both**, so an explicit `[]` is preserved and never re-populated from
  the map. An implementation using `or`/falsy semantics would **resurrect links the owner
  deliberately cleared**.

> **Hazard.** A model that declares the equivalent of `research_topic: Topic | None = None` and
> `research_ids: list[str] = []` is *type-correct* and *behaviourally wrong*: it produces `None`
> where the original produces `'general'`, and `[]` where the original produces the seeded links.
> The four application sites listed above then quietly degrade. **The transform is not a validator
> — it is a defaulting rule that carries content, and it must be reproduced as logic, not as a
> field default.**

---

## The WebMCP `stage_academic_profile` tool

`app/edit/editor.tsx`, in the `useEffect` at line 81 (the file's dense formatting means the whole
registration is one statement on that line).

**Registration.** Reads `(document as {modelContext?: {registerTool?: Function}}).modelContext`. If
absent or without `registerTool`, the effect returns immediately — so this is entirely optional and
inert in an ordinary browser. An `AbortController` is created per mount and its signal passed as
`registerTool(tool, {signal})`; the cleanup returns `lifecycle.abort()`, so the tool is
unregistered when the editor unmounts. The whole call is wrapped in `try {} catch {}` **and**
`.catch(() => {})` on the returned promise — **registration failure is silently ignored by
design**.

**Declared tool:**

| Property | Value |
|---|---|
| `name` | `stage_academic_profile` |
| `title` | `Stage profile changes` |
| `description` | `Stage profile fields in the owner editor. Valid edits autosave as a draft; publishing is a separate owner action.` |
| `annotations` | `{readOnlyHint: false, untrustedContentHint: false}` |

**Input schema** — built programmatically from the six-key list:

```json
{ "type": "object",
  "properties": { "name":        {"type": "string"},
                  "role":        {"type": "string"},
                  "affiliation": {"type": "string"},
                  "headline":    {"type": "string"},
                  "intro":       {"type": "string"},
                  "bio":         {"type": "string"} },
  "additionalProperties": false }
```

**No `required` array** — every field is optional, and a call with an empty object is accepted.

**`execute(input)` validation** — re-checked in code, not trusted to the schema:

1. `if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('Expected profile fields')`
2. For every `[key, value]` entry: throw `new Error('Invalid profile field')` unless the key is one
   of the six **and** `typeof value === 'string'` **and** `value.length <= 10000`.

The 10,000 cap matches the `text` schema for `intro` and `bio` — but **not** `name` (max 100),
`role` (max 200), `affiliation` (max 200) or `headline` (max 240). **So the tool accepts values the
content schema will later reject.**

**What it does on success:**

- `edit(old => ({...old, ...input}))` — merges the fields into the editor's form state.
- `setTab('profile')` — switches the visible tab.
- `setMessage('Profile fields staged as a draft. Review before publishing.')`
- Returns `{staged: Object.keys(input), published: false}`.

**What it does not do:**

- It does **not** call `save()`. It does not write to the server.
- It does **not** publish. `published: false` is returned literally.
- It does not touch any of the five collections, appearance, copy, scene, or Scholar fields.
- It has **no privileged access of any kind**: it manipulates React state in a page the owner is
  already authenticated on. It cannot be reached by anyone who could not already type into the
  form.

**The one indirect effect worth recording.** Because `edit()` marks the document dirty, the **1.5 s
autosave timer arms**. So a staged change *will* be written to the server as a **draft** 1.5 s
later, without further human action — provided the document validates and no blocker (recovery,
conflict, upload, paused) is active. The tool description states this accurately ("Valid edits
autosave as a draft"), and it remains true that nothing is published. But **"stages only, never
saves" is not quite right at the system level**: it stages, and the surrounding autosave then
persists the draft.

**And the over-long-value interaction.** A 10,000-character `name` is accepted by `execute`, merged
into the form, and then fails `contentSchema` at `save()` step 2 — which sets `issues` and returns
`false` **without setting `paused`**. The autosave timer re-arms on the next content change, so the
editor sits with an unsaveable draft and a validation summary until the owner fixes it. Not a
security problem; a usability one, and **a divergence between two validation layers**.

> **Note.** This is frontend-only with no server component. Its only coupling to the backend is the
> autosave it indirectly triggers.

---

## What is genuinely good here

Recorded because an assessment that only lists problems misleads a reader about how much care to
take.

- **The concurrency design is sophisticated and correct.** The revision CAS plus random-token
  gating is a real ABA defence, correctly applied to exactly the statements that need it. Most
  codebases of this size do not have optimistic concurrency at all.
- **The batch is factored for inspection.** `contentWriteStatements()` is a pure function returning
  statements, separate from the executor. That is a deliberate testability affordance — unused, but
  present.
- **Error messages are written for a human under stress.** Nearly every one tells the owner what is
  *safe* as well as what failed. That is unusual and worth preserving verbatim.
- **Security headers on the media path are correct and complete** — `nosniff`, `sandbox`,
  `default-src 'none'`, `private, no-cache` — and they are what make the weaker upload-side checks
  tolerable.
- **Every SQL statement is parameterised.** The scan found no string-concatenated SQL anywhere.
- **Uniform denial as 404** on the media route avoids confirming the existence of private assets.
- **Comments explain *why*, not *what*.** The batch rationale, the retired `autoTour` field, the
  "keystrokes during this request belong to the next draft" note, the back-compat shim comments —
  these are the notes of someone thinking about the next reader.
- **Content provenance is documented** to an unusual standard in `docs/CONTENT-SOURCES.md`, with a
  stated rule that missing facts stay blank rather than being invented.

## Sources

- `aidlc/spaces/default/intents/260924-chiku-website-migration/inception/reverse-engineering/developer-scan.md`
  § `code-quality-assessment` (authoritative for this file), with the media access rule from
  § `api-documentation` and reachability facts from § `code-structure`.
- Source files cited inline: `madhavi-tripathi/app/content-persistence.ts`, `app/content.ts`,
  `app/upload-validation.ts`, `app/edit/editor-workflow.ts`, `app/edit/editor.tsx`,
  `app/research-identity.ts`, `app/site-copy.ts`, `app/research-section.tsx`,
  `app/publication-utils.ts`, `app/api/*/route.ts`, `app/server.ts`, `app/site-metadata.ts`,
  `app/scene.tsx`, `app/scene-performance.ts`, `components/ui/carousel.tsx`,
  `app/use-section-carousel.ts`, `eslint.config.mjs`, `README.md`,
  `docs/CONTENT-SOURCES.md`, `docs/DESKTOP-START-HERE.md`.
- Measurements: per-file line/byte/longest-line counts; built chunk sizes from the existing
  `dist/` output; local Miniflare D1 row inspection via `sqlite3`; an empirical `ZodIssueCode`
  experiment against the installed `zod@3.25.76`; exhaustive search confirming zero test files and
  zero test-framework dependencies.
